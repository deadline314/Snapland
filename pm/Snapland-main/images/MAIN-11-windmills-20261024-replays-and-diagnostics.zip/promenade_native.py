from pathlib import Path
import os,shutil,time,json,subprocess
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();stage=r/'work/tutorial-current-20261020/validation-project';out=r/'work/remaining-20261024/promenade-native-v1';out.mkdir(exist_ok=False)
name='work/remaining-20261024/promenade_native.gd';shutil.copy2(r/name,stage/name)
(stage/'work/remaining-20261024/promenade_native.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/remaining-20261024/promenade_native.gd" id="1"]\n[node name="Review" type="Node"]\nscript = ExtResource("1")\n')
rec=subprocess.Popen(['ffmpeg','-n','-v','error','-f','x11grab','-video_size','1280x720','-framerate','15','-i',os.environ['DISPLAY'],'-t','300','-c:v','libx264','-threads','1','-preset','ultrafast','-crf','22','-pix_fmt','yuv420p',str(out/'native.mp4')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
engine=str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64');cmd=[engine,'--path',str(stage),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--resolution','1280x720','--position','0,0','res://work/remaining-20261024/promenade_native.tscn'];t=time.monotonic()
try:
 try:p=run_validated_godot(stage,cmd,dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'save/progress.json'),SNAPLAND_REVIEW_DIR=str(out/'captures')),300);s=p.stdout+p.stderr;code=p.returncode
 except subprocess.TimeoutExpired as e:s=(e.stdout or '')+(e.stderr or '');code=124
finally:
 _,error=rec.communicate('q\n',timeout=20);(out/'record.log').write_text(error)
(out/'result.log').write_text(s);d={'exit':code,'errors':s.count('ERROR:'),'seconds':round(time.monotonic()-t,2),'recorder_exit':rec.returncode};(out/'result.json').write_text(json.dumps(d,indent=2));print(d);print(s[-4000:])
