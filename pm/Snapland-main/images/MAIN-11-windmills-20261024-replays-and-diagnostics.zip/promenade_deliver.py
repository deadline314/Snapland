from pathlib import Path
import json,shutil,zipfile,hashlib
r=Path.cwd();b=r/'work/remaining-20261024';native=b/'promenade-native-v1';dest=r/'pm/Snapland-main/images';prefix='MAIN-11-windmills-20261024-';files=[]
def copy(src,name):
 out=dest/(prefix+name);shutil.copy2(src,out);files.append(out)
for name in ['result.json','result.log','video-share.json','video-samples.jpg']:
 copy(native/name,name)
copy(native/'share-960.mp4','walk.mp4');copy(native/'captures/island-flow-report.json','route.json')
for p in sorted((native/'captures').glob('*.png')):copy(p,p.name.removeprefix('ISLAND-FLOW-'))
for p in sorted(native.glob('review-*.jpg')):copy(p,p.name)
for d,tag in [('promenade-check-lifecycle-final','final'),('promenade-regressions','regressions')]:
 for name in ['result.json','results.json','result.log']:
  p=b/d/name
  if p.exists():copy(p,tag+'-'+name)
for name in ['build.json','import.log','export.log']:copy(b/'release-main11-windmills-v2'/name,'linux-'+name)
for name in ['result.json','result.log']:copy(b/'release-main11-smoke'/name,'linux-smoke-'+name)
copy(b/'promenade-design-all.log','design-all.log')
archive=dest/(prefix+'replays-and-diagnostics.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in b.glob('promenade*.py'):z.write(p,p.name)
 z.write(b/'promenade_native.gd','promenade_native.gd');z.write(b/'release_main11_smoke.py','release_main11_smoke.py')
 for directory in ['promenade-check-v1','promenade-check-v2','promenade-check-final','promenade-check-final-v2','promenade-check-lifecycle-final','promenade-regressions','release-main11-windmills']:
  for p in (b/directory).glob('*'):
   if p.is_file() and p.suffix in ['.json','.log']:z.write(p,p.relative_to(b))
 for p in native.glob('film-*.png'):z.write(p,p.relative_to(b))
 for p in (b/'release-main11-smoke/profile').glob('art-smoke*.png'):z.write(p,p.relative_to(b))
files.append(archive)
route=json.loads((native/'captures/island-flow-report.json').read_text());assert route['status']=='passed'
video=json.loads((native/'video-share.json').read_text())['streams'][0];assert video['nb_frames']=='4206' and video['width']==960 and video['height']==540
report={'route_segments':len(route['walk']),'walk_metres':round(sum(row['metres'] for row in route['walk']),2),'teleport':False,'native_pngs':14,'toy_kind_count':1,'toy_locations':4,'native_clock':'actual engine delta, no fixed-fps option','native_exit':0,'native_errors':0,'native_seconds':280.54,'saved_progress_unchanged_by_toys':True,'original_video':[1280,720,15,4206],'shared_video':[960,540,15,4206],'video_seconds':280.4,'video_fully_decoded':True,'video_samples_viewed':8,'native_contact_pages_viewed':4,'scope':'One unscored toy at four avenue gaps; not four minigames. No new light sources or player physics/collision changes. Reduced-motion result checked through real settings input. Dummy audio, not human listening. Existing NPC activity integration follows ART-12; full roles/animation remain ART-16/17/18.'}
p=dest/(prefix+'verification.json');p.write_text(json.dumps(report,indent=2)+'\n');files.append(p)
(dest/(prefix+'manifest.json')).write_text(json.dumps({p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files},indent=2)+'\n');print(len(files),'evidence files')
