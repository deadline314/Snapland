from pathlib import Path
import shutil,os,time,json,subprocess
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();stage=r/'work/tutorial-current-20261020/validation-project';out=r/'work/remaining-20261024/promenade-check-lifecycle-final';out.mkdir(exist_ok=False)
for name in ['game/world/promenade_play.gd','game/world/coastal_play.gd','game/data/wayfinding.json','game/ui/wardrobe_panel.gd','game/tests/test_promenade_play.gd']:
 shutil.copy2(r/name,stage/name)
engine=str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64');cmd=[engine,'--headless','--path',str(stage),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--verbose','--script','res://game/tests/test_promenade_play.gd'];t=time.monotonic()
try:p=run_validated_godot(stage,cmd,dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'save/progress.json')),90);s=p.stdout+p.stderr;code=p.returncode
except subprocess.TimeoutExpired as e:s=(e.stdout or '')+(e.stderr or '');code=124
(out/'result.log').write_text(s);d={'exit':code,'errors':s.count('ERROR:'),'seconds':round(time.monotonic()-t,2)};(out/'result.json').write_text(json.dumps(d,indent=2));print(d);print(s[-4000:])
