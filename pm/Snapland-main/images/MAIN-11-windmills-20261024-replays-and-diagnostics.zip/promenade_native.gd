extends "res://game/tests/native_island_flow_review.gd"
func _run() -> void:
	get_window().size=Vector2i(1280,720)
	_progress=get_tree().root.get_node("Progress")
	_progress.reset_progress();_progress.intro_seen=true;_progress.save_progress()
	_glyph_watch_enabled=false
	_report["toys"]=[]
	_main=MAIN_SCENE.instantiate();get_tree().root.add_child(_main)
	await _frames(10)
	# Wear via the real closet; no duplicate world toast should survive it.
	await _press(KEY_C)
	if not await _named("Tab_closet"):return
	if not await _named("WardrobeItem_outfit-rainvest"):return
	if not await _named("WearSelected"):return
	await _press(KEY_ESCAPE)
	if _main.toast.text.contains("已穿戴"):_fail("Wardrobe status repeated over world signs");return
	var protected:=FileAccess.get_file_as_bytes(OS.get_environment("SNAPLAND_SAVE_PATH"))
	await _walk_path("plaza-and-ticket",[Vector2(0,15),PLAZA_SIGN_STAND,TICKET_STAND,Vector2(-4.2,-4.2),Vector2(-1.6,-9.0)])
	if not _ok():return
	for index in _main.world.coastal_play.promenade.records.size():
		var record: Dictionary=_main.world.coastal_play.promenade.records[index]
		var before: int=record.turns
		if index==1:await _walk("bypass-avenue-sign",Vector2(-1.4,-21.2))
		await _walk("pressure-pad-%d"%index,Vector2(record.center.x,record.center.z))
		if not _ok():return
		await _frames(8)
		if int(record.turns)<=before:_fail("Actual walking did not activate pressure pad %d"%index);return
		await _shot("pad-%d-stepped"%index)
		await _frames(24)
		var held: int=record.turns
		await _frames(12)
		if int(record.turns)!=held:_fail("Standing repeatedly triggered a pressure pad");return
		if str(_main.world.nearest.get("id",""))!=record.id:_fail("Nearby context did not select windmill");return
		await _press(KEY_E)
		if int(record.turns)!=held+1:_fail("Context E did not turn the same windmill");return
		await _frames(12)
		await _shot("pad-%d-context"%index)
		(_report.toys as Array).append({"id":record.id,"walk_activated":true,"context_activated":true,"turns":record.turns,"angle":record.rotor.rotation.z})
	# Pause the real Main while the last windmill has its saved orientation.
	await _press(KEY_ESCAPE)
	var last: Dictionary=_main.world.coastal_play.promenade.records[3]
	var angle: float=last.rotor.rotation.z
	await _frames(16)
	if not is_equal_approx(angle,last.rotor.rotation.z):_fail("Paused world continued toy motion");return
	await _press(KEY_ESCAPE)
	await _walk_path("return-to-dock",[Vector2(0,-35),Vector2(-1.5,-21.2),Vector2(-1.5,-18),Vector2(-1.6,-9),Vector2(-4.2,-4.2),TICKET_STAND,PLAZA_SIGN_STAND,Vector2(0,15),Vector2(0,23.2)])
	if not _ok():return
	if protected!=FileAccess.get_file_as_bytes(OS.get_environment("SNAPLAND_SAVE_PATH")):_fail("Unscored walking toys changed the complete saved progress");return
	await _shot("dock-return")
	# Different phases are intentional settings changes, outside that assertion.
	for phase in ["dawn","dusk","night"]:
		await _select_phase(phase)
		if not _ok():return
		await _shot("dock-"+phase)
	await _walk_path("night-avenue",[Vector2(0,15),PLAZA_SIGN_STAND,TICKET_STAND,Vector2(-4.2,-4.2),Vector2(-1.6,-9),Vector2(-1.4,-16)])
	if not _ok():return
	await _shot("pad-night")
	_main._show_settings();await _frames(4)
	if not await _named("SettingsTab_play"):return
	if not await _named("Value_reduced_motion"):return
	await _press(KEY_ESCAPE)
	if not _main.world.reduced_motion:_fail("Actual reduced-motion checkbox not applied");return
	protected=FileAccess.get_file_as_bytes(OS.get_environment("SNAPLAND_SAVE_PATH"))
	await _frames(24);await _press(KEY_E)
	var first: Dictionary=_main.world.coastal_play.promenade.records[0]
	if not is_equal_approx(first.rotor.rotation.z,fposmod(float(first.target),TAU)):_fail("Reduced-motion windmill did not snap to its result");return
	if protected!=FileAccess.get_file_as_bytes(OS.get_environment("SNAPLAND_SAVE_PATH")):_fail("Reduced-motion toy changed progress");return
	await _shot("pad-night-reduced")
	_report.status="passed";_report["save_unchanged_by_toys"]=true;_write_report()
	print("PASS: native promenade four walk-up and context toys, dock round trip, four phases, reduced-motion checkbox and unchanged progress")
	await _main._quit_game()
func _named(node_name: String) -> bool:
	var button:=_main.overlay.find_child(node_name,true,false) as BaseButton
	if button==null:_fail("Missing normal UI button: "+node_name);return false
	await _click(button);await _frames(4)
	return _ok()
