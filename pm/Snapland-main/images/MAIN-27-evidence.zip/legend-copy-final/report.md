# MAIN-27 truthful welcome legend

Diff: legend now says 右側：園區路口; focused test retains both route labels, verifies all nine gate targets, and rejects the old all-unavailable claim. No data or layout change.

Command: `['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--headless', '--path', 'C:\\Users\\stanl\\Github\\Snapland', '--log-file', 'C:\\Users\\stanl\\Github\\Snapland\\.review\\region-map-main27-20261117\\legend-copy-final\\travel-book-engine.log', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', 'res://game/tests/test_travel_book_ui.tscn']`

Save: `C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\legend-copy-final\travel-book-profile\progress.json`

Result: travel collection UI tests exited 1:
Godot Engine v4.7.2.stable.official.ed1daf0bf - https://godotengine.org


SCRIPT ERROR: Parse Error: Cannot infer the type of "legend" variable because the value doesn't have a set type.
   at: GDScript::reload (res://game/tests/test_travel_book_ui.gd:72)
ERROR: Failed to load script "res://game/tests/test_travel_book_ui.gd" with error "Parse error".
   at: load (modules/gdscript/gdscript_resource_format.cpp:46)

Only travel collection UI suite rerun.

Final command: `['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--headless', '--path', 'C:\\Users\\stanl\\Github\\Snapland', '--log-file', 'C:\\Users\\stanl\\Github\\Snapland\\.review\\region-map-main27-20261117\\legend-copy-final\\green-travel-book-engine.log', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', 'res://game/tests/test_travel_book_ui.tscn']`

Save: `C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\legend-copy-final\green-travel-book-profile\progress.json`

Result: PASS, unchanged existing completion marker and zero engine ERROR

Initial focused test needed explicit Node annotation because Main overlay is dynamically typed; raw parse-failure log retained, owned failed process terminated before this rerun.
