# MAIN-27 worker evidence

Scope: `game/main.gd::_show_map`, `_show_region_games`, `_close`; `test_region_travel.gd`; twelve existing harbor Main fixtures; `native_rowing_main.gd`. No Git, PM, registry, AudioDirector, retake, or SG-41 files changed by this worker.

Behavioral RED evidence is root-owned `800x600-red/`: actual native harbor map/footer overflow with all seventeen locations and twelve delivered game actions. Worker initially attempted the strengthened travel regression before changing runtime code, but that attempt hit an indentation parse error and timed out at 100s; it is not counted as behavioral RED. The parse error is preserved in `worker-green-region-travel.log`; indentation was corrected. The next corrected run had no engine errors but exceeded its initial 45s bound during repeated world rebuilds, so the final run uses the existing validated launcher with a 180s bound.

All commands below were run through `tools.godot_entrypoints.run_validated_godot` with explicit absolute isolated `SNAPLAND_SAVE_PATH`. `run_game_tests.result_error` checks unchanged completion markers and rejects every engine ERROR. No editor/import was run. Warnings from existing occlusion materials and synthetic UI photo fixtures remain visible in logs.

No PASS marker text or numeric suite count changed, so no registry change is needed.


Command: `['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--headless', '--path', 'C:\\Users\\stanl\\Github\\Snapland', '--log-file', 'C:\\Users\\stanl\\Github\\Snapland\\.review\\region-map-main27-20261117\\worker-green-region-travel-engine.log', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', '--max-fps', '120', 'res://game/tests/test_region_travel.tscn']`

Save: `C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\worker-green-save\progress.json`

Result: TIMEOUT

Command: `['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--headless', '--path', 'C:\\Users\\stanl\\Github\\Snapland', '--log-file', 'C:\\Users\\stanl\\Github\\Snapland\\.review\\region-map-main27-20261117\\worker-green2-region-travel-engine.log', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', '--max-fps', '120', 'res://game/tests/test_region_travel.tscn']`

Save: `C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\worker-green2-save\progress.json`

Result: TIMEOUT

## sandbar Main tests

Command: `['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--log-file', 'C:\\Users\\stanl\\Github\\Snapland\\.review\\region-map-main27-20261117\\sandbar-Main-tests-engine.log', '--headless', '--path', 'C:\\Users\\stanl\\Github\\Snapland', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', 'res://game/tests/test_tide_sandbar_main.tscn']`

Save: `C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\sandbar-Main-tests-profile\progress.json`

Result: PASS, existing exact completion marker and no engine ERROR

## prism Main tests

Command: `['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--log-file', 'C:\\Users\\stanl\\Github\\Snapland\\.review\\region-map-main27-20261117\\prism-Main-tests-engine.log', '--headless', '--path', 'C:\\Users\\stanl\\Github\\Snapland', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', 'res://game/tests/test_lighthouse_prism_main.tscn']`

Save: `C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\prism-Main-tests-profile\progress.json`

Result: PASS, existing exact completion marker and no engine ERROR

## rowing Main tests

Command: `['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--log-file', 'C:\\Users\\stanl\\Github\\Snapland\\.review\\region-map-main27-20261117\\rowing-Main-tests-engine.log', '--headless', '--path', 'C:\\Users\\stanl\\Github\\Snapland', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', 'res://game/tests/test_rowing_main.tscn']`

Save: `C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\rowing-Main-tests-profile\progress.json`

Result: PASS, existing exact completion marker and no engine ERROR

## tug Main tests

Command: `['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--log-file', 'C:\\Users\\stanl\\Github\\Snapland\\.review\\region-map-main27-20261117\\tug-Main-tests-engine.log', '--headless', '--path', 'C:\\Users\\stanl\\Github\\Snapland', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', 'res://game/tests/test_rope_tug_main.tscn']`

Save: `C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\tug-Main-tests-profile\progress.json`

Result: PASS, existing exact completion marker and no engine ERROR

## crab Main tests

Command: `['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--log-file', 'C:\\Users\\stanl\\Github\\Snapland\\.review\\region-map-main27-20261117\\crab-Main-tests-engine.log', '--headless', '--path', 'C:\\Users\\stanl\\Github\\Snapland', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', 'res://game/tests/test_crab_marbles_main.tscn']`

Save: `C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\crab-Main-tests-profile\progress.json`

Result: PASS, existing exact completion marker and no engine ERROR

## cargo Main tests

Command: `['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--log-file', 'C:\\Users\\stanl\\Github\\Snapland\\.review\\region-map-main27-20261117\\cargo-Main-tests-engine.log', '--headless', '--path', 'C:\\Users\\stanl\\Github\\Snapland', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', 'res://game/tests/test_cargo_balance_main.tscn']`

Save: `C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\cargo-Main-tests-profile\progress.json`

Result: PASS, existing exact completion marker and no engine ERROR

## relay Main tests

Command: `['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--log-file', 'C:\\Users\\stanl\\Github\\Snapland\\.review\\region-map-main27-20261117\\relay-Main-tests-engine.log', '--headless', '--path', 'C:\\Users\\stanl\\Github\\Snapland', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', 'res://game/tests/test_buoy_relay_main.tscn']`

Save: `C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\relay-Main-tests-profile\progress.json`

Result: PASS, existing exact completion marker and no engine ERROR

## sail Main tests

Command: `['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--log-file', 'C:\\Users\\stanl\\Github\\Snapland\\.review\\region-map-main27-20261117\\sail-Main-tests-engine.log', '--headless', '--path', 'C:\\Users\\stanl\\Github\\Snapland', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', 'res://game/tests/test_sail_chase_main.tscn']`

Save: `C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\sail-Main-tests-profile\progress.json`

Result: PASS, existing exact completion marker and no engine ERROR

## shell Main tests

Command: `['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--log-file', 'C:\\Users\\stanl\\Github\\Snapland\\.review\\region-map-main27-20261117\\shell-Main-tests-engine.log', '--headless', '--path', 'C:\\Users\\stanl\\Github\\Snapland', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', 'res://game/tests/test_shell_tide_main.tscn']`

Save: `C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\shell-Main-tests-profile\progress.json`

Result: PASS, existing exact completion marker and no engine ERROR

## anchor Main tests

Command: `['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--log-file', 'C:\\Users\\stanl\\Github\\Snapland\\.review\\region-map-main27-20261117\\anchor-Main-tests-engine.log', '--headless', '--path', 'C:\\Users\\stanl\\Github\\Snapland', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', 'res://game/tests/test_anchor_chain_main.tscn']`

Save: `C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\anchor-Main-tests-profile\progress.json`

Result: PASS, existing exact completion marker and no engine ERROR

## gull Main tests

Command: `['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--log-file', 'C:\\Users\\stanl\\Github\\Snapland\\.review\\region-map-main27-20261117\\gull-Main-tests-engine.log', '--headless', '--path', 'C:\\Users\\stanl\\Github\\Snapland', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', 'res://game/tests/test_gull_glide_main.tscn']`

Save: `C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\gull-Main-tests-profile\progress.json`

Result: PASS, existing exact completion marker and no engine ERROR

## lock Main tests

Command: `['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--log-file', 'C:\\Users\\stanl\\Github\\Snapland\\.review\\region-map-main27-20261117\\lock-Main-tests-engine.log', '--headless', '--path', 'C:\\Users\\stanl\\Github\\Snapland', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', 'res://game/tests/test_tide_lock_main.tscn']`

Save: `C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\lock-Main-tests-profile\progress.json`

Result: PASS, existing exact completion marker and no engine ERROR

## travel collection UI tests

Command: `['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--log-file', 'C:\\Users\\stanl\\Github\\Snapland\\.review\\region-map-main27-20261117\\travel-collection-UI-tests-engine.log', '--headless', '--path', 'C:\\Users\\stanl\\Github\\Snapland', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', 'res://game/tests/test_travel_book_ui.tscn']`

Save: `C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\travel-collection-UI-tests-profile\progress.json`

Result: PASS, existing exact completion marker and no engine ERROR

## pixel UI collection tests

Command: `['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--log-file', 'C:\\Users\\stanl\\Github\\Snapland\\.review\\region-map-main27-20261117\\pixel-UI-collection-tests-engine.log', '--headless', '--path', 'C:\\Users\\stanl\\Github\\Snapland', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', 'res://game/tests/test_pixel_ui_collections.tscn']`

Save: `C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\pixel-UI-collection-tests-profile\progress.json`

Result: PASS, existing exact completion marker and no engine ERROR

## rowing native fixture tests

Command: `['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--log-file', 'C:\\Users\\stanl\\Github\\Snapland\\.review\\region-map-main27-20261117\\rowing-native-fixture-tests-engine.log', '--headless', '--path', 'C:\\Users\\stanl\\Github\\Snapland', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', 'res://game/tests/native_rowing_main.tscn', '--', '--rowing-preflight']`

Save: `C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\rowing-native-fixture-tests-profile\progress.json`

Result: PASS, existing exact completion marker and no engine ERROR

Command: `['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--headless', '--path', 'C:\\Users\\stanl\\Github\\Snapland', '--log-file', 'C:\\Users\\stanl\\Github\\Snapland\\.review\\region-map-main27-20261117\\worker-green3-region-travel-engine.log', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', '--max-fps', '120', 'res://game/tests/test_region_travel.tscn']`

Save: `C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\worker-green3-save\progress.json`

Result: PASS, existing exact completion marker and no engine ERROR

## pixel UI shell tests

Command: `['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--log-file', 'C:\\Users\\stanl\\Github\\Snapland\\.review\\region-map-main27-20261117\\pixel-UI-shell-tests-engine.log', '--headless', '--path', 'C:\\Users\\stanl\\Github\\Snapland', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', 'res://game/tests/test_pixel_ui_shell.tscn']`

Save: `C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\pixel-UI-shell-tests-profile\progress.json`

Result: PASS, existing exact completion marker and no engine ERROR

## Final region travel (includes reset from game entries)

Command: `['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--headless', '--path', 'C:\\Users\\stanl\\Github\\Snapland', '--log-file', 'C:\\Users\\stanl\\Github\\Snapland\\.review\\region-map-main27-20261117\\worker-final-region-travel-engine.log', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', '--max-fps', '120', 'res://game/tests/test_region_travel.tscn']`

Save: `C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\worker-final-save\progress.json`

Result: PASS, existing exact completion marker and no engine ERROR

## Welcome map review round 1

Root expanded MAIN-27 scope to include the pre-existing welcome map footer overflow and inaccurate entry-page back copy. Final 4/4 affected suites PASS; see `welcome-fix-round1/report.md` for exact commands and raw red/green logs. Unchanged PASS markers; no registry update needed.
