from pathlib import Path
import hashlib,json,os,sys
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from tools.godot_entrypoints import run_validated_godot
size=sys.argv[1];tag=sys.argv[2]
assert size in ['800x600','1280x720','1920x1080'] and tag.isalnum()
out=ROOT/'.review/region-map-main27-20261117'/f'{size}-{tag}'
assert not out.exists();out.mkdir(parents=True)
env=dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'profile/progress.json'),SNAPLAND_MAP_REVIEW_OUTPUT=str(out),SNAPLAND_MAP_REVIEW_SIZE=size)
sources=['game/main.gd','game/ui/harbor_map_panel.gd','game/tests/native_region_map_review.gd','game/tests/native_region_map_review.tscn','game/tests/native_region_travel_review.gd']
(out/'source_hashes.json').write_text(json.dumps({n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in sources},indent=2),encoding='utf-8')
result=run_validated_godot(ROOT,[r'C:\Tools\Godot\Godot_v4.7.2-stable_win64_console.exe','--path',str(ROOT),'--log-file',str(out/'engine.log'),'--rendering-method','gl_compatibility','--audio-driver','Dummy','--fixed-fps','60','res://game/tests/native_region_map_review.tscn','--quit-after','1500'],env=env,timeout=120)
log=result.stdout+result.stderr+'\n'+(out/'engine.log').read_text(encoding='utf-8')
(out/'native.log').write_text(log,encoding='utf-8')
(out/'result.json').write_text(json.dumps({'exit':result.returncode}),encoding='utf-8')
report=json.loads((out/'report.json').read_text(encoding='utf-8'))
if tag=='red':
    assert result.returncode!=0 and report['failures']
    print('EXPECTED RED',report['failures'],flush=True)
else:
    assert result.returncode==0 and 'ERROR:' not in log and 'PASS: native regional maps' in log and not report['failures']
    print('PASS native regional maps',size,len(report['captures']),flush=True)
