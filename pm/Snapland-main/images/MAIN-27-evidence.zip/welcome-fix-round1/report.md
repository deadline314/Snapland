# MAIN-27 welcome map fix round 1

Final results: 4/4 PASS, unchanged existing suite markers, zero engine ERROR: travel collection UI, region travel, pixel UI collections, pixel UI shell. First sixteen checks from the original regional-page change remain in the parent worker-report.md; twelve game outcome fixtures were not rerun because this round only changes welcome map layout and entry back copy.

The corrected physical-window regression produced behavioral RED for welcome selected-details/back bounds at800x600 (both text sizes), before the responsive code change. That first RED also showed later album/HUD assertions depended on the old map test's final forced1280 window; initialization was made explicit before scene creation, and each map case now restores its captured geometry. The first runtime green had only an existing avatar-floor-settling race in the unchanged no-teleport assertion; a bounded wait for real is_on_floor fixes fixture timing while preserving the exact original position equality assertion.

The final physical map checks include all12stops/all9gates, stop-vs-gate separation, every selected destination and footer bounds, target/font fit, and in-place1280↔800 live resize with identical descendant count. No source data, station projection, rewards, generic Paper style, registry, PM, Git, retake, or SG-41 changes.

All commands below use run_validated_godot, unique absolute save paths, 180s outer timeout; no editor/import was run. No human gameplay or visual approval is claimed. Root owns native800/1280/1920 captures.


RED command: `['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--headless', '--path', 'C:\\Users\\stanl\\Github\\Snapland', '--log-file', 'C:\\Users\\stanl\\Github\\Snapland\\.review\\region-map-main27-20261117\\welcome-fix-round1\\red-travel-book-engine.log', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', 'res://game/tests/test_travel_book_ui.tscn']`

Save: `C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\welcome-fix-round1\red-travel-book-profile\progress.json`

Result: travel collection UI tests exited 1:
0px, 16:9 photos, and readable captions
   at: push_error (core/variant/variant_utility.cpp:1023)
   GDScript backtrace (most recent call first):
       [0] _check (res://game/tests/test_travel_book_ui.gd:430)
       [1] _test_album (res://game/tests/test_travel_book_ui.gd:174)
       [2] _frames (res://game/tests/test_travel_book_ui.gd:424)
ERROR: FAIL: the ordinary collection shows one four-photo row at wide physical widths
   at: push_error (core/variant/variant_utility.cpp:1023)
   GDScript backtrace (most recent call first):
       [0] _check (res://game/tests/test_travel_book_ui.gd:430)
       [1] _test_album (res://game/tests/test_travel_book_ui.gd:175)
       [2] _frames (res://game/tests/test_travel_book_ui.gd:424)
ERROR: FAIL: wide album keeps four complete cards, category/detail/page controls inside the book paper and actual Scroll clip
   at: push_error (core/variant/variant_utility.cpp:1023)
   GDScript backtrace (most recent call first):
       [0] _check (res://game/tests/test_travel_book_ui.gd:430)
       [1] _test_album (res://game/tests/test_travel_book_ui.gd:197)
       [2] _frames (res://game/tests/test_travel_book_ui.gd:424)
ERROR: FAIL: album texture uses a complete centered 16:9 image at 220×124 minimum without crop or distortion
   at: push_error (core/variant/variant_utility.cpp:1023)
   GDScript backtrace (most recent call first):
       [0] _check (res://game/tests/test_travel_book_ui.gd:430)
       [1] _test_album (res://game/tests/test_travel_book_ui.gd:212)
       [2] _frames (res://game/tests/test_travel_book_ui.gd:424)
ERROR: FAIL: all ordinary IDs remain browsable across five four-slot pages
   at: push_error (core/variant/variant_utility.cpp:1023)
   GDScript backtrace (most recent call first):
       [0] _check (res://game/tests/test_travel_book_ui.gd:430)
       [1] _test_album (res://game/tests/test_travel_book_ui.gd:220)
       [2] _activate (res://game/tests/test_travel_book_ui.gd:421)
       [3] _frames (res://game/tests/test_travel_book_ui.gd:424)
ERROR: FAIL: book page control advances to the next four devil prints
   at: push_error (core/variant/variant_utility.cpp:1023)
   GDScript backtrace (most recent call first):
       [0] _check (res://game/tests/test_travel_book_ui.gd:430)
       [1] _test_album (res://game/tests/test_travel_book_ui.gd:234)
       [2] _activate (res://game/tests/test_travel_book_ui.gd:421)
       [3] _frames (res://game/tests/test_travel_book_ui.gd:424)
ERROR: FAIL: all visible HUD rectangles including empty toast and quest fit at 1280px
   at: push_error (core/variant/variant_utility.cpp:1023)
   GDScript backtrace (most recent call first):
       [0] _check (res://game/tests/test_travel_book_ui.gd:430)
       [1] _test_small_physical_menus (res://game/tests/test_travel_book_ui.gd:287)
       [2] _run (res://game/tests/test_travel_book_ui.gd:40)
       [3] _test_achievements (res://game/tests/test_travel_book_ui.gd:266)
       [4] _frames (res://game/tests/test_travel_book_ui.gd:424)
WARNING: Photo 'photo-welcome-game-1' screenshot has unexpected IHDR dimensions 32x18 at 'C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\welcome-fix-round1\red-travel-book-profile/album-test-frame.png' (expected 320x180); decoder was not called.
   at: push_warning (core/variant/variant_utility.cpp:1033)
   GDScript backtrace (most recent call first):
       [0] _read_game_photo_image (res://game/core/progress.gd:468)
       [1] _saved_texture (res://game/ui/collection_book_panel.gd:635)
       [2] _photo_tile (res://game/ui/collection_book_panel.gd:482)
       [3] _refresh_book (res://game/ui/collection_book_panel.gd:252)
       [4] _ready (res://game/ui/collection_book_panel.gd:167)
       [5] _show_album (res://game/main.gd:1667)
       [6] _test_small_physical_menus (res://game/tests/test_travel_book_ui.gd:302)
       [7] _frames (res://game/tests/test_travel_book_ui.gd:424)
WARNING: Photo 'photo-welcome-game-2' screenshot cannot be opened: 'C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\welcome-fix-round1\red-travel-book-profile/album-test-frame.png.missing'.
   at: push_warning (core/variant/variant_utility.cpp:1033)
   GDScript backtrace (most recent call first):
       [0] _read_game_photo_image (res://game/core/progress.gd:448)
       [1] _saved_texture (res://game/ui/collection_book_panel.gd:635)
       [2] _photo_tile (res://game/ui/collection_book_panel.gd:482)
       [3] _refresh_book (res://game/ui/collection_book_panel.gd:252)
       [4] _ready (res://game/ui/collection_book_panel.gd:167)
       [5] _show_album (res://game/main.gd:1667)
       [6] _test_small_physical_menus (res://game/tests/test_travel_book_ui.gd:302)
       [7] _frames (res://game/tests/test_travel_book_ui.gd:424)
ERROR: Travel/book UI failures: ["selecting every future gate keeps map details and return visible at 800x600", "all twelve station descriptions preserve the map and return control at 800x600", "selected destination details and fixed back fit actual 800x600", "selecting every future gate keeps map details and return visible at 800x600", "all twelve station descriptions preserve the map and return control at 800x600", "selected destination details and fixed back fit actual 800x600", "four album cards keep at least 232×200px, 16:9 photos, and readable captions", "the ordinary collection shows one four-photo row at wide physical widths", "wide album keeps four complete cards, category/detail/page controls inside the book paper and actual Scroll clip", "album texture uses a complete centered 16:9 image at 220×124 minimum without crop or distortion", "all ordinary IDs remain browsable across five four-slot pages", "book page control advances to the next four devil prints", "all visible HUD rectangles including empty toast and quest fit at 1280px"]
   at: push_error (core/variant/variant_utility.cpp:1023)
   GDScript backtrace (most recent call first):
       [0] _finish (res://game/tests/test_travel_book_ui.gd:453)

GREEN command: `['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--headless', '--path', 'C:\\Users\\stanl\\Github\\Snapland', '--log-file', 'C:\\Users\\stanl\\Github\\Snapland\\.review\\region-map-main27-20261117\\welcome-fix-round1\\green-travel-book-engine.log', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', 'res://game/tests/test_travel_book_ui.tscn']`

Save: `C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\welcome-fix-round1\green-travel-book-profile\progress.json`

Result: travel collection UI tests exited 1:
:
       [0] _warn_unsupported_material (res://game/world/occlusion_controller.gd:178)
       [1] _sync_capture_coastal_surfaces (res://game/world/occlusion_controller.gd:266)
       [2] finish_building (res://game/world/occlusion_controller.gd:223)
       [3] _build_attraction_districts (res://game/world/park_world.gd:1441)
       [4] _build_avenue (res://game/world/park_world.gd:1393)
       [5] _build_region_geometry (res://game/world/park_world.gd:179)
       [6] _ready (res://game/world/park_world.gd:160)
       [7] _ready (res://game/main.gd:86)
       [8] _run (res://game/tests/test_travel_book_ui.gd:34)
WARNING: OcclusionController: unsupported ShaderMaterial building material on /root/Snapland/@Node3D@2/AttractionDistricts/MoonshadowStage/@MeshInstance3D@1050; preserving it without cutaway
   at: push_warning (core/variant/variant_utility.cpp:1033)
   GDScript backtrace (most recent call first):
       [0] _warn_unsupported_material (res://game/world/occlusion_controller.gd:178)
       [1] _sync_capture_coastal_surfaces (res://game/world/occlusion_controller.gd:266)
       [2] finish_building (res://game/world/occlusion_controller.gd:223)
       [3] _build_attraction_districts (res://game/world/park_world.gd:1441)
       [4] _build_avenue (res://game/world/park_world.gd:1393)
       [5] _build_region_geometry (res://game/world/park_world.gd:179)
       [6] _ready (res://game/world/park_world.gd:160)
       [7] _ready (res://game/main.gd:86)
       [8] _run (res://game/tests/test_travel_book_ui.gd:34)
ERROR: FAIL: selecting a map destination does not teleport the avatar
   at: push_error (core/variant/variant_utility.cpp:1023)
   GDScript backtrace (most recent call first):
       [0] _check (res://game/tests/test_travel_book_ui.gd:431)
       [1] _test_map (res://game/tests/test_travel_book_ui.gd:76)
       [2] _activate (res://game/tests/test_travel_book_ui.gd:422)
       [3] _frames (res://game/tests/test_travel_book_ui.gd:425)
WARNING: Photo 'photo-welcome-game-1' screenshot has unexpected IHDR dimensions 32x18 at 'C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\welcome-fix-round1\green-travel-book-profile/album-test-frame.png' (expected 320x180); decoder was not called.
   at: push_warning (core/variant/variant_utility.cpp:1033)
   GDScript backtrace (most recent call first):
       [0] _read_game_photo_image (res://game/core/progress.gd:468)
       [1] _saved_texture (res://game/ui/collection_book_panel.gd:635)
       [2] _photo_tile (res://game/ui/collection_book_panel.gd:482)
       [3] _refresh_book (res://game/ui/collection_book_panel.gd:252)
       [4] _ready (res://game/ui/collection_book_panel.gd:167)
       [5] _show_album (res://game/main.gd:1667)
       [6] _test_album (res://game/tests/test_travel_book_ui.gd:157)
       [7] _run (res://game/tests/test_travel_book_ui.gd:38)
       [8] _test_map (res://game/tests/test_travel_book_ui.gd:154)
       [9] _frames (res://game/tests/test_travel_book_ui.gd:425)
WARNING: Photo 'photo-welcome-game-2' screenshot cannot be opened: 'C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\welcome-fix-round1\green-travel-book-profile/album-test-frame.png.missing'.
   at: push_warning (core/variant/variant_utility.cpp:1033)
   GDScript backtrace (most recent call first):
       [0] _read_game_photo_image (res://game/core/progress.gd:448)
       [1] _saved_texture (res://game/ui/collection_book_panel.gd:635)
       [2] _photo_tile (res://game/ui/collection_book_panel.gd:482)
       [3] _refresh_book (res://game/ui/collection_book_panel.gd:252)
       [4] _ready (res://game/ui/collection_book_panel.gd:167)
       [5] _show_album (res://game/main.gd:1667)
       [6] _test_album (res://game/tests/test_travel_book_ui.gd:157)
       [7] _run (res://game/tests/test_travel_book_ui.gd:38)
       [8] _test_map (res://game/tests/test_travel_book_ui.gd:154)
       [9] _frames (res://game/tests/test_travel_book_ui.gd:425)
WARNING: Photo 'photo-welcome-game-1' screenshot has unexpected IHDR dimensions 32x18 at 'C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\welcome-fix-round1\green-travel-book-profile/album-test-frame.png' (expected 320x180); decoder was not called.
   at: push_warning (core/variant/variant_utility.cpp:1033)
   GDScript backtrace (most recent call first):
       [0] _read_game_photo_image (res://game/core/progress.gd:468)
       [1] _saved_texture (res://game/ui/collection_book_panel.gd:635)
       [2] _photo_tile (res://game/ui/collection_book_panel.gd:482)
       [3] _refresh_book (res://game/ui/collection_book_panel.gd:252)
       [4] _ready (res://game/ui/collection_book_panel.gd:167)
       [5] _show_album (res://game/main.gd:1667)
       [6] _test_small_physical_menus (res://game/tests/test_travel_book_ui.gd:303)
       [7] _frames (res://game/tests/test_travel_book_ui.gd:425)
WARNING: Photo 'photo-welcome-game-2' screenshot cannot be opened: 'C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\welcome-fix-round1\green-travel-book-profile/album-test-frame.png.missing'.
   at: push_warning (core/variant/variant_utility.cpp:1033)
   GDScript backtrace (most recent call first):
       [0] _read_game_photo_image (res://game/core/progress.gd:448)
       [1] _saved_texture (res://game/ui/collection_book_panel.gd:635)
       [2] _photo_tile (res://game/ui/collection_book_panel.gd:482)
       [3] _refresh_book (res://game/ui/collection_book_panel.gd:252)
       [4] _ready (res://game/ui/collection_book_panel.gd:167)
       [5] _show_album (res://game/main.gd:1667)
       [6] _test_small_physical_menus (res://game/tests/test_travel_book_ui.gd:303)
       [7] _frames (res://game/tests/test_travel_book_ui.gd:425)
ERROR: Travel/book UI failures: ["selecting a map destination does not teleport the avatar"]
   at: push_error (core/variant/variant_utility.cpp:1023)
   GDScript backtrace (most recent call first):
       [0] _finish (res://game/tests/test_travel_book_ui.gd:454)

## travel collection UI tests

Command: `['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--log-file', 'C:\\Users\\stanl\\Github\\Snapland\\.review\\region-map-main27-20261117\\welcome-fix-round1\\final-travel-collection-UI-tests-engine.log', '--headless', '--path', 'C:\\Users\\stanl\\Github\\Snapland', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', 'res://game/tests/test_travel_book_ui.tscn']`

Save: `C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\welcome-fix-round1\final-travel-collection-UI-tests-profile\progress.json`

Result: PASS, existing exact completion marker and no engine ERROR

## pixel UI collection tests

Command: `['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--log-file', 'C:\\Users\\stanl\\Github\\Snapland\\.review\\region-map-main27-20261117\\welcome-fix-round1\\final-pixel-UI-collection-tests-engine.log', '--headless', '--path', 'C:\\Users\\stanl\\Github\\Snapland', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', 'res://game/tests/test_pixel_ui_collections.tscn']`

Save: `C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\welcome-fix-round1\final-pixel-UI-collection-tests-profile\progress.json`

Result: PASS, existing exact completion marker and no engine ERROR

## region travel tests

Command: `['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--log-file', 'C:\\Users\\stanl\\Github\\Snapland\\.review\\region-map-main27-20261117\\welcome-fix-round1\\final-region-travel-tests-engine.log', '--headless', '--path', 'C:\\Users\\stanl\\Github\\Snapland', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', 'res://game/tests/test_region_travel.tscn']`

Save: `C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\welcome-fix-round1\final-region-travel-tests-profile\progress.json`

Result: PASS, existing exact completion marker and no engine ERROR

## pixel UI shell tests

Command: `['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe', '--log-file', 'C:\\Users\\stanl\\Github\\Snapland\\.review\\region-map-main27-20261117\\welcome-fix-round1\\final-pixel-UI-shell-tests-engine.log', '--headless', '--path', 'C:\\Users\\stanl\\Github\\Snapland', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', 'res://game/tests/test_pixel_ui_shell.tscn']`

Save: `C:\Users\stanl\Github\Snapland\.review\region-map-main27-20261117\welcome-fix-round1\final-pixel-UI-shell-tests-profile\progress.json`

Result: PASS, existing exact completion marker and no engine ERROR
