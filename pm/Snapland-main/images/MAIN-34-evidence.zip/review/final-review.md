# Final whole-branch review — MAIN-34

Range: `92a5fa5..7501ac0` (opening `1c062c4`, spec/plan `58fa46a`, implementation `5902d65`, evidence/PM `7501ac0`). Reviewed against `design/runtime/game-rules-layout.md`, `docs/superpowers/plans/2026-11-18-game-rules-layout.md`, applicable AGENTS/pm-ticket guidance, and the requesting-code-review reviewer template.

## Strengths

- **Small, complete production correction.** `game/main.gd:1441` retains the full goal, instructions and three existing notes in the specified five-page order; `game/main.gd:1474` preserves their original 22/20/18 sizes and named note identities. `game/main.gd:1449` adds a rules-only HFlow beneath the existing typed footer, preserves both retake callbacks, the four play choices and return ordering, and retains the existing return callback through reparenting. No game, progress, save, economy, asset or shared modal implementation changes appear in this branch.
- **Causal evidence supports both changes.** The archived old native run records the 845-pixel panel overflowing an 800-pixel viewport; the width-only candidate records 822 failures, supporting the additional paging needed for long content. The five-page decision and PixelShell-only timeout adjustment are explicit, measured plan refinements, not unrecorded scope expansion.
- **Tests reach real behavior.** `game/tests/test_pixel_ui_shell.gd:415` dynamically visits the actual Catalog, three viewports, five ownership/attempt contexts and all five pages. It checks full rectangles, label/button fit, ownership-specific actions, complete goal/instructions and original fonts. Actual connected Next callbacks advance the matrix; representative paths exercise real Tab, Enter, pointer, tutorial, Session launch/cancel, retake prerequisites and return. `game/tests/test_cookie_mold_main.gd:51` keeps its participation assertion through real pager navigation.
- **Native and execution evidence is attributable.** The three actual GPU viewport reports have 125 cases each, zero failures and 45 PNGs each. PixelShell's archived standard GL/default-FPS run records 1,950 pages, one completion marker, exit 0, zero ERROR/leak records and 95.68 seconds. The earlier 90.16-second timeout is retained as failure. `tools/run_game_tests.py:553` changes only the measured PixelShell limit to the existing 240-second pattern; its contract test retains the 90-second expectation for other labels.
- **Dependency and delivery records are honest.** MAIN-34 and SG-43 have reciprocal Blocks/Blocked by links. SG-43 remains in progress with unchecked acceptance criteria and no feature code is bundled here. The PM commit records automated UI evidence without claiming human gameplay/listening or a completed full suite. Its completed UI acceptance is supported; synchronization to main and that head's CI remain executor delivery steps.

## Issues

### Critical (Must Fix)

None found.

### Important (Should Fix)

None found.

### Minor (Nice to Have)

1. **Inherited material warnings remain visible, not a new rules regression.** `D:/Snapland-QA/game-rules-layout-20261118/final-pixel240-e04721/run.log:8` reports unsupported occlusion material handling. Corresponding baseline output begins at `D:/Snapland-QA/game-rules-layout-20261118/baseline-pixel-c0e3ae/run.log:5`; both contain 21 warnings, including the same preserved-material cases. Other accepted runs retain their disclosed material/placeholder warnings. These can obscure future diagnostics and some unsupported materials do not receive cutaway behavior. Keep the disclosure and address material support in its owning work; do not suppress warnings or broaden this rules-only patch. This does not block MAIN-34.

## Evidence and Review Boundaries

- Read the supplied 53,374-byte whole-branch diff once in two consecutive chunks, including all four commits' text changes and binary-file inventory. Did not regenerate or reread the diff.
- Focused unchanged-code checks covered `_content_pager`, `_step_content_page`, `_back`, `_render_rules_note` and relevant existing fixture references to the moved named nodes. Their callbacks, focus handling and note-name mapping remain compatible with the new nesting. No extra production changes are needed for the reviewed callers.
- Read the private launch/staging helper for provenance only. It uses `prepare_runtime_stage`, an exact 15-file helper/fixture allowlist, the required Godot executable and validated launcher, real `.tscn` entrypoints and separate D-drive profiles. Did not run the helper.
- Parsed archive metadata and relevant receipts: 217 ZIP entries, 215 manifested entries, 20,872,017 bytes, 1,200 runtime inventory entries, 135 final native PNGs. Independently matched all seven frozen source files to the checkout, plus the frozen spec, plan and MAIN-34 ticket. Independently matched all four public PNG bytes to their archived raw sources. CRC/full manifest verification is the executor's recorded prior check; it was not redundantly rerun.
- Read baseline, RED, width-only candidate, standard timeout and final launch/log summaries. Final native reports record actual 800×600, 1152×648 and 1280×720 with DISABLED content scale, 26 catalog definitions and no failures. Native/PixelShell completion markers occur once. Other affected checks retain their own output conventions: Harbor reports 22 checks/0 failures rather than a PASS-prefixed marker; travel includes per-assertion PASS lines. No universal marker-count claim is made for them.
- Reviewed the existing 23-test runtime contract and 15-test entrypoint success receipts, and the five clean affected retake/factory/travel/harbor receipts. No passed test was rerun. The standard PixelShell run has no FPS override; the report accurately discloses private FPS240 for the smaller affected checks.
- Root supplied the completed visual inspection of the failed 800 image and final 800/1152/1280 representatives. This reviewer checked exact image provenance rather than repeating that visual pass.
- No source, Git index, HEAD, branch or paused SG-43 file was modified. Only this authorized review report was written.

## Recommendations

Proceed with the already-authorized delivery sequence and observe CI for the actual delivered main head before reporting integration complete. Keep the reviewed warnings and omitted-suite limits in the handoff. On SG-43 rebase, preserve this rules layout, its third participation mode and the in-progress ticket/dependency relationship; then resume its separate native/QA gate against the actual 27-game catalog.

## Declined to Judge

- Full-suite success and CI on the eventual main head: not yet observed for this delivery; the executor owns that subsequent gate, and this review does not certify it.
- The legacy photo-retake-Main and region-travel fault-child suites locally: explicitly omitted by the executor's strict validated-launch-boundary ruling; unchanged OS.execute children and save-failure behavior were not revalidated here. Existing affected UI and real callback coverage supports this rules-only change, not a new claim about failure injection.
- SG-43 gameplay, its untracked native fixture, three-mode participation integration after rebase and real 27-game native acceptance: a separate in-progress ticket; no SG-43 fixture was inspected, imported or touched.
- Human play, listening, broad art quality and gameplay performance: automated geometry, scripted inputs and Dummy audio do not establish these behaviors, and the branch does not claim them.
- New desktop export/release verification: explicitly excluded for this UI-only patch; the native fixture is review/test material and no exporter change is present.
- Fixing inherited unsupported-material/placeholder behavior: baseline evidence and unchanged ownership make this follow-up work; its warning/readiness impact was assessed above rather than silently discarded.

## Assessment

**Ready to merge? Yes.**

The reviewed branch implements the specified rules-only width and height correction with preserved content, fonts, callbacks and shared behavior, backed by complete catalog geometry, representative real input and native evidence. No Critical or Important issue was found; actual main CI and SG-43's separate acceptance remain explicit subsequent delivery gates, not results of this review.

Skipped: test reruns, full-suite/export execution, duplicate visual inspection, human play/listening and SG-43 validation.
Risk: inherited material warnings remain; eventual main CI and the rebased 27-game SG-43 native/QA checks still need executor confirmation.
