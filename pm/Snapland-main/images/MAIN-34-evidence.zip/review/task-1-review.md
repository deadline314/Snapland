# Task 1 review — MAIN-34

## Spec Compliance

- ✅ Spec compliant for `58fa46a..5902d65`. `game/main.gd:1442` preserves the complete goal, instructions and three existing notes in the required five-page order; `game/main.gd:1475` preserves the original 22/20/18 text sizes through the existing note renderer. `game/main.gd:1450` adds only the rules HFlow beneath the existing footer, retains the retake HBox, original callback arguments, four play choices and named return button (`game/main.gd:1461`, `game/main.gd:1468`, `game/main.gd:1473`). No other production behavior, font, threshold, save, asset or game data change appears in the package.
- ✅ The measured timeout exception matches the approved design: `tools/run_game_tests.py:553` changes only PixelShell to the existing 240-second avatar pattern; `tests/test_runtime_result_contract.py:123` checks that other labels retain 90 seconds. The preserved standard-90 receipt reports exit124 at90.16s with no final marker; final standard GL/default-FPS PixelShell reports exit0 at95.68s.
- ⚠️ Full suite/export, human gameplay/listening, legacy fault-child photo-retake/region-travel suites, and SG43's real27-game revalidation are outside this task gate. Their omission is explicitly authorized/disclosed, not a pass claim. Final PM completion and synchronization are root delivery work; this implementation commit appropriately leaves the ticket in progress.

## Strengths

- `game/main.gd:1449` reuses the house pager rather than adding layout infrastructure. The production change is confined to the rules function and its renderer; the global footer type and shared pager stay unchanged.
- `game/tests/test_pixel_ui_shell.gd:415` covers the actual dynamic Catalog, three physical viewports, all five ownership/attempt states, each page, complete goal/instructions and readable fonts. It advances the connected Next callback and waits for settled layout rather than injecting private page metadata. The added representative route checks exercise real keyboard/pointer callbacks and actual Main sessions without claiming gameplay success.
- `game/tests/native_game_rules_layout_review.gd:82` checks full control rectangles, text height/button text width, parent enclosure and overlapping visible text/actions. `game/tests/native_game_rules_layout_review.gd:39` supplies separate native GPU coverage and raw PNGs, while `game/tests/native_game_rules_layout_review.gd:59` and the updated PixelShell teardown use the existing audio-release helper.
- `game/tests/test_cookie_mold_main.gd:56` finds the real named participation note through actual pager navigation, retaining the meaningful participation/idle-exclusion assertion after the page-order change.

## Issues

### Critical / Important

- None found in the reviewed task diff.

### Minor

- Existing warning noise, nonblocking: `D:/Snapland-QA/game-rules-layout-20261118/final-pixel240-e04721/run.log:8` reports unsupported occlusion materials; further existing warnings remain in native/factory/travel logs. These runs are zero-ERROR/zero-leak, but their output is not warning-free. The warnings are disclosed and outside the rules-only production scope; keep them visible for their owning follow-up rather than describing the logs as pristine.

## Checks and Evidence

- Read the provided diff once. The first tool result truncated the native-fixture tail/cookie/PixelShell beginning, so only those missing package lines205–375 were recovered; no changed source file was reread for implementation review. No tests were rerun and no source, index, HEAD or branch mutation was performed.
- Focused outside-diff risk: moving the pager/card and return button could break note names, navigation focus or callback targets. Checked only the unchanged `_content_pager`/page-step/render helpers (`game/main.gd:538`), `_back` (`game/main.gd:666`), `_render_rules_note` (`game/main.gd:1793`) and existing page-sequence assertion (`game/tests/test_pixel_ui_shell.gd:368`). They preserve real callbacks, page counters, focus and RulesNote0/1/2 names with the new renderer's index offset.
- Focused launch/isolation risk: checked `.review/game-rules-layout-20261118/run_review.py:6`, `:11`, `:24` and `:38` plus receipts. The launcher uses `prepare_runtime_stage`, the exact15-helper allowlist and `run_validated_godot`; final PixelShell receipt uses the exact required engine, real `.tscn`, headless/GL/default FPS, and five isolated absolute D-drive environment paths.
- Read final launch/log metadata: PixelShell records26 games/1950 pages and real representative callbacks, exit0/0ERROR/0leaks/one final marker at95.68s. Each native report records125 cases,45 PNGs, exact800×600/1152×648/1280×720 viewport, DISABLED scale mode and zero failures; each corresponding receipt has exit0/0ERROR/0leaks/one final marker. Retake panel, Sugar Main, Cookie Main and travel UI receipts are exit0/0ERROR/0leaks; Harbor log reports22 checks/0 failures. Baseline/causal RED and footer-only candidate receipts remain present with the reported clean baseline,1332 RED errors and822 candidate errors.
- Read Python receipts: runtime contract23/23 and entrypoints15/15 pass. Parsed only inventory metadata:1200 entries; the five staged runtime/fixture SHA256 values match the report and staged files. The Python runner/test are intentionally outside the runtime inventory. No1200-hash dump or unrelated/paused SG43 inspection occurred.
- Image inspection was supplied by root for the final800 long instructions,1152 participation and1280 goal views; this reviewer did not duplicate that visual pass.

## Assessment

**Task quality: Approved.** The small production change addresses the demonstrated width and height causes while preserving the existing interface and behavior. The broader tests exercise real layout and callbacks, and the measured runner exception remains narrowly scoped.

Skipped: repeated test execution, full-suite/export, human play/listening and SG43 revalidation. Risk: inherited material/placeholder warnings remain; SG43 requires its separate rebase and real27-game check.
