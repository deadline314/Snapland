import argparse, hashlib, json, os, shutil, subprocess, sys, time, uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from tools.build_desktop_release import prepare_runtime_stage
from tools.godot_entrypoints import run_validated_godot

ENGINE = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
BASE = Path('D:/Snapland-QA/game-rules-layout-20261118')
ALLOW = ['test_pixel_ui_shell.gd','test_pixel_ui_shell.tscn','native_game_rules_layout_review.gd','native_game_rules_layout_review.tscn','audio_playback_release.gd','test_sugar_bridge_main.gd','test_sugar_bridge_main.tscn','test_sugar_bridge_session.gd','test_cookie_mold_main.gd','test_cookie_mold_main.tscn','test_cookie_mold_session.gd','test_retake_panel.gd','test_travel_book_ui.gd','test_travel_book_ui.tscn','test_harbor_collection.gd']

def launch(stage, label, args, extra=None, timeout=240):
    output = BASE / (label + '-' + uuid.uuid4().hex[:6])
    output.mkdir(parents=True)
    env = dict(os.environ)
    for key in ['APPDATA','LOCALAPPDATA','TEMP','TMP']:
        path = output / key.lower(); path.mkdir(); env[key] = str(path)
    env.update(SNAPLAND_SAVE_PATH=str(output/'profile'/'progress.json'),RULES_CAPTURE_DIR=str(output/'captures'))
    if extra: env.update(extra)
    command = [ENGINE,'--path',str(stage),*args]
    started=time.monotonic()
    try:
        result = run_validated_godot(stage, command, env, timeout)
    except subprocess.TimeoutExpired as error:
        result = subprocess.CompletedProcess(command,124,error.output or '',error.stderr or '')
    log = result.stdout + result.stderr
    (output/'run.log').write_text(log,encoding='utf-8')
    report = dict(command=command,env={key:env[key] for key in ['SNAPLAND_SAVE_PATH','APPDATA','LOCALAPPDATA','TEMP','TMP']},exit=result.returncode,errors=log.count('ERROR:'),leaks=log.count('leaked')+log.count('still in use'),seconds=round(time.monotonic()-started,2),markers=[line for line in log.splitlines() if line.startswith('PASS:')],output=str(output))
    (output/'launch.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report),flush=True)
    return result.returncode

if __name__ == '__main__':
    p=argparse.ArgumentParser(); p.add_argument('action'); p.add_argument('--stage'); p.add_argument('--size',default='800x600'); p.add_argument('--label',default='run'); a=p.parse_args()
    if a.action == 'stage':
        stage = BASE / ('stage-'+uuid.uuid4().hex[:6]); stage.mkdir(parents=True)
        tracked = subprocess.check_output(['git','ls-files','-z'],cwd=ROOT,text=True,encoding='utf-8').split('\0')
        hashes = prepare_runtime_stage(ROOT,stage,tracked)
        for name in ALLOW:
            source=ROOT/'game/tests'/name
            if source.is_file():
                target=stage/'game/tests'/name; target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(source,target); hashes['game/tests/'+name]=hashlib.sha256(source.read_bytes()).hexdigest()
        (stage.parent/(stage.name+'-inventory.json')).write_text(json.dumps(hashes,indent=2))
        print(stage,flush=True)
        sys.exit(launch(stage,'import',['--headless','--editor','--import','--quit'],timeout=600))
    stage=Path(a.stage)
    if a.action == 'sync':
        inventory=stage.parent/(stage.name+'-inventory.json')
        hashes=json.loads(inventory.read_text())
        for name in ['game/main.gd',*['game/tests/'+n for n in ALLOW]]:
            if (ROOT/name).is_file():
                shutil.copy2(ROOT/name,stage/name)
                hashes[name]=hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
        inventory.write_text(json.dumps(hashes,indent=2))
        sys.exit(0)
    if a.action == 'native':
        sys.exit(launch(stage,a.label,['--audio-driver','Dummy','res://game/tests/native_game_rules_layout_review.tscn'],dict(RULES_REVIEW_SIZE=a.size)))
    if a.action == 'pixel-standard':
        sys.exit(launch(stage,a.label,['--headless','--audio-driver','Dummy','--rendering-method','gl_compatibility','res://game/tests/test_pixel_ui_shell.tscn'],timeout=90))
    if a.action == 'pixel-final':
        sys.exit(launch(stage,a.label,['--headless','--audio-driver','Dummy','--rendering-method','gl_compatibility','res://game/tests/test_pixel_ui_shell.tscn'],timeout=240))
    entry={'pixel':'test_pixel_ui_shell.tscn','retake':'test_retake_panel.gd','sugar':'test_sugar_bridge_main.tscn','cookie':'test_cookie_mold_main.tscn','travel':'test_travel_book_ui.tscn','harbor':'test_harbor_collection.gd'}[a.action]
    sys.exit(launch(stage,a.label,['--headless','--audio-driver','Dummy','--max-fps','240',*(['--script'] if entry.endswith('.gd') else []),'res://game/tests/'+entry],timeout=360))
