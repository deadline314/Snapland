from pathlib import Path
import zipfile,json,hashlib
root=Path.cwd();base=Path('D:/Snapland-QA/game-rules-layout-20261118');work=root/'.superpowers/sdd/2026-11-18-game-rules-layout'
entries={}
labels=['baseline-pixel-c0e3ae','red-native-valid-efd3cf','red-pixel-matrix-3f1834','candidate1-pixel-1fb2e9','callback-matrix-standard90-5865df','final-pixel240-e04721','final-native800-a8d932','final-native1152-0a053f','final-native1280-8d5de4','final-retake-panel-72c437','final-sugar-main-42f71a','final-cookie-main-4bb02e','final-travel-ui-ad749e','final-harbor-collection-f7c0ba']
for label in labels:
 location=base/label
 assert location.is_dir(),label
 for p in location.iterdir():
  if p.is_file():entries['runs/'+label+'/'+p.name]=p
 for p in (location/'captures').glob('*'):
  if p.is_file():entries['runs/'+label+'/captures/'+p.name]=p
for p in base.glob('python-*.log'):entries['python/'+p.name]=p
for p in base.glob('*inventory.json'):entries['inventories/'+p.name]=p
for p in work.iterdir():
 if p.is_file():entries['review/'+p.name]=p
for p in (root/'.review/game-rules-layout-20261118').iterdir():
 if p.is_file():entries['private-tools/'+p.name]=p
sources=['game/main.gd','game/tests/test_pixel_ui_shell.gd','game/tests/test_cookie_mold_main.gd','game/tests/native_game_rules_layout_review.gd','game/tests/native_game_rules_layout_review.tscn','tools/run_game_tests.py','tests/test_runtime_result_contract.py','design/runtime/game-rules-layout.md','docs/superpowers/plans/2026-11-18-game-rules-layout.md','pm/Snapland-main/[MAIN-34]修復小視窗規則頁裁切.md']
for name in sources:entries['frozen-source/'+name]=root/name
out=root/'pm/Snapland-main/images/MAIN-34-evidence.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 z.writestr('README.md','MAIN34 actual rules-layout evidence.\nOnly final-* clean runs are acceptance; baseline/RED/width-onlycandidate/90stimeout retain their actualfailures. Matrix1950pageconditions uses actual connectedbuttoncallbacks andsettledlayout, representative pathsuse realkey/pointer. Native3sizes125caseseach/135rawPNGs. Rootviewedfinal800long009,1152participation025,1280goal025 andoriginal025failure; publicPNGcopies are unedited. StandardGL/defaultFPSPixelShell95.68s clean undermeasuredsuite240limit; otherchecksprivateFPS240 asreportdiscloses.\nThis is UI geometry/scriptedinput, not human gameplay/hearing. Synthetic ownership/admission fixtures only. Legacy fault-child localsuitesomitted underexplicitvalidated-launch-boundaryscope ruling; fullCIseparate. No UI-onlyexport. SG43native27needsseparaterebaseverification. Read taskreport/ledger/reviews for exactcommands/profiles/hashes/limits.\n')
 hashes={}
 for name,p in sorted(entries.items()):
  data=p.read_bytes();z.writestr(name,data);hashes[name]=hashlib.sha256(data).hexdigest()
 z.writestr('archive-sha256.json',json.dumps(hashes,ensure_ascii=False,indent=2))
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 hashes=json.loads(z.read('archive-sha256.json'))
 assert all(hashlib.sha256(z.read(name)).hexdigest()==h for name,h in hashes.items())
assert out.stat().st_size<90_000_000
print('MAIN34 archive',len(hashes),'files',out.stat().st_size,'bytes',hashlib.sha256(out.read_bytes()).hexdigest())
