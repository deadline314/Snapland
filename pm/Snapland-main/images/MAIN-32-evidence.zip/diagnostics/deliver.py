from pathlib import Path
import hashlib
import json
import shutil
import zipfile

root = Path.cwd()
review = root / '.review/main32-legacy-npc-20261118'
run = json.loads((review / 'green-grounding-full-entry.json').read_text(encoding='utf-8'))
assert run['exit'] == 0 and run['errors'] == 0 and run['final_marker_count'] == 1 and not run['leaks']
source = root / 'game/tests/native_npc_review.gd'
assert hashlib.sha256(source.read_bytes()).hexdigest() == run['source_sha256']
accepted = Path(run['environment']['SNAPLAND_SAVE_PATH']).parent / 'native-npc-review'
receipt = json.loads((accepted / 'receipt.json').read_text(encoding='utf-8'))
assert receipt['status'] == 'PASS' and not receipt['failure'] and not receipt['human_played']
assert receipt['reduced_standing'] and receipt['resumed'] and len(receipt['roles']) == 3
assert receipt['source_sha256'] == run['source_sha256']
for item in receipt['captures']:
    assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest() == item['sha256']
visual = json.loads((review / 'root-visual-acceptance.json').read_text(encoding='utf-8'))
assert visual['source_sha256'] == run['source_sha256'] and Path(visual['directory']) == accepted
public = root / 'pm/Snapland-main/images'
for role, filename in [('ticket', 'ticket-01.png'), ('imp', 'imp-02.png'), ('announcer', 'announcer-02.png')]:
    shutil.copy2(accepted / filename, public / f'MAIN-32-{role}.png')
rejected_run = json.loads((review / 'final-full-entry.json').read_text(encoding='utf-8'))
rejected = Path(rejected_run['environment']['SNAPLAND_SAVE_PATH']).parent / 'native-npc-review'
archive = public / 'MAIN-32-evidence.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for p in review.rglob('*'):
        if p.is_file() and p.suffix in {'.json', '.log', '.md', '.txt', '.py'}:
            z.write(p, 'diagnostics/' + p.relative_to(review).as_posix())
    for label, directory in [('accepted-grounded', accepted), ('rejected-clipped', rejected)]:
        for p in directory.iterdir():
            if p.is_file() and p.suffix in {'.json', '.png'}:
                z.write(p, label + '/' + p.name)
    workspace = root / '.superpowers/sdd/2026-11-18-legacy-npc-native-review'
    for p in workspace.iterdir():
        if p.is_file() and p.suffix in {'.md', '.diff'}:
            z.write(p, 'review/' + p.name)
    z.write(source, 'final-source/native_npc_review.gd')
ticket = next((root / 'pm/Snapland-main').glob('[[]MAIN-32]*.md'))
body = ticket.read_text(encoding='utf-8')
assert '# Commit-1' not in body
body = body.replace('狀態：進行中', '狀態：完成').replace('- [ ]', '- [x]')
body += '''
# Commit-1

## 內文

舊角色檢視仍使用過時位置、固定四格及只有一位角色巡路的假設，無法檢查目前正式內容。現在三位都依各自正式動作、服裝與巡路範圍檢查，保留姓名、標記、互動位置、材質同步及降低動態／恢復條件；結果記錄實際觀察到的姿勢，不冒稱固定動作全部完成。

原生逐張檢視另發現手動鏡頭改變後沒有同步腳底接地，造成靴子被地面切掉。該批畫面已拒收並保留；同步既有接地更新後重跑，三位代表圖均可見完整腳部。新圖與記錄保存在獨立存檔旁，再附至本票，歷史畫面不被覆寫。

### 測試結果

| 項目 | 結果 |
|---|---|
| 實際反例 | 舊位置不符，退出 1；另保留標記誤認及拒收的截腳畫面 |
| 最終完整原生入口 | 通過，28.574 秒；唯一完整成功標記、0 ERROR、無退出資源殘留 |
| 三位正式播放 | 每位 70 次自然時間取樣、各 22 個不同姿勢；實測巡路跨度票票 1.2、小角 0.592、阿浪 1.2 公尺，均在各自範圍內 |
| 降低動態及恢復 | 正式正面站姿、時鐘／根／互動位置、材質及恢復檢查通過 |
| 隔離與覆寫保護 | 相對存檔及非空輸出如實拒絕，既有哨兵內容保持相同 |
| 繼承相容性 | 匯入通過；子入口保留 MAIN-33 同一個既有深度失敗，無新增型別、I/O、退出錯誤 |
| 來源保護 | 1191 份其他正式內容及依賴指紋一致，角色與遊戲來源保持相同 |
| 設計資料與連結 | 五範圍通過 |

本次為腳本驅動原生呈現與靜態代表圖檢視；相機及畫外主角取景有記錄，不是人類自由遊玩、連續觀看、試聽或整套動畫自然度驗收。

### 截圖

![票票完整腳部](images/MAIN-32-ticket.png)
![小角完整自然步態](images/MAIN-32-imp.png)
![阿浪完整站姿](images/MAIN-32-announcer.png)

[原始失敗、拒收畫面、最終回歸、來源及審查](images/MAIN-32-evidence.zip)
'''
ticket.write_text(body, encoding='utf-8', newline='\n')
print(json.dumps({'archive_bytes': archive.stat().st_size, 'source_sha256': run['source_sha256']}))
