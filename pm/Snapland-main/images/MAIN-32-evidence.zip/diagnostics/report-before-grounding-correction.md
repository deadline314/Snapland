# MAIN32 Task 1 source-frozen report

Status: complete for the owned parent entry, pending root task/final reviews and delivery. Only `game/tests/native_npc_review.gd` runtime-test source changed. No Git/PM, production, base classes, child entry, runtime package or QA export changes by this worker.

## Source and scope

- RED source SHA256: `95368df30dda7ce8fd01c24b76021e1375fb2c7dbf49adfbd075817c97d474eb`.
- Final source SHA256: `633576bb5a0da83829c56fd0f921f024daf6ad8497f8f65260786da2b251cbcb`; exact bytes frozen at `.review/main32-legacy-npc-20261118/source-frozen.gd.txt`.
- Read frozen spec, plan global constraints, task brief, pm-ticket and ponytail; followed verification-before-completion evidence requirement. Inspected native parent/layout/base, sole clearance inheritor, scene/call references, activity registration/playback/current source normalization, timing, costume cache, authored patrol profiles, marker parenting, save guard and shared audio release helper before implementation.
- Public `NpcRoles`, `records`, `_sprite`, `_anchor`, `_texture_synced`, `_review_role`, `_check_npc_visible` and base-class path remain. Parent cleanup uses new `_npc_finish`; `_fail` is not overridden, so the child retains its original failure handling.
- All 1191 other staged/runtime/dependency inputs match initial stage-manifest SHA256 and current repository bytes; full comparisons are in `protected-final-hashes.json`. No player data reset: all profile trees are new independent D paths.

## Staging and commands

Stage: `D:/Snapland-QA/main32-legacy-npc-20261118-588c0df2/project`. `prepare_runtime_stage` copies tracked runtime only; explicit dependency allowlist is in private `run.py`: native NPC scene/script, native clearance scene/script for inherited parsing/smoke, native layout/base scripts, and audio playback release. No C import cache, full repository copy, existing-stage deletion, package mutation or re-export.

Every engine launch below used `tools.godot_entrypoints.run_validated_godot`, exact `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe`. Native logs identify `4.7.2.stable.official.ed1daf0bf`, Vulkan Forward+, AMD Radeon RX 9070 XT. Import/parser launches alone are headless. Every absolute save, APPDATA, LOCALAPPDATA, TEMP and TMP is independently recorded below.

Shell driver commands (each invokes the validated Python launcher internally):

```powershell
python .review/main32-legacy-npc-20261118/run.py prepare
python .review/main32-legacy-npc-20261118/run.py green-full-entry
python .review/main32-legacy-npc-20261118/run.py green2-full-entry
python .review/main32-legacy-npc-20261118/run.py final-full-entry
python .review/main32-legacy-npc-20261118/run.py child-smoke
python .review/main32-legacy-npc-20261118/run.py refuse-relative
python .review/main32-legacy-npc-20261118/run.py refuse-occupied
python .review/main32-legacy-npc-20261118/run.py import-green
python .review/main32-legacy-npc-20261118/report.py
```

## Actual RED and repair

Fresh full native RED exited 1 at ticket label/root/interaction identity, with actual root `(-3.8,0,5)` against obsolete `(-5,0,10)`. It is an actual pre-edit run, not reused ART17 evidence. Exact original source, raw log, command and environment are preserved.

First repaired run (`green-full-entry`) remained RED: name lookup selected the now-reparented interaction marker because both are direct Label3D children. Fix uses exact expected role name and checks marker identity/parent separately. Raw intermediate failure remains preserved. `green2-full-entry` passed. Final source then added actual sample/time observations and graceful missing-library rejection; `final-full-entry` reran the entire entry successfully.

Current entry validates full canonical sequence frames against the existing normalized library and shared timing checks; compares displayed texture membership by cached identity, including the announcer existing costume cache, plus shader texture/full UV. Legacy fallback and absent formal source cannot pass. All roles use current origins/point IDs and validated patrol profiles. Natural timers observe multiple poses and at least 80% of each allowed X span, bounded to 180 samples per role; no fixed four-frame or required service/dance claim.

## Final native results

Full entry: exit 0, 28.666 seconds, zero ERROR/leak markers, exact final success marker once. Successful marker emitted only after capture/receipt checks and shared Release capture -> shutdown -> queue_free -> existing two-frame barrier -> bounded weak-reference playback release. Raw stdout and stderr are concatenated in logs, so their merged textual order is not chronological.

| Role | Point | Different displayed texture poses | Observed X range (m) | Samples | Observation seconds |
|---|---|---:|---:|---:|---:|
| ticket | guide | 21 | 1.200000 | 70 | 7.507 |
| imp | quest-001 | 21 | 0.595000 | 70 | 7.521 |
| announcer | quest-002 | 21 | 1.200000 | 70 | 7.535 |

Action/direction and actual observed pose indices (not a claim of complete animation coverage):

```json
{
  "ticket": {
    "depart/right": [
      0,
      2,
      3
    ],
    "emotion_happy/front": [
      0,
      1,
      2,
      3,
      4,
      5,
      6,
      7
    ],
    "settle/right": [
      0,
      1,
      2,
      3
    ],
    "stand/front": [
      4,
      5,
      6,
      7,
      0,
      1
    ],
    "walk/right": [
      0,
      1,
      2,
      3
    ]
  },
  "imp": {
    "depart/right": [
      0,
      1
    ],
    "idle_gesture/front": [
      0,
      1,
      2,
      3,
      4,
      5,
      6
    ],
    "settle/left": [
      1,
      2,
      3
    ],
    "stand/front": [
      0,
      1,
      2,
      3,
      4,
      5,
      6
    ],
    "walk/left": [
      0,
      1,
      2,
      3
    ]
  },
  "announcer": {
    "depart/left": [
      0,
      1,
      2
    ],
    "emotion_curious/front": [
      0,
      1,
      2,
      3,
      4,
      5,
      6,
      7
    ],
    "settle/left": [
      0,
      1,
      2,
      3
    ],
    "special/front": [
      0
    ],
    "stand/front": [
      0,
      1,
      2,
      3,
      4
    ],
    "walk/left": [
      0,
      1,
      2,
      3
    ]
  }
}
```

Identity, unique three-role registration, required names, marker ownership/follow, point follow, per-role XYZ bounds, visible body/name centers and collision-geometry rays remain active. Reduced mode independently resolves formal front standing rather than accepting the legacy baseline: first complete source/costume texture, shader/full UV, zero action elapsed, stable controller clock, restored baseline roots/original interaction points and retained state across a 0.4-second natural wait. Normal mode resumes its clock/playback and synchronized formal source.

Review staging is explicit: world camera-follow physics disabled, offscreen hero `(15,0.4,-24.5)`, noon, fixed close camera per role at current origin plus `(0,3.8,6.5)` looking at origin plus `(0,1.45,0)`. NPC roots/actions/textures/clocks are never assigned. The usual marker visibility is not forced; marker parenting/XZ follow is checked. Captures were inspected for all three roles: required names and bodies are framed; no geometry or thresholds were modified.

## Captures and hashes

Fresh required profile-adjacent directory: `D:/Snapland-QA/main32-legacy-npc-20261118-588c0df2/profiles/final-full-entry-493ff8a5/native-npc-review`. It contains six original PNGs plus runtime receipt. No ART12 path was used. Runtime receipt SHA256: `549db9036f3aefcc349aeea7b481c689f9f6370157f3e2977df15153ba93828e`.

| File | SHA256 |
|---|---|
| ticket-01.png | `d3b54b282e9b104e3848e69501022f2ec172d05ff7194a389797c1c25f1e44c4` |
| ticket-02.png | `e9820433ae7a3bc1182ffec7c3c836ce77a72e723329f2ab213e8c01e0df4e8e` |
| imp-01.png | `9659cd281f4d9c87ed4e07a3939cd86af0cde448451470f7f365bb5608d8f8f2` |
| imp-02.png | `53a5ebfd3b205f31369670add7fc4502aa0f7e00c7397aeab82ac6a8c83a4b19` |
| announcer-01.png | `1737e84d9d90db68439e25d66d86529a63a970f42e15771ba65aecc6c68e2176` |
| announcer-02.png | `11f0fa2d6bf0b38a50a93a182008aba2a65d12249d0cb668c86a1e7d3afa4976` |

## Safeguards and inherited smoke

- Final headless editor import/parser: exit 0, zero ERROR/leak markers, unchanged child inheritance accepted.
- Relative save: native exit 1, no success marker. Both Progress guard and this entry reject the relative override. No relative progress file was created.
- Occupied native-npc-review: native exit 1, no success marker. Sentinel `keep.txt` remained byte-for-byte intact and the directory still contains only that sentinel, no receipt or captures.
- Child smoke: exit 1 with exactly the existing single `Sprite NPC announcer frame 2 has 307/47406 rendered body pixels hidden by scene geometry or overlays` ERROR; no new parser/type/I/O/teardown/leak errors. MAIN33 remains unmodified and unresolved.

## Exact engine invocations, environments and raw logs

### import-red

Raw log: `.review/main32-legacy-npc-20261118/import-red.log`; SHA256 `54c12aba3f341ec2e7dd56130186a1405a30c88804ec1aeb07e1215d0b80c1b6`.

```json
{
  "label": "import-red",
  "command": [
    "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe",
    "--path",
    "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\project",
    "--headless",
    "--editor",
    "--import",
    "--quit"
  ],
  "environment": {
    "SNAPLAND_SAVE_PATH": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\import-red-6a0b7a0d\\progress.json",
    "APPDATA": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\import-red-6a0b7a0d\\appdata",
    "LOCALAPPDATA": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\import-red-6a0b7a0d\\localappdata",
    "TEMP": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\import-red-6a0b7a0d\\temp",
    "TMP": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\import-red-6a0b7a0d\\temp"
  },
  "exit": 0,
  "seconds": 23.398,
  "errors": 0,
  "final_marker_count": 0,
  "source_sha256": "95368df30dda7ce8fd01c24b76021e1375fb2c7dbf49adfbd075817c97d474eb",
  "leaks": false
}
```

### red-full-entry

Raw log: `.review/main32-legacy-npc-20261118/red-full-entry.log`; SHA256 `7fb038d8e999480a2466cc905d081a5d769c347a6ace015f79be9da0ff32a6a3`.

```json
{
  "label": "red-full-entry",
  "command": [
    "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe",
    "--path",
    "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\project",
    "res://game/tests/native_npc_review.tscn"
  ],
  "environment": {
    "SNAPLAND_SAVE_PATH": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\red-full-entry-e155d68a\\progress.json",
    "APPDATA": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\red-full-entry-e155d68a\\appdata",
    "LOCALAPPDATA": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\red-full-entry-e155d68a\\localappdata",
    "TEMP": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\red-full-entry-e155d68a\\temp",
    "TMP": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\red-full-entry-e155d68a\\temp"
  },
  "exit": 1,
  "seconds": 5.607,
  "errors": 1,
  "final_marker_count": 0,
  "source_sha256": "95368df30dda7ce8fd01c24b76021e1375fb2c7dbf49adfbd075817c97d474eb",
  "leaks": false
}
```

### green-full-entry

Raw log: `.review/main32-legacy-npc-20261118/green-full-entry.log`; SHA256 `246780edde9c2ca5aaefb904f5bcd0c48761620a28da1374818dc7e52ea4a947`.

```json
{
  "label": "green-full-entry",
  "command": [
    "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe",
    "--path",
    "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\project",
    "res://game/tests/native_npc_review.tscn"
  ],
  "environment": {
    "SNAPLAND_SAVE_PATH": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\green-full-entry-53f3e13d\\progress.json",
    "APPDATA": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\green-full-entry-53f3e13d\\appdata",
    "LOCALAPPDATA": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\green-full-entry-53f3e13d\\localappdata",
    "TEMP": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\green-full-entry-53f3e13d\\temp",
    "TMP": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\green-full-entry-53f3e13d\\temp"
  },
  "exit": 1,
  "seconds": 5.232,
  "errors": 1,
  "final_marker_count": 0,
  "source_sha256": "3a1ed231b5246e997473cf8fb54823020933a9241f1180db028a26753aa823ba",
  "leaks": false
}
```

### green2-full-entry

Raw log: `.review/main32-legacy-npc-20261118/green2-full-entry.log`; SHA256 `14f7c8d86671eaa73e58e4c7b5175ff6e7f0adec8cf2c0f5dea8120b4b3e3a7b`.

```json
{
  "label": "green2-full-entry",
  "command": [
    "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe",
    "--path",
    "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\project",
    "res://game/tests/native_npc_review.tscn"
  ],
  "environment": {
    "SNAPLAND_SAVE_PATH": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\green2-full-entry-7b7e7d7d\\progress.json",
    "APPDATA": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\green2-full-entry-7b7e7d7d\\appdata",
    "LOCALAPPDATA": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\green2-full-entry-7b7e7d7d\\localappdata",
    "TEMP": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\green2-full-entry-7b7e7d7d\\temp",
    "TMP": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\green2-full-entry-7b7e7d7d\\temp"
  },
  "exit": 0,
  "seconds": 29.721,
  "errors": 0,
  "final_marker_count": 1,
  "source_sha256": "01c6de9a5dee40bc9ee859e3a3286aa6154f40d8cceefd27b4251757213108a0",
  "leaks": false
}
```

### final-full-entry

Raw log: `.review/main32-legacy-npc-20261118/final-full-entry.log`; SHA256 `caba2ba279585ea1de09c7bdaea7341d5c940752545d0f90b077bf5ce39cf5a3`.

```json
{
  "label": "final-full-entry",
  "command": [
    "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe",
    "--path",
    "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\project",
    "res://game/tests/native_npc_review.tscn"
  ],
  "environment": {
    "SNAPLAND_SAVE_PATH": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\final-full-entry-493ff8a5\\progress.json",
    "APPDATA": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\final-full-entry-493ff8a5\\appdata",
    "LOCALAPPDATA": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\final-full-entry-493ff8a5\\localappdata",
    "TEMP": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\final-full-entry-493ff8a5\\temp",
    "TMP": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\final-full-entry-493ff8a5\\temp"
  },
  "exit": 0,
  "seconds": 28.666,
  "errors": 0,
  "final_marker_count": 1,
  "source_sha256": "633576bb5a0da83829c56fd0f921f024daf6ad8497f8f65260786da2b251cbcb",
  "leaks": false
}
```

### import-green

Raw log: `.review/main32-legacy-npc-20261118/import-green.log`; SHA256 `7272f1a616b95db4510273232271ced55a1c572c7648ad7c5e53b3f97730858b`.

```json
{
  "label": "import-green",
  "command": [
    "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe",
    "--path",
    "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\project",
    "--headless",
    "--editor",
    "--import",
    "--quit"
  ],
  "environment": {
    "SNAPLAND_SAVE_PATH": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\import-green-c9acdd80\\progress.json",
    "APPDATA": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\import-green-c9acdd80\\appdata",
    "LOCALAPPDATA": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\import-green-c9acdd80\\localappdata",
    "TEMP": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\import-green-c9acdd80\\temp",
    "TMP": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\import-green-c9acdd80\\temp"
  },
  "exit": 0,
  "seconds": 4.527,
  "errors": 0,
  "final_marker_count": 0,
  "source_sha256": "633576bb5a0da83829c56fd0f921f024daf6ad8497f8f65260786da2b251cbcb",
  "leaks": false
}
```

### refuse-relative

Raw log: `.review/main32-legacy-npc-20261118/refuse-relative.log`; SHA256 `6f4dd4139f3538da0477128d00e4002ad9d1f89c42e6007715f6fdb9c574f5a6`.

```json
{
  "label": "refuse-relative",
  "command": [
    "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe",
    "--path",
    "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\project",
    "res://game/tests/native_npc_review.tscn"
  ],
  "environment": {
    "SNAPLAND_SAVE_PATH": "relative-progress.json",
    "APPDATA": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\refuse-relative-96f4b844\\appdata",
    "LOCALAPPDATA": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\refuse-relative-96f4b844\\localappdata",
    "TEMP": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\refuse-relative-96f4b844\\temp",
    "TMP": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\refuse-relative-96f4b844\\temp"
  },
  "exit": 1,
  "seconds": 2.277,
  "errors": 2,
  "final_marker_count": 0,
  "source_sha256": "633576bb5a0da83829c56fd0f921f024daf6ad8497f8f65260786da2b251cbcb",
  "leaks": false
}
```

### refuse-occupied

Raw log: `.review/main32-legacy-npc-20261118/refuse-occupied.log`; SHA256 `573f76459e23e932dd50197c8042c1609fe2982cdb531d4e141cd0710e986ec9`.

```json
{
  "label": "refuse-occupied",
  "command": [
    "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe",
    "--path",
    "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\project",
    "res://game/tests/native_npc_review.tscn"
  ],
  "environment": {
    "SNAPLAND_SAVE_PATH": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\refuse-occupied-9178d215\\progress.json",
    "APPDATA": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\refuse-occupied-9178d215\\appdata",
    "LOCALAPPDATA": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\refuse-occupied-9178d215\\localappdata",
    "TEMP": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\refuse-occupied-9178d215\\temp",
    "TMP": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\refuse-occupied-9178d215\\temp"
  },
  "exit": 1,
  "seconds": 2.256,
  "errors": 1,
  "final_marker_count": 0,
  "source_sha256": "633576bb5a0da83829c56fd0f921f024daf6ad8497f8f65260786da2b251cbcb",
  "leaks": false
}
```

### child-smoke

Raw log: `.review/main32-legacy-npc-20261118/child-smoke.log`; SHA256 `7dba2c60fe54984548e8103094ce2feeeb9bf659d981122bc0efc4a5d4e8cd2c`.

```json
{
  "label": "child-smoke",
  "command": [
    "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe",
    "--path",
    "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\project",
    "res://game/tests/native_sprite_clearance_review.tscn"
  ],
  "environment": {
    "SNAPLAND_SAVE_PATH": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\child-smoke-9989c0c9\\progress.json",
    "APPDATA": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\child-smoke-9989c0c9\\appdata",
    "LOCALAPPDATA": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\child-smoke-9989c0c9\\localappdata",
    "TEMP": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\child-smoke-9989c0c9\\temp",
    "TMP": "D:\\Snapland-QA\\main32-legacy-npc-20261118-588c0df2\\profiles\\child-smoke-9989c0c9\\temp"
  },
  "exit": 1,
  "seconds": 8.637,
  "errors": 1,
  "final_marker_count": 0,
  "source_sha256": "633576bb5a0da83829c56fd0f921f024daf6ad8497f8f65260786da2b251cbcb",
  "leaks": false
}
```

## Self-review and limits

- Scope checked against frozen task: one runtime-test source only, existing scene and inherited interfaces retained; no child/base/production/export changes. Protected-input hashes prove unchanged staged dependencies and runtime.
- New logic has actual full-entry RED/GREEN checks, assertions on exit/marker/error/leaks, three-role counts, captures/hashes, reduced/resume receipt and patrol spans; negative guard paths and inherited failure are exercised.
- No large frame/image buffers or per-sample source pixel reads. Sequence metadata/textures reuse library cache; announcer membership reads its existing bounded decoration cache without generating speculative costume frames. Only six viewport PNG captures read images.
- Geometry checks retain the original center visibility and collision rays. This does not prove zero rendered-pixel coverage, contact correctness or all action/direction coverage; MAIN33 child explicitly still fails its stricter depth criterion.
- Existing unsupported-material warnings remain in native logs; zero ERROR is asserted for successful parent/import, not zero warnings. No human gameplay, human listening, full-art, performance, full-suite or QA-package acceptance is claimed. Root owns remaining reviews/PM/Git/CI delivery.
