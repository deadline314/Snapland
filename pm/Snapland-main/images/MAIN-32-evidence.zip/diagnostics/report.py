"""Freeze the owned source and summarize observed MAIN32 evidence."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
OWNED = 'game/tests/native_npc_review.gd'
STAGE = Path(json.loads((HERE / 'stage-location.json').read_text()))
FINAL = json.loads((HERE / 'final-full-entry.json').read_text())
PROFILE = Path(FINAL['environment']['SNAPLAND_SAVE_PATH']).parent
RECEIPT = PROFILE / 'native-npc-review/receipt.json'
OBSERVATIONS = json.loads(RECEIPT.read_text())
INITIAL = json.loads((HERE / 'stage-manifest.json').read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert sha(ROOT / OWNED) == sha(STAGE / OWNED) == FINAL['source_sha256'] == OBSERVATIONS['source_sha256']
assert FINAL['exit'] == 0 and FINAL['errors'] == 0 and FINAL['final_marker_count'] == 1 and not FINAL['leaks']
protected = {name: dict(initial=digest, stage=sha(STAGE / name), source=sha(ROOT / name))
             for name, digest in INITIAL.items() if name != OWNED}
assert all(row['initial'] == row['stage'] == row['source'] for row in protected.values())
for row in OBSERVATIONS['captures']:
    assert sha(Path(row['path'])) == row['sha256']
(HERE / 'protected-final-hashes.json').write_text(json.dumps(protected, indent=2), encoding='utf-8')
(HERE / 'source-frozen.gd.txt').write_bytes((ROOT / OWNED).read_bytes())
(HERE / 'final-runtime-receipt.json').write_bytes(RECEIPT.read_bytes())

labels = ['import-red', 'red-full-entry', 'green-full-entry', 'green2-full-entry',
          'final-full-entry', 'import-green', 'refuse-relative', 'refuse-occupied', 'child-smoke']
report = [
    '# MAIN32 Task 1 source-frozen report', '',
    'Status: complete for the owned parent entry, pending root task/final reviews and delivery. Only `game/tests/native_npc_review.gd` runtime-test source changed. No Git/PM, production, base classes, child entry, runtime package or QA export changes by this worker.', '',
    '## Source and scope', '',
    f'- RED source SHA256: `{sha(HERE / "source-red.gd.txt")}`.',
    f'- Final source SHA256: `{FINAL["source_sha256"]}`; exact bytes frozen at `.review/main32-legacy-npc-20261118/source-frozen.gd.txt`.',
    '- Read frozen spec, plan global constraints, task brief, pm-ticket and ponytail; followed verification-before-completion evidence requirement. Inspected native parent/layout/base, sole clearance inheritor, scene/call references, activity registration/playback/current source normalization, timing, costume cache, authored patrol profiles, marker parenting, save guard and shared audio release helper before implementation.',
    '- Public `NpcRoles`, `records`, `_sprite`, `_anchor`, `_texture_synced`, `_review_role`, `_check_npc_visible` and base-class path remain. Parent cleanup uses new `_npc_finish`; `_fail` is not overridden, so the child retains its original failure handling.',
    f'- All {len(protected)} other staged/runtime/dependency inputs match initial stage-manifest SHA256 and current repository bytes; full comparisons are in `protected-final-hashes.json`. No player data reset: all profile trees are new independent D paths.', '',
    '## Staging and commands', '',
    f'Stage: `{STAGE.as_posix()}`. `prepare_runtime_stage` copies tracked runtime only; explicit dependency allowlist is in private `run.py`: native NPC scene/script, native clearance scene/script for inherited parsing/smoke, native layout/base scripts, and audio playback release. No C import cache, full repository copy, existing-stage deletion, package mutation or re-export.', '',
    'Every engine launch below used `tools.godot_entrypoints.run_validated_godot`, exact `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe`. Native logs identify `4.7.2.stable.official.ed1daf0bf`, Vulkan Forward+, AMD Radeon RX 9070 XT. Import/parser launches alone are headless. Every absolute save, APPDATA, LOCALAPPDATA, TEMP and TMP is independently recorded below.', '',
    'Shell driver commands (each invokes the validated Python launcher internally):', '',
    '```powershell',
    'python .review/main32-legacy-npc-20261118/run.py prepare',
    'python .review/main32-legacy-npc-20261118/run.py green-full-entry',
    'python .review/main32-legacy-npc-20261118/run.py green2-full-entry',
    'python .review/main32-legacy-npc-20261118/run.py final-full-entry',
    'python .review/main32-legacy-npc-20261118/run.py child-smoke',
    'python .review/main32-legacy-npc-20261118/run.py refuse-relative',
    'python .review/main32-legacy-npc-20261118/run.py refuse-occupied',
    'python .review/main32-legacy-npc-20261118/run.py import-green',
    'python .review/main32-legacy-npc-20261118/report.py',
    '```', '',
    '## Actual RED and repair', '',
    'Fresh full native RED exited 1 at ticket label/root/interaction identity, with actual root `(-3.8,0,5)` against obsolete `(-5,0,10)`. It is an actual pre-edit run, not reused ART17 evidence. Exact original source, raw log, command and environment are preserved.', '',
    'First repaired run (`green-full-entry`) remained RED: name lookup selected the now-reparented interaction marker because both are direct Label3D children. Fix uses exact expected role name and checks marker identity/parent separately. Raw intermediate failure remains preserved. `green2-full-entry` passed. Final source then added actual sample/time observations and graceful missing-library rejection; `final-full-entry` reran the entire entry successfully.', '',
    'Current entry validates full canonical sequence frames against the existing normalized library and shared timing checks; compares displayed texture membership by cached identity, including the announcer existing costume cache, plus shader texture/full UV. Legacy fallback and absent formal source cannot pass. All roles use current origins/point IDs and validated patrol profiles. Natural timers observe multiple poses and at least 80% of each allowed X span, bounded to 180 samples per role; no fixed four-frame or required service/dance claim.', '',
    '## Final native results', '',
    f'Full entry: exit 0, {FINAL["seconds"]} seconds, zero ERROR/leak markers, exact final success marker once. Successful marker emitted only after capture/receipt checks and shared Release capture -> shutdown -> queue_free -> existing two-frame barrier -> bounded weak-reference playback release. Raw stdout and stderr are concatenated in logs, so their merged textual order is not chronological.', '',
    '| Role | Point | Different displayed texture poses | Observed X range (m) | Samples | Observation seconds |',
    '|---|---|---:|---:|---:|---:|',
]
for row in OBSERVATIONS['roles']:
    report.append(f'| {row["role"]} | {row["point"]} | {row["different_poses"]} | {row["largest_x"]-row["smallest_x"]:.6f} | {row["samples"]} | {row["seconds"]:.3f} |')
report += ['', 'Action/direction and actual observed pose indices (not a claim of complete animation coverage):', '', '```json',
           json.dumps({r['role']: r['observed_action_direction_pose_indices'] for r in OBSERVATIONS['roles']}, indent=2), '```', '',
           'Identity, unique three-role registration, required names, marker ownership/follow, point follow, per-role XYZ bounds, visible body/name centers and collision-geometry rays remain active. Reduced mode independently resolves formal front standing rather than accepting the legacy baseline: first complete source/costume texture, shader/full UV, zero action elapsed, stable controller clock, restored baseline roots/original interaction points and retained state across a 0.4-second natural wait. Normal mode resumes its clock/playback and synchronized formal source.', '',
           'Review staging is explicit: world camera-follow physics disabled, offscreen hero `(15,0.4,-24.5)`, noon, fixed close camera per role at current origin plus `(0,3.8,6.5)` looking at origin plus `(0,1.45,0)`. NPC roots/actions/textures/clocks are never assigned. The usual marker visibility is not forced; marker parenting/XZ follow is checked. Captures were inspected for all three roles: required names and bodies are framed; no geometry or thresholds were modified.', '',
           '## Captures and hashes', '', f'Fresh required profile-adjacent directory: `{(PROFILE / "native-npc-review").as_posix()}`. It contains six original PNGs plus runtime receipt. No ART12 path was used. Runtime receipt SHA256: `{sha(RECEIPT)}`.', '',
           '| File | SHA256 |', '|---|---|']
for row in OBSERVATIONS['captures']:
    report.append(f'| {Path(row["path"]).name} | `{row["sha256"]}` |')
report += ['', '## Safeguards and inherited smoke', '',
           '- Final headless editor import/parser: exit 0, zero ERROR/leak markers, unchanged child inheritance accepted.',
           '- Relative save: native exit 1, no success marker. Both Progress guard and this entry reject the relative override. No relative progress file was created.',
           '- Occupied native-npc-review: native exit 1, no success marker. Sentinel `keep.txt` remained byte-for-byte intact and the directory still contains only that sentinel, no receipt or captures.',
           '- Child smoke: exit 1 with exactly the existing single `Sprite NPC announcer frame 2 has 307/47406 rendered body pixels hidden by scene geometry or overlays` ERROR; no new parser/type/I/O/teardown/leak errors. MAIN33 remains unmodified and unresolved.', '',
           '## Exact engine invocations, environments and raw logs', '']
for label in labels:
    item = json.loads((HERE / (label + '.json')).read_text())
    report += [f'### {label}', '', f'Raw log: `.review/main32-legacy-npc-20261118/{label}.log`; SHA256 `{sha(HERE / (label + ".log"))}`.', '',
               '```json', json.dumps(item, indent=2), '```', '']
report += ['## Self-review and limits', '',
           '- Scope checked against frozen task: one runtime-test source only, existing scene and inherited interfaces retained; no child/base/production/export changes. Protected-input hashes prove unchanged staged dependencies and runtime.',
           '- New logic has actual full-entry RED/GREEN checks, assertions on exit/marker/error/leaks, three-role counts, captures/hashes, reduced/resume receipt and patrol spans; negative guard paths and inherited failure are exercised.',
           '- No large frame/image buffers or per-sample source pixel reads. Sequence metadata/textures reuse library cache; announcer membership reads its existing bounded decoration cache without generating speculative costume frames. Only six viewport PNG captures read images.',
           '- Geometry checks retain the original center visibility and collision rays. This does not prove zero rendered-pixel coverage, contact correctness or all action/direction coverage; MAIN33 child explicitly still fails its stricter depth criterion.',
           '- Existing unsupported-material warnings remain in native logs; zero ERROR is asserted for successful parent/import, not zero warnings. No human gameplay, human listening, full-art, performance, full-suite or QA-package acceptance is claimed. Root owns remaining reviews/PM/Git/CI delivery.', '']
target = ROOT / '.superpowers/sdd/2026-11-18-legacy-npc-native-review/task-1-report.md'
target.write_text('\n'.join(report), encoding='utf-8')
print(json.dumps(dict(source=FINAL['source_sha256'], protected_inputs=len(protected), report=str(target),
                      report_sha256=sha(target), receipt=str(RECEIPT)), indent=2))
