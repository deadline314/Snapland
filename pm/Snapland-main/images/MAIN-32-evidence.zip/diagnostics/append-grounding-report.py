"""Preserve rejected evidence and append the one-line camera grounding repair."""
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
TARGET = ROOT / '.superpowers/sdd/2026-11-18-legacy-npc-native-review/task-1-report.md'
OWNED = 'game/tests/native_npc_review.gd'
STAGE = Path(json.loads((HERE / 'stage-location.json').read_text()))
RUN = json.loads((HERE / 'green-grounding-full-entry.json').read_text())
PROFILE = Path(RUN['environment']['SNAPLAND_SAVE_PATH']).parent
RECEIPT = PROFILE / 'native-npc-review/receipt.json'
OBS = json.loads(RECEIPT.read_text())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

assert sha(ROOT / OWNED) == sha(STAGE / OWNED) == RUN['source_sha256'] == OBS['source_sha256']
assert RUN['exit'] == 0 and RUN['errors'] == 0 and RUN['final_marker_count'] == 1 and not RUN['leaks']
old = (HERE / 'source-final-full-entry.gd.txt').read_text(encoding='utf-8')
new = (ROOT / OWNED).read_text(encoding='utf-8')
assert new == old.replace('\tmain.world.camera.current = true\n', '\tmain.world.camera.current = true\n\tmain.world._update_sprite_grounding()\n', 1)
protected = {name: dict(initial=digest, stage=sha(STAGE / name), source=sha(ROOT / name))
             for name, digest in json.loads((HERE / 'stage-manifest.json').read_text()).items() if name != OWNED}
assert all(row['initial'] == row['stage'] == row['source'] for row in protected.values())
for row in OBS['captures']: assert sha(Path(row['path'])) == row['sha256']
(HERE / 'protected-grounding-final-hashes.json').write_text(json.dumps(protected, indent=2), encoding='utf-8')
(HERE / 'source-grounding-frozen.gd.txt').write_bytes((ROOT / OWNED).read_bytes())
(HERE / 'grounding-runtime-receipt.json').write_bytes(RECEIPT.read_bytes())
old_report = TARGET.read_text(encoding='utf-8')
assert not (HERE / 'report-before-grounding-correction.md').exists()
(HERE / 'report-before-grounding-correction.md').write_text(old_report, encoding='utf-8')

notice = '''> Correction status: the earlier `final-full-entry-493ff8a5` run below passed script checks but FAILED root visual acceptance because the floor clipped all three characters' boots/legs. Its PNGs, logs, receipt, source hash and the worker's mistaken visual assessment are retained as rejected history. Current source/evidence is the appended **Grounding correction** section, frozen for independent root visual review. Do not package the old `final-full-entry` captures as accepted evidence.

'''
lines = ['', '# Grounding correction after root visual rejection', '',
         'Root rejected ticket-01, imp-02 and announcer-02 from `final-full-entry-493ff8a5`: a flat floor edge near screen Y550 cut off boots/legs in all three roles. The worker saw these PNGs and missed that defect; the earlier visual inspection statement is incorrect. Machine PASS alone did not satisfy the visual acceptance gate. Original report preserved byte-content at `.review/main32-legacy-npc-20261118/report-before-grounding-correction.md`; no old run files or PNGs overwritten.', '',
         '## Diagnosis and smallest correction', '',
         '`ParkWorld.sprite_ground_anchor_y` computes presentation child ground-anchor Y from `camera.global_basis.y.y` (the camera pitch). Production `_physics_process` calls `_update_sprite_grounding()` after camera `look_at`. This entry deliberately disables that physics loop for fixed framing and then changes the camera pitch, so presentation anchors retained the previous camera basis while billboard orientation used the new basis. The actual floor therefore clipped the now lower-projected feet. The existing native approach fixture already synchronizes grounding after its camera transform.', '',
         'Added exactly one runtime-test line, `main.world._update_sprite_grounding()`, immediately after the role camera transform/current assignment. The existing grounding owner resynchronizes the presentation child anchors for that pitch. No NPC activity roots/routes/actions/textures/clocks, floor visibility/geometry, shader/depth flags or occlusion thresholds were changed. A source comparison assert proves the correction is exactly this one-line addition relative to the rejected frozen source.', '',
         '```diff', *list(difflib.unified_diff(old.splitlines(), new.splitlines(), fromfile='rejected-source', tofile='grounded-source', lineterm='')), '```', '',
         f'New frozen source SHA256: `{RUN["source_sha256"]}` at `.review/main32-legacy-npc-20261118/source-grounding-frozen.gd.txt`. All {len(protected)} protected inputs still match initial/current/staged hashes; new comparison record `protected-grounding-final-hashes.json`.', '',
         '## Fresh verification and visual comparison', '',
         '```powershell',
         'python .review/main32-legacy-npc-20261118/run.py green-grounding-full-entry',
         'python .review/main32-legacy-npc-20261118/run.py import-grounded',
         'python .review/main32-legacy-npc-20261118/append-grounding-report.py', '```', '',
         f'Fresh absolute isolated D profile/output: `{(PROFILE / "native-npc-review").as_posix()}`. Full native Vulkan/Radeon run: exit 0, {RUN["seconds"]} seconds, zero ERROR/leak markers, exact final marker once, three-role formal membership/material/UV/bounds/name/point/marker-follow/reduced-standing/resume checks retained. Fresh headless parser/import includes unchanged child inheritance: exit 0, zero errors/leaks.', '',
         '| Role | Different poses | X span (m) | Samples | Seconds |', '|---|---:|---:|---:|---:|']
for row in OBS['roles']:
    lines.append(f'| {row["role"]} | {row["different_poses"]} | {row["largest_x"]-row["smallest_x"]:.6f} | {row["samples"]} | {row["seconds"]:.3f} |')
lines += ['', 'All six new PNGs inspected. Compared with the rejected old images: ticket has complete brown boot silhouettes; imp has complete planted/lifted red feet; announcer has complete yellow boots with curved outlines. The shared flat floor cutoff is gone. This confirms the existing grounding synchronization fixes the camera-dependent presentation issue. Root independently inspected ticket-01, imp-02 and announcer-02 and accepted the static visual gate for these three new captures. No claim of a generic rendered-pixel depth proof is made.', '',
          f'New runtime receipt SHA256: `{sha(RECEIPT)}`. Copied JSON receipt at `.review/main32-legacy-npc-20261118/grounding-runtime-receipt.json` records observed actions/directions/pose indices and every PNG hash.', '',
          '| New PNG | SHA256 |', '|---|---|']
for row in OBS['captures']: lines.append(f'| {Path(row["path"]).name} | `{row["sha256"]}` |')
for label in ['green-grounding-full-entry', 'import-grounded']:
    lines += ['', f'## {label} exact invocation/environment', '',
              f'Raw log `.review/main32-legacy-npc-20261118/{label}.log`, SHA256 `{sha(HERE / (label + ".log"))}`.', '',
              '```json', (HERE / (label + '.json')).read_text(), '```']
lines += ['', '## Remaining scope and limits', '',
          'Only the new camera synchronization line changed after the previous refusal/child checks. Earlier negative path/output and child smoke runs used source SHA256 `633576bb5a0da83829c56fd0f921f024daf6ad8497f8f65260786da2b251cbcb`, not the new `82627ce65faec3b550fa071e51311059f4e279665fa45b8c5d2a9d49af65875d` source. Their exact MAIN33 307/47406 failure and guard results remain preserved; the guard and inherited child paths are unchanged by the camera-only line. Child/base/production were not edited. No new generic foot-check framework, broad test suite, package export, human play/listening or full animation acceptance was added. Root owns task/final reviews and delivery.', '']
TARGET.write_text(notice + old_report + '\n'.join(lines), encoding='utf-8')
print(json.dumps(dict(source=RUN['source_sha256'], report_sha256=sha(TARGET), output=str(PROFILE / 'native-npc-review')), indent=2))
