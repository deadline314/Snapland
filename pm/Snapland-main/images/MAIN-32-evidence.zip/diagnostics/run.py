"""Owned MAIN32 staging and bounded validated-engine evidence."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import uuid

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from tools.build_desktop_release import prepare_runtime_stage
from tools.godot_entrypoints import run_validated_godot

HERE = Path(__file__).resolve().parent
ENGINE = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
OWNED = 'game/tests/native_npc_review.gd'
ALLOW = [OWNED, 'game/tests/native_npc_review.tscn',
         'game/tests/native_sprite_clearance_review.gd', 'game/tests/native_sprite_clearance_review.tscn',
         'game/tests/native_layout_review.gd', 'game/tests/native_review.gd',
         'game/tests/audio_playback_release.gd']
MARKER = 'PASS: native NPC formal-source playback, bounded patrol, labels, interaction points and reduced standing'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run(label, args, timeout=120, save_override=None, occupied=False):
    profile = STAGE.parent / 'profiles' / (label + '-' + uuid.uuid4().hex[:8])
    env = dict(os.environ, SNAPLAND_SAVE_PATH=str(profile / 'progress.json'),
               APPDATA=str(profile / 'appdata'), LOCALAPPDATA=str(profile / 'localappdata'),
               TEMP=str(profile / 'temp'), TMP=str(profile / 'temp'))
    for key in ['APPDATA', 'LOCALAPPDATA', 'TEMP']:
        Path(env[key]).mkdir(parents=True)
    if save_override is not None:
        env['SNAPLAND_SAVE_PATH'] = save_override
    if occupied:
        output = profile / 'native-npc-review'
        output.mkdir()
        (output / 'keep.txt').write_text('must remain unchanged', encoding='utf-8')
    cmd = [ENGINE, '--path', str(STAGE), *args]
    start = time.monotonic()
    try:
        result = run_validated_godot(STAGE, cmd, env, timeout)
        output, code = result.stdout + result.stderr, result.returncode
    except subprocess.TimeoutExpired as exc:
        output, code = str(exc.output or '') + str(exc.stderr or ''), 'timeout'
    receipt = dict(label=label, command=cmd, environment={k: env[k] for k in ['SNAPLAND_SAVE_PATH','APPDATA','LOCALAPPDATA','TEMP','TMP']},
                   exit=code, seconds=round(time.monotonic()-start, 3), errors=output.count('ERROR:'),
                   final_marker_count=output.count(MARKER), source_sha256=sha(STAGE / OWNED),
                   leaks=any(s in output.lower() for s in ['leaked', 'still in use', 'orphan']))
    (HERE / (label + '.log')).write_text(output, encoding='utf-8')
    (HERE / (label + '.json')).write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    print(json.dumps(receipt), flush=True)
    if label.startswith('refuse-'):
        assert code != 0 and receipt['final_marker_count'] == 0, receipt
        if occupied:
            assert (profile / 'native-npc-review/keep.txt').read_text() == 'must remain unchanged'
            assert sorted(p.name for p in (profile / 'native-npc-review').iterdir()) == ['keep.txt']
    elif label.startswith('green') or label == 'final-full-entry':
        assert code == 0 and receipt['errors'] == 0 and receipt['final_marker_count'] == 1 and not receipt['leaks'], receipt
        evidence = profile / 'native-npc-review'
        actual = json.loads((evidence / 'receipt.json').read_text())
        assert actual['status'] == 'PASS' and actual['source_sha256'] == receipt['source_sha256']
        assert len(actual['roles']) == 3 and len(actual['captures']) == 6
        assert actual['reduced_standing'] and actual['resumed']
        for row in actual['captures']:
            assert sha(Path(row['path'])) == row['sha256']
        for row in actual['roles']:
            assert row['different_poses'] >= 2
            assert row['largest_x'] - row['smallest_x'] >= .8 * (row['patrol_profile']['maximum_offset'] - row['patrol_profile']['minimum_offset'])
    return receipt

mode = sys.argv[1]
if mode == 'prepare':
    parent = Path('D:/Snapland-QA') / ('main32-legacy-npc-20261118-' + uuid.uuid4().hex[:8])
    STAGE = parent / 'project'
    STAGE.mkdir(parents=True)
    (HERE / 'stage-location.json').write_text(json.dumps(str(STAGE)), encoding='utf-8')
    tracked = subprocess.check_output(['git','ls-files','-z'], cwd=ROOT, text=True, encoding='utf-8').split('\0')
    manifest = prepare_runtime_stage(ROOT, STAGE, tracked)
    for p in ALLOW:
        (STAGE / p).parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / p, STAGE / p)
        manifest[p] = sha(ROOT / p)
    (HERE / 'stage-manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    (HERE / 'source-red.gd.txt').write_bytes((ROOT / OWNED).read_bytes())
    result = run('import-red', ['--headless','--editor','--import','--quit'], 300)
    assert result['exit'] == 0 and result['errors'] == 0, result
    run('red-full-entry', ['res://game/tests/native_npc_review.tscn'])
else:
    STAGE = Path(json.loads((HERE / 'stage-location.json').read_text()))
    shutil.copy2(ROOT / OWNED, STAGE / OWNED)
    (HERE / ('source-' + mode + '.gd.txt')).write_bytes((ROOT / OWNED).read_bytes())
    if mode in ['import-green', 'import-grounded']:
        result = run(mode, ['--headless','--editor','--import','--quit'], 300)
        assert result['exit'] == 0 and result['errors'] == 0, result
    elif mode == 'refuse-occupied':
        run(mode, ['res://game/tests/native_npc_review.tscn'], occupied=True)
    elif mode == 'refuse-relative':
        run(mode, ['res://game/tests/native_npc_review.tscn'], save_override='relative-progress.json')
    elif mode == 'child-smoke':
        result = run(mode, ['res://game/tests/native_sprite_clearance_review.tscn'], 90)
        log = (HERE / (mode + '.log')).read_text()
        assert result['exit'] == 1 and result['final_marker_count'] == 0 and result['errors'] == 1 and not result['leaks'], result
        assert 'has 307/47406 rendered body pixels hidden by scene geometry or overlays' in log
    else:
        run(mode, ['res://game/tests/native_npc_review.tscn'])
