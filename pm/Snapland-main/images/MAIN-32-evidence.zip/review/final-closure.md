# SDD ledger — plan: docs/superpowers/plans/2026-11-18-legacy-npc-native-review.md

Branch codex/legacy-npc-review-20261118, BASEc57ca6d, main95d9d80. MAIN32 opening already onmain, no implementation yet. ART17 bounded fixes delivered95d9d8072bb40cbee4df5f3c41d5ed7d70bad6a3; all task/final/scoped gates clean after1P2 finalwave. Main CI44147397191 pending; ownduplicate44147378720 cancellation requested. No old feature/worktree remains. Preserve allpreexisting untracked imports/UIDs.

## Preflight

| Task/pair | Producer/consumer and finding | Ruling |
|---|---|---|
| Task1 self | currentworld3origins/profilebounds + formalvalidatedsource vs actualnativechecks/strictguard | coherent, no new production/runtime abstraction |
| Task1 inheritance | parentnativeentry fields/utility methods consumed by clearancechild overriding_run | preserve baseclass/fields/method signatures; do not repair MAIN33 here |
| Task1→Task2 | frozen native GD/actualPNG+receipt consumed by root artifact/review/PM | no source change afterfreeze; no exportneeded for excludedfixture |
| Task2 self | per-ticket completion and main CI/cleanup vs userauthorization | already authorized; no approval prompt |

Ruling: use current approved source membership and observed counts, not obsolete legacy4frame count or unobserved dance/service claim — preserves original validation purpose without pretending fullart coverage; wrong choice costs a test refinement, no player logic/data change.
Ruling: write to fresh isolated profile-adjacent native-npc-review folder instead of overwriting historicalART12 captures — keeps new evidence reviewable and original evidence intact; wrong choice costs documented developer output-path adjustment.

## Status

- [x] Ticket opening onmain; spec/plan committed+pushedc57ca6d.
- [x] Task1 actualRED/repair/fullGPUchecks/pathrefusal/sourcefreeze/taskreview.
- [ ] Root evidence/finalreview/PM/Git/mainCI/cleanup.

Only root Git/PM/docs. Worker no subagents. New D stages only; Cdisk priorfull resolved by native singleleaf move of own deliveredSG41binary to D:/Snapland-QA/retained-sugar-bridge-20261118/SugarBridgeQAFinal.exe, SHA f023331e6b4e53c1dc0b2fffa1756c6b2c2e86ecda9a85190237625e6713fc5e. Relocation proof in priorART17public evidence. Do not remove policy-blocked C QA projectdirectories or mutate frozen acceptedpackages.

Root actualvisualgate REJECTED firsttechnicalGREEN633576... final-full-entry493ff8a5: all3representativePNGs boots clippedflatatfloor. Worker inspectedbutmissed; source/log/images preserved. Originalproducerfollowup diagnoseandminimalexistinggroundingsync aftercamerachange, sourceonlysameentry, newlabels/profile. No taskreview/commit yet; do notpublish firsttechnicalgreen asacceptedfullbody.

Task1: complete (commitsc57ca6d..389d711, spec+qualityPASS noBlocking). Source82627...; newgroundedfullGPU28.574s strictPASS +import0errors. Rootvisualacceptance3newfullfootPNGs stored; previous633 clippedproofrejectedretained. ParentcleanupisolatedNpcFinish, childoldMain33depth307/47406 preservedexact;1191protectedruntime/deps unchanged.
Task1 minor(deferred): P3 receiptstatus serializedbeforeownflushresult; failedwrite exits1/no marker but survivingJSONcouldsayPASS. Currentconsumerrequirescleanprocess+exactmarker+zeroERROR+receipt; specclarifiedno receipt-onlyacceptance. No newreceipt-onlyconsumer requested; finalreviewtotriage. No fixloopforMinor.
PreviousART17main95d9d80 all6CIjobs SUCCESS44147397191 viaGitHubconnector; userbranch/worktreecleanupdone. NewMAIN32finalreview/PM/mainCIremaining.

Wholebranch finalreview95d9d80..13b95df ReadyYES;0Critical/Important, P3selfreceiptstatus remainsnonblocking under strictcombinedprocesscontract. Finalreviewindependentlyviewed3publicfullfootPNGs andauditedpublic/archive/source826/marker/zeroERROR/leaks/1191proof. Nofixwave.
Finaldeclineditems accepted: production/assets unchanged; fullMain33childdepthrepair next, noallbodypixelclearanceclaimforparent; humanplay/hearing/fullart/performance outsideexactnativeevidence; driver+receipt combinedgate required, no receipt-onlyconsumer. Git/mainCIclosurependingroot.
