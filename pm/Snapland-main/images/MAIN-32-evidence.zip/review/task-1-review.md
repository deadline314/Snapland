# MAIN-32 Task 1 spec and quality review

Verdict: **PASS with one non-blocking evidence-status observation**. No blocking defect found in the reviewed successful entry, current-source validation, grounding correction, or inherited child path. Task 2 delivery and final whole-branch review remain root-owned gates.

## Scope and authority

Read-only review of the supplied `review-c57ca6d..389d711.diff`, current `game/tests/native_npc_review.gd`, Task 1 brief/report including the appended grounding correction, `design/runtime/legacy-npc-native-review.md`, and plan Global Constraints. Inspected the layout/native base chain, sole clearance inheritor, shared save guard/audio release/timing, NPC source normalization/costume cache and grounding implementation. Applied the active Ponytail scope/minimality requirements. Existing MAIN-32 ticket/Git/delivery are owned by root; this reviewer changed only this review artifact.

Reviewed runtime source SHA256: `82627ce65faec3b550fa071e51311059f4e279665fa45b8c5d2a9d49af65875d`. Current bytes equal `source-grounding-frozen.gd.txt`. A read-only comparison confirmed the grounding correction is exactly the one `_update_sprite_grounding()` call after camera transform relative to rejected source `633576bb5a0da83829c56fd0f921f024daf6ad8497f8f65260786da2b251cbcb`.

## Spec assessment

| Requirement | Assessment |
|---|---|
| Existing scene/base/inheritance preserved | PASS. `NativeLayoutReview -> NativeReview` chain, role constant and inherited fields/helpers remain. Child overrides `_run`, uses unchanged `_texture_synced`, and retains base `_fail`. New `_npc_finish` does not replace inherited failure handling. |
| Current origins, unique roles, names and point identity | PASS. Three active registrations and per-role counts, current three roots/IDs, expected name label and separate marker parent/identity are checked. |
| Formal complete sources and costume/material/UV | PASS. Normalized available library sequence is resolved by actual action/direction; shared timing, full frame count, canonical dimensions, texture identities and timing metadata must match; legacy fallback is rejected. Announcer uses already-produced costume-cache identities. Shader texture and full UV remain checked. |
| Natural bounded patrol and observations | PASS. Real timers advance activity; profiles supply actual bounds, minimum observed travel is 80% of span, multiple texture poses are required and action/direction/pose indices are recorded. Root/point/name/marker follow checks remain. No NPC root/action/texture/clock assignments were added. |
| Visibility and camera-dependent grounding | PASS within specified scope. Existing center visibility/collision rays remain; fixed camera and offscreen hero are disclosed. Existing grounding owner now resynchronizes presentation anchors after camera pitch changes. No geometry/depth/threshold edits. Root's recorded visual gate accepts three current representative complete-foot PNGs. |
| Reduced standing and resume | PASS. Independently resolved formal front standing, costume/material/UV, zero action elapsed, stable clock/root/point and restored original positions are checked after a natural pause. Normal clock and formal source playback then resume. |
| Isolated fresh output, no history overwrite | PASS. Existing absolute-save guard plus new-save/project containment checks precede progress reset. Nonempty output is rejected, each PNG refuses an existing file, and captures go beside the isolated profile. Relative and occupied-output failures were exercised. |
| Exact marker after teardown and evidence | PASS for verified run. Playback weakrefs are captured before shutdown/free; existing two-frame barrier and bounded release wait precede receipt and final marker. Failures exit nonzero. See minor receipt observation below. |

The implementation reuses existing owners and caches without a new framework, dependency, production change or per-sample image processing. The only viewport readbacks are the six evidence captures.

## Evidence checked

- Actual baseline raw log fails at obsolete ticket root/identity; it is not represented as a pass.
- Current `green-grounding-full-entry.json` and raw log record validated Godot 4.7.2, native Vulkan/Radeon, isolated D paths, exit 0 in 28.574 seconds, zero ERROR/leak markers, and the exact marker once. Each role records 22 poses and 70 natural samples; ranges are approximately 1.2/0.5925/1.2 metres. Receipt records reduced/resume success and explicit staging.
- Actual six current PNG SHA256 values match the current receipt; log SHA256 is `2738cf0f47769f607bcd122d13ccd726b71e6019dd25852f94b25dcc1d2c7ec1`; receipt SHA256 is `80c75c47de6c05074a84bf420718e63c2df79b43c97fdbd84476036e480ab1b7`. Both match the corrected report.
- All 1191 protected-input comparison records have identical initial/stage/source hashes. This review checked the supplied comparison records, not a new full filesystem rehash.
- Current parser/import metadata and raw log are clean. Earlier relative/occupied-output and child-smoke metadata correctly identify source `633576…`, not current `82627…`. The sole later source addition lies inside parent `_review_role`; guard paths and child's overriding `_run` do not execute it, so the disclosed older smoke remains relevant without claiming a new child run.
- Child raw log still fails with exactly the known MAIN-33 announcer frame 2 `307/47406` coverage error. This is not child clearance acceptance.
- The report clearly marks the old clipped-boot captures as rejected history. `root-visual-acceptance.json` identifies only current-source captures and limits that acceptance to representative static full bodies.

## Non-blocking observation

**[P3] Receipt status precedes receipt-write success — `game/tests/native_npc_review.gd:113-123`.** `_npc_finish` serializes `status=PASS` and an empty failure before `flush()/get_error()`. If receipt writing itself fails after bytes reach the file, the process correctly reports an error, omits the success marker and exits 1, but a surviving receipt can still claim PASS. No observed run encountered this; the provided driver checks exit/error/marker before trusting the receipt, so this does not invalidate the current acceptance evidence. A future evidence consumer should continue requiring process results; if receipt-only consumption is introduced, invalidate/remove a receipt on its write failure. No fault injection was performed.

## Limits

No engine launches, source changes, Git/PM actions, subagents or test reruns were performed. Root's already-recorded image inspection was reviewed as evidence; this reviewer did not independently view the PNGs. Center/ray checks and representative static images do not establish all rendered-pixel clearance, every animation/direction, human play/listening, full-art acceptance, performance, a broad suite or QA-export acceptance. MAIN-33 remains unresolved and separate.
