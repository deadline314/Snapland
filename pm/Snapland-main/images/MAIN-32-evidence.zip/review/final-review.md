# MAIN-32 final whole-branch review

Reviewed range: `95d9d80..13b95df`, using the supplied whole-branch diff, current source, authority `design/runtime/legacy-npc-native-review.md`, implementation plan, task brief/report/review, ledger, and retained evidence. This review follows the supplied requesting-code-review template. Only this report was written; no source, PM, index, branch, worktree or engine state was changed.

Runtime source reviewed: `game/tests/native_npc_review.gd`, SHA256 `82627ce65faec3b550fa071e51311059f4e279665fa45b8c5d2a9d49af65875d`.

### Strengths

- The change reaches the actual obsolete assumptions while retaining the entry scene and inheritance chain. Current origins and unique roles, separate name/marker identity, formal source membership, canonical frame dimensions, material texture/full UV and per-role patrol bounds are checked. The clearance child overrides `_run`, still consumes the unchanged role constant/texture helper, and retains its inherited `_fail`; the new private `_npc_finish` does not redirect child failures.
- Source validation follows the existing validated animation-library/normalization/timing owners and costume cache. It checks the complete live sequence against the formal sequence and the actual displayed texture against that sequence. Natural timers observe real activity and substantial bounded travel, with action/direction/pose observations recorded rather than unsupported fixed-animation completion claims.
- Reduced motion verifies formal front standing, original root/interaction positions, stable texture/time/position and material synchronization; resume checks clock progression and current formal texture membership. Existing collision/visibility checks remain. The camera correction calls the existing grounding owner immediately after changing the camera, without moving NPC roots or altering depth criteria.
- Output preparation precedes progress reset and combines the existing save guard with fresh-save/project containment/nonempty-output checks. Captures refuse existing paths. Teardown uses the existing playback weak-reference release helper before the receipt and exact success marker; failures exit nonzero.
- Evidence is candid about the rejected first technically green capture set, older source hashes for guard/child checks, and static/scripted coverage. The delivered PNGs and archive correspond to the corrected run, not the rejected images. No production, asset, base-review or child-fixture changes appear in the supplied range.

### Evidence examined

- Read the changed runtime source, original frozen source, native base/layout initialization and failure handling, clearance child's inherited use, save guard, audio release helper, animation normalization/timing/playback and world grounding implementation. Reviewed the spec, plan, ticket changes and archive producer/acceptance checks.
- Independently read final run metadata/raw log: validated Godot 4.7.2 native invocation, isolated D profile, exit `0`, `28.574` seconds, exactly one complete success marker, zero `ERROR:` and no checked leak markers. Current import metadata/raw log also records exit `0` and zero errors. No new engine run was performed.
- Current source hash matches the runtime receipt and archived final source. Archive accepted receipt equals the retained runtime receipt. All three public PNG bytes match their receipt hashes and archived accepted PNGs. Raw final log SHA256 is `2738cf0f47769f607bcd122d13ccd726b71e6019dd25852f94b25dcc1d2c7ec1`.
- Independently viewed all three public representative PNGs: ticket's brown boots, imp's planted/lifted feet, and announcer's yellow boots are present with full outlines. This supports representative static full-body acceptance, not every animation frame or zero rendered-pixel occlusion.
- Receipt records three roles, 70 samples per role, multiple formal poses, expected bounded spans, reduced standing and resume. All 1191 supplied protected-input records have equal initial/stage/source hashes; I did not repeat a full filesystem rehash.
- Baseline raw evidence exits `1` with no success marker. Relative-save and occupied-output raw evidence also exits `1` with no marker. Child smoke retains exactly the known `307/47406` announcer frame 2 depth failure. These guard/child runs used `633576...`; the subsequent source addition is confined to the parent role-camera grounding call and does not execute on these paths. They are relevant earlier-path evidence, not fresh final-source runs or child clearance acceptance.

### Issues

#### Critical (Must Fix)

None found.

#### Important (Should Fix)

None found.

#### Minor (Nice to Have)

1. **[P3] A surviving receipt can retain PASS after its own write failure.**
   - File: `game/tests/native_npc_review.gd:113-123`.
   - `_npc_finish` sets/serializes PASS before checking the receipt flush result. If bytes survive a failed flush, the file may say PASS while the process correctly emits an error, omits the success marker and exits `1`.
   - This can confuse someone inspecting only the JSON. It does not bypass this task's acceptance: the explicit contract and inspected drivers require clean exit, exact marker, zero errors and a successful receipt together. The accepted run shows no such failure, so this is non-blocking.
   - Retain combined process/receipt acceptance. If standalone receipt consumption becomes necessary, publish a final receipt only after a successfully checked temporary write, or invalidate the receipt on failure; include a focused write-failure check then. No fault injection was performed here.

### Recommendations

Proceed with the authorized delivery workflow and verify the MAIN-32 resulting main CI separately. Prior ART-17 green CI is not evidence that the new main revision has passed. No runtime fix, package export or broad rerun is justified by this review. Keep MAIN-33's existing failure visible and separate.

### Declined to judge

- MAIN-33's strict rendered-pixel depth/contact acceptance and earlier child geometry failure: explicitly separate work, with unchanged child source and failure preserved.
- Exhaustive action/direction, animation naturalness, human free play, listening and performance acceptance: this task promises natural scripted observations and representative static views, not those broader experiences.
- New package/export acceptance: only an excluded developer fixture changed, and no new production package is part of this repair.
- Pending main CI, merge/push completion and branch/worktree cleanup: executor-owned delivery gates after this review; no Git mutation or CI operation was authorized for this reviewer.

### Assessment

**Ready to merge? Yes.**

The whole-branch change satisfies the repair's source, patrol, reduced-motion, visibility, isolation, inheritance and teardown requirements, supported by final-source native evidence and matching reviewed public images. The one receipt-status observation is non-blocking under the explicit combined acceptance contract; final main CI remains a delivery gate, not a claimed result of this review.

Skipped engine reruns, broad suites, export, disk-failure injection and a new full protected-file rehash; no subagents were dispatched. Remaining risks are the documented receipt-only interpretation trap and the separate unresolved MAIN-33 depth failure.
