# MAIN-30 scoped review

Verdict: no actionable findings in the MAIN-30 test patch.

Reviewed `game/tests/test_travel_book_ui.gd` against HEAD, the supplied diagnosis, final RED/GREEN source snapshots and console/engine logs, and the relevant existing map callback and world-physics paths. This review changed only this report.

## Contract and callback coverage

The position snapshot remains before actual keyboard activation of `MapGate_harbor`. `_activate` still focuses the real button and sends press/release input through `Input.parse_input_event`; the existing threshold/detail assertion confirms the selection callback ran. The final no-teleport assertion uses exact full `Vector3` equality on the authoritative `CharacterBody3D` (`world.player`), without a tolerance, axis omission, reset, or replacement snapshot after activation.

The synthetic fixture writes only `world.camera.position.y`. It does not move the body, clear its velocity, disable physics, change gravity, or restore a callback-induced relocation. The existing grounded wait remains and now asserts that it achieved its precondition. The physics-frame/process-frame boundary permits the normal camera look-at and Sprite grounding path to run. The additional witness requires both an unchanged body and an actually changed Sprite position, so a silent failure to exercise visual adjustment cannot pass that assertion.

Existing production paths support the diagnosis: the map modal blocks movement but keeps world physics enabled; the welcome-map panel's zone selection changes styling and detail text; its setup is not connected to a travel callback. World physics lerps the camera, updates its orientation, and adjusts the Sprite's parent ground anchor using camera-up Y. The Sprite is a presentation child of the player body. `_sync_external_avatar_reposition` responds to body relocation by adjusting camera/motion state; it does not restore the body to the recorded snapshot. The camera-only fixture therefore does not mask a persistent callback-induced body teleport.

This remains an endpoint no-teleport check, as before. It does not claim to detect a transient relocation that returns to the same position before observation. No additional regression in that scope was introduced by changing the measured node.

## Evidence checked

- Current test SHA256 matches both `final-source.gd.txt` and the recorded final test hash: `ad59cd101a193324c4ce65ce89cbb877eab98bdc2e02390fc5c2d84731ba195a`.
- Current `park_world.gd`, `island_map_panel.gd`, and `main.gd` hashes match the supplied final-verification manifest. The reviewed patch changes only the test; no production change is required for this fix.
- RED and GREEN snapshots differ in the old Sprite-versus-new-body snapshot/assertion and the corresponding witness variable names; both contain the same camera perturbation and real frame boundary.
- RED console and engine logs each contain 162 PASS lines, one failed no-teleport assertion and two ERROR lines including its final summary. The body-stability/visual-change witness passes.
- GREEN console and engine logs each contain 164 PASS lines, zero failed assertions and zero ERROR lines. Both runs contain the same 19 warnings.
- Both logs record identical synthetic witness telemetry: body `(0.0, 0.120052, 23.2)` unchanged, Sprite Y `1.173763 -> 1.159348`. This is local fixture evidence, not CI position telemetry.

No engine execution, Git mutation, PM change, production edit, screenshot review, or full-suite/CI rerun was performed in this review. The supplied command record reports isolated save paths and engine exits RED=1/GREEN=0; exit codes were not independently rerun. Separate-main delivery and subsequent CI verification remain the root agent's responsibility.
