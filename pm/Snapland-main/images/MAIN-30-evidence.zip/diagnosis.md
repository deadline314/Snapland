# MAIN-30 map position assertion diagnosis

The assertion measured the display Sprite3D instead of the CharacterBody3D that owns player location. A grounded player does not imply a stationary billboard: camera follow continues settling, and billboard grounding changes its local Y from the camera up vector.

## Causal path

- `game/tests/test_travel_book_ui.gd` originally saved and compared `world.avatar.global_position` across several process frames during keyboard button activation.
- `game/main.gd::_open` sets `world.blocked=true` for a map. It leaves world physics enabled, and `_show_map` does not connect the welcome map panel to a travel callback.
- `game/ui/island_map_panel.gd::_select_zone` changes button styling and destination labels only.
- `game/world/park_world.gd::_physics_process` zeroes horizontal movement when blocked, retains gravity/floor snapping, lerps the camera, calls `look_at`, then `_update_sprite_grounding`.
- `_update_sprite_grounding` computes player billboard anchor Y using `camera.global_basis.y.y`. The Sprite sits below `avatar_ground_anchor`, so its global Y changes when this visual correction changes even while the player body stays at exactly the same full Vector3.
- `is_on_floor()` observes body contact; it cannot guarantee camera convergence. The prior grounded wait therefore did not remove the assertion's presentation dependency.

## Deterministic engine witness

This deliberately applies a **synthetic +1.0 camera Y offset after keyboard selection**, then crosses a real physics/process boundary. It does not move the player, change gravity, disable physics, relax equality, or wait for an arbitrary duration. The witness remains inside the existing real Node test scene; no extra scene or runner registration is required.

Both final RED and GREEN produced identical telemetry:

```text
MAP_POSITION_CAMERA_WITNESS player_before=(0.0, 0.120052, 23.2) player_after=(0.0, 0.120052, 23.2) sprite_before=(0.0, 1.173763, 23.2) sprite_after=(0.0, 1.159348, 23.2) camera_up_y=0.8387034535408 anchor_y=-0.16070425510406
```

The exact body comparison stayed true while Sprite Y changed by approximately -0.014415. The old Sprite comparison rejected that valid visual adjustment.

The supplied CI failure did not print position telemetry. This witness proves the assertion has a deterministic false-positive path matching the source dependency; these local synthetic numbers are not represented as measurements from the CI machine.

## Small fix and scope

The no-teleport contract now snapshots and compares `world.player.global_position` with exact full Vector3 equality. The grounded wait stays, with an explicit check that its precondition was achieved. The camera witness also checks that a Sprite adjustment occurred without body movement.

Only `game/tests/test_travel_book_ui.gd` was changed. Production code, test registration, dependencies, data, config, and exported APIs require no changes. The existing test remains in its existing runtime suite.

## Verification

Engine verified with `--version`: `4.7.2.stable.official.ed1daf0bf`.

Entry: `res://game/tests/test_travel_book_ui.tscn`, a real Node scene in the current project. Every invocation used an absolute independent `SNAPLAND_SAVE_PATH` below this review directory. No project copy or editor was used.

| Run | Engine exit | PASS lines | Failed assertions | ERROR lines | Result |
| --- | --- | --- | --- | --- | --- |
| `final-red` | 1 | 162 | 1 | 2 | Only the old Sprite no-teleport assertion failed, followed by its final failure summary |
| `final-green` | 0 | 164 | 0 | 0 | Full travel/book UI scene passed, including body equality and camera witness |

Both logs have 19 existing warnings: unsupported occlusion material warnings and the album test's deliberately invalid/missing photo fixtures. They were preserved. These engine-driven UI assertions are not human gameplay testing or visual screenshot review.

`git diff --check -- game/tests/test_travel_book_ui.gd`: exit 0.

Commands are in `commands.txt`; exact RED and final source snapshots are `final-red-source.gd.txt` and `final-source.gd.txt`. Complete stdout/stderr and engine logs are `final-{red,green}-{console,engine}.log`. Earlier preliminary RED/GREEN logs are retained as well.

## Source hashes at final verification

| Source | SHA256 |
| --- | --- |
| `game/tests/test_travel_book_ui.gd` | `ad59cd101a193324c4ce65ce89cbb877eab98bdc2e02390fc5c2d84731ba195a` |
| `game/world/park_world.gd` | `56cf0c6391eba5a1e0e36382a6db991e38d83d23619b3baf0e436772569bd2e0` |
| `game/ui/island_map_panel.gd` | `715b473462755fb2588ea276c79b7ed36ad382098982d93d60565e9ebb8e78d9` |
| `game/main.gd` | `fcd0b41a024931a0c655e7c1bf074a1ebc0238615198f8c88991b655b611550d` |
| `final-red-source.gd.txt` | `cad65ca4730ef28766b994cf935cf3a9e4fab04c3d8282d8859652663bbd0b57` |

Not run: unrelated suites, graphical screenshots, or the full CI matrix. Root owns ticket delivery, sparse main integration, and subsequent CI verification.
