# MAIN-31 diagnosis (source read-only)

## Confirmed

The unchanged real NPC dialogue scene completes every original functional assertion locally. Windows baseline initially used the project renderer; exact CI arguments (Dummy audio, gl_compatibility) also completed cleanly. The CI job log contains only the strict error summary (three resources), not verbose resource identities or the scene stdout marker; its error alone does not prove dialogue behavior failed.

In the explicit runtime-only private stage, observational WeakRefs show two stopped playback owners remain alive after shutdown plus the original fixed 150 ms timer: MusicPlayer0 AudioStreamPlaybackOggVorbis (plaza.ogg), and PlazaAmbience AudioStreamPlaybackWAV (plaza_ambience.wav). Streams/playbacks are observed by WeakRef only, never kept alive by strong diagnostic references. On clean original-lifecycle runs they become invalid after Main owner deletion and two process frames. The pre-owner timer therefore cannot establish the required release condition.

Controlled private A/B/A/B, all using the same target scene and every original functional assertion: remove the pre-owner timer in both variants; A retains the original owner-free plus two-frame exit; B alone adds a bounded actual playback WeakRef release condition after owner free. A1 clean; B1 clean after waiting (both playback+stream pairs were alive at the former exit); A2 exits 0 but logs the actual three-resource error; B2 clean after waiting (same pairs alive at the former exit).

A2 exact retained identities, confirmed by verbose shutdown:

- res://assets/audio/cc0/plaza.ogg::OggPacketSequence_k7vfj (OggPacketSequence)
- res://assets/audio/cc0/plaza.ogg (AudioStreamOggVorbis)
- res://assets/audio/plaza_ambience.wav (AudioStreamWAV)

Native leaked instances: AudioStreamPlaybackOggVorbis, OggPacketSequencePlayback, OggPacketSequence, AudioStreamOggVorbis, AudioStreamPlaybackWAV, AudioStreamWAV. The playback objects each have reference count 1. This is audio backend lifetime, not a retained dialogue panel or NPC atlas. This experiment isolates the same three-resource symptom under a controlled shorter pre-owner lifecycle; the subsequent Linux original-lifecycle reproduction below also retains the original 150 ms timing.

The existing result_error rejects causal-03-A despite exit0 and the complete original functional marker. It accepts A1/B1/B2; no allowlist, assertion relaxation, or error filtering was introduced.

## Proposed smallest fix (not implemented)

Only game/tests/test_npc_dialogue_hold.gd::_finish needs to change, using the existing MAIN-28 house pattern: snapshot WeakRefs of active AudioStreamPlayer playbacks before shutdown; shut down; delete Main; preserve existing two process frames; then wait while any playback WeakRef is valid. A two-second monotonic deadline must _check(false) and quit nonzero if release never completes. Remove the fixed 150 ms timer. Keep production AudioDirector/Main/dialogue code and all original feature assertions unchanged. No new shared helper/module is justified for this ticket.

Potential additional contract guard for root decision: set main.quitting=true before shutdown, as MAIN-28 already does, so late current-world callbacks cannot restart audio during teardown. This is independently valid ownership protection; it is not the proven cause of the three-resource retention and must not be described as such.

## Provenance and limits

Source project untouched throughout; private instrumentation only inside the actual test scene in D:/Snapland-QA/MAIN31-scoped-73d0b4e61a/project. The scene is launched through run_validated_godot, not through a .review snapshot script. Every launch uses a unique absolute SNAPLAND_SAVE_PATH. scoped-private-stage.json preserves copied source SHA256 values and the explicit SG42 untracked runtime allowlist. Godot Windows version: 4.7.2.stable.official.ed1daf0bf.

The first private stage (MAIN31-666173a80a) initially omitted untracked SG42 preloads, then copied unrelated untracked import/UID metadata; it is discarded as causal evidence. The fresh scoped stage was rebuilt with only tracked runtime plus exactly the approved SG42 source/PNG extras, and imported with zero engine errors. No shared files, Git, tickets, accepted SG42 release, or player profiles were changed.

Official CI Linux editor artifact downloaded to owned D directory: Godot_v4.7.2-stable_linux.x86_64.zip SHA256 cadd3204e728a35d3f13adb7fd0d7902636b79f6b95c40c265eb73b6c35329e4. Version validated as 4.7.2.stable.official.ed1daf0bf through run_validated_godot inside WSL Python using POSIX project/save paths. Linux untouched-lifecycle normal/verbose baselines completed cleanly. linux-original-endverbose-01 then reproduced the exact original fixed150ms + owner-free + two-frame lifecycle (the sole private instrumentation enables Engine.print_to_stdout at _finish). It exits0 with the complete original functional marker but six native instances / exactly the same three resource identities listed above. This closes the original-timing attribution gap locally on the CI operating-system family; the historical CI log itself still contains only the count.

No hardware listening, GPU rendering, full suite, or human gameplay has been claimed. Original-lifecycle Linux timing is now reproduced locally; the hosted historical CI process itself was not rerun.

## Linux original-timer causal comparison

`linux-original-endverbose-01` is A1 (original 150 ms retained), followed by `linux-timed-B-01`, `linux-timed-A-02`, `linux-timed-B-02`, all same scoped project, Linux engine, exact common arguments, --verbose --quiet startup, and Engine.print_to_stdout restored only at _finish. B keeps the original 150 ms as well; its sole lifecycle addition captures active playback WeakRefs before shutdown and waits for invalidation after owner free with a 2000 ms monotonic deadline. A1 has actual three-resource retention; B1 clean; A2 clean; B2 clean. Every run retains/completes the original feature assertions. The intermittent A and condition-based B results align with Windows A/B and direct ownership observations.

Private held-playback fault injection (`linux-deadline-held-playback`) keeps one real captured playback strongly alive after owner free. B reaches its monotonic deadline after 2004 ms, records the explicit release failure, emits no success marker, and exits1; no resource-still-in-use error remains after the injected reference is released. The strict completion/error contract therefore fails visibly instead of hanging or silently passing. This is deliberate fault injection, not normal runtime behavior.
