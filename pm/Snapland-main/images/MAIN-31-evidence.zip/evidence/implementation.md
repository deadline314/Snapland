# MAIN-31 implementation verification

## Owned changes

Seven files only: two-function test-only RefCounted helper, actual-playback SceneTree selftest, and five specified existing cleanup callers. No production audio, UI, rewards, runner/contracts, PM, Git, or accepted SG42 package edits. Helper capture snapshots active AudioStreamPlayer playback WeakRefs before shutdown; wait polls only those WeakRefs after caller-owned shutdown/free/frame barrier, with a 2000 ms monotonic deadline and false return on timeout. No strong reference crosses its await. No class_name/options/framework.

NPC removes its pre-owner 150 ms timer, captures before shutdown and retains two-frame barrier; quitting=true follows other Main cleanup but is not claimed causal. MAIN28 late current-world callback assertion remains between shutdown and owner deletion; all completion markers and original feature assertions remain. Four old capture/poll blocks are replaced with the same helper call. The selftest additionally checks same-frame completion for empty/dead references, preventing an unconditional wait from masquerading as immediate release. Final Windows selftest rerun after these assertions passes at 2001 ms (implementation-selftest-windows-final.*).

## Test-first and mutation evidence

- implementation-red-no-helper: new SceneTree entry run before helper existed; exit1, explicit missing-preload parse failure, no success marker. This is the dependency RED, not a claim of executed feature assertions.
- implementation-mutation-immediate-true: private helper mutation returns true immediately. Real-playback selftest rejects it with exit1 and failed nonretention/held-reference/deadline assertions; no success marker. Private helper was restored in finally.
- implementation-selftest-windows: true helper passes real looping WAV playback, ignores inactive/non-audio children, empty/dead refs, owner deletion, weak nonretention, held-reference false at 2001 ms, recovery after clearing strong injection; exit0 with exact registry marker.

## Windows scoped stage

D:/Snapland-QA/MAIN31-implementation-506d0accd2/project, created by prepare_runtime_stage from tracked runtime plus the exact explicit test/dependency list in implementation-stage.json. No broad untracked copy. Clean import exit0, zero engine errors. Every run uses tools.godot_entrypoints.run_validated_godot, validated Godot4.7.2.stable.official.ed1daf0bf, Dummy audio/gl_compatibility and an independent absolute SNAPLAND_SAVE_PATH on D.

| Entry | Seconds | Exit | Engine/marker contract |
|---|---:|---:|---|
| audio playback release tests | 2.59 | 0 | PASS |
| NPC dialogue hold tests | 7.50 | 0 | PASS |
| photo retake Main tests | 32.30 | 0 | PASS |
| sugar Main tests | 10.00 | 0 | PASS |
| cookie Main tests | 11.18 | 0 | PASS |

Exact commands, absolute saves, timing and outcomes: implementation-windows-results.json. Raw stdout/stderr: implementation-windows-{1..5}.stdout.log / .stderr.log. The full photo-retake run includes real save-failure child and existing late callback protection; no allowlist or old assertion was changed.

## Linux helper and NPC checks

Engine calls run through tools.godot_entrypoints.run_validated_godot inside WSL Python, with POSIX D project/profile paths and official Godot4.7.2.stable.official.ed1daf0bf. Artifact provenance is in diagnosis.md. Scoped Linux import exits0 with zero engine errors. Exact commands, absolute saves, source-variant SHA256s and outcomes are preserved in implementation-linux-results.json.

| Entry | Seconds | Exit | Engine/marker or fault contract |
|---|---:|---:|---|
| implementation-linux-selftest | 3.32 | 0 | PASS |
| implementation-linux-npc-normal | 18.78 | 0 | PASS |
| implementation-linux-npc-verbose | 18.69 | 0 | PASS |
| implementation-linux-npc-endverbose | 18.85 | 0 | PASS |
| implementation-linux-original-timer-helper | 18.68 | 0 | PASS |
| implementation-linux-npc-held-fault | 20.83 | 1 | PASS (deliberate held-reference fault) |

The final selftest source (including same-frame empty/dead checks) additionally passes Linux at2001ms: implementation-selftest-linux-final.stdout.log/stderr.log/command.json. Windows final counterpart also passes at2001ms. Final mutation using that same frozen selftest rejects immediate-true wait (exit1, no success marker); exact mutated helper/selftest source snapshots, SHA256s and command are saved as implementation-mutation-final-*.

The original150ms-helper contrast intentionally keeps the old timer and omits the new quitting guard: capture plus helper condition alone is green, so the guard/timer removal is not confused with the demonstrated release cause. Earlier Linux inline B and the new helper snapshot only TWO active native playback WeakRefs. Four alive observation IDs in the Windows diagnosis include their stream metadata, not four waited playbacks. No cached streams are polled by this API.

The helper-backed NPC fault preserves all original dialogue assertions, then deliberately holds one actual native playback strongly. It reaches the release deadline at2004ms; the existing caller failure path logs release failure, suppresses its success marker and exits1. Clearing the injected reference and waiting through the helper before diagnostic exit leaves no resource-retention error. This fault remains a failure under the strict suite contract; it is not an error allowlist.

## Fifth caller: coordinated root GPU case

Root executed native_cookie_mold_main.tscn, retake mode at1280x720, through its inherited native_sugar_bridge_main.finish cleanup. Root evidence in native-cookie-retake/{source-hashes.json,native.log,result.json,report.json} records exit0, no engine ERROR, no fixture failures, six captures, actual selected devil shutter and original-image pixel equality. It exercises the changed fifth cleanup caller and the existing nativeCookie dependency; no additional GPU run was needed for unchanged views. Its helper and native parent hashes match the frozen implementation hashes.

## Final source freeze

All seven shared source SHA256s are recorded in implementation-source-hashes.json. Final audit caught newline-only changes caused by private diagnostic write_text restoration in helper/NPC, verified normalized contents identical, and restored those private files by exact byte copy. Every private/shared source now matches the manifest exactly. Diagnostic variant text/logs remain preserved; no shared source changed during diagnostics. git diff --check for the seven owned paths is clean.

No production audio, game behavior, runner/contracts, PM, Git, or accepted SG42 package was edited by this worker. All four affected headless caller suites, real-playback helper selftest, Linux release contrasts/fault propagation, and the root-coordinated inherited native caller are verified. Seven sources are frozen for fresh root-led spec/quality review; root owns harness/contracts/QA dependency/PM/Git delivery.

These are automated regression, GPU/capture and lifecycle checks. No human gameplay, hardware listening, or full repository suite is claimed.
