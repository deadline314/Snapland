# MAIN-31 fresh source review

Reviewed 2026-11-18 against the working files supplied for `codex/dialogue-release-20261118` (parent-reported HEAD `c094e61`; no Git commands executed).

## Verdict

Final scoped review: **0 open P1/P2 findings** in the seven Task 1 files or the inspected runner/contract integration. Source review is approved. The previously pending Linux final-helper, native inherited-cleanup and private NPC QA package evidence has now been inspected and closes those review boundaries; no new findings.

## Scope and evidence

- Read `AGENTS.md`, the repository `pm-ticket` instructions, `design/runtime/test-audio-playback-release.md`, the implementation plan, diagnosis, implementation notes, Windows result manifest, and relevant raw selftest/mutation output.
- Read `audio_playback_release.gd`, `test_audio_playback_release.gd`, and the five specified callers. Final follow-up rehashed all seven: each matches the final `implementation-source-hashes.json` (helper `37a55699…`, selftest `c0a1febc…`). The selftest's added empty-owner capture and same-frame empty/dead completion assertions were inspected; the helper and five callers retain the previously reviewed hashes.
- Inspected `AudioDirector` construction/shutdown to confirm the captured players are its direct children, and `native_cookie_mold_main.gd` to confirm it inherits the reviewed native cleanup.
- Inspected the new runner registration, exact-marker selection and companion test in `tools/run_game_tests.py` / `tests/test_runtime_result_contract.py`. `runner-green.log` records 51 passing Python tests. A source-only AST count confirms 23 result-contract, 15 entrypoint and 13 shard tests, totaling 51. They were not rerun by this reviewer.
- Compared current NPC source with `original-test-source.txt`: changes are limited to helper preload and the intended cleanup replacement; original functional assertions and completion marker remain intact.

## Review conclusions

`capture()` obtains WeakRefs before shutdown and does not retain a playback between calls. `wait_for_release()` evaluates each temporary strong reference entirely inside the synchronous `any()` predicate; no playback object is stored across `await`. It has a 2000 ms monotonic deadline, returns false while a held playback survives past that deadline, and returns true for an empty/already-dead collection.

All five callers capture before shutdown, queue/free their owner, preserve their existing frame barrier, and then await actual playback invalidation. False reaches each caller's existing failure collection and nonzero exit, suppressing its success marker. Photo-retake's MAIN-28 late-world callback assertion remains after shutdown and before owner deletion. Native Cookie inherits the checked parent path.

The selftest uses an actual looping WAV, filters inactive/non-audio children, checks owner deletion and nonretention, explicitly checks same-frame completion for empty/dead references, holds a real playback strongly for the negative case, clears the injection, and verifies recovery before exit. The supplied final immediate-true mutation uses the frozen selftest, fails the intended assertions, exits 1 and emits no success marker. Its 5000 ms upper assertion has substantial tolerance over the 2000 ms deadline; supplied results do not demonstrate a material flakiness defect, so none is reported.

The new runner entry requires its exact stdout completion line. Missing/wrong/suffixed/stderr-only completion, nonzero exit, and engine/script errors on either stream are rejected by the inspected contract and companion cases. No new diagnostic allowlist or production audio behavior change was found in this scope.

The causal evidence distinguishes the historical CI count from the actual retained Ogg/WAV identities observed locally. The NPC quitting guard is not treated as the established cause. The diagnostic document's early single-file proposal is superseded by the later accepted design/plan for the two-function helper.

## Final evidence follow-up

- Final Windows and Linux selftest stdout records the exact completion marker and a 2001 ms held-reference deadline. Linux final command metadata binds the selftest to `c0a1febc…`; final mutation metadata binds the same test to the deliberately broken helper and exit 1.
- `implementation-linux-results.json` records clean NPC normal, verbose, endverbose and original-150ms-plus-helper-only runs. The latter omits the new quitting guard, keeping the release-condition causal comparison separate from that guard. The helper-backed held-playback fault records 2004 ms, exit 1, no NPC suite completion, and release failure; the cleared injection leaves no resource-retention diagnostic.
- `native-cookie-retake/{source-hashes.json,result.json,report.json,native.log}` confirms the frozen helper and native parent, exit 0, no engine errors, no fixture failures, six captures and retake mode at 1280x720. This exercises the changed inherited native cleanup; it is automated GPU evidence, not human gameplay/listening.
- `package-location.json` locates the root-created private NPC QA artifact. Its `build.json` records successful import/export and exactly three test fixture dependencies: NPC script, NPC scene and the helper. All three recorded hashes match current source. The packaged normal/verbose `result.json` files both record exit 0 and `strict_error: null`. The explicit helper packaging boundary is closed.

## Limits

No engine, editor, GPU, Git, PM, or production source operations were performed by this reviewer. Only this report was written. Verification here consists of source/hash inspection and review of existing execution evidence, not rerunning those checks. No claim is made that the whole branch's uninspected files or full repository suite passed, or that human gameplay/hardware listening occurred.
