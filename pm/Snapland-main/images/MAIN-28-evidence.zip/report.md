# MAIN-28: retake fixture waits for actual audio playback release

Status: COMPLETE. Causal A/B/A/B established; minimal fixture fix implemented; four consecutive full retake runs pass across original/verbose modes and isolated profiles.

## Confirmed cause

The exact five resources / ten objects are audio resources retained by AudioServer playback ownership after the AudioStreamPlayer nodes have stopped. They are **not GDScript resources**:

- `res://assets/audio/plaza_ambience.wav`: AudioStreamWAV + AudioStreamPlaybackWAV.
- `res://assets/audio/cc0/harbor.ogg`: AudioStreamOggVorbis + OggPacketSequence + AudioStreamPlaybackOggVorbis + OggPacketSequencePlayback.
- `res://assets/audio/cc0/game.ogg`: the same four Ogg objects.

The unchanged full retake suite reproduced the exact failure in `original-0.log` (exit 0, exact existing PASS, 32.29s). The exact resource paths/classes/instance IDs were then obtained in `quiet-identities-1.log`: launch with `--verbose --quiet` to keep startup output quiet, set `Engine.print_to_stdout=true` only immediately before final PASS/quit. It reproduced the same five resources / ten objects, exit 0, exact PASS, 32.29s. This logging variant is diagnostic only; the shipped fix uses the original command.

Weak-reference observations captured all three active native playbacks before shutdown. Both `audio-observe-0.log` and `audio-observe-1.log` show all three still alive **after the old 150ms timer**, despite AudioDirector already clearing every player stream. In those clean samples the following Main-free/three-frame interval happened to release them. An elapsed timer and a fixed frame count do not establish the backend release boundary.

Upstream source corroborates asynchronous stop ownership (`AudioStreamPlayerInternal::stop_basic` requests server stop and clears player references; AudioServer handles fade/deletion and deferred list cleanup). These sources are corroboration, not attribution of an unverified upstream issue:

- https://github.com/godotengine/godot/blob/master/scene/audio/audio_stream_player_internal.cpp
- https://github.com/godotengine/godot/blob/master/servers/audio/audio_server.cpp

## Controlled causal A/B/A/B

A tiny **private** Node scene uses the actual unchanged AudioDirector, plays actual game and harbor contexts (including ambience), captures three playback weak references, calls shutdown, frees the AudioDirector owner, and gives the original three process frames. The sole A/B variable is whether it then waits for those actual weak references to clear, with a 2-second failure bound. Same private project, scene entry, flags, save profile, resources and code across each A/B/A/B sequence.

Plain original flags (`run_audio_focused.py plain`):

| Run | Condition drain | Result |
|---|---|---|
| A 0 | off | exit 1, pending=true, explicit release assertion, exact 5-resource / 10-object diagnostics |
| B 1 | on | exit 0, pending=false, clean, actual drain 65ms |
| A 2 | off | exit 1, pending=true, explicit release assertion, exact 5-resource / 10-object diagnostics |
| B 3 | on | exit 0, pending=false, clean, actual drain 21ms |

Evidence: `audio-focused-plain-0-drain0.log` through `audio-focused-plain-3-drain1.log`.

The diagnostic quiet-startup verbose sequence independently produced A fail / B clean / A fail / B clean; B took 104ms and 90ms. First A shows the same exact named resource cluster. Evidence: `audio-focused-0-drain0.log` through `audio-focused-3-drain1.log`.

Exact focused marker: `PASS: audio backend released stopped playbacks`. Exact red assertion: `FAIL: audio backend released stopped playbacks`. The focused scene exists only in the private project's real `game/tests/`; `.review/audio_release_probe.gd.txt` is a non-runnable evidence copy.

## Implemented change

Only `game/tests/test_photo_retake_main.gd` changes. Before the existing AudioDirector shutdown, capture weak references to active native playbacks. Preserve the MAIN-26 quitting guard, real late-area callback assertion, Main queue_free and three process frames. Replace the fixed 150ms timer with a loop that awaits process frames **only while those playbacks actually remain alive**, and fails explicitly if they are not released within 2 seconds. This is a checked ownership boundary, not a longer sleep, retry, error allowlist or verbosity workaround.

All original retake, natural practice, formal participation, cancellation, save failure, PNG preservation, provenance and duplicate reward assertions remain byte-for-byte outside teardown. Exact existing full marker remains:

`PASS: Main selected retakes, actual attempts, truthful awards and safe PNG replacement`

No production Main/AudioDirector, player save, engine setting, PASS registry or strict `result_error` policy changes.

## Full-suite verification

All launches use `run_validated_godot`, Godot 4.7.2, an absolute isolated SNAPLAND_SAVE_PATH and the real `res://game/tests/test_photo_retake_main.tscn` entry. No workspace editor/import was run.

| Log | Mode/profile | Result |
|---|---|---|
| `fixed-original-0.log` | original nonverbose / original controlled same-profile | exit 0, exact PASS, no ERROR/leaks, 32.34s |
| `fixed-verbose-0.log` | verbose / new profile-b | exit 0, exact PASS, no ERROR/leaks, 32.72s |
| `fixed-original-1.log` | original nonverbose / new profile-c | exit 0, exact PASS, no ERROR/leaks, 32.34s |
| `fixed-verbose-1.log` | verbose / new profile-d | exit 0, exact PASS, no ERROR/leaks, 32.52s |

The unchanged strict runner `result_error('photo retake Main tests', result)` rejects `original-0.log` for its five-resource error and accepts all four fixed full-run logs (`None`). No suppression was added.

Exact full command (verbose runs add only `--verbose`):

```text
C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --path C:/Users/stanl/AppData/Local/Temp/snapland-retake-lifetime-ifyvhwax --audio-driver Dummy --rendering-method gl_compatibility res://game/tests/test_photo_retake_main.tscn
```

Launch wrappers: `run_probe.py fixed-original 0`, `run_probe.py fixed-verbose 0 profile-b`, `run_probe.py fixed-original 1 profile-c`, `run_probe.py fixed-verbose 1 profile-d`. `run_audio_focused.py plain` reruns the causal sequence. Every wrapper uses the validated launcher and an absolute isolated save path. The private fixture is restored in `finally`.

## Evidence/source identity and limits

`source-manifest.json` records engine/project/entry/save paths, all 453 private script hashes, original/fixed fixture hashes, and the baseline Git commit. The original fixture's raw CRLF SHA256 `702bbe79e32571ffcf808284d44ee02468a0e4d516c1a11c30e843416c2ebbae` exactly matches the prior investigation manifest. Original/fixed fixture text evidence is retained separately.

The prior baseline attribution remains valid: origin/main 5655318 reproduces this same batch, so this was not introduced by MAIN-26. New diagnosis establishes actual audio ownership. Original restoration samples 1/2, defer-only and owner-free were also clean, so those variants never established a script ownership cause and none was shipped. Two unavailable OS setter probes were rejected as invalid API experiments; the actual Engine.print_to_stdout API was confirmed in a separate bounded private SceneTree query.

No claim of interactive game play or native hardware audio acceptance is made from these headless lifecycle checks. Production shutdown was not changed; separate production hardening, if desired, requires its own observed reproduction and caller review. Root owns final current-workspace integration validation, ticket evidence and Git delivery.
