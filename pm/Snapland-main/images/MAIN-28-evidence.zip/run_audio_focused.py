from pathlib import Path
import os,sys,json
sys.path.insert(0,str(Path.cwd()))
from tools.godot_entrypoints import run_validated_godot
stage=Path(r'C:/Users/stanl/AppData/Local/Temp/snapland-retake-lifetime-ifyvhwax');out=Path('.review/retake-main28').resolve()
cmd=[r'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--verbose','--quiet','--headless','--path',str(stage),'--audio-driver','Dummy','--rendering-method','gl_compatibility','res://game/tests/audio_release_probe.tscn']
mode=sys.argv[1] if len(sys.argv)>1 else 'identities'
if mode=='plain': cmd.remove('--verbose');cmd.remove('--quiet')
for index,drain in enumerate(['0','1','0','1']):
 env=os.environ.copy();env['SNAPLAND_SAVE_PATH']=str(out/'audio-focused/progress.json');env['PROBE_DRAIN']=drain
 r=run_validated_godot(stage,cmd,env=env,timeout=15);data=r.stdout+'\n'+r.stderr
 (out/f'audio-focused-{mode}-{index}-drain{drain}.log').write_text(data,encoding='utf-8')
 print(json.dumps({'index':index,'drain':drain,'exit':r.returncode,'lines':[s for s in data.splitlines() if 'AUDIO_RELEASE' in s or 'Resource still in use:' in s or 'ERROR:' in s or 'leaked' in s]},ensure_ascii=False),flush=True)
