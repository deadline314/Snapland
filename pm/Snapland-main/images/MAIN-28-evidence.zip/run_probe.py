from pathlib import Path
import os, sys, time, hashlib, json
sys.path.insert(0,str(Path.cwd()))
from tools.godot_entrypoints import run_validated_godot
stage=Path(r'C:/Users/stanl/AppData/Local/Temp/snapland-retake-lifetime-ifyvhwax')
out=Path('.review/retake-main28').resolve()
fixture=stage/'game/tests/test_photo_retake_main.gd'
original=Path('game/tests/test_photo_retake_main.gd').read_bytes()
mode=sys.argv[1]; run=sys.argv[2]
text=original.decode('utf-8')
if mode in ['audio-observe','audio-drain','audio-state','audio-condition']:
 text=text.replace('func _finish() -> void:\r\n', 'func _finish() -> void:\r\n')
 text=text.replace('\tmain.quitting=true\r\n\tmain.audio.shutdown()', '\tmain.quitting=true\r\n\tvar draining: Array[WeakRef]=[]\r\n\tfor player in main.audio.get_children():\r\n\t\tif player is AudioStreamPlayer and player.has_stream_playback(): draining.append(weakref(player.get_stream_playback()))\r\n\tprint("AUDIO_CAPTURED_PLAYBACKS ",draining.size())\r\n\tmain.audio.shutdown()')
 text=text.replace('\tmain.queue_free()\r\n\tawait _frames()', '\tprint("AUDIO_AFTER_150MS ",_pending_playbacks(draining))\r\n\tmain.queue_free()\r\n\tawait _frames()\r\n\tprint("AUDIO_AFTER_MAIN_FREE ",_pending_playbacks(draining))')
 text+='\nfunc _pending_playbacks(refs: Array[WeakRef]) -> Array:\n\tvar pending: Array=[]\n\tfor item in refs:\n\t\tif item.get_ref()!=null: pending.append(str(item.get_ref().get_class()))\n\treturn pending\n'
 if mode in ['audio-drain','audio-condition']:
  text=text.replace('\tprint("AUDIO_AFTER_MAIN_FREE ",_pending_playbacks(draining))', '\tvar started:=Time.get_ticks_msec()\n\twhile not _pending_playbacks(draining).is_empty() and Time.get_ticks_msec()-started<2000:\n\t\tawait get_tree().process_frame\n\tprint("AUDIO_DRAIN elapsed_ms=",Time.get_ticks_msec()-started," pending=",_pending_playbacks(draining))\n\tcheck(_pending_playbacks(draining).is_empty(),"audio backend released stopped playbacks")')
if mode in ['audio-state','audio-condition']:
 text=text.replace('\tprint("AUDIO_CAPTURED_PLAYBACKS ",draining.size())\r\n','')
 text=text.replace('\tprint("AUDIO_AFTER_150MS ",_pending_playbacks(draining))\r\n','')
 text=text.replace('\tprint("AUDIO_AFTER_MAIN_FREE ",_pending_playbacks(draining))','\tEngine.print_to_stdout=true\n\tprint("AUDIO_BEFORE_QUIT ",_pending_playbacks(draining))')
if mode=='audio-condition':
 text=text.replace('\tprint("AUDIO_DRAIN elapsed_ms=",Time.get_ticks_msec()-started," pending=",_pending_playbacks(draining))', '\tEngine.print_to_stdout=true\n\tprint("AUDIO_DRAIN elapsed_ms=",Time.get_ticks_msec()-started," pending=",_pending_playbacks(draining))')
if mode=='external-observed':
 start=text.index('class ObservedMain extends '); end=text.index('func _ready()')
 inner=text[start:end].splitlines()[1:]
 helper='extends "res://game/main.gd"\n'+''.join(line[1:]+'\n' if line.startswith('\t') else line+'\n' for line in inner)
 (stage/'game/tests/retake_observed_main_probe.gd').write_text(helper,encoding='utf-8')
 text=text[:start]+'const ObservedMain=preload("res://game/tests/retake_observed_main_probe.gd")\n\n'+text[end:]
if mode=='quiet-identities':
 text=text.replace('\tif failures.is_empty(): print("PASS:', '\tEngine.print_to_stdout=true\n\tif failures.is_empty(): print("PASS:')
if mode=='defer-only':
 text=text.replace('\tget_tree().quit(0 if failures.is_empty() else 1)', '\tget_tree().process_frame.connect(get_tree().quit.bind(0 if failures.is_empty() else 1),CONNECT_ONE_SHOT)')
if mode=='owner-free':
 text=text.replace('\tget_tree().quit(0 if failures.is_empty() else 1)', '\tget_tree().process_frame.connect(get_tree().quit.bind(0 if failures.is_empty() else 1),CONNECT_ONE_SHOT)\n\tqueue_free()')
if mode=='late-verbose':
 text=text.replace('\tget_tree().quit(0 if failures.is_empty() else 1)','\tOS.set_verbose_stdout(true)\n\tget_tree().quit(0 if failures.is_empty() else 1)')
fixture.write_text(text,encoding='utf-8',newline='\n')
env=os.environ.copy(); env['SNAPLAND_SAVE_PATH']=str(out/(sys.argv[3] if len(sys.argv)>3 else 'same-profile')/'progress.json')
command=[r'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--headless','--path',str(stage),'--audio-driver','Dummy','--rendering-method','gl_compatibility','res://game/tests/test_photo_retake_main.tscn']
if mode=='fixed-verbose': command.insert(1,'--verbose')
if mode in ['quiet-identities','audio-state']: command[1:1]=['--verbose','--quiet']
try:
 start=time.monotonic(); result=run_validated_godot(stage,command,env=env,timeout=90)
 data=result.stdout+'\n'+result.stderr
 (out/f'{mode}-{run}.log').write_text(data,encoding='utf-8')
 print(json.dumps({'mode':mode,'run':run,'exit':result.returncode,'seconds':round(time.monotonic()-start,2),'pass': 'PASS: Main selected retakes, actual attempts, truthful awards and safe PNG replacement' in data,'errors':[line for line in data.splitlines() if 'ERROR:' in line or 'leaked' in line or 'Leaked instance' in line or 'Resource still in use' in line]},ensure_ascii=False),flush=True)
finally:
 fixture.write_bytes(original)
