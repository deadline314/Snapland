from pathlib import Path
import json,os,sys,time
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from tools.run_game_tests import build_checks,result_error
from tools.godot_entrypoints import run_validated_godot
out=ROOT/'.review/candy-main26-20261117'/ (sys.argv[1] if len(sys.argv)>1 else 'affected-final')
assert not out.exists();out.mkdir()
labels={'photo retake progress tests','participation result tests','retake panel tests','photo retake Main tests','retake native fixture tests','region progress tests','harbor world tests','candy world tests','region travel tests','delivered game catalog tests','harbor game progress tests','harbor collection tests','core runtime tests','travel collection UI tests'}
checks=[(label,cmd) for label,cmd in build_checks(r'C:\Tools\Godot\Godot_v4.7.2-stable_win64_console.exe') if label in labels]
assert len(checks)==len(labels)
checks=checks[int(sys.argv[2]):] if len(sys.argv)>2 else checks
checks=[row for row in checks if row[0]==sys.argv[3]] if len(sys.argv)>3 else checks
report=[]
for index,(label,cmd) in enumerate(checks):
    directory=out/str(index);directory.mkdir()
    env=dict(os.environ,SNAPLAND_SAVE_PATH=str(directory/'progress.json'))
    started=time.monotonic()
    result=run_validated_godot(ROOT,cmd,env=env,timeout=90)
    (directory/'runtime.log').write_text(result.stdout+result.stderr,encoding='utf-8')
    error=result_error(label,result,env['SNAPLAND_SAVE_PATH'])
    report.append({'label':label,'exit':result.returncode,'error':error,'seconds':round(time.monotonic()-started,2)})
    (out/'report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    assert error is None,(label,error)
    print('PASS',label,report[-1]['seconds'],flush=True)
print('PASS affected suites',len(report),flush=True)
