from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from tools.godot_entrypoints import run_validated_godot
base=ROOT/'.review/candy-main26-20261117/package-final'
stage=base/'project';release=base/'release'
relative='game/tests/native_candy_travel_review.gd'
shutil.copy2(ROOT/relative,stage/relative)
exe=release/'CandyTravelQAProvenance.exe';assert not exe.exists()
env=dict(os.environ,SNAPLAND_SAVE_PATH=str(base/'provenance-build-profile/progress.json'))
result=run_validated_godot(stage,[r'C:\Tools\Godot\Godot_v4.7.2-stable_win64_console.exe','--headless','--path',str(stage),'--editor','--export-release','Windows Desktop',str(exe),'--quit'],env=env,timeout=300)
log=result.stdout+result.stderr
(base/'provenance-export.log').write_text(log,encoding='utf-8')
assert result.returncode==0 and 'ERROR:' not in log
build=json.loads((base/'layout-build.json').read_text(encoding='utf-8'))
build['source_sha256'][relative]=hashlib.sha256((ROOT/relative).read_bytes()).hexdigest()
build['binary']={'file':exe.name,'bytes':exe.stat().st_size,'sha256':hashlib.sha256(exe.read_bytes()).hexdigest()}
(base/'provenance-build.json').write_text(json.dumps(build,indent=2),encoding='utf-8')
for mode in ['writer','restart']:
    out=base/('provenance-'+mode);assert not out.exists();out.mkdir()
    env.update(SNAPLAND_SAVE_PATH=str(base/'provenance-profile/progress.json'),SNAPLAND_CANDY_REVIEW_OUTPUT=str(out),SNAPLAND_CANDY_REVIEW_SIZE='1280x720',SNAPLAND_CANDY_REVIEW_MODE=mode,SNAPLAND_CANDY_REVIEW_TEXT_SCALE='1',SNAPLAND_CANDY_REVIEW_REDUCED_MOTION='0')
    result=run_validated_godot(stage,[str(exe),'--log-file',str(out/'engine.log'),'--rendering-method','gl_compatibility','--audio-driver','Dummy','--fixed-fps','60','--quit-after','5000'],env=env,timeout=180,release_directory=release)
    log=result.stdout+result.stderr+'\n'+(out/'engine.log').read_text(encoding='utf-8')
    (out/'native.log').write_text(log,encoding='utf-8')
    (out/'result.json').write_text(json.dumps({'exit':result.returncode}),encoding='utf-8')
    report=json.loads((out/'report.json').read_text(encoding='utf-8'))
    assert result.returncode==0 and 'ERROR:' not in log and 'PASS: native Main candy travel' in log and not report['failures'],mode
    assert report['scripted_profile_setup']==(mode=='writer')
    print('PASS standalone provenance candy',mode,len(report['captures']),flush=True)
