from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
ROOT=Path.cwd()
sys.path.insert(0,str(ROOT))
from tools.build_desktop_release import prepare_runtime_stage
from tools.godot_entrypoints import run_validated_godot
base=ROOT/'.review/candy-main26-20261117/package-final'
assert not base.exists()
base.mkdir()
stage=base/'project';stage.mkdir()
tracked=subprocess.check_output(['git','ls-files','-z'],text=True,encoding='utf-8').split('\0')
hashes=prepare_runtime_stage(ROOT,stage,tracked)
for name in ['native_candy_travel_review.gd','native_candy_travel_review.tscn','native_region_travel_review.gd']:
    relative='game/tests/'+name
    target=stage/relative;target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(ROOT/relative,target)
    hashes[relative]=hashlib.sha256((ROOT/relative).read_bytes()).hexdigest()
project=stage/'project.godot'
project.write_text(project.read_text().replace('res://game/main.tscn','res://game/tests/native_candy_travel_review.tscn'),encoding='utf-8')
preset=stage/'export_presets.cfg'
preset.write_text(preset.read_text().replace('game/tests/*,',''),encoding='utf-8')
release=base/'release';release.mkdir()
exe=release/'CandyTravelQA.exe'
engine=r'C:\Tools\Godot\Godot_v4.7.2-stable_win64_console.exe'
env=dict(os.environ,SNAPLAND_SAVE_PATH=str(base/'build-profile/progress.json'))
steps=[]
for name,args in [('import',['--editor','--import','--quit']),('export',['--editor','--export-release','Windows Desktop',str(exe),'--quit'])]:
    result=run_validated_godot(stage,[engine,'--headless','--path',str(stage),*args],env=env,timeout=300)
    log=result.stdout+result.stderr
    (base/(name+'.log')).write_text(log,encoding='utf-8')
    assert result.returncode==0 and 'ERROR:' not in log, name
    steps.append({'step':name,'exit':result.returncode})
assert exe.is_file() and exe.stat().st_size>100_000_000
(base/'build.json').write_text(json.dumps({'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_sha256':hashes,'steps':steps,'binary':{'bytes':exe.stat().st_size,'sha256':hashlib.sha256(exe.read_bytes()).hexdigest()},'scope':'Private QA executable with embedded PCK and only three allowlisted fixture files; modified entry scene, production runtime resources'},indent=2),encoding='utf-8')
for mode in ['writer','restart']:
    out=base/mode;out.mkdir()
    env.update(SNAPLAND_SAVE_PATH=str(base/'qa-profile/progress.json'),SNAPLAND_CANDY_REVIEW_OUTPUT=str(out),SNAPLAND_CANDY_REVIEW_SIZE='1280x720',SNAPLAND_CANDY_REVIEW_MODE=mode,SNAPLAND_CANDY_REVIEW_TEXT_SCALE='1',SNAPLAND_CANDY_REVIEW_REDUCED_MOTION='0')
    result=run_validated_godot(stage,[str(exe),'--log-file',str(out/'engine.log'),'--rendering-method','gl_compatibility','--audio-driver','Dummy','--fixed-fps','60','--quit-after','5000'],env=env,timeout=180,release_directory=release)
    log=result.stdout+result.stderr+'\n'+(out/'engine.log').read_text(encoding='utf-8')
    (out/'native.log').write_text(log,encoding='utf-8')
    (out/'result.json').write_text(json.dumps({'exit':result.returncode}),encoding='utf-8')
    report=json.loads((out/'report.json').read_text(encoding='utf-8'))
    assert result.returncode==0 and 'ERROR:' not in log and 'PASS: native Main candy travel' in log and not report['failures'] and len(report['captures'])>=(12 if mode=='restart' else 14),mode
    print('PASS standalone candy',mode,len(report['captures']),flush=True)
print('PASS private embedded Windows QA output; no loose project in release directory',flush=True)
