# MAIN-26 Task 2 fix round 1

Status: DONE. No Git operations by this worker.

## Change

- `game/ui/harbor_map_panel.gd`: disable autowrap for each numbered location label. Existing HFlowContainer now wraps whole entries in both regional maps. One production line; no map redesign.
- `game/tests/test_region_travel.gd`: use the actual open Harbor/Candy maps at native logical 800×600 with 1.25 text. Each location must render on one line and fit its flow container; all six Candy entries must additionally fit the viewport. Restore previous window geometry and text setting afterward.

## Validation

The original implementation reproduced three new focused failures: Harbor once, Candy twice (`before.log`, engine exit 1). After the production fix both Candy viewport checks passed. An initially broader Harbor viewport check exposed an unrelated existing horizontal overflow; evidence below explains its separate scope.

Latest validated run: engine exit **0**, **49.79 seconds**, no script errors, final exact marker:

`PASS: region travel admission, lifecycle, scoped UI, restart, and unchanged rewards`

Full log: `comparison.log`; live engine log: `comparison-engine.log`. The passing run included the final flow-local/one-line assertions for Harbor and unchanged stronger Candy viewport assertions. Its temporary geometry probe toggled Harbor labels to the original mode and back in memory; that diagnostic-only block was removed afterward. Root's final affected-suite run will execute the clean final test source.

Exact launcher used (Python from repository root):

```python
from pathlib import Path
import os
from tools.godot_entrypoints import run_validated_godot
root = Path.cwd()
output = root / '.review/candy-travel-fix1'
env = os.environ.copy()
env['SNAPLAND_SAVE_PATH'] = str(output / 'comparison-profile/progress.json')
command = [
    'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',
    '--headless', '--path', str(root), '--audio-driver', 'Dummy',
    '--rendering-method', 'gl_compatibility',
    '--log-file', str(output / 'comparison-engine.log'),
    'res://game/tests/test_region_travel.tscn',
]
result = run_validated_godot(root, command, env=env, timeout=90)
```

`git diff --check` passes. No editor/import launch used.

## Existing Harbor overflow, assigned MAIN-27

At the same 800×600 / 1.25 viewport, toggling only the live labels' autowrap confirms:

| Geometry | Original smart wrap | Fixed no wrap |
|---|---|---|
| Location flow | position (28,450), size (3713,57) | position (28,449), size (3713,58) |
| Existing footer | position (28,511), size (3713,55) | position (28,511), size (3713,55) |
| Viewport | position (0,0), size (800,600) | position (0,0), size (800,600) |

Exact evidence: `comparison-engine.log` lines 196–197. The twelve existing game actions share a non-scrolling horizontal footer; its unchanged 3713-pixel minimum width causes the pre-existing horizontal overflow. This is not vertical scroll content. Root opened MAIN-27 (1479d7b) for that separate layout change. No footer changes made here.

Native screenshots and package revalidation remain root-owned. No new test marker or registry entry is needed.
