# MAIN-26 Task 2 fix round 2

Status: DONE WITH KNOWN PRE-EXISTING ISSUE. No production Main change; no Git operations or error allowlist changes.

## Decisive baseline attribution

Actual origin/main **5655318da096943055281bd1c460300f76a0bd62** reproduces the exact reported shutdown diagnostics in the private copied project:

- Baseline run: engine exit **0**, exact existing PASS marker, **32.83 seconds**.
- `WARNING: 10 ObjectDB instances were leaked at exit (run with --verbose for details).`
- `ERROR: 5 resources still in use at exit (run with --verbose for details).`

Full evidence: `baseline-0.log`.

The private project is `C:\Users\stanl\AppData\Local\Temp\snapland-retake-lifetime-ifyvhwax`. Runtime entry remained `res://game/tests/test_photo_retake_main.tscn`, outside `.review` and using the validated launcher. No editor/import was run. Assets/imported data are shared read-only runtime junctions; code is copied. Seven changed production scripts were replaced with exact `git show origin/main:<path>` bytes: Main, Progress, ParkWorld and achievement/collection/harbor-map/island-map panels. CandyWorld remains unreferenced by the baseline Main. The retake fixture, original nonverbose flags and isolated save path were identical across current/baseline runs.

`source-manifests/manifest.json` records current/baseline SHA256s and the unchanged fixture SHA256. Current private files restored in finally: **True**. Private fixture hash matches: **True**.

This demonstrates the reported 5-resource/10-object exit issue pre-exists MAIN-26 under the same retake fixture. Exact leaked-resource class/path identities remain unknown: all verbose captures were clean. Counts alone were not used to identify resource types.

## Separately proven fixture teardown race

The fixture previously shut down audio while leaving Main.quitting false. A real current-world area_changed signal emitted afterward restarted the audio context through Main's existing area callback.

- Red: `late-area-red.log`, engine exit **1**, exact new failure `teardown ignores late current-world area callbacks`.
- Fix: add `main.quitting=true` before the existing audio shutdown. Keep the real signal emission and empty-context assertion as a regression check in the parent test.
- Green: `guarded-verbose.log`, engine exit **0**, **32.46 seconds**, exact existing PASS marker, zero ERROR/leak lines.

Only `game/tests/test_photo_retake_main.gd` changes in this round (four lines). The fixture now matches production `_quit_game` and regional/native test teardown ordering. This fixes the demonstrated late-area audio race; it does **not** claim to fix the separate original resource leak.

## Other bounded evidence

- Four unchanged verbose full-suite runs clean: 33.37, 32.57, 32.57, 32.65 seconds (`verbose.log`, `repeat-1..3.log`).
- Original nonverbose guarded run still reproduced exact 5/10 leak (`guarded-original.log`); no completion claim was made from its exit code/PASS marker alone.
- Root independently has a clean nonverbose result-contract run at `.review/candy-main26-20261117/retake-final/0/runtime.log` (32.95 seconds).
- Current typed/untyped/typed factory A/B/A in the same private project, same nonverbose command and same save path: all clean, 32.80 / 33.11 / 32.85 seconds (`factory-aba-0-typed.log`, `factory-aba-1-untyped.log`, `factory-aba-2-typed.log`). This did not isolate the factory annotation as a cause; no annotation change was applied.
- Pure ObservedMain construction/destruction: 20 clean verbose reduced probes. Three welcome-only and three three-region factory probes per typed/untyped mode clean. These reductions did not reproduce the full-suite issue.
- Forced pending notice, zero audio-drain and verbose+quiet probes were clean. Neither notice ownership nor audio drain duration was established as the original leak cause; no timer refactor/delay increase was applied.
- Private cleanup monitor found the same cached script reference counts with original watchdog lambda and native Callable variants. This did not demonstrate a watchdog cause; no watchdog change applied.
- First private full monitor trial lacked design/park JSON and was rejected as an invalid comparison (`owner-release-probe.log`); the missing design junction was supplied before the decisive A/B/A and baseline runs.

## Exact decisive launcher

Python from workspace root, after substituting the seven baseline scripts in the private project:

```python
from tools.godot_entrypoints import run_validated_godot
env = os.environ.copy()
env['SNAPLAND_SAVE_PATH'] = str(output / 'factory-aba-profile/progress.json')
command = [
    'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',
    '--headless', '--path', str(stage), '--audio-driver', 'Dummy',
    '--rendering-method', 'gl_compatibility',
    'res://game/tests/test_photo_retake_main.tscn',
]
result = run_validated_godot(stage, command, env=env, timeout=90)
```

Exact retained marker:

`PASS: Main selected retakes, actual attempts, truthful awards and safe PNG replacement`

No diagnostics suppressed. Root will track the pre-existing intermittent exit leak separately; native/package acceptance and final delivery remain root-owned.
