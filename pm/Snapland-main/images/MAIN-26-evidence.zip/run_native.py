from pathlib import Path
import json,os,sys,hashlib
ROOT=Path.cwd()
sys.path.insert(0,str(ROOT))
from tools.godot_entrypoints import run_validated_godot
base=ROOT/'.review/candy-main26-20261117'
size=sys.argv[1] if len(sys.argv)>1 else '1280x720'
restart='--restart' in sys.argv
tag=next((a.split('=',1)[1] for a in sys.argv if a.startswith('--tag=')), '')
assert not tag or tag.isalnum()
assert size in ['800x600','1280x720','1920x1080']
out=base/(size+('-'+tag if tag else '')+('-restart' if restart else '-writer'))
assert not out.exists()
out.mkdir()
sources=[p for folder in ['game','tools'] for p in (ROOT/folder).rglob('*') if p.suffix in ['.gd','.tscn','.json','.py']]
(out/'source_hashes.json').write_text(json.dumps({p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},indent=2),encoding='utf-8')
profile=base/('profile-'+size)/'progress.json'
env=os.environ.copy()
env.update(SNAPLAND_SAVE_PATH=str(profile),SNAPLAND_CANDY_REVIEW_OUTPUT=str(out),SNAPLAND_CANDY_REVIEW_SIZE=size,SNAPLAND_CANDY_REVIEW_MODE='restart' if restart else 'writer',SNAPLAND_CANDY_REVIEW_TEXT_SCALE='1.25' if size=='800x600' else '1',SNAPLAND_CANDY_REVIEW_REDUCED_MOTION='1' if size=='800x600' else '0')
command=[r'C:\Tools\Godot\Godot_v4.7.2-stable_win64_console.exe','--path',str(ROOT),'--log-file',str(out/'engine.log'),'--rendering-method','gl_compatibility','--audio-driver','Dummy','--fixed-fps','60','res://game/tests/native_candy_travel_review.tscn','--quit-after','5000']
result=run_validated_godot(ROOT,command,env=env,timeout=150)
(out/'result.json').write_text(json.dumps({'exit':result.returncode}),encoding='utf-8')
log=result.stdout+result.stderr+'\n'+(out/'engine.log').read_text(encoding='utf-8')
(out/'native.log').write_text(log,encoding='utf-8')
print(result.returncode,log[-2200:])
assert result.returncode==0 and 'ERROR:' not in log and 'PASS: native Main candy travel' in log
report=json.loads((out/'report.json').read_text(encoding='utf-8'))
assert not report['failures'] and len(report['captures'])>=(12 if restart else 14)
print('PASS native candy',size,'restart' if restart else 'writer',len(report['captures']),'captures')
