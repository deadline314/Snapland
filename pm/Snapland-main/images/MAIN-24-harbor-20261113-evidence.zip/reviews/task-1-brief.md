### Task 1: Transactional current-region state

**Files:** Modify `game/core/progress.gd`, `game/tests/progress_restart_review.gd`; create `game/tests/test_region_progress.gd`.

**Interfaces:** `Progress.current_region: String = "welcome"`; supported persisted values welcome/harbor. `set_current_region(region: String) -> bool` idempotently saves once, rolls back failure and does not emit changed. Missing/invalid/unimplemented destination loads welcome without rejecting other data.

- [ ] Write/run red tests for fresh/reset/missing/malformed/unknown/unimplemented destinations, both supported round trips, same-value no write, rejected value no write, exactly-one-write success, real failure rollback, unknown fields/prologue/rewards preserved.
- [ ] Reach declaration, payload, known-field exclusion, validation/load/reset paths, keeping version1. Optional malformed field warns and defaults welcome. Add current_region to explicit restart snapshot.
- [ ] Cover failure with real isolated IO in a captured child, assert exact expected diagnostic+PASS+exit and no hidden errors; parent suite has clean output (reuse existing child-test convention).
- [ ] Run new state test plus existing core/save/prologue-state regressions; self-review, commit only owned paths, detailed task-1-report.md. Do not edit runner/Main/world/UI.

