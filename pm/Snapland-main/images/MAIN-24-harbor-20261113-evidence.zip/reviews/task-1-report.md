# Task 1 report — transactional current-region state

Status: complete, committed. Task BASE: f15bb1e80a7d034683644d837e0f41eab3177147.
Commit: e77e28c6cf118c41b9499eacff8309d009935f29 (MAIN-24 保存目前園區並在切換失敗時還原).
Author and committer: Stanley Li <stanley890314@gmail.com>.

## Scope and implementation

Only the three assigned paths were staged and committed:

- `game/core/progress.gd`: typed `current_region: String = "welcome"`; supported destinations `welcome`/`harbor`; idempotent validating `set_current_region(String) -> bool`, exactly one existing atomic save on change, previous-value rollback on failure, no `changed` emission. Added the version-1 payload entry, known-field exclusion, optional-field validation warning/fallback, apply/load assignment, and reset default.
- `game/tests/progress_restart_review.gd`: explicit snapshot includes current_region; writer saves harbor; independent reader asserts harbor after restart.
- `game/tests/test_region_progress.gd`: new standalone SceneTree suite, no Main/world/audio setup. Exact parent PASS marker: `PASS: region progress defaults, migration, transactions, and rollback`.

Preservation coverage uses an already normalized complete payload containing photos, achievements, quests, visited, intro/prologue, pending platform achievements, settings including unknown settings, appearance, equipped and owned clothes, coins, rewarded/tutorial games, and a nested unknown top-level field. Region changes and invalid legacy fallback compare the complete unrelated payload, not selected reward counters. Failure is exercised in both directions and verifies old memory region, signal count, exact primary/backup bytes, full memory payload after a subsequent save, and reload.

The child captures eleven malformed/unknown/unimplemented destination warnings and two real `.tmp` directory write failures. Parent requires the exact ordered diagnostic list, exact child PASS marker, and exit zero. All unexpected WARNING/ERROR/SCRIPT ERROR diagnostics reject the child. Failure reporting includes exit/marker status, bounded diagnostic text and a 3000-character output tail. It reuses the existing synchronous captured-child convention; the official runner supplies the 90-second outer timeout.

## RED → GREEN evidence

Working directory for every command below:
`C:/Users/stanl/Github/Snapland/.review/harbor-travel-worktree`.
Windows engine: `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe`.
Both engines identify as `4.7.2.stable.official.ed1daf0bf`.

1. Before production edits, wrote and ran the new suite:

```powershell
$env:SNAPLAND_SAVE_PATH='C:/Users/stanl/Github/Snapland/.review/harbor-travel-worktree/.review/main24/region-red/progress.json'
& C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --path . --audio-driver Dummy --rendering-method gl_compatibility --script res://game/tests/test_region_progress.gd *> .review/main24-region-red.log
```

Result: exit 1; exactly the expected assertions `fresh memory starts in welcome` and `transactional region API exists` failed because the feature was absent. No parser failure.

2. After implementation, then again after strengthening rollback to both directions:

```powershell
$env:SNAPLAND_SAVE_PATH='C:/Users/stanl/Github/Snapland/.review/harbor-travel-worktree/.review/main24/region-green/progress.json'
& C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --path . --audio-driver Dummy --rendering-method gl_compatibility --script res://game/tests/test_region_progress.gd *> .review/main24-region-green.log
```

Result: exit 0; exact suite PASS marker; clean parent output, no diagnostic leakage.

3. Affected existing suites through the official runner:

```powershell
$env:GODOT_BIN='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
python tools/run_game_tests.py --only 'core runtime' --only 'test/review save isolation' --only 'boat prologue state' *> .review/main24-task1-regressions.log
```

Result: exit 0; 4/4 passed: clean import (15.00s), core runtime (0.88s), save isolation (3.21s), boat prologue state (0.49s). Runner creates an isolated absolute profile per suite. No runner modifications/exceptions.

4. Real independent writer and reader processes:

```powershell
$env:SNAPLAND_SAVE_PATH='C:/Users/stanl/Github/Snapland/.review/harbor-travel-worktree/.review/main24/region-restart/progress.json'
& C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --path . --audio-driver Dummy --rendering-method gl_compatibility res://game/tests/progress_restart_review.tscn -- --write-review *> .review/main24-task1-restart-writer.log
& C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --path . --audio-driver Dummy --rendering-method gl_compatibility res://game/tests/progress_restart_review.tscn *> .review/main24-task1-restart-reader.log
```

Result: both exit 0 and PASS; writer PID 15936, reader PID 29224. Exact saved-file hash and all snapshot fields match; harbor survives startup.

5. Linux portability, including exact captured real-IO diagnostics:

```powershell
wsl -d Ubuntu -- env SNAPLAND_SAVE_PATH=/home/stanley/.cache/snapland-main24/task1/progress.json /home/stanley/.cache/snapland-boat-debug/Godot_v4.7.2-stable_linux.x86_64 --headless --path /mnt/c/Users/stanl/Github/Snapland/.review/harbor-travel-worktree --audio-driver Dummy --rendering-method gl_compatibility --script res://game/tests/test_region_progress.gd *> .review/main24-task1-linux.log
```

Result: exit 0; exact suite PASS marker, clean parent output. Linux uses an absolute Linux profile path, not a Windows path.

## Self-review / handoff

- Reviewed the spec, task brief, runtime save pipeline/callers and complete owned diff. Checked no signal/autosave double-write, unknown field shadowing, legacy optional-field default, both rollback origins, and explicit restart coverage.
- `git diff --cached --check` passed before commit. Only assigned source/test paths in commit; generated `.import`/`.uid` files left untouched. Cross-platform engine use produces Git line-ending notices on import metadata; these were not staged.
- Task 3 must register the new suite with the exact parent PASS marker above. Main must refresh after world replacement; region transaction deliberately emits no changed signal.
- No new dependency, save version, travel framework, reward/visit flag, Main/world/UI/runner change, ticket change, push or branch change.
- No deviations or deferred defects found. No native gameplay/UI/packaged-build verification or full broad runtime suite in this task; those belong to subsequent integration/controller verification. Real failure coverage blocks the temporary-file open; the existing atomic save implementation's other failure branches were not changed.
