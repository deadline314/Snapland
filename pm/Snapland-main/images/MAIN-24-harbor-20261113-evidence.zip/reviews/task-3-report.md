# MAIN-24 Task 3 report

Status: source implementation and scoped verification complete; parent owns native/PCK acceptance, whole-branch review, rebase, ticket/evidence publication and push. Commit: 330f27116917bffe20a5b07843a20f64aa6f86a1 (feat: connect saved harbor travel and regional menus). Author/committer Stanley Li <stanley890314@gmail.com>; no trailers. Base: e77fe75f4136de68411077efb8b3370bc66d61c6. Worktree: C:/Users/stanl/Github/Snapland/.review/harbor-travel-worktree. No subagents or branch changes.

## Delivered scope

Main now explicitly selects welcome/harbor from the saved region. Capture and art-smoke review flows deliberately select welcome; ordinary startup/smoke follows the profile. Boat first-run/arrival and pause replay are welcome-only. Travel accepts only known different destinations, requires six GLOBAL distinct canonical ordinary cards for harbor, consumes nothing and always admits free welcome return. Session/dialogue/capture/reentry are blocked. The transactional setter saves before any world/modal/input mutation; write failure preserves old player/camera/world/flags/modal and provides retry text. Successful replacement is deferred out of interaction signal stacks, blocks input/stale area events, frees the old world synchronously before construction, rebinds once and refreshes settings, current full look, phase, story and markers. Reset changes the actual world back to welcome.

Exact optional CoastalPlay/discoveries dereferences are guarded. Region identity chooses harbor audio, including settings and welcome-game cancellation. Existing quitting guards stay effective and test cleanup sets quitting BEFORE shutdown, deliberately emits a pending area event and waits for real audio teardown. No resource-error whitelist was added.

HUD and pause counts use current-region numerators. Harbor has a separate small value-snapshot terrain chart with tide/sandbar status, numbered actual interaction markers, player marker and real ferry/return labels; welcome station map remains intact and correctly distinguishes harbor availability from eight future zones. Collection setup gains an optional welcome-default region, starts at the actual current region, offers a region selector, retains original welcome sources/viewer, and shows a clear empty harbor state. Harbor tasks point back to existing welcome tasks. Existing achievement/game views carry welcome scope labels. No harbor games, quests, rewards, photographs or future registry were added.

Approved ownership extension: only ParkWorld._build_gates' physical harbor label changed to `6 張 · 不消耗`; eight other gate labels remain 準備中. Integration asserts this exact distinction. Parent recorded the ruling in the plan before the edit. No other world source changed.

Two affected FakeProgress fixtures gained the existing normal_count_for_zone method. One welcome-map fixture changed its expected harbor state from 準備中 to 尚未達資格. Runner registers all three new suites and exact PASS lines, including the current world's `(7017 checks)` suffix; contract tests reject suffixes, missing/wrong markers, nonzero exit and any engine error. State/world sources remain owned by previous tasks.

## Tests and evidence

All commands below ran from the assigned worktree. Direct engine commands always carried an absolute isolated SNAPLAND_SAVE_PATH. Official runner creates a unique absolute profile directory for each invocation/suite. Windows engine: C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe. Linux engine: /home/stanley/.cache/snapland-boat-debug/Godot_v4.7.2-stable_linux.x86_64 (Ubuntu WSL).

First integration RED: created test_region_travel.tscn/gd and ran direct isolated engine. `.review/task3-red.log` reports `FAIL: Main has guarded regional travel`. After implementation the same missing-API/below-threshold test passed (`.review/task3-green.log`). Expanded scenario integration then exposed detached book deferred-layout callbacks, a too-long welcome map paragraph, fake fixture API drift and insufficient real-time audio drain when using fixed-fps children. Root fixes: local is_inside_tree guards in owned book callbacks, concise three-line harbor availability copy, narrow fixture APIs, and bounded max-fps/quit-after child execution with real-time teardown. No failures or resource errors were swallowed.

Commands (PowerShell):

    $env:GODOT_BIN='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
    python tools/run_game_tests.py --only 'region' --only 'harbor world' *> .review/task3-runner-new.log

Exit0, 4/4: clean import7.45s; region progress0.76s; harbor world34.53s; Main travel22.11s.

    python tools/run_game_tests.py --only 'travel collection' --only 'pixel UI collection' --only 'pixel UI customization' --only 'main scene integration' --only 'main story' --only 'NPC dialogue hold' --only 'island dialogue' --only 'island game entry' --only 'saved photo viewer' --only 'photo original' --only 'boat prologue' --only 'core runtime' --only 'story runtime' --only 'time-of-day' --only 'island audio dynamics' --keep-going *> .review/task3-regressions.log

Initial run identified exactly three affected suites: travel/book map overflow, saved-viewer FakeProgress API, pixel-collections FakeProgress API (subsequent geometry assertions cascaded). Other15/18 checks passed: import; core; time-of-day; NPC dialogue hold; boat state/stage/integration; story; Main story; photo originals; island dialogue; game entry; audio dynamics; Main integration; UI customization.

    python tools/run_game_tests.py --only 'travel collection' --only 'saved photo viewer' --only 'pixel UI collection' --keep-going *> .review/task3-regression-fixes.log

After fixes exit0, 4/4: import5.21s; travel/book8.35s; saved viewer0.57s; pixel collections10.16s. Thus all17 affected existing runtime suites passed across the focused runs, without rerunning unrelated suites.

    python tools/run_game_tests.py --only 'region travel' --only 'game startup' --only 'test/review save isolation' *> .review/task3-final-targeted.log

Exit0, 4/4: import4.92s; ordinary startup4.46s; expanded Main travel30.40s; save isolation3.08s. Expanded travel now also checks a nondefault complete appearance/free owned outfit and zero-card free return in both tides. Covers five/six/global-card boundary, devil/postcard exclusion, explicit gate button, session/dialogue/capture guards, deferred signal/reentry, old-world invalidation, one active world, harbor settings/look/time/audio, local HUD, real map snapshot/empty collection/welcome source switch, no local tasks, welcome minigame cancellation, both tides and ferry directions, repeated travel, saved harbor startup, reset, legacy/unknown fallback, actual failed IO/rollback/retry, unchanged reward snapshots, and deterministic quitting guard.

    wsl -d Ubuntu -- bash -lc 'cd /mnt/c/Users/stanl/Github/Snapland/.review/harbor-travel-worktree && GODOT_BIN=/home/stanley/.cache/snapland-boat-debug/Godot_v4.7.2-stable_linux.x86_64 python3 tools/run_game_tests.py --only "region travel" --only "region progress" > .review/task3-linux-new.log 2>&1'

Exit0, 3/3: clean import32.53s; region state1.67s; Main travel49.36s. Cross-platform captured child verifies exact isolated temporary-write error, exit0 and exact child PASS, with bounded actionable output on mismatch. No broad resource diagnostic exemptions.

    python -m unittest tests.test_runtime_result_contract tests.test_godot_entrypoints -q

Exit0, 33 tests. Repeated after fixture/runner edits.

Final direct import: SNAPLAND_SAVE_PATH=C:/Users/stanl/Github/Snapland/.review/harbor-travel-worktree/.review/task3-final-parser/progress.json, engine --headless --editor --path . --rendering-method gl_compatibility --import --quit, log `.review/task3-final-parser.log`. Exit0, no ERROR/SCRIPT ERROR. This parses final native fixture fail-fast/image guards and map physical font sizing. `git diff --check` passed for every owned source/test path. Self-review checked all direct coastal dereferences, destination validation/save ordering, old-world release and optional controllers, reset/startup/boat behavior, truthful counts/maps/collection/tasks, shutdown guard, strict runner contracts and stage ownership.

## Native fixture usage (controller responsibility)

Source entry: `res://game/tests/native_region_travel_review.tscn`, a Node scene loading actual Main. Do not launch its Node script with --script. Requires GPU window and isolated absolute SNAPLAND_SAVE_PATH. Environment:

- SNAPLAND_HARBOR_REVIEW_SIZE: 800x600 /1280x720 /1920x1080 (default1280x720).
- SNAPLAND_HARBOR_REVIEW_TEXT_SCALE: 1 or1.25 (default1).
- SNAPLAND_HARBOR_REVIEW_REDUCED_MOTION: 1 to enable, otherwise off.
- SNAPLAND_HARBOR_REVIEW_OUTPUT: absolute writable output directory (default beside profile/native-harbor-review).
- SNAPLAND_HARBOR_REVIEW_MODE: unset for writer, `restart` for a NEW process reading the same saved profile.

Writer deliberately sets up six synthetic canonical existing welcome records ONLY in its isolated profile, logs scripted_profile_setup=true /earned_in_human_play=false /human_played=false, preserves loaded full appearance/outfit, and asserts unchanged baseline photos/coins/quests/achievements/visited/look through actual Main gate button travel, both tide interactions, both free ferries, map/collection/settings/pause, permanent free return and repeat gate button. It ends in harbor via the actual successful region transaction, ready for a separate process to load. Reader does not seed/reset/edit the starting profile; it validates the real saved harbor load and no welcome boat/arrival before running review actions. All output PNGs assert actual Window+viewport dimensions, actual image dimensions and write success; visible key actions assert viewport containment. Report.json includes scripted/setup/restart labels, renderer, settings/look, captures, before/after reward snapshots and failures. This is automated evidence, not human play/listening or visual acceptance.

External-PCK-compatible bootstrap: use the immutable fixture source from this commit outside the PCK. A small external SceneTree script can add `load("/absolute/path/native_region_travel_review.gd").new()` to its root; that Node script preloads res://game/main.tscn and uses packed game resources/autoloads. Launch the external SceneTree bootstrap with the isolated game PCK and the same environment, as in the parent's boat workflow. Do not use --script on the Node fixture itself. Parent runs source/native and isolated PCK/Windows matrix and publishes evidence after this source commit.

## Limits / remaining work

No full repository suite, actual native window review, PCK export, human play or listening performed by this implementer; controller owns these. No push/rebase/ticket completion performed. Parent's plan edit and generated .import/.uid churn are left untouched and unstaged. Native physical layout, terrain appearance and audio listening remain acceptance work; all claimed results here are scoped automated runtime/source checks.
