### Task 2: Reusable world seams and real harbor terrain

**Files:** Modify `game/world/park_world.gd`; create `game/world/harbor_world.gd`, `game/tests/test_harbor_world.gd`.

**Interfaces:** HarborWorld extends ParkWorld; shared world contract unchanged. Expose `set_tide(high: bool)`, `is_high_tide() -> bool`, `take_ferry(point_id: String) -> bool`, `map_snapshot() -> Dictionary` as specified. Points harbor:tide, harbor:ferry:*, harbor:info:*, region:welcome only.

- [ ] Write/run red focused world tests for real independent scene, collision/terrain agreement, safe spawns, return/clock/docks reachability, both tide states, player-on-sandbar rising tide, free ferry and bounded scene reentry.
- [ ] Extract only existing region geometry/activities, player spawn/floor, instance ground wrapper, movement constraints and area name hooks. Preserve the static welcome ground API and original default behavior/order, including recovery stride reset. Route all internal grounding through wrapper; null-guard optional water materials.
- [ ] Build distinct lighthouse shore, sandbar shortcut, ring waterway and permanent reachable docks/path with existing helpers/materials. No welcome geometry built then deleted, hidden welcome slabs, NPC/toy controllers or reward points. Use real collision surfaces matching map terrain.
- [ ] Local tide preview uses no global clock/save; high tide makes sandbar unavailable and safely relocates a player standing there; ferry always free to fixed safe docks, zero velocity. Recovery cannot trap player in water.
- [ ] Reuse approved avatar/appearance/settings/time/lighting and shared movement; override no-op NPC/activity/collection behavior. Return snapshots only primitive geometry/point data, no retained world nodes.
- [ ] Run new world test plus affected welcome layout/grounding/avatar-motion/boat-stage tests. Self-review and commit owned files; detailed task-2-report.md. No Main/Progress/UI/runner/docs edits.

