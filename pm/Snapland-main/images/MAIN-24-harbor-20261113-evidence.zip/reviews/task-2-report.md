# Task 2 report — MAIN-24 harbor world

Status: complete within assigned world/test scope.
Base: e77e28c6cf118c41b9499eacff8309d009935f29
Commit: e77fe75f4136de68411077efb8b3370bc66d61c6
Branch: codex/harbor-travel-20261112
Author and committer: Stanley Li <stanley890314@gmail.com>

## Scope and implementation

Only committed paths:
- game/world/park_world.gd
- game/world/harbor_world.gd
- game/tests/test_harbor_world.gd

Read AGENTS.md, design/runtime/harbor-travel.md, plan Global Constraints (plan-path), task-2 brief and existing .review/main24-world-seam.md; trusted the focused audit. No branch changes, pushes, subagents, Main/Progress/UI/runner/assets/tickets changes. Generated .import/.uid churn from import remains unstaged.

ParkWorld keeps its original _ready and physics orchestration. Extracted geometry/activity, spawn/floor, instance ground sampling, constraint and area hooks. Original welcome builder content/order, floor dimensions, static _ground_surface_y API and fall-recovery telemetry reset are preserved. Every internal ground sample now uses ground_surface_y; the static function appears only in its wrapper and own declaration. Optional sea/fountain settings have null checks.

HarborWorld inherits the approved complete-source avatar, renderer/cache, lighting, camera, appearance, settings, input and physics. It skips welcome scenery, hidden slabs, NPCs, story landmarks, CoastalPlay and attraction controllers at construction; activity/NPC/floor/collection overrides are no-ops. Geometry is six explicit permanent collision/land rectangles surrounding the lighthouse waterway, a permanent north footbridge, and a genuinely removable low-tide sandbar. Textured shore/deck/sign materials reuse existing helpers/atlas, with physical lighthouse, tide clock, boat scenery, and concise Traditional Chinese signs. No PNG generated.

Navigation uses the same land rectangles as collision and map output; player clearance is checked at capsule-radius corners. Invalid external/fall positions recover to the harbor dock rather than a welcome coordinate. High tide relocates a player overlapping the sandbar before removing collision and zeroes velocity. Tide changes do not affect the global time or save. Ferry has fixed safe opposing positions in both tides and no cost/reward operations. Repeated worlds have 40 scenery meshes / 90 nodes and are freed after each visit.

## Integration contract

- extends ParkWorld, no replacement _ready/_physics_process.
- set_tide(high: bool), is_high_tide() -> bool, take_ferry(point_id: String) -> bool, map_snapshot() -> Dictionary.
- harbor:tide: local preview clock.
- harbor:ferry:shore: shore -> lighthouse.
- harbor:ferry:lighthouse: lighthouse -> shore.
- harbor:info:lighthouse and harbor:info:games: honest information only.
- region:welcome: permanent return point.
- current_area initially and subsequently 潮汐碼頭 (no false welcome subarea to select music).
- map_snapshot contains exactly bounds, land, sandbar, points, player, high_tide. bounds Rect2(-15,-12,30,24); land Array[Rect2]; sandbar Rect2(-9,-1.5,5,3); point dictionaries only id/label/position(Vector3); player Vector3. Data are detached and contain no nodes/resources.
- Fixed shore spawn/return ferry Vector3(-12,0.2,9), lighthouse ferry Vector3(-2,0.2,2). Shared capsule origin naturally settles about 0.1 below sampled terrain; renderer feet/shadow use the instance sampler. Region return point is (-12,0.2,5).
- Test marker for Task 3 runner registration: PASS: harbor world terrain, tide safety, free ferry, map alignment and bounded reentry (

## Commands, logs and observed results

All commands run in C:/Users/stanl/Github/Snapland/.review/harbor-travel-worktree.
Every direct Godot invocation had an absolute SNAPLAND_SAVE_PATH under this worktree's .review/main24. Official runner supplies its own isolated verified test profile.

### Baseline before any world edits

$env:GODOT_BIN='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
python tools/run_game_tests.py --only 'island layout' --only 'sprite clearance' --only 'avatar motion world' --only 'boat prologue stage' *> .review/main24/task-2-baseline.log

Observed all 5 runner entries PASS: import 6.73s; avatar motion world 11.41s; sprite clearance 11.80s; boat stage 8.05s; island layout 7.72s. Baseline executed once.

### Red, focused test before implementation

$env:SNAPLAND_SAVE_PATH='C:/Users/stanl/Github/Snapland/.review/harbor-travel-worktree/.review/main24/world-red/save.json'
& 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe' --headless --path . --script game/tests/test_harbor_world.gd *> .review/main24/task-2-red.log

An initial test-only inferred-Variant warning was corrected before observing red. Recorded red: ERROR independent HarborWorld exists; FAIL: harbor world (1/1). World source did not exist and no production changes had been made.

### Focused green / fixture calibration

$env:SNAPLAND_SAVE_PATH='C:/Users/stanl/Github/Snapland/.review/harbor-travel-worktree/.review/main24/world-green/save.json'
& 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe' --headless --path . --script game/tests/test_harbor_world.gd *> .review/main24/task-2-green.log

First implementation run passed all terrain/collision/input checks but had 9 test fixture failures comparing freshly relocated positions with the initial already-settled capsule origin. Corrected the assertions to compare against the actual fixed shore point, retaining separate settled-footing assertions; did not loosen terrain checks. Second run exit 0, PASS 6990 checks.

### Affected welcome regressions

$env:GODOT_BIN='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
python tools/run_game_tests.py --only 'island layout' --only 'sprite clearance' --only 'avatar motion world' --only 'boat prologue stage' *> .review/main24/task-2-regressions.log

Exit 0, all 5 PASS: import 5.19s; avatar motion world 11.41s; sprite clearance 11.76s; boat stage 8.00s; island layout 7.63s. Later edits touched only harbor sign copy/size and stronger harbor test assertions, so welcome suites were not redundantly repeated.

### Final focused run after self-review

$env:SNAPLAND_SAVE_PATH='C:/Users/stanl/Github/Snapland/.review/harbor-travel-worktree/.review/main24/world-final/save.json'
& 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe' --headless --path . --script game/tests/test_harbor_world.gd *> .review/main24/task-2-final.log

Exit 0, PASS: harbor world terrain, tide safety, free ferry, map alignment and bounded reentry (7017 checks).

The focused suite creates/frees the real world 3 times; checks no inherited welcome controllers/actors, shared source avatar/settings/look/time, initial area, value-only detached snapshots, exact allowed points, bounds, every interaction's actual footing/nearest selection, collision/map/height agreement over the full bounds in both tides, BFS permanent point reachability, real input across the low-tide sandbar and stopped at high-tide water, rising tide under player, fixed ferry landings both directions/both tides, unknown ferry rejection, harbor recovery without false strides, no reward/global-state mutation and bounded node/material counts.

Self-review: git diff --check / staged --check passed; checked original/default extraction and sampler callers, water supports, point spacing, detached value snapshots, exact commit ownership and author/committer. No API/spec contradictions identified.

## Remaining responsibility / limitations

No broad full suite, Linux, native human-play evidence or export run; controller owns native layout/calibration and isolated packaging. Tests are automated runtime checks, not human play/listening. Task 3 still must register the new focused suite and connect optional-controller-safe Main travel/tide/ferry/UI flow. Harbor alone does not make current Main ready to travel. Physical sign readability/overall visual composition remains for native verification; concise font16 copy was chosen to fit existing board widths. No new games, quests, photos, reward grants or future-zone framework.
