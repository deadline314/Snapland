# MAIN-24 whole-branch merge review

Reviewed base `e20268985b08dba5af2310a899c5240659fc26e0` through head `00b29d7794772812adf32fcb4dfb98ecae11868b`. HEAD matched the supplied head. Requirements: `design/runtime/harbor-travel.md` and `docs/superpowers/plans/2026-11-12-harbor-travel.md`.

## Strengths

- Save migration reaches declaration, payload, validation, known-field exclusion, loading and reset. The typed setter rejects unsupported destinations, avoids no-op writes and changed-signal reentrancy, saves once and restores the previous region on failure (`game/core/progress.gd:86`, `587`, `845`, `903`, `942`, `1034`). Tests compare the complete normalized unrelated payload and actual primary/backup bytes, including both failure directions.
- Main validates global canonical six-card admission before saving; free return requires neither cards nor tide. Deferred replacement escapes the interaction signal stack, blocks reentry/stale area events, and frees the old world before constructing its replacement (`game/main.gd:109`, `119`, `135`). Saved startup, reset reconciliation, welcome-only boat/capture flows and optional-controller guards agree with the two-world contract.
- Harbor reuses the existing player, camera, animation, lighting and physics orchestration without constructing welcome scenery first. Terrain, collision and detached map data share the same bounds; rising tide relocates before removing support and ferries use safe fixed destinations (`game/world/harbor_world.gd:4`, `18`, `95`, `120`, `133`, `146`). The static welcome ground API remains intact; internal sampling reaches the instance hook.
- Regional menus distinguish the current world's counts and map from welcome's retained games, achievements, tasks and original photos. Harbor exposes honest empty collections and allowed informational interaction IDs, with no local reward/visit grants (`game/main.gd:1247`, `1545`, `1555`, `1750`; `game/ui/collection_book_panel.gd:44`, `201`, `348`). The physical gate change is limited to harbor; eight future gates remain truthful.
- Tests target actual IO, world construction, collision rays, real movement, signal-driven replacement and separate-process persisted startup. Official runner contracts require exact completion lines and reject engine errors; native fixture records explicitly identify scripted admission data rather than earned cards or human play.

## Issues

### Critical

None found.

### Important

None found.

### Minor

None identified that warrants expanding this change.

## Review checks and evidence

- Read the supplied 164,039-byte immutable package, recovering truncated/unobserved portions in bounded chunks. Did not regenerate its diff. Read all three task reports/reviews and applicable repository instructions.
- Focused context checks addressed named cross-task risks: synchronous save signals causing duplicate replacement; modal close or game callbacks retaining old-world ownership; remaining static ground calls bypassing harbor terrain; optional NPC/toy/water callbacks dereferencing absent controllers; canonical global admission accepting postcards/devil cards. Existing code and the new tests resolve these risks. No additional production callers of region replacement/setter were found.
- Inspected six existing native report summaries: writer 11 captures and restart reader 10 at each of 800x600, 1280x720 and 1920x1080; actual window/viewport dimensions agree and every failures list is empty. Also visually inspected the 800x600 harbor empty-collection capture: the regional empty copy, selector and return control are readable and contained.
- Inspected existing packed writer/restart PASS lines and Windows fresh/saved-harbor/art-smoke logs. Harbor construction reports 40 meshes/90 nodes; forced-welcome art smoke reports welcome construction. Existing welcome material warnings remain visible, not suppressed. Other native, PCK, Windows, Linux, affected-regression and 33 Python-contract results are accepted as the controller/task evidence supplied, not claimed as new executions by this reviewer.
- Tracked working-tree and index diffs were empty. Existing generated imports/UIDs were left untouched. This report is the only write, in the confirmed ignored review directory. No tests, exports, branch changes, commits, pushes or subagents were run.

## Recommendations

Complete the controller-owned README/ticket/evidence closure and commit-metadata check, and resolve the in-progress full CI result before publication. Preserve the exact reviewed-head provenance and scripted-fixture qualifications in that closure. No additional source changes are requested by this review.

## Declined to judge

- New harbor minigames, story, quests, photo sources and visit rewards: explicitly excluded from MAIN-24; their absence is intentional, not approved future implementation.
- Other eight worlds and whole-game completion: outside this two-world travel delivery; no completion claim is made.
- Subjective art quality, audio listening and human gameplay enjoyment: automated runtime/capture evidence does not establish these; this review only checks the observed UI and technical contract.
- Final README/ticket/evidence publication, author metadata and the pending full CI result: explicitly controller-owned and not yet supplied as completed; unseen closure is not approved.
- Reworking the pre-existing welcome material warnings or atomic-save implementation beyond this field's integration: unchanged systems with supplied affected-regression evidence; no new failure or warning suppression was found here.

## Assessment

**Ready to merge? Yes for the reviewed source implementation; final publication remains subject to the controller's outstanding closure/CI/metadata gates.**

The complete branch delivers qualified, save-aware travel to a genuinely independent navigable harbor while preserving welcome behavior and existing progress. No source-level blocking findings remain; this approval covers MAIN-24 at the specified head, not unseen closure edits or the entire game.

Skipped repeat suites, broad repository crawling and human play/listening. Remaining risk is the not-yet-reviewed publication closure and pending full CI outcome, not an identified harbor source defect.
