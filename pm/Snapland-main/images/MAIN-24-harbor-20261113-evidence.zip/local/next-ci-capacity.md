# CI capacity observation for the full game

ST-6 source8512937 run43247479202 passed182Python/104runtimechecks. Actual game-runtime job ran15:24:44–15:49:38UTC (24m54s); workflow job limit30m. The runtime command itself began15:29:10. This is successful evidence, not a timeout or present defect.

Adding116realgames with model/view/lifecycle checks will exceed a single30m job unless execution capacity changes. After MAIN-24, observe its actual job time. If margin is small, open one narrow MAIN ticket for deterministic CI partitioning before more games expand the suite. Keep the local default all-tests path and complete registry/marker/entrypoint checks. No arbitrary test skipping, looser error policy or claim that a subset is the complete suite.

Small candidate: explicit shard index/count parameters validated together; partition stable labels, clean import in every shard, exact union/disjointness coverage assertions, CI matrix with finite jobs. Existing expensive source/asset contract preflight should run once as its own required gate rather than repeated in every shard. All required gates remain required; ordinary default invocation still runs everything. Test missing/duplicate registry coverage, boundary args, filters and marker/error contract unchanged. Tune concrete shard count from measured work, not a general distributed-test framework or new dependency.

Do not open an unrelated warning-cleanup ticket for existing Node/material notices; this observation concerns the30m full-suite capacity required by actual full-game growth.
