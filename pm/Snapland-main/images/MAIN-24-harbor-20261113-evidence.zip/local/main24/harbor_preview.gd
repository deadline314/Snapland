extends SceneTree
var world: Node3D
func _initialize() -> void:
	call_deferred("_run")
func _run() -> void:
	root.content_scale_size = Vector2i(1280,720)
	root.size = Vector2i(1280,720)
	world = load("res://game/world/harbor_world.gd").new()
	root.add_child(world)
	for i in range(8): await process_frame
	await RenderingServer.frame_post_draw
	var folder := OS.get_environment("SNAPLAND_SAVE_PATH").get_base_dir()
	DirAccess.make_dir_recursive_absolute(folder)
	if root.get_texture().get_image().save_png(folder.path_join("harbor-preview.png")) != OK:
		quit(1)
		return
	world.queue_free()
	for i in range(5): await process_frame
	print("PASS: standalone native harbor composition captured")
	quit()
