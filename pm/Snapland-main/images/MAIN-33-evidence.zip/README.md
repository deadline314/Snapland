MAIN33 actual native clearance evidence, 2026-11-18.
Final source532374fbba941da2f266bad4b1b911e9edff19b2a4abee3122e89b181c160344.
Official final run is green-hero20-full only, actual27segments/27originalPNGs, exit0/exactmarker1/0ERROR,15unchanged unsupported-materialwarnings. All other candidate/diagnostic/control runs retain actualfailure and explicit temporary interventions, never substitute for success.
Not human play, hearing, continuous animation or full artistic acceptance. No production/assets/parent/base changes or re-export. Root independently viewed final announcer-third, hero-front and celebrate; source guards and1190otherinputs unchanged. Full reports, exact paths, commands, hashes and logs enclosed.
