# MAIN-33 whole-branch final review

Reviewed 2026-11-18. Base `1cace97`; head `fc829df`. Read the supplied frozen diff package once, the approved spec/plan, SDD ledger, task report and task review. This review covers the caller-only source correction, root-owned specification/plan, completed PM record, three public PNGs and the 40,014,108-byte evidence ZIP. No source, Git, index, HEAD, stage, profile or accepted package was changed; this requested report is the sole review output.

### Spec alignment

- The seven-line source diff implements the measured ruling: NPC callers use the existing helper's 5-degree default; the hero explicitly requests 20 degrees (`game/tests/native_sprite_clearance_review.gd:244`, `:379`, `:382`). Rotating the original offset about UP preserves its vertical component, horizontal radius 6.5 and total distance; looking at the same target preserves pitch. Size 4.8, actor roots, source selections and scene geometry are unchanged. The parameter is internal to an existing fixture helper, with no player option, dependency or new framework.
- The spec explicitly incorporates the second obstruction and the measured NPC/hero split (`design/runtime/native-clearance-occlusion.md:13`, `:15`). This is a justified completion of the full-entry requirement, not a relaxation of it. The unchanged guard/pose methods and top-level constants are compared in the retained audit script; the only permitted avatar-method replacement is the camera argument. The diff contains no changes to body/foot/contact, RGBA8/source, material/UV/depth, visibility or exact-zero-covered checks.
- Native evidence preserves all 27 original segments: twelve NPC frames, three reduced-motion NPC checks, eight hero idle directions, one specified walk sample and three actions. Original pitch sampling and restoration remain in unchanged methods; this does not assert a pose-by-pitch Cartesian product. No speculative exit cleanup was added because the completed run produced no retention/leak error.
- The PM record reports the observable repaired behavior and separates numeric/native evidence from human play or complete artistic acceptance. Its completed delivery checkbox is the root's delivery commitment; merging/pushing and observing the new main CI remain post-review executor steps, rather than facts established by this review. The historical plan checklist is planning context; the ledger is the live execution status.

### Evidence examined

- Read the actual final full/import receipts and full-entry log. Godot 4.7.2 native Vulkan Forward+ identifies the RX 9070 XT; full receipt records exit 0, 0 ERROR and one pass (`.review/main33-native-clearance-20261118/green-hero20-full.json:3`, `:16`, `:18`, `:19`). The log contains exactly 27 depth lines followed by exactly one original completion marker (`green-hero20-full.log:6`, `:33`). All 27 original depth records were read from the D-profile, compared against the audit, and have positive body counts with exactly zero covered pixels. Import independently exited 0 with 0 ERROR.
- Read the private launcher and audit implementation. Engine calls go through `run_validated_godot`; the real Node scene runs without renderer override. Fresh UUID-labelled D stages and an existence assertion on each profile prevent reuse; save/APPDATA/LOCALAPPDATA/TEMP/TMP are absolute and the import/full profiles are separate. The stage uses tracked runtime inventory plus the explicit fixture/helper allowlist.
- Compared RED/GREEN manifest key sets: 1,191 inputs, only the owned child differs, leaving 1,190 unchanged entries. Independently checked the current child's SHA256 against the audit: `532374fbba941da2f266bad4b1b911e9edff19b2a4abee3122e89b181c160344`. Read the audit's repository/stage hash and unchanged-method assertions and its recorded result; did not rerun its artifact-writing script or recrawl every source file. Root's prior source/stage audit remains the evidence for all 1,191 physical file hashes.
- Independently compared the final raw log and receipt hashes with the audit. The archived audit, source, final receipt and final log equal their private originals byte for byte. ZIP CRC check passed; all 166 entries listed in `archive-sha256.json` exist and match their SHA256 values. `README.md` and the hash manifest itself are intentionally outside that list; the README explicitly identifies only `green-hero20-full` as official acceptance.
- All three public PNG hashes occur in the frozen 27-capture map, preserving original captures. Root's independent viewing of announcer-third, hero-front and celebrate is recorded in the ledger and archive README. This reviewer did not duplicate that visual pass.
- Diagnostic interventions are explicit in the retained launcher/report, with raw negative/control evidence separated from the official run. The fountain control's 307 to 0 to 307 and the original hero 0-degree failure support the causal framing decision; no diagnostic visibility manipulation appears in the shipped diff. Rejected candidates remain identified as failures.
- Independently compared raw `WARNING:` lines: 15 in RED and GREEN, exactly identical. The successful log has no `ERROR:`; its nonempty warning output is disclosed rather than called warning-free.

### Strengths

- The implementation fixes the shared framing cause once in the existing helper and adds only the necessary hero argument. It preserves all production assets and behavior and introduces no migration or compatibility burden.
- Verification checks the actual late hero sections and process completion, rather than treating cleared NPC frames or exit status alone as sufficient. The 27 records, captures, source hash and raw receipts agree.
- The failed hypothesis, restored controls, rejected camera candidate and official final are retained separately. This makes the evidence auditable without accepting a hidden-geometry control as success.
- Public documentation is restrained about what native screenshots establish, and the archive preserves exact source/log/capture provenance.

### Issues

#### Critical (Must Fix)

None found.

#### Important (Should Fix)

None found.

#### Minor (Nice to Have)

- **Inherited unsupported-material warning noise; deferred, nonblocking.** `.review/main33-native-clearance-20261118/green-hero20-full.log:34` begins the 15 existing warnings, with the stack pointing to `game/world/occlusion_controller.gd:178`. Unsupported building materials are preserved without cutaway, which makes the native log noisy and leaves that material-support behavior unresolved. All 15 warning lines are identical in RED/GREEN and the source responsible is unchanged, so they are not a regression from this camera correction. Keep the existing disclosure and investigate material support separately if that behavior becomes a requirement; do not widen MAIN-33 or suppress warnings merely to obtain pristine output.

### Recommendations

Proceed with the root-owned delivery steps and observe CI for the actual delivered main revision. Do not substitute the separately recorded successful MAIN-32 CI run for that result. Retain the explicit fixture scope and inherited-warning disclosure. No additional source change or repeated native run is warranted by the reviewed evidence.

### Declined to judge

- Arbitrary gameplay camera positions and all pose/pitch combinations: this change repairs explicitly sampled review viewpoints; no broader camera guarantee is claimed.
- Human play, live input, hearing, continuous animation and complete art naturalness: scripted native captures and numerical guards cannot establish these, and the spec/PM explicitly exclude the claims.
- Existing gameplay placement, authored assets, production occlusion/material behavior and MAIN-32 parent/base design: unchanged by this branch; only their preserved inputs and interfaces are relevant here. The inherited warning symptom is disclosed above rather than silently discarded.
- The uninvestigated obstruction in the rejected uniform 60-degree experiment: the candidate was rejected and is not shipped or counted as success.
- Full-suite, export and cross-device/renderer compatibility: production inputs are unchanged and the affected native fixture has a recorded successful default Forward+ run; the plan intentionally avoids a redundant export/full suite. This is not proof for every GPU/backend.
- Independent reinspection of every original/final image and every physical staged source file: root already performed the specified visual and immutable-source checks; this review checked exact public-image membership, archived final artifacts, manifest deltas and audit implementation instead of duplicating that work.
- Historical accepted-package/profile immutability beyond the recorded fresh-stage procedure and receipts: no filesystem snapshot can independently reconstruct all past writes; no evidence contradicts the recorded isolation, and this reviewer did not open accepted packages for write.
- Post-review merge/push, new-main CI and own-branch cleanup: these are subsequent executor responsibilities. The completed ticket checkbox does not serve as independent evidence that those operations have already happened.
- Inclusion of this final report in the already-frozen public ZIP: the ZIP contains the task review and is accurately labelled; this report did not exist when that snapshot was created. No claim says the frozen archive contains this later review.

### Assessment

**Ready to merge? Yes.**

**Reasoning:** The minimal fixture-only camera correction matches the measured spec, preserves strict checks, and has consistent full-entry native evidence for all original 27 segments with clean completion. No new blocking defect was found; only the already-disclosed, unchanged material warnings remain.

Skipped engine reruns, broad source recrawls, full-suite/export and duplicate image viewing. Residual risk is limited to untested viewpoints/devices and the inherited material behavior; human gameplay and artistic quality are not certified.
