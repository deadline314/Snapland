# SDD ledger — plan: docs/superpowers/plans/2026-11-18-native-clearance-occlusion.md

Branch codex/native-clearance-occlusion-20261118, BASE697bc94, main1cace97537257c9affeea7a667443d1b9ea5412e. MAIN33openingalreadyonmain; statusinprogress/specplanpushed697bc94 beforeimplementation. MAIN32 delivered/branchremoved, mainCI44152447837 pending; ownbranchduplicate44152430442 cancellationrequested. PriorART17main95 sixCIjobsSUCCESS44147397191.

## Preflight

| Task/pair | Producer/consumer and finding | Ruling |
|---|---|---|
| Task1self | rawRED/diagnosticimages vs strictbody0pixel fullGREEN | diagnosticinterventions never publishedsuccess; allgeometry/thresholds restored |
| Task1coverage | camera framing touchesNpc3pitchesandhero24deg helper | fullentryalloriginalsectionsrequired, no simple failingpose skip |
| Task1inheritance | child owns_run; MAIN32 parent826 semanticcode/publichelpers unchanged | compare currentcanonical+rawbefore/after, no parent/basechanges |
| Task1→Task2 | frozenentry+27expectedoriginalsegmentdepth records/captures vs publicevidence | reportactualcount, do not inferpose×pitchCartesianorartapproval |
| Task2self | review+mainGitCIclosure vs useralready-authorizeddelivery | no approvalprompt; currentmainCI observedseparately |

Ruling: diagnose actualrender first; prefer smallest testcamera correction ifforegroundocclusion proven, preserve alloriginalviewpitch/source/contact/depth conditions — no need altergamegeometry; wrongchoice costs anotherexplicitdiagnostic experiment, notplayerdata.

## Status

- [x] Existingticket/specplancommitted+pushed697bc94.
- [x] Task1freshRED/causaldiagnosis/minimalfix/fullnativeGREEN/sourcefreeze/taskreview.
- [ ] Rootindependentimages/evidence/finalreview/PM/Git/mainCI/owncleanup.

NoexistingDstage or acceptedQApackage mutation. Policy-blockedCQAprojectdirectoriesremain; never retrydeletionbypass. Cfree~1.4GB, D~200GB; newheavyartifactsDonly. ActualROOTMain32 source may have GitCRLF normalization aftermain integration; compare current stage/rawhashes and normalized/Gitblob equality, do not rewriteprotected files to matcholderworkingcopybytehashes.

## Task 1 execution / measured framing

Ruling: preserve proven NPC5deg and use hero20deg via one necessary internal parameter in the existing camera helper — fountain base+24 rimtiles control307→0→307 and originalhero0deg569 /5deg170 show two existing scene occluders, no need altergamegeometry/guards or adduseroptions — a wrong choice costs fixture rework, not playerdata.

Producer /root/main33_native_clearance_repair reports frozen532374fbba941da2f266bad4b1b911e9edff19b2a4abee3122e89b181c160344; native fullGREEN16.158s exit0/exactmarker1/0ERROR,27positivebody/0covered records,27PNGs,1190otherinputs unchanged. Details final-audit.json/private run logs; taskreport pending. Root independently viewed final announcerthird/heroidlefront/celebrate rawPNGs, completebody/bootoutlines visible. No audio/resource/leakexiterror: no speculative cleanup. All15 preexisting unsupportedmaterialwarnings identical RED/GREEN; disclose warningcount, no claim pristine warningfree.

MAIN32mainCI44152447837: all6jobs completedSUCCESS, observed throughGitHub connector separately fromprior95.

Task 1: complete — cc4cb30, producer frozen532374…; fresh taskreview /root/main33_task_review spec✅/qualityApproved,0Critical/Important. Report task-1-review.md. Root resolves unchanged-code items by reading audit.py exactmethod/poseguard/source1191hash assertions and actual validated-launcher run.py plus freshprofilereceipts; guards unchanged in actual7linepatch. Historical acceptedpackages never openedforwrite; allDpaths freshlabelled stages. Rootview3finalimages alreadyrecorded; finalwholebranchpending.

Ruling: defer inherited15unsupportedmaterialwarnings — exact RED/GREENlinecomparison and productionunchanged prove this fixturecorrection addsnone; currentmaterialguard preservesunsupportedmaterialssafely — a wrongscopechoice costs futurematerialsupportinvestigation, not maskedtestfailure. Actual0ERROR/cleanexit and warningsdisclosed separately.

Task2rootprogress: public3rawPNGs and evidencearchive prepared, linkscopePASS; nofullsuite/reexport needed for excludedfixtureonly. MAIN33completioncheckrequires finalreview/Gitdeliverystillpending.
