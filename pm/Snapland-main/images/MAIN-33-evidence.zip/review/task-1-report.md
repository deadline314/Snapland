# Task 1 report: native clearance obstruction repair

Completed 2026-11-18, caller-only change on MAIN33 after MAIN32 main1cace97. No worker commits, PM changes, production, parent/base, assets, existing repository import-cache or player-profile edits. Final full native entry succeeded with all original checks.

## Frozen implementation and scope

- Only `game/tests/native_sprite_clearance_review.gd` changed: 4 added / 3 removed lines. Existing camera helper accepts an internal azimuth default5deg for the two NPC callsites; hero caller explicitly uses20deg. The same Vector3 offset is rotated around UP. Existing pitches19.86/27.1/8deg, hero24deg, horizontal radius6.5, pitch-dependent3D distance and orthographic size4.8 remain intact. Actor roots, source textures, UVs and geometry remain intact.
- Final source SHA256 `532374fbba941da2f266bad4b1b911e9edff19b2a4abee3122e89b181c160344`. Frozen full source and diff: `.review/main33-native-clearance-20261118/final-source.txt`, `final-owned.diff`. All methods, pose lists, source/format/feet/material/depth/contact/visibility predicates match RED verbatim except hero camera call and camera helper. Exact depth0.10 / color0.035 thresholds and zero-covered requirement are unchanged.
- Formal reduced standing RGBA8/source447/anchor448 within-one-pixel contract remains unchanged. Twelve specified legacy full-body frames, three formal reduced frames with restoration, eight hero idle directions, one specified walk frame5-of8, photograph/wave/celebrate still execute. This is the original sampling, not all pose×pitch combinations.
- Successful exit had no audio retention/resource/leak errors. No speculative cleanup or base/Main quit change was made. Existing watchdog and failure behavior remain unchanged.

## Fresh RED, raw GPU evidence and causal control

1. Fresh tracked-runtime stage plus exact six-file fixture/helper allowlist, current MAIN32 parent: untouched full RED reproduced **307/47406** hidden body pixels on announcer frame2 at8deg. Exit1, one original guard ERROR, no completion marker. RED sourceSHA6526bcf3f35e4dd36e864fdd98748e8dd058f689d5bbf80d1762e3f38872f225. Raw `.review/main33-native-clearance-20261118/red-full.log` and matchingJSON retain exact command/profile/child hash.
2. Separate diagnostic stage instruments readback only; no threshold changes or failure bypass. Raw normal/alone/blank PNGs at `D:/Snapland-QA/main33-diagnostic-20261118-95956bd8-profiles/diagnostic-full/`. Mismatchbbox **(527,494),24×33**, left extended boot. Camera(3.4,2.193515,2.5), rotation(-0.139626,0,0), size4.8; actor root(3.4,0,-4), sprite(3.4,1.424909,-4). Viewing normal vs alone confirmed fountain edge over the boot; blank contains HUD only. Original texture is a generated Texture2D without resource_path; frozen runtime manifest and unchanged frame selection retain actual source provenance.
3. First private control hid the unique fountain base CylinderMesh at(0,.45,0), radius2.8,height.6. **307→303**, restore→307: only4 pixels belonged to the base. This disproved the narrower base-only hypothesis.
4. Second private control hid exactly that base plus24 raised BoxMesh rim tiles (y.79,radialdistance2.57,size.47/.07/.2). **307→0**, restore→307. Exact25 candidates asserted; original visibilities, sprite layers and camera cull restored before original guard failed. Evidence/controlJSON and unmodified before/without/restored PNGs: `D:/Snapland-QA/main33-rim-control-20261118-683263ea-profiles/rim-control-full/`. These explicitly diagnostic failures are never acceptance GREEN.
5. Normal5deg candidate cleared all12 NPC and3 reduced segments, then the newly reached hero idle/front failed **170/28007**. Raw normal/alone/blank and bbox **(585,554),93×20** retained at `D:/Snapland-QA/main33-diagnostic-hero-20261118-28c5e208-profiles/diagnostic-hero-full/`. Pixels are at shoes, not chest/hair; production hero material motion already0. No reference-ownership/predicate change was needed.
6. A private original0deg hero counterfactual retained5deg NPC cameras solely to reach the same hero method/setup; all original checks still ran. Original hero failed **569/28007**, bbox **(586,554),67×20**, confirming a preexisting hero framing obstruction. Raw triples at `D:/Snapland-QA/main33-hero-zero-20261118-4e890883-profiles/hero-zero-full/`. It is not a full baseline or acceptance substitute.
7. Ray/triangle diagnostic at actual mismatching5deg pixels located foreground `StoryLandmarks/Signpost_avenue`: CylinderMesh post at(0,1.07,-19.4), radius.09,height2.14 on left shoe; BoxMesh sign plank at(.266,1.72,-19.666),size(.9,.18,.06) on right shoe. `hero-rays.json` in `D:/Snapland-QA/main33-hero-rays-20261118-98f8c331-profiles/hero-rays-full/` retains hit locations, distances, nodepaths and AABBs. Raw GPU normal shows the post overlapping the left shoe, with the plank producing the small right-foot patch.
8. Uniform60deg was tested and rejected: ticket frame0 failed1930/46951 before later sections. No claim identifies that uninvestigated occluder. This supplied evidence that one uniform large rotation does not complete the original fixture. Root accepted the smallest helper reuse: NPC5deg, hero20deg, no new user option/config/framework. All rejected candidates and original failure logs/sources remain frozen.

## Actual final full native GREEN

Fresh import and then real Node `.tscn` GPU entry, no diagnostic code/hiding/overrides, exact source above:

```text
C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --path D:/Snapland-QA/main33-green-hero20-20261118-2ced186b res://game/tests/native_sprite_clearance_review.tscn
```

- Driver `.review/main33-native-clearance-20261118/run.py green-hero20` calls `tools.godot_entrypoints.run_validated_godot` for every engine process. Version header4.7.2.stable.official.ed1daf0bf; Vulkan1.4.359 Forward+ AMD Radeon RX9070XT; no renderer override. The preceding fresh import exit0/0ERROR is recorded separately.
- Full entry exit0 in16.158s, **27 original segments/27 captures**, all positive body and0covered, exact original one completion marker. **0ERROR, no leak/resource/audio retention message**. Fifteen existing unsupported-building-material warnings are line-identical to untouched RED; they preserve unsupported materials without cutaway.
- Exact environment (fresh absolute D SNAPLAND_SAVE_PATH/APPDATA/LOCALAPPDATA/TEMP/TMP), full command, elapsed time, source hash are in `green-hero20-full.json`; raw stdout/stderr in `green-hero20-full.log`. No player save or historical ART15 image was overwritten.
- Final depth records `D:/Snapland-QA/main33-green-hero20-20261118-2ced186b-profiles/green-hero20-full/sprite-depth-coverage.json`; original unedited PNGs `D:/Snapland-QA/main33-green-hero20-20261118-2ced186b-profiles/green-hero20-full/captures/`. Paths and SHA256 of all27 captures, plus all diagnostic/control rawPNG hashes, are frozen in `final-audit.json`.

| Original segment | Body pixels | Covered pixels |
|---|---:|---:|
| NPC ticket frame 0 | 46951 | 0 |
| NPC ticket frame 1 | 48097 | 0 |
| NPC ticket frame 2 | 47941 | 0 |
| NPC ticket frame 3 | 45510 | 0 |
| NPC imp frame 0 | 44650 | 0 |
| NPC imp frame 1 | 44184 | 0 |
| NPC imp frame 2 | 45242 | 0 |
| NPC imp frame 3 | 44808 | 0 |
| NPC announcer frame 0 | 46364 | 0 |
| NPC announcer frame 1 | 44899 | 0 |
| NPC announcer frame 2 | 47406 | 0 |
| NPC announcer frame 3 | 43476 | 0 |
| reduced-motion NPC ticket | 46215 | 0 |
| reduced-motion NPC imp | 29752 | 0 |
| reduced-motion NPC announcer | 26749 | 0 |
| hero idle/front | 28007 | 0 |
| hero idle/front_right | 30312 | 0 |
| hero idle/right | 25889 | 0 |
| hero idle/back_right | 27300 | 0 |
| hero idle/back | 28523 | 0 |
| hero idle/back_left | 27090 | 0 |
| hero idle/left | 26435 | 0 |
| hero idle/front_left | 30230 | 0 |
| hero walk/front_right/5-of-8 | 30693 | 0 |
| hero photograph | 40622 | 0 |
| hero wave | 41013 | 0 |
| hero celebrate | 37283 | 0 |

## Run/source receipts

Each label has `-import.json/.log` and `-full.json/.log`, copied-source manifest, actual `-stage-source.txt`, original caller snapshot and distinct Dstage location under `.review/main33-native-clearance-20261118/`. Diagnostic actual source hashes differ from copied-source manifest only by explicitly recorded stage instrumentation. Every new stage was made with `prepare_runtime_stage` from current read-only `git ls-files` runtime inventory, plus exact allowlist `native_sprite_clearance_review.gd/.tscn`, `native_npc_review.gd`, `native_layout_review.gd`, `native_review.gd`, `audio_playback_release.gd`. No whole-repo copy, existing-stage mutation/reuse/delete or Cimport.

| Full run label | Exit | ERROR count | Seconds | Actual staged childSHA256 |
|---|---:|---:|---:|---|
| red | 1 | 1 | 8.587 | `6526bcf3f35e4dd36e864fdd98748e8dd058f689d5bbf80d1762e3f38872f225` |
| diagnostic | 1 | 1 | 8.979 | `0aabc1ed9e09c78dd7842a4d039b1b60b79e22ce678600ea8292f326e1b05909` |
| control | 1 | 1 | 9.366 | `9ca76efba2f4002219538fc1d84c28d3da02580c36f979f08358fb5d4c44a4db` |
| rim-control | 1 | 1 | 9.453 | `3f3bba48a600c4594fc232039d83d1835c1e78da02a20fd508324b10461ca046` |
| green-camera | 1 | 1 | 10.61 | `9c7bedb43a32a9a2ec0bde267cb66b6cd8130ebbc50282c7468704872795217c` |
| diagnostic-hero | 1 | 1 | 10.878 | `743f20c72e3ba8b1cd0f9a55345997918d34235091aa9b112066a771cb2e5539` |
| hero-rays | 1 | 1 | 10.639 | `22f79da354483c4b89e8baf7c4fedd77ae92582d870b9be83f8248dc7bc468cd` |
| hero-zero | 1 | 1 | 10.57 | `f52bd4fcbc21d256d9332e4acb546080dfdd6f781db79202fb65765ac8f9f95e` |
| green-camera60 | 1 | 1 | 5.304 | `28b9856ab86d72dae251d1f0aed3b03db208ad0b5da5b835a2d1640fb53e9fed` |
| green-hero20 | 0 | 0 | 16.158 | `532374fbba941da2f266bad4b1b911e9edff19b2a4abee3122e89b181c160344` |

## Source/dependency and state audit

`python .review/main33-native-clearance-20261118/audit.py` PASS:1190 other copied tracked runtime/dependency/parent/fixture sources unchanged between RED and GREEN. All1191 manifest file hashes match both repository and finalDstage after import/run. Audit asserts exact original27 description order, positive body0covered, 27PNGs, exact completion marker and noERROR/leak strings; all old method bodies except the necessary camera call/helper match verbatim. Numerical rotation self-check asserts original pitch, horizontal radius and3D distance for every used pitch and both final azimuths.

- `game/tests/native_sprite_clearance_review.tscn`: `dfa802d93744e52ce117a48470cc6abae544fa7992c11254d9c2c53e22d99c58`
- `game/tests/native_npc_review.gd`: `82627ce65faec3b550fa071e51311059f4e279665fa45b8c5d2a9d49af65875d`
- `game/tests/native_layout_review.gd`: `0b7b35d2e71c4fbdc02d5e0c1563d9744718b03eeb8f3f09e439cea90016b38c`
- `game/tests/native_review.gd`: `4ee8d7f4bbe3f27c6c22354797306aec394b5378ac48197687111be00106f242`
- `game/tests/audio_playback_release.gd`: `1b61bba4e5c54e38050e8ba0b7170b18848198928937ca2c4dfdebc31cc37184`

Coverage routine restores sprite visibility/layers/camera cull exactly as before; diagnostic receipts independently confirm these states after raw readback and controlled restore. Source/state/root/material/UV checks are unchanged and actually passed in final full run. The fixture deliberately positions its camera and hero, pauses activity/world physics and selects legacy poses as before; it is not a claim that the whole live scene camera is returned to a prior gameplay state.

## Visual self-review, limits and concerns

Worker viewed original raw announcer normal/alone/blank and hero normal/alone, then final announcer third, imp third, all3 formal reduced images, hero idle/front, walk/front_right5of8 and celebrate. Heads, clothing, full limbs and feet are in-frame and unobstructed in these samples. Announcer left boot has a visible gap from fountain rim; hero shoes are clear of shifted signpost; standing sources remain complete full-body sprites. Root independently reviews representative raw/final images and owns PM/archive/review/delivery gates.

No full test suite, export, human playthrough, live input, continuous animation/art-naturalness review, hearing or performance claim. Camera choices are explicit review fixtures; broader arbitrary world camera/pose combinations are outside this request. Known15 unsupported-material warnings persist identically. No speculative audio cleanup, production/source repair, threshold/predicate relaxation or geometry hiding was shipped.
