## Task 1: Actual diagnosis, minimal correction and full native verification

**Ownership:** game/tests/native_sprite_clearance_review.gd only; private .review/main33-native-clearance-20261118 and new Dstages. Root owns others/Git/PM.

- [ ] Read spec, currententry/callers/parent interfaces and actualdepth/reference/contact path. Root read-only seed .review/main33-native-clearance-20261118/read-only-seed.md contains sourcefacts and an explicitly unproved foreground-fountain hypothesis; trust no hypothesis without rawGPUevidence.
- [ ] Fresh baseline fullentry RED via currentparent fromMAIN32; preserve code/command/save/profile/sourcehash/rawlog. Capture failing normal/alone/blank unmodifiedGPUimages and differingpixelbbox in separate explicitlydiagnostic Dvariant without changingCsource or test thresholds. Identify actual occluder; controlled A/B ifnecessary must restorestate and nevercountasofficialGREEN.
- [ ] Smallest proven fix in existingentry. If framing caused it, prefer existingcamera vector rotation/azimuth preservingpitch/distance/size and body/source/root state. Keep all threepitch values and exact depth/foot/body guards; no source-replacement or predicatewaiver.
- [ ] Run fresh published fullentry GREEN covering all originalNPC/reduced/hero sections with exact existing completion marker, zeroERROR/leaks and retained depth counts/captures. If a later unrelated assumption blocks currentfullpath, reportnarrow scopebeforetouchingotherfiles; do not silentlydropchecks. This task owns fullentry's needed fixes, not newplayerfeatures.
- [ ] If actual success exit shows nativeaudio retention, reuse inherited sharedRelease or existinghelper capture/shutdown/free/two-frame/wait in thisentry; no base/Mainquit changes. Keep failure/watchdog correct. No speculative masscleanup.
- [ ] Verifyimport/entry, frozenruntime/parent/dependencyhashes, actual source and camera/state restoration. Worker inspectrepresentativefailed/new foot/body images; root independentlyreview finalsamples. Fullnative oncepassingneednotrepeatwithoutnewchange/failure.
- [ ] Write task1report with causalRED/GREEN/control experiments/sourcehashes/actualsegmentcounts/capturepaths/selfreview/limits and frozenfinaldiff. No commits byworker. Fresh taskreview then mostcapablefinalwholebranchreview byroot.

