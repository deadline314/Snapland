"""Write the authorized task handoff from frozen receipts, without changing product/docs."""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
audit = json.loads((HERE / "final-audit.json").read_text())
stage = Path(audit["stage"]).as_posix()
profile = Path(audit["profile"]).as_posix()
rows = []
for label in ["red","diagnostic","control","rim-control","green-camera","diagnostic-hero","hero-rays","hero-zero","green-camera60","green-hero20"]:
    result = json.loads((HERE / (label + "-full.json")).read_text())
    rows.append(f'| {label} | {result["exit"]} | {result["errors"]} | {result["seconds"]} | `{result["child_sha256"]}` |')
counts = "\n".join(f'| {r["description"]} | {r["body_pixels"]} | {r["covered_pixels"]} |' for r in audit["segments"])
parents = "\n".join(f'- `{name}`: `{digest}`' for name,digest in audit["parent_and_dependencies"].items())
text = f'''# Task 1 report: native clearance obstruction repair

Completed 2026-11-18, caller-only change on MAIN33 after MAIN32 main1cace97. No worker commits, PM changes, production, parent/base, assets, existing repository import-cache or player-profile edits. Final full native entry succeeded with all original checks.

## Frozen implementation and scope

- Only `game/tests/native_sprite_clearance_review.gd` changed: 4 added / 3 removed lines. Existing camera helper accepts an internal azimuth default5deg for the two NPC callsites; hero caller explicitly uses20deg. The same Vector3 offset is rotated around UP. Existing pitches19.86/27.1/8deg, hero24deg, horizontal radius6.5, pitch-dependent3D distance and orthographic size4.8 remain intact. Actor roots, source textures, UVs and geometry remain intact.
- Final source SHA256 `{audit["child_sha256"]}`. Frozen full source and diff: `.review/main33-native-clearance-20261118/final-source.txt`, `final-owned.diff`. All methods, pose lists, source/format/feet/material/depth/contact/visibility predicates match RED verbatim except hero camera call and camera helper. Exact depth0.10 / color0.035 thresholds and zero-covered requirement are unchanged.
- Formal reduced standing RGBA8/source447/anchor448 within-one-pixel contract remains unchanged. Twelve specified legacy full-body frames, three formal reduced frames with restoration, eight hero idle directions, one specified walk frame5-of8, photograph/wave/celebrate still execute. This is the original sampling, not all pose×pitch combinations.
- Successful exit had no audio retention/resource/leak errors. No speculative cleanup or base/Main quit change was made. Existing watchdog and failure behavior remain unchanged.

## Fresh RED, raw GPU evidence and causal control

1. Fresh tracked-runtime stage plus exact six-file fixture/helper allowlist, current MAIN32 parent: untouched full RED reproduced **307/47406** hidden body pixels on announcer frame2 at8deg. Exit1, one original guard ERROR, no completion marker. RED sourceSHA6526bcf3f35e4dd36e864fdd98748e8dd058f689d5bbf80d1762e3f38872f225. Raw `.review/main33-native-clearance-20261118/red-full.log` and matchingJSON retain exact command/profile/child hash.
2. Separate diagnostic stage instruments readback only; no threshold changes or failure bypass. Raw normal/alone/blank PNGs at `D:/Snapland-QA/main33-diagnostic-20261118-95956bd8-profiles/diagnostic-full/`. Mismatchbbox **(527,494),24×33**, left extended boot. Camera(3.4,2.193515,2.5), rotation(-0.139626,0,0), size4.8; actor root(3.4,0,-4), sprite(3.4,1.424909,-4). Viewing normal vs alone confirmed fountain edge over the boot; blank contains HUD only. Original texture is a generated Texture2D without resource_path; frozen runtime manifest and unchanged frame selection retain actual source provenance.
3. First private control hid the unique fountain base CylinderMesh at(0,.45,0), radius2.8,height.6. **307→303**, restore→307: only4 pixels belonged to the base. This disproved the narrower base-only hypothesis.
4. Second private control hid exactly that base plus24 raised BoxMesh rim tiles (y.79,radialdistance2.57,size.47/.07/.2). **307→0**, restore→307. Exact25 candidates asserted; original visibilities, sprite layers and camera cull restored before original guard failed. Evidence/controlJSON and unmodified before/without/restored PNGs: `D:/Snapland-QA/main33-rim-control-20261118-683263ea-profiles/rim-control-full/`. These explicitly diagnostic failures are never acceptance GREEN.
5. Normal5deg candidate cleared all12 NPC and3 reduced segments, then the newly reached hero idle/front failed **170/28007**. Raw normal/alone/blank and bbox **(585,554),93×20** retained at `D:/Snapland-QA/main33-diagnostic-hero-20261118-28c5e208-profiles/diagnostic-hero-full/`. Pixels are at shoes, not chest/hair; production hero material motion already0. No reference-ownership/predicate change was needed.
6. A private original0deg hero counterfactual retained5deg NPC cameras solely to reach the same hero method/setup; all original checks still ran. Original hero failed **569/28007**, bbox **(586,554),67×20**, confirming a preexisting hero framing obstruction. Raw triples at `D:/Snapland-QA/main33-hero-zero-20261118-4e890883-profiles/hero-zero-full/`. It is not a full baseline or acceptance substitute.
7. Ray/triangle diagnostic at actual mismatching5deg pixels located foreground `StoryLandmarks/Signpost_avenue`: CylinderMesh post at(0,1.07,-19.4), radius.09,height2.14 on left shoe; BoxMesh sign plank at(.266,1.72,-19.666),size(.9,.18,.06) on right shoe. `hero-rays.json` in `D:/Snapland-QA/main33-hero-rays-20261118-98f8c331-profiles/hero-rays-full/` retains hit locations, distances, nodepaths and AABBs. Raw GPU normal shows the post overlapping the left shoe, with the plank producing the small right-foot patch.
8. Uniform60deg was tested and rejected: ticket frame0 failed1930/46951 before later sections. No claim identifies that uninvestigated occluder. This supplied evidence that one uniform large rotation does not complete the original fixture. Root accepted the smallest helper reuse: NPC5deg, hero20deg, no new user option/config/framework. All rejected candidates and original failure logs/sources remain frozen.

## Actual final full native GREEN

Fresh import and then real Node `.tscn` GPU entry, no diagnostic code/hiding/overrides, exact source above:

```text
C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --path {stage} res://game/tests/native_sprite_clearance_review.tscn
```

- Driver `.review/main33-native-clearance-20261118/run.py green-hero20` calls `tools.godot_entrypoints.run_validated_godot` for every engine process. Version header4.7.2.stable.official.ed1daf0bf; Vulkan1.4.359 Forward+ AMD Radeon RX9070XT; no renderer override. The preceding fresh import exit0/0ERROR is recorded separately.
- Full entry exit0 in16.158s, **27 original segments/27 captures**, all positive body and0covered, exact original one completion marker. **0ERROR, no leak/resource/audio retention message**. Fifteen existing unsupported-building-material warnings are line-identical to untouched RED; they preserve unsupported materials without cutaway.
- Exact environment (fresh absolute D SNAPLAND_SAVE_PATH/APPDATA/LOCALAPPDATA/TEMP/TMP), full command, elapsed time, source hash are in `green-hero20-full.json`; raw stdout/stderr in `green-hero20-full.log`. No player save or historical ART15 image was overwritten.
- Final depth records `{profile}/sprite-depth-coverage.json`; original unedited PNGs `{profile}/captures/`. Paths and SHA256 of all27 captures, plus all diagnostic/control rawPNG hashes, are frozen in `final-audit.json`.

| Original segment | Body pixels | Covered pixels |
|---|---:|---:|
{counts}

## Run/source receipts

Each label has `-import.json/.log` and `-full.json/.log`, copied-source manifest, actual `-stage-source.txt`, original caller snapshot and distinct Dstage location under `.review/main33-native-clearance-20261118/`. Diagnostic actual source hashes differ from copied-source manifest only by explicitly recorded stage instrumentation. Every new stage was made with `prepare_runtime_stage` from current read-only `git ls-files` runtime inventory, plus exact allowlist `native_sprite_clearance_review.gd/.tscn`, `native_npc_review.gd`, `native_layout_review.gd`, `native_review.gd`, `audio_playback_release.gd`. No whole-repo copy, existing-stage mutation/reuse/delete or Cimport.

| Full run label | Exit | ERROR count | Seconds | Actual staged childSHA256 |
|---|---:|---:|---:|---|
{chr(10).join(rows)}

## Source/dependency and state audit

`python .review/main33-native-clearance-20261118/audit.py` PASS:1190 other copied tracked runtime/dependency/parent/fixture sources unchanged between RED and GREEN. All1191 manifest file hashes match both repository and finalDstage after import/run. Audit asserts exact original27 description order, positive body0covered, 27PNGs, exact completion marker and noERROR/leak strings; all old method bodies except the necessary camera call/helper match verbatim. Numerical rotation self-check asserts original pitch, horizontal radius and3D distance for every used pitch and both final azimuths.

{parents}

Coverage routine restores sprite visibility/layers/camera cull exactly as before; diagnostic receipts independently confirm these states after raw readback and controlled restore. Source/state/root/material/UV checks are unchanged and actually passed in final full run. The fixture deliberately positions its camera and hero, pauses activity/world physics and selects legacy poses as before; it is not a claim that the whole live scene camera is returned to a prior gameplay state.

## Visual self-review, limits and concerns

Worker viewed original raw announcer normal/alone/blank and hero normal/alone, then final announcer third, imp third, all3 formal reduced images, hero idle/front, walk/front_right5of8 and celebrate. Heads, clothing, full limbs and feet are in-frame and unobstructed in these samples. Announcer left boot has a visible gap from fountain rim; hero shoes are clear of shifted signpost; standing sources remain complete full-body sprites. Root independently reviews representative raw/final images and owns PM/archive/review/delivery gates.

No full test suite, export, human playthrough, live input, continuous animation/art-naturalness review, hearing or performance claim. Camera choices are explicit review fixtures; broader arbitrary world camera/pose combinations are outside this request. Known15 unsupported-material warnings persist identically. No speculative audio cleanup, production/source repair, threshold/predicate relaxation or geometry hiding was shipped.
'''
(ROOT / ".superpowers/sdd/2026-11-18-native-clearance-occlusion/task-1-report.md").write_text(text,encoding="utf-8")
print("Wrote authorized task-1-report.md")
