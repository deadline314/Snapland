from pathlib import Path
import json,zipfile,hashlib
root=Path.cwd()
private=root/'.review/main33-native-clearance-20261118'
workspace=root/'.superpowers/sdd/2026-11-18-native-clearance-occlusion'
a=json.loads((private/'final-audit.json').read_text())
entries={}
for p in private.iterdir():
 if p.is_file(): entries['runs/'+p.name]=p
for p in workspace.iterdir():
 if p.is_file(): entries['review/'+p.name]=p
for src,digest in a['captures'].items():
 p=Path(src);assert hashlib.sha256(p.read_bytes()).hexdigest()==digest
 entries['final-captures/'+p.name]=p
for src,digest in a['raw_diagnostic_captures'].items():
 p=Path(src);assert hashlib.sha256(p.read_bytes()).hexdigest()==digest
 entries['diagnostic-captures/'+p.parent.name+'/'+p.name]=p
profile=Path(a['profile'])
entries['final-depth-records.json']=profile/'sprite-depth-coverage.json'
for receipt in private.glob('*-full.json'):
 profile_path=Path(json.loads(receipt.read_text(encoding='utf-8'))['environment']['SNAPLAND_SAVE_PATH']).parent
 for p in profile_path.glob('*.json'):
  if p.name != 'progress.json': entries['profile-receipts/'+receipt.stem+'/'+p.name]=p
for rel in ['design/runtime/native-clearance-occlusion.md','docs/superpowers/plans/2026-11-18-native-clearance-occlusion.md','pm/Snapland-main/[MAIN-33]修復原生接地檢視遮擋.md']:
 entries['delivery/'+Path(rel).name]=root/rel
out=root/'pm/Snapland-main/images/MAIN-33-evidence.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 z.writestr('README.md', 'MAIN33 actual native clearance evidence, 2026-11-18.\nFinal source532374fbba941da2f266bad4b1b911e9edff19b2a4abee3122e89b181c160344.\nOfficial final run is green-hero20-full only, actual27segments/27originalPNGs, exit0/exactmarker1/0ERROR,15unchanged unsupported-materialwarnings. All other candidate/diagnostic/control runs retain actualfailure and explicit temporary interventions, never substitute for success.\nNot human play, hearing, continuous animation or full artistic acceptance. No production/assets/parent/base changes or re-export. Root independently viewed final announcer-third, hero-front and celebrate; source guards and1190otherinputs unchanged. Full reports, exact paths, commands, hashes and logs enclosed.\n')
 manifest={}
 for name,p in sorted(entries.items()):
  data=p.read_bytes();z.writestr(name,data);manifest[name]=hashlib.sha256(data).hexdigest()
 z.writestr('archive-sha256.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 manifest=json.loads(z.read('archive-sha256.json'))
 assert all(hashlib.sha256(z.read(k)).hexdigest()==v for k,v in manifest.items())
print('archive',out.stat().st_size,'bytes',hashlib.sha256(out.read_bytes()).hexdigest(),'entries',len(manifest))
