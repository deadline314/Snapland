"""Private MAIN33 fresh-stage runs; diagnostic variants never count as full acceptance."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import uuid

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from tools.build_desktop_release import prepare_runtime_stage
from tools.godot_entrypoints import run_validated_godot

HERE = Path(__file__).resolve().parent
ENGINE = "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe"
CHILD = "game/tests/native_sprite_clearance_review.gd"
ALLOW = ["native_sprite_clearance_review.gd", "native_sprite_clearance_review.tscn",
         "native_npc_review.gd", "native_layout_review.gd", "native_review.gd", "audio_playback_release.gd"]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run(stage, label, imported=False):
    profile = stage.parent / (stage.name + "-profiles") / label
    assert not profile.exists()
    env = dict(os.environ, SNAPLAND_SAVE_PATH=str(profile / "progress.json"),
               APPDATA=str(profile / "appdata"), LOCALAPPDATA=str(profile / "localappdata"),
               TEMP=str(profile / "temp"), TMP=str(profile / "temp"))
    for key in ["APPDATA", "LOCALAPPDATA", "TEMP"]:
        Path(env[key]).mkdir(parents=True)
    cmd = [ENGINE, "--path", str(stage)] + (["--headless", "--editor", "--import", "--quit"] if imported else ["res://game/tests/native_sprite_clearance_review.tscn"])
    started = time.monotonic()
    result = run_validated_godot(stage, cmd, env, 300 if imported else 210)
    output = result.stdout + result.stderr
    receipt = dict(label=label, command=cmd, environment={k: env[k] for k in ["SNAPLAND_SAVE_PATH", "APPDATA", "LOCALAPPDATA", "TEMP", "TMP"]},
                   exit=result.returncode, seconds=round(time.monotonic()-started,3), errors=output.count("ERROR:"), passes=output.count("PASS:"),
                   child_sha256=digest(stage / CHILD))
    (HERE / (label + ".log")).write_text(output, encoding="utf-8")
    (HERE / (label + ".json")).write_text(json.dumps(receipt, indent=2), encoding="utf-8")
    print(json.dumps(receipt), flush=True)
    return receipt

def diagnose(source):
    source = source.replace("\tvar body_pixels := 0", "\tvar mismatch_bounds := Rect2i()\n\tvar body_pixels := 0")
    source = source.replace("\t\t\t\tcovered_pixels += 1", "\t\t\t\tcovered_pixels += 1\n\t\t\t\tvar pixel_rect := Rect2i(x, y, 1, 1)\n\t\t\t\tmismatch_bounds = pixel_rect if covered_pixels == 1 else mismatch_bounds.merge(pixel_rect)")
    needle = "\tvar ratio := float(covered_pixels)/float(maxi(body_pixels,1))"
    extra = '''
	if covered_pixels != 0:
		var directory := OS.get_environment("SNAPLAND_SAVE_PATH").get_base_dir()
		normal.save_png(directory.path_join("diagnostic-normal.png"))
		alone.save_png(directory.path_join("diagnostic-alone.png"))
		blank.save_png(directory.path_join("diagnostic-blank.png"))
		var metadata := {"description": description, "mismatch_bounds": str(mismatch_bounds), "camera_position": str(camera.position), "camera_rotation": str(camera.rotation), "camera_size": camera.size, "sprite_position": str(sprite.global_position), "root_position": str(sprite.get_parent().get_parent().global_position), "texture": sprite.texture.resource_path, "restored_layers": sprite.layers == saved_layers, "restored_cull": camera.cull_mask == saved_cull, "restored_visibility": sprite.visible}
		var receipt := FileAccess.open(directory.path_join("diagnostic.json"), FileAccess.WRITE)
		receipt.store_string(JSON.stringify(metadata, "  "))
		print("DIAGNOSTIC ", metadata)
'''
    assert needle in source
    return source.replace(needle, extra + needle)

def control(source):
    source = diagnose(source)
    needle = '\t\tprint("DIAGNOSTIC ", metadata)'
    extra = '''
		var candidates: Array[MeshInstance3D] = []
		for visual in main.world.find_children("*", "MeshInstance3D", true, false):
			if visual.mesh is CylinderMesh and visual.global_position.distance_to(Vector3(0, 0.45, 0)) < 0.0001 and is_equal_approx(visual.mesh.top_radius, 2.8) and is_equal_approx(visual.mesh.height, 0.6):
				candidates.append(visual)
		assert(candidates.size() == 1, "Control must identify exactly the fountain base")
		var base := candidates[0]
		var was_visible := base.visible
		base.visible = false
		await RenderingServer.frame_post_draw
		var without_base := get_viewport().get_texture().get_image()
		without_base.save_png(directory.path_join("control-without-fountain-base.png"))
		base.visible = was_visible
		await RenderingServer.frame_post_draw
		var restored := get_viewport().get_texture().get_image()
		restored.save_png(directory.path_join("control-restored.png"))
		var control_receipt := {"intervention": "Private diagnostic only: hide one CylinderMesh fountain base at (0,0.45,0), radius2.8,height0.6; restore before original failure", "path": str(base.get_path()), "without_base_covered": _diagnostic_mismatches(without_base, alone, blank), "restored_covered": _diagnostic_mismatches(restored, alone, blank), "visibility_restored": base.visible == was_visible, "camera_cull_restored": camera.cull_mask == saved_cull, "sprite_layers_restored": sprite.layers == saved_layers}
		var control_file := FileAccess.open(directory.path_join("control.json"), FileAccess.WRITE)
		control_file.store_string(JSON.stringify(control_receipt, "  "))
		print("PRIVATE CONTROL ONLY ", control_receipt)
'''
    source = source.replace(needle, needle + extra)
    source += '''
func _diagnostic_mismatches(normal: Image, alone: Image, blank: Image) -> int:
	var count := 0
	for y in range(alone.get_height()):
		for x in range(alone.get_width()):
			var a := alone.get_pixel(x,y)
			var b := blank.get_pixel(x,y)
			if maxf(absf(a.r-b.r), maxf(absf(a.g-b.g),absf(a.b-b.b))) < 0.10: continue
			var n := normal.get_pixel(x,y)
			if maxf(absf(a.r-n.r),maxf(absf(a.g-n.g),absf(a.b-n.b))) > 0.035: count += 1
	return count
'''
    return source

def rim_control(source):
    source = control(source)
    source = source.replace('candidates.append(visual)', '''candidates.append(visual)
			elif visual.mesh is BoxMesh and absf(visual.global_position.y - 0.79) < 0.0001 and absf(Vector2(visual.global_position.x, visual.global_position.z).length() - 2.57) < 0.0001 and visual.mesh.size.distance_to(Vector3(0.47,0.07,0.2)) < 0.0001:
				candidates.append(visual)''')
    source = source.replace('assert(candidates.size() == 1, "Control must identify exactly the fountain base")', 'assert(candidates.size() == 25, "Control must identify exactly fountain base and 24 rim tiles")')
    source = source.replace('base.visible = false', 'for candidate in candidates: candidate.visible = false')
    source = source.replace('base.visible = was_visible', 'for candidate in candidates: candidate.visible = was_visible')
    source = source.replace('"visibility_restored": base.visible == was_visible', '"visibility_restored": candidates.all(func(candidate: MeshInstance3D): return candidate.visible == was_visible), "candidate_count": candidates.size()')
    source = source.replace('hide one CylinderMesh fountain base at (0,0.45,0), radius2.8,height0.6', 'hide exact fountain base plus24 raised rim tiles (y.79,radius2.57,size.47/.07/.2)')
    return source

def hero_rays(source):
    source = diagnose(source)
    needle = '\t\tprint("DIAGNOSTIC ", metadata)'
    extra = '''
		var hits_by_pixel := {}
		for pixel in [Vector2(588.5,560.5),Vector2(672.5,572.5)]:
			var ray_start := camera.project_ray_origin(pixel)
			var ray_end := ray_start + camera.project_ray_normal(pixel) * 40.0
			var hits: Array = []
			for visual in main.world.find_children("*", "MeshInstance3D", true, false):
				if not visual.is_visible_in_tree() or visual.mesh == null: continue
				var start: Vector3 = visual.to_local(ray_start)
				var end: Vector3 = visual.to_local(ray_end)
				if not visual.get_aabb().intersects_segment(start,end): continue
				var faces: PackedVector3Array = visual.mesh.get_faces()
				var nearest := INF
				var hit_point := Vector3.ZERO
				for i in range(0, faces.size(), 3):
					var hit = Geometry3D.segment_intersects_triangle(start,end,faces[i],faces[i+1],faces[i+2])
					if hit == null: continue
					var point: Vector3 = visual.to_global(hit)
					var distance := point.distance_to(ray_start)
					if distance < nearest:
						nearest = distance
						hit_point = point
				if nearest != INF: hits.append({"distance":nearest,"hit":str(hit_point),"path":str(visual.get_path()),"position":str(visual.global_position),"mesh_class":visual.mesh.get_class(),"aabb":str(visual.get_aabb())})
			hits.sort_custom(func(a,b):return a.distance < b.distance)
			hits_by_pixel[str(pixel)] = hits.slice(0,5)
		var ray_file := FileAccess.open(directory.path_join("hero-rays.json"), FileAccess.WRITE)
		ray_file.store_string(JSON.stringify(hits_by_pixel,"  "))
'''
    return source.replace(needle, needle + extra)

mode = sys.argv[1]
stage = Path("D:/Snapland-QA") / ("main33-" + mode + "-20261118-" + str(uuid.uuid4())[:8])
stage.mkdir()
tracked = subprocess.check_output(["git", "ls-files", "-z"], cwd=ROOT, text=True, encoding="utf-8").split("\0")
manifest = prepare_runtime_stage(ROOT, stage, tracked)
for name in ALLOW:
    path = "game/tests/" + name
    (stage / path).parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ROOT / path, stage / path)
    manifest[path] = digest(ROOT / path)
(HERE / (mode + "-source.txt")).write_bytes((ROOT / CHILD).read_bytes())
if mode in ["diagnostic", "diagnostic-hero"]:
    (stage / CHILD).write_text(diagnose((ROOT / CHILD).read_text(encoding="utf-8")), encoding="utf-8")
elif mode == "control":
    (stage / CHILD).write_text(control((ROOT / CHILD).read_text(encoding="utf-8")), encoding="utf-8")
elif mode == "rim-control":
    (stage / CHILD).write_text(rim_control((ROOT / CHILD).read_text(encoding="utf-8")), encoding="utf-8")
elif mode == "hero-rays":
    (stage / CHILD).write_text(hero_rays((ROOT / CHILD).read_text(encoding="utf-8")), encoding="utf-8")
elif mode == "hero-zero":
    source = diagnose((ROOT / CHILD).read_text(encoding="utf-8"))
    source = source.replace('_position_camera(hero_target, deg_to_rad(24.0))', 'world.camera.position = hero_target + Vector3(0, tan(deg_to_rad(24.0)) * CLEARANCE_CAMERA_DISTANCE, CLEARANCE_CAMERA_DISTANCE)\n\tworld.camera.look_at(hero_target, Vector3.UP)\n\tprint("PRIVATE HERO ZERO AZIMUTH CONTROL ONLY; NPC section retains5deg to reach original hero setup")')
    (stage / CHILD).write_text(source, encoding="utf-8")
(HERE / (mode + "-manifest.json")).write_text(json.dumps(manifest, indent=2), encoding="utf-8")
(HERE / (mode + "-stage.json")).write_text(json.dumps(str(stage)), encoding="utf-8")
(HERE / (mode + "-stage-source.txt")).write_bytes((stage / CHILD).read_bytes())
print("STAGE " + str(stage), flush=True)
imported = run(stage, mode + "-import", True)
assert imported["exit"] == 0 and imported["errors"] == 0, "Fresh stage import failed"
run(stage, mode + "-full")
