"""Freeze completed MAIN33 evidence and assert the narrow caller-only change."""
import difflib
import hashlib
import json
import math
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CHILD = "game/tests/native_sprite_clearance_review.gd"
MODE = "green-hero20"

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(name):
    return json.loads((HERE / name).read_text(encoding="utf-8"))

red = read("red-manifest.json")
green = read(MODE + "-manifest.json")
assert red.keys() == green.keys()
changed = [name for name in red if red[name] != green[name]]
assert changed == [CHILD], changed
assert all(sha(ROOT / name) == digest for name, digest in green.items())
stage = Path(read(MODE + "-stage.json"))
assert all(sha(stage / name) == digest for name, digest in green.items()), "Staged tracked source drift"
source = (ROOT / CHILD).read_text(encoding="utf-8")
before = (HERE / "red-source.txt").read_text(encoding="utf-8")
assert (ROOT / CHILD).read_bytes() == (HERE / (MODE + "-source.txt")).read_bytes() == (stage / CHILD).read_bytes()
functions = lambda text: dict(re.findall(r"(?ms)^(func [^\n]+)\n(.*?)(?=^func |\Z)", text))
old_functions = functions(before)
new_functions = functions(source)
for declaration, body in old_functions.items():
    if declaration.startswith("func _position_camera("): continue
    if declaration.startswith("func _review_avatar_poses("):
        body = body.replace("_position_camera(hero_target, deg_to_rad(24.0))", "_position_camera(hero_target, deg_to_rad(24.0), deg_to_rad(20.0))")
    assert new_functions[declaration] == body, declaration
assert source[:source.index("func _run")] == before[:before.index("func _run")]
for pitch in [19.86,27.1,8.0,24.0]:
    y = math.tan(math.radians(pitch)) * 6.5
    for angle in [5.0,20.0]:
        x,z = math.sin(math.radians(angle))*6.5, math.cos(math.radians(angle))*6.5
        assert math.isclose(math.hypot(x,z),6.5)
        assert math.isclose(math.degrees(math.atan2(y,math.hypot(x,z))),pitch)
        assert math.isclose(math.sqrt(x*x+y*y+z*z), math.hypot(y,6.5))
receipt = read(MODE + "-full.json")
log = (HERE / (MODE + "-full.log")).read_text(encoding="utf-8")
assert receipt["exit"] == 0 and receipt["errors"] == 0 and receipt["passes"] == 1
marker = "PASS: native sprite clearance captures all three NPCs across four authored frames and three camera pitches, plus the player's eight idle directions and walk/photo/wave/celebrate poses. All views use explicit review fixtures, not gameplay evidence."
assert marker in log
assert not any(term in log.lower() for term in ["error:", "leaked", "still in use", "resources still"])
warnings = re.findall(r"(?m)^WARNING:.*$",log)
assert warnings == re.findall(r"(?m)^WARNING:.*$",(HERE / "red-full.log").read_text(encoding="utf-8"))
profile = Path(receipt["environment"]["SNAPLAND_SAVE_PATH"]).parent
records = json.loads((profile / "sprite-depth-coverage.json").read_text(encoding="utf-8"))
expected = [f"NPC {role} frame {frame}" for role in ["ticket","imp","announcer"] for frame in range(4)]
expected += [f"reduced-motion NPC {role}" for role in ["ticket","imp","announcer"]]
expected += ["hero idle/"+direction for direction in ["front","front_right","right","back_right","back","back_left","left","front_left"]]
expected += ["hero walk/front_right/5-of-8","hero photograph","hero wave","hero celebrate"]
assert [record["description"] for record in records] == expected and len(records) == 27
assert all(record["body_pixels"] > 0 and record["covered_pixels"] == 0 and record["covered_fraction"] == 0 for record in records)
captures = {str(path):sha(path) for path in sorted((profile / "captures").glob("*.png"))}
assert len(captures) == 27
raw = {}
for mode in ["diagnostic","control","rim-control","diagnostic-hero","hero-rays","hero-zero"]:
    location = Path(read(mode + "-full.json")["environment"]["SNAPLAND_SAVE_PATH"]).parent
    raw.update({str(path):sha(path) for path in sorted(location.glob("*.png"))})
diff = "".join(difflib.unified_diff(before.splitlines(True),source.splitlines(True),fromfile=CHILD+" (red)",tofile=CHILD+" (final)"))
(HERE / "final-owned.diff").write_text(diff,encoding="utf-8")
(HERE / "final-source.txt").write_bytes((ROOT / CHILD).read_bytes())
audit = dict(child_sha256=sha(ROOT / CHILD), stage=str(stage), profile=str(profile),
             immutable_source_count=len(green)-1, changed_sources=changed,
             all_repo_and_stage_hashes_match_manifest=True,
             parent_and_dependencies={name:green[name] for name in green if name.startswith("game/tests/") and name != CHILD},
             source_guards_and_pose_methods_unchanged=True, camera_pitch_radius_distance_preserved=True,
             segments=records, captures=captures, raw_diagnostic_captures=raw,
             final_log_sha256=sha(HERE / (MODE + "-full.log")), final_receipt_sha256=sha(HERE / (MODE + "-full.json")),
             known_unsupported_material_warnings=len(warnings), warnings_identical_to_red=True)
(HERE / "final-audit.json").write_text(json.dumps(audit,indent=2),encoding="utf-8")
print(json.dumps({"status":"PASS", "source_sha256":audit["child_sha256"],"immutable_sources":audit["immutable_source_count"],"segments":len(records),"captures":len(captures),"warnings":audit["known_unsupported_material_warnings"]}))
