### Task 1: Deterministic runner partition and real catalog coverage

**Files:** Modify `tools/run_game_tests.py`; create `tests/test_runtime_shards.py`; update only concretely affected existing runner contract fixtures if needed. No workflow/game/assets edits.

**Interfaces:** `--shard-index I --shard-count N` 0-based, both-or-neither; invalid/negative/outside/empty and --only combination fail. Default invocation unchanged. Extract one reusable suite-construction function and one selection/partition helper if required; choose clear names and record for Task2. Use stable hashlib label hash, preserve registry order and commands.

- [ ] Run existing result/entrypoint contract baseline before changes; write/run red shard tests using actual registry plus small edge fixtures, then implement.
- [ ] Move existing registry without altering commands/order. Validate unique labels, complete marker correspondence and nonempty runtime catalog. Keep every existing missing-engine/test/version/marker/error guard; missing markers cannot hide in unselected shards.
- [ ] Add validated CLI pair; stable per-label assignment independent of process hash seed/input membership/order, clean import always first, exactly-once union across4 and representative other counts. Reject empty shard and --only mixing. Default and old flags keep current semantics.
- [ ] Meaningful tests cover real registry completeness/partition union/disjointness, ordering/no mutation, stable membership, invalid values, actual main selection invocation, nonzero/errors/missing marker behavior and per-suite profile isolation. Do not mirror the chosen hash's numeric answers.
- [ ] Run focused new+existing Python contracts and one actual Godot shard (not only mocked commands). Record exact labels/count, pinned engine, isolated profiles and output. No repeat full suite required locally; four real cloud shards are Task2/controller gate.
- [ ] Self-review, commit owned paths, detailed task-1-report.md with status/commit/interfaces/exact commands/logs/concerns. Do not change workflow or tickets.

