# SDD ledger — plan: docs/superpowers/plans/2026-11-13-runtime-ci-shards.md

Workspace: C:/Users/stanl/Github/Snapland/.review/runtime-ci-worktree
Branch: codex/runtime-ci-shards-20261113
Ticketa61be77pushed; design/plan05722e2. Task1BASE05722e2c2e5efcefcc503a3cab22e3f60cb9b4e8.

Ruling: user authorizes autonomous tickets/implementation/push/mainmerge/cleanup without approval interviews.
Ruling: begin from reviewed/native-verified MAIN24 code00b29d7 while its fullCI/closure runs; rebase onto its finalmain before publication.
Ruling: use4stablelabel shards, preserve all runtimechecks and per-suite profile isolation; common source gates once. Cost if sizing is poor: adjust shardcount after actual timing, never omit checks or relax errors.
Ruling: unchanged productUI does not require invented screenshots/humanplay; real completeCI matrix and command/coverage evidence are this ticket's acceptance.

## Preflight

| Tasks | Contract / internal consistency | Result |
|---|---|---|
|1|One actual registry, stable label partition, original commands/order and oldflags/default; edge/coverage/real shard tests|Consistent|
|2|Only workflow/affectedcontracts; consumes completedflags;4jobs+once-sourcegate, no runner changes|Consistent|
|1/2|0-based indices0..3/count4 match registry-union tests; cleanimport repeat exempt from exactly-once runtime|Consistent|
|1/2|Strict version/marker/error/entrypoint/save-isolation untouched; sourcegate dependency and fail-fastfalse preserve full diagnostic coverage|Consistent|

Baseline: existing Python result/entrypoint contracts33/33 passed before changes. No game source changed. Source timing observation copied from MAIN24: ST6job24m54s/30mlimit; actual new fullCI107stillrunning.

## Tasks

- [x] Task1 runner partition — dispatched BASE05722e2
- [x] Task2 CI matrix — pending
- [ ] Whole-branch review, real fullmatrix/coverage/timing, ticket/main publication, cleanup
Task1spec+qualityAPPROVED(task-1-review.md),45PythonandrealWinshard22+import255.61sPASS073c27e. Task2 Ruling: existingrepo hasno workflowcontracttests; permitONEfocusedworkflowmatrix/actualcatalogcoverage contract inexistingtests/test_runtime_shards.py. No partitionimplementation changes; actualcloudmatrixremainsrequiredfullgate. Planownershipupdatedbeforeedit. ParentclosingMAIN24mainnext, waitTask2commitbefore rebasingthisworktree.
Task1spec+qualityAPPROVED,Task2spec+qualityAPPROVED(task-2-review.md). Parentplanownershipcommit8c1d3ea thenrebasedontomain MAIN24ee60e9a; game/tools/tests/workflowtreeidenticaltoe5bbc24proven. PublishedfeatureHEAD6956f93e2e1b5e1898fb5aae48998d2228ad9dd1:6d8b7be ticket,398025b plan,1760ba1 runner,85988e2 matrix,6956f93 scopeclarification. Explicitleaseexpecteda61be77checked. No productruntimechange; do notinventvisualQA. Pendingfull6jobsmatrix+actualunion/timing.

Task 1: complete —1760ba1 rebased, task review approved.
Task 2: complete —85988e2 rebased, task review approved.
Whole-branch final review APPROVED (final-review.md), no source fixes requested. Controller gate now PASS:43263971097 attempt2 overall success,196 Python,source and4runtime jobs. Actual RUN/PASS comparison verified106 unique runtime checks and4imports, exact ordering. Times0/1/2/3:286/280/522/349seconds native step; wholejobs629/470/683/528seconds. Attempt1 Python checkout558seconds caused10mincancel; only failed job retried, no timeoutrelaxation. Publicspec documents decision/costs, evidencearchived. Pending cleanmain publication/branch/worktree cleanup.
