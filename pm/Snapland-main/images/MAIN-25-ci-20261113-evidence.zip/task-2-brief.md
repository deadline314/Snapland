### Task 2: Complete required CI matrix and timing evidence

**Files:** Modify `.github/workflows/full-tests.yml`; add the focused workflow matrix/actual-catalog coverage contract to existing `tests/test_runtime_shards.py` if necessary. No partition implementation, runner/game/assets edits.

**Interfaces:** Consume Task1 flags, four indices0/1/2/3 with count4. Preserve full-suite job and all triggers, shared source gates once as a required prerequisite, game-runtime becomes fail-fast:false matrix.

- [ ] Read actual workflow and source preflight requirements. Preserve pinned Python/Godot/action versions, rights, timeouts, concurrency and all existing source/runtime/coverage/entrypoint checks.
- [ ] Move authoring/source preflight from repeated runtime job to a required once-only job; install its existing pinned engine there. Each runtime matrix job installs its own original pinned engine, keeps parser/entrypoint/partition coverage validation and runs its exact shard. No missing fourth job or partial --only filter.
- [ ] Validate existing/new contracts and exact matrix/flag coverage without a new YAML dependency. Parent pushes and runs actual full cloud workflow; any syntax/coverage failure must be fixed, no bypass.
- [ ] Self-review, commit owned paths, detailed task-2-report.md. Controller records per-job actual results/times, confirms full actual universe covered, reviews branch, updates ticket and merges/pushes/cleans. No visual screenshot is needed because product UI is unchanged.
