# Task 1 report: deterministic runtime shards

Status: Task1 implementation, Python contracts, self-review and required real Windows shard PASS. Commit recorded below.

BASE: `05722e2c2e5efcefcc503a3cab22e3f60cb9b4e8`
Worktree: `C:/Users/stanl/Github/Snapland/.review/runtime-ci-worktree`
Branch: `codex/runtime-ci-shards-20261113`

## Scope and interfaces

Owned changes: `tools/run_game_tests.py`, `tests/test_runtime_shards.py`, and concretely affected `tests/test_runtime_result_contract.py` fixtures. No workflow/game/assets/docs/ticket changes authored, no branch changes or push. Godot generated import/UID metadata is left untouched and excluded from staging.

- `build_checks(executable: str) -> list[tuple[str, list[str]]]`: the sole real suite catalog, extracted without changing command values/order; no engine launch.
- `select_checks(checks, *, only=(), shard_index=None, shard_count=None)`: full-catalog validation followed by label partition or the existing local `only` filter. Raises ValueError for invalid selection/catalog. Fresh outer list; rows/commands preserved.
- `validate_selection(only, shard_index, shard_count)`: shared static option validation used by argparse and selector.
- CLI: `--shard-index I --shard-count N`, both-or-neither, 0-based, N > 0, 0 <= I < N; `--only` combination rejected before engine discovery. Count > runtime count and empty assigned shard fail.
- Partition: `int.from_bytes(hashlib.sha256(label.encode("utf-8")).digest(), "big") % shard_count`. Only the label and count affect membership; original command/order retained.
- Every shard includes clean project import first. Whole-catalog unique labels/nonempty runtime catalog/exact PASS_MARKERS correspondence checked before selection, including unselected marker failures.
- Original version discovery, result_error and suite execution/isolation loop retained. Result parser and execution loop AST equality against BASE asserted, including expected boat temp-write policy and deadlines.

## Coverage and verification

Baseline before edits:
`python -m unittest tests.test_runtime_result_contract tests.test_godot_entrypoints -v`
Result: 33/33 PASS (2.007s).

RED after writing actual-catalog and CLI tests:
`python -m unittest tests.test_runtime_shards -v *> .superpowers/sdd/2026-11-13-runtime-ci-shards/task-1-red.log`
Result: 11 errors because build_checks was absent, before implementation. Log: `task-1-red.log`.

GREEN:
`python -m unittest tests.test_runtime_shards tests.test_runtime_result_contract tests.test_godot_entrypoints -v *> .superpowers/sdd/2026-11-13-runtime-ci-shards/task-1-green.log`
Result: 45/45 PASS (2.501s). Log: `task-1-green.log`.

Meaningful checks: real catalog exact marker coverage and every actual command entrypoint valid; full runtime union/exactly-once/disjointness and order across counts1/2/3/4/7; input not mutated; adding/reordering labels preserves membership; separate Python processes with PYTHONHASHSEED1/8473 agree; invalid pair/count/index/noninteger/mixed only and empty shard/catalog/duplicate/missing/stale marker cases; actual main dispatch private absolute per-suite parent directories; nonzero exit, engine errors, missing completion, pre-spawn path error, OS failure, timeout, keep-going and import-failure behavior; missing/unrunnable/wrong-version engine fails; unselected missing marker prevents any engine suite with both local only and shard flags. Old result fixtures now consume the single builder rather than introspecting main's removed literal AST catalog.

Self-review checks:
- Evaluated original BASE catalog AST under identical executable/ROOT/common values and asserted exact equality to build_checks output: PASS.
- Compared result_error and the full per-suite execution loop AST to BASE: unchanged.
- `git diff --check -- tools/run_game_tests.py tests/test_runtime_result_contract.py tests/test_runtime_shards.py`: PASS.
- No new dependencies, scheduler/list feature/config or game behavior.

Actual four-way catalog contains106 runtime suites. Shard sizes excluding imports:26/22/30/28. `task-1-catalog.json` records exact labels for all four shards. Counts sum106; tests prove exact once union against PASS_MARKERS.

## Real engine command and evidence

Engine: `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe`, version `4.7.2.stable.official.ed1daf0bf`.

PowerShell command (from assigned worktree):
```powershell
$env:GODOT_BIN = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
$env:TMPDIR = Join-Path (Get-Location) '.superpowers/sdd/2026-11-13-runtime-ci-shards/native-temp'
New-Item -ItemType Directory -Force -Path $env:TMPDIR | Out-Null
python -u tools/run_game_tests.py --shard-index 1 --shard-count 4 *> .superpowers/sdd/2026-11-13-runtime-ci-shards/task-1-native-shard.log
$nativeExit = $LASTEXITCODE
Set-Content .superpowers/sdd/2026-11-13-runtime-ci-shards/task-1-native-exit.txt $nativeExit
```

Actual selection:22 runtime suites +1 mandatory clean import, in this exact order:

0. clean project import
1. avatar runtime tests
2. avatar attachment tests
3. seated avatar tests
4. source registration coordinate tests
5. NPC world activity tests
6. NPC direction lifecycle tests
7. NPC missing walk idle tests
8. NPC dialogue hold tests
9. kite flight model tests
10. bench swap model tests
11. sign balance view tests
12. hat rescue model tests
13. ribbon rhythm view tests
14. shadow theatre model tests
15. boat prologue state tests
16. boat prologue integration tests
17. island game entry tests
18. island audio dynamics tests
19. main scene integration tests
20. pixel UI shell tests
21. pixel tutorial page tests
22. localization framework tests

Profiles: runner uses one fresh temporary root under the absolute task-specific TMPDIR, and separate `suite-N/progress.json` per invocation. Observed root: `C:/Users/stanl/Github/Snapland/.review/runtime-ci-worktree/.superpowers/sdd/2026-11-13-runtime-ci-shards/native-temp/snapland-godot-test-pau1edlt`. Existing suite parent directories captured while native execution ran in `task-1-native-isolation.txt`; actual Godot children receive absolute SNAPLAND_SAVE_PATH from the unchanged runner loop. Fake-engine sidecar tests cover independent photos/cache parents across the default entire catalog and selected shard. Native temporary root is automatically removed when runner completes.

## Limits and handoff

Only one real local shard is required here; no full-all local repeat, visual/human-play/audio claims or Linux repeat. Task2/controller must run shared source gates and all four real cloud shards before ticket completion. The hash gives stable membership but does not promise equal duration. Parent owns final whole-branch fresh review and publication; no subagents allowed by task brief, so this task performed self-review only. No known implementation concerns. Final whole-cloud coverage/timing gate remains with controller/Task2.

## Final native result

PASS, exit0. Actual RUN/PASS label sequences both exactly match select_checks for shard1/4:23 invocations (clean import +22 runtime), suite elapsed sum 255.61s. Every original 90s limit retained (this shard does not contain the 240s avatar renderer). Native temp root cleaned automatically. Full success transcript in task-1-native-shard.log, exit in task-1-native-exit.txt; task-1-catalog.json contains all actual labels.

## Final Python gate and commit

Final command: `python -m unittest tests.test_runtime_shards tests.test_runtime_result_contract tests.test_godot_entrypoints -v *> .superpowers/sdd/2026-11-13-runtime-ci-shards/task-1-final-python.log`
Result:45/45 PASS (2.567s), after native completion.
`python -m py_compile tools/run_game_tests.py tests/test_runtime_shards.py tests/test_runtime_result_contract.py`:PASS.
`git diff --cached --check`:PASS.

Commit:`073c27e09f77068f03dd7bd65cd2cc6e4f654561` (`feat: partition runtime checks into deterministic shards`). Author and committer Stanley Li <stanley890314@gmail.com>; no trailers. Exactly3 owned paths committed; no staged paths left and no post-commit changes to owned paths. Generated metadata from native import is deliberately left uncommitted.

Task1 complete. No deferred code findings or deviations. Parent/controller retains cloud matrix gate and branch final review.
