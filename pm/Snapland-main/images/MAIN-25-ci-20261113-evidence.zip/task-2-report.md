# Task 2 report: required four-way CI runtime matrix

Status: implementation, local contracts, installed YAML parse, structural preservation checks and self-review PASS. Actual cloud syntax/execution, source job, all four shards and timing remain REQUIRED controller gates; no cloud pass claimed here.

BASE: `073c27e09f77068f03dd7bd65cd2cc6e4f654561`
Commit: `e5bbc246d76e2c4c951440c2f17f9d4af0d559e3` (`ci: run complete runtime suite in four required shards`)
Worktree: `C:/Users/stanl/Github/Snapland/.review/runtime-ci-worktree`
Branch: `codex/runtime-ci-shards-20261113`
Author and committer: Stanley Li <stanley890314@gmail.com>; no trailers.

## Scope and rulings

Read root AGENTS.md, design/runtime/runtime-ci-shards.md, docs/superpowers/plans/2026-11-13-runtime-ci-shards.md including Global Constraints, task-2-brief.md and task-1-report.md, actual workflow and all source preflight entrypoints. No nested AGENTS.md under .github or tests. Verified assigned branch/BASE and existing unrelated generated metadata. No subagents, branch changes, rebase or push.

Owned committed files:
- `.github/workflows/full-tests.yml`
- `tests/test_runtime_shards.py` (one new focused contract plus its standard library imports; previous tests unchanged)

Ruling: no existing tests referenced the workflow, so one workflow/actual-catalog matrix guard belongs in the existing shard contract file. Parent explicitly approved and updated the task scope/plan before implementation commit. It checks actual YAML text in the existing house format using only the standard library, not a second suite catalog or a YAML dependency. A legitimate later YAML formatting rewrite may require adapting this narrow guard; actual Actions execution remains the semantic gate.

No runner/game/assets/docs/ticket changes authored or staged. Existing native-generated .import/.uid files left untouched. This ignored report and task logs are handoff artifacts, not source commits.

## Final structure

- Original events/path filters, permissions and concurrency header unchanged byte-for-byte.
- `full-suite`: unchanged original Ubuntu runner, 10 minute timeout, checkout@v4, setup-python@v5/Python3.12, Pillow12.2.0/numpy2.3.5 install, design validator and all unittest discovery. Its existing dependency-success condition retained.
- `runtime-source`: required once-only Ubuntu job, 30 minute timeout copied from original runtime job, same Python/actions, same pinned Godot4.7.2 Linux download/install command. Contains all five original source/preflight commands exactly once, in original order:
  1. `python tools/check_runtime_tests.py`
  2. `python tools/hero_2d/run_contract_tests.py`
  3. `python tools/hero_2d/run_hair_review.py --contracts`
  4. `python tools/walk_stability/run_audit.py --tag ci --test`
  5. `python tools/island_avatar/run_contracts.py`
- `game-runtime`: `needs: runtime-source`, same Ubuntu/30 minute timeout/Python/actions, `strategy.fail-fast: false`, sole matrix axis `shard-index: [0, 1, 2, 3]`, no include/exclude/conditional/continue-on-error/max-parallel bypass. Each job first runs strict parser/entrypoint/shard contracts, installs the same pinned Godot4.7.2 independently, then executes:
  `python tools/run_game_tests.py --shard-index ${{ matrix.shard-index }} --shard-count 4`
- Source failure prevents every runtime shard from starting; no failure bypass exists. Workflow success requires independent `full-suite`, required source job and all four runtime jobs to succeed under standard Actions success aggregation. Every original trigger uses the same complete matrix.
- Existing runner handles clean import and absolute per-suite profiles unchanged. Runtime catalog remains the single Task1 `build_checks`; no `--only`, timeout-scale or omissions introduced.

Actual selections from the workflow's four indices: `[26, 22, 30, 28]` runtime suites, total106, plus one clean import per shard. The contract computes union exactly once against actual PASS_MARKERS via select_checks rather than pinning copied labels.

## Tests and exact commands

Commands ran from the assigned worktree. Long output redirected to task artifacts; tails read and exit/result inspected.

Baseline before edits:
`python -m unittest tests.test_runtime_shards tests.test_runtime_result_contract tests.test_godot_entrypoints -v *> .superpowers/sdd/2026-11-13-runtime-ci-shards/task-2-baseline.log`
Result:45/45 PASS, 2.572s.

RED before workflow implementation:
`python -m unittest tests.test_runtime_shards.RuntimeShardTests.test_ci_matrix_runs_the_complete_real_partition_after_source_checks -v *> .superpowers/sdd/2026-11-13-runtime-ci-shards/task-2-red.log`
Result:1 expected failure because original game-runtime has no `needs: runtime-source`.

GREEN after workflow change:
`python -m unittest tests.test_runtime_shards tests.test_runtime_result_contract tests.test_godot_entrypoints -v *> .superpowers/sdd/2026-11-13-runtime-ci-shards/task-2-green.log`
Result:46/46 PASS, 2.523s.

Final after adding explicit once-only source guard:
`python -m unittest tests.test_runtime_shards tests.test_runtime_result_contract tests.test_godot_entrypoints -v *> .superpowers/sdd/2026-11-13-runtime-ci-shards/task-2-final-python.log`
Result:46/46 PASS, 2.666s.

`python -m py_compile tests/test_runtime_shards.py`:PASS.
`git diff --check -- .github/workflows/full-tests.yml tests/test_runtime_shards.py`:PASS.
`git diff --cached --check`:PASS.
`git status --short -- .github/workflows/full-tests.yml tests/test_runtime_shards.py`:empty after commit.

New focused contract verifies source dependency/no source matrix; exact indices/count/no matrix exclusions; fail-fast false; actual selection union/completion marker universe and repeated import; each original preflight command present exactly once in source; three runtime contract modules retained; pinned engine in both jobs; no source/runtime conditions or continue-on-error.

## Independent installed YAML/structure self-check

`Get-Command actionlint -ErrorAction SilentlyContinue`: no installed actionlint found. Installed PyYAML was available; it was used only for a local parse/comparison, never added to project/CI/tests. Executed the following Python body via PowerShell single-quoted here-string piped to `python -`, redirected to `.superpowers/sdd/2026-11-13-runtime-ci-shards/task-2-structure.log`:

```python
from collections import Counter
from pathlib import Path
import re
import subprocess
import yaml
from tools.run_game_tests import PASS_MARKERS, build_checks, select_checks

base = subprocess.check_output(['git', 'show', '073c27e09f77068f03dd7bd65cd2cc6e4f654561:.github/workflows/full-tests.yml'], text=True)
current = Path('.github/workflows/full-tests.yml').read_text(encoding='utf-8')
assert current.split('\njobs:\n')[0] == base.split('\njobs:\n')[0], 'events/rights/concurrency changed'
old = yaml.load(base, Loader=yaml.BaseLoader)
new = yaml.load(current, Loader=yaml.BaseLoader)
assert new['jobs']['full-suite'] == old['jobs']['full-suite'], 'data gate changed'
assert list(new['jobs']) == ['full-suite', 'runtime-source', 'game-runtime']
source = new['jobs']['runtime-source']
runtime = new['jobs']['game-runtime']
assert runtime['needs'] == 'runtime-source'
assert source['timeout-minutes'] == runtime['timeout-minutes'] == old['jobs']['game-runtime']['timeout-minutes'] == '30'
assert source['runs-on'] == runtime['runs-on'] == old['jobs']['game-runtime']['runs-on']
steps = old['jobs']['game-runtime']['steps']
assert source['steps'] == steps[:2] + steps[3:-1], 'source commands or install changed'
assert runtime['steps'][:2] == steps[:2]
assert runtime['steps'][3] == steps[3], 'runtime engine install changed'
assert runtime['strategy'] == {'fail-fast': 'false', 'matrix': {'shard-index': ['0', '1', '2', '3']}}
assert runtime['steps'][-1]['run'] == 'python tools/run_game_tests.py --shard-index ${{ matrix.shard-index }} --shard-count 4'
for job in new['jobs'].values():
    assert 'if' not in job and 'continue-on-error' not in job
    for step in job['steps']:
        assert 'continue-on-error' not in step
checks = build_checks('structure-check-godot')
counts = []
seen = Counter()
for index in runtime['strategy']['matrix']['shard-index']:
    selection = select_checks(checks, shard_index=int(index), shard_count=4)
    assert selection[0] == checks[0]
    counts.append(len(selection) - 1)
    seen.update(label for label, _ in selection[1:])
assert seen == Counter(PASS_MARKERS.keys())
print('PASS: installed PyYAML parses workflow; original events/permissions/concurrency/full-suite preserved; original source steps and both pinned installs exact; no failure bypass; actual counts', counts, 'sum', sum(counts))
```

Result:PASS, counts[26,22,30,28], sum106.

Self-review: read whole two-file diff and reconciled every Task2 requirement. All original commands/pins/limits/events preserved; source isolation implementations unchanged; four matrix arguments complete; no dependency upgrade, Node/actions notice repair or unrelated changes. No known code findings. New YAML text guard intentionally fails closed on unreviewed formatting/strategy changes rather than pretending to parse arbitrary YAML.

## Controller handoff / limits

Parent must now rebase onto MAIN24 main closure, push and inspect the actual Actions run. Record source/data/four-runtime conclusions and per-job durations; extract actual RUN/PASS sequences from all four jobs and compare exactly with current build_checks/select_checks including one import per shard, disjoint106-runtime union. Full cloud result is required before ticket closure/merge. Any Actions syntax/execution failure is a real remaining failure, not excused by this local guard or PyYAML parse.

No actual cloud run, no repeated native source gates, no extra local real shard/full suite, no product visuals/human-play/audio claims. Task1 already supplied the requested real Windows shard1 evidence; current work changes scheduling only. Runtime hash membership is stable but no equal-duration guarantee; actual timing remains to be measured. Existing generated metadata remains uncommitted for controller cleanup.
