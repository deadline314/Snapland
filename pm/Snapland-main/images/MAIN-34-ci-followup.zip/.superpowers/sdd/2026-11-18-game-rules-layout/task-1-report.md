# Task 1 report — MAIN-34

Status: DONE. Changes are uncommitted for root review and delivery.

## Scope and causal evidence

Read the task brief, runtime authority, applicable PM rules, systematic-debugging and TDD instructions. Production changes are confined to `_show_game_rules` and its necessary rules renderer. The shared HBox footer, Paper, panel scaling, fonts, thresholds, all callbacks/retake eligibility, progress, rewards and other modal functions remain unchanged.

Fresh tracked 26-game RED was collected before production edits at `D:/Snapland-QA/game-rules-layout-20261118/red-native-valid-efd3cf`. Actual physical 800×600, content-scale DISABLED, ui_scale1.25/reduced motion. For game001 and025, the footer minimum789 plus56 frame/margin produced an845×520 panel at(0,40), beyond viewport800. Retake pair minimum510 and card515 were narrower than available684, so the retake HBox was preserved; it was not the decisive width cause. Raw PNGs and complete rect/minimum propagation are in `captures/report.json` and `captures/game-025-context0-page0.png`. Four representative games ×four initial states ×three pages =48 cases,1332 strict boundary failures. Initial fixture parse error is separately retained at `red-native-fadf41`; it is not counted as valid RED.

The existing unchanged PixelShell baseline passed at `baseline-pixel-c0e3ae` (exit0/0ERROR). Expanded catalog RED at `red-pixel-matrix-3f1834` failed8658 boundary assertions over936 pages. Candidate1 fixed width but the full catalog caught height failures in004/005/006/009/010/011/012 (822 errors; game009 reached713px height) at `candidate1-pixel-1fb2e9`. This proved the need for paging, rather than accepting representative-only images.

Final rules retain the named GameRulesDetails card and existing GameRulesExtraDetails pager, with goal→instructions→devil→participation→assist pages at original22/20/18 base font sizes. The named retake pair and all four play choices/back stay continuously visible in a rules-only HFlow inside the unchanged global HBox footer. Long missing/unattempted pair plus the five other actions fit two rows at800. No shrinking, clipping, manual long scroll, new framework or dependency. Cookie Main's existing participation check now seeks real RulesNote1 using actual pager metadata.

## Frozen source stage and launch boundary

Final stage: `D:/Snapland-QA/game-rules-layout-20261118/stage-a2cba1`. Inventory: `stage-a2cba1-inventory.json` beside it,1200 files. Created by `prepare_runtime_stage` from git tracked inventory, then an exact15-file fixture/helper allowlist recorded in private `run_review.py`. Tests excluded by the normal runtime packager were copied only by that explicit list. No whole workspace/test-tree copy, no C project import, no untracked UID/import copy. The paused SG43 native fixture was neither read nor copied nor modified.

Every actual Godot process used `tools.godot_entrypoints.run_validated_godot` and exact `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe`. Node fixtures used their actual `.tscn`; SceneTree tests used `--script`. Native GPU is AMD Radeon RX9070XT/Forward+, reported in raw logs. Every launch owns fresh absolute D-only SNAPLAND_SAVE_PATH,APPDATA,LOCALAPPDATA,TEMP,TMP; complete exact command and all five paths are retained in each `launch.json`. No player or accepted old QA profile was modified/deleted.

Reproducible private commands (run from repository root):

```powershell
python .review/game-rules-layout-20261118/run_review.py stage
python .review/game-rules-layout-20261118/run_review.py pixel-final --stage D:/Snapland-QA/game-rules-layout-20261118/stage-a2cba1 --label final-pixel240
python .review/game-rules-layout-20261118/run_review.py native --stage D:/Snapland-QA/game-rules-layout-20261118/stage-a2cba1 --size 800x600 --label final-native800
python .review/game-rules-layout-20261118/run_review.py native --stage D:/Snapland-QA/game-rules-layout-20261118/stage-a2cba1 --size 1152x648 --label final-native1152
python .review/game-rules-layout-20261118/run_review.py native --stage D:/Snapland-QA/game-rules-layout-20261118/stage-a2cba1 --size 1280x720 --label final-native1280
```

Other final actions are `retake`, `sugar`, `cookie`, `travel`, `harbor` with the same stage and labels in the results table. Standard PixelShell launch was exactly `--headless --audio-driver Dummy --rendering-method gl_compatibility res://game/tests/test_pixel_ui_shell.tscn`, without a FPS override. Other headless affected checks used private `--max-fps240`; native used unchanged DISABLED content-scale mode and actual windows.

## Final results

| Check | exit / ERROR / leaks | seconds | Exact command, profiles and raw log directory |
|---|---|---|---|
| final-pixel240 | 0 / 0 / 0 | 95.68 | `D:/Snapland-QA/game-rules-layout-20261118/final-pixel240-e04721` |
| final-native800 | 0 / 0 / 0 | 10.36 | `D:/Snapland-QA/game-rules-layout-20261118/final-native800-a8d932` |
| final-native1152 | 0 / 0 / 0 | 10.95 | `D:/Snapland-QA/game-rules-layout-20261118/final-native1152-0a053f` |
| final-native1280 | 0 / 0 / 0 | 11.91 | `D:/Snapland-QA/game-rules-layout-20261118/final-native1280-8d5de4` |
| final-retake-panel | 0 / 0 / 0 | 30.54 | `D:/Snapland-QA/game-rules-layout-20261118/final-retake-panel-72c437` |
| final-sugar-main | 0 / 0 / 0 | 9.92 | `D:/Snapland-QA/game-rules-layout-20261118/final-sugar-main-42f71a` |
| final-cookie-main | 0 / 0 / 0 | 11.31 | `D:/Snapland-QA/game-rules-layout-20261118/final-cookie-main-4bb02e` |
| final-travel-ui | 0 / 0 / 0 | 9.06 | `D:/Snapland-QA/game-rules-layout-20261118/final-travel-ui-ad749e` |
| final-harbor-collection | 0 / 0 / 0 | 1.15 | `D:/Snapland-QA/game-rules-layout-20261118/final-harbor-collection-f7c0ba` |

PixelShell checks all actual Catalog definitions dynamically: current26 ×three physical sizes ×five synthetic contexts ×five pages =1950 page cases. Contexts are no cards/unattempted, no cards/attempted, ordinary-only, devil-only, both-owned. Every visible Control stays in the viewport and its parent; all label line heights/button text/style margins fit; visible text/actions do not overlap. Boundary/overlap tests use exact rectangles, without tolerance. Goal/instructions text and original font sizes are checked independently. Actual connected Next callbacks and settled container frames cover the matrix; representative001/025 routes use real Tab/Enter/pointer, tutorial, practice with persisted assistance, formal/assist tutorial gates and real Session launches, both retakes before/after attempt, Previous/Next and keyboard/pointer return. Candy callbacks use actual regional travel with explicitly synthetic admission cards. Cancelled practice/retake entry grants no target cards; no gameplay-success claim follows from synthetic ownership.

Each final native run checks five actual game definitions001/009/013/025/026 ×five states ×five pages =125 page cases and45 raw PNGs; total375 cases/135 PNGs across three sizes. Viewports are actual800×600/1152×648/1280×720 with unchanged content-scale DISABLED.800 uses ui_scale1.25/reduced motion; others1.0/normal motion. Each native full completion marker occurs exactly once, exit0,0ERROR,0leaks; existing Release helper tears down audio. Existing known unsupported-material/legacy-placeholder warnings are retained in raw logs and were not changed into audio or material fixes.

Representative final raw PNGs (root review uses these):

- `D:/Snapland-QA/game-rules-layout-20261118/final-native800-a8d932/captures/game-009-context0-page1.png` — long instructions and both long unattempted retakes.
- `D:/Snapland-QA/game-rules-layout-20261118/final-native800-a8d932/captures/game-025-context0-page3.png` — participation and all seven actions.
- `D:/Snapland-QA/game-rules-layout-20261118/final-native1152-0a053f/captures/game-009-context0-page1.png` — long instructions and both long unattempted retakes.
- `D:/Snapland-QA/game-rules-layout-20261118/final-native1152-0a053f/captures/game-025-context0-page3.png` — participation and all seven actions.
- `D:/Snapland-QA/game-rules-layout-20261118/final-native1280-8d5de4/captures/game-009-context0-page1.png` — long instructions and both long unattempted retakes.
- `D:/Snapland-QA/game-rules-layout-20261118/final-native1280-8d5de4/captures/game-025-context0-page3.png` — participation and all seven actions.

## Timeout boundary and Python checks

After removing redundant pointer pacing from all1950 geometry pages (keeping representative real input), unchanged GL/default-FPS90s timed out at90.16s, exit124,0ERROR/no completion marker: `callback-matrix-standard90-5865df`. An earlier standard run `standard-pixel90-d0d5cb` was deliberately stopped at46.57s after root requested the matrix optimization; it is not a test pass or timeout. Root authorized a label-only240s limit alongside the existing avatar-renderer house pattern. Every other suite remains90; timeout-scale and marker semantics remain unchanged. The final standard call completed95.68s, cleanly under240.

Python TDD changed the contract expectation first:23 tests failed exactly90!=240 (`python-contract-red.log`); after the narrow runner change,23/23 passed (`python-contract-green.log`). Entrypoint checks15/15 passed (`python-entrypoints.log`). Exact commands:

```powershell
python -m unittest discover -s tests -p test_runtime_result_contract.py -v
python -m unittest discover -s tests -p test_godot_entrypoints.py -v
git diff --check
```

Python temporary directories were redirected to fresh D paths recorded alongside those logs.

## Source SHA256

| Source | SHA256 |
|---|---|
| `game/main.gd` | `ed198313c41ce84b7a437b527e9b37e851db291f7bfcdbd9889f10b6d34b558c` |
| `game/tests/test_pixel_ui_shell.gd` | `6e6c33ea2acc920343695b474ced444a432aaa794ea069a763932c451811250b` |
| `game/tests/test_cookie_mold_main.gd` | `8be85ebf967e3177e2294d48d30ea6bebb940d43aa60921cd3d71a3ab616aaf6` |
| `game/tests/native_game_rules_layout_review.gd` | `2af78b4866ef3f5fa44c0f8daa47b6c930b6795dfcfc63824229285fe6183ea5` |
| `game/tests/native_game_rules_layout_review.tscn` | `b2db262d17de19a4ef1c5e280084cf11d04ae2676b0eb6b8efe9928890f80dc9` |
| `tools/run_game_tests.py` | `90f9fbd7b2bb7418ac1de678f39bea6979e109422c8ab7e12adb776b7654c93b` |
| `tests/test_runtime_result_contract.py` | `527b499b6f3ab7eb4330d2b5d1ad46290e5ca84355246f4605db14fadf4936d1` |

## Self-review and limits

All frozen runtime/fixture hashes match the source inventory. Reviewed the production diff for callback arguments, ordering, font sizes, ownership behavior, public node names and unchanged global modal/HBox behavior. Scope stayed rules-only; no index/HEAD/branch/commit/push changes were made by this worker. No other untracked asset/import/UID files or paused SG43 files were modified.

Root expressly ruled that legacy photo-retake-Main and region-travel fault-child suites are omitted locally because their existing OS.execute children bypass the mandated validated launcher and inherit profile environment paths. They were not silently skipped and their launcher/backend code was not broadened into this UI fix. Replacement affected coverage is the existing retake panel, actual factory Main integration, travel/book/harbor collection UI, plus actual Main retake and callback routes in enhanced PixelShell. Full suite/export is left to CI under the UI-only scope ruling. This work is automated UI/layout and scripted input verification, not human play or listening. SG43 still needs its own rebase and real27-game800 verification after MAIN34 delivery.

## Post-delivery CI correction

CI44176471323 reported seven failures from the shared sharded-runner fixture at `tests/test_runtime_shards.py:184`. Its timeout expectation still gave only avatar-renderer the240s allowance, so pixel UI shell with `--timeout-scale2` incorrectly expected180 rather than the runner's intentional480. This is the same MAIN34 timeout requirement; only the one-line test expectation was corrected to match the runner and existing result-contract test. Runner, production, other fixtures, PM and Git state were not changed by this follow-up worker.

RED was reproduced before the edit:13 test methods ran, with exactly seven `480.0 != 180` failures, exit1. After the one-line correction, all51 requested Python tests passed, exit0:

| Command (repository root) | Result | Evidence relative to repository root |
|---|---|---|
| `python -m unittest discover -s tests -p test_runtime_shards.py -v` before edit | RED:13 methods /7 failures | `.review/game-rules-layout-20261118/ci-followup/runtime-shards-red.log` |
| `python -m unittest discover -s tests -p test_runtime_shards.py -v` after edit | GREEN:13/13,0.655s | `.review/game-rules-layout-20261118/ci-followup/runtime-shards-green.log` |
| `python -m unittest discover -s tests -p test_runtime_result_contract.py -v` | GREEN:23/23,5.104s | `.review/game-rules-layout-20261118/ci-followup/runtime-result-contract-green.log` |
| `python -m unittest discover -s tests -p test_godot_entrypoints.py -v` | GREEN:15/15,0.143s | `.review/game-rules-layout-20261118/ci-followup/godot-entrypoints-green.log` |
| `git diff --check` | Clean | Tool result; no whitespace errors |

Python TEMP/TMP were isolated to fresh absolute paths under `D:/Snapland-QA/game-rules-layout-20261118/ci-followup-{red,shards-green,contract-green,entrypoints-green}`. These tests mock engine dispatch; no Godot/native/export/full-suite reruns were performed, per root's explicit scope. Paused SG43 files were not read or modified.

Final `tests/test_runtime_shards.py` SHA256: `b7c5e7c9a43357bec6d400b29b3db427ffe33022ee5ae3d9401808487f9db075`.
