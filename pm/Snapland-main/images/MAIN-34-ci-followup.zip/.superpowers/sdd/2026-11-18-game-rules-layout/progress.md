# SDD ledger — plan: docs/superpowers/plans/2026-11-18-game-rules-layout.md

Branchcodex/game-rules-layout-20261118,baseorigin/main92a5fa5;opening1c062c4and specplan58fa46a committed+pushed. BASETask1=58fa46a. SG43branchcodex/syrup-flood-20261118 preserved4ff5888(remotealso4ff); production27sourceCI44168308709running. SG43Task4producer/root/syrup_native_delivery STOPPEDallprocesses/writes, WAITINGcheckpointinitsworkspace; untrackednative_syrup_flood_main.gd/.tscnremainCbutMUSTnotimport/touch/stage. Nootherproducerwriting.

## Preflight

| Task/pair | Producer/consumer finding | Ruling |
|---|---|---|
| Task1self | actual800clippednativeSG43 screenshot vsbaseline26source | freshold025/026or001REDrequired, noSG43imageasoldproof |
| Task1layout | typedmodal_footerHBox sharedallmodals vsruleswrapping | preservetype/othermodals; scopeonlyrules-ownedcontainers/renderer |
| Task1tests | test_pixel_ui_shell directmodal_footer.get_children rulesactions vspossible nesting | preserveall4actionsnames/semantics, updatecorrectrecursivequerynotdeleteasserts |
| Task1geometry | fixingwidthmaygrowheight/paragraphwrap | fullControl/textwidth+height bounds3sizes4ownershipstates, font/mode/thresholdsunchanged |
| Task1inputs | retakemissingpair andcallbacktargetordinary/devil vswrap/order | bothmissing-unattemptedlongestcontext musttest, callbacks/IDsunchanged |
| Task1→Task2 | sourcefreeze/nativemarkers/rawpng vspublicevidence | actualcleanGREENonly, no rejectedcandidate/PASSwithERROR promotion |
| Task2SG43 | MAIN34maincode vsfeatureSyrupmainparticipation3mode line | fetch/rebasepreservebothUIcorrectionandSG43newmode; resolvePMadd/addprogressdependency |
| Task2Git | sharedrootcheckout vswaitinguntrackedSGfixture | explicitstagepaths/freshDtrackedallowlist; nootherplanworkspacewrites orcleanup |

Ruling: independentMAIN34fixbranchfromorigin/main beforeSG43delivery — actualsharedruleslayoutdebt found800fullscan, SG43notfullyaccepted; avoidmergingunfinishedgameaspartUIrepair — costsonebranch/rebase+possiblePMadd/addconflict, source27branchpreserved4ff.
Ruling: copySG43ticketonlyintomain34openingtoholdbidirectionaldependency — mainhasnoSG43code/ticketyet, ticketinprogressaccurateandMAIN34BlocksSG43/SG43BlockedbyMAIN34nowbothpresent — costsresolvingPMadd/addonSG43rebase, no prematurefeatureclaim.

## Baseline/status

RootviewedrawD:/Snapland-QA/syrup-native-candidate1-c64c1639/suite-800x600-f3bdba/captures/rules.png: panelandrightretake/next/backbuttonsclipped. ThisisdiagnosticcurrentSG43 evidenceonly, notMAIN34baseRED. Rootreadmainrules/_open/_back/PixelShellcallers: typedHBoxfooter, upperHBox2longretakes, direct-childtestqueryrisk identified. No productionedit onMAIN34yet.
- [x] Task1 freshproducerRED/cause/minimalfix/unit/native/sourcefreeze/taskreview.
- [ ] Rootimages/PM/evidence/mostcapablefinalreview/mainmergeCI/owncleanup.
- [ ] ReturnSG43/rebase/resolve/sourcefreeze/resumeoriginalTask4producer.

AfterSG43restore/rebase GitautocrlfmaynormalizetrackedModel/Driver/View/rawMainCRLF; preservecanonicalLF/Gitblobidentityvsoldfrozenhashes, recordnewrawhashes+exactfinalstage, donotwritebackhistoricalrawbytesjusttoreproduceoldhash. BinaryPNGhashesmustremainexact. AllnewheavyD, C2.16GB/D176GB last. Policyblocked3oldCQAprojectdirsretainedno retry/bypass. OtherplanSG43workspacealreadycheckpointedandnowleaveituntoucheduntilreturn.
SG43featureproduction4ff5888 CI44168308709all6SUCCESS observedGitHubconnector; noSG43mainmerge/native800UIacceptanceclaim. SharedMAIN34freshbasereproinprogress.
FreshbaseREDproducerproof: old025/001/013/026, panelRect(0,40,845,520)>800;footer minimum789+56margins=845, retakepairHBox510at25px. 48nativecases1332boundaryfailures, validRED separateinitialfixtureparsefailure. Rootindependentlyviewedold025rawPNG confirmingrightclipping. BaselineexistingPixelShellexit0/noERROR, lackedthisworstcase. Producerproceedingruleslocalflow/minheightchecks; sourcefreeze/taskreviewpending.

Ruling: localaffectedtestsremainstrictvalidatedboundary — legacyphoto-retakeMain/_run_failed_save_child andregion-travel/_run_save_failure_child invokeOS.executeGodoTchildoutsidePythonandshareparentDAPPDATA/TMP; doNOTbroadenUIticketintolaunchrefactororstagepatch. Omitthosetwolocalsuitesexplicitly; runchild-freePixelShell/RetakePanel/SugarCookieMain/travelcollectionUI andownnativeactualcallbacks. Backendunchanged; existingfullCI coverslegacyfaultsseparately. CostnotlocallyreplayingunchangedIO-failurechildren, nevermissingtest/engine-silentskip.
Ruling:5-pageexistingrulespagernecessaryaftercausalfooterfix — footerwidth789+56→845proven; removingretake/titleexperimentalchangeskeepsminimalcausefix, butfullcatalogfound7welcomeheightfailures(004/005/006/009/010/011/012;009height713),822errors — keepgoals/instructions/devil/participation/assistinoriginalfont22/20/18andorder, preserveall7actionsalwaysvisibleinrules-onlyflowfooter(retakegroupfirst,4play+backrelativeorderunchanged), no globalframework/font/threshold/modechange. Cost2moreoptionalrulespages, allcontent/actionsretained. Scopeincludesnecessaryrulesrenderer+affectednote-navigationtests; navigatebyactualnoteratherthanfixedclick1. Fullmatrixnow5ownershipcontexts(bothsinglecarddirections)×26games×3sizes×5pages.
Ruling: authorizePixelShell-only240s housepattern afteractualoptimizedstandardGL/defaultFPStimedout90.16s exit124/noERROR/nomarker; rawD:/Snapland-QA/game-rules-layout-20261118/callback-matrix-standard90-5865df/{launch.json,run.log}. Preserve1950cases/representativeactualinput, others90/globaltimescale>=1/strictmarkers unchanged. CostlongerCIallocationonlyforthisexpandedUIregression, notslowergameplay; no speculativeglobaltimeout. tools/run_game_tests.py+focusedresultcontracttestownershipextended andspec/planupdated; finalstandard240actualdurationrequired.
FinalPixelShellstandardheadlessGL/defaultFPS GREEN95.68s underauthorizedsuite240, exactmarker1/exit0/0ERROR/leaks,1950actualpages+representative001/025realkey/pointercallbackroutes. D:/Snapland-QA/game-rules-layout-20261118/final-pixel240-e04721/{launch.json,run.log}; frozenstage-a2cba1. Per-suitePythonTDD23RED90!=240then23GREEN,entry15GREEN. Finalnative800125cases/45PNGs/10.36s strict0/noERRORleaks complete; native1152/1280+4affectedsubsetpending. NoTask1DONE/reportfreezeyet.
RootindependentFINALrawviewcomplete: final-native800-a8d932/captures/game-009-context0-page1.png (longinstructions/bothretakes/all7actions), final-native1152-0a053f/captures/game-025-context0-page3.png (participation), final-native1280-8d5de4/captures/game-025-context0-page0.png(goal). Fulltext/allcontrolsinsideviewport, fontsreadable; no visualblock. Nativeeach125caseguards/45PNGs/cleanexit/exactmarker1/noERRORleaks; finalPixelShell1950standard95.68s. Affectedsubsetawaitingproducerfreeze.

Task1producer /root/main34_rules_layout DONE; rootverified7sourcehashesandcommitted5902d65(7worker+3rootdocs/PM,338+/20-), pausedSG43untrackedfilesNOTstaged. Fullreporttask-1-report.md; 1200stageinventory0mismatch, Pixel1950standard95.68s, native3×125/135PNGs clean, 5affectedretake/sugar/cookie/travel/harborchecksallclean,23+15Pythonpass. Fresh /root/main34_task_review pendingreview-58fa46a..5902d65.diff45KB; no Task1completeflagbeforebothverdicts. Rootalreadyviewedall3finalrepresentatives; no UIblock. Preparingpublicevidence/PMwhiletaskreviewruns, no productchanges.

Task 1: complete —5902d65, /root/main34_task_review spec✅qualityApproved0CriticalImportant. Reporttask-1-review.md, receipts/sourcehashes/strictmarker/read-onlyhelperfocus/namingcheck reviewed; no test reruns. Cannotverifyfullsuite/SG43outside26base areexplicitrootCIandSG43resumegates, notclaimedhere. InheritedwarningsMinorleftforfinaltriage. Public4rawPNGs(viewed) and20.87MBzip prepared, manifest/CRCverified.
Ruling: retaininheritedunsupportedmaterial/placeholderwarningnoise withdisclosure — exactrawlogsbaseline/final demonstrateexistingproduction/materialdefenses, UI-onlydiffdoesnotownit — futurematerial/assetsupportworkcost, no hiddenERRORorweakenedmarker. Wholebranchfinalmusttriage.

Wholebranchfinal /root/main34_final_review(Astrahigh)ReadyYES0CriticalImportant; inheritedmaterialwarningMinoronly. final-review.md evidence/zip/frozenhash/declineditemscomplete. Rootadjudicatesallsetaside: othermodal/Save/gameplayunchangedwithaffectedcallbackregressions; fullsuite/legacyfaultchildrenactualCIpending; SG43noton26base/pausedfilesuntouchedwillrebase+fresh27GPU; noexportforUIonly; no humanplay/hearing/art/performanceclaim. Nofixwave required. FinalreportnowaddedarchivewithfreshCRC/SHA, sourceunchanged. MainCIandactualGitdeliverypostreviewexecutorowned.

MAIN34deliveredmaina3efdb06f02fbcb735b595b6bc035dd2d0293265; featurepushed/FFmainpushed/exactSHAverified/ownlocal+remotebranchdeleted. NewmainCI44176471323running, duplicate44176460992cancelrequested. Finalzip217manifestfiles20,895,980bytesSHA777b8c08eb7cfaa966214ed0461b801de21e519e822caa60685c667af262177c includesfinalreview. Sourceunchangedpostfinal. NowrootreturnSG43/rebase.

Post-delivery CI correction: CI44176471323 full-suite7 stale timeout assertions; originalproducer reproduced RED and one-line tests/test_runtime_shards.py fix, 51 Python checks GREEN. Commit4dd3387. Same final reviewer scoped followup ReadyYes,0issues, reportci-followup-review.md. No production changes/native reruns; original evidence remains.
