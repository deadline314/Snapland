# MAIN-29 fixture data dependency repair

SG41mainCI44121228790/job134177033859 passed SugarMain but failed test/review save isolation with repeated missingCandy JSON/catalog diagnostics. The fixture copied and later removed only Welcome/Harbor JSON. LocalRED reproduced same strictfailure. First copy-only correction exposed the second cleanup list; final patch uses the same declared Catalog.DATA_PATHS for BOTH bounded copy and cleanup. No production behavior or save boundary changed, no diagnostics ignored.

Final exactGodot4.7.2 validated scene with unique absolute save: exit0, existing exactPASS, NEGATIVE_FAKE_PROFILE_HASHES_UNCHANGED, normalfakeuserdata load/save/reopen.50 Python completion/entry/shard contracts passed. Separate minimal project copied core/catalog/data bytes from origin/main(a749143,25delivered), onlyfixedfixture substituted: same clean exactPASS; source hashes retained. Current26underconstruction catalog also passed fixture; not a claim of26-game playable delivery.

Fresh scoped source reviewer approved minimalcopy/cleanup change and boundedfake-owned target, no newissue; reviewer didnot rerunengine. The test owns a uniquelynamed fakeGodotuserdata directory and verifies hashes of seeded fakeprimary/backup/tmp. It does not target the player's profile. A purefixture repair has noUI screenshot or humanplay/listening claim.
