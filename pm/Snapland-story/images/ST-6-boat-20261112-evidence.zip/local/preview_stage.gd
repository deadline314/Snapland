extends SceneTree
var main: Node
func _initialize() -> void:
	call_deferred("_run")
func _run() -> void:
	var progress := root.get_node("Progress")
	progress.intro_seen = true
	progress.set_setting("ui_scale", 1.25)
	main = load("res://game/main.tscn").instantiate()
	root.add_child(main)
	for i in range(5): await process_frame
	var stage: Node3D = load("res://game/story/boat_prologue_stage.gd").new()
	main.world.add_child(stage)
	if not stage.configure(main.world, progress.appearance, progress.equipped, false):
		push_error("Preview could not configure stage")
		quit(1)
		return
	main._start_dialogue(main.story.prologue_lines(), Callable())
	main.reveal = 999.0
	await create_timer(0.5).timeout
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png(OS.get_environment("SNAPLAND_SAVE_PATH").get_base_dir().path_join("composition.png"))
	stage.finish()
	main.free()
	await process_frame
	print("PASS: temporary native ferry composition captured")
	quit()
