### Task 3: First-run, replay and interruption integration

**Files:** Modify `game/main.gd`, `game/story/story_director.gd` entry metadata, `tools/run_game_tests.py`; create `game/tests/test_boat_prologue_integration.gd` and `.tscn`; update only affected existing story/UI fixtures; add native review fixtures as needed.

**Interfaces:** Consume Tasks 1/2. First-run only when both intro_seen and prologue_seen are false; returning players keep the original path. `show_beat` receives line index and pose from prologue_lines. Ordinary dialogue continues using existing code/UI/beep/reveal handling.

- [ ] Write/run failing integration tests for finish and skip into original arrival, replay to original location, repeated replay, external dialogue removal, scene exit, failed saving and no reward changes.
- [ ] Coordinate the Stage with existing `_start_dialogue`, `_render_dialogue`, `_finish_dialogue`, `_dialogue_panel_exiting` and quitting lifecycle. Guard against duplicate completion; interruption without actual finish/skip does not mark seen. Existing direct `_show_arrival` callers remain arrival-only.
- [ ] Add a pause replay action only while not in a minigame. Boat dialogue uses `直接下船` with contextual hover; existing dialogue defaults remain unchanged. Reuse focus, keyboard advance/skip and scale behavior.
- [ ] Change prologue entry to available with an honest description only after playback integration exists. Register all new state, stage and integration tests in the official runner and exact PASS marker contract. Existing tests specifically targeting arrival may explicitly set prologue_seen=true; do not globally bypass the new first-run path.
- [ ] Run affected story/save/dialogue/pause tests. Capture real native first-run and replay at 800×600, 1280×720 and 1920×1080 including text scale 1.25/reduced motion; inspect shots and run isolated PCK. Record fixture controls accurately. Controller completes native/export evidence if not owned by implementer.
- [ ] Self-review, commit owned files and write `task-3-report.md`; do not push or mark the ticket complete.
