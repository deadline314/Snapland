### Spec Compliance

- ✅ Spec compliant for the Task 2 behavior verifiable from this diff. The three requested files are present: the new Stage (`game/story/boat_prologue_stage.gd:1`), focused tests (`game/tests/test_boat_prologue_stage.gd:1`), and only a four-line ferry-local marker addition (`game/world/park_world.gd:1149`). No out-of-scope Main, Progress, StoryDirector, registry, asset, or ticket change appears in the review package.
- ✅ The required interface and lifecycle are implemented at `game/story/boat_prologue_stage.gd:28`, `:80`, `:110`, and `:123`. Configure rejects active reuse, invalid world/parent/tree membership, missing components, invalid pixel size, and a missing initial texture before it changes player/camera/world presentation (`:29–37` versus `:57–76`). Finish is idempotent; exit delegates to the same restoration path (`:111–124`).
- ✅ The preview uses the world's existing AvatarRenderer, one Sprite3D, approved complete renderer textures, and the existing avatar pixel size/filter/shading (`game/story/boat_prologue_stage.gd:33–37`, `:42`, `:65–75`, `:106`). It adds no renderer, world, image composer, image cache, texture source, deformation, or camera animation. The feet offset uses the canonical image center and FEET_BASELINE along normalized camera up (`:76–77`).
- ✅ Player visibility and world physics are captured exactly and restored, including originally hidden/disabled states; camera local transform, size, and projection are captured and restored (`game/story/boat_prologue_stage.gd:46–50`, `:57–63`, `:114–119`). Stage never assigns player transform, facing, progress, or rewards. Tests cover the real-world setup, active reconfigure, exact restoration, preserved location/facing, repeated finish, repeat configuration, and external removal (`game/tests/test_boat_prologue_stage.gd:39–65`, `:100–120`).
- ✅ Playback rejects stale/duplicate beats and unknown/unavailable authored actions, uses library durations/frame timing for finite actions, returns to idle, and uses idle_frame_for_time for idle (`game/story/boat_prologue_stage.gd:80–108`). Reduced motion holds the initial approved idle pose (`:85`, `:93`). Exceptional delta is finite-checked and clamped (`:94`); texture requests occur only on action/frame changes (`:104–108`). Tests cover these paths and node/cache bounds (`game/tests/test_boat_prologue_stage.gd:66–99`, `:110–118`).
- ⚠️ Cannot verify from the diff: native camera composition, whole-ferry framing, actor head/feet/rail clearance, and clearance above the actual bottom dialogue plaque at required viewport sizes (`game/story/boat_prologue_stage.gd:59–64`, `:76–77`). These remain the controller's native integration/calibration gate after Task 3, as expressly assigned; this review does not claim they passed.
- ⚠️ Cannot verify from the diff: actual Task 3 caller sequencing, dialogue lifecycle/NPC hold, and restoration after integrated Main cancellation. The Stage provides the required restoration hooks (`game/story/boat_prologue_stage.gd:110–124`); the controller should exercise those integration paths after wiring them.

### Strengths

- A single shared finish path handles both normal completion and removal, with no duplicate restoration logic (`game/story/boat_prologue_stage.gd:110–124`). Snapshot state is preserved across rejected active configure calls (`:29`, `:46–50`), and the test explicitly checks that guard (`game/tests/test_boat_prologue_stage.gd:61–62`).
- The implementation keeps temporary ownership narrow: one preview child, existing renderer/cache, unchanged real-player transform and facing, synchronous preview cleanup (`game/story/boat_prologue_stage.gd:65–77`, `:120–121`; `game/tests/test_boat_prologue_stage.gd:64–70`, `:99–106`).
- Tests instantiate real ParkWorld and a counting subclass of the real renderer rather than substituting fake playback behavior (`game/tests/test_boat_prologue_stage.gd:8–12`, `:27–32`). They check authored frame selection and finite completion, unchanged-cel request counts, originally disabled state, and bounded long playback (`:71–99`, `:107–120`).

### Issues

#### Critical (Must Fix)

- None found in the reviewed Task 2 scope (`game/story/boat_prologue_stage.gd:28–124`; `game/tests/test_boat_prologue_stage.gd:21–127`; `game/world/park_world.gd:1149–1152`).

#### Important (Should Fix)

- None found in the reviewed Task 2 scope. Native visual acceptance is still pending the explicitly deferred controller gate (`game/story/boat_prologue_stage.gd:59–77`).

#### Minor (Nice to Have)

- **Existing world-construction diagnostics make the focused test output noisy.** `game/tests/test_boat_prologue_stage.gd:28` builds the full existing world; the recorded green log contains 15 OcclusionController warnings for unsupported StandardMaterial3D and ShaderMaterial surfaces before PASS (`.superpowers/sdd/2026-11-12-boat-prologue/task-2-green.log:3`, `:39`, `:139`, `:150`). The backtraces place them in unchanged world-building/occlusion paths; they are not evidence of a Stage regression and do not block this task. Track or explicitly account for those known construction warnings in the existing test infrastructure so future unexpected warnings remain visible. The report's description mentions ShaderMaterials but omits the four StandardMaterial3D warnings.

### Focused Checks and Evidence

- **Named risk: ordinary world callbacks could overwrite the staged camera or move/change facing of the hidden real player.** Inspected only the relevant unchanged `ParkWorld._physics_process` and `_process` paths (`game/world/park_world.gd:2236–2354`), plus player visual parenting (`:2148–2169`). Player movement/facing and follow-camera assignments are in the disabled physics callback (`:2271–2295`, `:2321–2322`); the ordinary process callback does not assign player transform/facing or camera. The player visual/shadow children are under the hidden player root (`:2163–2167`). Stage's physics suspension and root visibility therefore address this concrete risk (`game/story/boat_prologue_stage.gd:57–58`).
- **Named risk: using renderer APIs incorrectly could introduce unapproved/fallback action frames or private resource growth.** Inspected only the relevant unchanged renderer contract (`game/world/avatar_renderer.gd:191–197`, `:212–270`, `:2028–2039`) and constants (`:6`, `:49–50`). The Stage calls the authored-action guard and the existing texture and idle timing APIs with front direction, uses the shared renderer cache, and derives feet from the matching canonical constants (`game/story/boat_prologue_stage.gd:37`, `:76`, `:82`, `:88`, `:104–106`). No additional image/texture generation is added by Stage.
- Read the supplied `a23dd1d273d163b910644e9c66b243522a0b9eb7..d73ad044d87e17145b5b5608444d9d4b5ac29343` review diff once. No changed file was separately re-read; the focused unchanged-code checks above were the only source expansion.
- Read the existing Task 2 report and green log. The log ends with PASS (`.superpowers/sdd/2026-11-12-boat-prologue/task-2-green.log:150`) and contains the warnings described above, with no ERROR/SCRIPT ERROR visible. Exit 0 and RED-before-GREEN are report claims; no test command was rerun and no additional runtime behavior is claimed.

### Assessment

**Task quality:** Approved.

**Reasoning:** The Stage has a small, reversible ownership boundary, validates before presentation mutation, reuses the existing rendering/animation APIs, and has focused behavioral coverage for restoration and playback. The only observed quality finding is pre-existing diagnostic noise; native composition and integrated cancellation remain the controller's later gate.

Skipped: repeated tests, native rendering, broad codebase review, and source/index/HEAD changes.
Risk: camera/rail/dialogue clearance and Task 3 integration remain unverified until the controller's native gate.
