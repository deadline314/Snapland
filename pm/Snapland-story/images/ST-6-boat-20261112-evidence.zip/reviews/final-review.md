# ST-6 whole-branch final review

Range: `2dcb765cb6c43e1651a494b61f01e7fe5ad75b92..16ab825839c96f9867b5a66cbc1f510c2661c2e2`.
Requirements: `design/runtime/boat-prologue.md` and `docs/superpowers/plans/2026-11-12-boat-prologue.md`.
Review source: supplied whole-branch package `review-2dcb765..16ab825.diff`, read in bounded sections; prior task reviews and recorded evidence. No git diff was regenerated and no tests were rerun.

## Strengths

- Persistence extends the existing version-1 payload and transactional save path without adding rewards or a second write. New/reset state is false; valid legacy saves and malformed optional values load as seen. Failed completion rolls back memory, while the focused state test compares the entire normalized payload and both durable files (`game/core/progress.gd:75`, `:571`, `:826`, `:885`, `:922`; `game/tests/test_boat_prologue_state.gd:37`).
- Optional story data has explicit validation and deep-copy isolation; the authored five beats preserve the requested speaker/action sequence. Missing or invalid data cannot start the boat stage, and Main safely uses the existing arrival (`game/story/story_director.gd:251`, `:265`; `game/data/first_park_story.json:23`; `game/main.gd:1020`).
- One temporary actor uses the existing renderer/cache and full textures. Configuration validates before mutating presentation; canonical feet placement, finite authored actions, unchanged-frame reuse and reduced-motion stillness are explicit. One idempotent cleanup path restores camera, physics and the original visibility (`game/story/boat_prologue_stage.gd:28`, `:76`, `:80`, `:110`).
- Main separates actual completion/skip from replacement, external panel removal and exit. Stage ownership is cleared before saving or starting arrival; old panel callbacks cannot clear the replacement panel. Replay closes pause before stage setup and returns to the original world state; direct arrival remains arrival-only (`game/main.gd:559`, `:1020`, `:1047`, `:1054`, `:1064`, `:1129`, `:1157`).
- The runner exception accepts exactly one deliberate state-suite IO error for that suite's exact isolated path. Missing, duplicate, wrong-path and unrelated errors still fail. All three boat suites require exact completion lines; the integration child independently verifies zero exit, one exact error and its exact PASS line (`tools/run_game_tests.py:135`; `tests/test_runtime_result_contract.py:158`; `game/tests/test_boat_prologue_integration.gd:140`).

## Issues

### Critical

None found.

### Important

None found.

### Minor

No new code finding. The previously recorded 15 OcclusionController material warnings remain a known nonblocking diagnostic issue in unchanged world construction. Their source is not the Stage; the change does not broadly suppress them. Keep them recorded rather than treating them as a clean-warning claim.

## Cross-task checks and evidence

- Read all changed production code, tests/fixtures, runner contracts, requirements and scope documents in the supplied package. Existing arrival-only fixtures opt out explicitly, while the new integration/native fixtures exercise actual first-run playback.
- Inspected only omitted context for named lifecycle risks: pause restoration, callback clearing and old-panel identity, dialogue modal state, and whether ordinary world/ride processing could move the hidden player or overwrite the stage camera. Follow-camera/player movement lives in suspended world physics; ordinary world processing does not overwrite them. Existing ride processing terminates when pause blocks the world before a natural pause-menu replay. No new issue identified.
- Read prior task review reports and the ledger. Read post-commit runner evidence showing import/startup/state/stage/integration 5/5 and contract-unit evidence showing 17/17. Earlier focused/regression results are retained from the supplied reports; no duplicate execution was needed.
- Read final three-size native reports: each records 10 captures, exact requested/window/viewport/image dimensions and an empty failures array. Configurations include 800x600 reduced motion plus 1.25 text, 1280x720 normal motion, and 1920x1080 plus 1.25 text. The controller supplied the image inspection for complete figures, deck and usable controls; this report does not claim a second visual inspection.
- Read the isolated PCK log's native Main first-run/replay PASS and the Windows startup log tail. Full log error counts, fresh-profile setup and export provenance are controller evidence, not independently rerun here.
- Shutdown guards are correctly ordered: quitting is set before Stage restoration and area-change/process/input guards prevent the recorded audio restart route. No human play or listening is claimed.

## Recommendations

Complete the controller-owned ticket/evidence and public scope updates, verify final commit metadata, and wait for the full runtime CI result before publication. Those pending administrative/CI gates are not missing boat implementation. Retain the known warning ledger without broad suppression.

## Declined to judge

- Remaining nine areas, 116 further games, endings, platform multiplayer and whole-game completion: explicitly outside this ST-6 delivery; the new delivery document distinguishes the planned full game from current playable scope.
- New character art or unrelated animation-quality tickets: no source art is changed; this ticket reuses approved complete character textures.
- Human play and listening acceptance: automated tests and captures cannot establish either; the implementation and evidence make no such claim.
- Repairing existing OcclusionController material handling: unchanged world subsystem, already recorded as deferred minor diagnostic noise, with no demonstrated boat regression.
- Final closure edits, raw commit metadata and the still-running full runtime CI: controller-owned gates outside the supplied reviewed HEAD; no approval of unseen edits or unfinished CI is implied.

## Assessment

**Ready to merge? Yes, from code review; final controller delivery gates remain.**

The branch implements the complete ST-6 behavior with narrow changes, safe legacy/save behavior, reversible presentation and meaningful integration coverage. No new must-fix or should-fix finding remains; merge/publication should follow successful runtime CI, metadata verification and the explicitly pending evidence/ticket closure.

Skipped: repeated tests, duplicate native rendering/image inspection, raw metadata verification and unrelated subsystem review; no tracked files, index or branch state changed.
Risk: existing material warnings remain visible; unfinished CI and final closure/metadata must be resolved by the controller before publication.
