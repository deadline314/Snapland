# Task 2 report

Status: complete; focused verification passed. Native composition calibration remains the controller's integration gate.

Commit: `d73ad044d87e17145b5b5608444d9d4b5ac29343` (`feat(story): add reversible ferry prologue stage`), author email `stanley890314@gmail.com`.

Base: `a23dd1d273d163b910644e9c66b243522a0b9eb7`.

## Scope and implementation

- Added only `game/story/boat_prologue_stage.gd`, `game/tests/test_boat_prologue_stage.gd`, and four ferry-local lines in `game/world/park_world.gd`.
- The existing ferry owns `FerryDeckStageAnchor` at `(5.5,1.04,22.65)`; no scenery or textures rebuilt.
- Stage implements `configure`, `show_beat`, `finish`, and restoration from `_exit_tree`. Configure preflights parent/tree membership, real player, camera, avatar, renderer, deck marker, valid pixel size and initial approved texture before changing presentation state. Active configure fails without overwriting restoration state.
- Hides the real player root (including existing actor/shadows); does not move it or change facing. Saves exact local camera transform, size and projection, player visibility and world physics enabled state; restores them idempotently. Removes its single temporary Sprite3D synchronously at finish.
- Preview shares `world.avatar_renderer`, the bounded texture cache, complete approved front textures, existing avatar pixel size/filter/shading. Canonical feet offset `(FEET_BASELINE - CANVAS_SIZE.y / 2) * pixel_size` is applied along normalized camera up, so the feet point coincides with the marker in all three world coordinates.
- Finite interact/photograph/wave clips use the renderer's animation library durations and frame timing, then idle. Idle uses `idle_frame_for_time`. Requests textures only when action/frame changes. Rejects unknown actions, stale and duplicate beat indices. Delta is finite-checked and clamped to 0..0.1. Reduced motion keeps approved idle cel 0 across all beats.
- Fixed bow-facing orthographic view: size 15.5, target `world.to_global(Vector3(5.5,1,24.6))`, offset `(7,12,-18)`, then camera moved down its up axis 2.8. Controller may calibrate after native rendering with the real dialogue panel.

## Verification

All commands ran from `C:/Users/stanl/Github/Snapland/.review/full-game-worktree`. Every direct engine invocation used an absolute isolated save path under this worktree's `.review/st6`.

RED (before implementation):

```powershell
$env:SNAPLAND_SAVE_PATH='C:/Users/stanl/Github/Snapland/.review/full-game-worktree/.review/st6/task2-red-save.json'
& 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe' --headless --path . --script res://game/tests/test_boat_prologue_stage.gd *> .superpowers/sdd/2026-11-12-boat-prologue/task-2-red.log
```

Observed `FAIL: reversible ferry stage exists` because the requested stage did not exist. The log also reports the expected missing-resource errors. The enclosing output command did not preserve the engine exit code; failure was verified from the explicit test failure and absence of PASS, not inferred from that shell result.

GREEN (run twice, second after adding active reconfiguration/same-cel/idle timing checks):

```powershell
$env:SNAPLAND_SAVE_PATH='C:/Users/stanl/Github/Snapland/.review/full-game-worktree/.review/st6/task2-green-save.json'
& 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe' --headless --path . --script res://game/tests/test_boat_prologue_stage.gd *> .superpowers/sdd/2026-11-12-boat-prologue/task-2-green.log
$engineExit=$LASTEXITCODE
Select-String -Path .superpowers/sdd/2026-11-12-boat-prologue/task-2-green.log -Pattern '^ERROR:|^SCRIPT ERROR:|^PASS:|scenery meshes'
exit $engineExit
```

Exit 0. `PASS: boat prologue reversible ferry stage, timing, and bounded preview`. No ERROR or SCRIPT ERROR in green log. Existing world construction emits OcclusionController warnings for unsupported ShaderMaterials; those warnings preserve the original materials and do not fail the test.

The test builds real ParkWorld and uses a counting subclass of the real AvatarRenderer to assert no texture request within unchanged frames. It verifies missing/null components and marker, unchanged state on failed configuration, no active duplicate configure, exact camera restoration, initial visible/enabled and originally hidden/disabled states, preserved player transform/facing, camera-up feet anchor, authored action and idle timing, finite completion, unknown/stale/duplicate beats, NaN/INF delta, reduced motion, 500 idle ticks, one temporary node and bounded shared cache, repeat configure, idempotent finish and external removal.

`git diff --cached --check` passed before commit. Staged stat contained exactly the three owned files.

## Self-review and concerns

- Reviewed every field mutation and restoration path; stage changes only the state it owns, and all mutations follow configuration validation.
- Stage takes player-root visibility rather than avatar-only visibility, so actor shadows and any other real-player visual children cannot linger in the ferry view. Existing avatar-specific visibility is never changed.
- The caller must add Stage as a world child before configure. The caller owns dialog lifecycle/NPC hold. Those integration responsibilities were intentionally left to Task 3.
- No native screenshots, small-viewport plaque overlap checks, PCK/export, human play or audio checks were run for Task 2, per the controller's ownership. Camera/head/feet/rail clearance and dialogue composition need the controller's native calibration.
- No broad suite, new fixtures, PNG edits, dependency, limb reconstruction, world replacement, branch change or push. Generated `.import`/`.uid` files were left alone and uncommitted.
