### Task 1: Story data and durable completion flag

**Files:** Modify `game/core/progress.gd`, `game/story/story_director.gd`, `game/data/first_park_story.json`; create `game/tests/test_boat_prologue_state.gd`.

**Interfaces:** `Progress.prologue_seen: bool` defaults false in new/reset memory; loaded legacy saves without the key default true. `Progress.mark_prologue_seen() -> bool` is idempotent and rolls back on failed save. `StoryDirector.prologue_lines() -> Array` returns a deep copy of valid prologue dialogue or an empty array. Keep the existing future entry status until Task 3 integrates playback.

- [ ] Write and run a failing focused test for default/reset false, legacy missing flag true, explicit false/true round trips, idempotence, failed save rollback, malformed optional field, and unchanged coins/photos/unknown fields.
- [ ] Add exactly five prologue lines to first_park_story.json, in order: 阿浪/idle welcomes the late-wind ferry approaching dock; 主角/interact secures the camera strap; 主角/photograph looks through the viewfinder; 阿浪/wave invites the player to greet the island; 主角/idle is ready to step onto the boardwalk. Text is short, warm, consistent with existing cast and non-punishing; there is no reward.
- [ ] Validate supplied prologue lines: allowed existing speaker, nonempty text, whitelisted pose idle/interact/photograph/wave. A missing optional field keeps legacy story validation working; invalid supplied data reports diagnostics and returns no prologue lines.
- [ ] Extend the existing save payload/validation/load/reset paths without bumping version, without moving fields into an unrelated wrapper, and without saving twice. Warning/default for malformed optional flag; preserve all unrelated data.
- [ ] Run the new state test and existing story/save checks affected by the edits. Record the red/green evidence, self-review, commit only owned files and write `task-1-report.md` with status, commits, tests and concerns.

