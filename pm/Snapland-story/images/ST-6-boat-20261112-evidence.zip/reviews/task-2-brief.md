### Task 2: Reversible ferry presentation

**Files:** Create `game/story/boat_prologue_stage.gd`, `game/tests/test_boat_prologue_stage.gd`; modify only the ferry portion of `game/world/park_world.gd` to add `FerryDeckStageAnchor`.

**Interfaces:** Stage extends Node3D. `configure(world: Node3D, appearance: Dictionary, equipped: Dictionary, reduced_motion: bool) -> bool`, `show_beat(index: int, action: String) -> void`, `finish() -> void`. Caller adds Stage as a world child before configure. Failed configuration changes nothing. `finish` is idempotent and `_exit_tree` restores state too.

- [ ] Write/run failing tests for configuration, exact restoration, duplicate beats, missing world components, reduced motion and bounded temporary nodes.
- [ ] Add one named Marker3D at the existing ferry's forward deck, initially `(5.5,1.04,22.65)`. Use the spec's camera/composition constraints; calibration after native rendering is allowed.
- [ ] Reuse `world.avatar_renderer` and approved full AvatarRenderer textures, with the existing avatar's pixel_size. Preview feet coincide with the deck marker: compensate along the camera up vector using `AvatarRenderer.FEET_BASELINE` and the canonical image center. Preserve the real player's transform/facing; hide and restore its original visibility and disable/restore world physics.
- [ ] Save/restore camera transform, size and projection. Frame the whole ferry/actor above the existing bottom dialogue plaque. No new world, source PNG, body deformation or camera sway.
- [ ] Idle uses `idle_frame_for_time`; finite front actions use the existing animation library timing then return to idle. Update the texture only on frame changes. Reduced motion keeps a fixed approved pose. Clamp exceptional delta; reject unknown actions safely; repeat beat indices do not restart playback.
- [ ] Run focused stage tests, self-review, commit owned files and write `task-2-report.md`. Do not touch Main, Progress, StoryDirector, registry or ticket.

