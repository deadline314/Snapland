# Task 3 report — first-run and replay integration

Status: implemented and self-reviewed; controller owns final native screenshots, PCK/Windows export, ticket and publication. No push or branch changes.

Base: d73ad044d87e17145b5b5608444d9d4b5ac29343. Worktree: C:/Users/stanl/Github/Snapland/.review/full-game-worktree. Branch: codex/boat-prologue-20261112.

## Scope and behavior

Main now starts the approved reversible boat Stage only when both intro_seen and prologue_seen are false. Natural completion and Esc/直接下船 invoke the same guarded completion callback, restore the Stage, call the transactional Progress.mark_prologue_seen once, then start unchanged _show_arrival. Direct _show_arrival remains arrival-only. Missing optional lines or failed Stage configuration use the original arrival path. No reward, collection, save-version, Progress, Stage, world, story JSON or asset changes were made.

Pause offers 重看船上序章 only outside a minigame; replay explicitly resumes pause's world presentation/audio, then uses the existing panel, reveal, keyboard input, beep and scale handling. Replay finishes or skips back to the original location without starting arrival. Reentrant starts retain one Stage; duplicate completion is harmless. Replacement dialogue, external panel removal and scene exit restore Stage state without marking seen. External removal also restores HUD visibility. Ordinary dialogue restores its default cancel text even if it reuses a boat panel.

Self-review and startup verification found a shutdown race: Stage cleanup restored world physics before its initial area-change notification had happened. That notification could start harbor/ambience after audio.shutdown. Main's area-change callback, process and input now ignore work once quitting is true. The official startup suite caught this as three leaked audio resources, and passes cleanly after the fix. Stage itself still restores its saved physics/camera/visibility state.

StoryDirector changes are limited to PROLOGUE_ENTRY available status and honest description. Official runner registers state, Stage and integration tests with exact PASS lines.

Ruling: the existing state suite deliberately causes one real temporary-file IO failure. result_error now accepts exactly one full-match diagnostic for that suite's exact isolated SNAPLAND_SAVE_PATH + .tmp and exact Can't open file text, using re.escape on the variable path. Missing, duplicate, other-path, changed-text, other engine errors and nonzero exits fail. No other suite has this exception. Unit checks exercise all these cases, regex metacharacters in paths, and exact completion lines.

Ruling: integration save-failure coverage runs a captured child Godot process with a separate absolute isolated profile. It must return0, print its exact child PASS line, and emit exactly the expected single IO error, with no script/runtime/other errors. Parent integration output remains clean, so the official runner's only diagnostic exception stays state-suite-specific. Child proves failed persistence keeps seen false and durable file bytes/rewards unchanged while restoring Stage and continuing original arrival.

## Tests and evidence

All direct Godot runs used an absolute isolated SNAPLAND_SAVE_PATH under .review/st6/. Official runner creates a fresh absolute per-suite temporary directory. Engine: C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe. Audio: Dummy. These are automated checks, not human gameplay/listening.

Red, before implementation:

- Direct headless res://game/tests/test_boat_prologue_integration.tscn failed with `FAIL: first run opens ferry before arrival`. Log: task-3-red.log.

Green:

- `python -m unittest tests.test_runtime_result_contract -v` —17/17 passed. Later quiet repeat17/17; task-3-unit.log.
- `python tools/run_game_tests.py --only 'boat prologue' --only 'story runtime' --only 'main story integration' --only 'island dialogue' --only 'main scene integration' --only 'pixel UI shell' --keep-going` —9/9 including clean import, all3 new suites, original story, dialogue and pause/layout coverage. task-3-runner.log.
- Focused direct integration after self-review/default cancel/HUD/legacy-save improvements passed without ERROR or leak warnings. task-3-integration-final.log.
- Final expanded runner before shutdown fix: clean import, core runtime, boat integration (including actual legacy save and keyboard skip), island dialogue and pixel UI shell all passed; startup alone caught the audio race. task-3-final-runner.log records this deliberately retained failure history.
- `python tools/run_game_tests.py --only 'game startup' --only 'tutorial seen progress' --keep-going` after shutdown guards and legacy tutorial fixture update —3/3 passed, including clean import. task-3-shutdown-runner.log.
- Direct post-fix startup passed with no ERROR/leak warning. task-3-smoke-final.log. Its persisted intro/prologue remain unseen during interruption.
- `git diff --check` for owned files passed.

New integration checks: five indexed beats; reentrant start; first-run natural finish saved once; original arrival completion/skip; actual legacy-file flag migration; intro-seen bypass; pause replay natural finish and repeated skips; exact synchronous player transform/camera/visibility/physics restoration; deferred preview removal; pause audio/process resumption; no replay in a live session; keyboard first-run skip; external panel removal; replacement dialogue with ordinary cancel defaults; scene exit; absent story/failed anchor fallback; real isolated failed save continuation; reward/appearance/unknown-field invariance.

Only intentional original-arrival fixtures set prologue_seen=true: existing story/Main/dialogue tests; four existing native original-arrival dialogue/NPC/entry/flow reviews; optional avatar world-reach audit; tutorial-failure child that historically begins with arrival. Fixtures already setting intro_seen=true keep their existing behavior. Dedicated new integration and native boat fixtures do not bypass first-run. Main thumbnail/original helpers instantiate Main outside the tree and do not run startup. Optional two-process progress review now includes prologue_seen in its snapshot fields.

## Native fixture for controller

Entry: res://game/tests/native_boat_prologue_review.tscn. Use a GPU-backed Godot window and absolute isolated SNAPLAND_SAVE_PATH. Optional fixture-only environment:

- SNAPLAND_BOAT_REVIEW_SIZE=800x600,1280x720,1920x1080 (default1280x720)
- SNAPLAND_BOAT_REVIEW_TEXT_SCALE=1 or1.25 (default1)
- SNAPLAND_BOAT_REVIEW_REDUCED_MOTION=1 (default off)
- SNAPLAND_BOAT_REVIEW_OUTPUT=absolute output directory (default profile sibling native-boat-review)

The fixture preserves appearance/equipped/owned-clothes from its already-loaded isolated profile across its new-progress reset, so controller may seed an isolated profile with the desired current appearance. It uses actual Main first-run, advances through five beats, finishes into arrival, returns to island, opens pause's real replay control, replays and skips back to the same location. Captures: first-run-beat-1..5, arrival, return-to-island, pause-replay-control, replay-controls, replay-return, plus report.json. Beat captures wait0.3s for mid-action cels; report records actual action/elapsed timing. Reduced motion honestly records idle.

The fixture explicitly sets root content_scale_size, content_scale_aspect IGNORE and actual window size to the requested dimensions. It checks actual window size, visible viewport and each saved image size all equal requested dimensions; report records each separately. It checks subtitle/advance/cancel and pause replay control bounds. This avoids labelling a stretched800x450 image as800x600. It checks the Stage consumes the loaded appearance/equipped values. At exit it shuts down audio, waits0.25s, frees Main and waits deferred frames before quitting.

Expected native completion: `PASS: native Main boat first-run and replay captures (WIDTH, HEIGHT); inspect images for visual acceptance`.

Native execution, visual acceptance at all sizes/settings, and isolated PCK/Windows runs remain controller-owned. The fixture was parsed by clean editor imports; I did not claim native screenshots or PCK evidence here.

## Self-review / remaining concerns

- No modifications to approved Stage/world/Progress/story JSON or parent-owned README/tickets; no .import/.uid churn staged.
- Stage cleanup remains idempotent and exact; completion clears current panel callbacks before opening arrival, and stale old-panel tree-exiting signals cannot tear down the new panel.
- Deliberate IO errors remain real; neither runner nor integration child broadly suppresses diagnostics.
- Existing15 world ShaderMaterial warnings per constructed world remain unchanged; repeated Main creation multiplies these expected warnings. No warning cleanup was included.
- Legacy native reviews and the optional avatar world-reach audit were updated narrowly for arrival-only setup but were not rerun natively/by that optional mode here. Controller owns native/export evidence. Human play/listening is not established.

## Commit

16ab825839c96f9867b5a66cbc1f510c2661c2e2 — feat: integrate replayable ferry prologue. Author email verified stanley890314@gmail.com; no trailers. Exactly19 assigned implementation/test/runner files committed. Unrelated parent edits and asset import/UID churn remain unstaged.

Post-commit verification of exact16ab825: `python tools/run_game_tests.py --only 'boat prologue' --only 'game startup' --keep-going` passed5/5 (clean import4.70s, startup4.05s, state0.38s, Stage8.53s, integration23.95s). Log: task-3-postcommit-runner.log. This clean import parses the final0.3s native capture fixture and action timing report. Post-fix startup's isolated JSON was checked: both intro_seen and prologue_seen remain false after quitting mid-boat.

## Task 3 fix round 1 — Linux child teardown (2026-11-12)

Trigger: CI43242323231 passed the design/Python job and runtime suites through80/104, then rejected the integration child with the generic exact-diagnostic assertion. No production playback/native/export defect was observed by controller.

Investigation and reproduced failure:

- Reproduced the original failing integration fixture locally in Ubuntu WSL2 with the exact pinned Godot4.7.2 Linux x86_64 build. Absolute isolated profile: /tmp/snapland-boat-debug/initial/progress.json. Log: task-3-linux-red.log. It failed the same assertion as CI.
- Added bounded failure diagnostics before changing teardown, then repeated on Linux with isolated /home/stanley/.cache/snapland-boat-debug/diagnostic/progress.json. Log: task-3-linux-diagnostic.log.
- Captured result was exit=0 and exact child PASS present, with the exact expected temporary-file IO error PLUS `ERROR: 3 resources still in use at exit (run with --verbose for details).` Thus this was not environment inheritance, path normalization, PASS parsing or error-text portability. The original strict check correctly rejected a real teardown error.

Concrete root cause: `_save_failure_child` cancels the boat, restoring world physics and opening arrival. `_dispose` then called audio.shutdown and waited0.2seconds while Main.quitting was still false. The now-enabled world's initial area_changed notification could run during that wait and restart harbor/ambience audio. Scene destruction then left those playback resources in use at process exit. Linux scheduling exposed this fixture race; Windows-only verification had not exposed it. Production `_quit_game` already sets quitting before cleanup and its callbacks already guard that state, so no production changes were needed.

Small fix, scope exactly game/tests/test_boat_prologue_integration.gd:

- Set main.quitting=true before fixture audio shutdown, mirroring real quit without saving or stopping the test process.
- Make the regression deterministic: emit the pending area_changed event after shutdown, then check the audio context stays empty through the teardown wait. This no longer depends on either OS's scheduling to exercise the dangerous callback.
- Keep the child acceptance predicate unchanged: exit0, exact child PASS and errors equal exactly the one expected isolated-path IO diagnostic. No errors are stripped, normalized or suppressed.
- On failure, report exit code, PASS presence, exact expected diagnostic (display capped500chars), captured error list (1000chars) and child output tail (3000chars). This exposes launch failures, missing PASS, extra errors and the relevant final stack trace without dumping the full repeated world-warning log. Comparisons still use complete untruncated values.

Validation:

1. Linux official runner: `GODOT_BIN=/home/stanley/.cache/snapland-boat-debug/Godot_v4.7.2-stable_linux.x86_64 python3 /mnt/c/Users/stanl/Github/Snapland/.review/full-game-worktree/tools/run_game_tests.py --only 'boat prologue integration' --timeout-scale 2` —2/2passed (clean import33.02s; integration46.14s). Uses runner-generated absolute isolated profiles. Log: task-3-linux-fix-runner.log. Scale2 accommodates slower WSL access to the mounted Windows worktree; observed integration duration is below the normal90s limit.
2. Final-source Linux child including deterministic pending-event assertion: direct headless scene with `-- --boat-save-failure-child`, isolated /home/stanley/.cache/snapland-boat-debug/final-child/progress.json —exit0, exactly the expected IO ERROR, exact child PASS, no resource leak. Log: task-3-fix-linux-child-final.log.
3. Final-source Windows official runner: `python tools/run_game_tests.py --only 'boat prologue integration'` with pinned GODOT_BIN —2/2passed (clean import5.83s; integration21.96s), including deterministic cleanup check on every Main disposal. Log: task-3-fix-windows-runner.log.
4. Final-source Windows focused child, isolated .review/st6/task3-fix-round1-windows/progress.json —exactly the expected IO ERROR and child PASS, no resource leak. Log: task-3-fix-windows-child.log.
5. `git diff --check -- game/tests/test_boat_prologue_integration.gd` passed. Self-review confirmed only fixture-owned changes, unchanged acceptance predicate, no production/runner/CI changes, no dependencies or new CI framework.

All engine executions used isolated absolute profile paths. No diagnostic-only commit or remote CI rerun was necessary to identify the root cause, because local Linux reproduced it directly. Parent owns push and the full remote CI rerun. Final CI confirmation remains outstanding; previous native/export evidence is unaffected by this test-only change.

Fix-round1 commit: 8512937d37e522a52d47484431f6be6921e589a2 — test: prevent audio restart during boat fixture cleanup. One owned file,8insertions/2deletions; author stanley890314@gmail.com. No push. Parent-owned unstaged files remain untouched.
