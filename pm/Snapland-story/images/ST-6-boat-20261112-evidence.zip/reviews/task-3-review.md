### Spec Compliance

- ✅ Spec compliant for the implementation reviewed: startup requires both unseen flags; replay is available only outside a session; finish/skip restores the Stage and distinguishes arrival from free roam; interruption clears presentation without marking completion (`game/main.gd:94`, `game/main.gd:962`, `game/main.gd:1020`, `game/main.gd:1047`, `game/main.gd:1054`, `game/main.gd:1157`). Direct arrival remains unchanged at `game/main.gd:1061`.
- ✅ All three suites are registered and require exact completion lines; the sole permitted engine diagnostic is one exact state-suite temporary-write error for the supplied isolated profile (`tools/run_game_tests.py:22`, `tools/run_game_tests.py:135`, `tools/run_game_tests.py:267`; focused rejection coverage in `tests/test_runtime_result_contract.py:158`). The integration child independently requires its exact PASS line, zero exit and exactly the expected error (`game/tests/test_boat_prologue_integration.gd:140`).
- ✅ Scope remains integration, fixtures and runner contracts: the package contains no Stage, world, Progress, story-data or asset changes; entry metadata becomes honestly available (`game/story/story_director.gd:39`). Existing arrival fixtures explicitly opt into arrival-only setup rather than globally bypassing first-run (`game/tests/test_story_integration.gd:24`, `game/tests/test_island_dialogue.gd:67`).
- ⚠️ Native visual acceptance and isolated PCK/Windows execution are controller-owned and in progress. The automated fixture exercises real Main first-run and pause replay and validates actual window/viewport/image dimensions; its captures are not human gameplay evidence (`game/tests/native_boat_prologue_review.gd:54`, `game/tests/native_boat_prologue_review.gd:67`, `game/tests/native_boat_prologue_review.gd:82`, `game/tests/native_boat_prologue_review.gd:97`). This is an outstanding delivery check, not missing implementation.
- ⚠️ The review package lists the commit but omits author email and full commit message; the report claims these were checked. Controller should retain its metadata verification for the user email/no-assistant-trailer constraint (`task-3-report.md`, Commit section).

### Strengths

- ✅ Completion is guarded by the live Stage, clears Stage ownership before persistence/arrival and reuses the existing dialogue callbacks. Replacement and external panel removal restore ordinary dialogue defaults and HUD visibility (`game/main.gd:1054`, `game/main.gd:1064`, `game/main.gd:1094`, `game/main.gd:1157`).
- ✅ Integration exercises actual legacy migration, repeated replay, keyboard skip, scene/panel/replacement interruption, missing data/anchors and a real isolated persistence failure, with reward/appearance invariance checks (`game/tests/test_boat_prologue_integration.gd:16`).
- ✅ Shutdown sets quitting before restoring Stage physics; the area-change and processing guards prevent the previously observed audio restart after shutdown (`game/main.gd:80`, `game/main.gd:227`, `game/main.gd:623`, `game/main.gd:671`).
- ✅ Existing pause closure resumes world presentation/audio before replay configuration. Focused inspection of `game/main.gd:559` confirmed this cross-cutting interaction. The diff truncates dialogue setup/finish bodies, so their omitted context was inspected at `game/main.gd:1064` and `game/main.gd:1129`: callbacks are cleared and old-panel identity detached before completion opens arrival, preventing deferred old-panel exit from interrupting the new dialogue.

### Issues

#### Critical (Must Fix)

- None.

#### Important (Should Fix)

- None.

#### Minor (Nice to Have)

- Previously approved world-construction ShaderMaterial warnings remain deferred; this task does not introduce their source (`task-3-report.md`, Self-review / remaining concerns). No new minor code finding.

### Assessment

**Task quality:** Approved.

**Reasoning:** The change is narrow and uses existing dialogue/pause behavior while guarding Stage ownership, interruption and shutdown. Saved evidence reports post-commit clean import/startup/state/Stage/integration 5/5 and focused contract unit checks 17/17 (`task-3-postcommit-runner.log:1`, `task-3-unit.log:1`); shutdown/tutorial checks also pass (`task-3-shutdown-runner.log:1`).

- Checks performed: read the supplied brief, report and diff, recovered only the tool-truncated diff portion, inspected the named callback-ordering/pause-restoration/shutdown-input contexts, and read the stated final logs. No tests or git commands rerun; no source/index/branch mutation.
- Not checked here: native visuals, exports or raw commit metadata; controller owns those delivery risks. Only this ignored review report was written.
