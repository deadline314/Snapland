# SDD ledger — plan: docs/superpowers/plans/2026-11-12-boat-prologue.md

Workspace: C:/Users/stanl/Github/Snapland/.review/full-game-worktree
Branch: codex/boat-prologue-20261112
Spec: design/runtime/boat-prologue.md
Base: 2dcb765cb6c43e1651a494b61f01e7fe5ad75b92
Ticket registered/pushed: dc145ba. Plan/spec: 3026345.

Ruling: user opted out of design/permission check-ins and explicitly authorized per-ticket pushes/merges/cleanup — execute without approval prompts.
Ruling: native worktree creation did not return or create a registered checkout; cancel its waiting cell and use an ignored Git worktree — preserve the original main checkout and inspect for stray managed artifacts before finish.
Ruling: use the existing dialogue UI, reveal/audio pipeline and ferry geometry — no new panel or world; reduces memory and preserves accessibility.

## Preflight
| Tasks | Shared contract / self-consistency | Result |
|---|---|---|
| 1 | Save/story additions have focused tests; future entry remains future until integration | Consistent |
| 2 | Stage/marker changes are isolated; actor uses existing renderer and finite timing | Consistent |
| 3 | Integration consumes both APIs and owns runner registration, native evidence | Consistent |
| 1/2 | Pose names idle/interact/photograph/wave and current appearance | Both use validated strings, no new source images |
| 1/3 | New/reset false; legacy missing flag true; idempotent transactional mark | Main only starts boat before unseen arrival; replay never gives rewards |
| 1/3 | StoryDirector is shared | Task 1 adds getter/data; Task 3 changes entry metadata only after playback exists |
| 2/3 | configure/show_beat/finish and interruption cleanup | Main owns dialogue lifecycle, Stage restores world state idempotently |

## Tasks
- [x] Task 1 story/save state — a23dd1d, spec + quality approved (task-1-review.md)
- [x] Task 2 reversible stage — d73ad04, spec + quality approved (task-2-review.md)
- [x] Task 3 integration/native/pack —16ab825, spec + quality approved; source3sizes, isolatedPCK and Windowsstartup passed
- [ ] Whole-branch review, ticket evidence, merge/push, clean worktree

Baseline: .review/st6/baseline.log (running before implementation).

Baseline complete: 7/7 passed (.review/st6/baseline.log). Task1 commit a23dd1d; focused red/green +4/4 regressions, task review running. Task2 BASE a23dd1d; implementation dispatched (only stage/test/marker). Ruling: retain real filesystem-failure coverage; Task3 runner must accept exactly one suite-specific expected save diagnostic, reject missing/duplicates/other errors, with focused runner unit checks. No blanket suppression.


Task2 minor deferred: passing stage test emits15 preexisting world warnings; final review to triage, no new production error. Controller provisional native composition shows full actor/deck at1280x720 with1.25ui; loose private fixture is not final evidence (small requested resolution produced800x450; exit resources still in use). Task3 informed to create exact-size fixture and clean exit.

Controller native gate passed: final16ab825 fixture3sizes (800x600 reducedmotion+1.25ui/curlyrainvest,1280x720 normal/tide,1920x1080+1.25ui/bobrainvest). Each10captures, actualdimensions and controls checked, JSONfailuresempty. Visually inspected deck/wholeactor/readableplaque and800pause replay. DefaultForward+ isolatedPCK1280x720+1.25 passed10captures and inspected. Windows release startup freshprofile PASS0ERROR; source1087trackedfiles, binarySHA808B79AE0128DEDC6D9143337C8408566D52E34EB2DFE2B06F05158F9ECFC960. FullCI43242323231: Python/design complete success, runtime inprogress. Known15constructionwarnings preserved, not introduced byStage; no animation-warning suppression added.
Task3 fix round1/5: CI43242323231 runtimefailed at81/104 (child savefailure exact output assertion), Python182passed. Originalimplementer resumed; rootcause/evidence required, no exception weakening. Wholebranchreview approved source, this new CI gate blocks main publication. Parent native3sizes/PCKForward+/Windows startup+12artsmoke allpassed; final metadata emails verifiedall5commits. MAIN24ticket52cc543/design4007e83 opened on separateworktree approved16ab base; no newimplementationuntilTask3fix complete.
Task3fix rootcause reproduced exact pinnedLinux4.7.2 inlocalUbuntuWSL: childexit0/PASStrue, expectedIOerrorplus3resourcesinuseERROR. Test_dispose audio.shutdown then0.2swait whilequittingfalse letrestoredphysics/areaeventrestartaudio. Fix testteardownflag before shutdown, keepstrictallerrorcheck, addboundedfailure diagnostics. No productionruntimechange expected; allnative/export evidence remains valid if runtimefile fingerprints equal afterfix.
Task3 fix round1/5: bothfindings addressed, zeroopen; commit16ab825..8512937, scopedrereviewapproved(task-3-fix-1-review.md). Linuxofficial2/2 plusdeterministicdirectchild, Windows2/2+directchildpassed; strictallerrorpredicateunchanged. CI43247479202 nowrunning for8512937. Finalreleaseinputs refreshed afterrestoringtrackedgeneratedimports and confirming gitnormalizedruntimeclean; source8512937 differs16abonlyexcludedtestfixture.

Final controller gate: CI43247479202 SUCCESS at8512937;182Python and104/104runtime checks. Clean committed-input rebuild exe/PCK byte-identical to verified artifacts. Metadata author+committer allstanley890314@gmail.com/no assistanttrailers. Native3sizes/PCK/Windowsstart+12assets, design5/5 andreviewsapproved. Ticket/evidence closure prepared for fetch/mainpublication. Rulings with costs retained in design/runtime/boat-prologue.md and this archive.
