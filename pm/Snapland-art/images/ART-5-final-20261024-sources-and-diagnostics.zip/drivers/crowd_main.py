from pathlib import Path
import os,json,time,subprocess,shutil
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();stage=r/'work/tutorial-current-20261020/validation-project';out=r/'work/remaining-20261024/crowd-main';out.mkdir(exist_ok=False)
before={p:p.stat().st_mtime_ns for p in stage.rglob('*.png') if '.godot' not in p.parts and 'assets' not in p.parts}
rec=subprocess.Popen(['ffmpeg','-n','-v','error','-f','x11grab','-video_size','1280x720','-framerate','15','-i',os.environ['DISPLAY'],'-t','150','-c:v','libx264','-threads','1','-preset','ultrafast','-crf','22','-pix_fmt','yuv420p',str(out/'native.mp4')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
t=time.monotonic()
try:
 p=run_validated_godot(stage,[str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'),'--path',str(stage),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--resolution','1280x720','--fixed-fps','60','--log-file',str(out/'engine.log'),'res://game/tests/native_crowd_acceptance_review.tscn','--','--video-only','--capture-dir=.review/art5-crowd-main-20261024'],dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'progress.json')),120)
finally:
 _,err=rec.communicate('q\n',timeout=15);(out/'record.log').write_text(err)
s=p.stdout+p.stderr;(out/'result.log').write_text(s);d=dict(exit=p.returncode,errors=s.count('ERROR:'),seconds=round(time.monotonic()-t,2),passes=[l for l in s.splitlines() if l.startswith('PASS:')]);(out/'result.json').write_text(json.dumps(d,indent=2))
for root in [stage]:
 for f in root.rglob('*.png'):
  if '.godot' in f.parts or 'assets' in f.parts or before.get(f)==f.stat().st_mtime_ns:continue
  q=out/'captures'/f.relative_to(stage);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,q)
print(d,s[-700:],flush=True);assert d['exit']==0 and d['errors']==0 and len(d['passes'])>=1
