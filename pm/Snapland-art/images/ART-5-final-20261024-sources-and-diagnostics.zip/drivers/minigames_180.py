from pathlib import Path
import os,json,time,subprocess
from tools.godot_entrypoints import run_validated_godot
from tools.run_game_tests import result_error
r=Path.cwd();s=r/'work/tutorial-current-20261020/validation-project';o=r/'work/remaining-20261024/minigames-local2x';o.mkdir(exist_ok=False);t=time.monotonic()
a=[str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'),'--headless','--path',str(s),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--log-file',str(o/'engine.log'),'--script','res://game/tests/test_minigames.gd']
try:
 p=run_validated_godot(s,a,dict(os.environ,SNAPLAND_SAVE_PATH=str(o/'progress.json')),180);text=p.stdout+p.stderr;record=dict(exit=p.returncode,error=result_error('welcome minigame tests',p))
except subprocess.TimeoutExpired as e:
 text=(e.stdout or '')+(e.stderr or '');record=dict(exit='timeout',error='180s local guard exceeded')
(o/'result.log').write_text(text);record.update(seconds=round(time.monotonic()-t,2),base_timeout=90,local_timeout_scale=2,effective_timeout=180,command=a)
(o/'result.json').write_text(json.dumps(record,indent=2));print({k:v for k,v in record.items() if k!='command'},flush=True);assert record['error'] is None
