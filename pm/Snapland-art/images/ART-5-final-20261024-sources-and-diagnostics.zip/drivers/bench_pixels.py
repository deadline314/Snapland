from pathlib import Path
import json,sys
import numpy as np
from PIL import Image,ImageFilter
root=Path(sys.argv[1]);records=[]
for phase in ['noon','night']:
 ref=Image.open(root/('bench-1280x720-%s.png'%phase)).convert('RGB')
 for width,height in [(800,450),(1280,720),(1920,1080)]:
  image=np.asarray(Image.open(root/('bench-%dx%d-%s.png'%(width,height,phase))).convert('RGB'),dtype=int);factor=width/1280
  for guest in range(6):
   x=247+157*guest-36;y=308+(10 if guest%2 else 0)
   canonical=ref.crop((x,y,x+72,y+92));rgb=np.asarray(canonical,dtype=int)
   alpha=Image.open(root/('guest-%d.png'%guest)).getchannel('A').resize((72,92),Image.Resampling.NEAREST)
   span=np.asarray(canonical.filter(ImageFilter.MaxFilter(3)),dtype=int)-np.asarray(canonical.filter(ImageFilter.MinFilter(3)),dtype=int)
   mask=(np.asarray(alpha.filter(ImageFilter.MinFilter(3)))>=250)&(span.max(axis=2)<=12)
   ys,xs=np.nonzero(mask);assert len(xs)>=16
   tx=np.floor((x+xs+.5)*factor).astype(int);ty=np.floor((y+ys+.5)*factor).astype(int)
   mae=float(np.abs(image[ty,tx]-rgb[ys,xs]).mean())
   records.append(dict(phase=phase,size=[width,height],guest=guest,reference_samples=len(xs),unique_target_pixels=len(set(zip(tx.tolist(),ty.tolist()))),mean_absolute_rgb_error=round(mae,4),within_20=mae<=20))
report=dict(method='Independent 1280 native canonical flat-interior samples projected into each size at fixed contractual seat-body locations. Source alpha>=250/255 (interiors predominantly252/253), 3x3 RGB range<=12 excludes aliasing edges, at least16 reference samples per figure. Unchanged RGB MAE limit20. Both original/fixed builds use the same method. Not an animation jitter or pixel-identical-resize claim.',pass_count=sum(r['within_20'] for r in records),count=len(records),observations=records)
(root/'pixels.json').write_text(json.dumps(report,indent=2));print(root.name,report['pass_count'],report['count']);print([(r['size'],r['phase'],r['guest'],r['mean_absolute_rgb_error']) for r in records if not r['within_20']])
