from pathlib import Path
import json,sys
import numpy as np
from PIL import Image, ImageFilter
root=Path(sys.argv[1]);records=[]
for phase in ['noon','night']:
 ref=Image.open(root/('bench-1280x720-%s.png'%phase)).convert('RGB')
 for width,height in [(800,450),(1280,720),(1920,1080)]:
  image=Image.open(root/('bench-%dx%d-%s.png'%(width,height,phase))).convert('RGB');factor=width/1280
  for guest in range(6):
   x=247+157*guest-36;y=308+(10 if guest%2 else 0)
   canonical=ref.crop((x,y,x+72,y+92))
   box=(round(x*factor),round(y*factor),round((x+72)*factor),round((y+92)*factor))
   actual=np.asarray(image.crop(box),dtype=np.float32)
   expected=np.asarray(canonical.resize((box[2]-box[0],box[3]-box[1]),Image.Resampling.NEAREST),dtype=np.float32)
   alpha=Image.open(root/('guest-%d.png'%guest)).getchannel('A').resize((box[2]-box[0],box[3]-box[1]),Image.Resampling.NEAREST)
   mask=np.asarray(alpha.filter(ImageFilter.MinFilter(3)))>=250
   assert mask.sum()>20
   mae=float(np.abs(actual-expected)[mask].mean())
   records.append(dict(phase=phase,size=[width,height],guest=guest,opaque_samples=int(mask.sum()),mean_absolute_rgb_error=round(mae,4),within_20=mae<=20))
report=dict(method='Independent 1280 canonical native figure crops compared at fixed contractual design positions using >=250/255 authored texture masks (source interiors predominantly252/253; identical cutoff before/after); RGB MAE limit 20 set before measuring. Actual pointer checked separately.',pass_count=sum(r['within_20'] for r in records),count=len(records),observations=records)
(root/'pixels.json').write_text(json.dumps(report,indent=2));print(root.name,report['pass_count'],report['count']);print([(r['size'],r['phase'],r['guest'],r['mean_absolute_rgb_error']) for r in records if not r['within_20']])
