from pathlib import Path
import os,json,time,sys,shutil
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();stage=r/'work/tutorial-current-20261020/validation-project'
label=sys.argv[1];assert label in ['before','after']
out=r/'work/remaining-20261024'/('crowd-light-'+label+'-v3');out.mkdir(exist_ok=False)
source=r/'work/remaining-20261024/crowd-light-native';target=stage/'work/remaining-20261024/crowd-light-native'
target.mkdir(parents=True,exist_ok=True)
for p in source.iterdir():shutil.copy2(p,target/p.name)
t=time.monotonic()
p=run_validated_godot(stage,[str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'),'--path',str(stage),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--resolution','1280x720','--log-file',str(out/'engine.log'),'res://work/remaining-20261024/crowd-light-native/entry.tscn'],dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'progress.json')),90)
s=p.stdout+p.stderr;(out/'result.log').write_text(s)
d=dict(exit=p.returncode,errors=s.count('ERROR:'),seconds=round(time.monotonic()-t,2),complete='PASS: four native crowd lighting captures' in s)
(out/'result.json').write_text(json.dumps(d,indent=2));print(d,s[-1500:],flush=True)
assert d['exit']==0 and d['errors']==0 and d['complete']
