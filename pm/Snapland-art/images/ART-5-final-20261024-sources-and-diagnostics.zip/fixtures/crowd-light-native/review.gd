extends Node
const Model = preload("res://game/minigames/crowd_traffic_model.gd")
const View = preload("res://game/minigames/crowd_semaphore_view.gd")
func _ready() -> void:
	call_deferred("_run")
func _run() -> void:
	var path := OS.get_environment("SNAPLAND_SAVE_PATH")
	if not path.is_absolute_path() or DisplayServer.get_name() == "headless":
		push_error("Crowd lighting needs native display and isolated absolute profile")
		get_tree().quit(1)
		return
	var model = Model.new()
	model.request_lane(0)
	for i in 70: model.step(0.05)
	var snapshot: Dictionary = model.snapshot().duplicate(true)
	var view = View.new()
	add_child(view)
	var out := path.get_base_dir()
	DirAccess.make_dir_recursive_absolute(out)
	var file := FileAccess.open(out.path_join("posed-state.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify(snapshot,"  "))
	for phase in ["dawn","noon","dusk","night"]:
		view.present_traffic(snapshot,float(snapshot.elapsed),true,phase)
		for i in 4: await get_tree().process_frame
		await RenderingServer.frame_post_draw
		if get_viewport().get_texture().get_image().save_png(out.path_join("crowd-%s.png" % phase)) != OK:
			push_error("Crowd phase screenshot failed")
			get_tree().quit(1)
			return
		var environment: Environment = view._environment
		print("LIGHT: ",phase," ambient=",environment.ambient_light_energy," key=",view._key_light.light_energy)
	print("PASS: four native crowd lighting captures, identical posed snapshot; not gameplay completion or listening")
	get_tree().quit(0)
