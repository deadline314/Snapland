extends Node
const Model = preload("res://game/minigames/bench_swap_model.gd")
const View = preload("res://game/minigames/bench_swap_view.gd")
const Renderer = preload("res://game/world/avatar_renderer.gd")
var model: RefCounted
var view: Control
var clicked: Array[int] = []

func _ready() -> void:
	call_deferred("_run")

func _frames(count: int) -> void:
	for i in count: await get_tree().process_frame

func _run() -> void:
	var save_path := OS.get_environment("SNAPLAND_SAVE_PATH")
	if not save_path.is_absolute_path() or DisplayServer.get_name() == "headless":
		push_error("Bench resize requires native display and isolated absolute profile")
		get_tree().quit(1)
		return
	get_window().content_scale_mode = Window.CONTENT_SCALE_MODE_DISABLED
	get_window().content_scale_size = Vector2i.ZERO
	model = Model.new()
	view = View.new()
	add_child(view)
	view.configure_avatar(Renderer.DEFAULT_APPEARANCE, {"outfit":"outfit-tide", "hat":"hat-none"})
	view.seat_requested.connect(func(index: int): clicked.append(index); model.select_seat(index); view.update_frame(model.snapshot(), model.time_phase, false))
	for guest in 6:
		var texture: Texture2D = view.avatar_texture_for_guest(guest)
		if texture == null:
			push_error("Missing complete guest texture")
			get_tree().quit(1)
			return
	var records: Array[Dictionary] = []
	var directory := save_path.get_base_dir()
	DirAccess.make_dir_recursive_absolute(directory)
	for guest in 6:
		view.avatar_texture_for_guest(guest).get_image().save_png(directory.path_join("guest-%d.png" % guest))
	for dimensions in [Vector2i(800,450), Vector2i(1280,720), Vector2i(1920,1080)]:
		get_window().size = dimensions
		await _frames(8)
		view.custom_minimum_size = Vector2.ZERO
		view.position = Vector2.ZERO
		view.size = Vector2(dimensions)
		for phase in ["noon", "night"]:
			model.reset(false, phase)
			view.update_frame(model.snapshot(), phase, true)
			await _frames(3)
			await RenderingServer.frame_post_draw
			var image := get_viewport().get_texture().get_image()
			var name := "bench-%dx%d-%s.png" % [dimensions.x, dimensions.y, phase]
			if image.get_size() != dimensions or image.save_png(directory.path_join(name)) != OK:
				push_error("Bench resize capture size or write failed")
				get_tree().quit(1)
				return
			var factor := minf(float(dimensions.x)/1280.0, float(dimensions.y)/720.0)
			for seat in [0,5]:
				model.reset(false, phase)
				view.update_frame(model.snapshot(), phase, true)
				clicked.clear()
				var design_point := Vector2(247.0 + seat * 157.0, 379.0 + (10.0 if seat%2 else 0.0))
				var pointer := (Vector2(dimensions)-Vector2(1280,720)*factor)*0.5+design_point*factor
				var motion := InputEventMouseMotion.new()
				motion.window_id=get_window().get_window_id()
				motion.position=pointer;motion.global_position=pointer
				Input.parse_input_event(motion)
				Input.flush_buffered_events()
				await _frames(2)
				for pressed in [true,false]:
					var event := InputEventMouseButton.new()
					event.position=pointer;event.global_position=pointer
					event.window_id=get_window().get_window_id()
					event.button_index=MOUSE_BUTTON_LEFT;event.pressed=pressed
					event.button_mask=MOUSE_BUTTON_MASK_LEFT if pressed else 0
					Input.parse_input_event(event)
					Input.flush_buffered_events()
					await _frames(2)
				if clicked != [seat] or int(model.snapshot().selected_seat) != seat:
					push_error("Bench actual pointer did not select expected outer seat: " + str([dimensions,seat,clicked]))
					get_tree().quit(1)
					return
			records.append({"size":str(dimensions),"phase":phase,"capture":name,"actual_pointer_seats":[0,5],"capture_reduced_motion":true})
	var file := FileAccess.open(directory.path_join("report.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify(records,"  "))
	print("PASS: bench native three sizes, noon/night, actual pointer outer seats; visual captures require separate inspection")
	get_tree().quit(0)
