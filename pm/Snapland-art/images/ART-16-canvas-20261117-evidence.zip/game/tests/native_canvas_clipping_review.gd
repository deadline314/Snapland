extends Node

const Avatar = preload("res://game/world/avatar_renderer.gd")
const Before = preload("res://game/tests/pose_canvas_before.gd")
const After = preload("res://game/world/character_animation_library.gd")

func _ready() -> void:
	call_deferred("_run")

func _run() -> void:
	var output := OS.get_environment("SNAPLAND_CANVAS_REVIEW")
	if not output.is_absolute_path() or not OS.get_environment("SNAPLAND_SAVE_PATH").is_absolute_path() or DisplayServer.get_name() == "headless":
		push_error("Native canvas review requires GPU and isolated absolute paths")
		get_tree().quit(1)
		return
	get_window().size = Vector2i(1280,720)
	var backdrop := ColorRect.new()
	backdrop.color = Color("18283b")
	backdrop.size = Vector2(1280,720)
	add_child(backdrop)
	var original := Avatar.new()
	var broken := Avatar.new()
	broken.animation_library = Before.new()
	broken.animation_library.manifest.actors.traveller.wave.front.frames[0].anchors.feet[0] = 0
	var recovered := Avatar.new()
	recovered.animation_library = After.new()
	recovered.animation_library.manifest.actors.traveller.wave.front.frames[0].anchors.feet[0] = 0
	var reference := Avatar.new()
	reference.animation_library.manifest.actors.traveller.erase("wave")
	var textures: Array[Texture2D] = []
	for renderer in [original, broken, recovered]:
		textures.append(renderer.texture(Avatar.DEFAULT_APPEARANCE, {"outfit":"outfit-tide"}, "front", 0, "wave"))
	if textures[2].get_image().get_data() != reference.texture(Avatar.DEFAULT_APPEARANCE,{"outfit":"outfit-tide"},"front",0,"wave").get_image().get_data():
		push_error("Clipped source did not recover the complete legacy character")
		get_tree().quit(1)
		return
	var labels := ["Valid authored pose", "Before: valid anchor clips body", "After: complete fallback"]
	for index in range(3):
		var title := Label.new()
		title.text = labels[index]
		title.position = Vector2(40+index*420,70)
		title.add_theme_font_size_override("font_size",22)
		add_child(title)
		var portrait := TextureRect.new()
		portrait.texture = textures[index]
		portrait.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		portrait.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		portrait.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		portrait.position = Vector2(50+index*420,160)
		portrait.size = Vector2(340,440)
		add_child(portrait)
	var caption := Label.new()
	caption.text = "Same source and malformed feet anchor. Static native rendering review; no gameplay or audio acceptance."
	caption.position = Vector2(40,650)
	caption.add_theme_font_size_override("font_size",18)
	add_child(caption)
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	if get_viewport().get_texture().get_image().save_png(output) != OK:
		push_error("Could not save native canvas comparison")
		get_tree().quit(1)
		return
	print("PASS: native canvas clipping comparison and complete legacy fallback")
	get_tree().quit(0)
