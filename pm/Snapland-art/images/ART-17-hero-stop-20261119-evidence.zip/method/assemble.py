from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json
from scipy.ndimage import label
base=Path("E:/Snapland-QA/art17-hero-stop-20261119")
capture=base/"source-poses-1119-083019-0cfb6f/captures"
def load(path):
    return np.array(Image.open(path).convert("RGBA"))

def difference(a,b):
    sa,sb=a[:,:,3]>=128,b[:,:,3]>=128
    changed=np.logical_xor(sa,sb)|((sa&sb)&(np.abs(a[:,:,:3].astype(np.int16)-b[:,:,:3].astype(np.int16)).max(axis=2)>35))
    cover=sa|sb
    return np.array([changed[lo:hi].sum()/cover[lo:hi].sum() for lo,hi in ((70,346),(70,200),(200,276),(276,346))])

def assembly(neutral,draft,original_y,target_y,offset):
    data=neutral.copy()
    img=Image.fromarray(draft[original_y:346,:,:]).resize((280,346-target_y),Image.Resampling.NEAREST)
    target=Image.new("RGBA",(280,346-target_y))
    target.paste(img,(offset,0))
    data[target_y:346,:,:]=np.asarray(target)
    return data

sheet=Image.new("RGB",(1120,720),(219,218,202))
drawer=ImageDraw.Draw(sheet)
result={}
for row,side in enumerate(("left","right")):
    idle=load(capture/f"{side}-idle.png")
    walks=[load(capture/f"{side}-walk-{n:02}.png") for n in range(8)]
    base_direct=np.array([difference(walk,idle) for walk in walks])
    max_old=np.max(base_direct,axis=0)
    candidates=[]
    for index in range(2):
        draft=load(base/f"{side}-draft-{index}.png")
        for original_y in range(258 if side=="left" else 271,279 if side=="left" else 291,2):
            for target_y in range(260 if side=="left" else 268,280 if side=="left" else 289,2):
                for shift in range(-8,9,2):
                    pose=assembly(idle,draft,original_y,target_y,shift)
                    left=pose[target_y-1,:,3]>=128
                    right=pose[target_y,:,3]>=128
                    seam=int(np.logical_xor(left,right).sum())
                    if seam>9 or label(pose[:,:,3]>=128)[1]>2:continue
                    belt=np.abs(pose[target_y-1,:,:3].astype(np.int16)-pose[target_y,:,:3].astype(np.int16)).max(axis=1)
                    seam_noise=int(((belt>95)&left&right).sum())
                    if seam_noise>=16:continue
                    into_idle=difference(pose,idle)
                    if into_idle[3]<.18:continue
                    from_walk=np.array([difference(walk,pose) for walk in walks])
                    allmax=np.maximum(from_walk,into_idle)
                    improvements=allmax<base_direct
                    good=np.flatnonzero(improvements[:,[0,2,3]].all(axis=1)).tolist()
                    count=len(good)
                    rank=sum(np.max(allmax,axis=0)) + (8-count)*.06 + seam*.025 + seam_noise*.015
                    candidates.append((rank,index,original_y,target_y,shift,good,np.max(allmax,axis=0).tolist(),into_idle.tolist(),pose))
    candidates.sort(key=lambda i:i[0])
    selected=[]
    for entry in candidates:
        if entry[1] not in {r[1] for r in selected}: selected.append(entry)
        if len(selected)==2:break
    result[side]={"maximum_direct":max_old.tolist(),"candidates":len(candidates),"best":[entry[:-1] for entry in selected]}
    for col,cel in enumerate([idle,*[entry[-1] for entry in selected],walks[0]]):
        image=Image.fromarray(cel)
        sheet.paste(image,(col*280,row*360),image)
        if col in [1,2]:image.save(base/f"{side}-baked-study-{col-1}.png")
        drawer.text((col*280+10,row*360+14),f"{side}  "+["idle","best leg artwork from candidate 1","best from candidate 2","walk 0"][col],fill=(20,32,35))
sheet.save(base/"assembled-study.png")
(base/"assembled-study.json").write_text(json.dumps(result,indent=2),encoding="utf8")
print(json.dumps(result))
