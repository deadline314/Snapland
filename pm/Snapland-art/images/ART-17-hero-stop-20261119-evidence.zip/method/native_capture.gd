extends "res://game/tests/native_island_animation_acceptance.gd"

func _hero_actions() -> void:
	var original: Dictionary = _world.avatar_appearance.duplicate(true)
	for look: String in ["default","rainvest","bob-straw","live-hair"]:
		var appearance := original.duplicate()
		if look in ["bob-straw","live-hair"]: appearance.hair = "bob"
		var gear := {"outfit":"outfit-rainvest" if look == "rainvest" else "outfit-tide",
			"hat":"hat-straw" if look == "bob-straw" else "hat-none"}
		_world.set_avatar_look(appearance,gear)
		_world.set_avatar_hair_motion_enabled(look == "live-hair")
		for side: String in ["left","right"]:
			var outcome := await _observe_a_stop(side,look,look=="live-hair")
			await _record_action(look+"-"+side+"-stop","settle",side,"authored",_actor_anchor(), bool(outcome.get("complete",false)),outcome)
			if not bool(outcome.get("complete",false)): return

func _observe_a_stop(side: String, look: String, with_hair: bool) -> Dictionary:
	var key := KEY_A if side=="left" else KEY_D
	for hold: float in [0.35,0.45,0.57]:
		var target := Vector3(-2.6,0,-5.5)
		target.y = _world.ground_surface_y(target)
		_world.player.global_position = target
		await _physics_frames(4)
		_press(key,true)
		var started := _simulated_seconds
		while _simulated_seconds-started<hold and _within_budget():
			await RenderingServer.frame_post_draw
		_press(key,false)
		started = _simulated_seconds
		var previous_index := -1
		while _simulated_seconds-started<0.36 and _within_budget():
			await RenderingServer.frame_post_draw
			if _world.last_avatar_action == "walk":
				previous_index = _world.last_avatar_frame
				continue
			if _world.last_avatar_action != "settle": break
			var position: Vector3 = _world.player.global_position
			var phase: float = _world.walk_distance_phase
			var elapsed := _simulated_seconds
			var expected: Texture2D = _world.avatar_renderer.texture(_world.avatar_appearance, _world.avatar_equipped, side, 0, "settle")
			var rig_active: bool = _world.avatar_hair_rig != null and _world.avatar_hair_rig.active and _world.avatar_hair_rig.pose_key.begins_with(side+"|settle|0|")
			var source_matches: bool = rig_active if with_hair else _world.avatar.texture == expected
			_store_capture(look+"-"+side+"-landing",get_viewport().get_texture().get_image())
			var drift := 0.0
			while _world.last_avatar_action=="settle" and _simulated_seconds-elapsed<0.25 and _within_budget():
				await RenderingServer.frame_post_draw
				drift = maxf(drift,position.distance_to(_world.player.global_position))
			var expected_approaches: Array = _world.AVATAR_STOP_FROM_WALK_CELS.get(side,[])
			var complete: bool = source_matches and _world.facing==side and _world.last_avatar_action=="idle" and _world.last_avatar_frame==0
			complete = complete and previous_index in expected_approaches and drift<=0.00001 and phase==_world.walk_distance_phase
			if look=="default": await _capture(look+"-"+side+"-neutral")
			return {"complete":complete,"previous_frame":previous_index,"source_matches":source_matches,
				"live_hair":rig_active,"root_drift":drift,"heading_after":_world.facing,
				"observed_hold_seconds":_simulated_seconds-elapsed}
	return {"complete":false,"reason":"no reviewed pose observed after physical deceleration"}
