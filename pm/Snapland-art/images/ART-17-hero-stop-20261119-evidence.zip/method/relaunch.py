"""Launch the already exported exact snapshot after independent test fixtures changed."""
from pathlib import Path
import importlib.util
import shutil

here=Path(__file__).resolve().parent
master=Path("C:/Users/stanl/Github/Snapland")
helper=master/".review/cotton-wind-20261118/final-fix/native_run.py"
spec=importlib.util.spec_from_file_location("isolated_native",helper)
runner=importlib.util.module_from_spec(spec)
source=helper.read_text("utf8").replace('Path(keys[key]).drive.upper() == "D:"','Path(keys[key]).drive == base.drive')
exec(compile(source,str(helper),"exec"),runner.__dict__)
runner.QA=here/"native"
export=runner.QA/"art16-export-1119-091348-5cf97b"
record=runner.read(export/"source-graph.json")
build=runner.read(export/"build.json")
receipt=runner.read(export/"receipt.json")
assert receipt["passed"] and not receipt["errors"] and not receipt["leak_diagnostics"]
runner.FIXTURES=record["fixtures"]
runtime=build["runtime_sha256"]
assert runtime==runner.read(export/"runtime-graph.json")
binary=export/"release/AvatarProfileStopQA.exe"
assert runner.sha(binary)==build["binary"]["sha256"] and not list(binary.parent.glob("*.pck"))
base=runner.make_base("art16-embedded")
stage=base/"project"
stage.mkdir()
manifest=record["source_raw_sha256"]
assert set(manifest)==set(runtime)
for name,digest in runtime.items():
    origin=export/"project"/name
    target=stage/name
    resolved=target.resolve()
    assert resolved.is_relative_to(stage) and runner.sha(origin)==digest
    if not name.startswith("game/tests/") and name not in {"project.godot","export_presets.cfg"}:
        assert runner.sha(master/name)==digest
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(origin,target)
    assert runner.sha(target)==digest
runner.dump(base/"source-graph.json",{"source_raw_sha256":manifest,"fixtures":runner.FIXTURES,
    "pinned_export":runner.describe(export/"build.json"),"runtime_sha256":runtime})
validate=runner.run_validated_godot
def aligned_logging(staged,command,*args,**kwargs):
    if "--" in command and command[-2]=="--log-file":
        offset=command.index("--")
        command[offset:offset]=command[-2:]
        del command[-2:]
    return validate(staged,command,*args,**kwargs)
runner.run_validated_godot=aligned_logging
out=base/"captures"
command=[binary,"--rendering-method","gl_compatibility","--audio-driver","Dummy","--fixed-fps","30",
    "--write-movie",base/"capture.avi","--","--actor=traveller","--actions-only","--animation-output="+out.as_posix()]
runner.launch(base,stage,manifest,"embedded",command,runner.environment(base),binary.parent)
assert runner.read(base/"runtime-graph.json")==runtime
report=runner.read(out/"traveller-report.json")
cases=[row for row in report["actions"] if row["label"].endswith("-stop")]
assert report["technical_status"]=="PASS" and not report["failures"]
assert len(cases)==8 and all(row["predicate"] and row["detail"]["root_drift"]==0 for row in cases)
assert sum(bool(row["detail"]["live_hair"]) for row in cases)==2
runner.dump(export/"embedded-acceptance.json",{"build":runner.describe(export/"build.json"),"launch":runner.describe(base/"receipt.json")})
print(base.as_posix())
