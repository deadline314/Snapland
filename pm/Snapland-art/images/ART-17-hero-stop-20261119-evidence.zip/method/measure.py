from pathlib import Path
from PIL import Image
import numpy as np,json
base=Path("E:/Snapland-QA/art17-hero-stop-20261119")
capture=base/"source-poses-1119-083019-0cfb6f/captures"
generated=Path("C:/Users/stanl/.codex/generated_images/01a1e5dd-6423-7963-9dc5-b040851d2b6b")
sources={"left":generated/"exec-4a4d26e9-3133-4231-9c7f-74f54f4141c9.png", "right":generated/"exec-ddc1d0ac-fdde-4202-8fd5-69bc3661ef66.png"}
areas=((70,200),(200,276),(276,346))
def read(path):return np.asarray(Image.open(path).convert("RGBA"))
def distances(a,b):
    union=(a[:,:,3]>=128)|(b[:,:,3]>=128)
    cover=(a[:,:,3]>=128)&(b[:,:,3]>=128)
    difference=((a[:,:,3]>=128)^(b[:,:,3]>=128))|(cover&(np.abs(a[:,:,:3].astype(np.int16)-b[:,:,:3].astype(np.int16)).max(axis=2)>35))
    return np.array([difference[lo:hi].sum()/union[lo:hi].sum() for lo,hi in areas])
report={}
for side,file in sources.items():
    image=Image.open(file).convert("RGBA")
    idle=read(capture/f"{side}-idle.png")
    walks=[read(capture/f"{side}-walk-{n:02}.png") for n in range(8)]
    old=[distances(walk,idle) for walk in walks]
    direct=np.max(old,axis=0)
    accepted=[]
    best_attempt=[]
    for n in range(2):
        width=image.width//2
        x=n*width
        cell=image.crop((x,0,x+width,image.height))
        bounds=cell.getchannel("A").point(lambda a:255 if a>=128 else 0).getbbox()
        part=cell.crop(bounds)
        for height in range(266,281,2):
            w=round(part.width*height/part.height)
            candidate=np.asarray(part.resize((w,height),Image.Resampling.NEAREST))
            for center in range(130,153,2):
                pose=np.zeros_like(idle)
                left=center-w//2
                pose[346-height:346,left:left+w]=candidate
                near=distances(pose,idle)
                if near[0] > direct[0]*1.2: 
                    best_attempt.append((float(near[0]),n,height,center))
                    continue
                maxdiff=np.maximum(np.max([distances(walk,pose) for walk in walks],axis=0),near)
                accepted.append((float(sum(maxdiff)),n,height,center,maxdiff.tolist(),near.tolist(),pose))
    accepted.sort(key=lambda a:a[0])
    best_attempt.sort()
    report[side]={"direct":direct.tolist(),"closest_head_attempts":best_attempt[:4],"best":[row[:6] for row in accepted[:4]]}
    for i,entry in enumerate(accepted[:3]):Image.fromarray(entry[6]).save(base/f"{side}-full-resample-{i}.png")
(base/"raw-cel-study.json").write_text(json.dumps(report,indent=2),encoding="utf8")
print(json.dumps(report))
