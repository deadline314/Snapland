extends Node2D
var originals: Array[Texture2D] = []
var candidates: Array[Texture2D] = []
var poses: Array[Dictionary] = []
var elapsed := 0.0
var total := 0.0
var current := 0
var captured: Dictionary = {}
var pending := false
var stopping := false
var negative := false
var folder := ""
var records: Array = []
var font: Font

func _ready() -> void:
	var profile := OS.get_environment("SNAPLAND_SAVE_PATH")
	if not profile.is_absolute_path() or DisplayServer.get_name()=="headless":get_tree().quit(2);return
	folder=profile.get_base_dir();DirAccess.make_dir_recursive_absolute(folder.path_join("captures"))
	negative=OS.get_cmdline_user_args().has("--one-pixel-negative")
	Engine.time_scale=0.25 if OS.get_cmdline_user_args().has("--quarter") else 1.0
	texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST;font=ThemeDB.fallback_font
	var base:=ProjectSettings.globalize_path("res://work/cloth-walk-20261022/vest-bake-v7/compiled")
	var guide: Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://work/cloth-walk-20261022/vest-guide-v1.json"))
	var manifest: Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://assets/characters/idle-stability-v1/manifest.json"))
	for row in guide.frames:
		var direction:=str(row.direction);var frame:=int(row.frame);var action:=str(row.action)
		var stem:="%s-%s-%02d"%[action,direction,frame]
		var a:=Image.load_from_file(base.path_join(stem+"-original.png"));var b:=Image.load_from_file(base.path_join(stem+".png"))
		if a==null or b==null or a.get_size()!=Vector2i(280,360) or b.get_size()!=Vector2i(280,360):get_tree().quit(2);return
		originals.append(ImageTexture.create_from_image(a));candidates.append(ImageTexture.create_from_image(b))
		total+=float(manifest.sequences["hero-idle/"+direction].frame_durations[frame]) if action=="idle" else 0.125
		poses.append({"action":action,"direction":direction,"frame":frame,"end":total})
	queue_redraw()

func _process(delta:float) -> void:
	if stopping or originals.size()!=100:return
	elapsed+=delta
	while current<poses.size()-1 and elapsed>=float(poses[current].end):current+=1
	queue_redraw()
	if not Engine.get_write_movie_path().is_empty():RenderingServer.force_draw(false,0.0)
	if not pending and not captured.has(current):_shot(current)
	if elapsed>=total+0.15 and not pending:
		stopping=true
		FileAccess.open(folder.path_join("render-report.json"),FileAccess.WRITE).store_string(JSON.stringify(records,"  "))
		if captured.size()!=100:push_error("Idle garment preview did not capture all source poses");get_tree().quit(1);return
		print("PASS: native longvest authoring 100 actual cels / eight directions; original head and feet exact; no wardrobe adoption")
		get_tree().quit()

func _draw() -> void:
	draw_rect(Rect2(0,0,1280,720),Color("#123442"))
	if originals.size()!=100:return
	draw_string(font,Vector2(180,40),"ART-18 / Longvest / original hoodie authoring",HORIZONTAL_ALIGNMENT_LEFT,-1,26,Color("#eee8cc"))
	draw_string(font,Vector2(220,82),"Original: %s / %02d"%[poses[current].direction,poses[current].frame],HORIZONTAL_ALIGNMENT_LEFT,-1,20,Color("#bce4d5"))
	draw_string(font,Vector2(700,82),"Clothing preview / original wearer",HORIZONTAL_ALIGNMENT_LEFT,-1,20,Color("#bce4d5"))
	draw_texture_rect(originals[current],Rect2(220,100,392,504),false)
	draw_texture_rect(candidates[current],Rect2(701 if negative else 700,100,392,504),false)
	for x in [220,700]:draw_line(Vector2(x,585),Vector2(x+392,585),Color("#aa8056"),1.0)
	draw_string(font,Vector2(220,642),"Original idle durations; walk inspection at 8 FPS; immutable head, hands, props and feet",HORIZONTAL_ALIGNMENT_LEFT,-1,19,Color("#eee8cc"))
	draw_string(font,Vector2(220,678),"Inspection only / clothing incomplete / not in the wardrobe",HORIZONTAL_ALIGNMENT_LEFT,-1,18,Color("#e6ba74"))

func _shot(index:int) -> void:
	pending=true
	await RenderingServer.frame_post_draw
	var image:=get_viewport().get_texture().get_image()
	if image==null or image.get_size()!=Vector2i(1280,720):push_error("Idle clothing window is not 1280x720");get_tree().quit(1);return
	var head_equal:=image.get_region(Rect2i(220,100,392,287)).get_data()==image.get_region(Rect2i(700,100,392,287)).get_data()
	var feet_equal:=image.get_region(Rect2i(220,534,392,70)).get_data()==image.get_region(Rect2i(700,534,392,70)).get_data()
	var path:=folder.path_join("captures/%s-%s-%02d.png"%[poses[index].action,poses[index].direction,poses[index].frame])
	if FileAccess.file_exists(path) or image.save_png(path)!=OK:push_error("Idle clothing capture exists or cannot be saved");get_tree().quit(1);return
	records.append({"action":poses[index].action,"direction":poses[index].direction,"frame":poses[index].frame,"head_render_exact":head_equal,"feet_render_exact":feet_equal,"time_scale":Engine.time_scale,"source_seconds":elapsed,"negative":negative})
	if not head_equal or not feet_equal:
		stopping=true
		FileAccess.open(folder.path_join("render-report.json"),FileAccess.WRITE).store_string(JSON.stringify(records,"  "))
		printerr("REJECTED: actual rendered longvest clothing head/feet moved relative to original")
		get_tree().quit(1);return
	captured[index]=true;pending=false
