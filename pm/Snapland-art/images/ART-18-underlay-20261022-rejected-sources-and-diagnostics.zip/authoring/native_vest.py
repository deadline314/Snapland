from pathlib import Path
import os,json,time,sys,hashlib,shutil,subprocess
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();b=r/'work/cloth-walk-20261022';stage=r/'work/tutorial-current-20261020/validation-project';case=sys.argv[1];out=b/case;out.mkdir();engine=r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'
cmd=[str(engine),'--path',str(stage),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--resolution','1280x720','--log-file',str(out/'engine.log'),'res://work/cloth-walk-20261022/native_vest_review.tscn','--fixed-fps','20']
if not case.startswith('negative'):cmd+=['--write-movie',str(out/'play.avi')]
if not case.startswith('normal'):cmd+=['--','--quarter' if case.startswith('quarter') else '--one-pixel-negative']
inputs=stage/'work/cloth-walk-20261022'
for name in ['native_vest_review.gd','native_vest_review.tscn','vest-guide-v1.json']:shutil.copyfile(inputs/name,out/name)
(out/'launch-source-hashes.json').write_text(json.dumps({str(p.relative_to(stage)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [inputs/'native_vest_review.gd',inputs/'native_vest_review.tscn',inputs/'vest-guide-v1.json',*sorted((inputs/'vest-bake-v7/compiled').glob('*.png'))]},indent=2)+'\n')
t=time.monotonic();p=run_validated_godot(stage,cmd,dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'progress.json')),180);log=p.stdout+p.stderr;data=dict(exit=p.returncode,errors=log.count('ERROR:'),seconds=round(time.monotonic()-t,2));(out/'result.log').write_text(log);(out/'result.json').write_text(json.dumps(data,indent=2)+'\n');print(case,data,log[-400:],flush=True)
if case.startswith('negative'):assert p.returncode==1 and data['errors']==0 and 'REJECTED: actual rendered longvest' in log
else:assert p.returncode==0 and data['errors']==0 and 'PASS: native longvest authoring 100 actual cels' in log
