from pathlib import Path
from PIL import Image,ImageDraw
b=Path('work/cloth-walk-20261022');src=b/'current-originals/sources'
for a in ['wave','photograph','interact','jump','sit','catch']:
 files=sorted(src.glob(a+'-front-*.png'));out=Image.new('RGB',(1120,380*((len(files)+3)//4)),'#dddccc');d=ImageDraw.Draw(out)
 for i,p in enumerate(files):
  im=Image.open(p).convert('RGBA');x=i%4*280;y=i//4*380;out.paste(im,(x,y+20),im);d.text((x+4,y+4),p.stem,fill='black')
 out.save(b/(a+'-originals.png'))
