from pathlib import Path
import shutil,os,json,time
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();b=r/'work/cloth-walk-20261022';stage=r/'work/tutorial-current-20261020/validation-project';g=r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'
rel='game/tests/test_garment_part_ownership.gd';shutil.copyfile(r/rel,stage/rel)
out=b/'part-guard';out.mkdir();t=time.monotonic();p=run_validated_godot(stage,[str(g),'--headless','--path',str(stage),'--audio-driver','Dummy','--script','res://'+rel],dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'progress.json')),90);log=p.stdout+p.stderr;(out/'result.log').write_text(log);record=dict(exit=p.returncode,errors=log.count('ERROR:'),seconds=round(time.monotonic()-t,2),completed='PASS: garment sleeves retain' in log);(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(record,log[-500:]);assert record['exit']==0 and record['errors']==0 and record['completed']
