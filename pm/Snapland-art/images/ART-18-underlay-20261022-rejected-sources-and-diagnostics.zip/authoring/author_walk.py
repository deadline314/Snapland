from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
import json,hashlib,copy,colorsys,shutil
r=Path.cwd();b=r/'work/cloth-walk-20261022';src=b/'current-originals/sources';old=r/'work/outfit-eight-view-20261021'
# Offline draft only. Freeze all marks and original RGBA signatures for review.
ns={};exec((old/'build_idle_guide.py').read_text().split('rows=[]')[0],ns);foreground=ns['foreground']
j=json.loads((r/'tools/island_avatar/garments/mustard-idle-eight-guide.json').read_text());rows=j['frames'];j['frames']=[]
j.update(body_atlas='tools/island_avatar/garments/mustard-body-eight-parts-v1.png',body_atlas_size=[1563,1006],body_atlas_sha256=hashlib.sha256((old/'parts-v1.png').read_bytes()).hexdigest())
# Joints are in the fixed original wearer canvas, not a per-cel crop.
B={
'front_right':[[[121,198],[110,220],[122,224]],[[176,198],[190,216],[184,224]]],
'right':[[[137,198],[134,222],[157,225]],[[162,198],[176,216],[183,225]]],
'back_right':[[[104,203],[95,224],[95,236]],[[171,199],[184,220],[188,232]]],
'back':[[[110,199],[96,216],[89,232]],[[174,199],[187,218],[187,235]]],
'back_left':[[[110,200],[99,224],[93,237]],[[175,200],[184,224],[184,237]]],
'left':[[[113,198],[111,218],[100,226]],[[144,198],[158,222],[134,225]]],
'front_left':[[[104,198],[92,217],[103,222]],[[166,198],[178,223],[159,226]]]
}
wrists={
'back_right':{0:[190,231],1:[189,230],2:[190,231],3:[198,234],4:[191,240],5:[190,236],6:[188,241],7:[191,234]},
'back_left':{0:[94,238],1:[94,230],2:[91,228],3:[95,235],4:[92,240],5:[95,234],6:[99,236],7:[103,224]},
'back':{0:([89,228],[187,229]),1:([95,232],[196,232]),2:([93,211],[194,232]),3:([95,211],[197,235]),4:([89,240],[187,228]),5:([95,232],[195,241]),6:([93,215],[190,235]),7:([95,225],[194,238])}}
for base in rows:
 if base['frame'] or base['direction']=='front':continue
 d=base['direction']
 for f in range(8):
  row=copy.deepcopy(base);im=Image.open(src/f'walk-{d}-{f:02}.png').convert('RGBA');row.update(action='walk',frame=f,source_pixel_sha256=hashlib.sha256(im.tobytes()).hexdigest(),protection_spans=foreground(im,d),target_arms=copy.deepcopy(B[d]))
  row['body_atlas_region']=row['atlas_region'][:];row['body_atlas_region'][2]=min(row['body_atlas_region'][2],1563-row['body_atlas_region'][0])
  if d=='front_right' and f in [4,7]:row['target_arms'][0]=[[120,200],[104,228],[92,239]]
  if d=='front_left' and f in [3,7]:row['target_arms'][1]=[[173,200],[188,226],[196,239]]
  if d=='back_right':
   p=wrists[d][f];row['target_arms'][1]=[[171,199],[(171+p[0])/2-1,(199+p[1])/2+3],p]
  if d=='back_left':
   p=wrists[d][f];row['target_arms'][0]=[[110,200],[(110+p[0])/2+1,(200+p[1])/2+3],p]
  if d=='back':
   for side,p in enumerate(wrists[d][f]):
    shoulder=[110 if side==0 else 174,199];row['target_arms'][side]=[shoulder,[(shoulder[0]+p[0])/2,(199+p[1])/2+4],p]
  # Preserve the actual camera rectangle, avoiding the old shorts under it.
  row['protection']={k:v for k,v in row['protection'].items() if k in ['head','feet']}
  rect={'front_right':[142,206,43,34],'right':[165,207,40,33],'left':[80,207,40,33],'front_left':[103,206,43,34]}.get(d)
  if rect:row['protection']['camera']=rect
  j['frames'].append(row)
j['provenance']['review']='Unreviewed seven-direction walk draft; separate torso fabric from original garment-only v1, camera sleeve cloth from v2. Original fixed wearer retained; no wardrobe registration.'
(b/'guide-v1.json').write_text(json.dumps(j,indent=2)+'\n')
shutil.copyfile(old/'parts-v1.png',r/j['body_atlas'])
stage=r/'work/tutorial-current-20261020/validation-project'
for rel in ['tools/island_avatar/build_garment_layers.gd','tools/island_avatar/garment_manifest.py',j['body_atlas']]:
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/rel,p)
print('Drafted',len(j['frames']),'cels, not visually accepted')
