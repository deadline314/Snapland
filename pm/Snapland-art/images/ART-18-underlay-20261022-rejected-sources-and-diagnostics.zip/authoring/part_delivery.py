from pathlib import Path
import os,shutil,json,time
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();b=r/'work/cloth-walk-20261022';s=r/'work/tutorial-current-20261020/validation-project';g=r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64';d=s/'work/cloth-walk-20261022';d.mkdir(exist_ok=True)
fixed=(r/'tools/island_avatar/build_garment_layers.gd').read_text();broken=fixed.replace('if not separate_body:', 'if true:');assert broken!=fixed
(d/'broken_underlay.gd').write_text(broken)
fixture=(r/'game/tests/test_garment_part_ownership.gd').read_text();(d/'broken_guard.gd').write_text(fixture.replace('res://tools/island_avatar/build_garment_layers.gd','res://work/cloth-walk-20261022/broken_underlay.gd'))
for rel in ['tools/island_avatar/build_garment_layers.gd','game/tests/test_garment_part_ownership.gd']:shutil.copyfile(r/rel,s/rel)
records=[]
for case,script in [('part-negative','res://work/cloth-walk-20261022/broken_guard.gd'),('part-final','res://game/tests/test_garment_part_ownership.gd')]:
 out=b/case;out.mkdir();start=time.monotonic();p=run_validated_godot(s,[str(g),'--headless','--path',str(s),'--audio-driver','Dummy','--script',script],dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'progress.json')),90);log=p.stdout+p.stderr;(out/'result.log').write_text(log);data=dict(exit=p.returncode,errors=log.count('ERROR:'),seconds=round(time.monotonic()-start,2));(out/'result.json').write_text(json.dumps(data,indent=2)+'\n');records.append(dict(case=case,**data));print(records[-1],flush=True)
 if case=='part-negative':assert p.returncode==1 and 'Independent torso fabric retained a camera-pose sleeve hole' in log
 else:assert p.returncode==0 and data['errors']==0 and 'PASS: garment sleeves retain' in log
(b/'part-delivery.json').write_text(json.dumps(records,indent=2)+'\n')
