from pathlib import Path
from PIL import Image
import json,shutil,hashlib
r=Path.cwd();b=r/'work/cloth-walk-20261022';j=json.loads((b/'guide-v2.json').read_text());raw=Path('/workspace/generated_images/exec-4a87667d-9b0a-4ce6-842d-15f46572ee30.png');size=list(Image.open(raw).size);print(size);assert size==[1563,1006]
j.update(body_atlas='tools/island_avatar/garments/mustard-body-eight-parts-v3.png',body_atlas_size=size,body_atlas_sha256=hashlib.sha256(raw.read_bytes()).hexdigest(),torso_scale=[.5,.35])
roots={'front_right':[227,180],'right':[225,180],'back_right':[186,180],'back':[210,120],'back_left':[225,120],'left':[207,120],'front_left':[187,120]}
for row in j['frames']:
 row['source_root']=roots[row['direction']];row['body_atlas_region']=row['atlas_region'][:];row['body_atlas_region'][2]=min(row['body_atlas_region'][2],size[0]-row['body_atlas_region'][0]);row['body_polygon']=[[1,1],[389,1],[389,502],[1,502]]
j['provenance']['review']='Unreviewed v3 independent sleeveless torso source generated with imagegen. Primary v2 sleeves retain distinct joints and source regions. Original approved wearer, hands and props retained.'
j['provenance']['body_imagegen_original']=str(raw)
(b/'guide-v3.json').write_text(json.dumps(j,indent=2)+'\n');shutil.copyfile(raw,r/j['body_atlas']);shutil.copyfile(raw,r/'work/tutorial-current-20261020/validation-project'/j['body_atlas'])
