from PIL import Image,ImageDraw
from pathlib import Path
b=Path('work/cloth-walk-20261022');src=b/'current-originals/sources'
for d in ['front','front_right','right','back_right','back','back_left','left','front_left']:
 out=Image.new('RGB',(1120,400),'#dddccc');dr=ImageDraw.Draw(out)
 for f in range(8):
  im=Image.open(src/f'walk-{d}-{f:02}.png').convert('RGBA');x=f%4*280;y=f//4*200
  out.paste(im.crop((0,175,280,350)),(x,y+25),im.crop((0,175,280,350)))
  dr.text((x+4,y+3),f'{d}/{f}: y175..350',fill='black')
  for k in range(80,211,20):dr.line((x+k,y+25,x+k,y+200),fill='#9faaa4');dr.text((x+k,y+15),str(k),fill='black')
  for k in [200,220,240,260,280,300,320]:dr.line((x+50,y+25+k-175,x+230,y+25+k-175),fill='#9faaa4');dr.text((x+15,y+25+k-175),str(k),fill='black')
 out.save(b/f'{d}-body-grid.png')
