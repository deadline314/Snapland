from pathlib import Path
import subprocess,concurrent.futures,json,hashlib,ast,re
r=Path.cwd();b=r/'work/cloth-walk-20261022';g=r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64';stage=r/'work/tutorial-current-20261020/validation-project'
def bake(name,guide,old):
 p=subprocess.run(['python','tools/island_avatar/build_garment_layers.py','--guide',guide,'--project',str(stage),'--godot',str(g),'--profile',str(b/name/'progress.json')],capture_output=True,text=True,timeout=70);log=p.stdout+p.stderr;(b/(name+'.log')).write_text(log);assert p.returncode==0,log
 files=sorted((b/name/'compiled').glob('*.png'));assert files
 for f in files:assert f.read_bytes()==(r/old/f.name).read_bytes(),f.name
 return dict(name=name,exit=p.returncode,pngs_byte_identical=len(files),errors=log.count('ERROR:'))
with concurrent.futures.ThreadPoolExecutor(2) as ex:
 results=list(ex.map(lambda a:bake(*a),[('front-regression','tools/island_avatar/garments/mustard-front-guide.json','work/outfit-eight-view-20261021/front-regression-v2/compiled'),('idle-regression','tools/island_avatar/garments/mustard-idle-eight-guide.json','work/outfit-eight-view-20261021/idle36-delivery-v2/compiled')]))
(b/'regression.json').write_text(json.dumps(results,indent=2)+'\n');print(results)
log=(b/'ci-59a-runtime.log').read_text();runs=re.findall(r'RUN: (.+?) \((\d+)/(\d+), limit (\d+)s\)',log);passes=re.findall(r'PASS: (.+?) \(([\d.]+)s\)',log)
tree=ast.parse(subprocess.check_output(['git','show','59a494f:tools/run_game_tests.py'],text=True));node=next(n for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='checks' for t in n.targets));names=[ast.literal_eval(row.elts[0]) for row in node.value.elts];assert len(runs)==len(passes)==len(names)==93;assert names==[x[0] for x in runs]==[x[0] for x in passes]
assert all(int(x[3])==(240 if x[0]=='avatar renderer tests' else 90) for x in runs)
full=(b/'ci-59a-full.log').read_text();assert 'Ran 137 tests' in full and 'PASS 5 design scope(s)' in full
(b/'ci-59a-verification.json').write_text(json.dumps(dict(commit='59a494f7c8b719c4f0e103057ea7d754ae086e2e',run=39524314595,python=137,godot_runs=93,godot_passes=93,scope_count=5,names_order_caps_verified=True,scope='Prior published main baseline only; excludes current authoring changes.'),indent=2)+'\n');print('Prior CI actual93/137/5 verified')
