from PIL import Image,ImageDraw
from pathlib import Path
import json
b=Path('work/cloth-walk-20261022');j=json.loads((b/'guide-v1.json').read_text());r=Path.cwd()
out=Image.new('RGB',(1564,1006),'#dddccc');im=Image.open(r/j['atlas']).convert('RGBA');out.paste(im,(0,0),im);dr=ImageDraw.Draw(out)
for row in j['frames']:
 if row['frame']:continue
 x,y,w,h=row['atlas_region'];dr.text((x+20,y+20),row['direction'],fill='red')
 for a in row['source_arms']:
  dr.line([(x+p[0],y+p[1]) for p in a],fill='red',width=2)
  for p in a:dr.ellipse((x+p[0]-3,y+p[1]-3,x+p[0]+3,y+p[1]+3),outline='red',width=2)
 for yy in range(100,440,40):dr.text((x+5,y+yy),str(yy),fill='red')
 for xx in range(80,350,40):dr.text((x+xx,y+450),str(xx),fill='red')
out.save(b/'source-bones-v1.png')
