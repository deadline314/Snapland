from PIL import Image,ImageDraw,ImageFilter
import colorsys
bags={'front':[80,192,120,62],'front_right':[65,188,76,70],'right':[77,193,64,65],'back_right':[74,192,88,61],'back':[105,192,62,60],'back_left':[113,192,90,62],'left':[157,190,61,63],'front_left':[174,188,52,67]}
papers={'front':[195,200,30,40],'front_right':[67,197,25,22],'right':[81,197,25,22],'back_right':[72,208,23,30],'back':[167,210,27,33],'back_left':[190,210,26,30],'left':[190,197,29,24],'front_left':[202,197,25,24]}
def hull(points):
 points=sorted(set(points));lo=[];hi=[]
 def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
 for p in points:
  while len(lo)>1 and cross(lo[-2],lo[-1],p)<=0:lo.pop()
  lo.append(p)
 for p in reversed(points):
  while len(hi)>1 and cross(hi[-2],hi[-1],p)<=0:hi.pop()
  hi.append(p)
 return lo[:-1]+hi[:-1]
def foreground(im,d,arms,action):
 mask=Image.new('L',(280,360));x0,y0,w,h=bags[d];seeds=[]
 for y in range(y0,y0+h):
  for x in range(x0,x0+w):
   r,g,b,a=im.getpixel((x,y));hh,s,v=colorsys.rgb_to_hsv(r/255,g/255,b/255)
   if a>12 and .035<hh<.14 and s>.28 and .12<v<.69 and r>g*1.17:seeds.append((x,y))
 left=set(seeds);components=[]
 while left:
  p=left.pop();component=[p];queue=[p]
  while queue:
   x,y=queue.pop()
   for dx,dy in [(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1)]:
    p=(x+dx,y+dy)
    if p in left:left.remove(p);component.append(p);queue.append(p)
  components.append(component)
 # Explicit authored backpack silhouette; disconnected pocket/flap colors
 # cannot define the bag boundary. No warm-color hull is used for ownership.
 polygons={
 'front_right':[[77,194],[105,197],[106,219],[94,249],[76,250],[67,235],[67,214]],
 'right':[[91,196],[115,201],[118,219],[117,244],[104,253],[86,249],[78,236],[80,214]],
 'back_right':[[89,194],[140,195],[154,216],[150,242],[134,249],[89,246],[80,234],[78,216]],
 'back':[[112,192],[162,192],[171,211],[170,244],[157,251],[118,251],[105,241],[104,212]],
 'back_left':[[125,197],[176,198],[193,217],[194,244],[175,251],[132,247],[122,229]],
 'left':[[165,197],[191,195],[213,217],[217,238],[205,249],[181,252],[164,242]],
 'front_left':[[180,196],[207,197],[223,218],[225,240],[212,252],[188,247],[177,228]]}
 if d in polygons:ImageDraw.Draw(mask).polygon(polygons[d],fill=255)
 for x,y in seeds:
  if y<230:mask.putpixel((x,y),255)
 px,py,pw,ph=papers[d]
 for y in range(py,py+ph):
  for x in range(px,px+pw):
   r,g,b,a=im.getpixel((x,y));hh,s,v=colorsys.rgb_to_hsv(r/255,g/255,b/255)
   if a>12 and v>.6 and s<.4:mask.putpixel((x,y),255)

 mask=mask.filter(ImageFilter.MaxFilter(3));spans=[]
 for y in range(192,285):
  start=last=None
  for x in range(280):
   if mask.getpixel((x,y)) and im.getpixel((x,y))[3]>12:
    if start is None:start=x
    last=x
   elif start is not None:spans.append([y,start,last]);start=last=None
  if start is not None:spans.append([y,start,last])
 return spans
