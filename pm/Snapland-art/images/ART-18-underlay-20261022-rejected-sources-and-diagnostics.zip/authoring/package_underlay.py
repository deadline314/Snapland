from pathlib import Path
import json,hashlib,shutil,zipfile
r=Path.cwd();b=r/'work/cloth-walk-20261022';out=r/'pm/Snapland-art/images';prefix='ART-18-underlay-20261022-'
refs=['tools/island_avatar/garment_manifest.py','tools/island_avatar/build_garment_layers.gd','tests/test_garment_manifest.py','game/tests/test_garment_part_ownership.gd']
history={'scope':'Authoring support and rejected visual candidates only; no new approved garment coverage or live wardrobe adoption.',
'coat_v1_v2':'56 numerical original-head/foot-safe cels rejected for exposed original sleeves, incomplete torso silhouette and incorrect shorts foreground.',
'coat_v3_v4':'Independent generated torso was a better underlay, but sleeve joints/sockets and inconsistent shoulder ownership remain rejected.',
'vest_v1':'100-cel numerical safety rejection because draw clip overlapped the enlarged immutable head region. No accepted output.',
'vest_v2_v3':'100 numerical cels; shorts fragments and/or backpack lower-body occlusion remained. First native normal run numerically passed; visually rejected.',
'vest_v4_v5':'Explicit backpack silhouette restores bag, but hand ownership and broad camera protection still expose unrelated original pixels.',
'vest_v6_v7':'Normal native head/foot checks pass, but missing palms/waist fragments still fail visual acceptance. No quarter-speed claim.',
'vest_v8':'Manual sleeve envelopes are still inaccurate and cut into some sleeves. Rejected; draft100 cels do not add to the existing approved coat44.',
'v3_author_script':'Initial local assumption that generated image width was1564 failed before baking. Actual1563 width retained, reviewed and used; no image resizing to force that assumption.',
'pipeline_delivery':'Independent torso underlay and original-arm span restoration are explicit authoring options, not wardrobe enablement. Both-atlas source validation, bounded geometry and inspection-only status remain mandatory.'}
for rel in ['python-19.log','regression.json','front-regression.log','idle-regression.log','part-delivery.json','part-negative/result.json','part-negative/result.log','part-final/result.json','part-final/result.log','ci-59a-verification.json','ci-59a-runtime.log','ci-59a-full.log','reference-images.json','spine-mesh.png','aseprite-fixed-grid.png','vest-bake-v8-walk-left.png','vest-bake-v7-walk-back_left.png','vest-bake-v3-back_left.png']:
 shutil.copyfile(b/rel,out/(prefix+rel.replace('/','-')))
for name in ['result.json','result.log','video-metadata.json']:shutil.copyfile(b/'normal-v7'/name,out/(prefix+'rejected-native-'+name))
shutil.copyfile(b/'normal-v7/play.mp4',out/(prefix+'rejected-native.mp4'))
(out/(prefix+'attempt-history.json')).write_text(json.dumps(history,indent=2)+'\n')
record={'starting_commit':'59a494f7c8b719c4f0e103057ea7d754ae086e2e','scope':'ART-18 authoring-only underlay safety and review process. All new clothing candidates rejected. No new approved poses, wardrobe or whole-ticket completion.','approved_existing_coat_cels':44,'existing_missing_cels':104,'extra_legacy_requests':24,'rejected_vest_draft_cels':100,'new_approved_cels':0,'python_focused_tests':19,'native_godot_guard':json.loads((b/'part-delivery.json').read_text()),'unchanged_old_outputs':json.loads((b/'regression.json').read_text()),'native_rejected_scope':'100-cel2D authoring with head/foot exactness; normal simulation only. Silent20FPS movie decoded; not a formal Main/wardrobe/slow/reduced/PCK,human play or listening acceptance.','source_sha256':{p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in refs},'baseline_ci':json.loads((b/'ci-59a-verification.json').read_text())}
(out/(prefix+'verification.json')).write_text(json.dumps(record,indent=2)+'\n')
# Preserve raw generated sources. They are review evidence, never runtime assets.
gen=[Path('/workspace/generated_images/exec-4a87667d-9b0a-4ce6-842d-15f46572ee30.png'),Path('/workspace/generated_images/exec-92f03291-a718-42eb-a15d-3d040c5747c5.png')]
provenance={'tool':'built-in imagegen','reference':{'path':'work/outfit-eight-view-20261021/parts-v1.png','sha256':hashlib.sha256((r/'work/outfit-eight-view-20261021/parts-v1.png').read_bytes()).hexdigest()},'outputs':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in gen],'status':'Unadopted authoring source, no production asset approval.'}
(b/'generation-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
with zipfile.ZipFile(out/(prefix+'rejected-sources-and-diagnostics.zip'),'w',zipfile.ZIP_DEFLATED) as z:
 for rel in refs:z.write(r/rel,'source-snapshot/'+rel)
 for p in gen:z.write(p,'generated-originals/'+p.name)
 z.write(r/'work/outfit-eight-view-20261021/parts-v1.png','generated-references/parts-v1.png')
 z.write(r/'work/outfit-eight-view-20261021/prompt.txt','generated-references/parts-v1-prompt.txt')
 for p in b.iterdir():
  if p.is_file() and p.suffix in ['.py','.gd','.tscn','.json','.txt']:z.write(p,'authoring/'+p.name)
 for case in ['bake-v1','bake-v2','bake-v3','bake-v4','vest-bake-v1','vest-bake-v2','vest-bake-v3','vest-bake-v4','vest-bake-v5','vest-bake-v6','vest-bake-v7','vest-bake-v8','normal','normal-v6','normal-v7','part-negative','part-final']:
  for name in ['result.json','result.log','bake-report.json','validated-guide.json','launch-source-hashes.json','render-report.json','native_vest_review.gd','native_vest_review.tscn','vest-guide-v1.json']:
   p=b/case/name
   if p.exists():z.write(p,'attempts/'+case+'/'+name)
 for p in (b/'vest-bake-v8/compiled').glob('*.png'):z.write(p,'rejected-final100/'+p.name)
 for p in (b/'normal-v7/captures').glob('*.png'):z.write(p,'rejected-native/'+p.name)
 for p in b.glob('vest-bake-v8-*.png'):z.write(p,'rejected-final-contacts/'+p.name)
files=sorted(p for p in out.glob(prefix+'*') if p.name!=prefix+'manifest.json');(out/(prefix+'manifest.json')).write_text(json.dumps({'status':'Authoring support + rejected art; no new approved garment cels','files':[{'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]},indent=2)+'\n')
print('Packaged',len(files),'files',sum(p.stat().st_size for p in files),'bytes')
