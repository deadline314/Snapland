from pathlib import Path
from PIL import Image
import json,copy,math,hashlib,shutil
from vest_foreground import foreground
from arm_ownership import polygons,spans
r=Path.cwd();b=r/'work/cloth-walk-20261022';j=json.loads((b/'guide-v4.json').read_text());walkrows=j['frames'];idle=json.loads((r/'tools/island_avatar/garments/mustard-idle-eight-guide.json').read_text());front=json.loads((r/'tools/island_avatar/garments/mustard-front-guide.json').read_text());j.update(outfit='candidate-mustard-longvest',construction='sleeveless_overlay');j['frames']=[]
roots={'front':[210,180],'front_right':[227,180],'right':[225,180],'back_right':[186,180],'back':[210,120],'back_left':[225,120],'left':[207,120],'front_left':[187,120]};dirs=list(roots)
def distance(p,a,c):
 vx,vy=c[0]-a[0],c[1]-a[1];t=max(0,min(1,((p[0]-a[0])*vx+(p[1]-a[1])*vy)/max(1,vx*vx+vy*vy)));return math.hypot(p[0]-a[0]-t*vx,p[1]-a[1]-t*vy),t
for source in walkrows+idle['frames']+front['frames']:
 row=copy.deepcopy(source);d=row['direction'];f=row['frame'];a=row['action'];im=Image.open(b/'current-originals/sources'/f'{a}-{d}-{f:02}.png').convert('RGBA');row['source_pixel_sha256']=hashlib.sha256(im.tobytes()).hexdigest();row['source_root']=roots[d];i=dirs.index(d);row['atlas_region']=[i%4*391,i//4*503,391,503];row['body_atlas_region']=[i%4*391,i//4*503,min(391,1563-i%4*391),503];row['body_polygon']=[[1,1],[389,1],[389,502],[1,502]];row['part_order']=['body'];row['protection']['head']=[0,0,280,205];row['unchanged_regions']=[[0,0,280,205],[0,310,280,50]];row['draw_clip']=[0,205,280,105];
 if a=='idle' and 'camera' in row['protection']:
  row['protection']['camera']={'front':[119,216,55,30],'front_right':[145,212,44,31],'right':[165,211,41,33],'left':[82,212,39,32],'front_left':[98,212,48,33]}[d]
 row['original_arm_spans']=[];row['protection_spans']=foreground(im,d,row['target_arms'],a)
 row['original_arm_polygons']=polygons(d,a,f,[arm[2] for arm in row['target_arms']])
 row['original_arm_spans']=[spans(im,p) for p in row['original_arm_polygons']]
 for name in ['source_arms','target_arms','arm_mesh_regions','arm_owner_bounds']:row.pop(name,None)
 j['frames'].append(row)
j['provenance']['review']='Unreviewed 100-cel longvest-over-hoodie sample. Separate garment identity from mustard longcoat. Approved complete original arms are explicitly owned and retained; only the independent sleeveless torso is new artwork. No anatomy deformation, sleeve skinning or live adoption.'
(b/'vest-guide-v1.json').write_text(json.dumps(j,indent=2)+'\n')
stage=r/'work/tutorial-current-20261020/validation-project'
for rel in ['tools/island_avatar/build_garment_layers.gd','tools/island_avatar/garment_manifest.py']:shutil.copyfile(r/rel,stage/rel)
print('Drafted',len(j['frames']),'longvest cels, separate from the old coat')
