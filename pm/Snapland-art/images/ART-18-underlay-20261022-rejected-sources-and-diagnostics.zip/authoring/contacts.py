from pathlib import Path
from PIL import Image,ImageDraw
import sys
b=Path('work/cloth-walk-20261022');case=sys.argv[1];src=b/case/'compiled'
for d in ['front_right','right','back_right','back','back_left','left','front_left']:
 out=Image.new('RGB',(1120,760),'#dddccc');dr=ImageDraw.Draw(out)
 for f in range(8):
  im=Image.open(src/f'walk-{d}-{f:02}.png').convert('RGBA');x=f%4*280;y=f//4*380
  out.paste(im,(x,y+20),im);dr.text((x+7,y+4),f'{case} {d}/{f}',fill='black')
 out.save(b/f'{case}-{d}.png')
