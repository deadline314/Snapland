from pathlib import Path
from PIL import Image,ImageDraw
import sys,collections
b=Path('work/cloth-walk-20261022');case=sys.argv[1];groups=collections.defaultdict(list)
for p in sorted((b/case/'compiled').glob('*.png')):
 if not p.stem.endswith(('-original','-garment')):
  action,direction,frame=p.stem.split('-');groups[action,direction].append(p)
for (a,d),files in groups.items():
 out=Image.new('RGB',(1120,380*((len(files)+3)//4)),'#dddccc');dr=ImageDraw.Draw(out)
 for i,p in enumerate(files):
  im=Image.open(p).convert('RGBA');x=i%4*280;y=i//4*380;out.paste(im,(x,y+20),im);dr.text((x+5,y+4),p.stem,fill='black')
 out.save(b/f'{case}-{a}-{d}.png')
print('Contacts',len(groups))
