from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
import json,colorsys
b=Path('work/cloth-walk-20261022');j=json.loads((b/'guide-v1.json').read_text());j['width_scale']=.82;j['torso_scale']=[.63,.43]
ns={};exec(Path('work/outfit-eight-view-20261021/build_idle_guide.py').read_text().split('rows=[]')[0],ns)
bags={'front_right':[65,188,76,70],'right':[77,193,64,65],'back_right':[74,192,88,61],'back':[105,192,62,60],'back_left':[113,192,90,62],'left':[157,190,61,63],'front_left':[174,188,52,67]}
papers={'front_right':[67,197,25,22],'right':[81,197,25,22],'back_right':[72,208,23,30],'back':[167,210,27,33],'back_left':[190,210,26,30],'left':[190,197,29,24],'front_left':[202,197,25,24]}
for row in j['frames']:
 im=Image.open(b/'current-originals/sources'/f"walk-{row['direction']}-{row['frame']:02}.png").convert('RGBA');mask=Image.new('L',(280,360));d=row['direction'];x0,y0,w,h=bags[d];seeds=[]
 for y in range(y0,y0+h):
  for x in range(x0,x0+w):
   r,g,bb,a=im.getpixel((x,y));hh,s,v=colorsys.rgb_to_hsv(r/255,g/255,bb/255)
   if a>12 and .035<hh<.14 and s>.28 and .12<v<.69 and r>g*1.17:seeds.append((x,y));mask.putpixel((x,y),255)
 # Keep the actual brown bag body including its seams, avoiding warm shorts.
 left=set(seeds);components=[]
 while left:
  p=left.pop();component=[p];queue=[p]
  while queue:
   x,y=queue.pop()
   for dx,dy in [(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1)]:
    p=(x+dx,y+dy)
    if p in left:left.remove(p);component.append(p);queue.append(p)
  components.append(component)
 if components:
  largest=max(components,key=len)
  if len(largest)>50:ImageDraw.Draw(mask).polygon(ns['hull'](largest),fill=255)
 px,py,pw,ph=papers[d]
 for y in range(py,py+ph):
  for x in range(px,px+pw):
   r,g,bb,a=im.getpixel((x,y));hh,s,v=colorsys.rgb_to_hsv(r/255,g/255,bb/255)
   if a>12 and v>.6 and s<.4:mask.putpixel((x,y),255)
 for arm in row['target_arms']:
  wx,wy=map(round,arm[2])
  for y in range(max(192,wy-8),min(285,wy+25)):
   for x in range(max(0,wx-13),min(280,wx+24)):
    r,g,bb,a=im.getpixel((x,y));hh,s,v=colorsys.rgb_to_hsv(r/255,g/255,bb/255)
    if a>12 and 0<hh<.18 and s>.2 and v>.25 and r>g*1.15 and g>bb*1.05:mask.putpixel((x,y),255)
 mask=mask.filter(ImageFilter.MaxFilter(3));spans=[]
 for y in range(192,285):
  start=None;last=None
  for x in range(280):
   yes=mask.getpixel((x,y)) and im.getpixel((x,y))[3]>12
   if yes:
    if start is None:start=x
    last=x
   elif start is not None:spans.append([y,start,last]);start=last=None
  if start is not None:spans.append([y,start,last])
 row['protection_spans']=spans
(b/'guide-v2.json').write_text(json.dumps(j,indent=2)+'\n')
