from pathlib import Path
import shutil,json
r=Path.cwd();b=r/'work/cloth-walk-20261022';stage=r/'work/tutorial-current-20261020/validation-project';old=r/'work/outfit-eight-view-20261021/native_idle_review.gd';s=old.read_text();start=s.index('\tvar base:=');end=s.index('\n\tqueue_redraw()',start)
s=s[:start]+'''	var base:=ProjectSettings.globalize_path("res://work/cloth-walk-20261022/vest-bake-v7/compiled")
	var guide: Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://work/cloth-walk-20261022/vest-guide-v1.json"))
	var manifest: Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://assets/characters/idle-stability-v1/manifest.json"))
	for row in guide.frames:
		var direction:=str(row.direction);var frame:=int(row.frame);var action:=str(row.action)
		var stem:="%s-%s-%02d"%[action,direction,frame]
		var a:=Image.load_from_file(base.path_join(stem+"-original.png"));var b:=Image.load_from_file(base.path_join(stem+".png"))
		if a==null or b==null or a.get_size()!=Vector2i(280,360) or b.get_size()!=Vector2i(280,360):get_tree().quit(2);return
		originals.append(ImageTexture.create_from_image(a));candidates.append(ImageTexture.create_from_image(b))
		total+=float(manifest.sequences["hero-idle/"+direction].frame_durations[frame]) if action=="idle" else 0.125
		poses.append({"action":action,"direction":direction,"frame":frame,"end":total})''' + s[end:]
s=s.replace('originals.size()!=36','originals.size()!=100').replace('captured.size()!=36','captured.size()!=100').replace('Eight-direction idle clothing authoring','Longvest / original hoodie authoring').replace('PASS: native garment idle authoring 36 actual cels / eight directions;', 'PASS: native longvest authoring 100 actual cels / eight directions;').replace('Rect2i(220,100,392,268)','Rect2i(220,100,392,287)').replace('Rect2i(700,100,392,268)','Rect2i(700,100,392,287)').replace('captures/%s-%02d.png','captures/%s-%s-%02d.png').replace('[poses[index].direction,poses[index].frame]','[poses[index].action,poses[index].direction,poses[index].frame]').replace('"direction":poses[index].direction','"action":poses[index].action,"direction":poses[index].direction').replace('Original idle durations; fixed canvas;', 'Original idle durations; walk inspection at 8 FPS;').replace('actual rendered idle clothing','actual rendered longvest clothing')
(b/'native_vest_review.gd').write_text(s);(b/'native_vest_review.tscn').write_text('[gd_scene load_steps=2 format=3]\n\n[ext_resource type="Script" path="res://work/cloth-walk-20261022/native_vest_review.gd" id="1"]\n\n[node name="LongvestReview" type="Node2D"]\nscript = ExtResource("1")\n')
dest=stage/'work/cloth-walk-20261022';dest.mkdir(exist_ok=True)
for name in ['native_vest_review.gd','native_vest_review.tscn','vest-guide-v1.json']:shutil.copyfile(b/name,dest/name)
shutil.copytree(b/'vest-bake-v7/compiled',dest/'vest-bake-v7/compiled')
