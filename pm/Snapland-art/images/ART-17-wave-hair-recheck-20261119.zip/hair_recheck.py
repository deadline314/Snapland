"""Retest live alternate hair against the side-greeting delivery."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
script = HERE / "final_checks.py"
previous_main = __import__("__main__").__name__
__name__ = "wave_fixture_library"
exec(compile(script.read_text("utf8"), str(script), "exec"))
__name__ = previous_main

FIXTURE = "game/tests/profile_wave_hair_recheck"
runner.FIXTURES = [FIXTURE + ".gd", FIXTURE + ".tscn"]
CODE = r'''extends Node
const ParkWorld := preload("res://game/world/park_world.gd")

func _ready() -> void:
	call_deferred("_run")

func _run() -> void:
	var out := OS.get_environment("COTTON_CAPTURE_DIR")
	assert(out.is_absolute_path() and DisplayServer.get_name() != "headless")
	var world := ParkWorld.new()
	add_child(world)
	var results: Array[Dictionary] = []
	var passed := true
	for style in ["bob", "curly"]:
		var appearance := world.avatar_appearance.duplicate()
		appearance.hair = style
		world.set_avatar_look(appearance, {"outfit": "outfit-tide", "hat": "hat-none"})
		world.player.position = Vector3(0.0, ParkWorld._ground_surface_y(Vector3(0.0, 0.0, -15.0)), -15.0)
		world.player.velocity = Vector3.ZERO
		var angles := 0.0
		Input.action_press("move_right")
		for tick in range(18):
			await get_tree().physics_frame
			angles = maxf(angles, world.avatar_hair_rig.spring.angles.length())
		Input.action_release("move_right")
		var active: bool = world.avatar_hair_rig.active
		results.append({"style": style, "active": active, "peak_angle": angles,
			"fallback_reason": world.avatar_hair_rig.fallback_reason})
		passed = passed and active and angles > 0.0001 and world.facing == "right"
		await RenderingServer.frame_post_draw
		passed = get_viewport().get_texture().get_image().save_png(out.path_join(style + "-walking.png")) == OK and passed
		for tick in range(12): await get_tree().physics_frame
	var file := FileAccess.open(out.path_join("hair-active.json"), FileAccess.WRITE)
	assert(file != null)
	file.store_string(JSON.stringify(results, "\t"))
	file.close()
	world.queue_free()
	await get_tree().process_frame
	if passed: print("PASS: both alternate hairstyles retain live source-bound motion")
	else: push_error("Alternate live hair failed: " + JSON.stringify(results))
	get_tree().quit(0 if passed else 1)
'''


def check(baseline):
    tag = "red-live-hair" if baseline else "fixed-live-hair"
    base = runner.make_base(tag)
    project = base / "project"
    project.mkdir()
    graph = runner.prepare_runtime_stage(ROOT, project, paths)
    scripts = {
        FIXTURE + ".gd": CODE,
        FIXTURE + ".tscn": f'[gd_scene load_steps=2 format=3]\n\n[ext_resource type="Script" path="res://{FIXTURE}.gd" id="1"]\n\n[node name="HairRecheck" type="Node"]\nscript = ExtResource("1")\n',
    }
    for name, code in scripts.items():
        target = project / name
        target.parent.mkdir(exist_ok=True, parents=True)
        target.write_text(code, encoding="utf8", newline="\n")
        graph[name] = runner.sha(target)
    if baseline:
        for style in ("alternate-owners", "bob", "curly"):
            name = "assets/characters/island-hair-" + style + "-v1.json"
            (project / name).write_bytes(subprocess.check_output(["git", "show", "545c95d:" + name], cwd=ROOT))
            graph[name] = runner.sha(project / name)
    runner.dump(base / "source-graph.json", {"source_raw_sha256": graph, "fixtures": runner.FIXTURES, "baseline": baseline})
    donor = runner.make_base(tag + "-import")
    import_project = donor / "project"
    shutil.copytree(project, import_project)
    shutil.copyfile(base / "source-graph.json", donor / "source-graph.json")
    runner.launch(donor, import_project, graph, "import", [runner.ENGINE, "--headless", "--path", import_project,
        "--editor", "--import", "--quit"], runner.environment(donor))
    runner.collect_imports(donor, import_project, graph)
    runner.copy_imports(donor, project, graph)
    print(base.as_posix(), flush=True)
    result = runner.launch(base, project, graph, tag,
        [runner.ENGINE, "--path", project, "--rendering-method", "gl_compatibility",
         "--audio-driver", "Dummy", "--fixed-fps", "30", "res://" + FIXTURE + ".tscn"], runner.environment(base))
    assert result["exit_code"] == 0 and not result["errors"] and not result["leak_diagnostics"]
    print(runner.read(base / "captures/hair-active.json"), flush=True)


if __name__ == "__main__":
    check(sys.argv[1] == "before")
