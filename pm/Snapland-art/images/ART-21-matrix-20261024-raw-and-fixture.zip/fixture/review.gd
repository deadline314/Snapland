extends "res://game/tests/native_minigame_acceptance.gd"
const Daylight = preload("res://game/core/time_of_day.gd")
var records: Array[Dictionary] = []

func _run() -> void:
	_read_arguments(".review/art21-current-20261024",24000)
	if not await _start_main(): return
	var baseline := _persistent_snapshot()
	for reduced in [false,true]:
		if reduced and not await _enable_reduced_motion(): return
		for number in range(1,13):
			var id := "game-%03d" % number
			var session := await _launch_station(id,"開始遊玩")
			if session == null: return
			if bool(session.reduced_motion) != reduced:
				await _fail("Session did not use actual reduced-motion setting: " + id)
				return
			if number == 1:
				_key(KEY_ENTER)
				await _frames(4)
				if not session.balloon_started:
					await _fail("Actual Enter did not start balloon delivery")
					return
			var phases: Array = ["night"] if reduced else Daylight.phase_ids()
			for phase in phases:
				_key(KEY_T)
				if not await _wait_frames_until(func() -> bool: return main.modal_kind == "time", "actual T time panel",240): return
				var frozen := _clock_state(session)
				await _frames(4)
				if _clock_state(session) != frozen or main.time_panel.collect_button != null:
					await _fail("Time menu advanced a game or offered world postcards: " + id)
					return
				var phase_button := main.overlay.find_child("TimePhase_"+phase,true,false) as Button
				if phase_button == null:
					await _fail("Missing phase button: " + phase)
					return
				if main.time_panel.current_phase != phase:
					if not await _native_click_button(phase_button,"select phase "+phase): return
				await _frames(3)
				if session.time_phase != phase or main.world.active_time_phase != phase or str(progress.settings.time_phase) != phase or _clock_state(session) != frozen:
					await _fail("Phase change reset or advanced a game, or did not apply: " + id + "/" + phase)
					return
				_key(KEY_ESCAPE)
				if not await _wait_frames_until(func() -> bool: return main.modal_kind == "", "Escape from time menu",240): return
				if main.session != session or not session.can_process():
					await _fail("Time menu did not restore the same playable session")
					return
				await _frames(3)
				var name := "%s-%s%s.png" % [id,phase,"-reduced" if reduced else ""]
				if not await _capture(name): return
				records.append({"game":id,"phase":phase,"reduced_motion":reduced,"capture":name,"clock_before_time_panel":frozen,"clock_after_resume":_clock_state(session)})
			if not await _click_hud(session,"PauseButton","pause before normal leave"): return
			if not await _click_hud(session,"LeaveButton","request normal leave"): return
			if not await _click_hud(session,"ConfirmAction","confirm normal leave"): return
			if not await _wait_frames_until(func() -> bool: return main.session == null and main.modal_kind == "", "return to park",240): return
			if _persistent_snapshot() != baseline:
				await _fail("Display/leave review changed collection, currency or other protected progress")
				return
	var out := OS.get_environment("SNAPLAND_SAVE_PATH").get_base_dir()
	var file := FileAccess.open(out.path_join("matrix.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify(records,"  "))
	if records.size() != 60:
		await _fail("Expected48phase views plus12reduced night views")
		return
	print("PASS: current Main twelve games x four actual time-panel phases, twelve actual reduced-motion night views, frozen clocks, same-session resume and confirmed leave with unchanged protected progress; no gameplay completion or listening claim")
	await main._quit_game()

func _enable_reduced_motion() -> bool:
	_key(KEY_ESCAPE)
	if not await _wait_frames_until(func() -> bool: return main.modal_kind == "pause", "park pause menu",240): return false
	var settings := main.overlay.find_child("PauseSettingsButton",true,false) as Button
	if not await _native_click_button(settings,"actual park settings entry"): return false
	if not await _wait_frames_until(func() -> bool: return main.modal_kind == "settings", "settings panel",240): return false
	var tab := main.overlay.find_child("SettingsTab_play",true,false) as Button
	if not await _native_click_button(tab,"gameplay settings category"): return false
	await _frames(3)
	var toggle := main.overlay.find_child("Value_reduced_motion",true,false) as CheckButton
	if toggle == null or not await _native_click_button(toggle,"actual reduced-motion setting"): return false
	if not bool(progress.settings.reduced_motion):
		await _fail("Actual setting click did not enable reduced motion")
		return false
	_key(KEY_ESCAPE)
	if not await _wait_frames_until(func() -> bool: return main.modal_kind == "", "settings return to park",240): return false
	return true

func _clock_state(session: Control) -> Dictionary:
	var state := {"elapsed":session.elapsed,"phase":session.phase,"score":session.score,"mistakes":session.mistakes}
	var fields := {"kite_rings":"kite_model","crowd_traffic":"crowd_model","hat_catching":"hat_model","ribbon_rhythm":"ribbon_model","flower_pipes":"pipe_model","sign_balance":"sign_model","shadow_alignment":"shadow_model","bubble_photo":"bubble_model","bench_swap":"bench_model","melody_memory":"melody_model"}
	if fields.has(session.mode):
		var model: Variant = session.get(fields[session.mode])
		var snapshot: Dictionary = model.snapshot()
		for key in ["elapsed","phase_elapsed","round_elapsed","phase_time","active_progress","score","error_count","input_index","gesture_index"]:
			if snapshot.has(key): state["model_"+key] = snapshot[key]
	return state
