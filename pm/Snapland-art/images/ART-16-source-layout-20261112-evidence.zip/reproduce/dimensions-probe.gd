extends SceneTree
func _initialize():
 var library=preload("res://game/world/character_animation_library.gd").new()
 var frame: Dictionary=library.manifest.actors.announcer.walk.right.frames[0]
 var source: Image=library._image(str(frame.source),"announcer","walk","right",0)
 var reshaped=Image.create_from_data(source.get_width()/2,source.get_height()*2,false,source.get_format(),source.get_data())
 assert(reshaped!=null)
 library._images[str(frame.source)]=reshaped
 var expected=library._render_frame("announcer","walk","right",0,frame,{},true)
 var actual=library.texture("announcer","walk","right",0)
 assert(expected!=null and actual!=null)
 var wrong=expected.get_image().get_data()!=actual.get_image().get_data()
 print("SAME_PIXEL_BYTES=",source.get_data()==reshaped.get_data()," SOURCE_LAYOUT=",source.get_size(),"/",reshaped.get_size()," STALE_OVERRIDE=",wrong)
 quit(1 if wrong else 0)
