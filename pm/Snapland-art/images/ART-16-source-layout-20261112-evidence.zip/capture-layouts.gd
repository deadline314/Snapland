extends SceneTree
func _initialize():
 var library=preload("res://game/world/character_animation_library.gd").new()
 var result={}
 for key in library._stable_walk_pixels.manifest:
  if key.begins_with("hero/"):continue
  for binding in library._stable_walk_pixels.manifest[key].source_bindings:
   var pose: Dictionary=binding.frame.pose
   var source: Image=library._image(str(pose.source),"announcer","walk","right",0)
   var context=HashingContext.new()
   if context.start(HashingContext.HASH_SHA256)!=OK or context.update(source.get_data())!=OK:quit(1);return
   assert(context.finish().hex_encode()==binding.image_sha256)
   result[str(pose.source)]="%dx%d:%d" % [source.get_width(),source.get_height(),source.get_format()]
 var file=FileAccess.open("C:/Users/stanl/Github/Snapland/.review/source-layout-20261112/layouts.json",FileAccess.WRITE)
 file.store_string(JSON.stringify(result,"  "))
 file.close()
 print("CAPTURED imported source layouts: ",result.size())
 quit()
