from pathlib import Path
import json
root=Path(__file__).resolve().parents[2]
base=Path(__file__).resolve().parent
layouts=json.loads((base/'layouts.json').read_text(encoding='utf-8'))
path=root/'assets/characters/walk-stability-v1/manifest.json'
data=json.loads(path.read_text(encoding='utf-8'))
count=0
for key,spec in data['sequences'].items():
 if key.startswith('hero/'):continue
 for binding in spec['source_bindings']:
  binding['image_layout']=layouts[binding['frame']['pose']['source']]
  count+=1
assert count==24
path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('BOUND layouts',count)
