from pathlib import Path
import hashlib,json,shutil,zipfile
root=Path(__file__).resolve().parents[2]
base=Path(__file__).resolve().parent
out=root/'pm/Snapland-art/images'
native=json.loads((base/'native-export/frames.json').read_text(encoding='utf-8'))['frames']
stable=json.loads((root/'assets/characters/walk-stability-v1/manifest.json').read_text(encoding='utf-8'))
count=0
for key,spec in stable['sequences'].items():
 if key.startswith('hero/'):continue
 family,view=key.split('/')
 rows=sorted([r for r in native if (r['family'],r['view'])==(family,view)],key=lambda r:r['frame'])
 assert len(rows)==len(spec['source_bindings'])
 for row,binding in zip(rows,spec['source_bindings']):
  assert row['source_binding']==binding
  count+=1
assert count==24
probe=(base/'dimensions-probe.log').read_text(encoding='utf-8')
assert 'SAME_PIXEL_BYTES=true' in probe and 'STALE_OVERRIDE=false' in probe and 'ERROR:' not in probe
sources=['game/world/walk_pixel_sources.gd','game/tests/export_walk_stability.gd','game/tests/test_character_animation_library.gd','tools/walk_stability/build_registered_walks.py','tests/test_walk_pixel_stability.py','assets/characters/walk-stability-v1/manifest.json']
review={'base_commit':'d396e86a4d2be18944cd55e8a26e2edd4bfa39a8','source_bindings_verified':24,'native_export_frames':672,'runtime_checks':5,'final_library_checks':2,'python_checks':7,'packed_checks':['pixel_stability','source_replacement','same_bytes_different_layout'],'source_pngs_changed':False,'human_played':False,'human_listened':False,'source_sha256':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in sources}}
(base/'review.json').write_text(json.dumps(review,indent=2)+'\n',encoding='utf-8')
shutil.copy2(base/'announcer-pack-isolated/announcer-walk-right-2.png',out/'ART-16-source-layout-20261112-native.png')
with zipfile.ZipFile(out/'ART-16-source-layout-20261112-evidence.zip','w',zipfile.ZIP_DEFLATED) as archive:
 for path in base.iterdir():
  if path.suffix in ('.log','.json','.py','.gd') and 'profile' not in path.name:archive.write(path,path.name)
 archive.write(root/'.review/source-bound-walks-final-20261112/dimensions-red.log','red/dimensions-red.log')
 archive.write(root/'.review/source-bound-walks-final-20261112/dimensions-probe.gd','reproduce/dimensions-probe.gd')
 archive.write(base/'native-export/frames.json','native-export/frames.json')
 for path in (base/'announcer-pack-isolated').glob('*.json'):archive.write(path,'native/'+path.name)
 for name in sources:archive.write(root/name,'frozen-source/'+name)
print('PACKAGED layout regression',count)
