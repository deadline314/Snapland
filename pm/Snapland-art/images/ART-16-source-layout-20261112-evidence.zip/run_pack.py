import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[2]
base = Path(__file__).resolve().parent
sys.path.insert(0,str(root))
from tools.animation_qa import export_animation_qa as qa
qa.FIXTURE_FILES |= {'game/tests/native_authored_patrol_review.gd'}
for role in ('announcer',):
    qa.FIXTURE_FILES |= {'game/tests/native_'+role+'_patrol_review.'+ext for ext in ('gd','tscn')}
stage = base/'pack-stage'
stage.mkdir()
project = Path(qa.prepare_project(stage)['project'])
engine = r'C:\Tools\Godot\Godot_v4.7.2-stable_win64_console.exe'
pack = base/'departures.pck'
for label,args in [('import',['--headless','--editor','--import','--quit']),('export',['--headless','--editor','--export-pack',qa.PRESET_NAME,str(pack),'--quit'])]:
    env = dict(os.environ,SNAPLAND_SAVE_PATH=str(base/'pack-build-profile.json'))
    with (base/('pack-'+label+'.log')).open('w',encoding='utf-8') as log:
        result = subprocess.run([engine,'--path',str(project),'--rendering-method','gl_compatibility',*args],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
    text = (base/('pack-'+label+'.log')).read_text(encoding='utf-8')
    if result.returncode or 'ERROR:' in text: raise RuntimeError(label+' failed: '+text[-1500:])
for role in ('announcer',):
    name = role+'-pack'
    env = dict(os.environ,SNAPLAND_SAVE_PATH=str(base/(name+'-profile.json')))
    args=[engine,'--main-pack',str(pack),'--path',str(project),'--rendering-method','gl_compatibility','--audio-driver','Dummy','--write-movie',str(base/(name+'.avi')),'--fixed-fps','30','res://game/tests/native_'+role+'_patrol_review.tscn','--','--actor='+role,'--actions-only','--animation-output='+str(base/name)]
    with (base/(name+'.log')).open('w',encoding='utf-8') as log:
        result = subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
    text=(base/(name+'.log')).read_text(encoding='utf-8')
    if result.returncode or 'ERROR:' in text: raise RuntimeError(name+' failed: '+text[-1500:])
    print(name,result.returncode)
