import os
from pathlib import Path
import subprocess
base=Path(__file__).resolve().parent
run=base/'empty-pack-run'
run.mkdir(exist_ok=True)
args=[r'C:\Tools\Godot\Godot_v4.7.2-stable_win64_console.exe','--main-pack',str(base/'source-bound-tests.pck'),'--path',str(run),'--rendering-method','gl_compatibility','--audio-driver','Dummy','--write-movie',str(base/'announcer-pack-isolated.avi'),'--fixed-fps','30','res://game/tests/native_announcer_patrol_review.tscn','--','--actor=announcer','--actions-only','--animation-output='+str(base/'announcer-pack-isolated')]
with (base/'announcer-pack-isolated.log').open('w',encoding='utf-8') as log:
 r=subprocess.run(args,env=dict(os.environ,SNAPLAND_SAVE_PATH=str(base/'pack-isolated-profile.json')),stdout=log,stderr=subprocess.STDOUT,timeout=180)
text=(base/'announcer-pack-isolated.log').read_text(encoding='utf-8')
if r.returncode or 'ERROR:' in text:raise RuntimeError(text[-2000:])
print('PASS: isolated source-bound announcer PCK')
