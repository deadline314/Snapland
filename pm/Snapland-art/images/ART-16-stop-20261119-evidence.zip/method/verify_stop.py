"""Reuse the departure acceptance harness with the new left-stop assertions."""
from pathlib import Path
import sys

path=Path(__file__).resolve()
original=path.parent.parent/"art16-20261119/verify_departure.py"
source=original.read_text("utf8")
source=source.replace('D:/Snapland-QA/art16-20261119','D:/Snapland-QA/art16-stop-20261119')
source=source.replace('assets/characters/announcer-departure-sides-v1.png','assets/characters/announcer-stop-landing-v1.png')
source=source.replace('assert detail["maximum_departure_root_drift"]',
    '''assert set(map(int,detail["settle_seen"]["left"])) == set(range(5))
        assert set(map(int,detail["settle_seen"]["right"])) == set(range(4))
        assert detail["maximum_departure_root_drift"]''')
exec(compile(source,str(path),"exec"))
