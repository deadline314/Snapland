"""Run the left stop study in the actual Main patrol, outside the checkout."""
from pathlib import Path
import sys

here = Path(__file__).resolve().parent
source = (here.parent/"art16-20261119/seams_native.py").read_text("utf8")
baseline = sys.argv[1] == "baseline"
prototype = sys.argv[1] == "candidate"
label = "exact-stop-" if baseline else ("candidate-stop-" if prototype else "final-stop-")
source = source.replace("formal-seams-",label)
source = source.replace("art16_formal_seams","art16_exact_stop")
source = source.replace("paths = [p for p in paths if not p.endswith(('.uid','.import'))]", "")
if not baseline and not prototype:
    source = source.replace("manifest = runner.prepare_runtime_stage(ROOT,STAGE,paths)",
        'paths = list(dict.fromkeys([*paths, "assets/characters/announcer-stop-landing-v1.png"]))\nmanifest = runner.prepare_runtime_stage(ROOT,STAGE,paths)')
source = source.replace("D:/Snapland-QA/art16-20261119","D:/Snapland-QA/art16-stop-20261119")
source = source.replace("D:/Snapland-QA/cotton-wind/final-fix/donor-1119-043400-30b24a",
                        "D:/Snapland-QA/art16-20261119/art16-donor-1119-051411-cde323")
if not baseline and not prototype:
    source = source.replace("D:/Snapland-QA/art16-20261119/art16-donor-1119-051411-cde323",sys.argv[2])
source = source.replace("source += '\\n'+(HERE/'seams_fixture.gd.txt').read_text(encoding='utf-8')",
    """fixture=(HERE.parent/'art16-20261119/seams_fixture.gd.txt').read_text('utf8')
fixture=fixture.replace('if identity == previous.get("identity", ""):\\n\\t\\t\\tcontinue\\n', '')
fixture=fixture.replace('\\t\\t\\t\\tvar transition', '\\t\\tvar transition')
if not baseline:
    fixture=fixture.replace('while seen.size() < 4','while seen.size() < 5').replace('if seen.size() != 4','if seen.size() != 5')
    fixture=fixture.replace('var sample := {', '''if action == "settle" and side == "left" and pose == 1 and previous.get("action","") == "settle" and previous.get("frame",-1) == 0:
			transition = "settle-weight-transfer-left"
		var sample := {''')
    fixture=fixture.replace('or transition.begins_with("walk-to-settle-")','or transition.begins_with("walk-to-settle-") or transition == "settle-weight-transfer-left"')
source += "\\n"+fixture""")
start=source.index("runner.dump(BASE/'source-graph.json'")
end=source.index("keys=runner.environment(BASE)",start)
source=source[:start]+'''from PIL import Image

if prototype:
    art = "assets/characters/announcer-stop-study-01.png"
    shutil.copy2(HERE/Path(art).name,STAGE/art)
    asset_path="assets/characters/complete-animation-regions.json"
    meta=runner.read(STAGE/asset_path)
    choice=runner.read(HERE/"announcer-stop-study-01.json")["left"]["choices"][0]
    x,y,w,h=choice["region"]
    alpha=Image.open(STAGE/art).convert("RGBA").crop((x,y,x+w,y+h)).getchannel("A")
    row=[i for i in range(w) if alpha.getpixel((i,choice["head_y"]))>=128]
    assert row
    entry=meta["actors"]["announcer"]["settle"]["left"]
    entry["frames"].insert(0,{"source":"res://"+art,"region":choice["region"],
        "anchors":{"feet":choice["feet"],"head":[round(sum(row)/len(row)),choice["head_y"]]},
        "source_scale":choice["source_scale"],"layers":[]})
    entry["frame_durations"]=[.06,.04,.10,.10,.10]
    (STAGE/asset_path).write_text(json.dumps(meta,ensure_ascii=False,indent=2)+"\\n",encoding="utf8",newline="\\n")
    manifest[art]=runner.sha(STAGE/art)
    manifest[asset_path]=runner.sha(STAGE/asset_path)
graph={"base":runner.BASE,"source_raw_sha256":manifest,"fixtures":runner.FIXTURES,
       "upstream_fixture":runner.describe(ORIGINAL),"driver":runner.describe(Path(__file__))}
runner.dump(BASE/"source-graph.json",graph)
assert all(runner.sha(STAGE/name)==digest for name,digest in manifest.items())
if not prototype:
    runner.QA=DONOR.parent
    runner.copy_imports(DONOR,STAGE,manifest)
else:
    runner.QA=PARENT
    import_base=PARENT/("candidate-stop-import-"+uuid.uuid4().hex[:10])
    import_stage=import_base/"project"
    shutil.copytree(STAGE,import_stage)
    runner.dump(import_base/"source-graph.json",graph)
    runner.launch(import_base,import_stage,manifest,"import",
                  [runner.ENGINE,"--headless","--path",import_stage,"--editor","--import","--quit"],
                  runner.environment(import_base))
    runner.collect_imports(import_base,import_stage,manifest)
    runner.copy_imports(import_base,STAGE,manifest)
runner.QA=PARENT
'''+source[end:]
source=source.replace("len(result['transition_pairs'])==4 and len(result['captures'])==8",
                      "len(result['transition_pairs'])==(4 if baseline else 5) and len(result['captures'])==(8 if baseline else 10)")
source=source.replace("source += \"\\n\"+fixture", "source += \"\\n\"+fixture.replace('+ 18000', '+ 45000')")
source=source.replace("'--resolution','1280x720'", "'--fixed-fps','30','--resolution','1280x720'")
exec(compile(source,str(here/"native_stop.py"),"exec"))
