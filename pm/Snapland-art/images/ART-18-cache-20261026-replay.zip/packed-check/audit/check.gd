extends SceneTree
const Avatar=preload("res://game/world/avatar_renderer.gd")
func _initialize() -> void:
 var folder:=OS.get_environment("SNAPLAND_SAVE_PATH").get_base_dir()
 if not folder.is_absolute_path():quit(2);return
 DirAccess.make_dir_recursive_absolute(folder)
 if FileAccess.file_exists("res://assets/characters/traveller-front-actions-v2.png") or not ResourceLoader.exists("res://assets/characters/traveller-front-actions-v2.png"):push_error("Pack is not isolated from loose PNGs");quit(1);return
 var a=Avatar.new()
 var begin:=Time.get_ticks_usec()
 if not a.garment_overlays.ready(a):push_error("Garment family rejected");quit(1);return
 var validation_usec:=Time.get_ticks_usec()-begin
 var rows: Array=JSON.parse_string(FileAccess.get_file_as_string(a.garment_overlays.MANIFEST_PATH)).frames
 var hashes: Dictionary={}
 for row in rows:
  var original: Image=a.original_garment_pose(row.action,row.direction,int(row.frame))
  var target:=original.duplicate()
  if not a.garment_overlays.apply(a,target,row.action,row.direction,int(row.frame)):push_error("Missing garment cel");quit(1);return
  hashes["%s/%s/%d"%[row.action,row.direction,int(row.frame)]]=a.head_source_signature(target)
 var stats: Dictionary={}
 if a.garment_overlays.has_method("cache_snapshot"):
  stats=a.garment_overlays.cache_snapshot()
 else:
  var bytes:=0
  for layer: Image in a.garment_overlays._layers.values():bytes+=layer.get_data().size()
  stats={"decoded_images":a.garment_overlays._layers.size(),"decoded_bytes":bytes}
 var report={"validation_usec":validation_usec,"all_cel_composition_hashes":hashes,"cache":stats}
 FileAccess.open(folder.path_join("report.json"),FileAccess.WRITE).store_string(JSON.stringify(report,"  "))
 print("PASS: all 172 garment blends measured; resident decoded cache: ",stats)
 quit()
