from pathlib import Path
import json,hashlib,shutil,os,time
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();b=r/'work/garment-memory-20261026/release-build';s=b/'project';report=json.loads((b/'build.json').read_text());binary=b/'release/Snapland.x86_64'
assert hashlib.sha256(binary.read_bytes()).hexdigest()==report['binary']['sha256']
changed=[name for name,h in report['source_sha256'].items() if hashlib.sha256((r/name).read_bytes()).hexdigest()!=h];assert set(changed)=={'game/world/avatar_renderer.gd','game/world/garment_overlay_library.gd'},changed
(b/'rejected-build.json').write_text(json.dumps(report,indent=2)+'\n');rejected=b/'rejected-source';rejected.mkdir()
for name in changed:shutil.copy2(s/name,rejected/Path(name).name);shutil.copy2(r/name,s/name)
(b/'rejected-reason.txt').write_text('Superseded before acceptance: real missing/changed-resource negatives showed final AvatarRenderer textures bypassing the invalidated garment family. The final release includes the validated-family cache state guard. Original rejection log/source hashes retained.\n')
binary.unlink();release=b/'release-final';release.mkdir();binary=release/'Snapland.x86_64';steps=[];engine=r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'
for label,args in [('final-import',['--editor','--import','--quit']),('final-export',['--editor','--export-release','Linux Desktop',str(binary),'--quit'])]:
 t=time.monotonic();p=run_validated_godot(s,[str(engine),'--headless','--path',str(s),*args],dict(os.environ,SNAPLAND_SAVE_PATH=str(b/'final-build-profile/progress.json')),300);log=p.stdout+p.stderr;(b/(label+'.log')).write_text(log);info=dict(step=label,exit=p.returncode,errors=log.count('ERROR:'),seconds=round(time.monotonic()-t,2));steps.append(info);print(info,flush=True);assert p.returncode==0 and info['errors']==0
assert binary.read_bytes()[:4]==b'\x7fELF';binary.chmod(binary.stat().st_mode|0o111)
for name in report['source_sha256']:report['source_sha256'][name]=hashlib.sha256((r/name).read_bytes()).hexdigest()
report.update(steps=steps,binary=dict(file='release-final/Snapland.x86_64',bytes=binary.stat().st_size,sha256=hashlib.sha256(binary.read_bytes()).hexdigest()),source_note='source_commit is the preceding base; source_sha256 records actual final runtime bytes. Supersedes rejected-build.json.')
(b/'build.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS final build',report['binary'],flush=True)
