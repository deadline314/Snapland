from pathlib import Path
import shutil,os,json,time,sys
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();s=r/'work/tutorial-current-20261020/validation-project';name='work/garment-memory-20261026/measure.gd';(s/name).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/name,s/name)
for name in ['game/world/garment_overlay_library.gd']:
 shutil.copy2(r/name,s/name)
out=r/'work/garment-memory-20261026'/sys.argv[1];out.mkdir(exist_ok=False);t=time.monotonic()
p=run_validated_godot(s,[str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'),'--headless','--path',str(s),'--script','res://work/garment-memory-20261026/measure.gd'],dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'profile/progress.json')),90)
log=p.stdout+p.stderr;(out/'result.log').write_text(log);info=dict(exit=p.returncode,errors=log.count('ERROR:'),seconds=round(time.monotonic()-t,2));(out/'result.json').write_text(json.dumps(info,indent=2)+'\n');print(info,log[-1200:]);assert p.returncode==0 and info['errors']==0
