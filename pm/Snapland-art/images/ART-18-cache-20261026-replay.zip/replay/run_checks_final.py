from pathlib import Path
import ast,os,shutil,time,json
from tools.godot_entrypoints import run_validated_godot
from tools.run_game_tests import result_error
r=Path.cwd();s=r/'work/tutorial-current-20261020/validation-project';engine=str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64')
for name in ['game/world/avatar_renderer.gd','game/world/garment_overlay_library.gd','game/tests/test_garment_cache.gd','game/tests/test_garment_overlay.gd']:shutil.copy2(r/name,s/name)
common=[engine,'--headless','--path',str(s),'--audio-driver','Dummy','--rendering-method','gl_compatibility'];tree=ast.parse((r/'tools/run_game_tests.py').read_text());n=next(n for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='checks' for t in n.targets));checks=eval(compile(ast.Expression(n.value),'<official>','eval'),{'common':common,'executable':engine,'ROOT':s,'str':str});names={'garment overlay tests','garment cache tests','wardrobe runtime tests','wardrobe UI tests','outfit atomic coverage tests','island hair binding tests','island hair lifecycle tests','island hair sources tests'};result=[]
base=r/'work/garment-memory-20261026/checks-final-v2';base.mkdir(exist_ok=False)
for name,cmd in checks:
 if name not in names:continue
 out=base/name.replace(' ','-');out.mkdir();t=time.monotonic();p=run_validated_godot(s,cmd,dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'profile/progress.json')),90);log=p.stdout+p.stderr;(out/'result.log').write_text(log);d=dict(name=name,exit=p.returncode,errors=log.count('ERROR:'),error=result_error(name,p),seconds=round(time.monotonic()-t,2));result.append(d);(base/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(d,flush=True)
 if d['error']:raise SystemExit(1)
print('completed official checks',len(result))
