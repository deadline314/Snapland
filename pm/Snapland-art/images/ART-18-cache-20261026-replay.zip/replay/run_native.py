from pathlib import Path
import os,time,json
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();s=r/'work/tutorial-current-20261020/validation-project';out=r/'work/garment-memory-20261026/native-result';out.mkdir(exist_ok=False);t=time.monotonic()
p=run_validated_godot(s,[str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'),'--path',str(s),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--resolution','1280x720','res://work/garment-memory-20261026/native/entry.tscn'],dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'profile/progress.json')),300);log=p.stdout+p.stderr;(out/'result.log').write_text(log);result=dict(exit=p.returncode,errors=log.count('ERROR:'),seconds=round(time.monotonic()-t,2));(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(result,log[-1500:]);assert p.returncode==0 and result['errors']==0 and 'PASS: native free rainvest' in log
