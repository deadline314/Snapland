from pathlib import Path
import json,shutil,hashlib,zipfile,subprocess
r=Path.cwd();b=r/'work/garment-memory-20261026';dest=r/'pm/Snapland-art/images';prefix='ART-18-cache-20261026';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for label,folder in [('native','native-result-final'),('release','release-smoke')]:
 for index in range(1,4):shutil.copy2(b/folder/f'contact-{index}.png',dest/f'{prefix}-{label}-{index}.png')
shutil.copy2(b/'native-result-final/profile/01-fitting.png',dest/f'{prefix}-fitting.png')
for name,folder in [('native','native-result-final'),('release','release-smoke')]:
 with zipfile.ZipFile(dest/f'{prefix}-{name}.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted((b/folder).rglob('*')):
   if p.is_file():z.write(p,p.relative_to(b/folder))
with zipfile.ZipFile(dest/f'{prefix}-replay.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for folder in ['before','after','cache','integration','checks-final','checks-final-v2','checks-additional','checks-additional-final','cache-final-v3','renderer-cache-negative','packed-check']:
  for p in sorted((b/folder).rglob('*')):
   if p.is_file():z.write(p,p.relative_to(b))
 for p in sorted(b.glob('*.py')):z.write(p,'replay/'+p.name)
 z.write(b/'measure.gd','replay/measure.gd')
 for p in sorted((b/'native').iterdir()):z.write(p,'replay/native/'+p.name)
 for name in ['game/world/avatar_renderer.gd','game/world/garment_overlay_library.gd','game/tests/test_garment_cache.gd','game/tests/test_garment_overlay.gd','tools/run_game_tests.py']:z.write(r/name,'final-source/'+name)
 z.writestr('baseline-source/garment_overlay_library.gd',subprocess.check_output(['git','show','39dea6d:game/world/garment_overlay_library.gd']))
 for name in ['build.json','rejected-build.json','rejected-reason.txt','import.log','export.log','final-import.log','final-export.log']:
  z.write(b/'release-build'/name,'release-build/'+name)
 for p in sorted((b/'release-build/rejected-source').iterdir()):z.write(p,'release-build/rejected-source/'+p.name)
 z.write(b/'python.log','python.log')
 z.write(b/'obsolete-binary-cleanup.json','obsolete-binary-cleanup.json')
checks=json.loads((b/'checks-final-v2/results.json').read_text())+json.loads((b/'checks-additional-final/results.json').read_text());assert len(checks)==10 and all(x['error'] is None for x in checks)
before=json.loads((b/'before/profile/report.json').read_text());after=json.loads((b/'packed-check/profile/report.json').read_text());assert before['all_cel_composition_hashes']==after['all_cel_composition_hashes']
summary={'date':'2026-10-26 Asia/Taipei','baseline':'39dea6d6a00b0e88b43ba1fea0d0adf1f62d0d48','scope':'Garment decoded-image steady cache only, not total RSS/VRAM, hardware FPS, new character animation or human hearing.','before':before,'final_packed':after,'reduction_percent':100*(1-after['cache']['decoded_bytes']/before['cache']['decoded_bytes']),'official_affected_checks':checks,'last_cache_replay':json.loads((b/'cache-final-v3/result.json').read_text()),'python':{'passed':161,'seconds':39.009},'native':json.loads((b/'native-result-final/result.json').read_text()),'release':json.loads((b/'release-smoke/result.json').read_text()),'final_binary':json.loads((b/'release-build/build.json').read_text())['binary'],'source_sha256':{name:sha(r/name) for name in ['game/world/avatar_renderer.gd','game/world/garment_overlay_library.gd','game/tests/test_garment_cache.gd','tools/run_game_tests.py']},'negative':{'renderer_cache':json.loads((b/'renderer-cache-negative/result.json').read_text()),'driver_timeout':'Additional diagnostic driver first used90s for avatar test incorrectly; original official240s was restored,160.88s0ERROR. Failed-driver stdout was not persisted; explicit record retained.'},'viewed':'All12 native captures in3contact sheets plus original1280fitting image; all12 finalELF entry initial-draw captures in3contact sheets. No new animation movie or listening claim.','artifact_sha256':{p.name:sha(p) for p in sorted(dest.glob(prefix+'-*'))}}
(dest/f'{prefix}-review.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
p=r/'pm/Snapland-art/[ART-18]同步換裝分層與角色動畫.md';s=p.read_text()+'''

# Commit — 2026-10-26 降低衣料常駐記憶體並修正回退

## 內文

同一套長背心原本常駐保存 172 張完整解碼圖。現在仍先驗證整套來源與覆蓋，再只持有近期使用的衣料：衣料畫布快取從 66.14 MiB 降至 4.61 MiB，減少 93.02%。全部 172 格合成像素與原版一致，免費試穿／穿戴、原外套、降低動態與保存重載維持正常。

實際刪除與改動已驗證的隔離衣料後，另發現角色可能繼續顯示舊穿衣貼圖。兩次反例均已保存並修正：衣物整套拒收後，已暖過的最終畫面也回到完整原人物，不由舊快取繞過。錯誤中會保留具體格次，且不反覆讀取壞檔。這是素材持有與回退的交付，不把記憶體改善當作尚未完成的全角色動作或換髮驗收。

### 測試結果

| 項目 | 結果 |
|---|---|
| 舊版／新版全套合成 | 172／172 RGBA 指紋相同 |
| 淘汰／回載及暖快取 | 344 次獨立像素比較、512 次暖命中；暖命中不增加解碼 |
| 真實檔案故障及最終畫面 | 刪檔／一位元組改動均拒收整套，原反例兩次失敗後通過；巨大 PNG 尺寸宣告在解碼前拒收 |
| 受影響正式原生程式檢查 | 10 組通過、0 ERROR；含完整角色外觀、衣料、髮型與衣櫃回歸 |
| Python | 161／161，39.009 秒 |
| 正式衣櫃輸入流程 | 33.54 秒、exit 0、0 ERROR；試穿／穿戴、八組移動輸入、降低動態、還原外套及保存重載，12 張畫面實際查看 |
| 最終成品內資源 | 隔離目錄讀取嵌入 PCK，172 格合成與原版相同，最多 12 格常駐；3.33 秒、0 ERROR |
| 真正 Linux 成品 | 新來源逐檔雜湊一致；冷啟動、十二入口初始繪製與退出 28.08 秒、0 ERROR；保留已保存雨衣、降低動態及金幣 |

外觀回歸的診斷驅動器首輪誤設 90 秒而逾時，未記作成功；使用既有官方 240 秒上限重跑，160.88 秒通過，沒有放寬正式測試。首份缺少最終貼圖回退修正的輸出也已拒收，附原來源與原因。快取數字只計衣料解碼畫布，不代表程序總記憶體、VRAM 或硬體 FPS；成品檢查不等於完整玩法／全套動畫或真人試聽。

[官方資料、責任與可重播流程](../../design/runtime/outfit-resource-cache.md)；[數值、來源與雜湊](images/ART-18-cache-20261026-review.json)；[正反例、原始 log 與程序](images/ART-18-cache-20261026-replay.zip)；[12 張正式衣櫃流程原圖](images/ART-18-cache-20261026-native.zip)；[12 張最終成品入口原圖與執行紀錄](images/ART-18-cache-20261026-release.zip)。

![正式試衣與完整人物](images/ART-18-cache-20261026-fitting.png)
![正式穿戴及移動一](images/ART-18-cache-20261026-native-1.png)
![正式穿戴及移動二](images/ART-18-cache-20261026-native-2.png)
![降低動態與保存重載](images/ART-18-cache-20261026-native-3.png)
![最終成品入口一](images/ART-18-cache-20261026-release-1.png)
![最終成品入口二](images/ART-18-cache-20261026-release-2.png)
![最終成品入口三](images/ART-18-cache-20261026-release-3.png)
''';p.write_text(s)
p=r/'pm/open_tickets.md';s=p.read_text().replace('2026-10-24（Asia/Taipei）。','2026-10-26（Asia/Taipei）。',1).replace('其他驗收仍依原票。','其他驗收仍依原票。2026-10-26 已再降低衣料快取常駐量並修正失效後舊貼圖繞過回退，整套角色動畫／換裝驗收維持未勾。',1);p.write_text(s)
print('artifact total bytes',sum(p.stat().st_size for p in dest.glob(prefix+'-*')))
