import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(root))
from tools.build_desktop_release import prepare_runtime_stage
from tools.godot_entrypoints import run_validated_godot

out = root / 'build/Snapland-preview-20261111'
if out.exists():
    raise RuntimeError('Preview destination must be new')
out.mkdir(parents=True)
stage = out / 'project'
stage.mkdir()
tracked = subprocess.check_output(['git','ls-files','-z'], cwd=root, text=True, encoding='utf-8').split('\0')
sources = prepare_runtime_stage(root, stage, tracked)
engine = r'C:\Tools\Godot\Godot_v4.7.2-stable_win64_console.exe'
env = dict(os.environ, SNAPLAND_SAVE_PATH=str(out/'qa-profile/progress.json'))
binary = out/'Snapland.exe'
steps=[]
for label, args, timeout in [
    ('import', ['--editor','--import','--quit'], 240),
    ('export', ['--editor','--export-release','Windows Desktop',str(binary),'--quit'], 240)]:
    start = time.monotonic()
    result = run_validated_godot(stage, [engine,'--headless','--path',str(stage),'--rendering-method','gl_compatibility',*args], env, timeout)
    log = result.stdout + result.stderr
    (out/(label+'.log')).write_text(log, encoding='utf-8')
    steps.append({'label':label,'exit':result.returncode,'errors':log.count('ERROR:'),'seconds':time.monotonic()-start})
    if result.returncode or 'ERROR:' in log:
        raise RuntimeError(label + ' failed, see log')
if not binary.is_file() or binary.read_bytes()[:2] != b'MZ':
    raise RuntimeError('Windows executable missing')
result=subprocess.run([str(binary),'--headless','--rendering-method','gl_compatibility','--audio-driver','Dummy','--','--smoke-test'],env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=120)
log=result.stdout+result.stderr
(out/'startup.log').write_text(log,encoding='utf-8')
if result.returncode or 'ERROR:' in log or 'PASS' not in log:
    raise RuntimeError('Windows embedded startup failed, see log')
report={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'source_sha256':sources,'steps':steps,'startup':{'exit':result.returncode,'errors':log.count('ERROR:')},'binary':{'file':str(binary),'bytes':binary.stat().st_size,'sha256':hashlib.sha256(binary.read_bytes()).hexdigest()},'scope':'Windows embedded PCK export and isolated headless startup; native visual QA remains separately documented.'}
(out/'build.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('PASS: Windows preview export and embedded startup', binary)
