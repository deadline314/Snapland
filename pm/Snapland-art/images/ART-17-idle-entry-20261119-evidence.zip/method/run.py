"""Capture fresh isolated development runs for the avatar idle clock."""
import importlib.util
from pathlib import Path
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
helper = ROOT / ".review/cotton-wind-20261118/final-fix/native_run.py"
spec = importlib.util.spec_from_file_location("sandboxed_godot", helper)
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
runner.QA = Path("D:/Snapland-QA/art17-idle-20261119")
DONOR = Path("D:/Snapland-QA/art16-20261119/art16-donor-1119-051411-cde323")
TEST = "test_avatar_side_idle"
FIXTURE = "native_avatar_side_idle"
NATIVE_CLOSURE = [
    "game/tests/" + name
    for name in (FIXTURE+".gd",FIXTURE+".tscn","native_island_animation_acceptance.gd")
]

launch_godot = runner.run_validated_godot
def native_options_first(stage, command, *args, **kwargs):
    if "--" in command and command[-2]=="--log-file":
        index=command.index("--")
        command[index:index]=command[-2:]
        del command[-2:]
    return launch_godot(stage,command,*args,**kwargs)
runner.run_validated_godot=native_options_first

paths = subprocess.check_output(["git","ls-files","-z"],cwd=ROOT,encoding="utf8").split("\0")

def stage(label, fixtures):
    base=runner.make_base(label)
    path=base/"project"
    path.mkdir()
    graph=runner.prepare_runtime_stage(ROOT,path,paths)
    for name in fixtures:
        path.joinpath(name).parent.mkdir(exist_ok=True,parents=True)
        shutil.copy2(ROOT/name,path/name)
        graph[name]=runner.sha(path/name)
    runner.dump(base/"source-graph.json",{
        "commit_base":runner.BASE, "source_raw_sha256":graph, "fixtures":fixtures,
        "driver":runner.describe(Path(__file__)),
    })
    assert all(runner.sha(ROOT/name)==runner.sha(path/name)==sha for name,sha in graph.items())
    runner.QA=DONOR.parent
    runner.copy_imports(DONOR,path,graph)
    runner.QA=base.parent
    runner.FIXTURES=fixtures
    return base,path,graph

def headless(name, red=False):
    base,path,graph=stage(("red-" if red else "headless-")+name,["game/tests/"+name+".gd"])
    if name=="test_avatar_authored_walk_loop":
        for filename in ("manifest.json","front-right-03-before-runtime.png"):
            relative="tools/walk_stability/repairs/"+filename
            target=path/relative
            target.parent.mkdir(exist_ok=True,parents=True)
            shutil.copy2(ROOT/relative,target)
            graph[relative]=runner.sha(target)
        runner.dump(base/"supplemental-data.json",{p:sha for p,sha in graph.items() if p.startswith("tools/walk_stability/repairs/")})
    command=[runner.ENGINE,"--headless","--path",path,"--script","res://game/tests/"+name+".gd"]
    try:
        receipt=runner.launch(base,path,graph,name,command,runner.environment(base))
    except RuntimeError:
        if not red:
            raise
        receipt=runner.read(base/"receipt.json")
        expected = "enters the authored neutral pose after walking"
        assert red and receipt["exit_code"]==1 and not receipt["leak_diagnostics"]
        assert len(receipt["errors"])==8 and all(expected in msg for msg in receipt["errors"])
        print("Confirmed failure across eight headings",base.as_posix(),flush=True)
        return
    assert not red,"Expected old code to fail"
    if name==TEST:
        marker="PASS: dedicated stable idle timing, source diagnostics, and reduced-motion stance"
        assert marker in (base/"engine.log").read_text("utf8").splitlines()
        assert marker in (base/"stdout.log").read_text("utf8").splitlines()
    elif name=="test_avatar_authored_walk_loop":
        marker="PASS: real world avatar presents authored eight-direction walk cels, natural stance holds, and allocates no unused hero rig"
        assert (base/"engine.log").read_text("utf8").splitlines().count(marker)==1
    print(base.as_posix(),flush=True)

def native(mode,directions,binary=None,pinned=None):
    base,path,graph=stage("native-"+mode,NATIVE_CLOSURE)
    options=["--quarter","--rebuild"] if mode=="quarter" else []
    command=[runner.ENGINE,"--path",path,"res://game/tests/"+FIXTURE+".tscn"]
    if binary is not None:
        runner.qa_override(path,pinned)
        build=runner.read(binary.parent.parent/"build.json")
        assert runner.sha(binary)==build["binary"]["sha256"]
        assert all(runner.sha(path/name)==digest for name,digest in build["runtime_sha256"].items())
        command=[binary]
    command += ["--rendering-method","gl_compatibility","--audio-driver","Dummy",
             "--fixed-fps","30","--write-movie",base/"capture.avi","--",
             "--actor=traveller","--actions-only","--animation-output="+(base/"captures").as_posix(),
             "--idle-directions="+directions,"--default-look-only",*options]
    runner.launch(base,path,graph,mode,command,runner.environment(base),binary.parent if binary else None)
    data=runner.read(base/"captures/traveller-report.json")
    assert data["technical_status"]=="PASS" and not data["failures"]
    assert data["playback_mode"].startswith("quarter" if mode=="quarter" else "normal")
    entrances=[action for action in data["actions"] if action["label"].startswith("first-neutral")]
    assert len(entrances)==len(directions.split(",")) and all(
        action["predicate"] and action["detail"]["frame"]==0 for action in entrances)
    assert any(action["detail"]["old_absolute_frame"]>0 for action in entrances)
    print(base.as_posix(),flush=True)
    return base

def package(directions):
    base,path,graph=stage("package-export",NATIVE_CLOSURE)
    pinned=runner.templates(base)
    runner.SCENE="game/tests/"+FIXTURE+".tscn"
    runner.qa_override(path,pinned)
    release=base/"release"
    release.mkdir()
    binary=release/"AvatarIdleQA.exe"
    runner.launch(base,path,graph,"export",
                  [runner.ENGINE,"--headless","--path",path,"--editor","--export-release","Windows Desktop",binary,"--quit"],
                  runner.environment(base))
    assert binary.stat().st_size>pinned["release"]["bytes"] and not list(release.glob("*.pck"))
    runner.dump(base/"build.json",{"binary":runner.describe(binary),"templates":pinned,
                "runtime_sha256":runner.read(base/"runtime-graph.json")})
    run=native("embedded",directions,binary,pinned)
    runner.dump(base/"embedded-acceptance.json",{"build":runner.describe(base/"build.json"),"launch":runner.describe(run/"receipt.json")})

if __name__=="__main__":
    if sys.argv[1]=="red":
        headless(TEST,True)
    elif sys.argv[1]=="headless":
        headless(sys.argv[2] if len(sys.argv)>2 else TEST)
    elif sys.argv[1]=="package":
        package(sys.argv[2])
    else:
        native(sys.argv[1],sys.argv[2])
