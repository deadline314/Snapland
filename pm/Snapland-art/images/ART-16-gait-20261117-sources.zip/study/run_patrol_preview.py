from pathlib import Path
import os,sys,json
from tools.godot_entrypoints import run_validated_godot

ROOT = Path.cwd()
OUT = ROOT / '.review/animation-source-20261117'
targets = [ROOT / name for name in ['assets/characters/complete-animation-regions.json', 'game/world/npc_activity.gd', 'game/tests/native_authored_patrol_review.gd']]
originals = {path: path.read_bytes() for path in targets}
quarter = '--quarter' in sys.argv
root_registered = '--root' in sys.argv
destination = OUT / (('root-' if root_registered else '') + ('main-preview-quarter' if quarter else 'main-preview-normal'))
assert not destination.exists()
destination.mkdir()
for path, data in originals.items():
    (OUT / ('before-preview-' + path.name)).write_bytes(data)
try:
    targets[0].write_bytes((OUT / ('native-root-patrol-preview-manifest.json' if root_registered else 'native-patrol-preview-manifest.json')).read_bytes())
    text = targets[1].read_text(encoding='utf-8')
    assert '"speed":0.6,"stride":0.36' in text
    targets[1].write_text(text.replace('"speed":0.6,"stride":0.36', '"speed":0.6,"stride":1.2'), encoding='utf-8')
    text = targets[2].read_text(encoding='utf-8')
    text = text.replace('seen.right.size() == 4 and seen.left.size() == 4', 'seen.right.size() == 8 and seen.left.size() == 8')
    # Only bare walk coverage is changed; settle/depart remain four source cels.
    text = text.replace('settle_seen.right.size() == 8 and settle_seen.left.size() == 8', 'settle_seen.right.size() == 4 and settle_seen.left.size() == 4')
    targets[2].write_text(text, encoding='utf-8')
    env = os.environ.copy()
    env['SNAPLAND_SAVE_PATH'] = str(destination / 'isolated-save.json')
    command = [r'C:\Tools\Godot\Godot_v4.7.2-stable_win64_console.exe', '--path', str(ROOT), '--rendering-method', 'gl_compatibility', '--audio-driver', 'Dummy', '--fixed-fps', '30', '--write-movie', str(destination/'preview.avi'), 'res://game/tests/native_announcer_patrol_review.tscn', '--quit-after', '2400', '--', '--actor=announcer', '--actions-only', '--animation-output='+str(destination/'capture')]
    if quarter:
        command[command.index('--quit-after')+1]='8000'
        command += ['--quarter','--rebuild']
    result = run_validated_godot(ROOT, command, env=env, timeout=220 if quarter else 110)
    log = result.stdout + result.stderr
    (destination/'native.log').write_text(log,encoding='utf-8')
    print(result.returncode, log[-2500:])
    assert result.returncode == 0 and 'ERROR:' not in log
    report=json.loads((destination/'capture/announcer-report.json').read_text(encoding='utf-8'))
    assert report['technical_status']=='PASS' and report['status']=='OBSERVATIONS_COMPLETE_VISUAL_PENDING'
    print('Observed all16 source cels and both departures/stops; visual acceptance remains pending')
finally:
    for path, data in originals.items():
        path.write_bytes(data)
