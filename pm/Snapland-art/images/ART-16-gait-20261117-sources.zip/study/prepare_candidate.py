from pathlib import Path
import argparse, json, shutil
from PIL import Image
import numpy as np
import cv2

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent

def gray(pixels):
    alpha = pixels[:, :, 3:4] / 255
    rgb = pixels[:, :, :3] * alpha + (1-alpha)*215
    return cv2.cvtColor(rgb.astype('uint8'), cv2.COLOR_RGB2GRAY)

def main():
    p=argparse.ArgumentParser()
    p.add_argument('source', type=Path)
    p.add_argument('tag')
    p.add_argument('--view',choices=['left','right'],default='right')
    p.add_argument('--manual-review',action='store_true')
    args=p.parse_args()
    dst=OUT/(args.tag+'.png')
    shutil.copy2(args.source,dst)
    pixels=np.array(Image.open(dst).convert('RGBA'))
    h,w=pixels.shape[:2]
    assert (w,h)==(1774,887)
    template=gray(pixels[:round(h/2),:round(w/4)])[20:180,155:340]
    manifest=json.loads((ROOT/'assets/characters/complete-animation-regions.json').read_text(encoding='utf-8'))
    cells=[]
    for i in range(8):
        x0=round((i%4)*w/4);x1=round((i%4+1)*w/4)
        y0=round((i//4)*h/2);y1=round((i//4+1)*h/2)
        tile=pixels[y0:y1,x0:x1]
        yy,xx=np.where(tile[:,:,3]>128)
        assert len(xx)>1000
        result=cv2.matchTemplate(gray(tile)[:220],template,cv2.TM_CCOEFF_NORMED)
        _,score,_,location=cv2.minMaxLoc(result)
        assert score>(.8 if args.manual_review else .9),(i,score)
        cells.append((x0,y0,tile,[int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)],location,score))
    grounds=[max(cells[i][3][3] for i in range(row*4,row*4+4)) for row in range(2)]
    frames=[];records=[]
    for i,(x0,y0,tile,b,location,score) in enumerate(cells):
        dx,dy=location[0]-155,location[1]-20
        root_x=(252 if args.view=='left' else 213)+dx
        left=max(0,b[0]-2);top=max(0,b[1]-2)
        right=min(tile.shape[1],b[2]+2);bottom=min(tile.shape[0],grounds[i//4]+2)
        frames.append({'source':str(dst),'region':[x0+left,y0+top,right-left,bottom-top],
            'anchors':{'feet':[root_x-left,grounds[i//4]-top],'head':[(225 if args.view=='left' else 249)+dx-left,18+dy-top]},
            'source_scale':.39,'head_neck_seam_y':290,'layers':[]})
        records.append({'phase':i+1,'registered_root_x':root_x,'row_ground':grounds[i//4],
            'strong_bounds':b,'head_template_translation':[dx,dy],'score':score})
    manifest['actors']['announcer']['walk'][args.view]={'fps':13.3333333333,'loop':True,'frames':frames}
    (OUT/(args.tag+'-manifest.json')).write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    (OUT/(args.tag+'-registration.json')).write_text(json.dumps(records,indent=2),encoding='utf-8')
    print(json.dumps({'grounds':grounds,'poses':records}))

if __name__=='__main__':main()
