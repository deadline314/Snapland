"""Verify the right landed cel in isolated Main and embedded Windows runs."""
from pathlib import Path

master = Path("C:/Users/stanl/Github/Snapland")
here = Path(__file__).resolve().parent
template = master / ".review/art16-20261119/verify_departure.py"
source = template.read_text("utf8")
source = source.replace("ROOT = HERE.parents[1]","ROOT = HERE / 'worktree'")
source = source.replace('helper = ROOT / ".review/cotton-wind-20261118/final-fix/native_run.py"',
    'helper = Path("C:/Users/stanl/Github/Snapland/.review/cotton-wind-20261118/final-fix/native_run.py")')
source = source.replace("spec.loader.exec_module(runner)", '''
runner_source = helper.read_text("utf8")
runner_source = runner_source.replace('ROOT = HERE.parents[2]', f'ROOT = Path({str(ROOT)!r})')
runner_source = runner_source.replace('donor.drive.upper() == "D:"', 'donor.drive == stage.drive')
runner_source = runner_source.replace('Path(keys[key]).drive.upper() == "D:"', 'Path(keys[key]).drive == base.drive')
exec(compile(runner_source, str(helper), "exec"), runner.__dict__)
''')
source = source.replace('Path("D:/Snapland-QA/art16-20261119")','HERE / "native"')
source = source.replace("announcer-departure-sides-v1.png","announcer-stop-landing-right-v1.png")
source = source.replace("AnnouncerDepartureQA.exe","AnnouncerRightLandingQA.exe")
source = source.replace('        assert detail["maximum_departure_root_drift"]','''
        assert set(map(int,detail["settle_seen"]["right"])) == set(range(5))
        assert set(map(int,detail["settle_seen"]["left"])) == set(range(5))
        assert detail["maximum_departure_root_drift"]''')
exec(compile(source,str(here/"verify.py"),"exec"))
