"""Capture adjacent real right-stop frames while the NPC keeps its original route."""
from pathlib import Path

master = Path("C:/Users/stanl/Github/Snapland")
here = Path(__file__).resolve().parent
template = master/".review/art16-20261119/seams_native.py"
source = template.read_text("utf8")
source = source.replace("ROOT = HERE.parents[1]","ROOT = HERE / 'worktree'")
source = source.replace("HELPER = ROOT / '.review/cotton-wind-20261118/final-fix/native_run.py'",
    "HELPER = Path(r'C:/Users/stanl/Github/Snapland/.review/cotton-wind-20261118/final-fix/native_run.py')")
source = source.replace("spec.loader.exec_module(runner)", '''
runner_source = HELPER.read_text("utf8")
runner_source = runner_source.replace('ROOT = HERE.parents[2]', f'ROOT = Path({str(ROOT)!r})')
runner_source = runner_source.replace('donor.drive.upper() == "D:"', 'donor.drive == stage.drive')
runner_source = runner_source.replace('Path(keys[key]).drive.upper() == "D:"', 'Path(keys[key]).drive == base.drive')
exec(compile(runner_source, str(HELPER), "exec"), runner.__dict__)
''')
source = source.replace("DONOR = Path('D:/Snapland-QA/cotton-wind/final-fix/donor-1119-043400-30b24a')","DONOR = Path(sys.argv[1]).resolve()")
source = source.replace("import subprocess","import subprocess\nimport sys")
source = source.replace("PARENT = Path('D:/Snapland-QA/art16-20261119')","PARENT = HERE / 'native'")
source = source.replace("paths = [p for p in paths if not p.endswith(('.uid','.import'))]","paths.append('assets/characters/announcer-stop-landing-right-v1.png')")
start = source.index("source += ")
end = source.index("\n", start)
source = source[:start] + r'''
fixture = Path(r"C:/Users/stanl/Github/Snapland/.review/art16-20261119/seams_fixture.gd.txt").read_text("utf8")
fixture = fixture.replace('\t\tif identity == previous.get("identity", ""):\n\t\t\tcontinue\n', '')
fixture = fixture.replace("18000","45000").replace("seen.size() < 4","seen.size() < 5").replace("seen.size() != 4","seen.size() != 5")
fixture = fixture.replace('var sample := {', """if side=="right" and action=="settle" and pose==1 and previous.get("action","")=="settle" and previous.get("frame",-1)==0:
			transition = "settle-weight-transfer-right"
		var sample := {""")
fixture = fixture.replace('or transition.begins_with("walk-to-settle-")','or transition.begins_with("walk-to-settle-") or transition == "settle-weight-transfer-right"')
source += "\n"+fixture
''' + source[end:]
source = source.replace("runner.copy_imports(DONOR,STAGE,manifest)","runner.QA=PARENT\nrunner.copy_imports(DONOR,STAGE,manifest)")
source = source.replace("'--resolution','1280x720'","'--fixed-fps','30','--resolution','1280x720'")
source = source.replace("len(result['transition_pairs'])==4 and len(result['captures'])==8",
    "len(result['transition_pairs'])==5 and len(result['captures'])==10")
exec(compile(source,str(here/"seam.py"),"exec"))
