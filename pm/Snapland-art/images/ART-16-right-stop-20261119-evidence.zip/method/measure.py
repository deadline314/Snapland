from pathlib import Path
import hashlib,json,numpy as np
from PIL import Image
from scipy.ndimage import label
base=Path("E:/Snapland-QA/art16-right-stop-20261119")
old=Path.cwd()/".review/art16-20261119/contact_study.py"
ns={"__file__":str(old)}
exec(compile(old.read_text("utf8").split("\nreport={}")[0],str(old),"exec"),ns)
d=ns["ACTOR"]["settle"]["right"]["frames"][0]
standing=ns["canvas"](ns["cropped"](d),d["source_scale"]*2,*d["anchors"]["feet"])
sheet=Image.open(ns["ASSETS"]/"walk-stability-v1/announcer-walk-right.png").convert("RGBA")
walks=[np.array(sheet.crop((n*320,0,(n+1)*320,460))) for n in range(4)]
distance=ns["distance"]
direct=[distance(walk,standing) for walk in walks]
baseline=np.max(direct,axis=0)
source=Path("C:/Users/stanl/.codex/generated_images/01a1e5dd-6423-7963-9dc5-b040851d2b6b/exec-3949b809-d015-4b5c-8d87-f9e687e8d2bd.png")
img=Image.open(source).convert("RGBA")
assert img.width % 3 == 0
width=img.width//3
candidates=[]
for n in range(3):
    x=n*width
    raw=img.crop((x,0,x+width,img.height))
    strong=raw.getchannel("A").point(lambda a:255 if a>=128 else 0).getbbox()
    weak=raw.getchannel("A").point(lambda a:255 if a>=8 else 0).getbbox()
    print(n,img.size,strong,weak)
    left,top,right,bottom=weak
    part=raw.crop((left-5,top-5,right+5,bottom+5))
    sole=strong[3]-top+5
    height=strong[3]-strong[1]
    assert label(np.asarray(part.getchannel("A"))>=128)[1] == 1
    for target_height in range(298,323,2):
        scale=target_height/height
        for foot in range(115,236,2):
            cel=ns["canvas"](part,scale,foot,sole)
            on_walk=[distance(frame,cel) for frame in walks]
            on_stand=distance(cel,standing)
            severe=np.maximum(np.max(on_walk,axis=0),on_stand)
            actual=np.maximum(on_walk[2],on_stand)
            qualifies=bool((severe<=baseline).all() and (actual<=direct[2]).all())
            rank=float(np.dot(severe+actual,[2,1,1,1]))
            if qualifies:
                candidate={"candidate":n,"source_scale":scale/2,"region":[x+left-5,top-5,part.width,part.height],"feet":[foot,sole],"head_y":strong[1]-top+5,"incoming":on_walk,"into_standing":on_stand,"actual":actual.tolist(),"max_by_area":severe.tolist(),"score":rank}
                candidates.append((rank,candidate,cel))
candidates.sort(key=lambda x:x[0])
report={"source":source.as_posix(),"source_sha256":hashlib.sha256(source.read_bytes()).hexdigest(),"original_size":img.size,"direct":direct,"max_baseline":baseline.tolist(),"candidates":len(candidates),"best":[row[1] for row in candidates[:8]]}
(base/"study-01.json").write_text(json.dumps(report,indent=2),encoding="utf8")
for i,(_,row,frame) in enumerate(candidates[:8]):
    Image.fromarray(frame).save(base/f"study-01-accepted-{i}.png")
print(json.dumps(report,ensure_ascii=False)[:2100])
