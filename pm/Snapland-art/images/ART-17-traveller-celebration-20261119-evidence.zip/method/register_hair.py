from pathlib import Path
import hashlib
import json

root=Path("assets/characters")
qa=Path(__file__).resolve().parent
candidate=qa/"hair-review-1119-112511-4e56e7"
assert json.loads((candidate/"receipt.json").read_text())["passed"]
owners=json.loads((candidate/"captures/hair-review.json").read_text())["owners"]
registered=json.loads((qa/"register-candidate-1119-111047-c51def/captures/registration.json").read_text())
assert set(owners)=={registered[str(index)]["source"] for index in range(4)}
props=json.loads((root/"avatar-prop-foreground-v1.json").read_text())["owners"]
for key,row in owners.items():
    # Keep the raised fist and camera out of the head's immutable cut.
    preserved={}
    for y,x0,x1 in props[key]["spans"]:
        preserved.setdefault(y,set()).update(range(x0,x1))
    clean=[]
    for y,x0,x1 in row["hair_owner_spans"]:
        remainder=[x for x in range(x0,x1) if x not in preserved.get(y,())]
        for x in remainder:
            if clean and clean[-1][0]==y and clean[-1][2]==x:
                clean[-1][2]=x+1
            else:
                clean.append([y,x,x+1])
    row["hair_owner_spans"]=clean
    assert len(clean)>200
    row["review"]="Grounded celebration: exact registered hair silhouette excludes the raised hand and camera."
owner_path=root/"avatar-head-material-owners-v1.json"
old=owner_path.read_text("utf8")
parsed=json.loads(old)["owners"]
assert not parsed.keys() & owners.keys()
tail="\n  }\n}\n"
assert old.endswith(tail)
new=old[:-len(tail)]+",\n"+",\n".join(f'    "{key}": '+json.dumps(row,separators=(",",":")) for key,row in sorted(owners.items()))+tail
assert json.loads(new)["owners"]==parsed|owners
deps=root/"island-hair-alternate-owners-v1.json"
dependency=deps.read_text("utf8")
old_digest=hashlib.sha256(old.encode("utf8")).hexdigest()
assert dependency.count(old_digest)==1
updated=dependency.replace(old_digest,hashlib.sha256(new.encode("utf8")).hexdigest())
owner_path.write_text(new,"utf8",newline="")
deps.write_text(updated,"utf8",newline="")
(qa/"approved-celebration-hair.json").write_text(json.dumps(owners,indent=2)+"\n","utf8")
print({key:len(row["hair_owner_spans"]) for key,row in owners.items()})
