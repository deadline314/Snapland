from PIL import Image,ImageDraw
from pathlib import Path
import sys
here=Path(__file__).resolve().parent
captures=Path(sys.argv[1])/"captures"
looks=("reward-default","rainvest-bob","rainvest-curly")
sheet=Image.new("RGB",(1200,1017),"#242432")
draw=ImageDraw.Draw(sheet)
for row,label in enumerate(looks):
    y=row*339
    draw.text((12,y+7),label,fill="white")
    for index in range(5):
        frame=Image.open(captures/f"traveller-{label}-{index}.png")
        crop=frame.crop((553,233,728,499))
        crop=crop.resize((224,310))
        sheet.paste(crop,(index*240+8,y+24))
sheet.save(here/"native-celebration-review.png")
