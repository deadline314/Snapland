extends "res://game/tests/native_island_animation_acceptance.gd"

func _hero_actions() -> void:
	var point := Vector3(-3.2,0,-5.5)
	point.y = _world.ground_surface_y(point)
	_world.player.global_position=point
	await _physics_frames(4)
	var save_path := OS.get_environment("SNAPLAND_SAVE_PATH")
	_main._launch_game("game-003",false)
	await _frames(3)
	var attempt_sent := -1
	var start := _simulated_seconds
	while _main.session != null and _simulated_seconds-start < 25.0 and _within_budget():
		var attempt: int = _main.session.fountain_attempts
		if bool(_main.session.beat_window) and attempt!=attempt_sent:
			attempt_sent=attempt
			_press(KEY_SPACE,true)
			_press(KEY_SPACE,false)
		await RenderingServer.frame_post_draw
	var success: bool = _main.modal_kind=="result" and _main.celebrate_on_close and _main.session==null and attempt_sent>=0
	var awarded := FileAccess.get_file_as_bytes(save_path)
	_report["real_fountain_success"] = success and not awarded.is_empty()
	if not _report["real_fountain_success"]:
		_fail("timed native fountain inputs did not produce a saved success")
		return
	await _capture("real-fountain-result")
	_press(KEY_ESCAPE,true)
	_press(KEY_ESCAPE,false)
	var first := await _capture_cheer("reward-default",false)
	await _record_action("reward-default-cheer","celebrate","front","authored",_actor_anchor(),bool(first.complete),first)
	if not bool(first.complete): return
	var appearance: Dictionary = _world.avatar_appearance.duplicate(true)
	for style: String in ["bob","curly"]:
		appearance.hair=style
		_world.set_avatar_look(appearance,{"outfit":"outfit-rainvest","hat":"hat-straw"})
		_world.play_action("celebrate")
		var outcome := await _capture_cheer("rainvest-"+style,false)
		await _record_action("rainvest-"+style+"-cheer","celebrate","front","authored",_actor_anchor(),bool(outcome.complete),outcome)
		if not bool(outcome.complete): return
	_world.apply_settings({"reduced_motion":true})
	_world.play_action("celebrate")
	var still := await _capture_cheer("reduced-inline",true)
	await _record_action("reduced-inline-cheer","celebrate","front","authored",_actor_anchor(),bool(still.complete),still)
	_world.apply_settings({"reduced_motion":false})
	_report["reward_save_unchanged_after_cheer"] = FileAccess.get_file_as_bytes(save_path)==awarded
	if not _report["reward_save_unchanged_after_cheer"]:
		_fail("visual celebration changed saved rewards")

func _capture_cheer(label: String, reduced: bool) -> Dictionary:
	var started := _simulated_seconds
	var at_start: Vector3 = _world.player.global_position
	var seen: Array[int] = []
	var sources_match := true
	var drift := 0.0
	while _simulated_seconds-started<1.2 and _within_budget():
		await RenderingServer.frame_post_draw
		drift = maxf(drift,at_start.distance_to(_world.player.global_position))
		if _world.last_avatar_action != "celebrate":
			if not seen.is_empty(): break
			continue
		var frame: int = _world.last_avatar_frame
		var expected: Texture2D = _world.avatar_renderer.texture(_world.avatar_appearance,_world.avatar_equipped,"front",frame,"celebrate")
		sources_match = sources_match and _world.last_avatar_source_action=="celebrate" and _world.facing=="front" and _world.avatar.texture==expected
		if frame not in seen:
			seen.append(frame)
			_store_capture("%s-%d" % [label,frame],get_viewport().get_texture().get_image())
	var expected_order: Array = [0] if reduced else [0,1,2,3,4]
	var complete: bool = sources_match and seen==expected_order and drift<=0.00001 and _world.last_avatar_action=="idle" and _world.facing=="front"
	return {"complete":complete,"sources_match":sources_match,"seen":seen,"root_drift":drift,"after":_world.last_avatar_action}
