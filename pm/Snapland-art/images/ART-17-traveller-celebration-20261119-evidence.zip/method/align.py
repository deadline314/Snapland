from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np
import json

q=Path("E:/Snapland-QA/art17-traveller-celebration-20261119")
src=Path("C:/Users/stanl/.codex/generated_images/01a1e5dd-6423-7963-9dc5-b040851d2b6b/exec-c17f8159-27d9-46e0-9051-a564aaf1f7ea.png")
original=Image.open(q/"traveller-reference.png").convert("RGBA")
sheets=Image.open(src).convert("RGBA")

def lens(im):
 r,g,b,a=np.moveaxis(np.array(im).astype(np.int16),-1,0)
 red=(r>105)&(r>g*1.66)&(r>b*1.20)&(g<95)&(a>128)
 ys,xs=np.where(red)
 return float(np.median(xs)),float(np.median(ys))

ref_lens=lens(original)
out=Image.new("RGB",(1400,394),"#e0dbcc")
pen=ImageDraw.Draw(out)
out.paste(original,(0,24),original)
pen.text((3,5),f"reference lens {ref_lens}",fill="black")
record=[]
for i in range(4):
 im=sheets.crop((i*sheets.width//4,0,(i+1)*sheets.width//4,sheets.height))
 bbox=im.getchannel("A").point(lambda a:255 if a>=128 else 0).getbbox()
 im=im.crop(bbox)
 x,y=lens(im)
 ratio=(346-ref_lens[1])/(im.height-y)
 im=im.resize((round(im.width*ratio),round(im.height*ratio)),Image.Resampling.NEAREST)
 placement=(round(ref_lens[0]-x*ratio),346-im.height)
 tile=Image.new("RGBA",(280,360))
 tile.paste(im,placement)
 tile.save(q/f"aligned-{i+1}.png")
 out.paste(tile,((i+1)*280,24),tile)
 pen.text(((i+1)*280+3,5),f"{i+1} lens-adjusted",fill="black")
 record.append({"frame":i+1,"ratio":ratio,"placement":placement,"camera":lens(tile)})
out.save(q/"aligned-review.png")
(q/"aligned-review.json").write_text(json.dumps({"reference":ref_lens,"generated":record},indent=2)+"\n","utf8")
print(ref_lens,record)
