from pathlib import Path
from PIL import Image
from scipy.ndimage import binary_dilation
import hashlib
import io
import json
import numpy as np

q=Path("E:/Snapland-QA/art17-traveller-celebration-20261119")
root=Path("assets/characters")
capture=q/"register-candidate-1119-111047-c51def/captures"
reg=json.loads((capture/"registration.json").read_text("utf-8"))
props=root/"avatar-prop-foreground-v1.json"
prop_text=props.read_text("utf-8")
owners=json.loads(prop_text)["owners"]
cloth=root/"rainvest-v1/manifest.json"
cloth_text=cloth.read_text("utf-8")
rows=json.loads(cloth_text)["frames"]
neutral_garment,=(row for row in rows if row["action"]=="idle" and row["frame"]==0 and row["direction"]=="front")
old_legacy=[row for row in rows if row["action"]=="celebrate" and row["direction"]=="front"]
assert len(old_legacy)==3 and all(row["source_kind"]=="runtime_fallback" for row in old_legacy)
neutral=np.array(Image.open(capture/"neutral.png").convert("RGBA"))
neutral_prop=np.zeros((360,280),dtype=bool)
for y,start,end in owners[reg["0"]["neutral"]]["spans"]:
 neutral_prop[y,start:end]=True
old_garment=Path(neutral_garment["path"].removeprefix("res://"))
assert hashlib.sha256(old_garment.read_bytes()).hexdigest()==neutral_garment["png_sha256"]
garment=np.array(Image.open(old_garment).convert("RGBA"))
logical_garment={"source_kind":"authored","direction":"front","action":"celebrate"}
rects=((84,200,128,244),(80,184,127,232),(64,152,112,193),(84,186,124,232))
new_owners=[]
new_layers=[]
record=[]
for frame in range(5):
 info=reg[str(frame)]
 assert info["neutral"]==neutral_garment["source_pixel_sha256"] and info["source"] not in owners
 raw=np.array(Image.open(capture/f"celebrate-{frame}.png").convert("RGBA"))
 exact=neutral_prop & np.all(raw==neutral,axis=2)
 mask=exact.copy()
 if frame<4:
  x0,y0,x1,y1=rects[frame]
  r,g,b,a=np.moveaxis(raw.astype(np.int16),-1,0)
  hand=np.zeros((360,280),dtype=bool)
  hand[y0:y1,x0:x1]=((r>100)&(r>g*1.17)&(r>b*1.3)&(a>=128))[y0:y1,x0:x1]
  assert hand.sum()>85
  mask |= binary_dilation(hand,iterations=2)&(a>=16)
 spans=[]
 for y in range(360):
  ext=np.pad(mask[y],(1,1))
  starts=np.flatnonzero(~ext[:-1]&ext[1:])
  ends=np.flatnonzero(ext[:-1]&~ext[1:])
  spans.extend([y,int(x),int(end)] for x,end in zip(starts,ends,strict=True))
 assert len(spans)>50 and sum(int(mask[y,145]) for y in range(229,251))>=12
 prop_row={"spans":spans,"poses":[f"celebrate/front/{frame}"],"review":"Preserves the stationary camera, camera hand and visible gesture against fabric and replacement hair."}
 new_owners.append("    "+json.dumps(info["source"])+": "+json.dumps(prop_row,separators=(",",":"))+",")
 extra=mask & (garment[:,:,3]>0) if frame<4 else np.zeros_like(mask)
 fitted=garment.copy()
 fitted[extra]=0
 if np.array_equal(fitted,garment):
  path=old_garment
 else:
  path=old_garment.with_name(f"celebration-front-{frame:02d}.pngdata")
  buf=io.BytesIO()
  Image.fromarray(fitted).save(buf,format="PNG",optimize=True)
  path.write_bytes(buf.getvalue())
 new_layers.append(dict(logical_garment,frame=frame,source_pixel_sha256=info["source"],path="res://"+path.as_posix(),
   png_sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
 record.append({"frame":frame,"protect_pixels":int(mask.sum()),"preserved_camera_pixels":int(exact.sum()),
                "garment_pixels_cleared":int(extra.sum()),"source":info["source"],"fabric":path.as_posix()})
marker='  "owners": {\n'
assert prop_text.count(marker)==1
props.write_text(prop_text.replace(marker,marker+"\n".join(new_owners)+"\n"),"utf-8",newline="")
for row in old_legacy:
 entry="\n".join("    "+line for line in json.dumps(row,indent=2).splitlines())
 assert cloth_text.count(entry+",\n")==1
 cloth_text=cloth_text.replace(entry+",\n","")
marker='\n  ],\n  "encoding"'
addition=",\n".join("\n".join("    "+s for s in json.dumps(row,indent=2).splitlines()) for row in new_layers)
assert cloth_text.count(marker)==1
cloth_text=cloth_text.replace(marker,",\n"+addition+marker)
assert len(json.loads(cloth_text)["frames"])==211
cloth.write_text(cloth_text,"utf-8",newline="")
(q/"fabric-and-prop-registration.json").write_text(json.dumps(record,indent=2)+"\n","utf-8")
print(json.dumps(record,indent=2))
