from pathlib import Path
from PIL import Image, ImageDraw
import numpy as np
from scipy.ndimage import label
import json

q=Path("E:/Snapland-QA/art17-traveller-celebration-20261119")
idle=Image.open(q/"traveller-reference.png").convert("RGBA")
base=np.array(idle)
board=Image.new("RGB",(1400,391),"#e1dccf")
draw=ImageDraw.Draw(board)
board.paste(idle,(0,20),idle)
draw.text((5,3),"settled source",fill="#172733")
yy,xx=np.mgrid[:360,:280]
mouth_boxes=((145,169,157,179),(136,167,161,178),(141,167,163,182),(136,162,159,173))
results=[]
for frame in range(1,5):
 gen=np.array(Image.open(q/f"aligned-{frame}.png").convert("RGBA"))
 art=base.copy()
 gesture=(xx>=39)&(xx<=np.interp(yy,[163,188,218,247,265,271],[106,106,122,124,108,82]))&(yy>=184)&(yy<=268)
 gesture &= (yy<=250)|((base[:,:,3]>=128)&(gen[:,:,3]>=128))
 art[gesture]=gen[gesture]
 cone=(xx>=52)&(xx<=105)&(yy>=158)&(yy<184)
 r,g,b,a=np.moveaxis(gen.astype(np.int16),-1,0)
 warm=(r>112)&(r>g*1.23)&(r>b*1.32)&(a>128)
 high=cone&((warm&(frame==3))|((base[:,:,3]<128)&(a>=128)))
 art[high]=gen[high]
 x0,y0,x1,y1=mouth_boxes[frame-1]
 mouth=(xx>=x0)&(xx<x1)&(yy>=y0)&(yy<y1)&(r>g+17)&(g<127)&(a>=128)
 my,mx=np.where(mouth)
 assert len(mx)>6
 dx=round(148-(mx.min()+mx.max())/2)
 dy=round(176-(my.min()+my.max())/2)
 old_r,old_g,_,_=np.moveaxis(base.astype(np.int16),-1,0)
 old_mouth=(xx>=141)&(xx<=155)&(yy>=172)&(yy<=181)&(old_r>old_g+42)&(old_g<150)
 for y in range(172,182):
  skin=base[y,137:141]
  art[y,old_mouth[y]]=np.median(skin,axis=0).astype(np.uint8)
 art[my+dy,mx+dx]=gen[my,mx]
 assert np.array_equal(art[278:],base[278:]) and np.array_equal(art[224:255,126:196],base[224:255,126:196])
 preview=Image.fromarray(art)
 preview.save(q/f"celebrate-{frame}.png")
 board.paste(preview,(280*frame,20),preview)
 draw.text((280*frame+5,3),f"pose {frame}",fill="#172733")
 _,count=label(art[:,:,3]>=128)
 results.append({"frame":frame,"mouth":len(mx),"translation":[dx,dy],"components_including_ink":count})
board.save(q/"celebrate-final-review.png")
(q/"celebrate-review.json").write_text(json.dumps(results,indent=2)+"\n","utf8")
print(results)
