from pathlib import Path
import sys

here=Path(__file__).resolve().parent
master=Path("C:/Users/stanl/Github/Snapland")
template=master/".review/art17-side-photo-20261119/final_checks.py"
source=template.read_text("utf8")
source=source.replace("template = here.parent / \"art16-20261119/verify_departure.py\"",
    'template = Path("C:/Users/stanl/Github/Snapland/.review/art16-20261119/verify_departure.py")')
source=source.replace('source = source.replace("spec.loader.exec_module(runner)",',
    '''source = source.replace("ROOT = HERE.parents[1]", "ROOT = Path('C:/Users/stanl/Github/Snapland')")
source = source.replace("spec.loader.exec_module(runner)",''')
source=source.replace("D:/Snapland-QA/art17-side-photo-20261119","E:/Snapland-QA/art17-traveller-celebration-20261119/native")
source=source.replace('d_stage if sys.argv[1] == "package" else local_stage','d_stage')
source=source.replace('f"assets/characters/traveller-photograph-{side}-v1.png" for side in ("front","front_right","right","back_right","back","back_left","left","front_left")',
    '"assets/characters/traveller-departure-compass-v1.png"')
source=source.replace("native_profile_photo_study","native_avatar_celebration_study")
source=source.replace("AvatarProfilePhotoQA.exe","AvatarCelebrationQA.exe")
source=source.replace("preserves 191 original","preserves 211 original")
start=source.index('    if mode!="reduced":')
end=source.index("''' + source[end:]",start)
source=source[:start]+'''    if mode!="reduced":
        cases=[row for row in report["actions"] if row["label"].endswith("-cheer")]
        assert {row["label"] for row in cases}=={"reward-default-cheer","rainvest-bob-cheer","rainvest-curly-cheer","reduced-inline-cheer"}
        assert all(row["predicate"] and row["detail"]["sources_match"] for row in cases)
        assert report["real_fountain_success"] and report["reward_save_unchanged_after_cheer"]
''' + source[end:]
exec(compile(source,str(here/"verify.py"),"exec"))



