from pathlib import Path
import json,hashlib,shutil,zipfile
r=Path.cwd();b=r/'work/legacy-head-20261026';dest=r/'pm/Snapland-art/images';prefix='ART-18-legacy-20261026-'
def cp(src,name):shutil.copy2(src,dest/(prefix+name))
def pack(files,name):
 with zipfile.ZipFile(dest/(prefix+name), 'w',zipfile.ZIP_DEFLATED,6) as z:
  for p in sorted(set(files)):
   if p.is_file() and '.godot' not in p.parts:z.write(p,str(p.relative_to(r)))
for mode,folder in [('normal','native-normal-3'),('quarter','native-quarter-final')]:
 report=json.loads((b/folder/'profile/report.json').read_text());res=json.loads((b/folder/'result.json').read_text());assert res['exit']==0 and res['errors']==0;assert len(report['captures'])==30
 pack(list((b/folder).rglob('*')),mode+'-native.zip')
 for i in range(1,6):cp(b/f'{mode}-contact-{i}.png',f'{mode}-{i}.png')
for p in (b/'references').glob('*.png'):cp(p,'reference-'+p.name)
files=[]
for sub in ['attempt-1','attempt-2','attempt-3','attempt-4','attempt-5','attempt-6','attempt-6-fixed','bake-compatible','compare-before','unit-1','unit-2','unit-final','checks','packed-check','release-smoke','native-normal-1','native-normal-2']:
 files+=list((b/sub).rglob('*'))
files+=[p for p in b.iterdir() if p.is_file() and p.suffix in ['.py','.gd','.json','.txt','.log']]
files+=list((b/'native').rglob('*'))+list((b/'references').rglob('*'))
files+=[r/'work/remaining-20261024/legacy-head-probe/result-v2/original.png',b/'release-build/stage-cleanup.txt',b/'release-build/build.json',b/'release-build/import.log',b/'release-build/export.log']
pack(files,'replay.zip')
pack(list((b/'release-smoke').rglob('*')),'release.zip')
review=dict(scope='ONE existing static human front celebration portrait; no new directional cels or authored motion coverage',reference_sources=json.loads((b/'references/sources.json').read_text()),default_render_sha256='ac5ae00803018d473727c82512bc3bd61c6c353787e7a73484b4e0c391315c2f',source_rgba_sha256='496bd30287ce3aed70b62522256b9f5be8b7b0fb7e91c56b36dc8a45ed892a24',normal=json.loads((b/'native-normal-3/result.json').read_text()),quarter=json.loads((b/'native-quarter-final/result.json').read_text()),packed=json.loads((b/'packed-check/result.json').read_text()),release=json.loads((b/'release-smoke/result.json').read_text()),official_checks=json.loads((b/'checks/results.json').read_text()),build=json.loads((b/'release-build/build.json').read_text()),visual_review='30 normal +30 true quarter native full-window captures viewed as five contacts per mode; original source/failed masks and final hair crop also inspected. No hearing or full gameplay claim.')
(dest/(prefix+'review.json')).write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
print('written evidence',prefix)
