extends SceneTree
const Before=preload("res://work/legacy-head-20261026/before_source.gd")
const Avatar=preload("res://game/world/avatar_renderer.gd")
func _initialize() -> void:
	var folder:=OS.get_environment("SNAPLAND_SAVE_PATH").get_base_dir()
	if not folder.is_absolute_path():quit(2);return
	DirAccess.make_dir_recursive_absolute(folder)
	var before=Before.new();var after=Avatar.new();var comparisons:=0
	for direction in Avatar.WALK_DIRECTIONS:
		for frame in range(3):
			var old: Image=before.texture(Avatar.DEFAULT_APPEARANCE,{"outfit":"outfit-tide","hat":"hat-none"},direction,frame,"celebrate").get_image()
			var current: Image=after.texture(Avatar.DEFAULT_APPEARANCE,{"outfit":"outfit-tide","hat":"hat-none"},direction,frame,"celebrate").get_image()
			if old.get_data()!=current.get_data():push_error("Default portrait drifted: "+direction+"/"+str(frame));quit(1);return
			comparisons+=1
	var raw: Image=after._atlas_pose_image(15)
	var source: Image=before.texture(Avatar.DEFAULT_APPEARANCE,{"outfit":"outfit-tide","hat":"hat-none"},"front",0,"celebrate").get_image()
	var report: Dictionary={"unchanged_default_requests":comparisons,"original_render_sha256":before.head_source_signature(source),"registry":after.legacy_heads.cache_snapshot(),"diagnostics":after.legacy_heads.diagnostics}
	var material_differences:=0
	for style in ["bob","curly"]:
		var look: Dictionary=Avatar.DEFAULT_APPEARANCE.duplicate();look.hair=style
		var image: Image=after.texture(look,{"outfit":"outfit-tide","hat":"hat-none"},"front",0,"celebrate").get_image()
		for y in 360:
			for x in 280:
				var color:=raw.get_pixel(x,y)
				if ((y>=140 and color.a>0.05) or (color.a>0.05 and color.h>0.40 and color.h<0.57 and color.s>0.35 and color.v>0.15)) and image.get_pixel(x,y)!=source.get_pixel(x,y):material_differences+=1
		for p in [Vector2i(111,114),Vector2i(162,114),Vector2i(115,99),Vector2i(158,99),Vector2i(140,135),Vector2i(170,139),Vector2i(43,86),Vector2i(233,83)]:
			if image.get_pixelv(p)!=source.get_pixelv(p):push_error("Independent original face/hand changed: "+str(p));quit(1);return
	if material_differences!=0:push_error("Original body/coat changed: "+str(material_differences));quit(1);return
	report["body_material_differences"]=material_differences
	FileAccess.open(folder.path_join("report.json"),FileAccess.WRITE).store_string(JSON.stringify(report,"  "))
	print("PASS: a26a65d default portrait RGBA preserved across 24 requests; original face/hand/body/coat witnesses preserved with alternate cuts; hash=",report.original_render_sha256)
	quit()
