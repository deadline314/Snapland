from pathlib import Path
import os,shutil,time,json,sys,subprocess
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();s=r/'work/tutorial-current-20261020/validation-project'
for name in ['game/world/avatar_renderer.gd','game/world/legacy_head_source.gd','assets/characters/legacy-head-ownership-v1.json','work/legacy-head-20261026/native/review.gd','work/legacy-head-20261026/native/entry.tscn']:
 d=s/name;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/name,d)
label=sys.argv[1];out=r/'work/legacy-head-20261026'/label;out.mkdir(exist_ok=False);t=time.monotonic();args=['--','--quarter'] if 'quarter' in label else []
try:p=run_validated_godot(s,[str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'),'--path',str(s),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--resolution','1280x720','res://work/legacy-head-20261026/native/entry.tscn',*args],dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'profile/progress.json')),300);log=p.stdout+p.stderr;code=p.returncode
except subprocess.TimeoutExpired as e:log=(e.stdout or '')+(e.stderr or '');code=124
(out/'result.log').write_text(log);info=dict(exit=code,errors=log.count('ERROR:'),seconds=round(time.monotonic()-t,2));(out/'result.json').write_text(json.dumps(info,indent=2)+'\n');print(info,log[-2200:],flush=True)
