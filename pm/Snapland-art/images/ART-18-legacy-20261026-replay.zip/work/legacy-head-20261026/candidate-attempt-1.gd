extends SceneTree
const Avatar=preload("res://game/world/avatar_renderer.gd")
class Candidate:
	extends "res://game/world/avatar_renderer.gd"
	const SIGNATURE="496bd30287ce3aed70b62522256b9f5be8b7b0fb7e91c56b36dc8a45ed892a24"
	var annotation: Dictionary={}
	func texture(appearance: Dictionary,equipped: Dictionary,direction: String="front",frame: int=0,action: String="idle") -> Texture2D:
		var valid: bool=_hair_atlas_valid
		if action=="celebrate" and appearance.get("hair","windswept")=="windswept":_hair_atlas_valid=false
		var result: Texture2D=super.texture(appearance,equipped,"front" if action=="celebrate" else direction,frame,action)
		_hair_atlas_valid=valid
		return result
	func _source_hair_mask(source: Image,direction: String) -> PackedByteArray:
		if head_source_signature(source)!=SIGNATURE:return super._source_hair_mask(source,direction)
		var mask:=PackedByteArray();mask.resize(280*360)
		var polygon:=PackedVector2Array()
		for p in [[61,97],[61,78],[67,70],[73,65],[68,61],[65,54],[66,45],[68,40],[87,47],[84,39],[97,20],[100,34],[110,38],[122,28],[144,27],[154,32],[151,27],[145,19],[163,24],[177,38],[178,49],[190,37],[193,31],[198,37],[201,47],[198,59],[194,62],[203,71],[214,72],[219,68],[220,76],[216,91],[210,99],[202,109],[193,120],[185,126],[180,129],[177,125],[178,108],[177,97],[171,84],[163,81],[155,83],[150,92],[143,107],[136,101],[129,90],[125,83],[121,92],[113,98],[106,104],[101,114],[100,125],[91,121],[89,114],[82,111],[78,107],[70,105],[62,101]]:polygon.append(Vector2(p[0],p[1]))
		var forelock:=PackedVector2Array()
		for p in [[150,65],[164,64],[176,70],[181,81],[182,94],[179,99],[177,88],[171,82],[163,79],[155,80],[150,85]]:forelock.append(Vector2(p[0],p[1]))
		for y in range(15,140):
			for x in range(50,225):
				if source.get_pixel(x,y).a>0.05 and (Geometry2D.is_point_in_polygon(Vector2(x+0.5,y+0.5),polygon) or Geometry2D.is_point_in_polygon(Vector2(x+0.5,y+0.5),forelock)):mask[y*280+x]=1
		return mask
	func _build_source_hair_metrics(source: Image,direction: String,guide: Image=null,tolerance: int=8,eyes: Array[Rect2i]=[],foreground: PackedByteArray=PackedByteArray(),contour: PackedVector2Array=PackedVector2Array()) -> Dictionary:
		if head_source_signature(source)!=SIGNATURE:return super._build_source_hair_metrics(source,direction,guide,tolerance,eyes,foreground,contour)
		var mask:=_source_hair_mask(source,"front")
		var spans: Array=[]
		for y in 360:
			var start: int=-1
			for x in range(281):
				var inside: bool=x<280 and mask[y*280+mini(x,279)]!=0
				if inside and start<0:start=x
				if not inside and start>=0:spans.append([y,start,x]);start=-1
		annotation={"body_start_y":140,"hair_owner_spans":spans}
		_head_material_owners[SIGNATURE]=annotation
		var closed: Array[Rect2i]=[Rect2i(105,109,23,12),Rect2i(148,108,24,12)]
		var head:=PackedVector2Array()
		for p in [[104,70],[117,60],[140,57],[160,62],[176,77],[180,96],[177,120],[167,139],[145,148],[123,145],[105,134],[99,116],[99,91]]:head.append(Vector2(p[0],p[1]))
		var metrics: Dictionary=super._build_source_hair_metrics(source,"front",null,20,closed,foreground,head)
		# Raised hands/cuffs and both expressive brows stay in the foreground.
		var guards: Array=[Rect2i(24,58,39,51),Rect2i(35,100,42,40),Rect2i(216,56,40,51),Rect2i(198,98,39,42),Rect2i(108,93,21,11),Rect2i(148,92,22,12)]
		var face: PackedByteArray=metrics.face_mask
		for guard: Rect2i in guards:
			for y in range(guard.position.y,guard.end.y):
				for x in range(guard.position.x,guard.end.x):
					if source.get_pixel(x,y).a>0.05:face[y*280+x]=1
		metrics.face_mask=face;metrics.face_indices=_mask_indices(face)
		for index in metrics.face_indices:metrics.replacement_source_mask[index]=0
		metrics.replacement_source_indices=_mask_indices(metrics.replacement_source_mask)
		return metrics
func _initialize() -> void:
	var folder:=OS.get_environment("SNAPLAND_SAVE_PATH").get_base_dir()
	if not folder.is_absolute_path():quit(2);return
	DirAccess.make_dir_recursive_absolute(folder)
	var candidate:=Candidate.new();var baseline:=Avatar.new()
	var raw: Image=candidate._atlas_pose_image(15)
	var metrics: Dictionary=candidate._build_source_hair_metrics(raw,"front")
	var colored:=raw.duplicate();var cut:=raw.duplicate()
	for index in metrics.source_hair_indices:colored.set_pixel(index%280,index/280,Color.MAGENTA)
	for index in metrics.replacement_source_indices:cut.set_pixel(index%280,index/280,Color.TRANSPARENT)
	colored.save_png(folder.path_join("owner.png"));cut.save_png(folder.path_join("cut.png"))
	var data: Array=[]
	for style in ["windswept","bob","curly"]:
		for hat in ["hat-none","hat-straw","hat-sailor"]:
			var look: Dictionary=Avatar.DEFAULT_APPEARANCE.duplicate();look.hair=style
			var result: Image=candidate.texture(look,{"outfit":"outfit-tide","hat":hat},"front",0,"celebrate").get_image()
			result.save_png(folder.path_join(style+"-"+hat+".png"))
			data.append({"style":style,"hat":hat,"pixels":candidate.head_source_signature(result)})
	FileAccess.open(folder.path_join("annotation.json"),FileAccess.WRITE).store_string(JSON.stringify(candidate.annotation,"  "))
	FileAccess.open(folder.path_join("report.json"),FileAccess.WRITE).store_string(JSON.stringify({"renders":data,"head_bounds":str(metrics.source_bounds),"face_pixels":metrics.face_indices.size(),"skull_pixels":metrics.skull_underlay_indices.size(),"body_start_y":metrics.body_start_y},"  "))
	quit()
