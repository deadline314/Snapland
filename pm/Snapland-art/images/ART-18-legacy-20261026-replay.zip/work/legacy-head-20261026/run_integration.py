from pathlib import Path
import os,shutil,time,json
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();s=r/'work/tutorial-current-20261020/validation-project'
for name in ['game/world/avatar_renderer.gd','game/world/legacy_head_source.gd','assets/characters/legacy-head-ownership-v1.json','work/legacy-head-20261026/check_integration.gd']:shutil.copy2(r/name,s/name)
out=r/'work/legacy-head-20261026/integration-1';out.mkdir(exist_ok=False);t=time.monotonic();p=run_validated_godot(s,[str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'),'--headless','--path',str(s),'--script','res://work/legacy-head-20261026/check_integration.gd'],dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'profile/progress.json')),90);log=p.stdout+p.stderr;(out/'result.log').write_text(log);info=dict(exit=p.returncode,errors=log.count('ERROR:'),seconds=round(time.monotonic()-t,2));(out/'result.json').write_text(json.dumps(info,indent=2)+'\n');print(info,log[-2000:])
