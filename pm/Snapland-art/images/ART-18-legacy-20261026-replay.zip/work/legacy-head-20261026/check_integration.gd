extends SceneTree
const Avatar=preload("res://game/world/avatar_renderer.gd")
func _initialize() -> void:
	var folder:=OS.get_environment("SNAPLAND_SAVE_PATH").get_base_dir()
	if not folder.is_absolute_path():quit(2);return
	DirAccess.make_dir_recursive_absolute(folder)
	var avatar:=Avatar.new()
	var rows: Array=[]
	for style in ["windswept","bob","curly"]:
		for hat in ["hat-none","hat-straw","hat-sailor"]:
			var look: Dictionary=Avatar.DEFAULT_APPEARANCE.duplicate();look.hair=style
			var result: Image=avatar.texture(look,{"outfit":"outfit-tide","hat":hat},"front",0,"celebrate").get_image()
			result.save_png(folder.path_join(style+"-"+hat+".png"))
			rows.append({"style":style,"hat":hat,"pixels":avatar.head_source_signature(result)})
	FileAccess.open(folder.path_join("report.json"),FileAccess.WRITE).store_string(JSON.stringify({"renders":rows,"cache":avatar.legacy_heads.cache_snapshot(),"diagnostics":avatar.legacy_heads.diagnostics},"  "))
	print("PASS: production legacy head render fixture completed")
	quit()
