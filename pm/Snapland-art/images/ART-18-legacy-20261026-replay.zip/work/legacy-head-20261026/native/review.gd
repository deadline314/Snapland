extends "res://game/tests/native_review.gd"
var folder := ""
var records: Array=[]
var inset: TextureRect
var caption: Label
var source_panel: Control
var expected_quarter := false
func _popup_key(popup: Window, code: int) -> void:
	# XTest sends real X11 keyboard input to the focused native popup.
	var names: Dictionary={KEY_DOWN:"Down",KEY_UP:"Up",KEY_ENTER:"Return",KEY_ESCAPE:"Escape",KEY_SPACE:"space"}
	var output: Array=[]
	if OS.execute("python3",["/workspace/work/Snapland-character/work/legacy-head-20261026/native_key.py",names[code]],output,true)!=0:
		push_error("Native X11 key failed: "+str(output))
func _frames(count: int) -> void:
	for index in count:await get_tree().process_frame
func _process(_delta: float) -> void:
	if not is_instance_valid(source_panel):return
	source_panel.visible=is_instance_valid(main) and main.modal_kind==""
	if is_instance_valid(main) and is_instance_valid(main.world) and is_instance_valid(main.world.avatar):
		inset.texture=main.world.avatar.texture
func _inset() -> void:
	var layer:=CanvasLayer.new();add_child(layer)
	source_panel=Control.new();source_panel.mouse_filter=Control.MOUSE_FILTER_IGNORE;layer.add_child(source_panel)
	var background:=ColorRect.new();background.position=Vector2(970,138);background.size=Vector2(300,410);background.color=Color("#263d48");background.mouse_filter=Control.MOUSE_FILTER_IGNORE;source_panel.add_child(background)
	caption=Label.new();caption.position=Vector2(980,143);caption.size=Vector2(280,38);caption.add_theme_font_size_override("font_size",13);caption.mouse_filter=Control.MOUSE_FILTER_IGNORE;source_panel.add_child(caption)
	inset=TextureRect.new();inset.position=Vector2(980,182);inset.size=Vector2(280,360);inset.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST;inset.mouse_filter=Control.MOUSE_FILTER_IGNORE;source_panel.add_child(inset)
func _set_hair(style: String) -> bool:
	_key(KEY_C);await get_tree().create_timer(0.2).timeout
	if not await _named_button("Tab_appearance"):return false
	var selector: OptionButton=main.overlay.find_child("Appearance_hair",true,false)
	if selector==null:await _fail("Missing actual hair option");return false
	var target: int=-1
	for index in selector.item_count:
		if str(selector.get_item_metadata(index))==style:target=index
	if target<0:await _fail("Unknown actual hair id");return false
	if not await _option("Appearance_hair",target):return false
	if main.wardrobe_panel.draft_appearance.hair!=style:await _fail("Popup did not update draft hair");return false
	if not await _take("ui-"+style,false):return false
	if not await _named_button("ApplyAppearance"):return false
	if progress.appearance.hair!=style:await _fail("Appearance Apply did not save");return false
	_key(KEY_ESCAPE);await get_tree().create_timer(0.2).timeout
	return true
func _run() -> void:
	folder=OS.get_environment("SNAPLAND_SAVE_PATH").get_base_dir()
	if not folder.is_absolute_path() or DisplayServer.get_name()=="headless":get_tree().quit(2);return
	DirAccess.make_dir_recursive_absolute(folder)
	expected_quarter=OS.get_cmdline_user_args().has("--quarter")
	Engine.time_scale=0.25 if expected_quarter else 1.0
	progress=get_tree().root.get_node("Progress");progress.reset_progress();progress.intro_seen=true
	# Explicit isolated currency fixture; no playthrough/earning is claimed.
	progress.coins=600
	main=_instantiate_main();get_tree().root.add_child(main);_inset()
	await get_tree().create_timer(1.0).timeout
	if not await _set_hair("bob"):return
	if not await _set_hair("curly"):return
	_key(KEY_C);await get_tree().create_timer(0.2).timeout
	if not await _named_button("Tab_closet"):return
	if not await _named_button("WardrobeItem_outfit-rainvest"):return
	if not await _named_button("WearSelected"):return
	if progress.equipped.outfit!="outfit-rainvest" or progress.coins!=600:await _fail("Free original garment flow changed");return
	_key(KEY_ESCAPE);await get_tree().create_timer(0.2).timeout
	main.world.player.position=Vector3(0,0.4,-6)
	main.world.camera.size=6.5
	await get_tree().create_timer(0.3).timeout
	for outfit in ["outfit-tide","outfit-rainvest"]:
		for style in ["windswept","bob","curly"]:
			for hat in ["hat-none","hat-straw","hat-sailor","hat-flower"]:
				var look: Dictionary=progress.appearance.duplicate();look.hair=style
				# Explicit scene look matrix; hats are not claimed purchased/earned.
				main.world.set_avatar_look(look,{"outfit":outfit,"hat":hat})
				main.world.facing="back"
				main.world.play_action("celebrate")
				await get_tree().create_timer(0.22).timeout
				if not await _take(outfit+"-"+style+"-"+hat):return
				await get_tree().create_timer(main.world.avatar_action_remaining+0.12).timeout
	main.world.set_avatar_look(progress.appearance,progress.equipped)
	main.world.play_action("celebrate");await get_tree().create_timer(0.2).timeout
	_key(KEY_ESCAPE);await _frames(4)
	if main.modal_kind!="pause" or not main.world.blocked:await _fail("Actual Escape pause failed");return
	var elapsed: float=main.world.avatar_action_elapsed;var clock: float=main.world.time
	await get_tree().create_timer(0.25).timeout
	if main.world.avatar_action_elapsed!=elapsed or main.world.time!=clock:await _fail("Paused actor clock advanced");return
	if not await _take("pause-clock",false):return
	_key(KEY_ESCAPE);await get_tree().create_timer(0.1).timeout
	main._show_settings();await get_tree().create_timer(0.2).timeout
	if not await _named_button("SettingsTab_play"):return
	if not await _named_button("Value_reduced_motion"):return
	if not progress.settings.reduced_motion or not main.world.reduced_motion:await _fail("Actual reduced-motion checkbox not applied");return
	if not await _take("reduced-settings",false):return
	_key(KEY_ESCAPE);await get_tree().create_timer(0.15).timeout
	main.world.play_action("celebrate");await get_tree().create_timer(0.2).timeout
	var frame: int=main.world.last_avatar_frame
	if not await _take("reduced-celebration"):return
	await get_tree().create_timer(0.3).timeout
	if main.world.last_avatar_frame!=frame:await _fail("Reduced static pose advanced display request");return
	if not progress.save_progress():await _fail("Cannot preserve actual appearance fixture");return
	main.queue_free();main=null;await _frames(6)
	progress.load_progress();main=_instantiate_main();get_tree().root.add_child(main)
	await get_tree().create_timer(0.8).timeout
	if progress.appearance.hair!="curly" or progress.equipped.outfit!="outfit-rainvest" or progress.coins!=600:await _fail("Actual free appearance/garment did not reload");return
	main.world.player.position=Vector3(0,0.4,-6);main.world.camera.size=6.5;main.world.facing="back"
	main.world.play_action("celebrate");await get_tree().create_timer(0.2).timeout
	if not await _take("scene-reentry"):return
	FileAccess.open(folder.path_join("report.json"),FileAccess.WRITE).store_string(JSON.stringify({"captures":records,"time_scale":Engine.time_scale,"scope":"Actual UI hair and free garment inputs, explicit24look API static-portrait matrix, pause/settings and same-process scene reentry. Source inset is the live Sprite3D texture. Not new animation artwork, earning or full gameplay."},"  "))
	print("PASS: native legacy human hair UI, 24 static look combinations, pause, reduced motion and scene reentry")
	await main._quit_game()
func _take(label: String, check_pose: bool=true) -> bool:
	if check_pose:
		if main.world.last_avatar_action!="celebrate" or main.world.facing!="back":await _fail("Static source fixture changed action or navigation heading");return false
		var snapshot: Dictionary=main.world.avatar_renderer.legacy_heads.cache_snapshot()
		if snapshot.compiled_portraits!=1 or not snapshot.ready:await _fail("Actual world did not load reviewed source masks");return false
		for record in main.world.actor_shadow_proxies:
			if str(record.role)=="hero" and record.silhouette.silhouette_material.albedo_texture!=main.world.avatar.texture:await _fail("Shadow did not follow final composed head");return false
	caption.text="LIVE SPRITE SOURCE / STATIC PORTRAIT\n%s / %s" % [main.world.avatar_appearance.hair,main.world.avatar_equipped.get("hat","hat-none")]
	await _frames(2);await RenderingServer.frame_post_draw
	var image:=get_viewport().get_texture().get_image();var file:=folder.path_join(label+".png")
	if image.get_size()!=Vector2i(1280,720) or FileAccess.file_exists(file) or image.save_png(file)!=OK:await _fail("Fresh full-size capture failed");return false
	records.append({"label":label,"wall_msec":Time.get_ticks_msec(),"time_scale":Engine.time_scale,"action":main.world.last_avatar_action,"requested_heading":main.world.last_avatar_direction,"frame":main.world.last_avatar_frame,"source_direction":"front" if check_pose else "UI","appearance":main.world.avatar_appearance.duplicate(),"equipped":main.world.avatar_equipped.duplicate(),"reduced_motion":main.world.reduced_motion,"head_cache":main.world.avatar_renderer.legacy_heads.cache_snapshot(),"body_source_sha256":main.world.avatar_renderer.head_source_signature(main.world.avatar.texture.get_image())})
	return true
