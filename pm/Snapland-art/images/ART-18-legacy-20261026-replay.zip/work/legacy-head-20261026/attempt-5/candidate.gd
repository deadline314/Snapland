extends SceneTree
const Avatar=preload("res://game/world/avatar_renderer.gd")
class Candidate:
	extends "res://game/world/avatar_renderer.gd"
	const SIGNATURE="496bd30287ce3aed70b62522256b9f5be8b7b0fb7e91c56b36dc8a45ed892a24"
	var annotation: Dictionary={}
	func texture(appearance: Dictionary,equipped: Dictionary,direction: String="front",frame: int=0,action: String="idle") -> Texture2D:
		var valid: bool=_hair_atlas_valid
		if action=="celebrate" and appearance.get("hair","windswept")=="windswept":_hair_atlas_valid=false
		var result: Texture2D=super.texture(appearance,equipped,"front" if action=="celebrate" else direction,frame,action)
		_hair_atlas_valid=valid
		return result
	func _source_hair_mask(source: Image,direction: String) -> PackedByteArray:
		if head_source_signature(source)!=SIGNATURE:return super._source_hair_mask(source,direction)
		var mask:=PackedByteArray();mask.resize(280*360)
		var outer:=PackedVector2Array()
		for p in [[50,0],[226,0],[226,60],[218,60],[218,88],[203,112],[190,130],[179,143],[100,143],[84,126],[72,113],[61,101],[60,70],[50,70]]:outer.append(Vector2(p[0],p[1]))
		var face:=PackedVector2Array()
		for p in [[99,110],[105,103],[113,98],[121,92],[125,83],[129,90],[136,101],[143,107],[150,92],[155,83],[163,81],[171,84],[177,97],[178,108],[177,125],[175,135],[164,144],[145,149],[126,146],[109,139],[100,132],[96,126]]:face.append(Vector2(p[0],p[1]))
		var ears: Array[Rect2i]=[Rect2i(89,119,13,18),Rect2i(176,119,14,18)]
		var hands: Array[Rect2i]=[Rect2i(24,58,39,51),Rect2i(35,100,42,40),Rect2i(216,56,40,51),Rect2i(198,98,39,42)]
		var lower_face:=PackedVector2Array()
		for p in [[106,63],[128,53],[150,54],[174,67],[183,91],[186,117],[180,135],[166,145],[145,151],[121,148],[100,137],[91,122],[93,94]]:lower_face.append(Vector2(p[0],p[1]))
		for y in range(0,145):
			for x in range(50,226):
				var point:=Vector2(x+0.5,y+0.5)
				var protected:=false
				for guard: Rect2i in ears+hands:
					if guard.has_point(Vector2i(x,y)):protected=true
				if y>=140 or (y>=120 and Geometry2D.is_point_in_polygon(point,lower_face)):protected=true
				if not protected and source.get_pixel(x,y).a>0.05 and Geometry2D.is_point_in_polygon(point,outer) and not Geometry2D.is_point_in_polygon(point,face):mask[y*280+x]=1
		return mask
	func _build_source_hair_metrics(source: Image,direction: String,guide: Image=null,tolerance: int=8,eyes: Array[Rect2i]=[],foreground: PackedByteArray=PackedByteArray(),contour: PackedVector2Array=PackedVector2Array()) -> Dictionary:
		if head_source_signature(source)!=SIGNATURE:return super._build_source_hair_metrics(source,direction,guide,tolerance,eyes,foreground,contour)
		var mask:=_source_hair_mask(source,"front")
		var spans: Array=[]
		for y in 360:
			var start: int=-1
			for x in range(281):
				var inside: bool=x<280 and mask[y*280+mini(x,279)]!=0
				if inside and start<0:start=x
				if not inside and start>=0:spans.append([y,start,x]);start=-1
		annotation={"body_start_y":140,"hair_owner_spans":spans}
		_head_material_owners[SIGNATURE]=annotation
		var closed: Array[Rect2i]=[Rect2i(105,109,23,12),Rect2i(148,108,24,12)]
		var head:=PackedVector2Array()
		for p in [[106,63],[128,53],[150,54],[174,67],[183,91],[186,117],[180,135],[166,145],[145,151],[121,148],[100,137],[91,122],[93,94]]:head.append(Vector2(p[0],p[1]))
		var metrics: Dictionary=super._build_source_hair_metrics(source,"front",null,20,closed,foreground,head)
		# Raised hands/cuffs and both expressive brows stay in the foreground.
		var guards: Array=[Rect2i(24,58,39,51),Rect2i(35,100,42,40),Rect2i(216,56,40,51),Rect2i(198,98,39,42),Rect2i(108,93,21,11),Rect2i(148,92,22,12)]
		var face: PackedByteArray=metrics.face_mask
		for guard: Rect2i in guards:
			for y in range(guard.position.y,guard.end.y):
				for x in range(guard.position.x,guard.end.x):
					if source.get_pixel(x,y).a>0.05:face[y*280+x]=1
		# The original jaw outline and raised-arm body are foreground, not hair.
		for y in range(120,360):
			for x in 280:
				if source.get_pixel(x,y).a>0.05 and (y>=140 or Geometry2D.is_point_in_polygon(Vector2(x+0.5,y+0.5),head)):face[y*280+x]=1
		metrics.face_mask=face;metrics.face_indices=_mask_indices(face)
		# Keep original visible skin shading, and fill the occluded temple/jaw
		# inside the independently traced anatomical head, not a rectangular box.
		var skull: PackedInt32Array=metrics.skull_underlay_indices
		var colors: PackedColorArray=metrics.skull_underlay_colors
		var seen: Dictionary={}
		for i in skull.size():
			var index: int=skull[i];seen[index]=true
			var color:=source.get_pixel(index%280,index/280)
			if mask[index]==0 and _is_color_family(color,Color("#fdbb7b"),0.055,0.25):colors[i]=color
		var surface:=source.get_pixel(140,122)
		for index in _mask_indices(mask):
			var point:=Vector2(index%280,index/280)
			if not seen.has(index) and face[index]==0 and Geometry2D.is_point_in_polygon(point+Vector2(0.5,0.5),head):
				skull.append(index);colors.append(surface)
		metrics.skull_underlay_indices=skull;metrics.skull_underlay_colors=colors
		var removal:=mask.duplicate()
		for index in skull:removal[index]=1
		for index in metrics.face_indices:removal[index]=0
		metrics.replacement_source_mask=removal
		for index in metrics.face_indices:metrics.replacement_source_mask[index]=0
		metrics.replacement_source_indices=_mask_indices(metrics.replacement_source_mask)
		return metrics
func _initialize() -> void:
	var folder:=OS.get_environment("SNAPLAND_SAVE_PATH").get_base_dir()
	if not folder.is_absolute_path():quit(2);return
	DirAccess.make_dir_recursive_absolute(folder)
	var candidate:=Candidate.new();var baseline:=Avatar.new()
	var raw: Image=candidate._atlas_pose_image(15)
	var metrics: Dictionary=candidate._build_source_hair_metrics(raw,"front")
	var colored:=raw.duplicate();var cut:=raw.duplicate()
	for index in metrics.source_hair_indices:colored.set_pixel(index%280,index/280,Color.MAGENTA)
	for index in metrics.replacement_source_indices:cut.set_pixel(index%280,index/280,Color.TRANSPARENT)
	colored.save_png(folder.path_join("owner.png"));cut.save_png(folder.path_join("cut.png"))
	var data: Array=[]
	for style in ["windswept","bob","curly"]:
		for hat in ["hat-none","hat-straw","hat-sailor"]:
			var look: Dictionary=Avatar.DEFAULT_APPEARANCE.duplicate();look.hair=style
			var result: Image=candidate.texture(look,{"outfit":"outfit-tide","hat":hat},"front",0,"celebrate").get_image()
			result.save_png(folder.path_join(style+"-"+hat+".png"))
			data.append({"style":style,"hat":hat,"pixels":candidate.head_source_signature(result)})
	var body_differences:=0
	var base: Image=candidate.texture(Avatar.DEFAULT_APPEARANCE,{"outfit":"outfit-tide","hat":"hat-none"},"front",0,"celebrate").get_image()
	for style in ["bob","curly"]:
		var look: Dictionary=Avatar.DEFAULT_APPEARANCE.duplicate();look.hair=style
		var result: Image=candidate.texture(look,{"outfit":"outfit-tide","hat":"hat-none"},"front",0,"celebrate").get_image()
		for y in range(140,360):
			for x in 280:
				if raw.get_pixel(x,y).a>0.05 and result.get_pixel(x,y)!=base.get_pixel(x,y):body_differences+=1
		for point in [Vector2i(111,114),Vector2i(162,114),Vector2i(115,99),Vector2i(158,99),Vector2i(140,135),Vector2i(170,139),Vector2i(43,86),Vector2i(233,83)]:
			if result.get_pixelv(point)!=base.get_pixelv(point):push_error("Independent face/hand witness changed: "+str(point));quit(1);return
	if body_differences!=0:push_error("Original opaque body changed: "+str(body_differences));quit(1);return
	print("PASS: prototype face/hand witnesses and opaque body remain exact across alternate styles")
	FileAccess.open(folder.path_join("annotation.json"),FileAccess.WRITE).store_string(JSON.stringify(candidate.annotation,"  "))
	FileAccess.open(folder.path_join("report.json"),FileAccess.WRITE).store_string(JSON.stringify({"renders":data,"head_bounds":str(metrics.source_bounds),"face_pixels":metrics.face_indices.size(),"skull_pixels":metrics.skull_underlay_indices.size(),"body_start_y":metrics.body_start_y},"  "))
	quit()
