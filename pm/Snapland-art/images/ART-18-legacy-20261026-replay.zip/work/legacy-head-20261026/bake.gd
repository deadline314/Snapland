extends SceneTree
const Prototype=preload("res://work/legacy-head-20261026/candidate.gd")
func runs(mask: PackedByteArray) -> Array:
	var result: Array=[]
	for y in 360:
		var start: int=-1
		for x in range(281):
			var inside: bool=x<280 and mask[y*280+mini(x,279)]!=0
			if inside and start<0:start=x
			if not inside and start>=0:result.append([y,start,x]);start=-1
	return result
func rect(rectangle: Rect2i) -> Array:return [rectangle.position.x,rectangle.position.y,rectangle.size.x,rectangle.size.y]
func _initialize() -> void:
	var folder:=OS.get_environment("SNAPLAND_SAVE_PATH").get_base_dir()
	if not folder.is_absolute_path():quit(2);return
	DirAccess.make_dir_recursive_absolute(folder)
	var a=Prototype.Candidate.new();var original: Image=a._atlas_pose_image(15)
	var m: Dictionary=a._build_source_hair_metrics(original,"front")
	var hair: PackedByteArray=m.source_hair_mask.duplicate();var face: PackedByteArray=m.face_mask
	for index in m.face_indices:hair[index]=0
	var colors: Dictionary={}
	for i in m.skull_underlay_indices.size():
		var index: int=m.skull_underlay_indices[i]
		if face[index]==0:
			var c: Color=m.skull_underlay_colors[i]
			colors[index]=[c.r8,c.g8,c.b8,c.a8]
	var underlay: Array=[]
	for y in 360:
		var start: int=-1;var color: Array=[]
		for x in range(281):
			var next: Array=colors.get(y*280+x,[]) if x<280 else []
			if start>=0 and next!=color:underlay.append([y,start,x]+color);start=-1
			if not next.is_empty() and start<0:start=x;color=next
	var contour: Array=[]
	for point in m.skull_contour:contour.append([point.x,point.y])
	# Preserve the original runtime's coat tint exclusions independently of
	# real hair material. These spans never authorize stripping source pixels.
	var original_renderer=preload("res://game/world/avatar_renderer.gd").new()
	var before: Dictionary=original_renderer._build_source_hair_metrics(original,"front")
	var palette:=PackedByteArray();palette.resize(280*360)
	for index in before.palette_hair_indices:palette[index]=1
	var record: Dictionary={"action":"celebrate","pose_index":15,"source_direction":"front","supported_species":["human"],"source_pixel_sha256":a.head_source_signature(original),"hair_spans":runs(hair),"palette_compat_spans":runs(palette),"restore_spans":runs(face),"underlay_runs":underlay,"source_bounds":rect(m.source_bounds),"skin_bounds":[89,83,100,72],"target_face":[102,83,74,40],"eyes_bounds":rect(m.eyes_bounds),"body_start_y":m.body_start_y,"skull_contour":contour}
	var data: Dictionary={"schema_version":1,"canvas":[280,360],"description":"Reviewed head material and independent foreground ownership of the existing complete original legacy portrait. Not new animation artwork. All source positions are fixed; hair is behind raised hands, jaw outline and body. RGB skin runs are source-derived, before appearance palette.","poses":[record]}
	FileAccess.open(folder.path_join("owner.json"),FileAccess.WRITE).store_string(JSON.stringify(data,"\t"))
	print("BAKED legacy head: hair runs ",record.hair_spans.size(),", foreground runs ",record.restore_spans.size(),", underlay runs ",underlay.size())
	quit()
