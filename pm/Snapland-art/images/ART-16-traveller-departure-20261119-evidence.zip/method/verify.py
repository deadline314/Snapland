from pathlib import Path
import sys

here=Path(__file__).resolve().parent
master=Path("C:/Users/stanl/Github/Snapland")
template=master/".review/art17-side-photo-20261119/final_checks.py"
source=template.read_text("utf8")
source=source.replace("template = here.parent / \"art16-20261119/verify_departure.py\"",
    'template = Path("C:/Users/stanl/Github/Snapland/.review/art16-20261119/verify_departure.py")')
source=source.replace('source = source.replace("spec.loader.exec_module(runner)",',
    '''source = source.replace("ROOT = HERE.parents[1]", "ROOT = Path('C:/Users/stanl/Github/Snapland')")
source = source.replace("spec.loader.exec_module(runner)",''')
source=source.replace("D:/Snapland-QA/art17-side-photo-20261119","E:/Snapland-QA/art16-traveller-departure-20261119/native")
source=source.replace('d_stage if sys.argv[1] == "package" else local_stage','d_stage')
source=source.replace('f"assets/characters/traveller-photograph-{side}-v1.png" for side in ("left","right")',
    '"assets/characters/traveller-departure-sides-v1.png"')
source=source.replace("native_profile_photo_study","native_profile_departure_study")
source=source.replace("AvatarProfilePhotoQA.exe","AvatarSideDepartureQA.exe")
source=source.replace("preserves 191 original","preserves 201 original")
start=source.index('    if mode!="reduced":')
end=source.index("''' + source[end:]",start)
source=source[:start]+'''    if mode!="reduced":
        cases=[item for item in report["actions"] if item["label"].endswith("-departure")]
        assert len(cases)==6 and all(item["predicate"] for item in cases)
        assert {(row["label"],row["direction"]) for row in cases}=={
            (look+"-"+side+"-departure",side)
            for look in ("default","rainvest","live-hair") for side in ("left","right")}
        assert sum(bool(row["detail"]["live_hair"]) for row in cases)==2
''' + source[end:]
exec(compile(source,str(here/"verify.py"),"exec"))


