from pathlib import Path
import sys

here = Path(__file__).resolve().parent
body=(here/"export_reference.py").read_text("utf8")
body=body.replace('"game/tests/export_hero_stop_reference.gd"','"game/tests/register_hero_stop.gd"')
body=body.replace('HERE/"export_reference.gd"','HERE/"register_probe.gd"')
body=body.replace('make_base("source-poses")','make_base("import-candidate" if sys.argv[1]=="import" else "register-candidate")')
body=body.replace('tracked=subprocess.check_output(["git","ls-files","-z"],cwd=ROOT,encoding="utf8").split("\\0")',
    'tracked=subprocess.check_output(["git","ls-files","-z"],cwd=ROOT,encoding="utf8").split("\\0")')
body=body.replace('graph=runner.prepare_runtime_stage(ROOT,project,tracked)',
    'tracked = list(dict.fromkeys([*tracked,"assets/characters/traveller-departure-sides-v1.png"]))\ngraph=runner.prepare_runtime_stage(ROOT,project,tracked)')
body=body.replace("donor.parent == Path", "donor.parent == Path")
cut=body.index("donor=Path(")
body=body[:cut]+'''
if sys.argv[1]=="import":
    runner.launch(base,project,graph,"import",[runner.ENGINE,"--headless","--path",project,"--editor","--import","--quit"],runner.environment(base))
    runner.collect_imports(base,project,graph)
else:
    original = runner.copy_imports
    raw = helper_source = sys.modules.get("native")
    assert Path(sys.argv[2]).resolve().parent==HERE
    runner.copy_imports(Path(sys.argv[2]),project,graph)
    runner.MARKER="PASS: actual imported stop-source fingerprints"
    runner.launch(base,project,graph,"register",[runner.ENGINE,"--headless","--path",project,"--script","res://"+fixture],runner.environment(base))
    print((base/"captures/registration.json").read_text("utf8"))
print(base)
'''
body=body.replace("donor.parent == Path(\"E:/Snapland-QA/art16-right-stop-20261119/native\")","donor.parent == QA")
body=body.replace('    original = runner.copy_imports\n    raw = helper_source = sys.modules.get("native")\n','')
exec(compile(body,str(here/"register_probe.py"),"exec"))

