from pathlib import Path
import hashlib,json
from PIL import Image,ImageDraw
import numpy as np
from scipy.ndimage import label
base=Path("E:/Snapland-QA/art16-traveller-departure-20261119")
repo=Path("C:/Users/stanl/Github/Snapland")
art=repo/"assets/characters"
generated=Path("C:/Users/stanl/.codex/generated_images/01a1e5dd-6423-7963-9dc5-b040851d2b6b")
sources={
    "left":"exec-a113bfdf-ec85-490b-bc5f-73d4f28dd589.png",
    "right":"exec-dc812e84-19d3-4539-85a7-6b1e265377b6.png",
}
areas=((70,346),(70,200),(200,276),(276,346))
def measure(first,second):
    a=first[:,:,3]>=128;b=second[:,:,3]>=128
    diff=(a^b)|(a&b&(np.abs(first[:,:,:3].astype(np.int16)-second[:,:,:3].astype(np.int16)).max(axis=2)>35))
    both=a|b
    return np.array([diff[i:j].sum()/both[i:j].sum() for i,j in areas])
def bake(neutral,draft,old_y,new_y,shift):
    out=neutral.copy()
    legs=Image.fromarray(draft[old_y:346]).resize((280,346-new_y),Image.Resampling.NEAREST)
    moved=Image.new("RGBA",(280,346-new_y))
    moved.paste(legs,(shift,0))
    out[new_y:346]=np.asarray(moved)
    return out
def knee_pixels(img):
    r,g,b,a=np.moveaxis(img[265:320].astype(np.int16),-1,0)
    return int(np.sum((a>128)&(r>140)&(r>g+20)&(g>b+18)))

def visible_component_count(img):
    components,count=label(img[:,:,3]>=128)
    sizes=np.bincount(components.ravel())[1:]
    return (sizes>20).sum()
layout=Image.new("RGB",(4*280,2*360),(222,218,201))
draw=ImageDraw.Draw(layout)
report={}
for row,(view,name) in enumerate(sources.items()):
    idle=np.asarray(Image.open(art/f"idle-stability-v1/{view}.png").convert("RGBA").crop((0,0,280,360)))
    walk_atlas=Image.open(art/f"walk-stability-v1/island-raw-{view}.png").convert("RGBA")
    walk=[np.asarray(walk_atlas.crop((280*i,0,280*(i+1),360))) for i in range(8)]
    old=np.array([measure(cel,idle) for cel in walk])
    new=Image.open(generated/name).convert("RGBA")
    width=new.width//2
    points=np.where(idle[:200,:,3]>=128)
    top=int(points[0].min())
    height=346-top
    expected_center=int((points[1].min()+points[1].max())//2)
    choices=[]
    for i in range(2):
        cell=new.crop((i*width,0,(i+1)*width,new.height))
        raw=cell.crop(cell.getchannel("A").point(lambda a:255 if a>=128 else 0).getbbox())
        ratio=height/raw.height
        part=raw.resize((round(raw.width*ratio),height),Image.Resampling.NEAREST)
        pic=Image.new("RGBA",(280,360))
        pic.paste(part,(expected_center-part.width//2,top))
        draft=np.asarray(pic)
        for sy in range(260,295,2):
            for dy in range(270,292,2):
                for shift in range(-10,11,2):
                    pose=bake(idle,draft,sy,dy,shift)
                    pre=pose[dy-1,:,3]>=128
                    post=pose[dy,:,3]>=128
                    seam=int(np.sum(pre^post))
                    if seam>10: continue
                    rough=np.abs(pose[dy-1,:,:3].astype(np.int16)-pose[dy,:,:3].astype(np.int16)).max(axis=1)
                    color_errors=int(((rough>90)&pre&post).sum())
                    if color_errors>17 or visible_component_count(pose)>2: continue
                    if knee_pixels(pose) < knee_pixels(idle)*0.65:continue
                    th=measure(pose,idle)
                    if not (0.10<th[3]<0.77):continue
                    mx=np.maximum(np.array([measure(cel,pose) for cel in walk]),th)
                    good=np.flatnonzero((mx[:,0] + .005<old[:,0])&(mx[:,3] + .01<old[:,3])&(mx[:,2]<=old[:,2]+.004)).tolist()
                    if not good:continue
                    improvement=float(np.sum((old[:,0]-mx[:,0])[good]))
                    rank=-(len(good)+improvement*2)+seam*.015+color_errors*.015
                    choices.append((rank,i,sy,dy,shift,good,mx.tolist(),th.tolist(),pose))
    choices.sort(key=lambda v:v[0])
    chosen=[]
    if choices:
        chosen.append(choices[0])
        if any(c[1]!=chosen[0][1] for c in choices):
            chosen.append(next(c for c in choices if c[1]!=chosen[0][1]))
    for col,image in enumerate([Image.fromarray(idle),*map(lambda r:Image.fromarray(r[-1]),chosen)]):
        layout.paste(image,(col*280,row*360),image)
        draw.text((col*280+9,row*360+13),view+(" neutral" if col==0 else f" study {col}"),fill=(22,32,36))
        if col>0:image.save(base/f"{view}-refined-{col}.png")
    report[view]={"atlas":name,"sha256":hashlib.sha256((generated/name).read_bytes()).hexdigest(),
        "old":old.tolist(),"count":len(choices),"chosen":[r[:-1] for r in chosen]}
    print(view,len(choices),[(c[1],c[3],c[5]) for c in chosen],flush=True)
layout.save(base/"two-side-departure.png")
(base/"two-side-departure.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf8")
