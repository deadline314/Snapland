extends "res://game/tests/native_island_animation_acceptance.gd"

var _inside_guide_range := false

func _focus_live_actor() -> void:
	super._focus_live_actor()
	if not _inside_guide_range: return
	for point in _world.points:
		if String(point.id) != "guide": continue
		_world.player.global_position = point.position + Vector3(0.0, 0.3, 0.0)
		return

func _npc_actions() -> void:
	var progress := get_tree().root.get_node("Progress")
	var photo := "photo-welcome-story-1"
	if not await _open_guide(): return
	_tap(KEY_ESCAPE)
	await _frames(3)
	var cancelled: bool = _main.modal_kind == "" and not progress.photos.has(photo) and _current_action() != "interact"
	await _record_action("guide-cancel", _current_action(), _current_direction(), _current_source(), _actor_anchor(), cancelled)
	if not cancelled or not await _open_guide(): return
	await _capture("actual-guide-dialogue")
	var limit: int = _main.dialogue.size() * 3 + 2
	while _main.modal_kind == "dialogue" and limit > 0:
		limit -= 1
		_tap(KEY_E)
		await _frames(1)
	_inside_guide_range = false
	var awarded: bool = _main.modal_kind == "" and progress.photos.has(photo)
	var anchored := _actor_anchor()
	var playback := await _observe_npc_sequence("interact", awarded)
	var fixed_root := anchored == _actor_anchor()
	playback["anchored"] = fixed_root
	playback["photo_awarded"] = awarded
	await _record_action("first-guide-stamp", "interact", "front", "authored", anchored, bool(playback.complete) and fixed_root, playback)
	if not bool(playback.complete): return
	var previous_count: int = progress.photos.size()
	if not await _open_guide(): return
	limit = _main.dialogue.size() * 3 + 2
	while _main.modal_kind == "dialogue" and limit > 0:
		limit -= 1
		_tap(KEY_E)
		await _frames(1)
	_inside_guide_range = false
	var repeated: bool = _main.modal_kind == "" and progress.photos.size() == previous_count and _current_action() != "interact"
	await _record_action("guide-repeat", _current_action(), _current_direction(), _current_source(), _actor_anchor(), repeated)
	await _wait_npc_settle()

func _open_guide() -> bool:
	_inside_guide_range = true
	for index in range(12):
		await _frames(1)
		if String(_world.nearest.get("id", "")) != "guide": continue
		_tap(KEY_E)
		await _frames(1)
		if _main.modal_kind == "dialogue": return true
	_fail("E did not open real guide dialogue")
	return false

func _tap(key: Key) -> void:
	_press(key, true)
	_press(key, false)
