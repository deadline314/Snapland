from pathlib import Path
here=Path(__file__).resolve().parent
source=(here.parent/"art17-traveller-celebration-20261119/verify.py").read_text("utf8")
source=source.replace("art17-traveller-celebration-20261119",here.name)
source=source.replace("native_avatar_celebration_study","native_ticket_stamp_study")
source=source.replace("AvatarCelebrationQA.exe","TicketStampQA.exe")
start=source.index('start=source.index(')
source=source[:start]+"""
source=source.replace('res://"+FIXTURE+"', 'res://"+FIXTURE+"')
source=source.replace('exec(compile(source,str(here/"final_checks.py"),"exec"))',
    'source=source.replace("--actor=traveller","--actor=ticket").replace("traveller-report.json","ticket-report.json")\\n'+
    'exec(compile(source,str(here/"final_checks.py"),"exec"))')
start=source.index('    if mode!="reduced":')
end=source.index("''' + source[end:]",start)
source=source[:start]+'''    if mode!="reduced":
        cases={row["label"]:row for row in report["actions"]}
        assert all(cases[name]["predicate"] for name in ("guide-cancel","first-guide-stamp","guide-repeat"))
        proof=cases["first-guide-stamp"]["detail"]
        assert proof["source_frame_count"]==8 and proof["anchored"] and proof["photo_awarded"]
''' + source[end:]
exec(compile(source,str(here/"verify.py"),"exec"))
"""
exec(compile(source,str(here/"verify.py"),"exec"))
