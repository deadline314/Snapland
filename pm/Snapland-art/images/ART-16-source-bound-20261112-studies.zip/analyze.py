from pathlib import Path
import json
import numpy as np
from PIL import Image
base=Path(__file__).resolve().parent
result={}
for side in ('right','left'):
 a=np.array(Image.open(base/(side+'-eight-candidate.png')))
 h,w=a.shape[:2]
 frames=[]
 for row in range(2):
  y0,y1=round(row*h/2),round((row+1)*h/2)
  ground=int(np.where((a[y0:y1,:,3]>128).any(axis=1))[0][-1])+1
  for col in range(4):
   x0,x1=round(col*w/4),round((col+1)*w/4)
   body=a[y0:y1,x0:x1,3]>128
   yy,xx=np.where(body)
   bx0,bx1=int(xx.min()),int(xx.max())+1
   by0,by1=int(yy.min()),int(yy.max())+1
   rx0,rx1=max(0,bx0-2),min(x1-x0,bx1+2)
   ry0,ry1=max(0,by0-2),min(y1-y0,ground+2)
   frames.append({'source':'res://assets/characters/announcer-walk-'+side+'-v3.png','region':[x0+rx0,y0+ry0,rx1-rx0,ry1-ry0],'anchors':{'feet':[round((x1-x0)/2)-rx0,ground-ry0],'head':[round((x1-x0)/2)-rx0,by0-ry0]},'source_scale':0.40,'layers':[], 'analysis':{'bottom_gap':ground-by1,'top':by0,'body_width':bx1-bx0,'body_height':by1-by0,'cell_root':x0+round((x1-x0)/2),'ground':y0+ground}})
 result[side]=frames
 print(side, (w,h), [f['analysis'] for f in frames])
(base/'candidate-frames.json').write_text(json.dumps(result,indent=2))
