extends SceneTree
const OUT = "C:/Users/stanl/Github/Snapland/.review/announcer-poseguide-20261112/"
var old_frames: Array[Texture2D] = []
var new_frames: Array[Texture2D] = []
var old_sprite: Sprite2D
var new_sprite: Sprite2D
var ticks := 0
func _initialize():
 call_deferred("run")
func run():
 root.size=Vector2i(1100,600)
 var library=preload("res://game/world/character_animation_library.gd").new()
 var stable_path="res://assets/characters/walk-stability-v1/announcer-walk-right.png"
 library._stable_walk_pixels.images[stable_path]=Image.load_from_file(stable_path)
 var source=Image.load_from_file(OUT+"right-eight-candidate.png")
 assert(source != null)
 var path="res://.review/announcer-poseguide-20261112/right-eight-candidate.png"
 library._images[path]=source
 var report=[]
 for i in range(8):
  var col=i%4
  var row=i/4
  var x0=roundi(float(col)*source.get_width()/4.0)
  var x1=roundi(float(col+1)*source.get_width()/4.0)
  var y0=0 if row==0 else 550
  var ground=489 if row==0 else 999
  var frame={"source":path,"region":[x0,y0,x1-x0,ground-y0+2],"anchors":{"feet":[roundi(float(x1-x0)/2.0),ground-y0],"head":[roundi(float(x1-x0)/2.0),121 if row==0 else 75]},"source_scale":0.40,"layers":[]}
  var texture=library._render_frame("announcer","study","right",i,frame,{},true)
  assert(texture!=null)
  new_frames.append(texture)
  texture.get_image().save_png(OUT+"new-%02d.png"%i)
  report.append(frame)
 for i in range(4):
  var texture=library.texture("announcer","walk","right",i)
  old_frames.append(texture)
  texture.get_image().save_png(OUT+"old-%02d.png"%i)
 FileAccess.open(OUT+"frames.json",FileAccess.WRITE).store_string(JSON.stringify(report,"  "))
 var canvas=Node2D.new()
 root.add_child(canvas)
 var background=ColorRect.new()
 background.color=Color("637f70")
 background.size=Vector2(1100,600)
 canvas.add_child(background)
 for x in [50,600]:
  var line=ColorRect.new()
  line.position=Vector2(x,548)
  line.size=Vector2(450,2)
  line.color=Color("d8dfb1")
  canvas.add_child(line)
  var label=Label.new()
  label.position=Vector2(x+80,30)
  label.text="CURRENT 4 POSES / 7 FPS" if x==50 else "STUDY 8 POSES / 14 FPS"
  canvas.add_child(label)
 old_sprite=Sprite2D.new()
 new_sprite=Sprite2D.new()
 for sprite in [old_sprite,new_sprite]:
  sprite.centered=false
  sprite.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
  canvas.add_child(sprite)
 old_sprite.position=Vector2(115,100)
 new_sprite.position=Vector2(665,100)
 old_sprite.texture=old_frames[0]
 new_sprite.texture=new_frames[0]
func _process(_delta):
 if new_frames.is_empty():return false
 var seconds=float(ticks)/30.0
 var speed=1.0 if seconds<4.0 else 0.25
 var elapsed=seconds if seconds<4.0 else 4.0+(seconds-4.0)*speed
 old_sprite.texture=old_frames[int(elapsed*7)%4]
 new_sprite.texture=new_frames[int(elapsed*14)%8]
 ticks+=1
 if ticks==241:
  capture.call_deferred()
 if ticks>=360:quit()
 return false
func capture():
 await RenderingServer.frame_post_draw
 root.get_texture().get_image().save_png(OUT+"comparison.png")
