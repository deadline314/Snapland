"""Run focused suites and packaged playback against the tracked profile-wave source."""
from pathlib import Path

here=Path(__file__).resolve().parent
template=here.parent/"art16-20261119/verify_departure.py"
source=template.read_text("utf8")
source=source.replace("D:/Snapland-QA/art16-20261119","D:/Snapland-QA/art17-side-wave-20261119")
source=source.replace('ART_FILE = "assets/characters/announcer-departure-sides-v1.png"',
    'ART_FILES = ["assets/characters/traveller-wave-left-v1.png","assets/characters/traveller-wave-right-v1.png"]')
source=source.replace("paths = list(dict.fromkeys([*paths, ART_FILE]))","paths = list(dict.fromkeys([*paths, *ART_FILES]))")
start=source.index("FIXTURE =")
end=source.index("paths = subprocess.check_output",start)
source=source[:start]+'''FIXTURE = "game/tests/native_profile_wave_study"
PROBE = runner.QA/"profile-native-1119-062042-311a38/project"
TESTS = {
    "test_avatar_motion_world": "PASS: integrated avatar motion world checks",
    "test_avatar": "PASS: avatar runtime checks",
    "test_garment_overlay": "PASS: garment overlay preserves 182 original compositions; missing last cel falls back across all eight directions",
}
runner.FIXTURES = [
    FIXTURE + ".gd", FIXTURE + ".tscn",
    "game/tests/native_island_animation_acceptance.gd",
    *["game/tests/" + name + ".gd" for name in TESTS],
]

def fixture_source(name):
    return (PROBE if name.startswith(FIXTURE+".") else ROOT)/name

'''+source[end:]
source=source.replace("runner.sha(ROOT/name) for name in runner.FIXTURES","runner.sha(fixture_source(name)) for name in runner.FIXTURES")
source=source.replace("shutil.copy2(ROOT/name,target)","shutil.copy2(fixture_source(name),target)")
source=source.replace("AnnouncerDepartureQA.exe","AvatarWaveQA.exe")
source=source.replace('"--actor=announcer"','"--actor=traveller"')
start=source.index('    report=runner.read(out/"announcer-report.json")')
end=source.index('    assert movie.stat().st_size',start)
source=source[:start]+'''    report=runner.read(out/"traveller-report.json")
    assert report["technical_status"]=="PASS" and not report["failures"]
    assert report['playback_mode'].startswith("quarter" if mode=="quarter" else "normal")
    cases=[row for row in report["actions"] if row["label"].endswith("-profile-wave")]
    assert report["scene_rebuild"] == (mode=="quarter")
    assert len(cases)==6
    assert all(row["predicate"] and row["detail"]["root_drift"]==0 for row in cases)
    assert {(row["label"],row["direction"]) for row in cases}=={
        (look+"-profile-wave",side) for look in ("base","rainvest","hat-and-bob") for side in ("left","right")}
'''+source[end:]
exec(compile(source,str(here/"final_checks.py"),"exec"))
