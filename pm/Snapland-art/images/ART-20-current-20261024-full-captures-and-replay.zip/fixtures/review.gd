extends "res://game/tests/native_layout_review.gd"
var records: Array[Dictionary]=[]
func _run() -> void:
 progress=get_tree().root.get_node("Progress")
 progress.reset_progress();progress.intro_seen=true
 main=_instantiate_main();get_tree().root.add_child(main);await _frames(8)
 var sizes := [Vector2i(1280,720),Vector2i(800,600),Vector2i(1920,1080)]
 if OS.get_environment("SNAPLAND_MAP_COMPACT_ONLY")=="1":sizes=[Vector2i(800,600)]
 if OS.get_environment("SNAPLAND_MAP_LARGE_ONLY")=="1":sizes=[Vector2i(1920,1080)]
 for dimensions in sizes:
  progress.set_setting("ui_scale",1.25 if dimensions.x!=1280 else 1.0)
  if not await _resize_window(dimensions):return
  get_window().position=Vector2i.ZERO
  await _tap_key(KEY_M)
  await _frames(3)
  var map_button := _find_text_button(main.overlay,"島嶼地圖")
  if map_button==null or not await _native_click_button(map_button,"open map through travel pass"):return
  await _frames(10)
  var canvas: Control=main.overlay.find_child("IslandChartCanvas",true,false)
  var rows: Array[Dictionary]=[]
  for gate in canvas.get_children():
   if not gate is Button or not str(gate.name).begins_with("MapGate_"):continue
   var overlaps: Array[String]=[]
   for other in canvas.get_children():
    if other is Button and other!=gate and gate.get_global_rect().intersects(other.get_global_rect()):overlaps.append(str(other.name))
   rows.append({"name":str(gate.name),"text":gate.text,"rect":var_to_str(gate.get_global_rect()),"minimum":var_to_str(gate.get_combined_minimum_size()),"inside":canvas.get_global_rect().encloses(gate.get_global_rect()),"overlaps":overlaps})
  var viewed_stations: Array[String]=[]
  var visited: Array[String]=[]
  for i in 32:
   await _tap_key(KEY_TAB)
   var focus := get_viewport().gui_get_focus_owner()
   if focus is Button and str(focus.name) in ["MapStop_game-005","MapStop_game-012"] and not viewed_stations.has(str(focus.name)):
    viewed_stations.append(str(focus.name));await _frames(3)
    await RenderingServer.frame_post_draw
    get_viewport().get_texture().get_image().save_png(OS.get_environment("SNAPLAND_SAVE_PATH").get_base_dir()+"/%s-%d.png"%[str(focus.name),dimensions.x])
   if focus is Button and str(focus.name).begins_with("MapGate_") and not visited.has(str(focus.name)):
    visited.append(str(focus.name))
    var pressed := {"count":0}
    focus.pressed.connect(func(): pressed.count+=1,CONNECT_ONE_SHOT)
    await _tap_key(KEY_ENTER)
    if pressed.count!=1:await _fail("Map gate keyboard activation failed");return
  if visited.size()!=9:await _fail("Actual Tab routing did not reach all nine gates: "+str(visited));return
  for gate in canvas.get_children():
   if gate is Button and str(gate.name).begins_with("MapGate_"):
    if not await _native_click_button(gate,"select "+str(gate.name)):return
  records.append({"width":dimensions.x,"canvas":var_to_str(canvas.get_global_rect()),"gates":rows,"keyboard_activated":visited,"pointer_activated":9})
  await RenderingServer.frame_post_draw
  get_viewport().get_texture().get_image().save_png(OS.get_environment("SNAPLAND_SAVE_PATH").get_base_dir()+"/map-%d.png"%dimensions.x)
  await _tap_key(KEY_ESCAPE);await _frames(4)
  if main.modal_kind!="" or main.world.blocked:await _fail("Map Escape failed to restore park");return
 var f=FileAccess.open(OS.get_environment("SNAPLAND_SAVE_PATH").get_base_dir()+"/map.json",FileAccess.WRITE);f.store_string(JSON.stringify(records,"  "))
 print("PASS: map geometry diagnostic captured; visual/input acceptance separate")
 main.audio.shutdown();await _frames(4);get_tree().quit()
