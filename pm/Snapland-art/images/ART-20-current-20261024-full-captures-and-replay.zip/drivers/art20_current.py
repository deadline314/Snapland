from pathlib import Path
import os,json,time,subprocess
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();stage=r/'work/tutorial-current-20261020/validation-project';base=r/'work/remaining-20261024/art20-current';base.mkdir(exist_ok=False)
for name,size,scale,phase,reduced in [('standard','1280x720','1','noon',False),('compact','800x600','1.25','night',True),('large','1920x1080','1.25','dusk',False)]:
 out=base/name;out.mkdir();args=[str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'),'--path',str(stage),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--resolution',size,'--log-file',str(out/'engine.log'),'res://game/tests/native_pixel_ui_review.tscn','--',f'--ui-size={size}',f'--ui-scale={scale}',f'--ui-phase={phase}',f'--ui-prefix=art20-current-{name}']
 if reduced:args.append('--ui-reduced-motion')
 t=time.monotonic()
 try:
  p=run_validated_godot(stage,args,dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'progress.json')),240);s=p.stdout+p.stderr;d=dict(exit=p.returncode,errors=s.count('ERROR:'),complete='PASS: native pixel UI presentation' in s)
 except subprocess.TimeoutExpired as e:
  s=(e.stdout or '')+(e.stderr or '');d=dict(exit='timeout',errors=s.count('ERROR:'),complete=False)
 d['seconds']=round(time.monotonic()-t,2);(out/'result.log').write_text(s);(out/'result.json').write_text(json.dumps(d,indent=2));print(name,d,s[-1000:],flush=True)
 if not(d['exit']==0 and d['errors']==0 and d['complete']):break
