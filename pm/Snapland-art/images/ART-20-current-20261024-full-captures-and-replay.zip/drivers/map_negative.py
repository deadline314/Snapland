from pathlib import Path
import os,json,subprocess,time,shutil
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();stage=r/'work/tutorial-current-20261020/validation-project';out=r/'work/remaining-20261024/map-negative';out.mkdir(exist_ok=False);f='game/ui/island_map_panel.gd';shutil.copy2(r/f,stage/f)
try:
 (stage/f).write_bytes(subprocess.check_output(['git','show','HEAD:'+f]));t=time.monotonic();p=run_validated_godot(stage,[str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'),'--headless','--path',str(stage),'--audio-driver','Dummy','--rendering-method','gl_compatibility','res://game/tests/test_travel_book_ui.tscn'],dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'progress.json')),90);s=p.stdout+p.stderr;(out/'result.log').write_text(s);d=dict(exit=p.returncode,seconds=round(time.monotonic()-t,2),expected_failure=p.returncode!=0 and 'all nine future gate targets remain distinct' in s);(out/'result.json').write_text(json.dumps(d,indent=2));print(d,flush=True);assert d['expected_failure']
finally:shutil.copy2(r/f,stage/f)
