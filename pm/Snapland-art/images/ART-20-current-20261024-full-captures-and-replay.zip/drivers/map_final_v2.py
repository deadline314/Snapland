from pathlib import Path
import os,json,time,shutil,subprocess
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();stage=r/'work/tutorial-current-20261020/validation-project';out=r/'work/remaining-20261024/map-final-v2';out.mkdir(exist_ok=False)
src=r/'work/remaining-20261024/map-native';target=stage/'work/remaining-20261024/map-native';target.mkdir(parents=True,exist_ok=True)
for p in src.iterdir():shutil.copy2(p,target/p.name)
t=time.monotonic();args=[str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'),'--path',str(stage),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--resolution','1920x1080','--fixed-fps','60','--log-file',str(out/'engine.log'),'res://work/remaining-20261024/map-native/entry.tscn','--','--review-fixed-clock','--capture-dir=.review/art21-current-20261024-v1']
rec=subprocess.Popen(['ffmpeg','-n','-v','error','-f','x11grab','-video_size','1920x1080','-framerate','15','-i',os.environ['DISPLAY'],'-t','120','-c:v','libx264','-threads','1','-preset','ultrafast','-crf','22','-pix_fmt','yuv420p',str(out/'native.mp4')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
try:
 p=run_validated_godot(stage,args,dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'progress.json')),120);text=p.stdout+p.stderr;d=dict(exit=p.returncode,errors=text.count('ERROR:'),complete='PASS: map geometry diagnostic' in text)
except subprocess.TimeoutExpired as e:
 text=(e.stdout or '')+(e.stderr or '');d=dict(exit='timeout',errors=text.count('ERROR:'),complete=False)
_,err=rec.communicate('q\n',timeout=15);(out/'record.log').write_text(err)
(out/'result.log').write_text(text);d['seconds']=round(time.monotonic()-t,2);(out/'result.json').write_text(json.dumps(d,indent=2));print(d,text[-1600:],flush=True)
assert d['exit']==0 and d['errors']==0 and d['complete']
