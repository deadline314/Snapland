extends SceneTree
const Avatar = preload("res://game/world/avatar_renderer.gd")

func _initialize() -> void:
	var avatar := Avatar.new()
	var out := OS.get_environment("COTTON_CAPTURE_DIR")
	var result := {}
	for side in ["front","front_right","back_right","back","back_left","front_left"]:
		var source := avatar.original_garment_pose("depart",side,0)
		var neutral := avatar.original_garment_pose("idle",side,0)
		if source == null or neutral == null or source.save_png(out.path_join(side+"-depart.png"))!=OK:
			quit(1)
			return
		var head := avatar.walk_head_anchor(side,avatar.walk_idle_frame(side))
		result[side] = {"head":[head.x,head.y],"source":avatar.head_source_signature(source),"neutral":avatar.head_source_signature(neutral)}
	var file := FileAccess.open(out.path_join("registration.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify(result,"  "))
	file.close()
	print("PASS: actual imported stop-source fingerprints")
	quit(0)



