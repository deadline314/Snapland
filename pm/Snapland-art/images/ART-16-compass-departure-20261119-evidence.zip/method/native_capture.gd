extends "res://game/tests/native_island_animation_acceptance.gd"

func _hero_actions() -> void:
	var original: Dictionary = _world.avatar_appearance.duplicate(true)
	for look: String in ["default", "rainvest", "live-hair"]:
		var appearance := original.duplicate()
		if look != "default": appearance.hair = "bob"
		var gear := {"outfit":"outfit-rainvest" if look == "rainvest" else "outfit-tide",
			"hat":"hat-straw" if look == "rainvest" else "hat-none"}
		_world.set_avatar_look(appearance, gear)
		_world.set_avatar_hair_motion_enabled(look == "live-hair")
		for side: String in ["front", "front_right", "right", "back_right", "back", "back_left", "left", "front_left"]:
			var outcome := await _observe_departure(side, look)
			await _record_action(look+"-"+side+"-departure", "depart", side, "authored", _actor_anchor(), bool(outcome.get("complete",false)), outcome)
			if not bool(outcome.get("complete",false)): return

func _observe_departure(side: String, look: String) -> Dictionary:
	var keys: Array = {"front":[KEY_S],"front_right":[KEY_S,KEY_D],"right":[KEY_D],"back_right":[KEY_W,KEY_D],"back":[KEY_W],"back_left":[KEY_W,KEY_A],"left":[KEY_A],"front_left":[KEY_S,KEY_A]}[side]
	var point := Vector3(-3.2, 0, -5.5)
	point.y = _world.ground_surface_y(point)
	_world.player.global_position = point
	await _physics_frames(4)
	# A real approach first establishes the direction. The second departure has
	# a clean relocation and the same settled heading.
	for key: Key in keys: _press(key, true)
	await _observe_for(0.42)
	for key: Key in keys: _press(key, false)
	await _observe_for(0.40)
	if _world.facing != side or _world.last_avatar_source_action != "idle":
		return {"complete":false, "reason":"approach did not establish the requested stationary heading"}
	_world.player.global_position = point
	await _physics_frames(4)
	var before: Vector3 = _world.player.global_position
	var prior_phase: float = _world.walk_distance_phase
	for key: Key in keys: _press(key, true)
	var started := _simulated_seconds
	while _simulated_seconds-started < 0.25 and _within_budget():
		await RenderingServer.frame_post_draw
		if _world.last_avatar_source_action != "depart": continue
		var first: Vector3 = _world.player.global_position
		var phase_at_first: float = _world.walk_distance_phase
		var elapsed := _simulated_seconds
		var expected: Texture2D = _world.avatar_renderer.texture(_world.avatar_appearance,_world.avatar_equipped,side,0,"depart")
		var rig: bool = _world.avatar_hair_rig != null and _world.avatar_hair_rig.active and _world.avatar_hair_rig.pose_key.begins_with(side+"|depart|0|")
		var matched: bool = rig if look == "live-hair" else _world.avatar.texture == expected
		_store_capture(look+"-"+side+"-takeoff",get_viewport().get_texture().get_image())
		while _world.last_avatar_source_action == "depart" and _simulated_seconds-elapsed < 0.25 and _within_budget():
			await RenderingServer.frame_post_draw
		var moved: float = first.distance_to(_world.player.global_position)
		var detail := {"complete":matched and _world.facing == side and _world.last_avatar_action == "walk"
			and _world.last_avatar_source_action == "walk" and _world.last_avatar_frame == 0 and before.distance_to(first) > 0.0
			and moved > 0.01 and phase_at_first > prior_phase and _world.walk_distance_phase > phase_at_first,
			"source_matches":matched,"live_hair":rig,"first_displacement":before.distance_to(first),"takeoff_travel":moved,
			"phase_before":prior_phase,"phase_first":phase_at_first,"phase_after":_world.walk_distance_phase,
			"first_walk_cel":_world.last_avatar_frame,"held_simulation_seconds":_simulated_seconds-elapsed}
		for key: Key in keys: _press(key, false)
		await _observe_for(0.40)
		return detail
	for key: Key in keys: _press(key, false)
	return {"complete":false,"reason":"no takeoff after grounded same-heading input"}

func _observe_for(seconds: float) -> void:
	var from := _simulated_seconds
	while _simulated_seconds-from < seconds and _within_budget():
		await RenderingServer.frame_post_draw



