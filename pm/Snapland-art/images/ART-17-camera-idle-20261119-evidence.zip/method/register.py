from pathlib import Path
import hashlib
import json

assets = Path("assets/characters")
base = Path("D:/Snapland-QA/art17-idle-camera-20261119")
owner_base = base / "camera-idle-owner-boundaries-1119-064548-06edcc"
look_base = base / "camera-idle-registered-1119-064602-527ae5"
receipt = json.loads((look_base / "receipt.json").read_text("utf8"))
assert receipt["passed"] and not receipt["errors"]
registered = json.loads((look_base / "captures/preview.json").read_text("utf8"))
entries = json.loads((owner_base / "captures/owner-candidates.json").read_text("utf8"))["owners"]
assert len(registered) == len(entries) == 3
assert all(row["head_owner"] and row["source_sha256"] in entries for row in registered)

owners = assets / "avatar-head-material-owners-v1.json"
text = owners.read_text("utf8")
original = json.loads(text)
for row in entries.values():
    row["review"] = "camera check: registered closed-eye, forelock, face and fabric boundary"
assert all(original["owners"].get(key, value) == value for key, value in entries.items())
entries = {key: value for key, value in entries.items() if key not in original["owners"]}
tail = '\n  }\n}\n'
assert text.endswith(tail)
content = text if not entries else text[:-len(tail)] + ",\n" + ",\n".join(
    f'    "{key}": ' + json.dumps(row, separators=(",", ":"), ensure_ascii=False)
    for key, row in sorted(entries.items())
) + tail
new = json.loads(content)
assert all(new["owners"][key] == value for key, value in original["owners"].items())
owners.write_text(content, encoding="utf8", newline="\n")

deps = assets / "island-hair-alternate-owners-v1.json"
text = deps.read_text("utf8")
dep, = [dep for dep in json.loads(text)["dependencies"] if dep["source"] == "res://" + owners.as_posix()]
assert text.count(dep["source_sha256"]) == 1
deps.write_text(text.replace(dep["source_sha256"], hashlib.sha256(content.encode("utf8")).hexdigest()), encoding="utf8", newline="\n")

wardrobe = assets / "rainvest-v1/manifest.json"
text = wardrobe.read_text("utf8")
old = json.loads(text)
row, = [row for row in old["frames"] if (row["action"], row["direction"], row["frame"]) == ("idle", "front", 0)]
assert len(old["frames"]) == 182
additions = [{**row, "action": "idle_gesture", "frame": pose["frame"], "source_pixel_sha256": pose["source_sha256"]} for pose in registered]
tail = '\n  ],\n  "encoding": "png_bytes_without_import_conversion"\n}\n'
assert text.endswith(tail)
content = text[:-len(tail)] + ",\n" + ",\n".join("    " + json.dumps(item, indent=2).replace("\n", "\n    ") for item in additions) + tail
assert json.loads(content)["frames"][:-3] == old["frames"]
wardrobe.write_text(content, encoding="utf8", newline="\n")
