"""Run current camera idle scenes with the pinned native acceptance driver."""
from pathlib import Path

here = Path(__file__).resolve().parent
template = here.parent / "art16-20261119/verify_departure.py"
source = template.read_text("utf8")
source = source.replace("D:/Snapland-QA/art16-20261119", "D:/Snapland-QA/art17-idle-camera-20261119")
source = source.replace('ART_FILE = "assets/characters/announcer-departure-sides-v1.png"',
                        'ART_FILE = "assets/characters/traveller-camera-check-front-v1.png"')
start = source.index("FIXTURE =")
end = source.index("paths = subprocess.check_output",start)
source = source[:start] + '''FIXTURE = "game/tests/native_camera_idle_acceptance"
TESTS = {
    "test_avatar_motion_world": "PASS: integrated avatar motion world checks",
    "test_garment_overlay": "PASS: garment overlay preserves 185 original compositions; missing last cel falls back across all eight directions",
    "test_island_hair_lifecycle": "PASS: island hair lifecycle retains live walk phase through appearance, motion and reduced-motion changes",
}
runner.FIXTURES = [FIXTURE + ".gd", FIXTURE + ".tscn", "game/tests/native_island_animation_acceptance.gd",
                   *["game/tests/" + name + ".gd" for name in TESTS]]
def fixture_source(name):
    return {FIXTURE+".gd": HERE/"native_capture.gd", FIXTURE+".tscn": HERE/"native_capture.tscn"}.get(name,ROOT/name)
''' + source[end:]
source = source.replace("runner.sha(ROOT/name) for name in runner.FIXTURES", "runner.sha(fixture_source(name)) for name in runner.FIXTURES")
source = source.replace("shutil.copy2(ROOT/name,target)", "shutil.copy2(fixture_source(name),target)")
source = source.replace("AnnouncerDepartureQA.exe", "AvatarCameraIdleQA.exe")
source = source.replace('"normal":[]', '"normal":["--camera-idle-full-wait"]')
source = source.replace('"--actor=announcer"', '"--actor=traveller"')
start = source.index('    report=runner.read(out/"announcer-report.json")')
end = source.index("    assert movie.stat().st_size", start)
source = source[:start] + '''    report = runner.read(out/"traveller-report.json")
    assert report["technical_status"] == "PASS" and not report["failures"]
    assert report["playback_mode"].startswith("quarter" if mode=="quarter" else "normal")
    assert report["reduced_motion"] == (mode=="reduced")
    assert report["scene_rebuild"] == (mode in ("quarter","reduced"))
    actions = [item for item in report["actions"] if item["label"].endswith("-camera-check")]
    if mode=="reduced":
        assert not actions and any(item["label"]=="reduced-motion" and item["predicate"] for item in report["actions"])
    else:
        assert len(actions)==3 and all(item["predicate"] for item in actions)
        assert sum(not item["detail"]["world_clock_accelerated"] for item in actions)==(1 if mode=="normal" else 0)
''' + source[end:]
exec(compile(source,str(here/"final_checks.py"),"exec"))
