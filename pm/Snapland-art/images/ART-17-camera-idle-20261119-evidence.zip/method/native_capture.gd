extends "res://game/tests/native_island_animation_acceptance.gd"

var capture_prefix := "camera"

func _store_capture(label: String, image: Image, framing: Dictionary = {}) -> void:
	super._store_capture(capture_prefix + "-" + label, image, framing)

func _hero_actions() -> void:
	_world.set_avatar_hair_motion_enabled(false)
	var original: Dictionary = _world.avatar_appearance.duplicate(true)
	var full_wait := OS.get_cmdline_user_args().has("--camera-idle-full-wait")
	for look in ["base", "rainvest", "bob-and-straw"]:
		capture_prefix = look
		var appearance := original.duplicate()
		if look == "bob-and-straw": appearance.hair = "bob"
		var gear := {"outfit": "outfit-rainvest" if look == "rainvest" else "outfit-tide",
			"hat": "hat-straw" if look == "bob-and-straw" else "hat-none"}
		_world.set_avatar_look(appearance, gear)
		_press(KEY_S, true)
		await _physics_frames(8)
		_press(KEY_S, false)
		var resting := await _wait_hero_settle()
		if not resting.complete or _world.facing != "front":
			_fail("Inputs did not reach the front stance")
			return
		var action := "idle_gesture"
		var root_before: Vector3 = _world.player.global_position
		var original_epoch: float = _world._avatar_idle_started_at
		var full: bool = full_wait and look == "base"
		if not full: _world.time = original_epoch + 17.82
		var started := _simulated_seconds
		var root_drift := 0.0
		var entered_at := -1.0
		var after := -1
		_begin_observation("hero_sequence", action)
		while _simulated_seconds - started < (21.0 if full else 2.0) and _within_budget():
			await RenderingServer.frame_post_draw
			root_drift = maxf(root_drift, root_before.distance_to(_world.player.global_position))
			if _world.last_avatar_action == action:
				if entered_at < 0.0: entered_at = float(_world.time) - original_epoch
			elif entered_at >= 0.0:
				after = int(_world.last_avatar_frame)
				break
		var observed := _end_observation()
		_flush_buffered_captures()
		await _capture("return")
		var garment_ok: bool = _world.avatar_renderer.garment_overlays.ready(_world.avatar_renderer)
		var complete: bool = observed.frames.size() == 3 and bool(observed.source_consistent)
		complete = complete and after == 0 and _world.facing == "front" and root_drift <= 0.00001
		complete = complete and entered_at >= 18.0 and entered_at < 18.20 and garment_ok
		await _record_action(look + "-camera-check", action, "front", "authored", _actor_anchor(), complete,
			{"world_clock_accelerated": not full, "wait_until_gesture": entered_at,
			 "root_drift": root_drift, "returned_frame": after, "observed": observed, "garment_ready": garment_ok})
