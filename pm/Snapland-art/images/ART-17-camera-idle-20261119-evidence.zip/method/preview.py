"""Render registered camera-check cels and compile owner candidates in an isolated project."""
from pathlib import Path
import importlib.util
import json
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
HELPER = ROOT / ".review/cotton-wind-20261118/final-fix/native_run.py"
SPEC = importlib.util.spec_from_file_location("native_runner", HELPER)
run = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(run)
run.QA = Path("D:/Snapland-QA/art17-idle-camera-20261119")
manifest_name = "assets/characters/complete-animation-regions.json"
art_name = "assets/characters/traveller-camera-check-front-v1.png"
owner_name = "assets/characters/avatar-head-material-owners-v1.json"
preview_script = "game/tests/camera_check_preview.gd"
owner_script = "game/tests/camera_check_owner_study.gd"
source = Path("C:/Users/stanl/.codex/generated_images/01a1e5dd-6423-7963-9dc5-b040851d2b6b/exec-9a9d1b33-c795-4de5-aada-9e2f3ab3e046.png")
poses = [
    ([315, 89, 274, 526], [137, 518], [146, 8]),
    ([941, 89, 275, 526], [137, 518], [147, 8]),
    ([1567, 89, 275, 526], [137, 518], [146, 8]),
]
clip = {"fps": 8, "loop": False, "frame_durations": [0.20,0.40,0.28],
        "frames": [
            {"source": "res://" + art_name, "region": region, "anchors": {"feet":feet, "head":head},
             "source_scale": 274 / 816, "layers": []}
            for region, feet, head in poses]}

PREVIEW = r'''extends SceneTree
const Renderer := preload("res://game/world/avatar_renderer.gd")

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var renderer := Renderer.new()
	var frames := renderer.authored_frame_count("idle_gesture", "front")
	assert(frames==3)
	var out := OS.get_environment("COTTON_CAPTURE_DIR")
	var rows: Array = []
	var baseline: Image = renderer.original_garment_pose("idle","front",0)
	assert(baseline.save_png(out.path_join("existing-neutral.png"))==OK)
	for frame in range(frames):
		var original: Image = renderer.original_garment_pose("idle_gesture","front",frame)
		assert(original != null and original.save_png(out.path_join("%d-source.png" % frame))==OK)
		var metrics := renderer._authored_source_hair_metrics(original, "front","idle_gesture",frame)
		for style in ["windswept", "bob", "curly", "hat", "vest"]:
			var look := Renderer.DEFAULT_APPEARANCE.duplicate()
			var gear := {"outfit":"outfit-rainvest" if style=="vest" else "outfit-tide","hat":"hat-straw" if style=="hat" else "hat-none"}
			if style in ["bob","curly"]: look.hair = style
			var action_image := renderer.texture(look,gear,"front",frame,"idle_gesture").get_image()
			var file := out.path_join("%d-%s.png" % [frame,style])
			assert(action_image.save_png(file)==OK)
		rows.append({"frame":frame, "source_sha256":renderer.head_source_signature(original),
			"bounds":str(original.get_used_rect()), "head_owner":metrics.hair_owner_valid,
			"source_neutral_equal": original.get_data()==baseline.get_data()})
	var file := FileAccess.open(out.path_join("preview.json"), FileAccess.WRITE)
	assert(file != null)
	file.store_string(JSON.stringify(rows,"\t"))
	file.close()
	print("PASS: registered camera idle pose study")
	quit(0)
'''


def stage(label, dependencies=None):
    base = run.make_base(label)
    project = base / "project"
    project.mkdir()
    paths = subprocess.check_output(["git","ls-files","-z"],cwd=ROOT,encoding="utf8").split("\0")
    graph = run.prepare_runtime_stage(ROOT, project, paths)
    shutil.copyfile(source, project / art_name)
    graph[art_name] = run.sha(project / art_name)
    assert graph[art_name] == "cd4ec54e2826adc23832e48f12328de201bb447f41363ce85867676e536f9d43"
    parsed = run.read(project / manifest_name)
    parsed["actors"]["traveller"]["idle_gesture"] = {"front":clip}
    (project / manifest_name).write_text(json.dumps(parsed, ensure_ascii=False, indent=2) + "\n", encoding="utf8", newline="\n")
    graph[manifest_name] = run.sha(project / manifest_name)
    compiler = (ROOT / "tools/build_head_material_owners.gd").read_text("utf8")
    start = compiler.index("\tvar poses: Array = []")
    end = compiler.index("\tvar owners := {}", start)
    compiler = compiler[:start] + '\tvar poses: Array = [["idle_gesture","front",0],["idle_gesture","front",1],["idle_gesture","front",2]]\n' + compiler[end:]
    compiler = compiler.replace('var output := ""','var output := OS.get_environment("COTTON_CAPTURE_DIR").path_join("owner-candidates.json")')
    for name, code in ((preview_script,PREVIEW),(owner_script,compiler)):
        path = project / name
        path.parent.mkdir(exist_ok=True,parents=True)
        path.write_text(code,encoding="utf8",newline="\n")
        graph[name] = run.sha(path)
    if dependencies is not None:
        for name, data in dependencies.items():
            (project / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf8", newline="\n")
            graph[name] = run.sha(project / name)
    run.FIXTURES = [preview_script,owner_script]
    run.dump(base / "source-graph.json", {"fixture":"registered camera idle art study", "source_raw_sha256":graph, "fixtures":run.FIXTURES})
    return base, project, graph


def import_stage(name, project, graph):
    base = run.make_base(name)
    dest = base / "project"
    shutil.copytree(project,dest)
    shutil.copyfile(project.parent / "source-graph.json",base / "source-graph.json")
    run.launch(base,dest,graph,"import",[run.ENGINE,"--headless","--path",dest,"--editor","--import","--quit"],run.environment(base))
    run.collect_imports(base,dest,graph)
    return base


def preview(name, base, project, graph, donor):
    run.copy_imports(donor,project,graph)
    run.MARKER = "PASS: registered camera idle pose study"
    run.launch(base,project,graph,name,[run.ENGINE,"--headless","--path",project,"--script","res://"+preview_script],run.environment(base))
    print(base.as_posix(), json.dumps(run.read(base / "captures/preview.json")),flush=True)


if __name__ == "__main__":
    base, project, graph = stage("camera-idle-study")
    donor = import_stage("camera-idle-study-import",project,graph)
    preview("camera-preview",base,project,graph,donor)
    base, project, graph = stage("camera-idle-owner-boundaries")
    run.copy_imports(donor,project,graph)
    run.MARKER = "WROTE: 3 head/body material owner candidates; visual approval is separate"
    output = base / "captures/owner-candidates.json"
    run.launch(base,project,graph,"camera-owners",[run.ENGINE,"--headless","--path",project,"--script","res://"+owner_script],run.environment(base))
    data = run.read(base / "captures/owner-candidates.json")["owners"]
    assert len(data)==3
    owners = run.read(ROOT / owner_name)
    assert not (data.keys() & owners["owners"].keys())
    owners["owners"].update(data)
    base, project, graph = stage("camera-idle-registered",{owner_name:owners})
    donor = import_stage("camera-idle-registered-import",project,graph)
    preview("camera-preview-registered",base,project,graph,donor)
