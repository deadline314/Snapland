from pathlib import Path
import os, subprocess
root=Path(__file__).resolve().parents[2]
base=Path(__file__).resolve().parent
stage=base/'pack-stage/qa-project'
engine=r'C:\Tools\Godot\Godot_v4.7.2-stable_win64_console.exe'
env=dict(os.environ,SNAPLAND_SAVE_PATH=str(base/'regression-profile.json'))
for name in ('test_walk_pixel_stability.gd','test_character_animation_library.gd'):
 (stage/'game/tests'/name).write_bytes((root/'game/tests'/name).read_bytes())
pack=base/'source-bound-tests.pck'
commands=[('regression-export',[engine,'--headless','--path',str(stage),'--editor','--export-pack','Snapland Animation QA Windows',str(pack),'--quit'])]
empty=base/'empty-pack-run'
empty.mkdir(exist_ok=True)
for name in ('test_walk_pixel_stability','test_character_animation_library'):
 commands.append((name,[engine,'--headless','--main-pack',str(pack),'--path',str(empty),'--script','res://game/tests/'+name+'.gd','--quit-after','2']))
for name,command in commands:
 r=subprocess.run(command,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=120)
 text=r.stdout+r.stderr
 (base/(name+'.log')).write_text(text,encoding='utf-8')
 if r.returncode or 'ERROR:' in text or (name.startswith('test_') and 'PASS' not in text):raise RuntimeError(name+': '+text[-2000:])
 print('PASS',name)
