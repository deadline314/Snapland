from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
root=Path(__file__).resolve().parents[2]
base=Path(__file__).resolve().parent
study=root/'.review/announcer-poseguide-20261112'
out=root/'pm/Snapland-art/images'
prefix='ART-16-source-bound-20261112'
stable=json.loads((root/'assets/characters/walk-stability-v1/manifest.json').read_text(encoding='utf-8'))
manifest=json.loads((root/'assets/characters/complete-animation-regions.json').read_text(encoding='utf-8'))
native=json.loads((base/'native-export/frames.json').read_text(encoding='utf-8'))['frames']
bound=0
for key,spec in stable['sequences'].items():
 if key.startswith('hero/'):continue
 family,view=key.split('/')
 actor,action=family.split('-',1)
 geometry=manifest['actors'][actor]
 rows=sorted([r for r in native if (r['family'],r['view'])==(family,view)],key=lambda r:r['frame'])
 assert len(rows)==len(spec['source_bindings'])==spec['frames']
 for i,binding in enumerate(spec['source_bindings']):
  assert binding==rows[i]['source_binding']
  assert binding['frame']=={'pose':geometry[action][view]['frames'][i],'canvas_size':geometry['canvas_size'],'reference_size':geometry['reference_size'],'feet_baseline':geometry['feet_baseline']}
  bound+=1
assert bound==24
movies=[]
for label,name in [('normal-pack','announcer-pack-isolated'),('quarter','announcer-quarter'),('reduced','announcer-reduced')]:
 report=json.loads((base/name/'announcer-report.json').read_text(encoding='utf-8'))
 assert report['technical_status']=='PASS' and report['human_played'] is False
 source=base/(name+'.avi')
 target=out/(prefix+'-'+label+'.mp4')
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(source),'-an','-c:v','libx264','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(target)],check=True)
 probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=nb_frames,r_frame_rate,duration','-of','json',str(target)],encoding='utf-8'))['streams'][0]
 movies.append({'label':label,'file':target.name,**probe})
shutil.copy2(base/'announcer-pack-isolated/announcer-settled.png',out/(prefix+'-settled.png'))
shutil.copy2(study/'comparison.png',out/(prefix+'-study.png'))
shutil.copy2(study/'compare.mp4',out/(prefix+'-study.mp4'))
sources={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ['game/world/walk_pixel_sources.gd','game/world/character_animation_library.gd','game/tests/test_character_animation_library.gd','game/tests/export_walk_stability.gd','assets/characters/walk-stability-v1/manifest.json','tools/walk_stability/build_registered_walks.py','tests/test_walk_pixel_stability.py']}
review={'ticket':'ART-16','date':'2026-11-12','base_commit':'f9a05ae7286006a8f986daa05570c62cf5c24930','source_bindings':bound,'source_pngs_modified':False,'runtime_local_checks':16,'final_guard_checks':4,'native_export_frames':672,'movies':movies,'isolated_pack_regressions':['test_walk_pixel_stability','test_character_animation_library'],'candidate_poses':16,'candidate_accepted':False,'candidate_ground_gap_source_pixels':[0,5],'human_played':False,'human_listened':False,'sources':sources,'note':'Native fixture captures and source comparisons; no human continuous-play or listening acceptance. Candidate study uses fixed cell roots, one scale and shared row ground.'}
(out/(prefix+'-review.json')).write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
with zipfile.ZipFile(out/(prefix+'-studies.zip'),'w',zipfile.ZIP_DEFLATED) as archive:
 for name in ['right-eight-candidate.png','left-eight-candidate.png','right-eight-guide.svg','right-eight-guide.png','left-eight-guide.svg','left-eight-guide.png','reference-left.png','review.json','left-generation.json','candidate-frames.json','compare.gd','compare-final.log','analyze.py','frames.json','comparison.png']:
  archive.write(study/name,name)
 for side in ('right','front'):archive.write(root/'.review/announcer-walk8-20261112'/('reference-'+side+'.png'),'reference-'+side+'.png')
with zipfile.ZipFile(out/(prefix+'-evidence.zip'),'w',zipfile.ZIP_DEFLATED) as archive:
 for path in base.glob('*.log'):archive.write(path,'logs/'+path.name)
 for name in ['runtime-local-final.log','runtime-final-guard.log','python-builder.log','python-staging.log','design.log','native-pixel-stability.log','final-library.log','extra-red.log']:
  archive.write(root/'.review/source-bound-walks-20261112'/name,'logs/'+name)
 for name in ['red-direct.log','source-binding-red.log','source-binding-local.log']:archive.write(study/name,'prior-failures/'+name)
 for name in ['announcer-pack-isolated','announcer-quarter','announcer-reduced']:
  for path in (base/name).iterdir():
   if path.suffix=='.png' and name=='announcer-quarter' and path.name not in ('announcer-walk-left-0.png','announcer-settled.png','announcer-depart-right-2.png'):continue
   if path.suffix=='.png' and name=='announcer-reduced' and path.name!='announcer-start.png':continue
   archive.write(path,name+'/'+path.name)
 for row in native:
  if row['family'] in ('island-raw','announcer-walk','announcer-walk_candidate','ticket-walk_candidate'):archive.write(base/'native-export'/row['file'],'native-export/'+row['file'])
 archive.write(base/'native-export/frames.json','native-export/frames.json')
 for path in base.glob('*.py'):archive.write(path,'reproduce/'+path.name)
 for name in sources:archive.write(root/name,'frozen-source/'+name)
 archive.write(out/(prefix+'-review.json'),'review.json')
print('PACKAGED',bound,'source bindings',movies)
