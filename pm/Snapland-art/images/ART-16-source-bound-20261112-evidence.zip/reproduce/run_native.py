import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[2]
base = Path(__file__).resolve().parent
role, mode = sys.argv[1:3]
if role not in ('ticket','imp','announcer') or mode not in ('normal','quarter','reduced'):
    raise ValueError('Select ticket|imp and normal|quarter|reduced')
name = role + '-' + mode
env = dict(os.environ, SNAPLAND_SAVE_PATH=str(base/(name+'-profile.json')))
args = [r'C:\Tools\Godot\Godot_v4.7.2-stable_win64_console.exe','--path',str(root),
        '--rendering-method','gl_compatibility','--audio-driver','Dummy',
        '--write-movie',str(base/(name+'.avi')),'--fixed-fps','30',
        'res://game/tests/native_'+role+'_patrol_review.tscn','--','--actor='+role,
        '--actions-only','--animation-output='+str(base/name)]
if mode == 'quarter': args += ['--quarter','--rebuild']
if mode == 'reduced': args += ['--reduced-motion','--rebuild']
with (base/(name+'.log')).open('w',encoding='utf-8') as log:
    done = subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
text = (base/(name+'.log')).read_text(encoding='utf-8')
if done.returncode or 'ERROR:' in text:
    raise RuntimeError(name+' failed: '+text[-2500:])
print(name,done.returncode)
