"""Run wardrobe faults and animation source checks on isolated exact projects."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import shutil
import sys

import run as perf

run = perf.run
donor = Path(sys.argv[1])
TESTS = {
    "test_garment_cache": "PASS: garment cache bounds",
    "test_garment_overlay": "PASS: garment overlay preserves 185 original compositions",
    "test_character_animation_library": "PASS: character animation library checks",
    "test_avatar": "PASS: avatar runtime checks",
    "test_avatar_motion_world": "PASS: integrated avatar motion world checks",
}
run.FIXTURES = [f"game/tests/{name}.gd" for name in TESTS]


def test(name, expect_red=False):
    label = "red-garment-cache" if expect_red else name
    base = run.make_base(label)
    project = base / "project"
    project.mkdir()
    graph = run.prepare_runtime_stage(perf.ROOT, project, perf.paths)
    for relative in run.FIXTURES:
        target = project / relative
        target.parent.mkdir(exist_ok=True, parents=True)
        shutil.copy2(perf.ROOT / relative, target)
        graph[relative] = run.sha(target)
    run.dump(base / "source-graph.json", {"source_raw_sha256":graph, "fixtures":run.FIXTURES})
    run.copy_imports(donor,project,graph)
    try:
        run.launch(base,project,graph,label,[run.ENGINE,"--headless","--path",project,"--script","res://game/tests/"+name+".gd"],run.environment(base))
    except RuntimeError:
        if not expect_red: raise
        receipt = run.read(base/"receipt.json")
        assert receipt["exit_code"]==1 and not receipt["leak_diagnostics"]
        assert receipt["errors"]==["ERROR: Validation created unused GPU textures for the base poses"], receipt["errors"]
    else:
        assert not expect_red
        for log in ("engine.log","stdout.log"):
            assert any(line.startswith(TESTS[name]) for line in (base/log).read_text("utf8").splitlines())
    print(base.as_posix(),flush=True)


if sys.argv[2:] == ["red"]:
    test("test_garment_cache", True)
else:
    with ThreadPoolExecutor(max_workers=2) as pool:
        list(pool.map(test, sys.argv[2:] or TESTS))
