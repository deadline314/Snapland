"""Repeat paired native wardrobe measurements against the exact preflight baseline."""
import json
from pathlib import Path
import statistics
import subprocess
import sys

import run as perf

run = perf.run
donor = Path(sys.argv[1])
base_commit = "5cbdd91b3e31ff4360a72e0823b0eece96fda277"
paths = ["game/world/" + file for file in (
    "avatar_renderer.gd", "character_animation_library.gd", "garment_overlay_library.gd")]
rows = []
for index, variant in enumerate(("before", "after", "after", "before"), 1):
    base, project, graph = perf.stage("cold-" + variant)
    if variant == "before":
        for name in paths:
            target = project / name
            target.write_bytes(subprocess.check_output(["git","show",base_commit + ":" + name],cwd=perf.ROOT))
            graph[name] = run.sha(target)
    proof = run.read(base / "source-graph.json")
    proof.update({"source_raw_sha256":graph,"variant":variant,"paired_source_baseline":base_commit,"order":index})
    (base/"source-graph.json").write_text(json.dumps(proof,indent=2)+"\n",encoding="utf8",newline="\n")
    run.copy_imports(donor, project, graph)
    run.MARKER = "PASS: local native animation timing and cache measurements"
    receipt = run.launch(base,project,graph,"cold-"+variant,
        [run.ENGINE,"--path",project,"--audio-driver","Dummy","res://"+perf.scene+".tscn"],run.environment(base))
    assert receipt["marker_counts_engine_stdout_stderr"] == [1,1,0]
    report = run.read(base/"captures/performance.json")
    assert report["renderer"]=="forward_plus" and report["uses_native_clock"] and not report["failures"]
    stats = next(row for row in report["rows"] if row["profile"]=="rainvest")
    row = {"stage":base.as_posix(),"variant":variant,"cold_setup_ms":stats["setup_ms"],
           "garment_images":stats["end_cache_counts"]["garment_images"],
           "authored_textures_after_motion":stats["end_cache_counts"]["authored_textures"]}
    rows.append(row)
    print(row,flush=True)
comparison = {variant:statistics.median(row["cold_setup_ms"] for row in rows if row["variant"]==variant)
              for variant in ("before","after")}
assert max(row["cold_setup_ms"] for row in rows if row["variant"]=="after") < min(row["cold_setup_ms"] for row in rows if row["variant"]=="before")
comparison["setup_reduction_percent"] = 100.0 * (1.0 - comparison["after"]/comparison["before"])
run.dump(perf.HERE/"comparison.json",{"samples":rows,"median_ms":comparison})
print(comparison,flush=True)
