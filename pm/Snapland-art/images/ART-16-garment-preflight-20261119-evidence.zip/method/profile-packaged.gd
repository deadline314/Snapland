extends Node

const MainScene := preload("res://game/main.tscn")
const Guard := preload("res://game/core/test_save_guard.gd")
const Release := preload("res://game/tests/audio_playback_release.gd")
const AvatarRenderer := preload("res://game/world/avatar_renderer.gd")
const ClipLibrary := preload("res://game/world/character_animation_library.gd")
const HairRig := preload("res://game/world/avatar_hair_rig.gd")
const STEPS := [[KEY_W], [KEY_W, KEY_D], [KEY_D], [KEY_D, KEY_S], [KEY_S], [KEY_S, KEY_A], [KEY_A], [KEY_A, KEY_W]]

var _main: Node

func _ready() -> void:
	call_deferred("_run")

func _run() -> void:
	var out := OS.get_environment("COTTON_CAPTURE_DIR")
	var save := OS.get_environment("SNAPLAND_SAVE_PATH")
	if DisplayServer.get_name() == "headless" or OS.has_feature("movie") or not out.is_absolute_path() or not Guard.validate_save_path(save, OS.get_user_data_dir()).is_empty():
		push_error("Display-backed performance measurement requires an isolated native run")
		get_tree().quit(1)
		return
	if "--fixed-fps" in OS.get_cmdline_args() or Engine.time_scale != 1.0:
		push_error("Frame pacing must be left to the native runtime")
		get_tree().quit(1)
		return
	get_window().size = Vector2i(1280, 720)
	Progress.reset_progress()
	Progress.intro_seen = true
	_main = MainScene.instantiate()
	get_tree().root.add_child(_main)
	for _frame in range(30): await get_tree().process_frame
	var world: Node = _main.world
	if not is_instance_valid(world) or _main.modal_kind != "":
		push_error("Main did not enter an unobstructed island")
		get_tree().quit(1)
		return
	var rows: Array = []
	var failures: Array = []
	for profile in ["default","rainvest","reduced"]:
		world.player.global_position = Vector3(-4.0, 0.4, -6.0)
		world.player.velocity = Vector3.ZERO
		_set_keys([])
		for _frame in range(8): await get_tree().physics_frame
		var appearance: Dictionary = AvatarRenderer.DEFAULT_APPEARANCE.duplicate()
		if profile != "default": appearance.hair = "bob"
		var gear := {"outfit": "outfit-tide" if profile == "default" else "outfit-rainvest",
			"hat":"hat-none" if profile == "default" else "hat-straw"}
		var start := Time.get_ticks_usec()
		world.set_avatar_look(appearance, gear)
		world.apply_settings({"reduced_motion": profile == "reduced"})
		var setup_ms := (Time.get_ticks_usec() - start) / 1000.0
		var row := await _measure(world)
		row.profile = profile
		row.setup_ms = setup_ms
		rows.append(row)
		if row.headings.size() != 8 or row.frame_ms.size() < 100 or not row.caches_bounded:
			failures.append(profile + " coverage or cache limits")
		if profile != "default" and row.garment.validated_cels != 185:
			failures.append(profile + " did not load the complete rainvest")
		var path := out.path_join(profile + "-native.png")
		if FileAccess.file_exists(path) or get_viewport().get_texture().get_image().save_png(path) != OK:
			failures.append("could not preserve the viewport")
	var report := {"renderer": RenderingServer.get_current_rendering_method(), "gpu": RenderingServer.get_video_adapter_name(),
		"window_px": [get_window().size.x, get_window().size.y], "vsync": DisplayServer.window_get_vsync_mode(),
		"engine_max_fps": Engine.max_fps, "debug": OS.is_debug_build(), "rows":rows, "failures":failures,
		"uses_native_clock": true, "recording_movie": false}
	var output := out.path_join("performance.json")
	if not FileAccess.file_exists(output):
		var file := FileAccess.open(output, FileAccess.WRITE)
		if file != null:
			file.store_string(JSON.stringify(report, "\t"))
			file.close()
			if failures.is_empty(): print("PASS: local native animation timing and cache measurements")
	_set_keys([])
	if not failures.is_empty(): push_error("Profile checks: " + "; ".join(failures))
	_main.quitting = true
	var playbacks := Release.capture(_main.audio)
	_main.audio.shutdown()
	_main.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	if not await Release.wait_for_release(get_tree(), playbacks):
		push_error("Packaged probe could not release its audio playbacks")
		get_tree().quit(1)
		return
	get_tree().quit(0 if failures.is_empty() else 1)

func _measure(world: Node) -> Dictionary:
	var frame_times := PackedFloat64Array()
	var headings := {}
	var last := Time.get_ticks_usec()
	var focused := 0
	var peak_static := 0
	var peak_video := 0
	var peak_draws := 0
	var next_monitor := last
	for _round in range(2):
		for keys in STEPS:
			_set_keys(keys)
			var deadline := Time.get_ticks_usec() + 500000
			while Time.get_ticks_usec() < deadline:
				await RenderingServer.frame_post_draw
				var now := Time.get_ticks_usec()
				frame_times.append((now - last) / 1000.0)
				last = now
				if get_window().has_focus(): focused += 1
				if world.avatar_is_walking: headings[world.facing] = true
				if now >= next_monitor:
					peak_static = maxi(peak_static, int(Performance.get_monitor(Performance.MEMORY_STATIC)))
					peak_video = maxi(peak_video, int(Performance.get_monitor(Performance.RENDER_VIDEO_MEM_USED)))
					peak_draws = maxi(peak_draws, int(Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)))
					next_monitor = now + 100000
	_set_keys([])
	var avatar: RefCounted = world.avatar_renderer
	var counts := {
		"avatar_textures": avatar.cached_texture_count(),
		"authored_textures": avatar.animation_library.cached_texture_count(),
		"hair_views": world.avatar_hair_rig._cache.size(),
		"garment_images": avatar.garment_overlays.cache_snapshot().decoded_images,
	}
	var bounded: bool = counts.avatar_textures <= AvatarRenderer.CACHE_LIMIT and counts.authored_textures <= ClipLibrary.TEXTURE_CACHE_LIMIT
	bounded = bounded and counts.hair_views <= HairRig.CACHE_LIMIT and counts.garment_images <= avatar.garment_overlays.DECODED_CACHE_LIMIT
	return {"frame_ms": Array(frame_times), "headings":headings.keys(), "focused_frames":focused,
		"peak_static_bytes":peak_static,"peak_video_bytes":peak_video,"peak_draw_calls":peak_draws,
		"end_cache_counts": counts, "caches_bounded":bounded, "garment":avatar.garment_overlays.cache_snapshot()}

func _set_keys(keys: Array) -> void:
	for key in [KEY_W, KEY_D, KEY_S, KEY_A]:
		var event := InputEventKey.new()
		event.keycode = key
		event.physical_keycode = key
		event.pressed = keys.has(key)
		Input.parse_input_event(event)
	Input.flush_buffered_events()
