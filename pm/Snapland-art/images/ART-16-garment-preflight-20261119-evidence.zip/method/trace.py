"""Attribute cold wardrobe latency inside a disposable project only."""
from pathlib import Path
import sys

import run as perf

donor = Path(sys.argv[1])
base, project, graph = perf.stage("garment-breakdown")
name = "game/world/garment_overlay_library.gd"
file = project / name
program = file.read_text("utf8")
for needle, replacement in (
    ("\tvar pending: Dictionary = {}\n", "\tvar pending: Dictionary = {}\n\tvar source_us := 0\n\tvar layer_us := 0\n\tvar slot_us := {}\n"),
    ("\t\tvar source: Image = avatar.original_garment_pose", "\t\tvar body_started := Time.get_ticks_usec()\n\t\tvar source: Image = avatar.original_garment_pose"),
    ('\t\tvar path := str(row.get("path",""))', '\t\tvar body_elapsed := Time.get_ticks_usec() - body_started\n\t\tsource_us += body_elapsed\n\t\tslot_us[action] = int(slot_us.get(action, 0)) + body_elapsed\n\t\tvar path := str(row.get("path",""))'),
    ("\t\tif _verified_layer(record,key) == null: return false\n", "\t\tvar layer_started := Time.get_ticks_usec()\n\t\tif _verified_layer(record,key) == null: return false\n\t\tlayer_us += Time.get_ticks_usec() - layer_started\n"),
    ("\t_records = pending\n", '\tprint("GARMENT_TRACE: ", JSON.stringify({"source_us":source_us,"layer_us":layer_us,"by_action_us":slot_us}))\n\t_records = pending\n'),
):
    assert program.count(needle) == 1
    program = program.replace(needle, replacement, 1)
file.write_text(program, encoding="utf8", newline="\n")
graph[name] = perf.run.sha(file)
provenance = perf.run.read(base / "source-graph.json")
provenance["source_raw_sha256"] = graph
provenance["local_timing_instrumentation"] = name
(base / "source-graph.json").write_text(perf.run.json.dumps(provenance,indent=2)+"\n",encoding="utf8",newline="\n")
perf.run.copy_imports(donor, project, graph)
perf.run.launch(base,project,graph,"garment-breakdown",[perf.run.ENGINE,"--path",project,"--audio-driver","Dummy","res://"+perf.scene+".tscn"],perf.run.environment(base))
print(*(line for line in (base/"engine.log").read_text("utf8").splitlines() if line.startswith("GARMENT_TRACE:")),sep="\n")
print(base.as_posix(),flush=True)
