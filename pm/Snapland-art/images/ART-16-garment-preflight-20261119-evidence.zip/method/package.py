"""Verify the same appearance preflight from the embedded Windows runtime pack."""
from pathlib import Path
import json
import shutil
import sys

import run as perf

run = perf.run
donor = Path(sys.argv[1])
run.SCENE = perf.scene + ".tscn"
fixtures = run.FIXTURES.copy()
release_helper = "game/tests/audio_playback_release.gd"
package_profile = perf.HERE / "profile-packaged.gd"
original_profile = (perf.HERE / "profile.gd").read_text("utf8")
old_exit = '\tawait _main._quit_game()\n'
assert original_profile.count(old_exit) == 1
packaged_profile = original_profile.replace(
    'const Guard := preload("res://game/core/test_save_guard.gd")',
    'const Guard := preload("res://game/core/test_save_guard.gd")\nconst Release := preload("res://' + release_helper + '")',
).replace(old_exit, '''\t_main.quitting = true
\tvar playbacks := Release.capture(_main.audio)
\t_main.audio.shutdown()
\t_main.queue_free()
\tawait get_tree().process_frame
\tawait get_tree().process_frame
\tif not await Release.wait_for_release(get_tree(), playbacks):
\t\tpush_error("Packaged probe could not release its audio playbacks")
\t\tget_tree().quit(1)
\t\treturn
\tget_tree().quit(0 if failures.is_empty() else 1)
''')
package_profile.write_text(packaged_profile, encoding="utf8", newline="\n")


def stage_for_package(kind):
    run.FIXTURES = fixtures.copy()
    folder, project, graph = perf.stage(kind)
    run.FIXTURES.append(release_helper)
    for relative, source in ((perf.scene + ".gd", package_profile), (release_helper, perf.ROOT / release_helper)):
        shutil.copyfile(source, project / relative)
        graph[relative] = run.sha(project / relative)
    source_graph = run.read(folder / "source-graph.json")
    source_graph.update({"source_raw_sha256":graph,"fixtures":run.FIXTURES,"fixture_cleanup":"release audio and scene before quitting"})
    (folder / "source-graph.json").write_text(json.dumps(source_graph,indent=2)+"\n",encoding="utf8",newline="\n")
    return folder, project, graph


folder, project, graph = stage_for_package("perf-export")
run.copy_imports(donor,project,graph)
templates = run.templates(folder)
run.qa_override(project,templates)
release = folder / "release"
release.mkdir()
binary = release / "AvatarGarmentQA.exe"
run.launch(folder,project,graph,"export",[run.ENGINE,"--headless","--path",project,"--editor","--export-release","Windows Desktop",binary,"--quit"],run.environment(folder))
assert binary.stat().st_size > templates["release"]["bytes"] and not list(release.glob("*.pck"))
original = run.read(folder / "runtime-graph.json")
file_id = run.describe(binary)
run.dump(folder/"build.json",{"asset_graph":original,"binary":file_id,"templates":templates})
live, project, graph = stage_for_package("perf-embedded")
run.qa_override(project,templates)
assert all(run.sha(project / name) == digest for name,digest in original.items())
assert run.describe(binary)==file_id
run.MARKER = "PASS: local native animation timing and cache measurements"
receipt = run.launch(live,project,graph,"perf-embedded",[binary,"--audio-driver","Dummy"],run.environment(live),release)
assert receipt["marker_counts_engine_stdout_stderr"] == [1,1,0]
report = run.read(live/"captures/performance.json")
assert not report["debug"] and report["renderer"]=="forward_plus" and not report["failures"]
assert all(row["caches_bounded"] and row["end_cache_counts"]["authored_textures"]==0 for row in report["rows"])
run.dump(folder/"embedded-acceptance.json",{"build":run.describe(folder/"build.json"),"launch":run.describe(live/"receipt.json")})
print(folder.as_posix(),live.as_posix(),flush=True)
