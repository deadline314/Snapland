extends SceneTree
const Avatar=preload("res://game/world/avatar_renderer.gd")
func _initialize():
 var avatar=Avatar.new()
 assert(not ResourceLoader.exists(Avatar.ATLAS_PATH) and not avatar.is_asset_ready())
 var report=[]
 var out=OS.get_environment("SNAPLAND_SAVE_PATH").get_base_dir()
 DirAccess.make_dir_recursive_absolute(out)
 for direction in ["front","back","left","right"]:
  var image: Image=avatar.texture(Avatar.DEFAULT_APPEARANCE,{"outfit":"outfit-tide","hat":"hat-none"},direction,0,"walk").get_image()
  assert(image.get_size()==Vector2i(64,96) and image.get_used_rect().has_area())
  assert(image.save_png(out.path_join(direction+".png"))==OK)
  report.append({"direction":direction,"size":image.get_size(),"visible_bounds":image.get_used_rect()})
 print("PASS: actual missing primary atlas retains four recognizable built-in walk fallbacks ",JSON.stringify(report))
 quit()
