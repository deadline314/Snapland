extends SceneTree
const Avatar = preload("res://game/world/avatar_renderer.gd")
const World = preload("res://game/world/park_world.gd")
func _initialize() -> void: call_deferred("_run")
func _run() -> void:
	var output := OS.get_environment("SNAPLAND_PACK_REVIEW_DIR")
	assert(output.is_absolute_path())
	DirAccess.make_dir_recursive_absolute(output)
	var renderer = Avatar.new()
	assert(renderer.is_asset_ready() and renderer.has_walk_atlas())
	var signatures := {}
	for direction in ["front", "back", "left", "right"]:
		assert(renderer.walk_frame_count(direction) == 8)
		for index in 8:
			_record(signatures, renderer, renderer.DEFAULT_APPEARANCE, {}, direction, "walk", index)
	for action in ["wave", "photograph", "interact", "jump"]:
		assert(renderer.has_authored_action(action, "front") and renderer.authored_frame_count(action, "front") == 8)
		for index in 8:
			_record(signatures, renderer, renderer.DEFAULT_APPEARANCE, {}, "front", action, index)
	for hair in ["windswept", "bob", "curly"]:
		var look: Dictionary = renderer.DEFAULT_APPEARANCE.duplicate()
		look.hair = hair
		for index in 8:
			_record(signatures, renderer, look, {"outfit":"outfit-rainvest", "hat":"hat-straw"}, "front", "jump", index)
	var world = World.new()
	root.add_child(world)
	await physics_frame
	await physics_frame
	for index in 8:
		world.avatar_renderer.texture(world.avatar_appearance,world.avatar_equipped,"front",index,"jump")
	world.play_action("celebrate")
	assert(world.avatar_action == "celebrate" and world.last_avatar_source_action == "jump")
	var seen := {}
	for tick in 80:
		if world.last_avatar_action == "celebrate": seen[world.last_avatar_frame] = true
		await physics_frame
		if world.avatar_action.is_empty(): break
	assert(seen.size() == 8 and world.last_avatar_action == "idle")
	var file := FileAccess.open(output.path_join("poses.json"), FileAccess.WRITE)
	file.store_string(JSON.stringify({"poses":signatures, "count":signatures.size(), "celebration_source":"jump", "celebration_cels":seen.size(), "engine":Engine.get_version_info().string, "resource_root":ProjectSettings.globalize_path("res://"), "development_test_present":FileAccess.file_exists("res://game/tests/test_avatar_authored_walk_loop.gd"), "scope":"Resource and lifecycle probe, not a native player boot or play/listening acceptance"}, "\t"))
	file.close()
	world.queue_free()
	await process_frame
	print("PASS_PACKED_ACTIONS poses=",signatures.size()," celebration_cels=",seen.size())
	quit()
func _record(signatures: Dictionary, renderer: RefCounted, appearance: Dictionary, equipped: Dictionary, direction: String, action: String, index: int) -> void:
	var image: Image = renderer.texture(appearance,equipped,direction,index,action).get_image()
	assert(not image.is_empty() and image.get_used_rect().size.x > 0)
	var hash := HashingContext.new()
	hash.start(HashingContext.HASH_SHA256)
	hash.update(image.get_data())
	var key := "%s/%s/%s/%s/%d" % [appearance.hair, JSON.stringify(equipped), direction, action, index]
	signatures[key] = {"sha256":hash.finish().hex_encode(), "width":image.get_width(), "height":image.get_height()}
