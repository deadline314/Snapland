from pathlib import Path
from tools.godot_entrypoints import run_validated_godot
import os, json, time, shutil
root = Path.cwd()
base = root / 'work/celebration'
release = base / 'linux-release/release'
out = base / 'release-native'
out.mkdir(exist_ok=False)
profile = out / 'profile/progress.json'
profile.parent.mkdir()
shutil.copy2(base / 'normal-v3/profile/progress.json', profile)
env = dict(os.environ, SNAPLAND_SAVE_PATH=str(profile))
start = time.monotonic()
args = [str(release / 'Snapland.x86_64'), '--rendering-method', 'gl_compatibility', '--audio-driver', 'Dummy', '--', '--smoke-test', '--smoke-art']
r = run_validated_godot(root, args, env, 300, release_directory=release)
log = r.stdout + r.stderr
(out / 'run.log').write_text(log)
report = dict(exit=r.returncode, errors=log.count('ERROR:'), seconds=round(time.monotonic()-start, 2), cwd=str(release), loose_project=(release/'project.godot').exists(), editor_cache=(release/'.godot').exists(), binary_sha256=json.loads((base/'linux-release/build.json').read_text())['binary']['sha256'], captures=len(list(profile.parent.glob('art-smoke-*.png'))), scope='Actual exported ELF, embedded main scene, no source/scene/pack override. Scripted art resource smoke; Dummy audio is not listening.')
(out / 'review.json').write_text(json.dumps(report, indent=2)+'\n')
print(report)
print('\n'.join(x for x in log.splitlines() if 'PASS' in x or 'ERROR:' in x))
assert r.returncode == 0 and 'ERROR:' not in log and report['captures'] == 12 and 'PASS: art resources loaded' in log
