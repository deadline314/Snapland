import importlib.util
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[2]
base = Path(__file__).resolve().parent
sys.path.insert(0, str(root))
from tools.animation_qa import export_animation_qa as qa

qa.FIXTURE_FILES |= {'game/tests/native_authored_patrol_review.gd',
                     'game/tests/native_ticket_patrol_review.gd',
                     'game/tests/native_ticket_patrol_review.tscn'}
stage = base / 'pack-stage'
stage.mkdir()
result = qa.prepare_project(stage)
project = Path(result['project'])
engine = r'C:\Tools\Godot\Godot_v4.7.2-stable_win64_console.exe'
env = dict(os.environ, SNAPLAND_SAVE_PATH=str(base / 'pack-profile.json'))
pack = base / 'ticket-turn.pck'
for label, args in [('import', ['--editor', '--import', '--quit']),
                    ('export', ['--editor', '--export-pack', qa.PRESET_NAME, str(pack), '--quit'])]:
    with (base / ('pack-' + label + '.log')).open('w', encoding='utf-8') as log:
        done = subprocess.run([engine, '--headless', '--path', str(project), '--rendering-method', 'gl_compatibility', *args], env=env, stdout=log, stderr=subprocess.STDOUT, timeout=240)
    content = (base / ('pack-' + label + '.log')).read_text(encoding='utf-8')
    if done.returncode or 'ERROR:' in content:
        raise RuntimeError(label + ' failed: ' + content[-1500:])
with (base / 'pack-native.log').open('w', encoding='utf-8') as log:
    done = subprocess.run([engine, '--main-pack', str(pack), '--path', str(project), '--rendering-method', 'gl_compatibility', '--audio-driver', 'Dummy', '--write-movie', str(base / 'pack.avi'), '--fixed-fps', '30', 'res://game/tests/native_ticket_patrol_review.tscn', '--', '--actor=ticket', '--actions-only', '--animation-output=' + str(base / 'pack')], env=env, stdout=log, stderr=subprocess.STDOUT, timeout=240)
print('PCK native', done.returncode)
raise SystemExit(done.returncode)
