from pathlib import Path
import os,shutil,json
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();stage=r/'work/tutorial-current-20261020/validation-project';base=r/'work/remaining-20261024/art18-fallback';out=base/'sources';out.mkdir(exist_ok=False);target=stage/'work/remaining-20261024/art18-fallback';target.mkdir(parents=True,exist_ok=True);shutil.copy2(base/'export.gd',target/'export.gd')
p=run_validated_godot(stage,[str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'),'--headless','--path',str(stage),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--script','res://work/remaining-20261024/art18-fallback/export.gd'],dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'progress.json')),60);s=p.stdout+p.stderr;(out/'result.log').write_text(s);print(s);assert p.returncode==0 and 'ERROR:' not in s
j=json.loads((out/'sources.json').read_text());print('24requests unique sources',len({x['sha256'] for x in j}),'reviewed head owners',sum(x['head_owner_available'] for x in j))
