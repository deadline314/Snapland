extends SceneTree
func _initialize() -> void:
 var out:=OS.get_environment("SNAPLAND_SAVE_PATH").get_base_dir()
 var avatar=preload("res://game/world/avatar_renderer.gd").new()
 var records:Array=[]
 for direction in avatar.WALK_DIRECTIONS:
  for frame in 3:
   var pose_direction:String=direction if avatar.DIRECTIONS.has(direction) else avatar._closest_cardinal(direction)
   var pose:int=avatar._pose_index(pose_direction,frame,"celebrate")
   var source:Image=avatar._atlas_pose_image(pose)
   var name:="celebrate-%s-%02d.png"%[direction,frame]
   source.save_png(out.path_join(name))
   records.append({"action":"celebrate","direction":direction,"frame":frame,"pose":pose,"source":name,"sha256":avatar.head_source_signature(source),"head_owner_available":avatar.has_head_material_owner(source)})
 FileAccess.open(out.path_join("sources.json"),FileAccess.WRITE).store_string(JSON.stringify(records,"  "))
 print("PASS: actual24 existing celebration render requests exported; no new source animation authored")
 quit()
