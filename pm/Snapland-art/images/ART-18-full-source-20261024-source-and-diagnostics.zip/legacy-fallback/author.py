from pathlib import Path
from PIL import Image,ImageDraw
import json,copy
r=Path.cwd();b=r/'work/remaining-20261024/art18-ownership';fallback=r/'work/remaining-20261024/art18-fallback';g=json.loads((b/'guide-v19.json').read_text());row=copy.deepcopy(next(x for x in g['frames'] if x['action']=='photograph' and x['frame']==2));im=Image.open(fallback/'sources/celebrate-front-00.png').convert('RGBA')
def spans(poly):
 mask=Image.new('L',im.size);ImageDraw.Draw(mask).polygon(poly,fill=255);out=[]
 for y in range(360):
  start=None
  for x in range(281):
   v=x<280 and mask.getpixel((x,y)) and im.getpixel((x,y))[3]>12
   if v and start is None:start=x
   if not v and start is not None:out.append([y,start,x-1]);start=None
 return out
# Explicit original raised forearms, hands, camera and backpack straps.
row.update(source_kind='runtime_fallback',target_root=[140,185],torso_scale=[0.6,0.4],draw_clip=[0,205,280,95],unchanged_regions=[[0,0,280,205],[0,300,280,60]],protection={'head':[0,0,280,205],'feet':[0,300,280,60],'camera':[110,190,60,44]})
row['original_arm_polygons']=[[[22,50],[70,50],[112,163],[110,200],[75,190],[45,127],[20,85]],[[170,50],[258,50],[260,100],[224,149],[197,191],[164,203],[170,162],[198,96]]];row['original_arm_spans']=[spans(p) for p in row['original_arm_polygons']]
row['protection_spans']=spans([[82,165],[107,170],[115,214],[104,238],[73,247],[69,224]])+spans([[167,171],[190,176],[210,214],[212,243],[183,246],[168,219]])
g['runtime_fallback_frames']=[]
for item in json.loads((fallback/'sources/sources.json').read_text()):
 x=copy.deepcopy(row);x.update(action=item['action'],direction=item['direction'],frame=item['frame'],source_pixel_sha256=item['sha256']);g['runtime_fallback_frames'].append(x)
g['provenance']['review']='Inspection-only148 authored cels plus24 actual legacy render requests that all alias one original celebration image. Upper original foreground frozen by exact-source authoring proof; no new celebration animation or wardrobe adoption.'
(b/'guide-v20.json').write_text(json.dumps(g,indent=2)+'\n')
