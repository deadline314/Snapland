from pathlib import Path
from PIL import Image,ImageDraw
import json,copy,hashlib,colorsys
r=Path.cwd();b=r/'work/remaining-20261024/art18-ownership';g=json.loads((b/'guide-v10.json').read_text());base=next(x for x in g['frames'] if x['action']=='idle' and x['direction']=='front' and x['frame']==0);records=[]
# These are reviewed source-pose attachment proposals, not body transforms.
roots={'wave':[(140,205)]*8,'photograph':[(140,205)]*8,'interact':[(140,205)]*8,'catch':[(140,205)]*12,'jump':[(140,190),(140,245),(140,190),(140,155),(140,155),(140,185),(140,235),(140,185)],'sit':[(140,205)]*4}
def raster(im,poly):
 mask=Image.new('L',im.size);ImageDraw.Draw(mask).polygon(poly,fill=255);spans=[]
 for y in range(360):
  start=None
  for x in range(281):
   inside=x<280 and mask.getpixel((x,y)) and im.getpixel((x,y))[3]>12
   if inside and start is None:start=x
   if not inside and start is not None:spans.append([y,start,x-1]);start=None
 return spans
for a,poses in roots.items():
 for f,root in enumerate(poses):
  im=Image.open(r/'work/cloth-walk-20261022/current-originals/sources'/f'{a}-front-{f:02}.png').convert('RGBA');row=copy.deepcopy(base);row.update(action=a,frame=f,source_pixel_sha256=hashlib.sha256(im.tobytes()).hexdigest(),target_root=list(root));yy=root[1]
  primary_bottom=max(y for y in range(360) if any(im.getpixel((x,y))[3]>128 for x in range(280)))
  foot_y=max(yy+1,primary_bottom-54)
  row['protection']={'head':[0,0,280,yy],'feet':[0,foot_y,280,360-foot_y]};row['unchanged_regions']=[[0,0,280,yy],[0,330,280,30]];row['draw_clip']=[0,yy,280,min(330-yy,125)]
  # Freeze a new explicit central object/hand envelope from this exact source.
  # Central camera red is only a proposal locator. All proposed output cels
  # must be inspected; the shipping game will never infer ownership by color.
  camera=[]
  for y in range(100,310):
   for x in range(110,171):
    rr,gg,bb,aa=im.getpixel((x,y))
    if aa>128 and rr>80 and rr>gg*1.65 and rr>bb*1.45:camera.append((x,y))
  if camera:
   x0=min(x for x,y in camera);x1=max(x for x,y in camera);y0=min(y for x,y in camera);y1=max(y for x,y in camera)
   row['protection']['camera']=[max(0,x0-6),max(0,y0-5),min(280,x1+7)-max(0,x0-6),min(360,y1+6)-max(0,y0-5)]
  polys=[]
  for left in [True,False]:
   x0,x1=(55,127) if left else (153,225)
   skin=[]
   for y in range(max(0,yy-100),min(310,yy+71)):
    for x in range(x0,x1):
     rr,gg,bb,aa=im.getpixel((x,y))
     if aa>128 and rr>175 and 75<gg<210 and bb<160 and rr>gg*1.15:skin.append((x,y))
   bottom=max((y for x,y in skin),default=yy+50)+4
   # Only the sleeve/hand side of the torso; original source pixels within
   # the boundary remain immutable. It is not a new limb or motion rig.
   poly=[[55,yy-30],[127,yy-30],[127,bottom],[55,bottom]] if left else [[153,yy-30],[225,yy-30],[225,bottom],[153,bottom]]
   polys.append(poly)
  row['original_arm_polygons']=polys;row['original_arm_spans']=[raster(im,p) for p in polys]
  row['protection_spans']=[]
  # Original backpack sits behind the original right sleeve; keep its entire
  # visible side, without borrowing the trousers as a foreground rectangle.
  bag=[[185,yy-5],[224,yy+10],[224,yy+63],[185,yy+65]]
  row['protection_spans']=raster(im,bag)
  g['frames'].append(row);records.append({'action':a,'frame':f,'root':root,'camera':row['protection'].get('camera'),'arm_polygons':polys})
g['provenance']['review']='Unreviewed full authored-pose preview:148 source cels,24 legacy celebration requests still separate. Added48 explicit source-bound garment/arm proposals; every output requires whole-body and original-pixel review. No garment is enabled.'
(b/'guide-v11.json').write_text(json.dumps(g,indent=2)+'\n');(b/'actions-v11.json').write_text(json.dumps(records,indent=2)+'\n');print('prepared',len(g['frames']),'inspection-only source cels')
