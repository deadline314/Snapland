from pathlib import Path
from PIL import Image,ImageDraw
import json,sys
b=Path('work/remaining-20261024/art18-ownership');v=sys.argv[1];src=b/(sys.argv[2] if len(sys.argv)>2 else f'bake-{v}')/'compiled';j=json.loads((b/f'guide-{v}.json').read_text());groups={}
for row in j['frames']:groups.setdefault((row['action'],row['direction']),[]).append(row)
for (a,direction),rows in groups.items():
 rows.sort(key=lambda x:x['frame']);out=Image.new('RGB',(1120,384*((len(rows)+3)//4)),'#dfddcc');d=ImageDraw.Draw(out)
 for i,row in enumerate(rows):
  p=src/f'{a}-{direction}-{row["frame"]:02}.png';im=Image.open(p).convert('RGBA');x=i%4*280;y=i//4*384+24;out.paste(im,(x,y),im);d.text((x+5,y-20),p.stem,fill='black')
 out.save(b/f'{v}-{a}-{direction}.jpg',quality=95)
print('wrote',len(groups),'whole-body contact pages')
