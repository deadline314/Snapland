from pathlib import Path
from PIL import Image,ImageDraw
import json,copy,hashlib
r=Path.cwd();old=r/'work/cloth-walk-20261022/vest-bake-v8/validated-guide.json';out=r/'work/remaining-20261024/art18-ownership';g=json.loads(old.read_text());changed=[]
for row in g['frames']:
 d=row['direction'];a=row['action'];f=row['frame'];polys=copy.deepcopy(row['original_arm_polygons']);before=copy.deepcopy(polys)
 if d=='left':
  # Original near sleeve and its chest strap run left of the old upper-arm
  # corridor. Explicitly traced on the original source, never on the garment.
  polys[1][:3]=[[120,195],[151,195],[167,218]]
 if d=='back':
  # Preserve the complete shoulder cap, not merely the shoulder bone center.
  polys[0][:2]=[[92,195],[120,198]]
  polys[1][:2]=[[164,195],[183,196]]
 if polys==before:continue
 im=Image.open(r/'work/cloth-walk-20261022/current-originals/sources'/f'{a}-{d}-{f:02}.png').convert('RGBA');assert hashlib.sha256(im.tobytes()).hexdigest()==row['source_pixel_sha256']
 spans=[]
 for poly in polys:
  mask=Image.new('L',im.size);ImageDraw.Draw(mask).polygon(poly,fill=255);arm=[]
  for y in range(192,290):
   start=None
   for x in range(281):
    inside=x<280 and mask.getpixel((x,y)) and im.getpixel((x,y))[3]>12
    if inside and start is None:start=x
    if not inside and start is not None:arm.append([y,start,x-1]);start=None
  spans.append(arm)
 row['original_arm_polygons']=polys;row['original_arm_spans']=spans;changed.append([a,d,f])
g['provenance']['review']='Inspection-only continuation. Two shoulder/strap ownership contours traced against immutable originals after visible yellow paint-on-arm counterexamples; all changed composites require inspection. No new art coverage or wardrobe registration.'
(out/'guide-v9.json').write_text(json.dumps(g,indent=2)+'\n');(out/'changes-v9.json').write_text(json.dumps(changed,indent=2));print('changed',len(changed),'of',len(g['frames']))
