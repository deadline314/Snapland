from pathlib import Path
from PIL import Image,ImageDraw
import json,copy
r=Path.cwd();b=r/'work/remaining-20261024/art18-ownership';g=json.loads((b/'guide-v12.json').read_text());held=[[[83,201],[109,201],[126,219],[132,244],[111,256],[77,254],[63,236],[65,219]],[[171,201],[194,203],[214,225],[210,246],[179,255],[156,242],[165,220]]]
def raster(im,poly):
 m=Image.new('L',im.size);ImageDraw.Draw(m).polygon(poly,fill=255);spans=[]
 for y in range(360):
  start=None
  for x in range(281):
   inside=x<280 and m.getpixel((x,y)) and im.getpixel((x,y))[3]>12
   if inside and start is None:start=x
   if not inside and start is not None:spans.append([y,start,x-1]);start=None
 return spans
for row in g['frames']:
 a=row['action'];f=row['frame']
 if a not in ['photograph','jump','catch']:continue
 im=Image.open(r/'work/cloth-walk-20261022/current-originals/sources'/f'{a}-front-{f:02}.png').convert('RGBA');polys=copy.deepcopy(held);dy=row['target_root'][1]-205;dx=0
 if a=='jump':
  # The existing original torso leans sideways in airborne cels. Only the
  # garment attachment follows the held-camera/torso source; no body move.
  box=row['protection']['camera'];x=round(box[0]+box[2]/2);dx=x-row['target_root'][0];row['target_root'][0]=x
 for poly in polys:
  for p in poly:p[0]+=dx;p[1]+=dy
 row['original_arm_polygons']=polys;row['original_arm_spans']=[raster(im,p) for p in polys]
 if a=='jump':
  # Backpack remains on the same leaning original torso, not the fixed grid center.
  bag=[[185+dx,row['target_root'][1]-5],[224+dx,row['target_root'][1]+10],[224+dx,row['target_root'][1]+63],[185+dx,row['target_root'][1]+65]];row['protection_spans']=raster(im,bag)
g['provenance']['review']='Unreviewed148-cel continuation. Avoided self-crossing lifted arm proposals; retained original whole-body placement and followed the actual leaning torso only for garment attachments. All outputs remain inspection-only.'
(b/'guide-v13.json').write_text(json.dumps(g,indent=2)+'\n')
