from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
import json
r=Path.cwd();b=r/'work/remaining-20261024/art18-ownership';g=json.loads((b/'guide-v15.json').read_text());audit=[]
for row in g['frames']:
 a=row['action'];d=row['direction'];f=row['frame'];im=Image.open(r/'work/cloth-walk-20261022/current-originals/sources'/f'{a}-{d}-{f:02}.png').convert('RGBA');owned=set()
 for arm in row['original_arm_spans']:
  for y,lo,hi in arm:
   for x in range(lo,hi+1):owned.add((x,y))
 pts=set()
 for y in range(360):
  for x in range(280):
   rr,gg,bb,aa=im.getpixel((x,y))
   if aa>128 and rr>150 and .32<gg/max(1,rr)<.84 and .12<bb/max(1,rr)<.72 and gg>bb*1.10:pts.add((x,y))
 comps=[]
 while pts:
  q=[pts.pop()];v=[]
  while q:
   p=q.pop();v.append(p);x,y=p
   for n in [(x-1,y),(x+1,y),(x,y-1),(x,y+1)]:
    if n in pts:pts.remove(n);q.append(n)
  if len(v)>=10 and any(p in owned for p in v):comps.append(v)
 mask=Image.new('L',im.size)
 for comp in comps:
  for p in comp:mask.putpixel(p,255)
 mask=mask.filter(ImageFilter.MaxFilter(5));spans=[]
 for y in range(360):
  start=None
  for x in range(281):
   inside=x<280 and mask.getpixel((x,y)) and im.getpixel((x,y))[3]>12
   if inside and start is None:start=x
   if not inside and start is not None:spans.append([y,start,x-1]);start=None
 row['protection_spans']+=spans
 audit.append({'action':a,'direction':d,'frame':f,'component_bounds':[[min(x for x,y in c),min(y for x,y in c),max(x for x,y in c),max(y for x,y in c),len(c)] for c in comps],'extra_spans':spans,'review':'proposed original hand/strap color component connected to authored sleeve ownership; not a shipping detector or independent naturalness proof'})
g['provenance']['review']='Inspection-only148. Original hand/strap candidates connected to authored sleeve masks are frozen as exact source spans, to avoid garment clipping a fingertip at polygon edges. Every source proposal and output requires visual inspection; no runtime color inference.'
(b/'guide-v16.json').write_text(json.dumps(g,indent=2)+'\n');(b/'hand-proposals-v16.json').write_text(json.dumps(audit,indent=2)+'\n')
