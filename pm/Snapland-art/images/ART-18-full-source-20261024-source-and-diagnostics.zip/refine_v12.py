from pathlib import Path
from PIL import Image,ImageDraw
import json,copy,collections
r=Path.cwd();b=r/'work/remaining-20261024/art18-ownership';g=json.loads((b/'guide-v11.json').read_text());boxes=[]
def raster(im,poly):
 m=Image.new('L',im.size);ImageDraw.Draw(m).polygon(poly,fill=255);spans=[]
 for y in range(360):
  start=None
  for x in range(281):
   inside=x<280 and m.getpixel((x,y)) and im.getpixel((x,y))[3]>12
   if inside and start is None:start=x
   if not inside and start is not None:spans.append([y,start,x-1]);start=None
 return spans
held=[[[83,201],[109,201],[126,219],[132,244],[111,256],[77,254],[63,236],[65,219]],[[171,201],[194,203],[214,225],[210,246],[179,255],[156,242],[165,220]]]
for row in g['frames']:
 a=row['action'];f=row['frame']
 if a in ['walk','idle']:continue
 im=Image.open(r/'work/cloth-walk-20261022/current-originals/sources'/f'{a}-front-{f:02}.png').convert('RGBA');pts=set()
 for y in range(100,310):
  for x in range(95,186):
   rr,gg,bb,aa=im.getpixel((x,y))
   if aa>128 and rr>80 and rr>gg*1.65 and rr>bb*1.45 and gg<=bb*1.25:pts.add((x,y))
 comps=[]
 while pts:
  q=[pts.pop()];component=[]
  while q:
   p=q.pop();component.append(p);x,y=p
   for n in [(x-1,y),(x+1,y),(x,y-1),(x,y+1)]:
    if n in pts:pts.remove(n);q.append(n)
  comps.append(component)
 comp=max(comps,key=len);assert len(comp)>=20,(a,f,len(comp));x0=min(x for x,y in comp)-5;x1=max(x for x,y in comp)+6;y0=min(y for x,y in comp)-5;y1=max(y for x,y in comp)+6
 assert x1-x0<90 and y1-y0<65,(a,f,(x0,y0,x1,y1))
 row['protection']['camera']=[x0,y0,x1-x0,y1-y0];boxes.append([a,f,len(comp),row['protection']['camera']])
 root=row['target_root'];dy=root[1]-205;polys=copy.deepcopy(held)
 for poly in polys:
  for p in poly:p[1]+=dy
 if a=='photograph' and f in [1,2,3,4,5]:
  lift=15 if f in [1,5] else 47
  for poly in polys:
   for p in poly:
    if p[1]>210:p[1]-=lift
 if a=='wave' and f in [2,3,4,5,6]:
  polys[0]=[[42,155],[94,157],[114,195],[113,231],[83,235],[64,213],[40,190]]
 if a=='interact' and f in [1,2]:
  polys[1]=[[172,201],[196,206],[243,224],[248,242],[225,254],[185,243],[162,232]]
 if a=='interact' and f in [3,4,5]:
  polys=[[[67,205],[103,201],[140,217],[204,214],[220,244],[166,263],[112,257],[72,239]],[[165,203],[200,205],[235,217],[235,249],[196,257],[165,240]]]
 if a=='sit':
  polys=[[[77,201],[105,200],[123,235],[117,273],[120,285],[88,290],[68,268],[62,241]],[[170,201],[195,204],[213,237],[213,268],[194,288],[161,287],[164,267],[174,245]]]
 if a=='catch' and f in range(2,10):
  # Raised hands and sleeves are preserved above the torso; the source head
  # ownership is independently restored by the compiler.
  lift=[0,0,12,25,50,70,100,120,100,70,0,0][f]
  for poly in polys:
   for p in poly:p[1]-=lift
 row['original_arm_polygons']=polys;row['original_arm_spans']=[raster(im,p) for p in polys]
 assert all(row['original_arm_spans']),(a,f)
g['provenance']['review']='Unreviewed148-cel continuation. Rejected full-body warm-color camera envelopes; now strict camera-red connected component creates only proposed source-bound camera rectangles, all48 displayed and reviewed before acceptance. Pose-specific sleeve contours remain inspection-only.'
(b/'guide-v12.json').write_text(json.dumps(g,indent=2)+'\n');(b/'camera-proposals-v12.json').write_text(json.dumps(boxes,indent=2)+'\n');print(boxes)
