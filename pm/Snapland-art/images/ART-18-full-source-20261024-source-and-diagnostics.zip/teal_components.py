from pathlib import Path
from PIL import Image,ImageDraw
r=Path.cwd();b=r/'work/remaining-20261024/art18-ownership';src=r/'work/cloth-walk-20261022/current-originals/sources';canvas=Image.new('RGB',(1120,768),'#dfddcc');draw=ImageDraw.Draw(canvas)
for i,name in enumerate(['photograph-front-00','photograph-front-02','wave-front-03','interact-front-03','catch-front-00','catch-front-07','sit-front-00','jump-front-03']):
 im=Image.open(src/(name+'.png')).convert('RGBA');pts=set()
 for y in range(190 if not name.startswith('jump') else 150,310):
  for x in range(40,241):
   rr,gg,bb,aa=im.getpixel((x,y))
   if aa>128 and gg>rr*1.25 and bb>rr*1.25:pts.add((x,y))
 comps=[]
 while pts:
  q=[pts.pop()];v=[]
  while q:
   p=q.pop();v.append(p);x,y=p
   for n in [(x-1,y),(x+1,y),(x,y-1),(x,y+1)]:
    if n in pts:pts.remove(n);q.append(n)
  if len(v)>35:comps.append(v)
 bounds=[];x=i%4*280;y=i//4*384+20;canvas.paste(im,(x,y),im)
 for n,v in enumerate(sorted(comps,key=len,reverse=True)[:8]):
  x0=min(p[0] for p in v);x1=max(p[0] for p in v);y0=min(p[1] for p in v);y1=max(p[1] for p in v);bounds.append((n,len(v),(x0,y0,x1,y1)));draw.rectangle((x+x0,y+y0,x+x1,y+y1),outline=['red','blue','green','purple','orange','cyan','black','gray'][n],width=1);draw.text((x+x0,y+y0),str(n),fill='red')
 print(name,bounds);draw.text((x+4,y-16),name,fill='black')
canvas.save(b/'teal-components.jpg',quality=95)
