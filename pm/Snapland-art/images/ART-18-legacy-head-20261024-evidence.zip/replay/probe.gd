extends SceneTree
const Avatar=preload("res://game/world/avatar_renderer.gd")
const Builder=preload("res://tools/build_head_material_owners.gd")
func _initialize() -> void:
 var folder=OS.get_environment("SNAPLAND_SAVE_PATH").get_base_dir()
 DirAccess.make_dir_recursive_absolute(folder)
 var a=Avatar.new()
 var source: Image=a._atlas_pose_image(15)
 source.save_png(folder.path_join("original.png"))
 var metrics: Dictionary=a._build_source_hair_metrics(source,"front")
 var b=Builder.new()
 var mask: PackedByteArray=b._candidate_ink_boundary(a,source,metrics)
 var colored: Image=source.duplicate()
 var cut: Image=source.duplicate()
 var spans: Array=[]
 for y in source.get_height():
  var start: int=-1
  for x in range(source.get_width()+1):
   var inside: bool=x<source.get_width() and mask[y*source.get_width()+mini(x,source.get_width()-1)]!=0
   if inside:
    colored.set_pixel(x,y,Color.MAGENTA);cut.set_pixel(x,y,Color.TRANSPARENT)
   if inside and start<0:start=x
   if not inside and start>=0:spans.append([y,start,x]);start=-1
 colored.save_png(folder.path_join("candidate-owner.png"));cut.save_png(folder.path_join("candidate-cut.png"))
 var signature: String=a.head_source_signature(source)
 FileAccess.open(folder.path_join("candidate.json"),FileAccess.WRITE).store_string(JSON.stringify({"signature":signature,"body_start_y":metrics.body_start_y,"hair_owner_spans":spans,"source_bounds":str(metrics.source_bounds),"valid_before":a.has_head_material_owner(source),"face_indices":metrics.face_indices.size(),"skull_underlay_indices":metrics.skull_underlay_indices.size()},"  "))
 var comparisons:=0
 for direction in Avatar.WALK_DIRECTIONS:
  for frame in range(3):
   var expected: Image
   for style in ["windswept","bob","curly"]:
    var look: Dictionary=Avatar.DEFAULT_APPEARANCE.duplicate();look.hair=style
    var actual: Image=a.texture(look,{"outfit":"outfit-tide","hat":"hat-none"},direction,frame,"celebrate").get_image()
    if expected==null:expected=actual
    elif expected.get_data()!=actual.get_data():push_error("Incomplete legacy head fallback changed with hair style");quit(1);return
    comparisons+=1
   if frame==0:expected.save_png(folder.path_join("fallback-"+direction+".png"))
 var changed:=source.duplicate();changed.set_pixel(140,100,Color.MAGENTA)
 if a.has_head_material_owner(source) or a.has_head_material_owner(changed):push_error("Missing owner borrowed an unrelated source");quit(1);return
 FileAccess.open(folder.path_join("fallback-check.json"),FileAccess.WRITE).store_string(JSON.stringify({"renders":comparisons,"all_three_hair_styles_preserve_the_same_complete_fallback":true,"original_and_one_pixel_changed_source_have_no_owner":true},"  "))
 print("PASS: 72 legacy celebration renders preserve complete fallback for all eight requested headings; unknown source cannot borrow head ownership")
 b.free();quit()
