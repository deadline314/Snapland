extends Node2D
var originals: Array[Texture2D] = []
var candidates: Array[Texture2D] = []
var elapsed := 0.0
var current := 0
var captured: Dictionary = {}
var pending := false
var stopping := false
var negative := false
var folder := ""
var records: Array = []
var font: Font

func _ready() -> void:
	var profile := OS.get_environment("SNAPLAND_SAVE_PATH")
	if not profile.is_absolute_path() or DisplayServer.get_name()=="headless":get_tree().quit(2);return
	folder=profile.get_base_dir();DirAccess.make_dir_recursive_absolute(folder.path_join("captures"))
	negative=OS.get_cmdline_user_args().has("--one-pixel-negative")
	Engine.time_scale=0.25 if OS.get_cmdline_user_args().has("--quarter") else 1.0
	texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	font=ThemeDB.fallback_font
	var base:=ProjectSettings.globalize_path("res://work/outfit-authoring-20261021")
	for index in 8:
		var a:=Image.load_from_file(base.path_join("bake-reviewed/compiled/walk-front-%02d-original.png"%index))
		var b:=Image.load_from_file(base.path_join("bake-reviewed/compiled/walk-front-%02d.png"%index))
		if a==null or b==null or a.get_size()!=Vector2i(280,360) or b.get_size()!=Vector2i(280,360):get_tree().quit(2);return
		originals.append(ImageTexture.create_from_image(a));candidates.append(ImageTexture.create_from_image(b))
	queue_redraw()

func _process(delta:float) -> void:
	if stopping or originals.size()!=8:return
	elapsed+=delta;current=int(floor(elapsed*8.0))%8
	queue_redraw()
	if not Engine.get_write_movie_path().is_empty():RenderingServer.force_draw(false,0.0)
	if not pending and not captured.has(current):_shot(current)
	if elapsed>=3.1 and not pending:
		stopping=true
		FileAccess.open(folder.path_join("render-report.json"),FileAccess.WRITE).store_string(JSON.stringify(records,"  "))
		if captured.size()!=8:push_error("Garment native cycle did not capture every authored cel");get_tree().quit(1);return
		print("PASS: native garment authoring eight-pose normal/quarter preview with exact rendered original head and foot regions; no wardrobe adoption")
		get_tree().quit()

func _draw() -> void:
	draw_rect(Rect2(0,0,1280,720),Color("#123442"))
	if originals.size()!=8:return
	draw_string(font,Vector2(180,40),"ART-18 / Garment-layer authoring candidate",HORIZONTAL_ALIGNMENT_LEFT,-1,26,Color("#eee8cc"))
	draw_string(font,Vector2(220,82),"Original complete cel",HORIZONTAL_ALIGNMENT_LEFT,-1,20,Color("#bce4d5"))
	draw_string(font,Vector2(700,82),"New garment / original wearer",HORIZONTAL_ALIGNMENT_LEFT,-1,20,Color("#bce4d5"))
	draw_texture_rect(originals[current],Rect2(220,100,392,504),false)
	draw_texture_rect(candidates[current],Rect2(701 if negative else 700,100,392,504),false)
	for x in [220,700]:draw_line(Vector2(x,585),Vector2(x+392,585),Color("#aa8056"),1.0)
	draw_string(font,Vector2(220,642),"Fixed canvas; original body, hands, camera and feet retained",HORIZONTAL_ALIGNMENT_LEFT,-1,20,Color("#eee8cc"))
	draw_string(font,Vector2(220,678),"Preview only / not available in the wardrobe",HORIZONTAL_ALIGNMENT_LEFT,-1,18,Color("#e6ba74"))

func _shot(index:int) -> void:
	pending=true
	await RenderingServer.frame_post_draw
	var image:=get_viewport().get_texture().get_image()
	if image==null or image.get_size()!=Vector2i(1280,720):push_error("Garment authoring actual window is not 1280x720");get_tree().quit(1);return
	var head_equal:=image.get_region(Rect2i(220,100,392,268)).get_data()==image.get_region(Rect2i(700,100,392,268)).get_data()
	var feet_equal:=image.get_region(Rect2i(220,534,392,70)).get_data()==image.get_region(Rect2i(700,534,392,70)).get_data()
	var path:=folder.path_join("captures/pose-%02d.png"%index)
	if FileAccess.file_exists(path) or image.save_png(path)!=OK:push_error("Garment native output already exists or could not be saved");get_tree().quit(1);return
	records.append({"frame":index,"head_render_exact":head_equal,"feet_render_exact":feet_equal,"time_scale":Engine.time_scale,"source_seconds":elapsed,"negative":negative})
	if not head_equal or not feet_equal:
		stopping=true
		FileAccess.open(folder.path_join("render-report.json"),FileAccess.WRITE).store_string(JSON.stringify(records,"  "))
		printerr("REJECTED: actual rendered garment wearer head/feet moved relative to original")
		get_tree().quit(1);return
	captured[index]=true;pending=false
