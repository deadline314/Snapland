from pathlib import Path
import shutil,os,time,json,subprocess
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();b=r/'work/outfit-authoring-20261021';stage=r/'work/tutorial-current-20261020/validation-project';shutil.copytree(b,stage/b.relative_to(r),dirs_exist_ok=True)
for case in ['normal-reviewed','quarter-reviewed','negative-reviewed']:
 out=b/case;out.mkdir(exist_ok=False)
 cmd=[str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'),'--path',str(stage),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--resolution','1280x720','--log-file',str(out/'engine.log'),'res://work/outfit-authoring-20261021/native_review.tscn','--fixed-fps','20']
 if case!='negative-reviewed':cmd+=['--write-movie',str(out/'play.avi')]
 if case!='normal-reviewed':cmd+=['--','--quarter' if case=='quarter-reviewed' else '--one-pixel-negative']
 start=time.monotonic();p=run_validated_godot(stage,cmd,dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'progress.json')),60);s=p.stdout+p.stderr;(out/'result.log').write_text(s);d=dict(exit=p.returncode,errors=s.count('ERROR:'),seconds=round(time.monotonic()-start,2));(out/'result.json').write_text(json.dumps(d,indent=2)+'\n');print(case,d,s[-600:],flush=True)
 if case=='negative-reviewed':assert p.returncode==1 and d['errors']==0 and 'REJECTED: actual rendered' in s
 else:assert p.returncode==0 and d['errors']==0 and 'PASS: native garment' in s
