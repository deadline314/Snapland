extends SceneTree
## Authoring-only full-canvas garment-layer probe. Never installed as a live outfit.
## Generated character anatomy is not used: only new garment pixels may composite.
const PALMS := [
 [Rect2i(103,205,28,34),Rect2i(188,240,28,32)],
 [Rect2i(102,206,30,34),Rect2i(186,239,30,34)],
 [Rect2i(65,236,31,37),Rect2i(150,203,30,36)],
 [Rect2i(69,237,31,37),Rect2i(149,203,31,38)],
 [Rect2i(100,209,30,37),Rect2i(185,240,31,39)],
 [Rect2i(101,210,33,38),Rect2i(190,246,32,36)],
 [Rect2i(65,244,32,39),Rect2i(146,216,34,38)],
 [Rect2i(69,241,32,42),Rect2i(149,211,34,39)]
]
func _initialize() -> void:
	var profile := OS.get_environment("SNAPLAND_SAVE_PATH")
	if not profile.is_absolute_path(): quit(2); return
	var folder := profile.get_base_dir()
	DirAccess.make_dir_recursive_absolute(folder)
	var base := ProjectSettings.globalize_path("res://work/outfit-authoring-20261021")
	var sheet := Image.load_from_file(base.path_join("front-coat-v1.png"))
	if sheet == null or sheet.get_size()!=Vector2i(1536,1024): quit(3); return
	sheet.convert(Image.FORMAT_RGBA8)
	var records: Array = []
	for index in 8:
		var original := Image.load_from_file(base.path_join("current-sources/sources/walk-front-%02d.png"%index))
		if original==null or original.get_size()!=Vector2i(280,360): quit(4); return
		original.convert(Image.FORMAT_RGBA8)
		var garment := Image.create(280,360,false,Image.FORMAT_RGBA8)
		var generated_cell := sheet.get_region(Rect2i((index%4)*384,int(index/4)*512,384,512))
		# One uniform whole-cell scale and placement for every frame. No alpha fit,
		# shoe alignment, anatomy retiming or per-frame scale/translation.
		generated_cell.resize(270,360,Image.INTERPOLATE_NEAREST)
		garment.blit_rect(generated_cell,Rect2i(0,0,270,360),Vector2i(5,0))
		var selected := PackedByteArray(); selected.resize(280*360)
		for y in range(192,310):
			for x in range(55,225):
				var p := garment.get_pixel(x,y)
				if p.a>0.4 and p.s>0.4 and p.v>0.15 and ((p.h>=0.09 and p.h<=0.20) or (p.h>=0.43 and p.h<=0.64)):
					selected[y*280+x]=1
		var expanded := selected.duplicate()
		for y in range(192,310):
			for x in range(55,225):
				if selected[y*280+x]==0: continue
				for dy in range(-1,2):
					for dx in range(-1,2): expanded[(y+dy)*280+x+dx]=1
		var output := original.duplicate()
		var layer := Image.create(280,360,false,Image.FORMAT_RGBA8)
		var changed := 0
		var new_silhouette := 0
		for y in range(192,310):
			for x in range(55,225):
				var point := Vector2i(x,y)
				if Rect2i(119,207,53,49).has_point(point) or PALMS[index][0].has_point(point) or PALMS[index][1].has_point(point): continue
				if expanded[y*280+x]==0:continue
				var color := garment.get_pixel(x,y)
				if color.a<=0.4:continue
				layer.set_pixel(x,y,color)
				output.set_pixel(x,y,color)
				changed+=1
				if original.get_pixel(x,y).a<=0.4:new_silhouette+=1
		var upper_equal := true
		var feet_equal := true
		for y in 360:
			for x in 280:
				if y<192 and output.get_pixel(x,y)!=original.get_pixel(x,y):upper_equal=false
				if y>=310 and output.get_pixel(x,y)!=original.get_pixel(x,y):feet_equal=false
		assert(upper_equal and feet_equal and changed>500 and new_silhouette>100)
		assert(output.save_png(folder.path_join("front-coat-%02d.png"%index))==OK)
		assert(layer.save_png(folder.path_join("front-garment-%02d.png"%index))==OK)
		records.append({"frame":index,"changed":changed,"new_silhouette":new_silhouette,"head_pixels_unchanged":upper_equal,"foot_pixels_unchanged":feet_equal,"state":"diagnostic_only_not_production"})
	FileAccess.open(folder.path_join("report.json"),FileAccess.WRITE).store_string(JSON.stringify(records,"  "))
	print("PASS: eight garment-only diagnostic composites retain original head and feet; visual garment/hand alignment still requires review")
	quit()
