extends SceneTree
## Authoring-only garment skinning with explicit source/target joint guides.
## The wearer is the immutable complete original cel. No RGB/anatomy inference.
const ROOT := Vector2(140,195)
const WIDTH_SCALE := 0.55
const WRISTS := [
 [Vector2(139,278),Vector2(307.5,322.5)],[Vector2(146.5,276),Vector2(309.5,321)],
 [Vector2(84.5,320.5),Vector2(250,282.5)],[Vector2(93,320.5),Vector2(263,276)],
 [Vector2(140.5,238.5),Vector2(305.5,275)],[Vector2(139.5,243),Vector2(309,275.5)],
 [Vector2(83,273),Vector2(254.5,245)],[Vector2(94.5,275),Vector2(266.5,240.5)]
]
const TARGETS := [
 [[Vector2(102,203),Vector2(87,231),Vector2(112,222)],[Vector2(181,204),Vector2(197,229),Vector2(198,252)]],
 [[Vector2(102,204),Vector2(87,232),Vector2(112,223)],[Vector2(181,204),Vector2(198,231),Vector2(196,252)]],
 [[Vector2(102,205),Vector2(86,231),Vector2(80,252)],[Vector2(181,202),Vector2(196,226),Vector2(164,225)]],
 [[Vector2(102,205),Vector2(87,232),Vector2(84,255)],[Vector2(181,204),Vector2(198,225),Vector2(166,223)]],
 [[Vector2(104,205),Vector2(87,237),Vector2(111,229)],[Vector2(181,206),Vector2(200,235),Vector2(200,261)]],
 [[Vector2(105,206),Vector2(90,238),Vector2(116,229)],[Vector2(181,208),Vector2(203,237),Vector2(204,267)]],
 [[Vector2(103,208),Vector2(87,240),Vector2(80,264)],[Vector2(182,206),Vector2(199,237),Vector2(161,239)]],
 [[Vector2(103,207),Vector2(87,240),Vector2(84,262)],[Vector2(181,205),Vector2(196,235),Vector2(167,230)]]
]
const PALMS := [
 [Rect2i(103,205,28,34),Rect2i(188,240,28,32)],[Rect2i(102,206,30,34),Rect2i(186,239,30,34)],
 [Rect2i(65,236,31,37),Rect2i(150,203,30,36)],[Rect2i(69,237,31,37),Rect2i(149,203,31,38)],
 [Rect2i(100,209,30,37),Rect2i(185,240,31,39)],[Rect2i(101,210,33,38),Rect2i(190,246,32,36)],
 [Rect2i(65,244,32,39),Rect2i(146,216,34,38)],[Rect2i(69,241,32,42),Rect2i(149,211,34,39)]
]
const TORSO := [Vector2(109,173),Vector2(146,165),Vector2(196,176),Vector2(248,165),Vector2(280,181),Vector2(281,205),Vector2(261,232),Vector2(260,302),Vector2(318,358),Vector2(296,394),Vector2(255,373),Vector2(241,328),Vector2(240,221),Vector2(159,221),Vector2(156,322),Vector2(145,369),Vector2(108,394),Vector2(71,359),Vector2(133,303),Vector2(135,237),Vector2(109,207)]
var sheet: Image
var output: Image
var garment_layer: Image

func _initialize() -> void:
	var profile := OS.get_environment("SNAPLAND_SAVE_PATH")
	if not profile.is_absolute_path(): quit(2);return
	var folder := profile.get_base_dir();DirAccess.make_dir_recursive_absolute(folder)
	var base := ProjectSettings.globalize_path("res://work/outfit-authoring-20261021")
	sheet=Image.load_from_file(base.path_join("front-coat-parts-v2.png"))
	if sheet==null or sheet.get_size()!=Vector2i(1564,1006):quit(3);return
	sheet.convert(Image.FORMAT_RGBA8)
	var records: Array = []
	for index in 8:
		var original := Image.load_from_file(base.path_join("current-sources/sources/walk-front-%02d.png"%index))
		original.convert(Image.FORMAT_RGBA8)
		output=original.duplicate();garment_layer=Image.create(280,360,false,Image.FORMAT_RGBA8)
		var cel := sheet.get_region(Rect2i((index%4)*391,int(index/4)*503,391,503))
		var dy: float = [0.0,0.0,0.0,0.0,-40.0,-36.0,-39.0,-38.0][index]
		var source_root := Vector2(196,210+dy)
		var torso := PackedVector2Array()
		for p in TORSO:torso.append(p+Vector2(0,dy))
		_draw_torso(cel,torso,source_root)
		for side in 2:
			var bent := (index%4<2) if side==0 else (index%4>=2)
			var wrist: Vector2=WRISTS[index][side]
			var shoulder := Vector2(146 if side==0 else 252,222+dy)
			var elbow := wrist+Vector2(-43,10) if side==0 and bent else wrist+Vector2(28,-55) if side==0 else wrist+Vector2(43,10) if bent else wrist+Vector2(-29,-54)
			_draw_arm(cel,[shoulder,elbow,wrist],TARGETS[index][side],side)
		# Layer ownership is the actual original wearer, never generated anatomy.
		for y in 360:
			for x in 280:
				var p := Vector2i(x,y)
				if y<192 or y>=310 or Rect2i(119,207,53,49).has_point(p) or PALMS[index][0].has_point(p) or PALMS[index][1].has_point(p):
					if original.get_pixelv(p).a>0.4:
						output.set_pixelv(p,original.get_pixelv(p));garment_layer.set_pixelv(p,Color.TRANSPARENT)
		var protected_equal := true
		for y in 360:
			for x in 280:
				if (y<192 or y>=310) and output.get_pixel(x,y)!=original.get_pixel(x,y): protected_equal=false
		if not protected_equal:push_error("Garment mesh changed a protected body region");quit(1);return
		if output.save_png(folder.path_join("front-rig-%02d.png"%index))!=OK or garment_layer.save_png(folder.path_join("layer-%02d.png"%index))!=OK:quit(1);return
		records.append({"frame":index,"original_head_feet_unchanged":protected_equal,"source_body_guide":[source_root.x,source_root.y],"source_wrist_guides":str(WRISTS[index]),"target_joint_guides":str(TARGETS[index]),"status":"authoring_probe_not_production"})
	FileAccess.open(folder.path_join("report.json"),FileAccess.WRITE).store_string(JSON.stringify(records,"  "))
	print("PASS: explicit-joint garment-only eight-frame authoring probe; visual acceptance still required")
	quit()

func _draw_torso(cel: Image, polygon: PackedVector2Array, source_root: Vector2) -> void:
	for y in range(192,310):
		for x in range(40,240):
			var uv := (Vector2(x+0.5,y+0.5)-ROOT)/WIDTH_SCALE+source_root
			if Geometry2D.is_point_in_polygon(uv,polygon):_sample(cel,uv,Vector2i(x,y))

func _bone_point(p:Vector2,a:Vector2,b:Vector2,c:Vector2,d:Vector2) -> Vector2:
	var axis:Vector2=(b-a).normalized();var normal:=Vector2(-axis.y,axis.x)
	var target_axis:Vector2=(d-c).normalized();var target_normal:=Vector2(-target_axis.y,target_axis.x)
	return c+target_axis*((p-a).dot(axis)*c.distance_to(d)/maxf(a.distance_to(b),0.001))+target_normal*((p-a).dot(normal)*WIDTH_SCALE)

func _skin(p:Vector2,src:Array,dst:Array) -> Vector2:
	var du:=p.distance_to(Geometry2D.get_closest_point_to_segment(p,src[0],src[1]))
	var dl:=p.distance_to(Geometry2D.get_closest_point_to_segment(p,src[1],src[2]))
	var weight:=clampf(0.5+(du-dl)/maxf(du+dl,1.0)*0.5,0.0,1.0)
	return _bone_point(p,src[0],src[1],dst[0],dst[1]).lerp(_bone_point(p,src[1],src[2],dst[1],dst[2]),weight)

func _arm_owns(p:Vector2,src:Array,side:int) -> bool:
	var du:=p.distance_to(Geometry2D.get_closest_point_to_segment(p,src[0],src[1]))
	var dl:=p.distance_to(Geometry2D.get_closest_point_to_segment(p,src[1],src[2]))
	# Explicit garment-side corridor prevents pulling the opposite torso panel.
	return minf(du,dl)<=25.0 and (p.x<173 if side==0 else p.x>226)

func _draw_arm(cel:Image,src:Array,dst:Array,side:int) -> void:
	for y in range(120,400,6):
		for x in range(45 if side==0 else 225,175 if side==0 else 345,6):
			var a:=Vector2(x,y);var b:=Vector2(x+6,y);var c:=Vector2(x+6,y+6);var d:=Vector2(x,y+6)
			_triangle(cel,[a,b,c],[_skin(a,src,dst),_skin(b,src,dst),_skin(c,src,dst)],src,side)
			_triangle(cel,[a,c,d],[_skin(a,src,dst),_skin(c,src,dst),_skin(d,src,dst)],src,side)

func _triangle(cel:Image,uv:Array,p:Array,src:Array,side:int) -> void:
	var minx:=maxi(0,floori(minf(p[0].x,minf(p[1].x,p[2].x))))
	var maxx:=mini(279,ceili(maxf(p[0].x,maxf(p[1].x,p[2].x))))
	var miny:=maxi(192,floori(minf(p[0].y,minf(p[1].y,p[2].y))))
	var maxy:=mini(309,ceili(maxf(p[0].y,maxf(p[1].y,p[2].y))))
	var v0:Vector2=p[1]-p[0];var v1:Vector2=p[2]-p[0];var den:=v0.cross(v1)
	if absf(den)<0.0001:return
	for y in range(miny,maxy+1):
		for x in range(minx,maxx+1):
			var v2:=Vector2(x+0.5,y+0.5)-Vector2(p[0]);var u:=v2.cross(v1)/den;var v:=v0.cross(v2)/den
			if u < -0.001 or v < -0.001 or u+v>1.001:continue
			var source_uv:Vector2=Vector2(uv[0])+(Vector2(uv[1])-Vector2(uv[0]))*u+(Vector2(uv[2])-Vector2(uv[0]))*v
			if _arm_owns(source_uv,src,side):_sample(cel,source_uv,Vector2i(x,y))

func _sample(cel:Image,uv:Vector2,point:Vector2i) -> void:
	var q:=Vector2i(floori(uv.x),floori(uv.y))
	if q.x<0 or q.y<0 or q.x>=391 or q.y>=503:return
	var color:=cel.get_pixelv(q)
	if color.a>0.4:
		output.set_pixelv(point,color);garment_layer.set_pixelv(point,color)
