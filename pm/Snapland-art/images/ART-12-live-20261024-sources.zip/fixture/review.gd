extends Node
const World = preload("res://game/world/park_world.gd")
var world: Node3D
func _ready() -> void:
	call_deferred("_run")
func _run() -> void:
	var folder := OS.get_environment("SNAPLAND_SAVE_PATH").get_base_dir()
	if DisplayServer.get_name()=="headless" or not folder.is_absolute_path():get_tree().quit(1);return
	world=World.new();add_child(world)
	await get_tree().create_timer(1.0).timeout
	var samples: Array=[]
	for actor in world.character_sprites:
		var role: String=actor.role
		world.player.position=actor.activity_root.global_position+Vector3(0,0,3)
		for shot in 4:
			await get_tree().create_timer(2.2).timeout
			await RenderingServer.frame_post_draw
			for current in world.character_sprites:
				var measured:=_feet(current.sprite)
				measured["role"]=str(current.role);measured["view_role"]=role;measured["shot"]=shot
				samples.append(measured)
				if measured.samples<5 or measured.minimum < -0.00001:
					FileAccess.open(folder.path_join("failed-feet.json"),FileAccess.WRITE).store_string(JSON.stringify(samples,"  "))
					push_error("Actual live NPC feet intersect terrain: "+str(measured));get_tree().quit(1);return
			var path:=folder.path_join("%s-%d.png"%[role,shot])
			if FileAccess.file_exists(path) or get_viewport().get_texture().get_image().save_png(path)!=OK:push_error("Exclusive NPC capture failed");get_tree().quit(1);return
	FileAccess.open(folder.path_join("feet.json"),FileAccess.WRITE).store_string(JSON.stringify(samples,"  "))
	world.queue_free();await get_tree().process_frame;await get_tree().process_frame
	print("PASS: current natural NPC activity sampled across three viewpoints with independent actual-alpha foot projection")
	get_tree().quit(0)
func _feet(sprite: Sprite3D) -> Dictionary:
	var image:=sprite.texture.get_image()
	var result:={"samples":0,"minimum":INF}
	var up:Vector3=world.camera.global_basis.y.normalized()
	var right:Vector3=world.camera.global_basis.x.normalized()
	for y in range(440,image.get_height()):
		for x in image.get_width():
			if image.get_pixel(x,y).a<0.5:continue
			var pixel:=Vector2(x+0.5-image.get_width()*0.5,image.get_height()*0.5-y-0.5)
			var point:Vector3=sprite.global_position+(right*pixel.x+up*pixel.y)*sprite.pixel_size
			result.samples+=1;result.minimum=minf(result.minimum,point.y-world._ground_surface_y(point))
	return result
