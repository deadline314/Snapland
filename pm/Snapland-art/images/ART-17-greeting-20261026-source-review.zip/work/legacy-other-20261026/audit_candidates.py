from PIL import Image,ImageDraw
from pathlib import Path
import json,hashlib,shutil
import numpy as np
b=Path('work/legacy-other-20261026')
for number,source in [(1,Path('/workspace/generated_images/exec-723b49c8-8aed-45a6-b5f3-06deac77e481.png')),(2,Path('/workspace/generated_images/exec-52267035-debb-4866-92d8-23e024977187.png'))]:
 d=b/f'candidate-wave-v{number}';d.mkdir(exist_ok=True);shutil.copy2(source,d/'source.png')
 if number==2:shutil.copy2(b/'wave-v2-prompt.txt',d/'prompt.txt')
 im=Image.open(source).convert('RGBA');rows=[];out=Image.new('RGB',(1536,1080),'#263d48');draw=ImageDraw.Draw(out)
 for i in range(6):
  cell=im.crop((i%3*512,i//3*512,(i%3+1)*512,(i//3+1)*512));opaque=cell.getchannel('A').point(lambda a:255 if a>128 else 0)
  # Match the same explicit camera-lens patch, independently of arms, alpha
  # bounds and soles. Each scan row allocates <8 MiB, not a giant image tensor.
  template=np.asarray(im.crop((281,270,323,314)).convert('RGB'),dtype=np.float32)
  pixels=np.asarray(cell.convert('RGB'),dtype=np.float32);best=(float('inf'),0,0)
  for sy in range(240,311):
   windows=np.lib.stride_tricks.sliding_window_view(pixels[sy:sy+44,180:370],(44,42),axis=(0,1))[0].transpose(0,2,3,1)
   scores=((windows-template)**2).mean(axis=(1,2,3));ix=int(scores.argmin());score=float(scores[ix])
   if score<best[0]:best=(score,180+ix,sy)
  center=best[1]+21;row=dict(frame=i,cell_origin=[i%3*512,i//3*512],opaque_bounds=list(opaque.getbbox()),camera_lens_template_center_x=center,camera_lens_template_center_y=best[2]+22,template_rgb_mean_square_error=round(best[0],3));rows.append(row)
  # Diagnostic only: fixed original grid, uniform 1:1 cells, no per-cel recenter.
  loc=(i%3*512,i//3*540);back=Image.new('RGBA',(512,512),'#e5e1d2');back.alpha_composite(cell);out.paste(back.convert('RGB'),loc);draw.line((loc[0]+256,loc[1],loc[0]+256,loc[1]+512),fill='#ff00cc',width=2);draw.text((loc[0]+8,loc[1]+514),f'frame {i}: lens X={center:.2f}; ground={row["opaque_bounds"][3]}',fill='white')
 spread=round(max(r['camera_lens_template_center_x'] for r in rows)-min(r['camera_lens_template_center_x'] for r in rows),3)
 report=dict(tool='image_gen.imagegen',source_original=str(source),sha256=hashlib.sha256(source.read_bytes()).hexdigest(),transparent_background_requested=True,reference=str(b/'result/profile/wave.png') if number==1 else str(b/'candidate-wave-v1/source.png'),prompt_file='prompt.txt',frames=rows,camera_x_spread_px=spread,accepted=False,decision='Rejected: unchanged torso camera material varies horizontally within the promised equal cells, and bottom row ground differs. Do not silently recenter each frame by its alpha bounds or soles; no production assets changed.',visual_review='Both entire six-pose sheets and v1 white-background alpha diagnostic actually viewed. Initial dark viewer showed glow-colored transparent RGB; alpha audit/white composition supersede that initial background concern. Rejection is based on registration and changing figure, not RGB of alpha-zero background.',scope='Still source diagnostics, not native animation playback or gameplay acceptance.')
 (d/'review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');out.save(d/'fixed-grid-diagnostic.png');print(number,'camera_x_spread_px',spread,'ground',[r['opaque_bounds'][3] for r in rows])
