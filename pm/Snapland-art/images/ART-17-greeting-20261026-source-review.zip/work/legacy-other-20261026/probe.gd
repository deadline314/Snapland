extends SceneTree
const Avatar=preload("res://game/world/avatar_renderer.gd")
func _initialize() -> void:
 var folder:=OS.get_environment("SNAPLAND_SAVE_PATH").get_base_dir()
 if not folder.is_absolute_path():quit(2);return
 DirAccess.make_dir_recursive_absolute(folder)
 var avatar:=Avatar.new();var rows: Array=[]
 for index in range(12,16):
  var raw: Image=avatar._atlas_pose_image(index)
  raw.save_png(folder.path_join(avatar.ACTIONS[index-12]+".png"))
  rows.append({"action":avatar.ACTIONS[index-12],"source_sha256":avatar.head_source_signature(raw),"source_bounds":str(raw.get_used_rect())})
 FileAccess.open(folder.path_join("sources.json"),FileAccess.WRITE).store_string(JSON.stringify(rows,"  "))
 print("PASS: four existing raw static sources exported without changes")
 quit()
