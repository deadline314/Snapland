from pathlib import Path
import shutil,os,time,json
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();stage=r/'work/tutorial-current-20261020/validation-project'
name='game/tests/native_actor_alpha_shadow_review.gd';shutil.copy2(r/name,stage/name)
for label,args in [('lshape',[]),('base',['--','--character']),('vest-hat-wave',['--','--character','--rainvest','--hat','--wave']),('low-resolution-negative',['--','--low-resolution-negative']),('live-texture',['--','--live-texture'])]:
 out=r/'work/remaining-20261024'/('alpha-shadow-upright-v2-'+label);out.mkdir(exist_ok=False)
 cmd=[str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'),'--path',str(stage),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--resolution','1280x720','--script','res://'+name,*(args+['--candidate','--upright'] if args else ['--','--candidate','--upright'])]
 t=time.monotonic();p=run_validated_godot(stage,cmd,dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'save/progress.json')),60)
 log=p.stdout+p.stderr;(out/'result.log').write_text(log)
 report={'exit':p.returncode,'errors':log.count('ERROR:'),'seconds':round(time.monotonic()-t,2),'expected_failure':label=='low-resolution-negative','command':cmd}
 (out/'result.json').write_text(json.dumps(report,indent=2));print(report)
 assert (p.returncode!=0) == (label=='low-resolution-negative')
 assert report['errors']==(1 if label=='low-resolution-negative' else 0)
