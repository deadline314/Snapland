"""Lossless storage of opaque screenshot matrices; never an animation record.

repack RAW.zip replaces PNG payloads with a lossless RGB container plus names,
dimensions and original-byte/decoded-pixel hashes. Transparent PNGs stay intact.
extract PACK.zip NEW_DIRECTORY recreates PNG pixel data (encoding may differ).
"""
from pathlib import Path
from PIL import Image,PngImagePlugin
import hashlib,io,json,subprocess,sys,tempfile,zipfile

def digest(data):return hashlib.sha256(data).hexdigest()
def read_exact(stream,count):
 data=bytearray()
 while len(data)<count:
  part=stream.read(count-len(data))
  if not part:raise ValueError('Missing decoded frame bytes')
  data.extend(part)
 return bytes(data)
def decoded_frames(movie,manifest):
 width,height=manifest['canvas'];size=width*height*3
 command=['ffmpeg','-v','error','-i',str(movie),'-f','rawvideo','-pix_fmt','rgb24','pipe:1']
 p=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 try:
  for record in manifest['frames']:
   frame=Image.frombytes('RGB',(width,height),read_exact(p.stdout,size))
   image=frame.crop((0,0,*record['size'])).convert('RGBA')
   assert digest(image.tobytes())==record['rgba_sha256'],record['name']
   yield record,image
  assert not p.stdout.read(1),'Unexpected extra frames'
  error=p.stderr.read();assert p.wait()==0,error
 finally:
  if p.poll() is None:p.kill();p.wait()
def repack(path):
 path=Path(path);original_size=path.stat().st_size
 with tempfile.TemporaryDirectory(prefix='matrix-',dir=path.parent) as temporary:
  temporary=Path(temporary);movie=temporary/'frames.mkv';records=[]
  with zipfile.ZipFile(path) as old:
   for name in old.namelist():
    if not name.endswith('.png'):continue
    payload=old.read(name);image=Image.open(io.BytesIO(payload)).convert('RGBA')
    if image.getchannel('A').getextrema()!=(255,255):continue
    assert not any(k in image.info for k in ['icc_profile','gamma','chromaticity']), 'Unsupported color metadata; retain original PNG instead'
    records.append({'name':name,'color_metadata':{k:image.info[k] for k in ['srgb'] if k in image.info},'size':list(image.size),'original_png_sha256':digest(payload),'rgba_sha256':digest(image.tobytes())})
   assert records,'No opaque screenshots to pack'
   width=max(x['size'][0] for x in records);height=max(x['size'][1] for x in records);width+=width%2;height+=height%2
   cmd=['ffmpeg','-n','-v','error','-f','rawvideo','-pixel_format','rgb24','-video_size',f'{width}x{height}','-framerate','1','-i','pipe:0','-c:v','libx264rgb','-threads','2','-preset','veryfast','-crf','0','-pix_fmt','rgb24','-fps_mode','passthrough',str(movie)]
   p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
   try:
    for record in records:
     image=Image.open(io.BytesIO(old.read(record['name']))).convert('RGB');canvas=Image.new('RGB',(width,height));canvas.paste(image,(0,0));p.stdin.write(canvas.tobytes())
    p.stdin.close();error=p.stderr.read();assert p.wait()==0,error
   finally:
    if p.poll() is None:p.kill();p.wait()
   manifest={'format':'snapland-lossless-capture-matrix-v1','not_animation':True,'canvas':[width,height],'alpha_restored':255,'codec':'libx264rgb CRF 0; variable-size images padded only for storage','png_encoding_note':'Decoded RGBA pixels are identical; recreated PNG compressed bytes may differ. Transparent PNGs retain original bytes.','frames':records,'container_sha256':digest(movie.read_bytes())}
   assert sum(1 for _ in decoded_frames(movie,manifest))==len(records)
   names={x['name'] for x in records};replacement=temporary/'replacement.zip'
   with zipfile.ZipFile(replacement,'w',zipfile.ZIP_DEFLATED) as new:
    for name in old.namelist():
     if name not in names:new.writestr(name,old.read(name))
    new.write(movie,'__matrix__/frames.mkv');new.writestr('__matrix__/manifest.json',json.dumps(manifest,indent=2)+'\n')
   with zipfile.ZipFile(replacement) as new:
    assert new.testzip() is None
    assert digest(new.read('__matrix__/frames.mkv'))==manifest['container_sha256']
  if replacement.stat().st_size>=original_size:raise ValueError('Lossless matrix did not reduce storage')
  replacement.replace(path)
 return {'file':str(path),'original_bytes':original_size,'packed_bytes':path.stat().st_size,'pixel_verified_frames':len(records)}
def extract(path,output):
 output=Path(output);output.mkdir(parents=True,exist_ok=False)
 with zipfile.ZipFile(path) as z,tempfile.TemporaryDirectory(prefix='matrix-extract-') as temporary:
  manifest=json.loads(z.read('__matrix__/manifest.json'));movie=Path(temporary)/'frames.mkv';movie.write_bytes(z.read('__matrix__/frames.mkv'));assert digest(movie.read_bytes())==manifest['container_sha256']
  for record,image in decoded_frames(movie,manifest):
   name=Path(record['name']);assert not name.is_absolute() and '..' not in name.parts
   target=output/name;target.parent.mkdir(parents=True,exist_ok=True)
   color=record.get('color_metadata',{});info=PngImagePlugin.PngInfo()
   if 'srgb' in color:info.add(b'sRGB',bytes([int(color['srgb'])]))
   image.save(target,pnginfo=info)
   assert Image.open(target).info.get('srgb')==color.get('srgb')
   assert digest(Image.open(target).convert('RGBA').tobytes())==record['rgba_sha256']
  for name in z.namelist():
   if name.startswith('__matrix__/'):continue
   relative=Path(name);assert not relative.is_absolute() and '..' not in relative.parts
   target=output/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(name))
 return {'extracted_frames':len(manifest['frames']),'all_rgba_hashes_match':True}
if __name__=='__main__':
 if sys.argv[1]=='repack':print(json.dumps(repack(sys.argv[2])))
 elif sys.argv[1]=='extract':print(json.dumps(extract(sys.argv[2],sys.argv[3])))
 else:raise SystemExit(__doc__)
