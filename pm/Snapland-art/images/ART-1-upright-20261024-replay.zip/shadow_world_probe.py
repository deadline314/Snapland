from pathlib import Path
import shutil,os,time,json,sys,subprocess
from types import SimpleNamespace
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();stage=r/'work/tutorial-current-20261020/validation-project';out=r/'work/remaining-20261024'/('shadow-world-'+sys.argv[1]);out.mkdir(exist_ok=False)
f='work/remaining-20261024/shadow-world-probe';shutil.copytree(r/f,stage/f,dirs_exist_ok=True)
cmd=[str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'),'--path',str(stage),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--resolution','1280x720','--position','0,0','res://'+f+'/entry.tscn'];t=time.monotonic()
rec=subprocess.Popen(['ffmpeg','-n','-v','error','-f','x11grab','-video_size','1280x720','-framerate','15','-i',os.environ['DISPLAY'],'-t','270','-c:v','libx264','-threads','2','-preset','ultrafast','-crf','22','-pix_fmt','yuv420p',str(out/'native-world.mp4')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
try:
 p=run_validated_godot(stage,cmd,dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'save/progress.json'),SNAPLAND_EXPECT_ALPHA_CASTERS='1',SNAPLAND_SHADOW_QUARTER='1' if 'quarter' in sys.argv[1] else '0'),240)
except subprocess.TimeoutExpired as e:
 def decoded(value):return value.decode(errors='replace') if isinstance(value,bytes) else value or ''
 p=SimpleNamespace(returncode=124,stdout=decoded(e.stdout),stderr=decoded(e.stderr))
finally:
 _,error=rec.communicate('q\n',timeout=15);(out/'record.log').write_text(error)
s=p.stdout+p.stderr;(out/'result.log').write_text(s);d={'exit':p.returncode,'errors':s.count('ERROR:'),'seconds':round(time.monotonic()-t,2),'engine_time_scale':0.25 if 'quarter' in sys.argv[1] else 1.0};(out/'result.json').write_text(json.dumps(d,indent=2));print(d);print(s[-1800:]);assert p.returncode==0 and d['errors']==0
