from pathlib import Path
from PIL import Image,ImageDraw
import subprocess,json
r=Path('work/remaining-20261024');out=r/'actor-shadow-review-contacts'
def page(paths,label):
 for offset in range(0,len(paths),4):
  canvas=Image.new('RGB',(2560,1480),'#223747');d=ImageDraw.Draw(canvas)
  for i,p in enumerate(paths[offset:offset+4]):
   x=(i%2)*1280;y=(i//2)*740;canvas.paste(Image.open(p).convert('RGB'),(x,y+20));d.text((x+10,y+2),p.name,fill='white')
  canvas.save(out/f'{label}-{offset//4+1}.png')
page(sorted((r/'shadow-world-after-upright-quarter-v1/save').glob('*.png')),'world-quarter')
page(sorted(p for p in (r/'alpha-world-lighting-v2').glob('light-*.png') if p.name!='light-night-reduced-plaza.png'),'main-phases')
old=out/'main-phases-5.png'
if old.exists():old.unlink()
page(sorted((r/'release-actor-shadow-smoke-v1/profile').glob('art-smoke-*.png')),'release-smoke')
paths=sorted((r/'alpha-world-lighting-v2').glob('shadow-*.png'))
for offset in range(0,len(paths),12):
 canvas=Image.new('RGB',(2040,2800),'#223747');d=ImageDraw.Draw(canvas)
 for i,p in enumerate(paths[offset:offset+12]):
  pic=Image.open(p).convert('RGB');assert pic.width<=680 and pic.height<=680
  x=(i%3)*680;y=(i//3)*700;canvas.paste(pic,(x,y+20));d.text((x+5,y+2),p.name,fill='white')
 canvas.save(out/f'main-shadow-masks-{offset//12+1}.png')
for phase in ['dawn','noon','dusk','night']:
 canvas=Image.new('RGB',(880,340),'#223747');d=ImageDraw.Draw(canvas)
 for i,folder in enumerate(['shadow-world-before-v1','shadow-world-after-upright-normal-v1']):
  p=r/folder/'save'/f'{phase}-idle.png';pic=Image.open(p).convert('RGB').crop((400,275,840,595));canvas.paste(pic,(i*440,20));d.text((i*440+5,2),('before volumes' if i==0 else 'after upright alpha')+' / '+phase,fill='white')
 canvas.save(out/f'before-after-{phase}.png')
metadata=[]
for label,folder,movie in [('normal','shadow-world-after-upright-normal-v1','native-world.mp4'),('quarter','shadow-world-after-upright-quarter-v1','native-world.mp4'),('release','release-actor-shadow-smoke-v1','actual-release.mp4')]:
 path=r/folder/movie
 probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-select_streams','v:0','-show_entries','stream=width,height,r_frame_rate,nb_read_frames:format=duration','-of','json',str(path)],text=True))
 subprocess.run(['ffmpeg','-v','error','-i',str(path),'-f','null','-'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
 duration=float(probe['format']['duration']);samples=[]
 for i,fraction in enumerate([.1,.25,.4,.55,.75,.95]):
  output=out/f'film-{label}-{i+1}.png';seconds=duration*fraction
  subprocess.run(['ffmpeg','-n','-v','error','-ss',str(seconds),'-i',str(path),'-frames:v','1',str(output)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE);samples.append(output)
 page(samples,f'film-{label}-contact');metadata.append({'label':label,'file':str(path),'probe':probe,'fully_decoded':True,'samples_seconds':[round(duration*f,3) for f in [.1,.25,.4,.55,.75,.95]],'review_scope':'sample frames, not continuous watching or listening'})
(r/'actor-shadow-films.json').write_text(json.dumps(metadata,indent=2)+'\n')
print('PASS: full decode and six sample frames per actual capture movie',flush=True)
