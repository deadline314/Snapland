from pathlib import Path
import os,json,hashlib,shutil,time
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();b=r/'work/remaining-20261024/release-actor-shadow-v2';stage=b/'project';old=json.loads((b/'build.json').read_text());guards=json.loads((r/'work/remaining-20261024/actor-shadow-final-guards-v2/results.json').read_text());assert len(guards)==2 and all(x['error'] is None for x in guards)
prior_binary=b/'release/Snapland.x86_64';assert hashlib.sha256(prior_binary.read_bytes()).hexdigest()==old['binary']['sha256'];(b/'rejected-build.json').write_text(json.dumps(old,indent=2)+'\n');prior_binary.unlink()
changed=[name for name,sha in old['source_sha256'].items() if hashlib.sha256((r/name).read_bytes()).hexdigest()!=sha];assert changed==['game/world/actor_shadow_silhouette.gd'],changed
for name in changed:shutil.copy2(r/name,stage/name)
engine=r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64';output=b/'release-final';output.mkdir(exist_ok=False);binary=output/'Snapland.x86_64';steps=[]
for label,args in [('final-import',['--editor','--import','--quit']),('final-export',['--editor','--export-release','Linux Desktop',str(binary),'--quit'])]:
 t=time.monotonic();p=run_validated_godot(stage,[str(engine),'--headless','--path',str(stage),*args],dict(os.environ,SNAPLAND_SAVE_PATH=str(b/'final-build-profile/progress.json')),300);log=p.stdout+p.stderr;(b/(label+'.log')).write_text(log);steps.append({'step':label,'exit':p.returncode,'errors':log.count('ERROR:'),'seconds':round(time.monotonic()-t,2)});assert p.returncode==0 and 'ERROR:' not in log
assert binary.read_bytes()[:4]==b'\x7fELF';binary.chmod(binary.stat().st_mode|0o111)
for name in old['source_sha256']:old['source_sha256'][name]=hashlib.sha256((r/name).read_bytes()).hexdigest()
old.update(steps=steps,binary={'file':'release-final/Snapland.x86_64','bytes':binary.stat().st_size,'sha256':hashlib.sha256(binary.read_bytes()).hexdigest()},source_note='source_commit is the preceding base commit; source_sha256 records actual working-tree runtime bytes. Final guarded source supersedes rejected-build.json.',superseded_binary_removed='release/Snapland.x86_64',reason='detached-actor fallback contract failed before final tree-membership guard')
(b/'build.json').write_text(json.dumps(old,indent=2)+'\n');print('PASS final guarded export',old['binary'])
