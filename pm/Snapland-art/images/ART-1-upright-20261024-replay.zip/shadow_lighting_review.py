from pathlib import Path
import os,json,time
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();stage=r/'work/tutorial-current-20261020/validation-project';out=r/'work/remaining-20261024/alpha-world-lighting-v2';out.mkdir(exist_ok=False)
cmd=[str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'),'--path',str(stage),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--resolution','1280x720','--log-file',str(out/'engine.log'),'res://game/tests/native_light_occlusion_review.tscn','--','--lighting'];t=time.monotonic()
p=run_validated_godot(stage,cmd,dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'save/progress.json'),SNAPLAND_REVIEW_OUT=str(out)),240);s=p.stdout+p.stderr;(out/'result.log').write_text(s);d={'exit':p.returncode,'errors':s.count('ERROR:'),'seconds':round(time.monotonic()-t,2)};(out/'result.json').write_text(json.dumps(d,indent=2));print(d);print(s[-3000:]);assert p.returncode==0 and d['errors']==0
