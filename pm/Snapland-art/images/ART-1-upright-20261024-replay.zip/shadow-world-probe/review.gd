extends Node
const World = preload("res://game/world/park_world.gd")
var world: Node3D
var folder := ""
var rows: Array=[]
func _ready() -> void:call_deferred("run")
func run() -> void:
	folder=OS.get_environment("SNAPLAND_SAVE_PATH").get_base_dir()
	if not folder.is_absolute_path() or DisplayServer.get_name()=="headless":get_tree().quit(2);return
	DirAccess.make_dir_recursive_absolute(folder)
	Engine.time_scale=0.25 if OS.get_environment("SNAPLAND_SHADOW_QUARTER")=="1" else 1.0
	world=World.new();add_child(world)
	world.set_avatar_look(world.avatar_appearance,{"outfit":"outfit-rainvest","hat":"hat-straw"})
	world.player.position=Vector3(0,0.4,-6)
	await get_tree().create_timer(1.0).timeout
	for phase in ["dawn","noon","dusk","night"]:
		world.set_time_of_day(phase)
		await get_tree().create_timer(0.6).timeout
		if not await capture(phase+"-idle"):return
	for action in ["wave","photograph","interact"]:
		world.play_action(action)
		await get_tree().create_timer(0.35).timeout
		if not await capture("night-"+action):return
		await get_tree().create_timer(world.avatar_action_remaining+0.1).timeout
	# Actual project input drives the same world walk/stop route as the player.
	for entry in [["move_right"],["move_right","move_up"],["move_up"],["move_left","move_up"],["move_left"],["move_left","move_down"],["move_down"],["move_right","move_down"]]:
		for action in entry:Input.action_press(action)
		await get_tree().create_timer(0.3).timeout
		if not await capture("night-walk-"+str(rows.size())):return
		for action in entry:Input.action_release(action)
		await get_tree().create_timer(0.15).timeout
	world.apply_settings({"reduced_motion":true})
	await get_tree().create_timer(0.3).timeout
	if not await capture("night-reduced"):return
	FileAccess.open(folder.path_join("report.json"),FileAccess.WRITE).store_string(JSON.stringify(rows,"  "))
	world.queue_free()
	for index in 5:await get_tree().process_frame
	print("PASS: native world shadow review four phases, authored actions, eight real input headings and reduced motion")
	get_tree().quit()
func capture(label: String) -> bool:
	await RenderingServer.frame_post_draw
	var records: Array=[]
	for record in world.actor_shadow_proxies:
		var nodes: Array=[]
		for node in record.node.get_children():
			if node is GeometryInstance3D and node.visible:nodes.append(str(node.name))
		if OS.get_environment("SNAPLAND_EXPECT_ALPHA_CASTERS")=="1":
			var shadow: MeshInstance3D=record.get("silhouette")
			if not is_instance_valid(shadow) or nodes.size()!=1 or shadow.silhouette_material.albedo_texture!=shadow.source.texture or not shadow.global_position.is_equal_approx(shadow.source.global_position):
				push_error("World caster did not follow its actual final texture and pose: "+str(record.role));get_tree().quit(1);return false
			nodes.append("source:"+shadow.source.texture.get_class())
		records.append({"role":str(record.role),"casters":nodes})
	var lights:=0;var shadows:=0
	for lamp in world.lamps:
		if lamp.light_energy>0:lights+=1
		if lamp.shadow_enabled:shadows+=1
	if lights>8 or shadows>2:push_error("Light budget changed");get_tree().quit(1);return false
	var image:=get_viewport().get_texture().get_image()
	if image.save_png(folder.path_join(label+".png"))!=OK:push_error("Cannot save review capture");get_tree().quit(1);return false
	rows.append({"time_scale":Engine.time_scale,"label":label,"hero_action":world.last_avatar_action,"hero_direction":world.last_avatar_direction,"hero_frame":world.last_avatar_frame,"casters":records,"lights":lights,"point_shadows":shadows})
	return true
