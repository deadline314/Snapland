"""Verify side photo input, source ownership, and the embedded Windows scene."""
from pathlib import Path
import sys

here = Path(__file__).resolve().parent
template = here.parent / "art16-20261119/verify_departure.py"
source = template.read_text("utf8").replace("D:/Snapland-QA/art16-20261119","D:/Snapland-QA/art17-side-photo-20261119")
source = source.replace("spec.loader.exec_module(runner)", '''
local_stage = ROOT / ".review/art17-side-photo-20261119/runtime-staging"
d_stage = Path("D:/Snapland-QA/art17-side-photo-20261119")
runner_source = helper.read_text("utf8")
runner_source = runner_source.replace('donor.drive.upper() == "D:" and donor.parent in {QA, QA.parent / "task4"}',
    'donor.parent in {QA, ROOT / ".review/art17-side-photo-20261119/runtime-staging"}')
runner_source = runner_source.replace('Path(keys[key]).drive.upper() == "D:"', 'Path(keys[key]).drive == base.drive')
exec(compile(runner_source, str(helper), "exec"), runner.__dict__)
''')
source = source.replace('runner.QA = Path("D:/Snapland-QA/art17-side-photo-20261119")',
    'runner.QA = d_stage if sys.argv[1] == "package" else local_stage')
source = source.replace('ART_FILE = "assets/characters/announcer-departure-sides-v1.png"',
    'ART_FILES = [f"assets/characters/traveller-photograph-{side}-v1.png" for side in ("left","right")]')
source = source.replace("paths = list(dict.fromkeys([*paths, ART_FILE]))","paths = list(dict.fromkeys([*paths, *ART_FILES]))")
start = source.index("FIXTURE =")
end = source.index("paths = subprocess.check_output",start)
source = source[:start] + '''FIXTURE = "game/tests/native_profile_photo_study"
TESTS = {
    "test_avatar_motion_world": "PASS: integrated avatar motion world checks",
    "test_avatar_prop_foreground": "PASS: prop foreground 128 complete-pose blends, independent hand/camera witnesses, rigid guards, exact-source rejection, bounded cache and 10 malformed inputs",
    "test_garment_overlay": "PASS: garment overlay preserves 191 original compositions; missing last cel falls back across all eight directions",
    "test_garment_cache": "PASS: garment cache bounds 344 exact blends, 512 warm hits and atomic missing or changed reload recovery",
    "test_island_hair_sources": "PASS: alternate island hair ownership remains registered across 200 actual walk and idle/blink cels",
}
runner.FIXTURES = [FIXTURE+".gd",FIXTURE+".tscn","game/tests/native_island_animation_acceptance.gd",
                   *["game/tests/"+name+".gd" for name in TESTS]]
def fixture_source(name):
    return {FIXTURE+".gd":HERE/"native_capture.gd",FIXTURE+".tscn":HERE/"native_capture.tscn"}.get(name,ROOT/name)
''' + source[end:]
source = source.replace("runner.sha(ROOT/name) for name in runner.FIXTURES","runner.sha(fixture_source(name)) for name in runner.FIXTURES")
source = source.replace("shutil.copy2(ROOT/name,target)","shutil.copy2(fixture_source(name),target)")
source = source.replace("AnnouncerDepartureQA.exe","AvatarProfilePhotoQA.exe")
source = source.replace('"--actor=announcer"','"--actor=traveller"')
start = source.index('    report=runner.read(out/"announcer-report.json")')
end = source.index("    assert movie.stat().st_size",start)
source = source[:start] + '''    report = runner.read(out/"traveller-report.json")
    assert report["technical_status"]=="PASS" and not report["failures"]
    assert report["scene_rebuild"] == (mode in ("quarter","reduced"))
    assert report["reduced_motion"] == (mode=="reduced")
    assert report["playback_mode"].startswith("quarter" if mode=="quarter" else "normal")
    if mode!="reduced":
        cases=[item for item in report["actions"] if item["label"].endswith("-profile-photo")]
        assert len(cases)==6 and all(item["predicate"] for item in cases)
        assert {(row["label"],row["direction"]) for row in cases}=={
            (look+"-profile-photo",side) for look in ("base","rainvest","hat-and-bob") for side in ("left","right")}
''' + source[end:]
exec(compile(source,str(here/"final_checks.py"),"exec"))
