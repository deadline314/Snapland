from PIL import Image, ImageDraw
from pathlib import Path
import sys
sys.path.insert(0,str(Path(".review/art17-side-photo-20261119").resolve()))
from preview import FOREGROUND
repo=Path.cwd()
folder=Path("D:/Snapland-QA/art17-side-photo-20261119/side-photo-with-owners-1119-074427-eddb95/captures")
targets={
    "left": [(96,220,172,268),(101,223,174,265),(98,227,168,270)],
    "right": [(109,222,192,267),(112,218,190,267),(111,229,188,268)]
}
output=repo/".review/art17-side-photo-20261119"
result=Image.new("RGB",(840,720),(230,226,210))
for row,side in enumerate(targets):
    template=Image.open(repo/f"assets/characters/rainvest-v1/idle-{side}-00.pngdata").convert("RGBA")
    template=template.crop(template.getbbox())
    for index,target in enumerate(targets[side]):
        x,y,end,bottom=target
        src=Image.open(folder/f"{side}-{index}-source.png").convert("RGBA")
        overlay=Image.new("RGBA",src.size)
        overlay.paste(template.resize((end-x,bottom-y),Image.Resampling.NEAREST),(x,y))
        protect=Image.new("1",src.size)
        ImageDraw.Draw(protect).polygon(FOREGROUND[side][index],fill=1)
        for yy in range(y,bottom):
            for xx in range(x,end):
                r,g,b,a=src.getpixel((xx,yy))
                # Preserve the arms/prop and side of the backpack beside the torso.
                is_pack = yy<250 and r>g and g>b and not (r>145 and g>111 and yy>250) and ((side=="left" and xx>152) or (side=="right" and xx<133))
                if protect.getpixel((xx,yy)) or is_pack:
                    overlay.putpixel((xx,yy),(0,0,0,0))
        overlay.save(output/f"photograph-{side}-{index:02}.png")
        posed=Image.alpha_composite(src,overlay)
        result.paste(posed,(index*280,row*360),posed)
result.save(output/"fabric-adjusted.png")
