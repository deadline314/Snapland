extends "res://game/tests/native_island_animation_acceptance.gd"

var capture_prefix := "profile"

func _store_capture(label: String, image: Image, framing: Dictionary = {}) -> void:
	super._store_capture(capture_prefix + "-" + label, image, framing)

func _hero_actions() -> void:
	_world.set_avatar_hair_motion_enabled(false)
	var original: Dictionary = _world.avatar_appearance.duplicate(true)
	var pairs := [["right",KEY_D],["left",KEY_A]]
	for look in ["base","rainvest","hat-and-bob"]:
		var appearance := original.duplicate()
		if look=="hat-and-bob": appearance.hair="bob"
		var equipped := {"outfit":"outfit-rainvest" if look=="rainvest" else "outfit-tide",
						 "hat":"hat-straw" if look=="hat-and-bob" else "hat-none"}
		_world.set_avatar_look(appearance,equipped)
		for pair in pairs:
			var side: String=pair[0]
			var key: int=pair[1]
			capture_prefix=look+"-"+side
			_press(key,true)
			await _physics_frames(12)
			_press(key,false)
			var resting := await _wait_hero_settle()
			if not resting.complete or _world.facing!=side:
				_fail("Real movement did not reach the facing needed for "+side)
				return
			var root_before: Vector3=_world.player.global_position
			var clip:=_sequence("photograph",side)
			_begin_observation("hero_sequence","photograph")
			_press(KEY_P,true)
			await _frames(1)
			_press(KEY_P,false)
			var started := _simulated_seconds
			var actual_drift := 0.0
			while _simulated_seconds-started<1.26 and _within_budget():
				await RenderingServer.frame_post_draw
				actual_drift=maxf(actual_drift,root_before.distance_to(_world.player.global_position))
			var observed:=_end_observation()
			_flush_buffered_captures()
			var complete: bool=bool(clip.get("available",false)) and observed.frames.size()==3 and bool(observed.source_consistent) and observed.get("direction","")==side
			complete=complete and _world.facing==side and _world.last_avatar_action=="idle" and actual_drift<=0.00001
			await _record_action(look+"-profile-photo","photograph",side,"authored",_actor_anchor(),complete,
				{"observed":observed,"facing_after":_world.facing,"root_drift":actual_drift,"clip_frames":clip.get("frames",[]).size()})
