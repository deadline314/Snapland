import os
from pathlib import Path
import subprocess
root=Path(__file__).resolve().parents[2]
base=Path(__file__).resolve().parent
engine=r'C:\Tools\Godot\Godot_v4.7.2-stable_win64_console.exe'
def run(name,scene,arguments=(),environment=None,movie=False):
 env=dict(os.environ,SNAPLAND_SAVE_PATH=str(base/(name+'-profile.json')))
 env.update(environment or {})
 args=[engine,'--path',str(root),'--rendering-method','gl_compatibility','--audio-driver','Dummy']
 if movie: args += ['--write-movie',str(base/(name+'.avi')),'--fixed-fps','30']
 args += ['res://game/tests/'+scene+'.tscn']
 if arguments: args += ['--',*arguments]
 with (base/(name+'.log')).open('w',encoding='utf-8') as log:
  done=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 text=(base/(name+'.log')).read_text(encoding='utf-8')
 if done.returncode or 'ERROR:' in text or 'PASS:' not in text: raise RuntimeError(name+' failed '+text[-2000:])
 print(name,'PASS',flush=True)
run('gallery-accepted','native_wardrobe_pose_review',environment={'SNAPLAND_WARDROBE_POSE_DIR':str(base/'sheets-accepted')})
for mode in ['normal','quarter','reduced']:
 name='accepted-'+mode
 run(name,'native_wardrobe_motion_review',[] if mode=='normal' else ['--'+mode],{'SNAPLAND_WARDROBE_MOTION_DIR':str(base/name)},True)
for mode in ['normal','quarter']:
 name='reverse-'+mode
 run(name,'native_island_hair_binding',['--hair-reverse-only'],{'SNAPLAND_ISLAND_HAIR_DIR':str(base/name),'SNAPLAND_ISLAND_HAIR_STYLE':'curly','SNAPLAND_ISLAND_HAIR_QUARTER':'1' if mode=='quarter' else '0'})
