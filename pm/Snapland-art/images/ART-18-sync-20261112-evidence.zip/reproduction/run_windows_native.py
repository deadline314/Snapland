import os
from pathlib import Path
import subprocess
root=Path('.').resolve()
out=root/'build/Snapland-preview-20261112'
env=dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'native-verified/progress.json'))
r=subprocess.run([str(out/'Snapland.exe'),'--audio-driver','Dummy','--','--smoke-test','--smoke-art'],env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=150)
log=r.stdout+r.stderr
(out/'native-smoke-verified.log').write_text(log,encoding='utf-8')
print('exit',r.returncode,'errors',log.count('ERROR:'),'captures',len(list((out/'native-verified').glob('art-smoke-*.png'))))
print(log[-1800:])
if r.returncode or 'ERROR:' in log or 'PASS' not in log: raise RuntimeError('Native preview smoke failed')
