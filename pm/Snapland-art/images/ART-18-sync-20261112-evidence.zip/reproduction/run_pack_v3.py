import os
from pathlib import Path
import subprocess
import sys
root=Path(__file__).resolve().parents[2]
base=Path(__file__).resolve().parent
sys.path.insert(0,str(root))
from tools.animation_qa import export_animation_qa as qa
fixtures=['native_review.gd','native_layout_review.gd','native_walk_review.gd','native_island_hair_binding.gd','test_avatar_prop_foreground.gd','test_island_hair_binding.gd']
fixtures += [n+'.'+ext for n in ['native_wardrobe_motion_review','native_wardrobe_pose_review'] for ext in ['gd','tscn']]
qa.FIXTURE_FILES |= {'game/tests/'+n for n in fixtures}
stage=base/'pack-stage-v3'
stage.mkdir()
project=Path(qa.prepare_project(stage)['project'])
engine=r'C:\Tools\Godot\Godot_v4.7.2-stable_win64_console.exe'
pack=base/'wardrobe-v3.pck'
run_directory=base/'pack-run-v3'
run_directory.mkdir()
def run(name,args,env,timeout=240):
 with (base/(name+'.log')).open('w',encoding='utf-8') as log:
  result=subprocess.run([engine,*args],env=dict(os.environ,**env),stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
 text=(base/(name+'.log')).read_text(encoding='utf-8')
 if result.returncode or 'ERROR:' in text: raise RuntimeError(name+' failed: '+text[-2500:])
 print(name,'PASS',flush=True)
profile={'SNAPLAND_SAVE_PATH':str(base/'pack-build-profile.json')}
for label,args in [('import',['--headless','--editor','--import','--quit']),('export',['--headless','--editor','--export-pack',qa.PRESET_NAME,str(pack),'--quit'])]:
 run('pack-v3-'+label,['--path',str(project),'--rendering-method','gl_compatibility',*args],profile)
run('pack-v3-props',['--main-pack',str(pack),'--path',str(run_directory),'--headless','--script','res://game/tests/test_avatar_prop_foreground.gd'],{'SNAPLAND_SAVE_PATH':str(base/'pack-props/profile.json')})
run('motion-pack-v3',['--main-pack',str(pack),'--path',str(run_directory),'--rendering-method','gl_compatibility','--audio-driver','Dummy','--write-movie',str(base/'motion-pack-v3.avi'),'--fixed-fps','30','res://game/tests/native_wardrobe_motion_review.tscn'],{'SNAPLAND_SAVE_PATH':str(base/'pack-motion-profile.json'),'SNAPLAND_WARDROBE_MOTION_DIR':str(base/'motion-pack-v3')})
run('pack-v3-hair-pixels',['--main-pack',str(pack),'--path',str(run_directory),'--rendering-method','gl_compatibility','--audio-driver','Dummy','--script','res://game/tests/test_island_hair_binding.gd'],{'SNAPLAND_SAVE_PATH':str(base/'pack-hair-profile.json'),'SNAPLAND_ISLAND_HAIR_DIR':str(base/'pack-v3-hair-pixels'),'SNAPLAND_ISLAND_HAIR_REQUIRE_PACK':'1'},300)
