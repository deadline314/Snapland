from pathlib import Path
from collections import Counter
import json
import sys
qa=Path(__file__).resolve().parent
before,after=[json.loads((Path(path)/"captures/replay.json").read_text("utf8")) for path in sys.argv[1:]]
assert len(before)==len(after)==72
totals=0
changes=[]
expected=["front","front_left","left","back_left","back"]
for prior,next in zip(before,after,strict=True):
    assert all(prior[key]==next[key] for key in ("route","scale","approach"))
    assert prior["physics"]==next["physics"],(next["route"],next["scale"],next["approach"])
    totals+=len(prior["physics"])
    if prior["sources"]==next["sources"]: continue
    headings=list(dict.fromkeys(state.split("/")[1] for state in next["sources"] if state.startswith("pivot_depth")))
    assert next["route"] in ("front-back","back-front")
    assert headings==(expected if next["route"]=="front-back" else expected[::-1]),next
    changes.append({key:next[key] for key in ("route","scale","approach","sources")})
assert totals==6480 and changes and {row["route"] for row in changes}=={"front-back","back-front"}
result={"identical_ticks":totals,"real_key_cases":len(before),"changed_routes":changes}
(qa/"depth-physics-comparison.json").write_text(json.dumps(result,indent=2)+"\n","utf8")
print(totals,Counter((case["route"],case["scale"]) for case in changes))
measurements=json.loads((qa/"approved-phase-pairs.json").read_text("utf8"))["samples"]
for angle,pairs in (("front",{(5,5),(5,6),(6,6)}),("back",{(5,5),(6,6)})):
    approved=[row for row in measurements[angle] if (row["entry"],row["exit"]) in pairs]
    assert len(approved)==len(pairs) and all(row["allowed"] for row in approved)
    print(angle,[(r["entry"],r["exit"],r["direct"],r["generated"]) for r in approved])
