extends SceneTree

const World = preload("res://game/world/park_world.gd")
const ROUTES := [
	["front-back","move_down","move_up"],
	["back-front","move_up","move_down"],
	["left-right","move_left","move_right"],
]

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var world := World.new()
	root.add_child(world)
	var results: Array = []
	for scale: float in [1.0,0.25]:
		Engine.time_scale = scale
		var repeats := roundi(1.0/scale)
		for route: Array in ROUTES:
			for approach: int in [16,18,20,22,24,26,27,28,30,32,34,36]:
				var point := Vector3(-2.5,0,-14.5)
				point.y = world.ground_surface_y(point)
				world.player.global_position = point
				for tick in range(6*repeats): await physics_frame
				Input.action_press(route[1])
				for tick in range(approach*repeats): await physics_frame
				Input.action_release(route[1])
				Input.action_press(route[2])
				var samples: Array = []
				var sources: Array[String] = []
				var prior := ""
				for tick in range(36*repeats):
					await physics_frame
					var p := world.player.global_position
					var v := world.player.velocity
					samples.append([p.x,p.y,p.z,v.x,v.z,world.walk_distance_phase,world.facing,world.player.is_on_floor(),world.avatar_is_walking])
					var source := "%s/%s/%d" % [world.last_avatar_source_action,world.last_avatar_direction,world.last_avatar_frame]
					if source != prior:
						sources.append(source)
						prior = source
				Input.action_release(route[2])
				for tick in range(18*repeats): await physics_frame
				results.append({"route":route[0],"scale":scale,"approach":approach,"physics":samples,"sources":sources})
	var out := FileAccess.open(OS.get_environment("COTTON_CAPTURE_DIR").path_join("replay.json"),FileAccess.WRITE)
	out.store_string(JSON.stringify(results))
	out.close()
	world.queue_free()
	await process_frame
	print("PASS: measured 72 real depth/lateral reversals")
	quit()
