extends "res://game/tests/native_island_animation_acceptance.gd"

const VIEWS := ["front", "front_left", "left", "back_left", "back"]

func _hero_actions() -> void:
	var original: Dictionary = _world.avatar_appearance.duplicate()
	for style in ["windswept","bob","curly"]:
		var look := original.merged({"hair":style},true)
		var equipment := {"outfit":"outfit-tide" if style=="windswept" else "outfit-rainvest",
			"hat":"hat-none" if style=="windswept" else "hat-straw"}
		_world.set_avatar_look(look,equipment)
		for target in ["back","front"]:
			var sample := await _verified_turn(target,style)
			await _record_action(style+"-toward-"+target,"pivot_depth",target,"authored",_actor_anchor(),bool(sample.complete),sample)
			if not bool(sample.complete): return

func _verified_turn(target: String, style: String) -> Dictionary:
	var point := Vector3(-2.5,0,-14.5)
	point.y = _world.ground_surface_y(point)
	_world.player.global_position=point
	await _physics_frames(8)
	var key := KEY_S if target=="back" else KEY_W
	var reverse := KEY_W if target=="back" else KEY_S
	_press(key,true)
	var ready := false
	for index in range(240):
		await _physics_frames(1)
		if _actual_entry_support(target):
			ready = true
			break
	_press(key,false)
	if not ready: return {"complete":false,"reason":"no safe stride candidate before deadline"}
	var start: Vector3 = _world.player.global_position
	_press(reverse,true)
	var phases: Array[String] = []
	var textures_match := true
	var grounded := true
	var time_start := _simulated_seconds
	var final: Vector3 = start
	while _simulated_seconds-time_start<1.0 and _within_budget():
		await RenderingServer.frame_post_draw
		final = _world.player.global_position
		if _world.last_avatar_source_action != "pivot_depth":
			if not phases.is_empty(): break
			continue
		var view := String(_world.last_avatar_direction)
		var expected: Texture2D = _world.avatar_renderer.texture(_world.avatar_appearance,_world.avatar_equipped,view,0,"pivot_depth")
		textures_match = textures_match and _world.avatar.texture==expected
		grounded = grounded and _world.player.is_on_floor()
		if phases.is_empty() or phases.back()!=view:
			phases.append(view)
			_store_capture("%s-%s-%s" % [style,target,view],get_viewport().get_texture().get_image())
	_press(reverse,false)
	var entered: Array = VIEWS.duplicate()
	if target=="front": entered.reverse()
	var kept_heading: bool = _world.facing==target and _world.last_avatar_source_action=="walk"
	var offset := Vector2(final.x-start.x,final.z-start.z)
	var complete: bool = phases==entered and textures_match and grounded and kept_heading and absf(offset.x)<0.001
	await _wait_hero_settle()
	return {"complete":complete,"headings":phases,"textures_match":textures_match,"grounded":grounded,
		"off_axis_metres":absf(offset.x),"reversal_metres":absf(offset.y),"continued_walk":kept_heading}

func _actual_entry_support(target: String) -> bool:
	var from := "front" if target=="back" else "back"
	if _world.facing!=from or _world.last_avatar_source_action!="walk": return false
	var speed: float = absf(_world.player.velocity.z)
	if speed<1.499: return false
	var dt: float = _world.get_physics_process_delta_time()
	var step: float = _world.AVATAR_RUN_SPEED*dt/_world.AVATAR_ACCELERATION_SECONDS
	var signed_approach := speed
	var distance := 0.0
	while signed_approach>0.34:
		signed_approach -= step
		distance += maxf(0.0,signed_approach)*dt
	if signed_approach<=0.0: return false
	var original_phase: float = _world.walk_distance_phase
	var stride: float = _world.walk_stride_for(from)
	var entry: float = _world.advance_walk_phase(original_phase,distance,stride)
	var acceleration: float = _world.AVATAR_RUN_SPEED/_world.AVATAR_ACCELERATION_SECONDS
	var braking := signed_approach/acceleration
	var continuation := maxf(0.0,0.15+dt-braking)
	var possible := 0.5*acceleration*(braking*braking+continuation*continuation)
	var exit: float = _world.advance_walk_phase(entry,possible,stride)
	var entry_frame: int = _world.walk_frame_for_phase(entry,8)
	var exit_frame: int = _world.walk_frame_for_phase(exit,8)
	if target=="back" and entry_frame==5:
		return exit_frame in [5,6]
	return entry_frame==6 and exit_frame==6
