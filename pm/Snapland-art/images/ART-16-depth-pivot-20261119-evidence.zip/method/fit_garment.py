"""Fit directional rainvest layers and foreground ownership to the new turnaround cels."""
from pathlib import Path
import hashlib
import json
import numpy as np
from scipy.ndimage import binary_dilation
from PIL import Image,ImageDraw
import io

HERE=Path(__file__).resolve().parent
root=Path("assets/characters")
reg=HERE/"native/register-1119-121459-5d4cc4/captures"
owner=HERE/"native/compile-hair-1119-121459-64df55/captures/hair-candidates.json"
registered=json.loads((reg/"registration.json").read_text("utf8"))
candidates=json.loads(owner.read_text("utf8"))["owners"]
assert set(candidates)=={value["source"] for value in registered.values()}
views=("front","front_left","left","back_left","back")
geometry={
    "front":(0,2,[(104,212,177,255)],[(81,215,196,252)],[]),
    "front_left":(3,-1,[(85,205,142,251)],[(103,210,165,251)],[(158,195,209,256)]),
    "left":(5,-1,[(80,207,116,252)],[(94,205,138,253)],[(145,193,208,250)]),
    "back_left":(2,1,[(76,208,103,243)],[(84,221,122,254)],[(110,190,194,266)]),
    "back":(1,2,[],[(68,222,108,266),(177,222,219,266)],[(106,193,177,254)]),
}
path=root/"rainvest-v1/manifest.json"
text=path.read_text("utf8")
existing=json.loads(text)["frames"]
assert len(existing)==211
props={}
clothes=[]
report={}
board=Image.new("RGB",(1400,387),"#d9d2c0")
draw=ImageDraw.Draw(board)


def spans(mask):
    encoded=[]
    for y,row in enumerate(mask):
        run=np.diff(np.pad(row.astype(np.int8),(1,1)))
        encoded.extend([y,int(a),int(b)] for a,b in zip(np.flatnonzero(run==1),np.flatnonzero(run==-1),strict=True))
    return encoded


def with_color(boxes, eligible):
    mask=np.zeros(eligible.shape,bool)
    for x0,y0,x1,y1 in boxes:
        mask[y0:y1,x0:x1]=eligible[y0:y1,x0:x1]
    return mask


for index,view in enumerate(views):
    sx,sy,camera,hand,pack=geometry[view]
    raw=Image.open(reg/f"pivot-{view}.png").convert("RGBA")
    a=np.array(raw)
    r,g,b,alpha=np.moveaxis(a.astype(np.int16),-1,0)
    skin=(r>105)&(r>g*1.16)&(g>b*1.14)&(alpha>=128)
    brown=(r>25)&(r>g*1.14)&(r>b*1.12)&(alpha>=128)
    alpha_visible=alpha>=64
    foreground=with_color(camera,alpha_visible)|with_color(hand,skin)|with_color(pack,brown)
    foreground=binary_dilation(foreground,iterations=1)&alpha_visible
    key=registered[view]["source"]
    prop_ranges=spans(foreground)
    assert len(prop_ranges)>=40
    props[key]={"spans":prop_ranges,"poses":[f"pivot_depth/{view}/0"],
        "review":"Protects embedded camera, hands and directional backpack from overlapping cloth and hair."}
    row=candidates[key]
    ownership=np.zeros(foreground.shape,bool)
    for y,l,h in row["hair_owner_spans"]: ownership[y,l:h]=True
    row["hair_owner_spans"]=spans(ownership & ~foreground)
    row["review"]="Authored depth pivot: exact exposed source hair, with camera and hands separately protected."
    assert len(row["hair_owner_spans"])>=120 and np.count_nonzero(ownership & ~foreground)>8000
    idle,=[row for row in existing if row["action"]=="idle" and row["direction"]==view and row["frame"]==0]
    assert idle["source_pixel_sha256"]==registered[view]["idle"]
    prior=Path(idle["path"].removeprefix("res://"))
    assert hashlib.sha256(prior.read_bytes()).hexdigest()==idle["png_sha256"]
    out=Image.new("RGBA",raw.size)
    out.paste(Image.open(prior).convert("RGBA"),(sx,sy))
    layer=np.array(out)
    original_foreground=foreground&(layer[:,:,3]>0)
    safe_alpha=binary_dilation(alpha_visible,iterations=2)
    column,row_y=np.meshgrid(np.arange(280),np.arange(360))
    safe_alpha[row_y>=247]=True
    # Preserve a continuous lower coat hem while keeping sleeves on the authored shoulders.
    layer[(~safe_alpha)|foreground]=0
    assert np.count_nonzero(layer[:,:,3])>3500 and not np.any(layer[foreground,3])
    filepath=prior.with_name(f"pivot-depth-{view}.pngdata")
    buf=io.BytesIO()
    layer_image=Image.fromarray(layer)
    layer_image.save(buf,"PNG",optimize=True)
    filepath.write_bytes(buf.getvalue())
    clothes.append({"source_kind":"authored","direction":view,"action":"pivot_depth","frame":0,
        "source_pixel_sha256":key,"path":"res://"+filepath.as_posix(),
        "png_sha256":hashlib.sha256(filepath.read_bytes()).hexdigest()})
    posed=Image.alpha_composite(raw,layer_image)
    board.paste(posed,(280*index,20),posed)
    draw.text((280*index+8,4),view,fill="#13283c")
    report[view]={"source":key,"foreground_pixels":int(foreground.sum()),
          "foreground_removed_from_layer":int(original_foreground.sum()),"shift":[sx,sy],
          "fabric_pixels":int(np.count_nonzero(layer[:,:,3])),"hair_spans":len(row["hair_owner_spans"])}
board.save(HERE/"depth-rainvest-first-fit.png")


def append_owner_rows(file,additions):
    original=file.read_text("utf8")
    current=json.loads(original)["owners"]
    assert not current.keys() & additions.keys()
    marker='  "owners": {\n'
    assert original.count(marker)==1
    rows="\n".join(f'    "{key}": '+json.dumps(value,separators=(",",":"))+"," for key,value in sorted(additions.items()))
    new=original.replace(marker,marker+rows+"\n")
    assert json.loads(new)["owners"]==current|additions
    file.write_text(new,"utf8",newline="")
    return hashlib.sha256(original.encode("utf8")).hexdigest(),hashlib.sha256(new.encode("utf8")).hexdigest()


old,new=append_owner_rows(root/"avatar-head-material-owners-v1.json",candidates)
deps=root/"island-hair-alternate-owners-v1.json"
dependency=deps.read_text("utf8")
assert dependency.count(old)==1
deps.write_text(dependency.replace(old,new),"utf8",newline="")
append_owner_rows(root/"avatar-prop-foreground-v1.json",props)
tail='\n  ],\n  "encoding"'
assert text.count(tail)==1
rows=",\n".join("    "+json.dumps(row,indent=2).replace("\n","\n    ") for row in clothes)
combined=text.replace(tail,",\n"+rows+tail)
assert json.loads(combined)["frames"]==existing+clothes
path.write_text(combined,"utf8",newline="")
(HERE/"depth-registrations.json").write_text(json.dumps(report,indent=2)+"\n","utf8")
print(report)
