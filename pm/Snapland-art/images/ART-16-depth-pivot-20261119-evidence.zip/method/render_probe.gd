extends SceneTree

const Avatar = preload("res://game/world/avatar_renderer.gd")
const VIEWS := ["front", "front_left", "left", "back_left", "back"]

func _initialize() -> void:
	var folder := OS.get_environment("COTTON_CAPTURE_DIR")
	var avatar := Avatar.new()
	var result := {}
	for view: String in VIEWS:
		var source := avatar.original_garment_pose("pivot_depth",view,0)
		var geometry := avatar._authored_source_hair_metrics(source,view,"pivot_depth",0)
		var props := avatar.prop_foreground.indices(source)
		result[view] = {"hair_owner":geometry.hair_owner_valid,"geometry":geometry.replacement_geometry_valid,
			"face_color_pixels":geometry.face_indices.size(),"skull_pixels":geometry.skull_underlay_indices.size(),
			"props":props.size()}
		for style: String in ["windswept","bob","curly"]:
			var look := Avatar.DEFAULT_APPEARANCE.merged({"hair":style},true)
			var outfit := {"outfit":"outfit-tide" if style=="windswept" else "outfit-rainvest",
				"hat":"hat-none" if style=="windswept" else "hat-straw"}
			var posed := avatar.texture(look,outfit,view,0,"pivot_depth").get_image()
			if posed.save_png(folder.path_join("%s-%s.png" % [style,view])) != OK:
				quit(1)
				return
	var file := FileAccess.open(folder.path_join("geometry.json"),FileAccess.WRITE)
	file.store_string(JSON.stringify(result,"  "))
	file.close()
	print("PASS: five depth-turn poses composed with three wardrobe looks")
	quit()
