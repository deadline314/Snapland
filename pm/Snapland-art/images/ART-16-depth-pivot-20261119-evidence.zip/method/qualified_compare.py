from pathlib import Path
from PIL import Image, ImageDraw
import hashlib
import json
import numpy as np

HERE=Path(__file__).resolve().parent
previous=Path("E:/Snapland-QA/art16-traveller-pivot-study-20261119")
raw=previous/"replay/turn-baseline-1119-105122-7e7f32/captures"
original=Path("C:/Users/stanl/.codex/generated_images/01a1e5dd-6423-7963-9dc5-b040851d2b6b/exec-6f477656-2414-45f1-a98f-4942319807be.png")
atlas=Image.open(original).convert("RGBA")
alpha=np.array(atlas)[:,:,3]
columns=np.flatnonzero((alpha>=128).sum(axis=0)>3)
groups=np.split(columns,np.where(np.diff(columns)>24)[0]+1)
assert len(groups)==5
regions=[]
for group in groups:
    x0,x1=int(group.min()),int(group.max())+1
    yy,xx=np.where(alpha[:,x0:x1]>=128)
    regions.append((x0-3,int(yy.min())-3,x1+3,int(yy.max())+4))
print("regions",atlas.size,regions,flush=True)
start=np.array(Image.open(raw/"front-back-slow-05.png").convert("RGBA"))
finish=np.array(Image.open(raw/"front-back-slow-42.png").convert("RGBA"))

def silhouette(a):
    return a[70:346:2,::2,3]>=128

def signatures(a):
    cut=a[70:346:2,::2,:3].astype(np.int16)
    return (silhouette(a),cut)

def diff(a,b):
    ma,pa=a
    mb,pb=b
    union=ma|mb
    changed=(ma^mb)|(ma&mb&(np.abs(pa-pb).max(axis=2)>35))
    return float(changed.sum()/union.sum()),float(changed[-35:].sum()/union[-35:].sum())

def feet(a):
    pixels=np.flatnonzero((a[343:346,:,3]>=128).sum(axis=0)>=2)
    if len(pixels)<8: return ()
    return tuple(float(np.mean(p)) for p in np.split(pixels,np.where(np.diff(pixels)>1)[0]+1) if len(p)>5)

def shape(i,size,shift):
    source=atlas.crop(regions[i])
    scale=size/(regions[0][3]-regions[0][1]-6)
    normalized=source.resize(tuple(round(d*scale) for d in source.size),Image.Resampling.NEAREST)
    pixels=np.array(normalized)
    ys,xs=np.where(pixels[:,:,3]>=128)
    center=(xs.min()+xs.max())//2
    result=Image.new("RGBA",(280,360))
    result.paste(normalized,(140-center+shift,345-int(ys.max())))
    return np.array(result)

base=diff(signatures(start),signatures(finish))
choices=[]
for target_height in range(250,287,2):
    stages=[[(0,start)],*[
        [(shift,shape(i,target_height,shift)) for shift in range(-16,17,2)] for i in range(5)
    ],[(0,finish)]]
    first=[((0.0,0.0,0.0),[stages[0][0]],[])]
    for stage in stages[1:]:
        nxt=[]
        for shift,pose in stage:
            if not feet(pose): continue
            sz=signatures(pose)
            ranked=[]
            for old, chain, metrics in first:
                prev=chain[-1][1]
                whole,lower=diff(signatures(prev),sz)
                distance=min(abs(f-g) for f in feet(prev) for g in feet(pose))
                peak=(max(whole,old[0]),max(lower,old[1]),max(distance,old[2]))
                rank=6*max(0.0,peak[0]-base[0])+6*max(0.0,peak[1]-base[1])+peak[0]+.3*peak[1]+.002*peak[2]
                ranked.append((rank,peak,chain+[(shift,pose)],metrics+[(whole,lower,distance)]))
            for _,peak,chain,metrics in sorted(ranked,key=lambda r:r[0])[:3]:
                nxt.append((peak,chain,metrics))
        first=nxt
    for peak,chain,metrics in first:
        choices.append((6*max(0,peak[0]-base[0])+6*max(0,peak[1]-base[1])+peak[0]+.3*peak[1]+.002*peak[2],target_height,peak,chain,metrics))
_,height,maxima,chain,metrics=min(choices,key=lambda r:r[0])
facts={"original_sha256":hashlib.sha256(original.read_bytes()).hexdigest(),"asset_size":atlas.size,"regions":regions,
    "comparison_stride_pixels":2,"baseline":base,"peak":maxima,"height":height,"shifts":[x for x,a in chain],"edges":metrics,
    "plant_centers":[feet(a) for x,a in chain]}
(HERE/"generated-compare.json").write_text(json.dumps(facts,indent=2)+"\n","utf8")
sheet=Image.new("RGB",(1540,372),"#dbd3c4")
draw=ImageDraw.Draw(sheet)
for i,(shift,pose) in enumerate(chain):
    sample=Image.fromarray(pose)
    sample.save(HERE/f"normalized-{i}.png")
    cropped=sample.crop((33,32,247,354))
    sheet.paste(cropped,(220*i+4,25),cropped)
    draw.text((220*i+4,7),f"phase {i} | x {shift:+}",fill="#162939")
sheet.save(HERE/"generated-compare.png")
print(json.dumps(facts,indent=2))
