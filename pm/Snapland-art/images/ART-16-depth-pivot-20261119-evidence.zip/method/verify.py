"""Capture and package actual depth turns using isolated Godot state."""
from pathlib import Path
import importlib.util
import shutil
import subprocess
import sys

HERE=Path(__file__).resolve().parent
ROOT=Path("C:/Users/stanl/Github/Snapland")
HELPER=ROOT/".review/cotton-wind-20261118/final-fix/native_run.py"
spec=importlib.util.spec_from_file_location("depth_native",HELPER)
runner=importlib.util.module_from_spec(spec)
source=HELPER.read_text("utf8")
source=source.replace('Path(keys[key]).drive.upper() == "D:"','Path(keys[key]).drive == base.drive')
source=source.replace('donor.drive.upper() == "D:" and donor.parent in {QA, QA.parent / "task4"}','donor.parent == QA')
strict=next(line for line in source.splitlines() if "Asset donor differs in asset or configuration bytes" in line)
source=source.replace(strict,'''
    names={name for name in old if name.startswith("assets/") or name in {"project.godot","export_presets.cfg"}}
    assert names=={name for name in manifest if name.startswith("assets/") or name in {"project.godot","export_presets.cfg"}}
    for name in names:
        if manifest[name]==old[name]: continue
        a,b=donor/"project"/name,stage/name
        assert name.endswith(".json") and sha(a)==old[name] and sha(b)==manifest[name]
        assert a.read_text("utf8")==b.read_text("utf8"),name
''')
exec(compile(source,str(HELPER),"exec"),runner.__dict__)
runner.QA=HERE/"native"
validate_run=runner.run_validated_godot


def validate_command(staged, command, *args, **kwargs):
    if "--" in command and command[-2]=="--log-file":
        insert=command.index("--")
        extra=command[-2:]
        del command[-2:]
        command[insert:insert]=extra
    return validate_run(staged,command,*args,**kwargs)


runner.run_validated_godot=validate_command
FIXTURE="game/tests/native_avatar_depth_pivot_study"
fixtures={FIXTURE+ext:HERE/("native_capture"+ext) for ext in (".gd",".tscn")}
fixtures["game/tests/native_island_animation_acceptance.gd"]=ROOT/"game/tests/native_island_animation_acceptance.gd"
runner.FIXTURES=list(fixtures)


def stage(label,donor=None):
    folder=runner.make_base("depth-"+label)
    project=folder/"project"
    project.mkdir()
    files=subprocess.check_output(["git","ls-files","-z"],cwd=ROOT,encoding="utf8").split("\0")
    graph=runner.prepare_runtime_stage(ROOT,project,files)
    for name,source in fixtures.items():
        target=project/name
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(source,target)
        graph[name]=runner.sha(target)
    runner.dump(folder/"source-graph.json",{"base":subprocess.check_output(["git","rev-parse","HEAD"],cwd=ROOT,text=True).strip(),
        "source_raw_sha256":graph,"fixtures":runner.FIXTURES,"driver":runner.describe(Path(__file__))})
    if donor is not None:
        runner.copy_imports(donor,project,graph)
    return folder,project,graph


def record(mode,donor,binary=None,pinned=None):
    folder,path,graph=stage(mode,donor)
    options={"normal":[],"quarter":["--quarter","--rebuild"],"reduced":["--reduced-motion","--rebuild"],"embedded":[]}[mode]
    movie=folder/"capture.avi"
    out=folder/"captures"
    app=[runner.ENGINE,"--path",path,"res://"+FIXTURE+".tscn"]
    if binary:
        runner.qa_override(path,pinned)
        build=runner.read(binary.parent.parent/"build.json")
        assert runner.sha(binary)==build["binary"]["sha256"]
        assert all(runner.sha(path/name)==sha for name,sha in build["runtime_sha256"].items())
        app=[binary]
    command=[*app,"--rendering-method","gl_compatibility","--audio-driver","Dummy","--fixed-fps","60",
        "--write-movie",movie,"--","--actor=traveller","--actions-only","--animation-output="+out.as_posix(),*options]
    runner.launch(folder,path,graph,mode,command,runner.environment(folder),binary.parent if binary else None)
    report=runner.read(out/"traveller-report.json")
    assert report["technical_status"]=="PASS" and not report["failures"] and movie.stat().st_size>0
    assert report["scene_rebuild"]==(mode in ("quarter","reduced")) and report["reduced_motion"]==(mode=="reduced")
    if mode!="reduced":
        rows=[row for row in report["actions"] if row["action"]=="pivot_depth"]
        assert len(rows)==6 and all(row["predicate"] and len(row["detail"]["headings"])==5 for row in rows)
        assert {row["direction"] for row in rows}=={"front","back"}
    print(folder.as_posix(),flush=True)
    return folder


def package(donor):
    folder,path,graph=stage("export",donor)
    pinned=runner.templates(folder)
    runner.SCENE=FIXTURE+".tscn"
    runner.qa_override(path,pinned)
    release=folder/"release"
    release.mkdir()
    exe=release/"AvatarDepthPivotQA.exe"
    runner.launch(folder,path,graph,"export",
        [runner.ENGINE,"--headless","--path",path,"--editor","--export-release","Windows Desktop",exe,"--quit"],
        runner.environment(folder))
    assert exe.stat().st_size>pinned["release"]["bytes"] and not list(release.glob("*.pck"))
    runner.dump(folder/"build.json",{"binary":runner.describe(exe),"templates":pinned,
        "source":runner.describe(folder/"source-graph.json"),"runtime_sha256":runner.read(folder/"runtime-graph.json"),
        "export":runner.describe(folder/"receipt.json"),"normal_main":runner.describe(ROOT/"project.godot"),
        "normal_export":runner.describe(ROOT/"export_presets.cfg")})
    launched=record("embedded",donor,exe,pinned)
    runner.dump(folder/"embedded-acceptance.json",{"build":runner.describe(folder/"build.json"),"launch":runner.describe(launched/"receipt.json")})


if __name__=="__main__":
    mode=sys.argv[1]
    donor=Path(sys.argv[2])
    if mode=="package":
        package(donor)
    else:
        record(mode,donor)
