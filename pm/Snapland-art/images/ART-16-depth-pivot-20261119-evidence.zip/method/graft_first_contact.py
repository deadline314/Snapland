"""Fit only the supporting right leg to the initial planted reference."""
from pathlib import Path
from PIL import Image,ImageDraw
import json
import numpy as np

HERE=Path(__file__).resolve().parent
src=(HERE/"fit_entry.py").read_text("utf8").split("valid=[]")[0]
exec(compile(src,str(HERE/"fit_entry.py"),"exec"))
yy,xx=np.mgrid[:360,:280]
qualifying=[]
for base_y in range(259,295,2):
 for split in range(127,149,2):
  for x_shift in range(-5,6):
   donor=np.roll(entry,x_shift,axis=1)
   mask=(yy>=base_y)&(xx>=split)
   pose=np.where(mask[:,:,None],donor,raw)
   # Graft edges follow the shorts' lower seam and transparent inner leg gap.
   def mismatch(a,b):
    aa,bb=a[:,3]>=128,b[:,3]>=128
    d=np.abs(a[:,:3].astype(np.int16)-b[:,:3].astype(np.int16)).max(axis=1)
    return int((aa^bb).sum()),int((aa&bb&(d>80)).sum())
   horizontal=mismatch(pose[base_y-1,split:],pose[base_y,split:])
   vertical=mismatch(pose[base_y:346,split-1],pose[base_y:346,split])
   if horizontal[0]>13 or vertical[0]>15 or sum((horizontal[1],vertical[1]))>13: continue
   contacts=feet(pose)
   if len(contacts)<2 or not (min(contacts)<130 and max(contacts)>140): continue
   a,b=diff(entry,pose),diff(pose,dest)
   peak=np.max([source_peak,a,b],axis=0)
   if any(peak>base): continue
   gap=max(plant_shift(entry,pose),plant_shift(pose,dest))
   if gap>12:continue
   cost=peak[0]+.3*peak[1]+.002*gap+.002*sum(horizontal+vertical)
   qualifying.append((cost,base_y,split,x_shift,horizontal,vertical,a,b,contacts,peak,pose))
print("qualified",len(qualifying),flush=True)
qualifying.sort(key=lambda r:r[0])
assert qualifying
sheet=Image.new("RGB",(1100,379),"#dad3c4")
draw=ImageDraw.Draw(sheet)
facts=[]
for i,row in enumerate(qualifying[:5]):
 _,y,x,shift,hor,vert,a,b,contacts,peak,pose=row
 original=Image.fromarray(pose)
 original.save(HERE/f"planted-entry-{i}.png")
 image=original.crop((36,35,244,358))
 sheet.paste(image,(i*220+4,26),image)
 draw.text((i*220+4,7),f"seam ({x},{y}) shift {shift:+}",fill="#16232c")
 facts.append({"index":i,"x":x,"y":y,"shift":shift,"horizontal":hor,"vertical":vert,"first_edge":a,"second_edge":b,"feet":contacts,"peak":peak.tolist()})
sheet.save(HERE/"planted-entry-options.png")
(HERE/"planted-entry-options.json").write_text(json.dumps(facts,indent=2)+"\n","utf8")
print(json.dumps(facts[0]))
