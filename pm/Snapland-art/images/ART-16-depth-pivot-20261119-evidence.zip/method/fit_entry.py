from pathlib import Path
from PIL import Image,ImageDraw
import json
import numpy as np

HERE=Path(__file__).resolve().parent
root=Path("assets/characters")
source=(HERE/"search_existing.py").read_text("utf8")
s=source.index("def feet(")
e=source.index("report={}",s)
exec(compile(source[s:e],str(HERE/"search_existing.py"),"exec"))
comparison=(Path("E:/Snapland-QA/art16-traveller-pivot-study-20261119")/"compare.py").read_text("utf8")
exec(compile(comparison[comparison.index("def diff("):comparison.index("board=Image.new")],"<compare>","exec"))
frames=[np.array(Image.open(HERE/f"normalized-{i}.png").convert("RGBA")) for i in range(7)]
front={
 "approach":frames[0],
 "settle":np.array(Image.open(root/"traveller-settle-compass-v1.png").convert("RGBA").crop((0,0,280,360))),
 "depart":np.array(Image.open(root/"traveller-departure-compass-v1.png").convert("RGBA").crop((0,0,280,360))),
 "idle":np.array(Image.open(root/"idle-stability-v1/front.png").convert("RGBA").crop((0,0,280,360)))
}
walk=Image.open(root/"walk-stability-v1/island-raw-front.png").convert("RGBA")
for i in range(8):front[f"walk-{i}"]=np.array(walk.crop((i*280,0,(i+1)*280,360)))
entry=frames[0]
raw=frames[1]
dest=frames[2]
base=diff(frames[0],frames[-1])
constant=[diff(a,b) for a,b in zip(frames[2:-1],frames[3:])]
source_peak=np.max(constant,axis=0)
print("base",base,"constant",source_peak.tolist(),"original first",diff(entry,raw),"original exit",diff(raw,dest),flush=True)
valid=[]
tested=0
for key,lower in front.items():
  for bottom_start in range(251,285,2):
    for top_end in range(bottom_start-5,bottom_start+6,2):
      for dx in range(-10,11,2):
        if top_end < 248: continue
        clip=Image.fromarray(lower[bottom_start:346])
        if clip.height != 346-top_end:
           clip=clip.resize((280,346-top_end),Image.Resampling.NEAREST)
        stripped=Image.new("RGBA",clip.size)
        stripped.paste(clip,(dx,0))
        pose=raw.copy()
        pose[top_end:346]=np.array(stripped)
        a,b=pose[top_end-1],pose[top_end]
        aa,bb=a[:,3]>=128,b[:,3]>=128
        gap=(aa^bb).sum()
        color=(aa&bb&(np.abs(a[:,:3].astype(np.int16)-b[:,:3].astype(np.int16)).max(axis=1)>75)).sum()
        if gap>15 or color>16 or not feet(pose): continue
        tested+=1
        p1,p2=diff(entry,pose),diff(pose,dest)
        peak=np.max([source_peak,p1,p2],axis=0)
        if any(peak>base): continue
        f1=plant_shift(entry,pose)
        f2=plant_shift(pose,dest)
        if max(f1,f2)>20: continue
        score=peak[0]+.25*peak[1]+.002*max(f1,f2)+.001*gap+.001*color
        valid.append((score,key,bottom_start,top_end,dx,int(gap),int(color),p1,p2,f1,f2,pose))
print("tested seams",tested,"qualified",len(valid),flush=True)
valid.sort(key=lambda row:row[0])
if not valid: raise SystemExit(1)
sheet=Image.new("RGB",(1320,362),"#ddd4c4")
draw=ImageDraw.Draw(sheet)
summaries=[]
for i,row in enumerate(valid[:6]):
    score,key,y0,y1,dx,gap,color,first,second,f1,f2,pose=row
    image=Image.fromarray(pose)
    image.save(HERE/f"entry-option-{i}.png")
    image=image.crop((34,36,246,355))
    sheet.paste(image,(i*220+4,28),image)
    draw.text((i*220+4,5),f"{key} {y0}/{y1} {dx:+d}",fill="#18323c")
    summaries.append({"index":i,"source_legs":key,"source_y":y0,"target_y":y1,"shift":dx,
        "seam_alpha_pixels":gap,"seam_color_pixels":color,"entry_edge":first,"second_edge":second,
        "plant_step_pixels":[f1,f2],"feet":feet(pose),"whole_sequence_max":np.max([source_peak,first,second],axis=0).tolist()})
sheet.save(HERE/"entry-options.png")
(HERE/"entry-options.json").write_text(json.dumps({"choices":summaries,"seam_candidates":tested,"passing":len(valid)},indent=2)+"\n","utf8")
print(json.dumps(summaries[:2],indent=2))
