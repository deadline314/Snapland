from pathlib import Path
from itertools import product
import json
import numpy as np
from PIL import Image,ImageDraw

HERE=Path(__file__).resolve().parent
root=Path("assets/characters")
prior=Path("E:/Snapland-QA/art16-traveller-pivot-study-20261119")
raw=prior/"replay/turn-baseline-1119-105122-7e7f32/captures"
source=(prior/"compare.py").read_text("utf8")
exec(compile(source[source.index("compass="):source.index("board=Image.new")],str(prior/"compare.py"),"exec"))
for direction,variants in poses.items():
    atlas=Image.open(root/f"walk-stability-v1/island-raw-{direction}.png").convert("RGBA")
    assert atlas.size==(2240,360)
    for index in range(8):
        variants[f"walk-{index}"]=np.array(atlas.crop((280*index,0,280*(index+1),360)))

def feet(a):
    contact=(((a[343:346,:,3]>=128).sum(axis=0))>=2).nonzero()[0]
    if len(contact)<9: return None
    parts=np.split(contact,np.where(np.diff(contact)>1)[0]+1)
    return tuple(float(np.mean(p)) for p in parts if len(p)>=6)

def plant_shift(a,b):
    return min(abs(x-y) for x in feet(a) for y in feet(b))

report={}
board=Image.new("RGB",(1100,672),"#ded6c4")
draw=ImageDraw.Draw(board)
for y,name in enumerate(("front-back","back-front")):
    walk,=[line for line in json.loads((raw/"registration.json").read_text("utf8")) if line["route"]==name and line["speed"]==0.25]
    rows=walk["samples"]
    target=name.split("-")[1]
    turn=next(index for index,row in enumerate(rows) if row[1].split("/")[0]==target)
    start=next(index for index in reversed(range(turn)) if index==0 or rows[index-1][1]!=rows[index][1])
    source,dest=[np.array(Image.open(raw/f"{name}-slow-{index:02d}.png").convert("RGBA")) for index in (start,turn)]
    print(name,start,turn,feet(source),feet(dest),flush=True)
    baseline=diff(source,dest)
    best=[]
    for path in cases[name]:
        candidates=[[(key,frame) for key,frame in poses[view].items() if feet(frame)] for view in path]
        stages=[[("approach",source)],*candidates,[("departure",dest)]]
        edges=[]
        for a,b in zip(stages,stages[1:]):
            grid={}
            for key,frame in a:
                for next_key,next_frame in b:
                    change=diff(frame,next_frame)
                    grid[key,next_key]=(*change,plant_shift(frame,next_frame))
            edges.append(grid)
        for views in product(*stages):
            labels,images=zip(*views,strict=True)
            changes=[grid[labels[i],labels[i+1]] for i,grid in enumerate(edges)]
            peak=np.max(changes,axis=0)
            best.append((bool(peak[0]<=baseline[0] and peak[1]<=baseline[1]),float(peak[0]+.25*peak[1]+.002*peak[2]),path,labels,peak,changes,images))
    best.sort(key=lambda row:(not row[0],row[1]))
    accepted,_,path,labels,peak,changes,images=best[0]
    report[name]={"entry_tick":start,"exit_tick":turn,"baseline":baseline,"direct_plant_gap":plant_shift(source,dest),
        "combinations":len(best),"both_improve":sum(row[0] for row in best),"best_existing_path":path,"labels":labels,"peak":peak.tolist(),"changes":changes}
    for x,(label,frame) in enumerate(zip(labels,images,strict=True)):
        tile=Image.fromarray(frame).crop((36,48,244,358))
        px=x*220+6
        py=y*336
        board.paste(tile,(px,py+24),tile)
        draw.text((px,py+5),f"{name} {label}",fill="#252f30")
board.save(HERE/"existing-pose-comparison.png")
(HERE/"existing-pose-comparison.json").write_text(json.dumps(report,indent=2)+"\n","utf8")
print(json.dumps(report,indent=2))
