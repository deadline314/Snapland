from pathlib import Path
from PIL import Image
import json
import numpy as np

HERE=Path(__file__).resolve().parent
root=Path("assets/characters")
src=(HERE/"fit_entry.py").read_text("utf8").split("valid=[]")[0]
exec(compile(src,str(HERE/"fit_entry.py"),"exec"))
phases=frames[1:6]
internal=np.max([diff(a,b) for a,b in zip(phases,phases[1:])],axis=0)
book={}
for side in ("front","back"):
    atlas=Image.open(root/f"walk-stability-v1/island-raw-{side}.png").convert("RGBA")
    book[side]=[np.array(atlas.crop((i*280,0,(i+1)*280,360))) for i in range(8)]
record={}
proof={}
for first,second,turnposes in (("front","back",phases),("back","front",phases[::-1])):
    route={}
    measurements=[]
    for index,a in enumerate(book[first]):
        for destination,b in enumerate(book[second]):
            direct=diff(a,b)
            first_edge=diff(a,turnposes[0])
            last_edge=diff(turnposes[-1],b)
            peak=np.max([first_edge,internal,last_edge],axis=0)
            if not feet(a) or not feet(b):continue
            gaps=[plant_shift(a,turnposes[0]),plant_shift(turnposes[-1],b)]
            improvement=bool(np.all(peak<np.array(direct)-0.003))
            stable=max(gaps)<=max(11,min(18,plant_shift(a,b)))
            measurements.append({"entry":index,"exit":destination,"direct":direct,"generated":peak.tolist(),
                                  "edge_contact_gaps":gaps,"allowed":improvement and stable})
            if improvement and stable:route.setdefault(index,[]).append(destination)
    record[first]=route
    proof[first]=measurements
(HERE/"approved-phase-pairs.json").write_text(json.dumps({"selected_pairs":record,"samples":proof},indent=2)+"\n","utf8")
print(json.dumps(record,indent=2))
