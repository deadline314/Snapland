extends SceneTree
const Library = preload("res://game/world/character_animation_library.gd")
func _initialize():
 var library = Library.new()
 library.manifest.actors.traveller.wave.front.erase("frames")
 library.manifest.actors.traveller.wave.front.frame_durations = [0.25]
 var available: bool = library.has_action("traveller","wave","front")
 print("PROBE completed, available=",available)
 quit(1 if available else 0)
