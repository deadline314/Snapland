extends Node
const Avatar = preload("res://game/world/avatar_renderer.gd")
func _ready():
 get_window().size=Vector2i(960,540)
 get_window().content_scale_size=Vector2i(960,540)
 var baseline=Avatar.new()
 baseline.animation_library.manifest.actors.traveller.erase("wave")
 var damaged=Avatar.new()
 damaged.animation_library.manifest.actors.traveller.wave.front.erase("frames")
 damaged.animation_library.manifest.actors.traveller.wave.front.frame_durations=[0.25]
 var canvas=ColorRect.new();canvas.color=Color("d5e2df");canvas.size=Vector2(960,540);add_child(canvas)
 var title=Label.new();title.text="ART-17 | Missing-cel timing recovers the complete source";title.position=Vector2(30,12);title.add_theme_color_override("font_color",Color("203436"));title.add_theme_font_size_override("font_size",22);add_child(title)
 for col in 3:
  var look=Avatar.DEFAULT_APPEARANCE.duplicate();look.hair=["windswept","bob","curly"][col]
  var original=baseline.texture(look,{"outfit":"outfit-tide"},"front",0,"wave")
  var recovered=damaged.texture(look,{"outfit":"outfit-tide"},"front",0,"wave")
  assert(original.get_image().get_data()==recovered.get_image().get_data())
  for i in 2:
   var portrait=Sprite2D.new();portrait.texture=[original,recovered][i];portrait.position=Vector2(85+col*310+i*145,205);portrait.scale=Vector2(0.46,0.46);portrait.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST;add_child(portrait)
  var label=Label.new();label.text=look.hair+"\noriginal     recovered\nRGBA identical";label.position=Vector2(40+col*310,295);label.add_theme_color_override("font_color",Color("203436"));label.add_theme_font_size_override("font_size",19);add_child(label)
 var note=Label.new();note.text="Technical render comparison only. No new animation or human playthrough.\nA missing frame table now reports one diagnostic and retains the complete portrait.";note.position=Vector2(30,425);note.add_theme_color_override("font_color",Color("203436"));add_child(note)
 await get_tree().process_frame
 await RenderingServer.frame_post_draw
 var output=OS.get_environment("SNAPLAND_SAVE_PATH").get_base_dir().path_join("comparison.png")
 assert(get_viewport().get_texture().get_image().save_png(output)==OK)
 print("PASS: native missing-cel complete-source comparison")
 get_tree().quit()
