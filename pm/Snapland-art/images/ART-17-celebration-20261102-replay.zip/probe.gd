extends SceneTree
const World = preload("res://game/world/park_world.gd")
func _initialize():call_deferred("run")
func run():
 var world=World.new();root.add_child(world)
 await physics_frame;await physics_frame
 world.set_process(false);world.set_physics_process(false)
 world.facing="back";world.play_action("celebrate")
 var pixels={};var frames=[]
 for i in 8:
  world.avatar_action_elapsed=(float(i)+0.2)/12.0
  world._refresh_avatar_texture(i)
  var hash=HashingContext.new();hash.start(HashingContext.HASH_SHA256);hash.update(world.avatar.texture.get_image().get_data())
  var signature=hash.finish().hex_encode();pixels[signature]=true
  frames.append({"index":world.last_avatar_frame,"sha256":signature,"facing":world.last_avatar_direction})
 print("CELEBRATION_PROBE: ",JSON.stringify({"unique_images":pixels.size(),"duration":world.avatar_action_remaining,"frames":frames,"scope":"Controlled renderer snapshots; no gameplay or timing acceptance"}))
 world.queue_free();await process_frame;quit()
