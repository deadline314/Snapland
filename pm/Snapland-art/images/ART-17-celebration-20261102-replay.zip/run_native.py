from pathlib import Path
from tools.godot_entrypoints import run_validated_godot
import os,json,time,sys
root=Path.cwd();mode=sys.argv[1];out=root/'work/celebration'/mode
out.mkdir(exist_ok=False)
env=dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'profile/progress.json'),SNAPLAND_ACTION_REVIEW_DIR=str(out))
args=['/workspace/work/engine/Godot_v4.7.2-stable_linux.x86_64','--path',str(root),'--rendering-method','gl_compatibility','--audio-driver','Dummy','--fixed-fps','30','--write-movie',str(out/'movie.avi'),'res://game/tests/native_avatar_action_events_review.tscn','--','--review-fixed-clock']
if mode.startswith('quarter'):args+=['--quarter']
start=time.monotonic()
r=run_validated_godot(root,args,env=env,timeout=600)
log=r.stdout+r.stderr;(out/'run.log').write_text(log)
print('exit',r.returncode,'errors',log.count('ERROR:'),'wall_seconds',round(time.monotonic()-start,2));print('\n'.join(x for x in log.splitlines() if 'PASS' in x or 'ERROR:' in x))
if r.returncode or 'ERROR:' in log or 'PASS_NATIVE_ACTION_EVENTS' not in log:print(log[-5000:]);sys.exit(1)
