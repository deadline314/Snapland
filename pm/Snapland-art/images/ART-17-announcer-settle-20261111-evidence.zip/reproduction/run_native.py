import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[2]
base = Path(__file__).resolve().parent
mode = sys.argv[1]
output = base / mode
env = dict(os.environ, SNAPLAND_SAVE_PATH=str(base / (mode + '-profile.json')))
args = [r'C:\Tools\Godot\Godot_v4.7.2-stable_win64_console.exe', '--path', str(root),
        '--rendering-method', 'gl_compatibility', '--audio-driver', 'Dummy',
        '--write-movie', str(base / (mode + '.avi')), '--fixed-fps', '30',
        'res://game/tests/native_announcer_patrol_review.tscn', '--', '--actor=announcer',
        '--actions-only', '--animation-output=' + str(output)]
if mode == 'quarter':
    args += ['--quarter', '--rebuild']
elif mode == 'reduced':
    args += ['--reduced-motion', '--rebuild']
with (base / (mode + '.log')).open('w', encoding='utf-8') as log:
    completed = subprocess.run(args, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=300)
print(mode, completed.returncode)
raise SystemExit(completed.returncode)

