from pathlib import Path
import os
import sys
here=Path(__file__).resolve().parent
role=os.environ.get("SNAPLAND_QA_NPC_ROLE","imp")
assert role in ("ticket","imp","announcer")
source=(here.parent/"art17-traveller-celebration-20261119/verify.py").read_text("utf8")
source=source.replace("art17-traveller-celebration-20261119",here.name)
source=source.replace("native_avatar_celebration_study","native_npc_wave_reply_study")
source=source.replace("AvatarCelebrationQA.exe","NpcWaveReplyQA.exe")
start=source.index('start=source.index(')
source=source[:start]+"""
source=source.replace('exec(compile(source,str(here/"final_checks.py"),"exec"))',
    'source=source.replace("--actor=traveller","--actor='+role+'").replace("traveller-report.json","'+role+'-report.json")\\n'+
    'exec(compile(source,str(here/"final_checks.py"),"exec"))')
start=source.index('    if mode!="reduced":')
end=source.index("''' + source[end:]",start)
source=source[:start]+'''    if mode!="reduced":
        reply,=[row for row in report["actions"] if row["label"]=="deliberate-reply"]
        assert reply["predicate"] and reply["detail"]["complete"] and reply["detail"]["held_clip"]
''' + source[end:]
exec(compile(source,str(here/"verify.py"),"exec"))
"""
exec(compile(source,str(here/"verify.py"),"exec"))
