extends "res://game/tests/native_island_animation_acceptance.gd"

var _near := false

func _focus_live_actor() -> void:
	super._focus_live_actor()
	if not _near: return
	var point_id := String(NPC_POINT[_actor])
	for point in _world.points:
		if String(point.id) != point_id: continue
		_world.player.global_position = point.position + Vector3(0.0,0.3,0.0)
		return

func _npc_actions() -> void:
	var progress := get_tree().root.get_node("Progress")
	var photos_before: int = progress.photos.size()
	var point_id := String(NPC_POINT[_actor])
	var started := _simulated_seconds
	_near = true
	while _simulated_seconds-started<12.0 and _within_budget():
		await _frames(1)
		if _current_action() in ["stand","idle"] and String(_world.nearest.get("id",""))==point_id:
			break
	var ready: bool = _current_action() in ["stand","idle"] and String(_world.nearest.get("id",""))==point_id
	if not ready:
		_fail("no natural stationary NPC window available near actual player")
		return
	await _frames(2)
	var root := _actor_anchor()
	var hover: bool = _main.context_action.tooltip_text.contains("F")
	var held_clip := false
	_tap_wave()
	await _frames(1)
	var accepted: bool = _world.last_avatar_action=="wave" and _current_action()=="greet"
	if accepted:
		await _frames(1)
		var elapsed: float = _npc_record(_actor).action_elapsed
		_tap_wave()
		held_clip = float(_npc_record(_actor).action_elapsed) >= elapsed and _current_action()=="greet"
	_near=false
	var shown := await _observe_npc_sequence("greet",accepted)
	var sole_reply := true
	for role in ["ticket","imp","announcer"]:
		if role!=_actor and String(_npc_record(role).get("action",""))=="greet":
			sole_reply=false
	shown["anchored"] = root==_actor_anchor()
	shown["hover"] = hover
	shown["hover_text"] = _main.context_action.tooltip_text
	shown["held_clip"] = held_clip
	shown["sole_reply"] = sole_reply
	shown["photos_unchanged"] = progress.photos.size()==photos_before
	shown["no_modal"] = _main.modal_kind==""
	var passed: bool = shown.complete and shown.anchored and hover and held_clip and sole_reply and shown.photos_unchanged and shown.no_modal
	await _record_action("deliberate-reply","greet","front","authored",root,passed,shown)
	await _wait_npc_settle()

func _tap_wave() -> void:
	_press(KEY_F,true)
	_press(KEY_F,false)
