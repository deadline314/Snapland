extends Node
class SentinelSession:
	extends "res://game/minigames/session.gd"
	var sentinel := 0
	var backdrop_calls := 0
	func _draw_backdrop() -> void:
		backdrop_calls+=1
		if sentinel==1:draw_rect(Rect2(Vector2.ZERO,DESIGN_SIZE),Color.MAGENTA)
		elif sentinel==0:super._draw_backdrop()
var folder := ""
func _ready() -> void:
	process_mode=Node.PROCESS_MODE_ALWAYS
	call_deferred("run")
func frames(count: int) -> void:
	for index in count:await get_tree().process_frame
func run() -> void:
	folder=OS.get_environment("SNAPLAND_SAVE_PATH").get_base_dir()
	if not folder.is_absolute_path() or DisplayServer.get_name()=="headless":get_tree().quit(2);return
	DirAccess.make_dir_recursive_absolute(folder)
	get_window().size=Vector2i(1280,720)
	var rows: Array=[]
	for number in range(1,13):
		var session:=SentinelSession.new();session.process_mode=Node.PROCESS_MODE_PAUSABLE;add_child(session)
		session.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		session.start("game-%03d"%number)
		await get_tree().create_timer(0.5).timeout
		if not is_instance_valid(session.presentation):push_error("Missing current presentation");get_tree().quit(1);return
		session.set_paused(true)
		# Diagnostic only: freeze models/render targets, keep gameplay pixels unobscured.
		session.minigame_hud.set_paused(false)
		get_tree().paused=true
		await frames(4)
		session.queue_redraw();await frames(3);await RenderingServer.frame_post_draw
		var normal:=get_viewport().get_texture().get_image()
		session.sentinel=1;session.queue_redraw();await frames(3);await RenderingServer.frame_post_draw
		var sentinel:=get_viewport().get_texture().get_image()
		session.sentinel=2;session.queue_redraw();await frames(3);await RenderingServer.frame_post_draw
		var absent:=get_viewport().get_texture().get_image()
		var same:=normal.get_data()==sentinel.get_data() and normal.get_data()==absent.get_data()
		var row:={"id":"game-%03d"%number,"mode":session.mode,"presentation":session.presentation.get_script().resource_path,"backdrop_calls":session.backdrop_calls,"full_viewport_pixels_identical":same}
		if session.backdrop_calls>0:
			# Negative control: without the replacement scene the same sentinel must be visible.
			session.presentation.hide()
			session.sentinel=1;session.queue_redraw();await frames(3);await RenderingServer.frame_post_draw
			var exposed_sentinel:=get_viewport().get_texture().get_image()
			session.sentinel=2;session.queue_redraw();await frames(3);await RenderingServer.frame_post_draw
			var exposed_absent:=get_viewport().get_texture().get_image()
			row["negative_control_detects_exposed_backdrop"]=exposed_sentinel.get_data()!=exposed_absent.get_data()
			exposed_sentinel.save_png(folder.path_join("game-%03d-negative-sentinel.png"%number))
			exposed_absent.save_png(folder.path_join("game-%03d-negative-absent.png"%number))
			if not row.negative_control_detects_exposed_backdrop:push_error("Blind sentinel comparison");get_tree().quit(1);return
		rows.append(row)
		normal.save_png(folder.path_join("game-%03d-normal.png"%number));sentinel.save_png(folder.path_join("game-%03d-sentinel.png"%number));absent.save_png(folder.path_join("game-%03d-absent.png"%number))
		get_tree().paused=false
		session.queue_free();await frames(5)
		if not same:FileAccess.open(folder.path_join("failed.json"),FileAccess.WRITE).store_string(JSON.stringify(rows,"  "));push_error("Legacy background is still visible: "+str(row));get_tree().quit(1);return
	FileAccess.open(folder.path_join("report.json"),FileAccess.WRITE).store_string(JSON.stringify(rows,"  "))
	print("PASS: twelve current presentations fully replace legacy backdrop pixels; sentinel swap changes no viewport pixel")
	get_tree().quit()
