extends "res://game/tests/native_walk_review.gd"
var folder := ""
var preview: TextureRect
var caption: Label
var native_records: Array = []
var first_pause_checked := false
var reentering := false

func _run() -> void:
	var profile:=OS.get_environment("SNAPLAND_SAVE_PATH")
	if not profile.is_absolute_path() or DisplayServer.get_name()=="headless":get_tree().quit(2);return
	folder=profile.get_base_dir();DirAccess.make_dir_recursive_absolute(folder.path_join("captures"))
	Engine.time_scale=0.25 if OS.get_cmdline_user_args().has("--quarter") else 1.0
	progress=get_tree().root.get_node("Progress");progress.reset_progress();progress.intro_seen=true
	main=_instantiate_main();get_tree().root.add_child(main);await _frames(8)
	main.world.camera.size=7.0
	var layer:=CanvasLayer.new();layer.layer=90;add_child(layer)
	var background:=ColorRect.new();background.position=Vector2(815,90);background.size=Vector2(450,600);background.color=Color("#123442");background.mouse_filter=Control.MOUSE_FILTER_IGNORE;layer.add_child(background)
	preview=TextureRect.new();preview.position=Vector2(840,155);preview.size=Vector2(392,504);preview.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST;preview.mouse_filter=Control.MOUSE_FILTER_IGNORE;layer.add_child(preview)
	caption=Label.new();caption.position=Vector2(832,108);caption.add_theme_color_override("font_color",Color.WHITE);caption.add_theme_font_size_override("font_size",17);layer.add_child(caption)
	for style in ["windswept","bob","curly"]:
		for hat in ["hat-none","hat-straw","hat-sailor","hat-flower"]:
			if not await _case(style,hat,false,"live"):return
			if native_records.size()==1:
				main.world.hide();main.hud.hide()
	main.world.apply_settings({"reduced_motion":true})
	if not await _case("curly","hat-sailor",true,"reduced"):return
	main.world.apply_settings({"reduced_motion":false})
	for code in [KEY_W,KEY_A,KEY_S,KEY_D]:_held_key(code,false)
	reentering=true;preview.texture=null
	main.queue_free();await _frames(3)
	main=_instantiate_main();get_tree().root.add_child(main);await _frames(8);main.world.camera.size=7.0;main.world.hide();main.hud.hide();reentering=false
	if not await _case("curly","hat-sailor",false,"reentry"):return
	FileAccess.open(folder.path_join("audit.json"),FileAccess.WRITE).store_string(JSON.stringify({"time_scale":Engine.time_scale,"cases":native_records,"actual_key_input":true,"pause_resume":first_pause_checked,"scope":"Actual Main S/D movement and distance-selected frames; returning-player, appearance and open-ground placement fixtures. First appearance renders the full world; remaining appearances hide 3D/HUD and mirror the same actual Main Sprite/GPU hair texture. Not wardrobe UI, human play or all-world lighting acceptance."},"  "))
	print("PASS: native Main source repair 14 cases, three hairstyles/four hats, eight actual walk frames, pause, reduced motion and scene reentry")
	await main._quit_game()

func _process(_delta:float) -> void:
	if not reentering and is_instance_valid(main) and is_instance_valid(preview) and is_instance_valid(main.world) and main.world.avatar!=null:
		preview.texture=main.world.avatar.texture
		caption.text=("Actual Main Sprite / %s\n%s / %s / frame %d" if main.world.visible else "Main Sprite QA (3D hidden) / %s\n%s / %s / frame %d")%[main.world.avatar_appearance.hair,main.world.avatar_equipped.hat,main.world.last_avatar_direction,main.world.last_avatar_frame]

func _case(style:String,hat:String,reduced:bool,tag:String) -> bool:
	for code in [KEY_W,KEY_A,KEY_S,KEY_D,KEY_SHIFT]:_held_key(code,false)
	await _frames(3)
	main.world.player.position=Vector3(0,0.4,-6);main.world.player.velocity=Vector3.ZERO
	var look: Dictionary=WalkRenderer.DEFAULT_APPEARANCE.duplicate();look.hair=style
	main.world.set_avatar_look(look,{"outfit":"outfit-tide","hat":hat})
	await _frames(8)
	var start_position: Vector3=main.world.player.global_position
	var seen: Dictionary={};var captured:=false;var deadline:=Time.get_ticks_msec()+30000
	while seen.size()<8 or not captured or Vector2(main.world.player.global_position.x-start_position.x,main.world.player.global_position.z-start_position.z).length()<2.0:
		if Time.get_ticks_msec()>deadline:
			await _fail("Native source repair did not observe all distance-selected frames: "+style+"/"+hat);return false
		_held_key(KEY_S,true);_held_key(KEY_D,true)
		await get_tree().physics_frame;await get_tree().process_frame
		if not main.world.avatar_is_walking or main.world.last_avatar_action!="walk" or main.world.last_avatar_direction!="front_right":continue
		seen[main.world.last_avatar_frame]=true
		var receipt: Dictionary=main.world.avatar_hair_rig.receipt()
		if bool(receipt.active)==reduced or not Transform2D(receipt.root).is_equal_approx(Transform2D.IDENTITY) or not _avatar_texture_synced():
			await _fail("Source repair hair binding/material mismatch "+style+"/"+hat+" "+str(receipt));return false
		if main.world.last_avatar_frame==3 and not captured:
			await RenderingServer.frame_post_draw
			var live: Image=main.world.avatar.texture.get_image()
			var source: Texture2D=main.world.avatar_renderer.texture(look,{"outfit":"outfit-tide","hat":hat},"front_right",3,"walk")
			var feet_equal:=_visible_equal(live,source.get_image(),Rect2i(0,300,280,60))
			var ghost:=live.get_pixel(82,248)
			if not feet_equal or (ghost.a>=0.5 and ghost.r>ghost.b):await _fail("Live GPU source repair retained a third hand or changed the feet");return false
			var name:="%02d-%s-%s-%s.png"%[native_records.size(),tag,style,hat]
			if get_viewport().get_texture().get_image().save_png(folder.path_join("captures/"+name))!=OK:await _fail("Native source screenshot failed");return false
			captured=true
	for code in [KEY_S,KEY_D]:_held_key(code,false)
	var stop_deadline:=Time.get_ticks_msec()+4000
	while main.world.avatar_is_walking and Time.get_ticks_msec()<stop_deadline:
		await get_tree().physics_frame;await get_tree().process_frame
	await _frames(2)
	var distance:float=Vector2(main.world.player.global_position.x-start_position.x,main.world.player.global_position.z-start_position.z).length()
	if distance<2.0 or main.world.avatar_is_walking or main.world.last_avatar_action!="idle":await _fail("Real source repair movement/stop route was incomplete: distance="+str(distance)+" walking="+str(main.world.avatar_is_walking)+" action="+main.world.last_avatar_action);return false
	if not first_pause_checked:
		_key(KEY_ESCAPE);await _frames(4)
		if main.modal_kind!="pause" or not main.world.blocked:await _fail("Native source pause did not open");return false
		var held_phase:float=main.world.walk_distance_phase;var held_position:Vector3=main.world.player.position
		_held_key(KEY_S,true);_held_key(KEY_D,true);await _frames(8)
		if main.world.walk_distance_phase!=held_phase or main.world.player.position.distance_to(held_position)>0.001:await _fail("Paused source travel changed phase or position");return false
		for code in [KEY_S,KEY_D]:_held_key(code,false)
		_key(KEY_ESCAPE);await _frames(4)
		if main.modal_kind!="" or main.world.blocked:await _fail("Native source pause did not resume");return false
		first_pause_checked=true
	native_records.append({"hair":style,"hat":hat,"tag":tag,"frames":seen.keys(),"distance":distance,"gpu_hair_active":not reduced,"root_identity":true,"sprite_material_synced":true,"frame3_feet_exact":true,"extra_hand_absent":true})
	print("NATIVE SOURCE: ",tag," ",style," ",hat," frames=",seen.size()," distance=",distance)
	return true

func _visible_equal(a:Image,b:Image,region:Rect2i) -> bool:
	if a.get_size()!=b.get_size():return false
	for y in range(region.position.y,region.end.y):
		for x in range(region.position.x,region.end.x):
			var p:=a.get_pixel(x,y);var q:=b.get_pixel(x,y)
			if p.a!=q.a or (p.a>=0.5 and p!=q):return false
	return true
