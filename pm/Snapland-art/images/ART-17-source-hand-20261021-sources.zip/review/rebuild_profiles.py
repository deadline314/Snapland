from pathlib import Path
import json,hashlib
from tools.island_avatar.import_hair_ownership import build as build_owners
from tools.hero_2d.author_island_hair import build as build_wind
from tools.hero_2d.author_alternate_hair import build as build_alternate
r=Path.cwd();b=r/'work/hero-source-repair-20261021';assets=r/'assets/characters';stage=r/'work/tutorial-current-20261020/validation-project';owners=build_owners(b/'hair-ownership-new');(assets/'island-hair-alternate-owners-v1.json').write_text(json.dumps(owners,indent=2)+'\n');wind=build_wind();(assets/'island-hair-windswept-v1.json').write_text(json.dumps(wind,ensure_ascii=False,indent=2)+'\n');reports=[]
for style in ['windswept','bob','curly']:
 p=assets/('island-hair-'+style+'-v1.json')
 if style!='windswept':p.write_text(json.dumps(build_alternate(style),indent=2)+'\n')
 before=json.loads((b/'hair-profiles-before'/p.name).read_text());after=json.loads(p.read_text());changes=[]
 for direction in before['directions']:
  old=before['directions'][direction]['strands'];new=after['directions'][direction]['strands']
  for a,c in zip(old,new):
   assert a['root']==c['root'] and a['tip']==c['tip'] and a['spans']==c['spans'],'hair roots or owned pixels changed'
  if old!=new:changes.append({'direction':direction,'cut_spans_changed':True})
 reports.append({'style':style,'roots_tips_and_owned_hair_pixels_unchanged':True,'cut_span_changes':changes})
for name in ['island-hair-windswept-v1.json','island-hair-bob-v1.json','island-hair-curly-v1.json','island-hair-alternate-owners-v1.json']:(stage/'assets/characters'/name).write_bytes((assets/name).read_bytes())
old_owners=json.loads((b/'hair-profiles-before/island-hair-alternate-owners-v1.json').read_text());owner_changes=[]
for style in ['bob','curly']:
 for direction in owners['owners'][style]:
  a=old_owners['owners'][style][direction];c=owners['owners'][style][direction];assert a['hair_owner_spans']==c['hair_owner_spans']
  if a['source_alpha_spans']!=c['source_alpha_spans']:owner_changes.append({'style':style,'direction':direction,'union_alpha_changed':True})
result={'profiles':reports,'actual_compositor_union_changes':owner_changes,'dependency_scope':'Fresh actual two-style/eight-direction compositor ownership and walk+idle pose alpha unions, not assumed unchanged from the raw source union.','sha256':{name:hashlib.sha256((assets/name).read_bytes()).hexdigest() for name in ['island-hair-windswept-v1.json','island-hair-bob-v1.json','island-hair-curly-v1.json','island-hair-alternate-owners-v1.json']}};(b/'hair-rebuild-report.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='sha256'},indent=2))
