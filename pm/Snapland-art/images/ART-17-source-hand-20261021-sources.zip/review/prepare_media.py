from pathlib import Path
import subprocess,json
from PIL import Image,ImageDraw
b=Path('work/hero-source-repair-20261021');records=[]
for mode in ['normal','quarter']:
 p=b/f'native-{mode}-v3';assert json.loads((p/'result.json').read_text())['exit']==0
 subprocess.run(['ffmpeg','-n','-v','error','-i',str(p/'play.avi'),'-an','-c:v','libx264','-threads','1','-preset','veryfast','-crf','20','-pix_fmt','yuv420p',str(p/'review.mp4')],check=True,timeout=90)
 info=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-select_streams','v:0','-show_entries','stream=width,height,r_frame_rate,nb_read_frames,duration','-of','json',str(p/'review.mp4')],text=True))
 subprocess.run(['ffmpeg','-v','error','-i',str(p/'review.mp4'),'-f','null','-'],check=True,timeout=60)
 captures=sorted((p/'captures').glob('*.png'));assert len(captures)==14
 for page in range(4):
  chunk=captures[page*4:page*4+4];sheet=Image.new('RGB',(392*len(chunk),544),(222,220,205));d=ImageDraw.Draw(sheet)
  for i,path in enumerate(chunk):
   image=Image.open(path).convert('RGB');sheet.paste(image.crop((840,155,1232,659)),(392*i,40));d.text((392*i+6,6),f'{mode} / '+path.stem,fill=(0,0,0))
  sheet.save(p/f'live-sprite-contact-{page}.png')
 records.append({'mode':mode,'video':info['streams'][0],'decoded_all_frames':True,'actual_viewport_captures':14,'scope':'Silent fixed 20FPS authoring movie; first appearance full Main world, later actual Main sprite isolated, not measured hardware FPS or human play.'})
(b/'media-report.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps(records,indent=2))
