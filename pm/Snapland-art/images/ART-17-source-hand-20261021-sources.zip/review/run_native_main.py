from pathlib import Path
import os,json,time,shutil,subprocess
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();b=r/'work/hero-source-repair-20261021';stage=r/'work/tutorial-current-20261020/validation-project';dest=stage/'work/hero-source-repair-20261021'
for name in ['native_main_review.gd','native_main_review.tscn']:shutil.copyfile(b/name,dest/name)
for case in ['native-normal-v3','native-quarter-v3']:
 out=b/case;out.mkdir(exist_ok=False);cmd=[str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'),'--path',str(stage),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--resolution','1280x720','--fixed-fps','20','--log-file',str(out/'engine.log'),'--write-movie',str(out/'play.avi'),'res://work/hero-source-repair-20261021/native_main_review.tscn']
 if case=='native-quarter-v3':cmd+=['--','--quarter']
 start=time.monotonic()
 try:
  p=run_validated_godot(stage,cmd,dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'progress.json')),120 if case=='native-normal-v3' else 240)
 except subprocess.TimeoutExpired as e:
  log=''.join(x.decode(errors='replace') if isinstance(x,bytes) else x for x in [e.stdout or '',e.stderr or '']);(out/'result.log').write_text(log);(out/'result.json').write_text(json.dumps({'exit':None,'completed':False,'timeout_seconds':120 if case=='native-normal-v3' else 240,'seconds':round(time.monotonic()-start,2)},indent=2)+'\n');raise
 log=p.stdout+p.stderr;(out/'result.log').write_text(log);d={'exit':p.returncode,'errors':log.count('ERROR:'),'seconds':round(time.monotonic()-start,2)};(out/'result.json').write_text(json.dumps(d,indent=2)+'\n');print(case,d,log[-900:],flush=True);assert p.returncode==0 and d['errors']==0 and 'PASS: native Main source repair' in log
