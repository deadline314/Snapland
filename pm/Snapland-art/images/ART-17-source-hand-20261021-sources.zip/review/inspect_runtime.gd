extends SceneTree
func _initialize() -> void:
	var profile:=OS.get_environment("SNAPLAND_SAVE_PATH")
	if not profile.is_absolute_path():quit(2);return
	var corrected:=OS.get_environment("SNAPLAND_SOURCE_REPAIR_EXPECT_CORRECTED")=="1"
	var folder:=profile.get_base_dir();DirAccess.make_dir_recursive_absolute(folder)
	var avatar=preload("res://game/world/avatar_renderer.gd").new()
	var source: Image=avatar._walk_pose_image("front_right",3)
	var before:=Image.load_from_file(ProjectSettings.globalize_path("res://work/hero-source-repair-20261021/before-runtime.png"))
	before.convert(Image.FORMAT_RGBA8)
	var head_equal:=source.get_region(Rect2i(0,0,280,185)).get_data()==before.get_region(Rect2i(0,0,280,185)).get_data()
	var feet_equal:=source.get_region(Rect2i(0,300,280,60)).get_data()==before.get_region(Rect2i(0,300,280,60)).get_data()
	var hands_equal:=source.get_region(Rect2i(115,202,88,55)).get_data()==before.get_region(Rect2i(115,202,88,55)).get_data()
	var outside_visible:=0;var outside_rgba:=0
	var region:=Rect2i(68,218,37,47)
	for y in 360:
		for x in 280:
			if region.has_point(Vector2i(x,y)):continue
			var a:=source.get_pixel(x,y);var b:=before.get_pixel(x,y)
			if a!=b:outside_rgba+=1
			if a.a!=b.a or (a.a>=0.5 and a!=b):outside_visible+=1
	var ghost:=source.get_pixel(82,248)
	if not head_equal or not feet_equal or not hands_equal or outside_visible!=0:
		push_error("Source correction changed protected original pixels");quit(1);return
	if corrected and ghost.r>ghost.b:push_error("Extra source hand is still visible");quit(1);return
	if not corrected and ghost.r<=ghost.b:push_error("Before fixture did not reproduce the extra hand");quit(1);return
	var records: Array=[]
	for style in ["windswept","bob","curly"]:
		var appearance: Dictionary=avatar.DEFAULT_APPEARANCE.duplicate();appearance.hair=style
		for frame in 8:
			var rendered: Texture2D=avatar.texture(appearance,{"outfit":"outfit-tide","hat":"hat-none"},"front_right",frame,"walk")
			var image:=rendered.get_image();var stem:="%s-%02d.png"%[style,frame]
			image.save_png(folder.path_join(stem))
			if corrected:
				var old:=Image.load_from_file(ProjectSettings.globalize_path("res://work/hero-source-repair-20261021/runtime-before/"+stem));old.convert(Image.FORMAT_RGBA8)
				if image.get_region(Rect2i(0,0,280,185)).get_data()!=old.get_region(Rect2i(0,0,280,185)).get_data() or image.get_region(Rect2i(0,300,280,60)).get_data()!=old.get_region(Rect2i(0,300,280,60)).get_data():
					push_error("Hair or feet changed after source correction: "+stem);quit(1);return
				if frame!=3 and image.get_data()!=old.get_data():push_error("An unrelated source pose changed: "+stem);quit(1);return
			records.append({"hair":style,"frame":frame,"source_correction":corrected})
	if not avatar._missing_head_owner_warnings.is_empty():push_error("Source correction broke hair ownership");quit(1);return
	source.save_png(folder.path_join("source.png"))
	FileAccess.open(folder.path_join("report.json"),FileAccess.WRITE).store_string(JSON.stringify({"corrected":corrected,"source_rgba_sha256":avatar.head_source_signature(source),"original_runtime_rgba_sha256":avatar.head_source_signature(before),"head_exact":head_equal,"feet_exact":feet_equal,"camera_hands_exact":hands_equal,"outside_visible_changed":outside_visible,"outside_rgba_changed":outside_rgba,"appearances":records},"  "))
	print("PASS: corrected source and three hairstyles retain original heads, feet and unrelated cels" if corrected else "REPRODUCED: source cel has an extra third hand behind the backpack; baseline appearances exported")
	quit()
