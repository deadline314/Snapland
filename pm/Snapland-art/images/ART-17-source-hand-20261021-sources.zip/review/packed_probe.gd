extends SceneTree
func _initialize() -> void:
	_run.call_deferred()
func _run() -> void:
	var profile:=OS.get_environment("SNAPLAND_SAVE_PATH")
	if not profile.is_absolute_path() or DisplayServer.get_name()=="headless":quit(2);return
	var folder:=profile.get_base_dir();DirAccess.make_dir_recursive_absolute(folder)
	if FileAccess.file_exists("res://assets/characters/walk-stability-v1/island-raw-front_right.png") or FileAccess.file_exists("res://tools/island_avatar/garment_ownership.gd") or FileAccess.file_exists("res://game/tests/test_garment_part_ownership.gd"):
		push_error("Packed probe must use imported resources without raw PNG, tools or tests");quit(1);return
	var renderer=load("res://game/world/avatar_renderer.gd").new()
	var source:Image=renderer._walk_pose_image("front_right",3)
	if renderer.head_source_signature(source)!="d0247653d44007566eb24624a8b7d9f705bd8bc0dd46835e71c468f12960ac2c":push_error("Packed cel differs from reviewed source correction");quit(1);return
	var rig=load("res://game/world/avatar_hair_rig.gd").new();root.add_child(rig);await process_frame
	var records:Array=[]
	for hair in ["windswept","bob","curly"]:
		var look:Dictionary=renderer.DEFAULT_APPEARANCE.duplicate();look.hair=hair
		for hat in ["hat-none","hat-straw","hat-sailor","hat-flower"]:
			var equipment:Dictionary={"outfit":"outfit-tide","hat":hat}
			var original:Texture2D=renderer.texture(look,equipment,"front_right",3,"walk")
			var result:Texture2D=rig.sync_pose(original,renderer,look,equipment,"front_right",3,"walk")
			var receipt:Dictionary=rig.receipt()
			if not receipt.active or not Transform2D(receipt.root).is_equal_approx(Transform2D.IDENTITY):push_error("Packed hair source/dependency validation failed: "+str(receipt));quit(1);return
			rig.advance(0.05,Vector2(40,20),false);await process_frame;await RenderingServer.frame_post_draw
			var original_image:Image=original.get_image()
			var image:Image=result.get_image();var ghost:=image.get_pixel(82,248)
			if ghost.a>=0.5 and ghost.r>ghost.b:push_error("Packed GPU texture retained extra hand");quit(1);return
			for y in range(300,360):
				for x in 280:
					var a:=image.get_pixel(x,y);var c:=original_image.get_pixel(x,y)
					if a.a!=c.a or (a.a>=0.5 and a!=c):push_error("Packed GPU feet changed");quit(1);return
			image.save_png(folder.path_join(hair+"-"+hat+".png"))
			records.append({"hair":hair,"hat":hat,"source_corrected":true,"root_identity":true,"gpu_hair_active":true,"feet_exact":true})
		for view in renderer.WALK_DIRECTIONS:
			if not rig._valid_view(view):push_error("Packed hair profile invalid in "+hair+"/"+view);quit(1);return
	if not renderer._missing_head_owner_warnings.is_empty():push_error("Packed owner missing");quit(1);return
	FileAccess.open(folder.path_join("audit.json"),FileAccess.WRITE).store_string(JSON.stringify({"cases":records,"all_24_style_direction_profiles_valid":true,"raw_png_absent":true,"tools_and_tests_absent":true,"scope":"Editor GPU probe loads separately exported player PCK from a clean probe directory. Separate actual release main smoke; not wardrobe or human play."},"  "))
	print("PASS: packed corrected source, twelve live GPU hair/hat combinations and all 24 direction/style profiles without loose art, tools or tests")
	rig.queue_free();await process_frame;quit()
