from pathlib import Path
import os,time,json,shutil,subprocess
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();b=r/'work/hero-source-repair-20261021';engine=r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64';stage=b/'release-v1/project';pack=b/'pack-v1';pack.mkdir(exist_ok=False)
probe=b/'pack-probe-v1';probe.mkdir(exist_ok=False);(probe/'project.godot').write_text('[application]\nconfig/name="Private packed resource probe"\n');shutil.copyfile(b/'packed_probe.gd',probe/'probe.gd')
for label,root,args,timeout in [('export',stage,['--headless','--path',str(stage),'--editor','--export-pack','Linux Desktop',str(pack/'Snapland.pck'),'--quit'],120),('gpu',probe,['--path',str(probe),'--main-pack',str(pack/'Snapland.pck'),'--script',str(probe/'probe.gd'),'--audio-driver','Dummy','--rendering-method','gl_compatibility'],120)]:
 out=pack/label;out.mkdir();start=time.monotonic()
 try:p=run_validated_godot(root,[str(engine),*args],dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'progress.json')),timeout)
 except subprocess.TimeoutExpired as e:
  (out/'result.log').write_text((e.stdout or '')+(e.stderr or ''));(out/'result.json').write_text(json.dumps({'exit':None,'timeout':timeout}));raise
 log=p.stdout+p.stderr;(out/'result.log').write_text(log);d={'exit':p.returncode,'errors':log.count('ERROR:'),'seconds':round(time.monotonic()-start,2)};(out/'result.json').write_text(json.dumps(d,indent=2)+'\n');print(label,d,log[-800:],flush=True);assert p.returncode==0 and d['errors']==0
 if label=='gpu':assert 'PASS: packed corrected source' in log
