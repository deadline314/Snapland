extends SceneTree
var records: Array=[]
var folder:=""
func _initialize() -> void:
	var profile:=OS.get_environment("SNAPLAND_SAVE_PATH")
	if not profile.is_absolute_path():quit(2);return
	folder=profile.get_base_dir();DirAccess.make_dir_recursive_absolute(folder)
	var avatar=preload("res://game/world/avatar_renderer.gd").new()
	avatar._stable_walk_pixels.manifest.clear();avatar._walk_source_image_cache.clear()
	for view in avatar.WALK_DIRECTIONS:
		for frame in 8:
			if not _save(avatar._walk_pose_image(view,frame),"island-raw",view,frame):return
	var library=preload("res://game/world/character_animation_library.gd").new()
	library._stable_walk_pixels.manifest.clear()
	for group in [["announcer","walk","left"],["announcer","walk","right"],["announcer","walk_candidate","front"],["ticket","walk_candidate","front"]]:
		for frame in library.frame_count(group[0],group[1],group[2]):
			var texture: Texture2D=library.texture(group[0],group[1],group[2],frame)
			if texture==null:push_error("Raw rebuild source missing");quit(1);return
			if not _save(texture.get_image(),group[0]+"-"+group[1],group[2],frame):return
	if records.size()!=88:push_error("Raw rebuild must retain all eight hero and four NPC diagnostic groups");quit(1);return
	FileAccess.open(folder.path_join("frames.json"),FileAccess.WRITE).store_string(JSON.stringify({"frames":records,"scope":"Raw inputs for deterministic full canvas rebuild. Rejected NPC diagnostic candidates remain diagnostic; this does not adopt NPC walking."},"  "))
	print("PASS: raw rebuild 88 source cels across all twelve existing groups")
	quit()
func _save(image:Image,family:String,view:String,frame:int) -> bool:
	var name:="%s--%s--%02d.png"%[family,view,frame]
	if FileAccess.file_exists(folder.path_join(name)) or image.save_png(folder.path_join(name))!=OK:push_error("Raw source output exists or cannot be saved");quit(1);return false
	records.append({"family":family,"view":view,"frame":frame,"file":name,"size":[image.get_width(),image.get_height()]})
	return true
