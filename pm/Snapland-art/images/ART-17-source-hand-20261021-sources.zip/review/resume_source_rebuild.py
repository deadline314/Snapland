from pathlib import Path
import shutil,os,json,time,hashlib
from PIL import Image
from tools.godot_entrypoints import run_validated_godot
from tools.walk_stability.build_registered_walks import compile_frames
from tools.walk_stability.check_registration import inspect
r=Path.cwd();b=r/'work/hero-source-repair-20261021';raw=b/'raw-rebuild-v1'
assert json.loads((raw/'result.json').read_text())['exit']==0 and len(list(raw.glob('*.png')))==88
old=json.loads((r/'assets/characters/walk-stability-v1/manifest.json').read_text());matches=[]
for key,spec in old['sequences'].items():
 actor,view=key.split('/');family='island-raw' if actor=='hero' else actor
 for frame in range(spec['frames']):
  source=raw/('%s--%s--%02d.png'%(family,view,frame));matches.append(hashlib.sha256(source.read_bytes()).hexdigest()==spec['source_frame_sha256'][frame])
(b/'raw-input-hash-comparison.json').write_text(json.dumps({'input_files':len(matches),'exact_old_png_hash_matches':sum(matches),'scope':'PNG byte identity is reported separately from pixel identity and independently guarded repair inputs.'},indent=2)+'\n')
output=b/'recompiled-v1';assert not output.exists();new=compile_frames(raw,output);registered=b/'registered-rebuild-v1';registered.mkdir(exist_ok=False);equal=[]
for key,spec in new['sequences'].items():
 actor,view=key.split('/');family='island-raw' if actor=='hero' else actor
 atlas=Image.open(r/spec['source'].removeprefix('res://')).convert('RGBA');existing=Image.open(r/old['sequences'][key]['source'].removeprefix('res://')).convert('RGBA');assert atlas.size==existing.size
 visible_equal=True
 for a,c in zip(atlas.get_flattened_data(),existing.get_flattened_data()):
  if a[3]!=c[3] or (a[3]>=128 and a[:3]!=c[:3]):visible_equal=False;break
 equal.append({'sequence':key,'alpha_and_opaque_rgb_equal_current_atlas':visible_equal})
 assert visible_equal,'Full rebuild changed a runtime sequence beyond the reviewed local repair: '+key
 w,h=spec['canvas']
 for frame in range(spec['frames']):atlas.crop((w*frame,0,w*(frame+1),h)).save(registered/('%s--%s--%02d.png'%(family,view,frame)))
audit=inspect(raw,registered,output);assert not audit['errors'],audit['errors'];(b/'source-rebuild-verification.json').write_text(json.dumps({'sequences':equal,'raw_inputs':88,'root_audit':audit['result'],'scope':'All twelve groups rebuilt; all visible runtime pixels match, with exactly the approved local hand correction. Original candidate NPC diagnostics are not adopted.'},indent=2)+'\n');print('PASS: deterministic full twelve-group rebuild, current visible atlas equality and independent original/root/limb audit')
