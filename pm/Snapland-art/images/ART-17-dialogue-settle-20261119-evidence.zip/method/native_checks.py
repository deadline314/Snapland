"""Verify real key events, planted NPC turns, and packaged dialogue playback."""
from pathlib import Path

here = Path(__file__).resolve().parent
template = here.parent / "art16-20261119/verify_departure.py"
source = template.read_text("utf8").replace("D:/Snapland-QA/art16-20261119", "D:/Snapland-QA/npc-dialogue-settle-20261119")
start = source.index("FIXTURE =")
end = source.index("paths = subprocess.check_output", start)
source = source[:start] + '''FIXTURE = "game/tests/native_walking_dialogue"
TESTS = {}
runner.FIXTURES = [FIXTURE+".gd", FIXTURE+".tscn","game/tests/native_npc_approach_review.gd","game/tests/audio_playback_release.gd"]
def fixture_source(name):
    if name.startswith(FIXTURE+"."): return HERE/Path(name).name
    return ROOT/name
''' + source[end:]
source = source.replace("runner.sha(ROOT/name) for name in runner.FIXTURES", "runner.sha(fixture_source(name)) for name in runner.FIXTURES")
source = source.replace("shutil.copy2(ROOT/name,target)", "shutil.copy2(fixture_source(name),target)")
source = source.replace("AnnouncerDepartureQA.exe", "NPCWalkingDialogueQA.exe")
source = source.replace('"normal":[]','"normal":["--rebuild"]')
source = source.replace('"--actor=announcer","--actions-only",','')
start = source.index('    report=runner.read(out/"announcer-report.json")')
end = source.index("    assert movie.stat().st_size", start)
source = source[:start] + '''    report=runner.read(out/"npc-approach-report.json")
    assert report["technical_status"]=="PASS" and not report["failures"]
    assert report["time_scale"] == (0.25 if mode=="quarter" else 1.0)
    assert report["scene_rebuild"] == (mode!="embedded")
    assert report["reduced_motion"] == (mode=="reduced")
    cases=report["roles"]
    assert len(cases)==(3 if mode=="embedded" else 6)
    assert all(case["held_positions"] and case["source_consistent"] for case in cases)
    if mode!="reduced":
        for case in cases:
            expected = 5 if (case["role"],case["side"])==("announcer","left") else 4
            assert set(case["settle_frames"])==set(range(expected))
            assert set(case["gesture_frames"])==set(range(7 if case["role"]=="imp" else 8))
''' + source[end:]
exec(compile(source,str(here/"native_checks.py"),"exec"))
