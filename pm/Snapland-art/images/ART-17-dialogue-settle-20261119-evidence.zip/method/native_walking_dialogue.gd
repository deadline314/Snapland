extends "res://game/tests/native_npc_approach_review.gd"

func _ready() -> void:
	_report.placement_note = "The fixture advances the active patrol through the controller before placing only the player within front interaction range. E opens actual Main dialogue while the actor walks. Camera-follow is then held for the recording. No actor root, route data or authored source is substituted."
	super._ready()

func _review_role(role: String, pass_index: int, reduced: bool) -> void:
	_world.set_physics_process(true)
	_world.player.visible = true
	_world.apply_settings({"reduced_motion": false})
	if reduced:
		await super._review_role(role, pass_index, true)
		return
	var actor := _actor(role)
	var root: Node3D = actor.activity_root
	var sprite: Sprite3D = actor.sprite
	var side := "right" if pass_index == 0 else "left"
	var action := "greet" if role == "ticket" else "interact"
	var label := role + "-" + side
	var selected := false
	for _attempt in range(3):
		var walking := false
		for _step in range(1200):
			var previous := root.global_position
			_world.npc_activity._process(1.0 / 60.0)
			var record := _record(role)
			if record.action == "walk" and record.direction == side and root.global_position.distance_to(previous) > 0.001:
				walking = true
				break
		if not _check(walking, label + " advances the actual authored patrol to the desired moving side"): return
		_world.player.global_position = root.global_position + Vector3(0.0, 0.10, 1.35)
		await get_tree().physics_frame
		await get_tree().physics_frame
		await get_tree().process_frame
		var current := _record(role)
		selected = _world.nearest.get("id", "") == POINTS[role] and current.action == "walk" and current.direction == side
		if selected: break
	if not _check(selected, label + " real proximity approaches an actor still walking"): return
	var roots := {}
	var points := {}
	for other in POINTS:
		roots[other] = (_actor(other).activity_root as Node3D).global_position
		points[other] = _world._point_by_id(POINTS[other]).position
	var event := InputEventKey.new()
	event.physical_keycode = KEY_E
	event.keycode = KEY_E
	event.pressed = true
	Input.parse_input_event(event)
	Input.flush_buffered_events()
	var record := _record(role)
	if not _check(_main.modal_kind == "dialogue" and _world.blocked and record.action == "settle" and record.direction == side, label + " E opens dialogue immediately on the first side turn cel"): return
	_world.player.visible = false
	_world.set_physics_process(false)
	var camera: Camera3D = _world.camera
	camera.global_position = root.global_position + Vector3(0,2.0,4.2)
	camera.look_at(root.global_position + Vector3(0,0.45,0), Vector3.UP)
	camera.size = 6.0
	camera.current = true
	_world._update_sprite_grounding()
	var row := {"role":role, "pass":pass_index, "side":side, "action":action,
		"settle_frames":[], "gesture_frames":[], "source_consistent":true, "held_positions":true,
		"clock_prepared_via_patrol_ticks":true}
	var settle: Dictionary = record.action_sequence
	var started := 0.0
	var captured_turn := false
	var captured_action := false
	var greeting: Dictionary = {}
	while started < 2.6:
		await RenderingServer.frame_post_draw
		if event.pressed:
			event.pressed = false
			Input.parse_input_event(event)
			Input.flush_buffered_events()
		record = _record(role)
		row.held_positions = bool(row.held_positions) and _held_positions(roots, points)
		if record.action == "settle" or record.action == action:
			row.source_consistent = bool(row.source_consistent) and _source_matches(role, sprite, record)
			var seq: Dictionary = record.action_sequence
			var cel := Timing.frame_at_time(seq, float(record.action_elapsed))
			if record.action == "settle":
				if not row.settle_frames.has(cel): row.settle_frames.append(cel)
				if cel == 2 and not captured_turn:
					captured_turn = true
					await _capture(label + "-turn", sprite, row)
			else:
				greeting = seq
				if not row.gesture_frames.has(cel): row.gesture_frames.append(cel)
				if cel == 3 and not captured_action:
					captured_action = true
					await _capture(label + "-gesture", sprite, row)
		elif not greeting.is_empty():
			break
		await get_tree().process_frame
		started += get_process_delta_time()
	_check(record.action in ["stand","idle"] and record.direction == "front" and _source_matches(role,sprite,record), label + " returns to complete front idle")
	_check(row.settle_frames.size() == settle.frames.size() and row.gesture_frames.size() == greeting.get("frames",[]).size(), label + " renders every authored turn and gesture cel")
	_check(captured_turn and captured_action and bool(row.held_positions) and bool(row.source_consistent), label + " crops neither pose and keeps roots and points fixed")
	_report.roles.append(row)
	await _press_key(KEY_ESCAPE)
	_check(_main.modal_kind == "" and not _world.npc_dialogue_hold, label + " exits dialogue without a queued gesture")
