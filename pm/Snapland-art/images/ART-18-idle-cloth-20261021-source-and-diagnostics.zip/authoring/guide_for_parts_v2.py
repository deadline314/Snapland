from pathlib import Path
from PIL import Image
import json,shutil,hashlib
r=Path.cwd();b=r/'work/outfit-eight-view-20261021';p=Path('/workspace/generated_images/exec-b5fe7335-4807-4f5a-8770-63dad6dd66e7.png');shutil.copyfile(p,b/'parts-v2.png');size=Image.open(p).size
(b/'parts-v2-provenance.json').write_text(json.dumps({'original':str(p),'size':size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'prompt':'prompt-v2-sleeves.txt','state':'unintegrated_sleeve_pose_correction'},indent=2)+'\n')
j=json.loads((b/'probe-guide-v4.json').read_text());j['atlas']=str((b/'parts-v2.png').relative_to(r));j['atlas_size']=list(size);j['atlas_sha256']=hashlib.sha256(p.read_bytes()).hexdigest();j['source_arm_radius']=33
S=[[[[137,222],[112,278],[145,287]],[[274,222],[302,278],[267,287]]],[[[142,221],[135,280],[199,289]],[[259,221],[290,263],[305,279]]],[[[175,221],[157,278],[239,287]],[[360,100],[370,120],[380,140]]],[[[136,221],[112,267],[91,284]],[[278,221],[302,264],[315,280]]],[[[137,148],[121,190],[90,205]],[[275,148],[291,191],[316,205]]],[[[145,148],[122,190],[102,205]],[[263,148],[282,190],[299,199]]],[[[360,100],[370,120],[380,140]],[[236,150],[255,211],[143,211]]],[[[137,150],[113,190],[134,203]],[[263,150],[285,205],[226,217]]]]
for i,row in enumerate(j['frames']):
 row['source_arms']=S[i]
 if i==1:row['arm_owner_bounds']=[[30,235],[260,380]];row['arm_mesh_regions']=[[30,180,205,175],[260,180,120,175]]
 elif i==2:row['arm_owner_bounds']=[[80,280],[350,390]];row['arm_mesh_regions']=[[80,180,200,175],[350,100,40,60]]
 elif i==6:row['arm_owner_bounds']=[[350,390],[100,310]];row['arm_mesh_regions']=[[350,100,40,60],[100,100,210,175]]
 elif i==7:row['arm_owner_bounds']=[[30,175],[190,380]];row['arm_mesh_regions']=[[30,100,145,175],[190,100,190,175]]
 else:row['arm_owner_bounds']=[[30,200],[230,380]]
 row['atlas_region'][2]=min(row['atlas_region'][2],size[0]-row['atlas_region'][0])
(b/'parts-v2-guide-v1.json').write_text(json.dumps(j,indent=2)+'\n');q=r/'work/tutorial-current-20261020/validation-project'/j['atlas'];shutil.copyfile(p,q);print('source',size)
