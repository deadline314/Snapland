from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
import json,hashlib,copy,colorsys,shutil
r=Path.cwd();b=r/'work/outfit-eight-view-20261021';src=r/'work/outfit-authoring-20261021/current-sources/sources';base=json.loads((r/'tools/island_avatar/garments/mustard-front-guide.json').read_text());proto=copy.deepcopy(base['frames'][0]);base['frames']=[];base['atlas']=str((b/'parts-v1.png').relative_to(r));base['atlas_size']=[1563,1006];base['atlas_sha256']=hashlib.sha256((b/'parts-v1.png').read_bytes()).hexdigest();base['width_scale']=.5;base['source_arm_radius']=33
D=['front','front_right','right','back_right','back','back_left','left','front_left']
S=[[[[135,222],[109,279],[101,324]],[[274,222],[300,279],[319,324]]],[[[143,222],[133,274],[142,321]],[[259,221],[290,274],[308,317]]],[[[166,221],[155,269],[150,319]],[[239,227],[250,264],[265,305]]],[[[135,221],[110,257],[91,295]],[[278,221],[300,258],[320,300]]],[[[137,148],[110,190],[88,233]],[[275,148],[302,190],[319,233]]],[[[145,148],[123,191],[103,233]],[[263,148],[284,190],[299,227]]],[[[157,150],[142,190],[131,233]],[[239,150],[253,190],[265,232]]],[[[138,150],[108,193],[91,237]],[[264,149],[286,194],[299,238]]]]
T=[[[[108,202],[92,229],[102,237]],[[174,202],[191,229],[182,237]]],[[[121,202],[111,233],[124,237]],[[176,202],[190,229],[186,237]]],[[[137,202],[134,237],[157,239]],[[162,201],[176,222],[183,236]]],[[[104,206],[95,229],[95,239]],[[171,202],[184,229],[187,238]]],[[[110,201],[96,227],[102,236]],[[174,201],[186,227],[184,238]]],[[[110,202],[94,227],[93,238]],[[175,202],[184,228],[184,238]]],[[[123,202],[111,225],[100,237]],[[144,202],[145,237],[121,239]]],[[[104,202],[91,228],[96,237]],[[166,202],[172,234],[153,239]]]]
P=[[[96,218,29,27],[171,217,27,28],[119,211,53,42]],[[120,216,31,29],[181,216,24,30],[147,207,43,43]],[[153,216,32,29],[183,214,17,31],[168,206,39,48]],[[177,218,27,29]],[[91,219,23,27]],[[80,219,26,28]],[[100,215,31,31],[74,208,43,48]],[[133,216,29,29],[91,215,21,29],[99,208,47,46]]]
for i,d in enumerate(D):
 row=copy.deepcopy(proto);row.update(action='idle',direction=d,frame=0,atlas_region=[i%4*391,i//4*503,390 if i%4==3 else 391,503]);im=Image.open(src/('idle-'+d+'-00.png')).convert('RGBA');row['source_pixel_sha256']=hashlib.sha256(im.tobytes()).hexdigest();row['source_root']=[195,220 if i<4 else 150];row['target_root']=[140,205];row['source_arms']=S[i];row['target_arms']=T[i]
 row['body_polygon']=[[10,80],[380,80],[380,455],[10,455]];row['arm_mesh_regions']=[[40,100,175,310],[210,100,170,310]];row['arm_owner_bounds']=[[30,215],[210,380]];row['part_order']=['arm_0','body','arm_1'];row['draw_clip']=[0,192,280,118];row['protection']={'head':[0,0,280,192],'feet':[0,310,280,50]};row['unchanged_regions']=[[0,0,280,192],[0,310,280,50]]
 for j,rect in enumerate(P[i]):row['protection']['foreground_'+str(j)]=rect
 # Offline foreground draft only. Exact spans and original fingerprint are
 # frozen in the candidate guide for visual review, never inferred live.
 mask=Image.new('L',(280,360));pix=mask.load()
 for y in range(192,265):
  for x in range(60,220):
   red,green,blue,alpha=im.getpixel((x,y));h,s,v=colorsys.rgb_to_hsv(red/255,green/255,blue/255)
   if alpha>12 and .035<h<.14 and s>.28 and .12<v<.69 and red>green*1.17:pix[x,y]=255
 # Original bag/strap border pixels need one-pixel foreground ownership too.
 mask=mask.filter(ImageFilter.MaxFilter(3));spans=[]
 for y in range(192,265):
  xs=[x for x in range(280) if mask.getpixel((x,y)) and im.getpixel((x,y))[3]>12];start=last=None
  for x in xs:
   if start is None:start=last=x
   elif x==last+1:last=x
   else:spans.append([y,start,last]);start=last=x
  if start is not None:spans.append([y,start,last])
 row['protection_spans']=spans;base['frames'].append(row)
base['provenance']['review']='Unreviewed eight-direction idle clothing registration probe; no live adoption.'
(b/'probe-guide-v1.json').write_text(json.dumps(base,indent=2)+'\n')
stage=r/'work/tutorial-current-20261020/validation-project';dest=stage/base['atlas'];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(b/'parts-v1.png',dest)
print('Prepared eight unreviewed idle guides')
