from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
import json,colorsys
b=Path('work/outfit-eight-view-20261021');j=json.loads((b/'parts-v2-guide-v2.json').read_text());src=Path('work/outfit-authoring-20261021/current-sources/sources')
for i,row in enumerate(j['frames']):
 if i==6:row['target_arms'][1]=[[144,202],[158,237],[134,239]]
 if i==7:
  row['target_arms'][1]=[[166,202],[188,232],[169,237]];row['target_arms'][0][2]=[102,237];row['source_arms'][0][2]=[111,203]
 mask=Image.new('L',(280,360));im=Image.open(src/('idle-'+row['direction']+'-00.png')).convert('RGBA')
 for y,lo,hi in row['protection_spans']:
  for x in range(lo,hi+1):mask.putpixel((x,y),255)
 skin=Image.new('L',(280,360))
 for y in range(192,265):
  for x in range(60,220):
   r,g,bb,a=im.getpixel((x,y));h,s,v=colorsys.rgb_to_hsv(r/255,g/255,bb/255)
   if a>12 and 0<h<.18 and s>.2 and v>.25 and r>g*1.05 and g>bb*1.05:skin.putpixel((x,y),255)
 skin=skin.filter(ImageFilter.MaxFilter(3));spans=[]
 for y in range(192,265):
  start=None;last=None
  for x in range(280):
   marked=(mask.getpixel((x,y)) or skin.getpixel((x,y))) and im.getpixel((x,y))[3]>12
   if marked:
    if start is None:start=x
    last=x
   elif start is not None:spans.append([y,start,last]);start=last=None
  if start is not None:spans.append([y,start,last])
 row['protection_spans']=spans;row['protection']={k:v for k,v in row['protection'].items() if not k.startswith('foreground')}
 camera={0:[119,211,53,42],1:[147,207,43,43],2:[168,206,39,48],6:[74,208,43,48],7:[99,208,47,46]}.get(i)
 if camera:row['protection']['camera']=camera
(b/'parts-v2-guide-v3.json').write_text(json.dumps(j,indent=2)+'\n')
