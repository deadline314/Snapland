from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
import json,colorsys,copy,hashlib
b=Path('work/outfit-eight-view-20261021');base=json.loads((b/'parts-v2-guide-v6.json').read_text());src=Path('work/outfit-authoring-20261021/current-sources/sources');manifest=json.loads(Path('assets/characters/idle-stability-v1/manifest.json').read_text())['sequences']
def hull(points):
 points=sorted(set(points))
 def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
 lo=[];hi=[]
 for p in points:
  while len(lo)>=2 and cross(lo[-2],lo[-1],p)<=0:lo.pop()
  lo.append(p)
 for p in reversed(points):
  while len(hi)>=2 and cross(hi[-2],hi[-1],p)<=0:hi.pop()
  hi.append(p)
 return lo[:-1]+hi[:-1]
def foreground(im,direction):
 mask=Image.new('L',(280,360));seeds=set()
 for y in range(192,265):
  for x in range(60,220):
   r,g,bb,a=im.getpixel((x,y));h,s,v=colorsys.rgb_to_hsv(r/255,g/255,bb/255)
   if a<=12:continue
   brown=y<260 and .035<h<.14 and s>.28 and .12<v<.69 and r>g*1.17
   if brown:seeds.add((x,y))
   if brown or (y<255 and v>.65 and s<.35) or (y<252 and 0<h<.18 and s>.2 and v>.25 and r>g*1.05 and g>bb*1.05):mask.putpixel((x,y),255)
 components=[];left=set(seeds)
 while left:
  p=left.pop();component=[p];queue=[p]
  while queue:
   x,y=queue.pop()
   for dx,dy in [(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1)]:
    n=(x+dx,y+dy)
    if n in left:left.remove(n);component.append(n);queue.append(n)
  components.append(component)
 if direction!='front':
  largest=max(components,key=len)
  if len(largest)>50:ImageDraw.Draw(mask).polygon(hull(largest),fill=255)
 mask=mask.filter(ImageFilter.MaxFilter(3));spans=[]
 for y in range(192,265):
  start=None;last=None
  for x in range(280):
   marked=mask.getpixel((x,y)) and im.getpixel((x,y))[3]>12
   if marked:
    if start is None:start=x
    last=x
   elif start is not None:spans.append([y,start,last]);start=last=None
  if start is not None:spans.append([y,start,last])
 return spans
rows=[]
for row in base['frames']:
 direction=row['direction'];count=int(manifest['hero-idle/'+direction]['frames'])
 for f in range(count):
  new=copy.deepcopy(row);new['frame']=f;im=Image.open(src/('idle-'+direction+'-%02d.png'%f)).convert('RGBA');new['source_pixel_sha256']=hashlib.sha256(im.tobytes()).hexdigest();new['protection_spans']=foreground(im,direction)
  # The earlier whole-body warm draft included trouser edges; new hand ownership stops above them.
  breath=f in ([2,3] if count==8 else [1])
  if breath:
   new['target_root'][1]-=1
   for arm in new['target_arms']:
    for point in arm:point[1]-=1
  rows.append(new)
base['frames']=rows;base['provenance']['review']='Unintegrated eight-direction dedicated idle candidate, 36 actual source cels; source-specific foreground spans require review. Clothing-only one-pixel breath follows the existing original body pose; no body changes.'
(b/'idle36-guide-v2.json').write_text(json.dumps(base,indent=2)+'\n');print('Prepared',len(rows),'actual idle cels; foreground hand draft excludes trouser edges')
