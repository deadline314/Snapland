from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
import json,colorsys
b=Path('work/outfit-eight-view-20261021');j=json.loads((b/'parts-v2-guide-v1.json').read_text());src=Path('work/outfit-authoring-20261021/current-sources/sources')
def hull(points):
 points=sorted(set(points))
 def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
 lo=[];hi=[]
 for p in points:
  while len(lo)>=2 and cross(lo[-2],lo[-1],p)<=0:lo.pop()
  lo.append(p)
 for p in reversed(points):
  while len(hi)>=2 and cross(hi[-2],hi[-1],p)<=0:hi.pop()
  hi.append(p)
 return lo[:-1]+hi[:-1]
for i,row in enumerate(j['frames']):
 if i==2:row['target_root']=[148,202]
 if i==6:row['source_arms'][1][0]=[202,155];row['source_arms'][1][1]=[226,207];row['target_root']=[144,200]
 if i==3:row['target_root']=[133,203]
 if i==4:row['target_root']=[139,202]
 if i==5:row['target_root']=[138,202]
 im=Image.open(src/('idle-'+row['direction']+'-00.png')).convert('RGBA');seeds=set();white=[]
 for y in range(192,260):
  for x in range(60,220):
   r,g,bb,a=im.getpixel((x,y));h,s,v=colorsys.rgb_to_hsv(r/255,g/255,bb/255)
   if a<=12:continue
   if .035<h<.14 and s>.28 and .12<v<.69 and r>g*1.17:seeds.add((x,y))
   if v>.65 and s<.35 and y<255:white.append((x,y))
 components=[];left=set(seeds)
 while left:
  p=left.pop();component=[p];queue=[p]
  while queue:
   x,y=queue.pop()
   for dx,dy in [(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1)]:
    n=(x+dx,y+dy)
    if n in left:left.remove(n);component.append(n);queue.append(n)
  components.append(component)
 mask=Image.new('L',(280,360));draw=ImageDraw.Draw(mask)
 for point in seeds|set(white):mask.putpixel(point,255)
 if row['direction'] not in ['front']:
  largest=max(components,key=len)
  if len(largest)>50:draw.polygon(hull(largest),fill=255)
 mask=mask.filter(ImageFilter.MaxFilter(3));spans=[]
 for y in range(192,265):
  start=None;last=None
  for x in range(280):
   marked=mask.getpixel((x,y)) and im.getpixel((x,y))[3]>12
   if marked:
    if start is None:start=x
    last=x
   elif start is not None:spans.append([y,start,last]);start=last=None
  if start is not None:spans.append([y,start,last])
 row['protection_spans']=spans
(b/'parts-v2-guide-v2.json').write_text(json.dumps(j,indent=2)+'\n')
