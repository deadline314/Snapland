from pathlib import Path
import os,json,time,shutil
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();b=r/'work/outfit-eight-view-20261021';stage=r/'work/tutorial-current-20261020/validation-project';dest=stage/'work/outfit-eight-view-20261021';dest.mkdir(exist_ok=True)
for name in ['native_idle_review.gd','native_idle_review.tscn']:shutil.copyfile(b/name,dest/name)
shutil.copytree(b/'idle36-v2/compiled',dest/'idle36-v2/compiled')
for case in ['normal-v2','quarter-v2','negative-v2']:
 out=b/case;out.mkdir(exist_ok=False);cmd=[str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'),'--path',str(stage),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--resolution','1280x720','--log-file',str(out/'engine.log'),'res://work/outfit-eight-view-20261021/native_idle_review.tscn','--fixed-fps','20']
 if case!='negative-v2':cmd+=['--write-movie',str(out/'play.avi')]
 if case!='normal-v2':cmd+=['--','--quarter' if case=='quarter-v2' else '--one-pixel-negative']
 start=time.monotonic();p=run_validated_godot(stage,cmd,dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'progress.json')),180);log=p.stdout+p.stderr;(out/'result.log').write_text(log);data={'exit':p.returncode,'errors':log.count('ERROR:'),'seconds':round(time.monotonic()-start,2)};(out/'result.json').write_text(json.dumps(data,indent=2)+'\n');print(case,data,log[-450:],flush=True)
 if case=='negative-v2':assert p.returncode==1 and data['errors']==0 and 'REJECTED: actual rendered' in log
 else:assert p.returncode==0 and data['errors']==0 and 'PASS: native garment idle' in log
