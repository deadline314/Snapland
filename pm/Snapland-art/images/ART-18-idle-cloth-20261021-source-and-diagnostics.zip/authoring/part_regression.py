from pathlib import Path
import os,json,time,re
from tools.godot_entrypoints import run_validated_godot
from tools.run_game_tests import result_error
r=Path.cwd();b=r/'work/outfit-eight-view-20261021';stage=r/'work/tutorial-current-20261020/validation-project';source=stage/'tools/island_avatar/build_garment_layers.gd';fixed=source.read_text();guard='\tif not mesh_regions[side].has_point(Vector2i(floori(p.x),floori(p.y))):return false\n';assert guard in fixed
try:
 for case in ['part-before-v2','part-after-v2']:
  out=b/case;out.mkdir(exist_ok=False);text=fixed.replace(guard,'') if case=='part-before-v2' else fixed;source.write_text(text);(out/'authoring-source.gd.txt').write_text(text);cmd=[str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'),'--headless','--path',str(stage),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--script','res://game/tests/test_garment_part_ownership.gd'];start=time.monotonic();p=run_validated_godot(stage,cmd,dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'progress.json')),30);log=p.stdout+p.stderr;(out/'result.log').write_text(log);d={'exit':p.returncode,'errors':log.count('ERROR:'),'seconds':round(time.monotonic()-start,2)};(out/'result.json').write_text(json.dumps(d,indent=2)+'\n');print(case,d,log[-400:],flush=True)
  if case=='part-before-v2':assert p.returncode==1 and int(re.search(r'neighbor=(\d+)',log)[1])>0
  else:assert result_error('garment part ownership tests',p) is None
finally:source.write_text(fixed)
