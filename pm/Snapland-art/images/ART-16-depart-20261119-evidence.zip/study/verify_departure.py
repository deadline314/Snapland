"""Validate and record isolated stock-engine ART-16 launch paths."""
from concurrent.futures import ThreadPoolExecutor
import importlib.util
from pathlib import Path
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
helper = ROOT / ".review/cotton-wind-20261118/final-fix/native_run.py"
spec = importlib.util.spec_from_file_location("isolated_native", helper)
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
runner.QA = Path("D:/Snapland-QA/art16-20261119")

validate_run = runner.run_validated_godot
def godot_options_before_separator(staged, command, *args, **kwargs):
    if "--" in command and command[-2] == "--log-file":
        insert = command.index("--")
        command[insert:insert] = command[-2:]
        del command[-2:]
    return validate_run(staged, command, *args, **kwargs)
runner.run_validated_godot = godot_options_before_separator

ART_FILE = "assets/characters/announcer-departure-sides-v1.png"
FIXTURE = "game/tests/native_announcer_patrol_review"
TESTS = {
    "test_npc_departure_lifecycle": "PASS: planted NPC departure, pause, dialogue, interruption, stride restart, reduced motion and damaged-source fallback",
    "test_npc_authored_source_walking": "PASS: all three authored NPC routes display complete side poses and preserve independent personality actions",
    "test_character_animation_library": "PASS: character animation library checks",
}
runner.FIXTURES = [
    FIXTURE + ".gd", FIXTURE + ".tscn",
    "game/tests/native_authored_patrol_review.gd",
    "game/tests/native_island_animation_acceptance.gd",
    *["game/tests/" + name + ".gd" for name in TESTS],
]
paths = subprocess.check_output(["git","ls-files","-z"],cwd=ROOT,encoding="utf8").split("\0")
paths = list(dict.fromkeys([*paths, ART_FILE]))
fixtures = {name: runner.sha(ROOT/name) for name in runner.FIXTURES}

def stage(label, donor=None):
    base = runner.make_base(label)
    path = base / "project"
    path.mkdir()
    graph = runner.prepare_runtime_stage(ROOT,path,paths)
    for name,digest in fixtures.items():
        target=path/name
        target.parent.mkdir(exist_ok=True,parents=True)
        shutil.copy2(ROOT/name,target)
        assert runner.sha(target)==digest
        graph[name]=digest
    runner.dump(base/"source-graph.json",{
        "commit_base":runner.BASE, "source_raw_sha256":graph, "fixtures":runner.FIXTURES,
        "driver":runner.describe(Path(__file__)),
    })
    assert all(runner.sha(path/name)==sha for name,sha in graph.items())
    if donor is not None:
        runner.copy_imports(donor,path,graph)
    return base,path,graph

def run_test(item, donor):
    name,marker=item
    base,path,graph=stage(name,donor)
    command=[runner.ENGINE,"--headless","--path",path,"--script","res://game/tests/"+name+".gd"]
    receipt=runner.launch(base,path,graph,name,command,runner.environment(base))
    assert [sum(line==marker for line in (base/log).read_text(encoding="utf8").splitlines())
            for log in ("engine.log","stdout.log","stderr.log")] == [1,1,0]
    return base.as_posix()

def run_movie(mode, donor, binary=None, pinned=None):
    base,path,graph=stage("art16-"+mode,donor)
    opts={
        "normal":[], "quarter":["--quarter","--rebuild"],
        "reduced":["--reduced-motion","--rebuild"], "embedded":[],
    }[mode]
    movie=base/"capture.avi"
    out=base/"captures"
    project=[runner.ENGINE,"--path",path,"res://"+FIXTURE+".tscn"]
    if binary:
        runner.qa_override(path,pinned)
        build=runner.read(binary.parent.parent/"build.json")
        assert runner.sha(binary)==build["binary"]["sha256"]
        assert all(runner.sha(path/name)==sha for name,sha in build["runtime_sha256"].items())
        project=[binary]
    command=[*project,"--rendering-method","gl_compatibility","--audio-driver","Dummy",
             "--fixed-fps","30","--write-movie",movie,"--",
             "--actor=announcer","--actions-only","--animation-output="+out.as_posix(),*opts]
    runner.launch(base,path,graph,mode,command,runner.environment(base),binary.parent if binary else None)
    report=runner.read(out/"announcer-report.json")
    assert report["technical_status"]=="PASS" and not report["failures"]
    if mode != "reduced":
        detail=report["grounded_announcer_patrol"]
        assert set(map(int,detail["depart_seen"]["right"])) == set(range(5))
        assert set(map(int,detail["depart_seen"]["left"])) == set(range(5))
        assert detail["maximum_departure_root_drift"] == 0 and detail["source_consistent"]
    assert report['playback_mode'].startswith("quarter" if mode=="quarter" else "normal")
    assert report["reduced_motion"] == (mode=="reduced")
    assert movie.stat().st_size > 0
    print(base.as_posix(),flush=True)
    return base

def export_and_launch(donor):
    base,path,graph=stage("art16-export",donor)
    pinned=runner.templates(base)
    runner.SCENE=FIXTURE+".tscn"
    runner.qa_override(path,pinned)
    release=base/"release"
    release.mkdir()
    binary=release/"AnnouncerDepartureQA.exe"
    runner.launch(base,path,graph,"export",
                  [runner.ENGINE,"--headless","--path",path,"--editor","--export-release","Windows Desktop",binary,"--quit"],
                  runner.environment(base))
    assert binary.stat().st_size>pinned["release"]["bytes"] and not list(release.glob("*.pck"))
    runner.dump(base/"build.json",{
        "binary":runner.describe(binary),"templates":pinned,"source":runner.describe(base/"source-graph.json"),
        "runtime_sha256":runner.read(base/"runtime-graph.json"),
        "export":runner.describe(base/"receipt.json"),
        "normal_main":runner.describe(ROOT/"project.godot"),"normal_export":runner.describe(ROOT/"export_presets.cfg"),
    })
    launched=run_movie("embedded",donor,binary,pinned)
    runner.dump(base/"embedded-acceptance.json",{"build":runner.describe(base/"build.json"),"launch":runner.describe(launched/"receipt.json")})

if __name__=="__main__":
    if sys.argv[1]=="import":
        base,path,graph=stage("art16-donor")
        runner.launch(base,path,graph,"import",[runner.ENGINE,"--headless","--path",path,"--editor","--import","--quit"],runner.environment(base))
        runner.collect_imports(base,path,graph)
        print(base.as_posix(),flush=True)
    elif sys.argv[1]=="tests":
        donor=Path(sys.argv[2])
        with ThreadPoolExecutor(max_workers=2) as pool:
            print(list(pool.map(lambda item: run_test(item,donor),TESTS.items())),flush=True)
    elif sys.argv[1]=="package":
        export_and_launch(Path(sys.argv[2]))
    else:
        run_movie(sys.argv[1],Path(sys.argv[2]))
