"""Compare candidate cel registration on the exact authored 320x460 canvas.

Only reads source pixels and writes numeric study results.
"""
import json
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
ASSETS = ROOT / "assets/characters"
ACTOR = json.loads((ASSETS/"complete-animation-regions.json").read_text("utf8"))["actors"]["announcer"]
AREAS = [(132,448),(132,275),(275,365),(365,448)]

def cropped(d):
    x,y,w,h = d["region"]
    path = ROOT / d["source"].removeprefix("res://")
    return Image.open(path).convert("RGBA").crop((x,y,x+w,y+h))

def canvas(img, scale, fx, fy):
    size = (round(img.width*scale),round(img.height*scale))
    out = np.zeros((460,320,4),dtype=np.uint8)
    x = round(160-fx*scale)
    y = 448-round(fy*scale)
    assert x >= 0 and y >= 0 and x+size[0] <= 320 and y+size[1] <= 460
    out[y:y+size[1],x:x+size[0],:] = np.array(img.resize(size,Image.Resampling.NEAREST))
    return out

def distance(first,second):
    alpha1,alpha2 = first[:,:,3]>=128,second[:,:,3]>=128
    union = alpha1 | alpha2
    silhouette_change = np.logical_xor(alpha1,alpha2)
    color_change = np.max(np.abs(first[:,:,:3].astype(np.int16)-second[:,:,:3]),axis=2)>30
    different = silhouette_change | (alpha1 & alpha2 & color_change)
    return [round(float(different[lo:hi].sum()/union[lo:hi].sum()),4) for lo,hi in AREAS]

def compare(part,stand,walk,left,top,height,head_y,feet_y):
    candidates = []
    baseline = distance(stand,walk)
    for target_h in range(303,315):
        for fx in range(122,205,2):
            cel = canvas(part,target_h/height,fx,feet_y-top)
            lengths = [distance(stand,cel),distance(cel,walk)]
            max_by_area = [max(first,second) for first,second in zip(*lengths,strict=True)]
            score = sum(val * weight for val,weight in zip(max_by_area,(2,1,1,1),strict=True))
            d = {"region":[left,top,part.width,part.height],"source_scale":target_h/(2*height),
                 "feet":[fx,feet_y-top],"head_y":head_y-top,"change":lengths,"max_by_area":max_by_area,"score":round(score,4)}
            if all(value <= old for value,old in zip(max_by_area,baseline,strict=True)):
                candidates.append(d)
    return sorted(candidates,key=lambda item:item["score"])[:5]

report={}
for direction,j in [("right",0),("left",1)]:
    d = ACTOR["depart"][direction]["frames"][-1]
    stand = canvas(cropped(d),d["source_scale"]*2,*d["anchors"]["feet"])
    walk = np.array(Image.open(ASSETS/f"walk-stability-v1/announcer-walk-{direction}.png").convert("RGBA").crop((0,0,320,460)))
    report[direction] = {"stand_to_walk":distance(stand,walk)}
    for no in [2,3,4]:
        img=Image.open(HERE/f"announcer-departure-candidate-{no:02}.png").convert("RGBA")
        boundaries=[0,img.width//2,img.width]
        cell=img.crop((boundaries[j],0,boundaries[j+1],img.height))
        x0,y0,x1,y1=cell.getchannel("A").point(lambda a:255 if a>=32 else 0).getbbox()
        _,t,_,b=cell.getchannel("A").point(lambda a:255 if a>=128 else 0).getbbox()
        x=x0+boundaries[j]-8
        y=y0-8
        part=img.crop((x,y,x1+boundaries[j]+8,y1+8))
        report[direction][f"candidate_{no}"]=compare(part,stand,walk,x,y,b-t,t,b)
for side,data in report.items():
    print(side,data["stand_to_walk"])
    for key in ("candidate_2","candidate_3","candidate_4"): print(key, data[key][:1])
(HERE/"contact-study.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf8")
