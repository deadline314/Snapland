extends SceneTree
func _initialize():
 var library=preload('res://game/world/character_animation_library.gd').new()
 library.texture('announcer','walk','right',0).get_image().save_png('C:/Users/stanl/Github/Snapland/.review/announcer-walk8-20261112/reference-right.png')
 library.texture('announcer','idle','front',0).get_image().save_png('C:/Users/stanl/Github/Snapland/.review/announcer-walk8-20261112/reference-front.png')
 quit()
