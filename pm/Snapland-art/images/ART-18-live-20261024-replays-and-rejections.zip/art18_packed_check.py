from pathlib import Path
import shutil,os,json,time,subprocess
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();out=r/'work/remaining-20261024/art18-packed-overlay';out.mkdir(exist_ok=False);audit=out/'audit';audit.mkdir()
shutil.copy2(r/'project.godot',audit/'project.godot');shutil.copy2(r/'game/tests/test_garment_overlay.gd',audit/'check.gd')
assert sorted(p.name for p in audit.iterdir())==['check.gd','project.godot']
engine=r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64';binary=r/'work/remaining-20261024/release-art18-overlay/release/Snapland.x86_64'
cmd=[str(engine),'--headless','--path',str(audit),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--main-pack',str(binary),'--script',str(audit/'check.gd')]
t=time.monotonic()
try:p=run_validated_godot(audit,cmd,dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'save/progress.json')),90);log=p.stdout+p.stderr;code=p.returncode
except subprocess.TimeoutExpired as e:log=(e.stdout or '')+(e.stderr or '');code=124
(out/'result.log').write_text(log);d={'exit':code,'seconds':round(time.monotonic()-t,2),'errors':log.count('ERROR:'),'scope':'Pinned editor engine loading actual embedded PCK; audit has only project.godot and external test, no loose player scripts or art. Not a native release boot.'};(out/'result.json').write_text(json.dumps(d,indent=2));print(d);print(log[-4500:])
