from pathlib import Path
import os,json,shutil,time,subprocess,sys
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();stage=r/'work/tutorial-current-20261020/validation-project';out=r/('work/remaining-20261024/art18-world-'+sys.argv[1]);out.mkdir(exist_ok=False)
engine=str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64');cmd=[engine,'--path',str(stage),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--resolution','1280x720','res://work/remaining-20261024/art18_world.tscn','--']+(['--quarter'] if sys.argv[1]=='quarter' else [])
t=time.monotonic()
try:p=run_validated_godot(stage,cmd,dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'save/progress.json')),300);log=p.stdout+p.stderr;code=p.returncode
except subprocess.TimeoutExpired as e:log=(e.stdout or '')+(e.stderr or '');code=124
(out/'result.log').write_text(log);result={'exit':code,'seconds':round(time.monotonic()-t,2),'errors':log.count('ERROR:')};(out/'result.json').write_text(json.dumps(result,indent=2));print(result);print(log[-3500:])
