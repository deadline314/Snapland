from pathlib import Path
import json,shutil,hashlib
r=Path.cwd();a=r/'work/remaining-20261024/art18-ownership';dest=r/'assets/characters/rainvest-v1';dest.mkdir(exist_ok=False)
rows=json.loads((a/'bake-v20/bake-report.json').read_text())['frames'];manifest={'schema_version':1,'outfit':'outfit-rainvest','canvas':[280,360],'frames':[]}
for row in rows:
 key=f"{row['action']}-{row['direction']}-{row['frame']:02}"
 src=a/'bake-v20/compiled'/f'{key}-garment.png';shutil.copy2(src,dest/(key+'.png'))
 manifest['frames'].append({k:row[k] for k in ['action','direction','frame','source_kind','source_pixel_sha256']}|{'path':'res://assets/characters/rainvest-v1/'+key+'.png','png_sha256':hashlib.sha256(src.read_bytes()).hexdigest()})
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
