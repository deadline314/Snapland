from pathlib import Path
import json,hashlib,zipfile,shutil,subprocess
r=Path.cwd();a=r/'work/remaining-20261024/art18-ownership';images=r/'pm/Snapland-art/images';prefix='ART-18-full-source-20261024-'
files=[]
def copy(src,name):
 dst=images/(prefix+name);shutil.copy2(src,dst);files.append(dst)
for name in ['coverage.json','bake-report.json','result.json','engine.log']:
 p=a/'bake-v20'/name
 if p.exists():copy(p,name)
for name in ['legacy-parity.json','tool-parity.json']:copy(a/name,name)
copy(r/'work/remaining-20261024/art18-authoring-checks/results.json','ownership-results.json')
copy(r/'work/remaining-20261024/art18-authoring-checks/garment-part-ownership-tests.log','ownership.log')
for p in sorted(a.glob('v20-*.jpg')):copy(p,p.name)
p=subprocess.run(['python','-m','unittest','discover','-s','tests','-p','test_garment_manifest.py','-v'],capture_output=True,text=True);assert p.returncode==0
log=images/(prefix+'python-23.log');log.write_text(p.stdout+p.stderr);files.append(log)
archive=images/(prefix+'source-and-diagnostics.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in a.rglob('*'):
  if p.is_file() and p.suffix in ['.py','.json','.txt','.png','.log'] and not any(part.startswith('bake-v') and part!='bake-v20' for part in p.parts):z.write(p,p.relative_to(a))
 for p in (r/'work/remaining-20261024/art18-fallback').rglob('*'):
  if p.is_file() and p.suffix in ['.py','.gd','.json','.png','.log']:z.write(p,Path('legacy-fallback')/p.relative_to(r/'work/remaining-20261024/art18-fallback'))
files.append(archive)
manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files};(images/(prefix+'manifest.json')).write_text(json.dumps(manifest,indent=2)+'\n')
print(len(files),'files; zip',archive.stat().st_size)
