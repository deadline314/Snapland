from pathlib import Path
import os,subprocess,json
r=Path.cwd();out=r/'work/remaining-20261024/art18-quarter-recording';out.mkdir(exist_ok=False)
rec=subprocess.Popen(['ffmpeg','-n','-v','error','-f','x11grab','-video_size','1280x720','-framerate','15','-i',os.environ['DISPLAY'],'-t','300','-c:v','libx264','-threads','1','-preset','ultrafast','-crf','22','-pix_fmt','yuv420p',str(out/'native.mp4')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
try:
 p=subprocess.run(['python','work/remaining-20261024/art18_native.py','quarter'],check=False);code=p.returncode
finally:
 _,err=rec.communicate('q\n',timeout=20);(out/'record.log').write_text(err)
print({'driver_exit':code,'recorder_exit':rec.returncode})
