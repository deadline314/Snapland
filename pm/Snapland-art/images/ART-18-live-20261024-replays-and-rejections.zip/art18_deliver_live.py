from pathlib import Path
import shutil,json,zipfile,hashlib
r=Path.cwd();b=r/'work/remaining-20261024';dest=r/'pm/Snapland-art/images';prefix='ART-18-live-20261024-';files=[]
def copy(source,name):
 p=dest/(prefix+name);shutil.copy2(b/source,p);files.append(p)
for directory,tag in [('art18-overlay-check-v4','source'),('art18-packed-overlay-final','pack'),('art18-native-normal-final','normal'),('art18-native-quarter','quarter'),('art18-world-normal','world'),('release-art18-smoke-final','release')]:
 for name in ['result.json','result.log']:
  copy(f'{directory}/{name}',f'{tag}-{name}')
for name in ['build.json','import.log','export.log']:copy('release-art18-final-v2/'+name,'linux-'+name)
for name,tag in [('art18-overlay-regressions/results.json','regressions.json'),('art18-wardrobe-checks-v2/results.json','wardrobe.json'),('art18-main-checks/results.json','main-checks.json'),('art18-payload-parity.json','payload-parity.json'),('art18-python-full.log','python-159.log'),('art18-design-all.log','design-all.log'),('art18-quarter-recording/native.mp4','quarter.mp4'),('art18-quarter-recording/video.json','quarter-video.json'),('art18-native-normal-final/save/render-report.json','normal-172.json'),('art18-native-quarter/save/render-report.json','quarter-172.json'),('art18-world-normal/save/observations.json','world-inputs.json')]:copy(name,tag)
copy('art18-final-pck-parity.json','final-pck-parity.json')
copy('release-art18-smoke-final/video.json','release-video.json')
copy('release-art18-smoke-final/video-samples.jpg','release-video-samples.jpg')
copy('release-art18-smoke-final/actual-release.mp4','release.mp4')
copy('release-art18-smoke-final/profile/art-smoke-game-005.png','release-rainvest.png')
for p in sorted((b/'release-art18-smoke-final').glob('review-*.jpg')):copy(str(p.relative_to(b)),'release-'+p.name)
for p in sorted((b/'art18-native-normal-final').glob('review-*.jpg')):copy(str(p.relative_to(b)),p.name)
for p in sorted((b/'art18-world-normal/save').glob('*.png')):copy(str(p.relative_to(b)),'world-'+p.name)
for tag in ['normal-final','quarter']:
 archive=dest/(prefix+tag+'-raw-captures.zip')
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
  for p in sorted((b/('art18-native-'+tag)/'save/captures').glob('*.png')):z.write(p,p.name)
 files.append(archive)
archive=dest/(prefix+'replays-and-rejections.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in list(b.glob('art18*'))+list(b.glob('release_art18*.py')):
  if p.is_file() and p.suffix in ['.py','.gd','.json']:z.write(p,p.name)
 for directory in ['art18-overlay-check-v1','art18-overlay-check-v2','art18-packed-overlay','art18-native-normal','release-art18-smoke','art18-overlay-regressions','art18-main-checks','art18-wardrobe-checks','art18-wardrobe-checks-v2']:
  for p in (b/directory).glob('*'):
   if p.is_file() and p.suffix in ['.json','.log']:z.write(p,p.relative_to(b))
 for directory in ['art18-quarter-recording','release-art18-smoke-final']:
  for p in (b/directory).glob('sample-*.png'):z.write(p,p.relative_to(b))
files.append(archive)
manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files};(dest/(prefix+'manifest.json')).write_text(json.dumps(manifest,indent=2)+'\n');print(len(files),'evidence files')
