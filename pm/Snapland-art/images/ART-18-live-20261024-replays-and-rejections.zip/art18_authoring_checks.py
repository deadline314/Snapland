from pathlib import Path
import ast,os,json,time
from tools.godot_entrypoints import run_validated_godot
from tools.run_game_tests import result_error
r=Path.cwd();stage=r/'work/tutorial-current-20261020/validation-project';out=r/'work/remaining-20261024/art18-authoring-checks';out.mkdir(exist_ok=False);engine=str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64');common=[engine,'--headless','--path',str(stage),'--audio-driver','Dummy','--rendering-method','gl_compatibility'];tree=ast.parse((r/'tools/run_game_tests.py').read_text());n=next(n for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='checks' for t in n.targets));checks=eval(compile(ast.Expression(n.value),'<official>','eval'),{'common':common,'executable':engine,'ROOT':stage,'str':str});names={'garment part ownership tests'};result=[]
for name,cmd in checks:
 if name not in names:continue
 t=time.monotonic();p=run_validated_godot(stage,cmd,dict(os.environ,SNAPLAND_SAVE_PATH=str(out/name.replace(' ','-')/'progress.json')),90);s=p.stdout+p.stderr;(out/(name.replace(' ','-')+'.log')).write_text(s);d=dict(name=name,exit=p.returncode,error=result_error(name,p),seconds=round(time.monotonic()-t,2));result.append(d);(out/'results.json').write_text(json.dumps(result,indent=2));print(d,flush=True)
 if d['error']:raise SystemExit(1)
