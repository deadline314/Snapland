from pathlib import Path
import os,json,shutil,time,subprocess,sys
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();stage=r/'work/tutorial-current-20261020/validation-project';out=r/('work/remaining-20261024/art18-native-'+sys.argv[1]);out.mkdir(exist_ok=False)
for name in ['game/world/avatar_renderer.gd','game/world/garment_overlay_library.gd','work/remaining-20261024/art18_native.gd']:
 dest=stage/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/name,dest)
scene=stage/'work/remaining-20261024/art18_native.tscn';scene.write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://work/remaining-20261024/art18_native.gd" id="1"]\n[node name="Review" type="Node2D"]\nscript = ExtResource("1")\n')
engine=str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64');cmd=[engine,'--path',str(stage),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--resolution','1280x720','res://work/remaining-20261024/art18_native.tscn','--']+(['--quarter'] if sys.argv[1]=='quarter' else [])
t=time.monotonic()
try:p=run_validated_godot(stage,cmd,dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'save/progress.json')),300);log=p.stdout+p.stderr;code=p.returncode
except subprocess.TimeoutExpired as e:log=(e.stdout or '')+(e.stderr or '');code=124
(out/'result.log').write_text(log);result={'exit':code,'seconds':round(time.monotonic()-t,2),'errors':log.count('ERROR:')};(out/'result.json').write_text(json.dumps(result,indent=2));print(result);print(log[-3500:])
