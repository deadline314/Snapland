extends "res://game/tests/native_review.gd"
var folder := ""
var observations: Array = []
func _run() -> void:
	var profile := OS.get_environment("SNAPLAND_SAVE_PATH")
	if not profile.is_absolute_path() or DisplayServer.get_name()=="headless":get_tree().quit(2);return
	folder=profile.get_base_dir();DirAccess.make_dir_recursive_absolute(folder)
	progress=get_tree().root.get_node("Progress")
	progress.reset_progress();progress.intro_seen=true
	main=_instantiate_main();get_tree().root.add_child(main)
	await get_tree().create_timer(1.0).timeout
	var coins: int=progress.coins
	_key(KEY_C);await get_tree().create_timer(0.2).timeout
	if not await _named_button("Tab_closet"):return
	if not await _named_button("WardrobeItem_outfit-rainvest"):return
	if not await _take("01-fitting"):return
	if progress.equipped.outfit!="outfit-tide":await _fail("Fitting saved before Wear");return
	if not await _named_button("WearSelected"):return
	if progress.equipped.outfit!="outfit-rainvest" or progress.coins!=coins:await _fail("Free rainvest could not be worn");return
	_key(KEY_ESCAPE);await get_tree().create_timer(0.2).timeout
	for keys in [[KEY_W],[KEY_W,KEY_D],[KEY_D],[KEY_D,KEY_S],[KEY_S],[KEY_S,KEY_A],[KEY_A],[KEY_A,KEY_W]]:
		for key in keys:_held_key(key,true)
		await get_tree().create_timer(0.35).timeout
		if not await _take("02-walking-%02d"%observations.size()):return
		for key in keys:_held_key(key,false)
		await get_tree().create_timer(0.12).timeout
	main._show_settings();await get_tree().create_timer(0.2).timeout
	if not await _named_button("SettingsTab_play"):return
	if not await _named_button("Value_reduced_motion"):return
	if not progress.settings.reduced_motion or not main.world.reduced_motion:await _fail("Actual reduced-motion checkbox not applied");return
	if not await _take("03-reduced-settings"):return
	_key(KEY_ESCAPE);await get_tree().create_timer(0.15).timeout
	main.world.play_action("wave")
	await get_tree().create_timer(0.4).timeout
	var reduced_frame: int=main.world.last_avatar_frame
	if not await _take("04-reduced-wave"):return
	await get_tree().create_timer(0.3).timeout
	if reduced_frame!=main.world.last_avatar_frame:await _fail("Reduced-motion action advanced frames");return
	_key(KEY_C);await get_tree().create_timer(0.2).timeout
	if not await _named_button("Tab_closet"):return
	if not await _named_button("WardrobeItem_outfit-tide"):return
	if not await _named_button("WearSelected"):return
	if progress.equipped.outfit!="outfit-tide":await _fail("Original jacket cannot be restored");return
	if not await _named_button("WardrobeItem_outfit-rainvest"):return
	if not await _named_button("WearSelected"):return
	_key(KEY_ESCAPE);await get_tree().create_timer(0.15).timeout
	progress.load_progress()
	if progress.equipped.outfit!="outfit-rainvest" or progress.coins!=coins:await _fail("Saved outfit or currency changed on reload");return
	if not await _take("05-reentry"):return
	FileAccess.open(folder.path_join("observations.json"),FileAccess.WRITE).store_string(JSON.stringify(observations,"  "))
	print("PASS: native free rainvest fitting, explicit Wear, eight movement inputs, reduced-motion checkbox, original jacket return and saved reload")
	await main._quit_game()
func _take(label: String) -> bool:
	await RenderingServer.frame_post_draw
	var image:=get_viewport().get_texture().get_image()
	var path:=folder.path_join(label+".png")
	if image.get_size()!=Vector2i(1280,720) or FileAccess.file_exists(path) or image.save_png(path)!=OK:await _fail("Cannot save fresh native clothing evidence");return false
	observations.append({"label":label,"direction":main.world.last_avatar_direction,"action":main.world.last_avatar_action,"frame":main.world.last_avatar_frame,"equipped":progress.equipped.duplicate(),"reduced_motion":main.world.reduced_motion,"position":[main.world.player.position.x,main.world.player.position.z]})
	return true
