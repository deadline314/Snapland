from pathlib import Path
import shutil,os,json,time
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();stage=r/'work/tutorial-current-20261020/validation-project';out=r/'work/remaining-20261024/art18-overlay-check-v4';out.mkdir(exist_ok=False)
for name in ['game/world/avatar_renderer.gd','game/world/garment_overlay_library.gd','game/tests/test_garment_overlay.gd']:
 shutil.copy2(r/name,stage/name)
shutil.copytree(r/'assets/characters/rainvest-v1',stage/'assets/characters/rainvest-v1',dirs_exist_ok=True)
engine=str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64')
import subprocess
t=time.monotonic()
try:
 p=run_validated_godot(stage,[engine,'--headless','--path',str(stage),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--script','res://game/tests/test_garment_overlay.gd'],dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'save/progress.json')),90)
 s=p.stdout+p.stderr;exitcode=p.returncode
except subprocess.TimeoutExpired as e:
 s=(e.stdout or '')+(e.stderr or '');exitcode=124
(out/'result.log').write_text(s);d={'exit':exitcode,'seconds':round(time.monotonic()-t,2),'errors':s.count('ERROR:')};(out/'result.json').write_text(json.dumps(d,indent=2));print(d);print(s[-9000:])
