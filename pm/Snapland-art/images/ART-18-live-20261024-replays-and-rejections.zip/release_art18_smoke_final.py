from pathlib import Path
import os,time,json,subprocess
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();b=r/'work/remaining-20261024';out=b/'release-art18-smoke-final';out.mkdir(exist_ok=False);binary=b/'release-art18-final-v2/release/Snapland.x86_64'
import shutil
(out/'profile').mkdir()
shutil.copy2(b/'art18-world-normal/save/progress.json',out/'profile/progress.json')
rec=subprocess.Popen(['ffmpeg','-n','-v','error','-f','x11grab','-video_size','1280x720','-framerate','15','-i',os.environ['DISPLAY'],'-t','150','-c:v','libx264','-threads','2','-preset','ultrafast','-crf','22','-pix_fmt','yuv420p',str(out/'actual-release.mp4')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
t=time.monotonic()
try:
 p=run_validated_godot(r,[str(binary),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--resolution','1280x720','--position','0,0','--log-file',str(out/'engine.log'),'--','--smoke-test','--smoke-art'],dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'profile/progress.json')),120,release_directory=binary.parent)
finally:
 _,err=rec.communicate('q\n',timeout=15);(out/'record.log').write_text(err)
s=p.stdout+p.stderr;(out/'result.log').write_text(s);d=dict(exit=p.returncode,errors=s.count('ERROR:'),seconds=round(time.monotonic()-t,2),completion='PASS: art resources loaded (props=16, scenes=4, foliage=8)' in s);(out/'result.json').write_text(json.dumps(d,indent=2)+'\n');print(d,s[-1500:],flush=True);assert p.returncode==0 and d['errors']==0 and d['completion']

payload=json.loads((out/"profile/progress.json").read_text());assert payload["equipped"]["outfit"]=="outfit-rainvest" and payload["coins"]==120
print("PASS: actual cold release retained free rainvest, reduced motion and currency")
