extends Node2D
const Avatar = preload("res://game/world/avatar_renderer.gd")
var avatar = Avatar.new()
var poses: Array = []
var cursor := 0
var elapsed := 0.0
var pending := false
var captured := false
var textures: Array[Texture2D] = []
var records: Array = []
var folder := ""
var stopping := false
var style := {}
func _ready() -> void:
	var profile := OS.get_environment("SNAPLAND_SAVE_PATH")
	if not profile.is_absolute_path() or DisplayServer.get_name()=="headless":get_tree().quit(2);return
	folder=profile.get_base_dir();DirAccess.make_dir_recursive_absolute(folder.path_join("captures"))
	Engine.time_scale=0.25 if OS.get_cmdline_user_args().has("--quarter") else 1.0
	texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	var manifest: Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://assets/characters/rainvest-v1/manifest.json"))
	poses=manifest.frames
	if not avatar.garment_overlays.ready(avatar):push_error(str(avatar.garment_overlays.diagnostics));get_tree().quit(1);return
	_next()
func _next() -> void:
	textures.clear();elapsed=0.0;captured=false
	var row: Dictionary=poses[cursor]
	style=Avatar.DEFAULT_APPEARANCE.duplicate()
	style["hair"]="bob" if cursor%2==0 else "curly"
	style["hair_color"]="silver" if cursor%2==0 else "chestnut"
	style["skin"]="deep" if cursor%2==0 else "olive"
	for appearance in [Avatar.DEFAULT_APPEARANCE,style]:
		for outfit in ["outfit-tide","outfit-rainvest"]:
			textures.append(avatar.texture(appearance,{"outfit":outfit,"hat":"hat-none"},row.direction,int(row.frame),row.action))
	queue_redraw()
func _process(delta: float) -> void:
	if stopping or textures.size()!=4:return
	elapsed+=delta;queue_redraw()
	if not captured and not pending:_shot()
	if elapsed<0.125 or not captured or pending:return
	cursor+=1
	if cursor<poses.size():_next();return
	stopping=true
	FileAccess.open(folder.path_join("render-report.json"),FileAccess.WRITE).store_string(JSON.stringify(records,"  "))
	print("PASS: native garment overlay 172 actual requests, default and alternate hair palettes, exact unchanged non-cloth pixels")
	get_tree().quit()
func _draw() -> void:
	draw_rect(Rect2(0,0,1280,720),Color("#153c47"))
	if textures.size()!=4 or cursor>=poses.size():return
	var row: Dictionary=poses[cursor]
	draw_string(ThemeDB.fallback_font,Vector2(35,65),"ART-18 / pure clothing integration / %s %s %02d"%[row.action,row.direction,row.frame],HORIZONTAL_ALIGNMENT_LEFT,-1,24,Color.WHITE)
	for i in 4:
		var x:=30+i*310
		draw_texture(textures[i],Vector2(x,190))
		draw_string(ThemeDB.fallback_font,Vector2(x,155),"Original" if i%2==0 else "Rain vest",HORIZONTAL_ALIGNMENT_LEFT,-1,20,Color.WHITE)
		draw_line(Vector2(x,536),Vector2(x+280,536),Color("#a5ad83"))
	draw_string(ThemeDB.fallback_font,Vector2(35,610),"1:1 pixels / same original body and head anchors / clothing only",HORIZONTAL_ALIGNMENT_LEFT,-1,22,Color.WHITE)
	draw_string(ThemeDB.fallback_font,Vector2(35,652),"Quarter-time" if Engine.time_scale<1.0 else "Normal time",HORIZONTAL_ALIGNMENT_LEFT,-1,20,Color.WHITE)
func _shot() -> void:
	pending=true
	await RenderingServer.frame_post_draw
	var screen:=get_viewport().get_texture().get_image()
	if screen.get_size()!=Vector2i(1280,720):push_error("Wrong native window dimensions");get_tree().quit(1);return
	var row: Dictionary=poses[cursor]
	var cloth:=Image.new();cloth.load_png_from_buffer(FileAccess.get_file_as_bytes(row.path))
	var changed_outside:=0
	for pair in 2:
		var a: Image=textures[pair*2].get_image()
		var b: Image=textures[pair*2+1].get_image()
		for y in 360:
			for x in 280:
				if cloth.get_pixel(x,y).a==0.0 and a.get_pixel(x,y)!=b.get_pixel(x,y):changed_outside+=1
	var dest:=folder.path_join("captures/%03d-%s-%s-%02d.png"%[cursor,row.action,row.direction,row.frame])
	if FileAccess.file_exists(dest) or screen.save_png(dest)!=OK:push_error("Capture cannot be saved");get_tree().quit(1);return
	records.append({"action":row.action,"direction":row.direction,"frame":row.frame,"source_kind":row.source_kind,"time_scale":Engine.time_scale,"outside_cloth_changes":changed_outside,"style":style})
	if changed_outside>0:push_error("Clothing integration moved or recolored non-cloth pixels");get_tree().quit(1);return
	captured=true;pending=false
