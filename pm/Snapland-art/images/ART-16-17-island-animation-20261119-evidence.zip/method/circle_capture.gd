extends "res://game/tests/native_island_animation_acceptance.gd"

const TOUR := [
	["back",[KEY_W]],["back_right",[KEY_W,KEY_D]],["right",[KEY_D]],["front_right",[KEY_D,KEY_S]],
	["front",[KEY_S]],["front_left",[KEY_S,KEY_A]],["left",[KEY_A]],["back_left",[KEY_A,KEY_W]],
]

func _hero_actions() -> void:
	var previous: Dictionary = _world.avatar_appearance.duplicate()
	for style in ["windswept","curly"]:
		var look := previous.merged({"hair":style},true)
		var outfit := {"outfit":"outfit-tide" if style=="windswept" else "outfit-rainvest",
			"hat":"hat-none" if style=="windswept" else "hat-straw"}
		_world.set_avatar_look(look,outfit)
		var point := Vector3(-2.5,0,-14.5)
		point.y = _world.ground_surface_y(point)
		_world.player.global_position=point
		await _physics_frames(8)
		var held: Array = []
		for turn in TOUR:
			var direction: String = turn[0]
			var keys: Array = turn[1]
			var continuing := not held.is_empty()
			for key in held:
				if key not in keys: _press(key,false)
			for key in keys:
				if key not in held: _press(key,true)
			held=keys
			var started := _simulated_seconds
			var frames := {}
			var appeared := false
			var grounded := true
			var kept_walking := true
			var source := true
			var anchor := _actor_anchor()
			while _simulated_seconds-started<0.42 and _within_budget():
				await RenderingServer.frame_post_draw
				var expected: bool = _world.facing==direction and _world.last_avatar_direction==direction
				if continuing or appeared:
					grounded = grounded and _world.player.is_on_floor()
					kept_walking = kept_walking and _world.avatar_is_walking
				if expected and _world.last_avatar_source_action=="walk":
					appeared = true
					grounded = grounded and _world.player.is_on_floor()
					source = source and _hero_sprite_source_consistent()
					var cel: int = _world.last_avatar_frame
					if not frames.has(cel):
						frames[cel]=true
						if frames.size()==2:
							_store_capture(style+"-"+direction,get_viewport().get_texture().get_image())
			var complete: bool = frames.size()>1 and source and grounded and kept_walking and _actor_anchor()!=anchor
			await _record_action("continuous-"+style+"-"+direction,"walk",direction,"authored",_actor_anchor(),complete,
				{"grounded":grounded,"kept_walking":kept_walking,"sources_match":source,"cels":frames.keys()})
		for key in held: _press(key,false)
		var halt := await _wait_hero_settle()
		await _record_action("settled-"+style,"idle",String(_world.facing),"authored",_actor_anchor(),bool(halt.complete),halt)
