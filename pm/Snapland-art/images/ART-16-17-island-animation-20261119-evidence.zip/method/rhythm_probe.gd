extends SceneTree
const World = preload("res://game/world/park_world.gd")
const Activity = preload("res://game/world/npc_activity.gd")
const Timing = preload("res://game/world/character_animation_library.gd").AnimationTiming
const BLINKS := {"ticket":3,"imp":2,"announcer":3}

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var world := World.new()
	root.add_child(world)
	var first_blink := {}
	var role_actions := {}
	var false_waves := 0
	for tick in range(1800):
		await process_frame
		for record in world.npc_activity._records:
			var role := String(record.role)
			if not BLINKS.has(role): continue
			if not role_actions.has(role): role_actions[role] = {}
			var action := String(record.action)
			role_actions[role][action] = true
			if action == "greet": false_waves += 1
			if action not in ["stand","idle"] or first_blink.has(role): continue
			var phase: float = float(record.action_elapsed) * Activity.breath_tempo(role)
			if Timing.frame_at_time(record.action_sequence, phase)==BLINKS[role]:
				first_blink[role] = tick
	var distinct := {}
	var tempo := {}
	for role in BLINKS:
		if not first_blink.has(role):
			push_error("missing authored idle blink on " + role)
			quit(1)
			return
		distinct[first_blink[role]] = true
		tempo[role] = world.npc_activity.breath_cycle_seconds(role)
	if distinct.size()!=BLINKS.size() or false_waves!=0:
		push_error("idle blink synchronization or an unrequested wave")
		quit(1)
		return
	var output := FileAccess.open(OS.get_environment("COTTON_CAPTURE_DIR").path_join("rhythm.json"),FileAccess.WRITE)
	output.store_string(JSON.stringify({"first_blink_ticks":first_blink,"breath_cycles_seconds":tempo,
		"observed_actions":role_actions,"greet_without_player_input":false_waves,"fixed_process_fps":60},"  "))
	output.close()
	world.queue_free()
	await process_frame
	print("PASS: three live island actors keep distinct idle rhythm")
	quit()
