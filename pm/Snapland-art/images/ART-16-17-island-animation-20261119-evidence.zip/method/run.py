"""Run the full production-connected character acceptance fixture."""
import sys
from pathlib import Path

here=Path(__file__).resolve().parent
base=here.parent/"art16-longitudinal-pivot-study-20261119/verify.py"
text=base.read_text("utf8")
start=text.index('FIXTURE="game/tests/native_avatar_depth_pivot_study"')
stop=text.index('def stage(',start)
text=text[:start]+'''FIXTURE="game/tests/native_island_animation_acceptance"
fixtures={FIXTURE+ext:ROOT/(FIXTURE+ext) for ext in (".gd",".tscn")}
runner.FIXTURES=list(fixtures)


'''+text[stop:]
text=text.replace('folder=runner.make_base("depth-"+label)','folder=runner.make_base("suite-"+label)')
text=text.replace('def record(mode,donor,binary=None,pinned=None):','def record(mode,donor,binary=None,pinned=None):')
text=text.replace('["--actor=traveller","--actions-only",','["--actor="+ROLE,"--idle-only" if mode=="idle" else "--actions-only",')
text=text.replace('"--","--actor=traveller","--actions-only",','"--","--actor="+ROLE,"--idle-only" if mode=="idle" else "--actions-only",')
text=text.replace('"normal":[],"quarter"','"normal":[],"idle":[],"quarter"')
text=text.replace('out/"traveller-report.json"','out/f"{ROLE}-report.json"')
a=text.index('    if mode!="reduced":')
b=text.index('    print(folder.as_posix()',a)
text=text[:a]+'''    if report.get("pending"):
        print("PENDING", report["pending"], flush=True)
'''+text[b:]
text=text.replace("AvatarDepthPivotQA.exe","IslandAnimationSuiteQA.exe")
a=text.index('if __name__=="__main__":')
text=text[:a]+'''
if __name__=="__main__":
    mode=sys.argv[1]
    if mode=="import":
        folder,path,graph=stage("donor")
        runner.launch(folder,path,graph,"import",[runner.ENGINE,"--headless","--path",path,"--editor","--import","--quit"],
            runner.environment(folder))
        runner.collect_imports(folder,path,graph)
        print(folder)
    else:
        donor=Path(sys.argv[2])
        ROLE=sys.argv[3]
        assert ROLE in ("traveller","ticket","imp","announcer")
        if mode=="package":
            package(donor)
        else:
            record(mode,donor)
'''
exec(compile(text,str(here/"run.py"),"exec"))
