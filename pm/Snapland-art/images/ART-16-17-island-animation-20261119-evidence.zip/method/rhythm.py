"""Run the simultaneous idle-phase check against a single world."""
import sys
from pathlib import Path

here=Path(__file__).resolve().parent
base=here.parent/"art16-longitudinal-pivot-study-20261119/verify.py"
text=base.read_text("utf8")
start=text.index('FIXTURE="game/tests/native_avatar_depth_pivot_study"')
stop=text.index('def stage(',start)
text=text[:start]+'''FIXTURE="game/tests/test_island_rhythm_probe.gd"
fixtures={FIXTURE:HERE/"rhythm_probe.gd"}
runner.FIXTURES=list(fixtures)
runner.MARKER="PASS: three live island actors keep distinct idle rhythm"


'''+text[stop:text.index("def record(")]
text+='''
donor=Path(sys.argv[1])
folder,path,graph=stage("rhythm",donor)
runner.launch(folder,path,graph,"rhythm",[runner.ENGINE,"--headless","--fixed-fps","60","--path",path,"--script",
    "res://"+FIXTURE],runner.environment(folder))
print(folder)
'''
exec(compile(text,str(here/"rhythm.py"),"exec"))
