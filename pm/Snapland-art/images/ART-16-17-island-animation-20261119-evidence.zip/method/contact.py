"""Make portrait contact sheets from independently cropped native frames."""
from pathlib import Path
import hashlib
import json
import math
import sys
from PIL import Image, ImageDraw, ImageOps

HERE=Path(__file__).resolve().parent
NATIVE=HERE/"native"
ROLES=("traveller","ticket","imp","announcer")
DIRECTIONS=("front","front_right","right","back_right","back","back_left","left","front_left")
GESTURES={
    "ticket":("greet-frame-3","interact-frame-4","emotion_happy-frame-3","idle_gesture-frame-2"),
    "imp":("greet-frame-3","interact-frame-3","emotion_proud-frame-3","dance-frame-2"),
    "announcer":("greet-frame-3","interact-frame-3","emotion_curious-frame-3","special-frame-2"),
}


def load(path):
    return json.loads(path.read_text("utf8"))


def stage(mode,role,kind="suite"):
    choices=[]
    for folder in NATIVE.glob(f"{kind}-{mode}-1119-*"):
        receipt=folder/"receipt.json"
        path=folder/"captures"/f"{role}-report.json"
        if receipt.exists() and path.exists() and load(receipt)["passed"]:
            report=load(path)
            if not report.get("pending") and report["technical_status"]=="PASS":
                choices.append(folder)
    if len(choices)>1:
        fixture="game/tests/native_island_animation_acceptance.gd"
        exact=hashlib.sha256((Path("C:/Users/stanl/Github/Snapland")/fixture).read_bytes()).hexdigest()
        choices=[folder for folder in choices if load(folder/"runtime-graph.json").get(fixture)==exact]
    assert len(choices)==1,(kind,mode,role,choices)
    return choices[0]/"captures"


def insert(sheet,draw,captures,role,label,column,row,width,height):
    report=load(captures/f"{role}-report.json")
    pose=next(item["framing"] for item in report["captured_frame_framing"] if item["label"]==label)
    assert pose["full_silhouette_inside_hud_safe_viewport"]
    x,y,w,h=pose["sprite_alpha_screen_rect"]
    if role=="traveller":
        # Review the original framing as the source pose advances after the observation.
        x,y,w,h=x-16,y-30,w+32,h+40
    rect=(math.floor(x-8),math.floor(y-8),math.ceil(x+w+8),math.ceil(y+h+8))
    with Image.open(captures/f"{role}-{label}.png") as raw:
        crop=raw.convert("RGB").crop(rect)
        portrait=ImageOps.contain(crop,(width-12,height-27))
    sheet.paste(portrait,(column*width+(width-portrait.width)//2,row*height+25+(height-27-portrait.height)//2))
    draw.text((column*width+6,row*height+5),label.replace("-frame-"," "),fill="#f6f0e4")


def hero(mode):
    capt=stage(mode,"traveller","circle")
    sheet=Image.new("RGB",(1440,522),"#283a46")
    draw=ImageDraw.Draw(sheet)
    for row,style in enumerate(("windswept","curly")):
        for col,view in enumerate(DIRECTIONS):
            insert(sheet,draw,capt,"traveller",style+"-"+view,col,row,180,261)
    sheet.save(HERE/f"traveller-{mode}-eight-directions.png")

def actors(mode):
    sheet=Image.new("RGB",(1120,900),"#283a46")
    draw=ImageDraw.Draw(sheet)
    for row,role in enumerate(ROLES[1:]):
        capt=stage(mode,role)
        for col,label in enumerate(GESTURES[role]):
            insert(sheet,draw,capt,role,label,col,row,280,300)
    sheet.save(HERE/f"npc-{mode}-personality.png")


if __name__=="__main__":
    hero(sys.argv[1])
    actors(sys.argv[1])
