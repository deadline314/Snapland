"""Inspect all authored directional NPC strides from actual idle scheduler captures."""
from PIL import Image,ImageDraw
from contact import HERE,ROLES,stage,insert

sheet=Image.new("RGB",(1440,780),"#283a46")
draw=ImageDraw.Draw(sheet)
for row,role in enumerate(ROLES[1:]):
    captures=stage("idle",role)
    for i,direction in enumerate(("left","right")):
        for index in range(4):
            insert(sheet,draw,captures,role,f"natural-walk-{direction}-{index}",i*4+index,row,180,260)
sheet.save(HERE/"npc-natural-strides.png")
