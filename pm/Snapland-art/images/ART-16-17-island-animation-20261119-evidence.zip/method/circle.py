"""Use the same isolated recorder with the continuous eight-direction scene."""
from pathlib import Path

here=Path(__file__).resolve().parent
program=(here/"run.py").read_text("utf8")
needle='runner.FIXTURES=list(fixtures)'
assert needle in program
program=program.replace(needle,'''FIXTURE="game/tests/native_animation_circle_review"
fixtures.update({FIXTURE+ext:HERE/("circle_capture"+ext) for ext in (".gd",".tscn")})
runner.FIXTURES=list(fixtures)
''')
program=program.replace('runner.make_base("suite-"+label)','runner.make_base("circle-"+label)')
exec(compile(program,str(here/"run.py"),"exec"))
