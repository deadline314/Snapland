extends "res://game/tests/native_island_animation_acceptance.gd"

const HEADINGS := ["back_left", "back", "back_right"]

func _hero_actions() -> void:
	var original: Dictionary = _world.avatar_appearance.duplicate(true)
	for look: String in ["default", "rainvest", "live-hair"]:
		var appearance := original.duplicate()
		if look != "default": appearance.hair = "bob"
		var outfit := {"outfit":"outfit-rainvest" if look=="rainvest" else "outfit-tide",
			"hat":"hat-straw" if look=="rainvest" else "hat-none"}
		_world.set_avatar_look(appearance,outfit)
		_world.set_avatar_hair_motion_enabled(look=="live-hair")
		for left_to_right: bool in [true,false]:
			var goal := "right" if left_to_right else "left"
			var result := await _pivot(left_to_right,look)
			await _record_action(look+"-"+goal+"-pivot","walk",goal,"authored",_actor_anchor(),bool(result.complete), result)
			if not bool(result.complete): return

func _pivot(left_to_right: bool, look: String) -> Dictionary:
	var start := "left" if left_to_right else "right"
	var goal := "right" if left_to_right else "left"
	var point := Vector3(-2.5 if left_to_right else -0.5,0,-14.5)
	point.y = _world.ground_surface_y(point)
	_world.player.global_position=point
	await _physics_frames(4)
	var from_key := KEY_A if left_to_right else KEY_D
	var to_key := KEY_D if left_to_right else KEY_A
	_press(from_key,true)
	await _observe_for(0.45 if left_to_right else 0.40)
	var began: bool = _world.facing==start and _world.last_avatar_source_action=="walk"
	_store_capture(look+"-"+goal+"-before",get_viewport().get_texture().get_image())
	_press(from_key,false)
	_press(to_key,true)
	var start_time := _simulated_seconds
	var visible_headings: Array[String] = []
	var sources_match := true
	var last_x: float = _world.player.global_position.x
	var sum_delta := 0.0
	var logs: Array = []
	while _simulated_seconds-start_time<0.34 and _within_budget():
		await RenderingServer.frame_post_draw
		var current_x: float = _world.player.global_position.x
		var direction: String = _world.last_avatar_direction
		var action: String = _world.last_avatar_source_action
		logs.append([_simulated_seconds-start_time, direction, action, _world.last_avatar_frame, current_x, _world.walk_distance_phase])
		if _world._avatar_pivot_remaining > 0.0:
			sum_delta += absf(current_x-last_x)
			var expected: Texture2D = _world.avatar_renderer.texture(_world.avatar_appearance,_world.avatar_equipped,direction,0,action)
			if look =="live-hair":
				sources_match = sources_match and _world.avatar_hair_rig != null and _world.avatar_hair_rig.active and _world.avatar_hair_rig.pose_key.begins_with(direction+"|"+action+"|0|")
			else:
				sources_match = sources_match and _world.avatar.texture==expected
			if visible_headings.is_empty() or visible_headings[-1]!=direction:
				visible_headings.append(direction)
				_store_capture(look+"-"+goal+"-"+direction,get_viewport().get_texture().get_image())
		last_x=current_x
	var ordered: Array = ["back_left","back","back_right"] if left_to_right else ["back_right","back","back_left"]
	var complete: bool = began and sources_match and visible_headings==ordered and sum_delta>0 and _world.facing==goal and _world.last_avatar_source_action=="walk"
	_press(to_key,false)
	await _observe_for(0.23)
	return {"complete":complete,"sources_match":sources_match,"headings":visible_headings,"physical_travel_during_pivot":sum_delta,"live_hair":look=="live-hair" and sources_match,"trace":logs}

func _observe_for(seconds: float) -> void:
	var start := _simulated_seconds
	while _simulated_seconds-start<seconds and _within_budget():
		await RenderingServer.frame_post_draw
