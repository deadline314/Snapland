from pathlib import Path
from PIL import Image,ImageDraw
import json
import numpy as np

root=Path("assets/characters")
q=Path("E:/Snapland-QA/art16-traveller-pivot-study-20261119")
raw=Path("E:/Snapland-QA/art16-traveller-turn-baseline-20261119/turn-baseline-1119-102815-7d0032/captures")
headed=("back_left","back","back_right")

def load(path):
 return np.array(Image.open(path).convert("RGBA"))
def compare(a,b):
 aa= a[:,:,3]>=128
 bb= b[:,:,3]>=128
 both=aa|bb
 miss=aa^bb
 miss |= aa&bb&(np.abs(a[:,:,:3].astype(np.int16)-b[:,:,:3].astype(np.int16)).max(axis=2)>35)
 return (float(miss[70:346].sum()/both[70:346].sum()),float(miss[276:346].sum()/both[276:346].sum()))
def knee(a):
 r,g,b,alpha=np.moveaxis(a[264:312].astype(np.int16),-1,0)
 return int(((r>140)&(r>g+20)&(g>b+18)&(alpha>=128)).sum())
def planted_boot(a):
 row=((a[343:346,:,3]>=128).sum(axis=0)>=2).nonzero()[0]
 if len(row)<9: return -1
 groups=np.split(row,np.where(np.diff(row)>1)[0]+1)
 main=max(groups,key=len)
 return float(np.mean(main))

start=load(raw/"left-right-slow-02.png")
finish=load(raw/"left-right-slow-42.png")
sources=[load(q/f"side-to-side-candidate-{index+1}.png") for index in range(4)]
reference=[load(root/f"idle-stability-v1/{heading}.png")[:360,:280] for heading in headed]
variant_rows=[]
for i,idle in enumerate(reference):
 prefs=((0,1),(1,2),(2,3))[i]
 groups=[]
 for source_index in prefs:
  source=sources[source_index]
  records=[]
  for sy in range(240,300,2):
   for dy in range(270,295,2):
    lower=Image.fromarray(source[sy:346]).resize((280,346-dy),Image.Resampling.NEAREST)
    for shift in range(-32,33,4):
     canvas=Image.new("RGBA",(280,346-dy))
     canvas.paste(lower,(shift,0))
     pose=idle.copy()
     pose[dy:346]=np.array(canvas)
     above=pose[dy-1,:,3]>=128
     below=pose[dy,:,3]>=128
     seam=np.sum(above^below)
     if seam>17: continue
     color=(np.abs(pose[dy-1,:,:3].astype(np.int16)-pose[dy,:,:3].astype(np.int16)).max(axis=1)>95)
     errors=np.sum(above&below&color)
     if errors>19 or knee(pose)<.59*knee(idle): continue
     f=planted_boot(pose)
     if not 83<=f<=194: continue
     _,shift_delta=compare(pose,idle)
     if shift_delta<.08: continue
     boundary=compare(start,pose) if i==0 else compare(pose,finish) if i==2 else (0,0)
     score=seam/92+errors/140+.2*shift_delta+boundary[0]*2+boundary[1]
     records.append((score,(source_index,sy,dy,shift),f,pose))
  records.sort(key=lambda r:r[0])
  selected=[]
  for opt in records:
   if any(opt[1][1:]==chosen[1][1:] for chosen in selected):continue
   selected.append(opt)
   if len(selected)>=22:break
  groups.extend(selected)
 print(headed[i],len(groups),flush=True)
 if not groups: raise RuntimeError(headed[i]+" has no anatomical candidate")
 variant_rows.append(groups)

max_direct=compare(start,finish)
edges={}
for i in range(2):
 for a,row in enumerate(variant_rows[i]):
  for b,next_row in enumerate(variant_rows[i+1]):
   if abs(row[2]-next_row[2])<=13:
    edges[i,a,b]=compare(row[-1],next_row[-1])

enter=[compare(start,entry[-1]) for entry in variant_rows[0]]
exit=[compare(entry[-1],finish) for entry in variant_rows[2]]
candidates=[]
for i,a in enumerate(variant_rows[0]):
 for j,b in enumerate(variant_rows[1]):
  if (0,i,j) not in edges:continue
  for k,c in enumerate(variant_rows[2]):
   if (1,j,k) not in edges or abs(a[2]-c[2])>16: continue
   changes=[enter[i],edges[0,i,j],edges[1,j,k],exit[k]]
   worst=np.max(changes,axis=0).tolist()
   score=worst[0]+.2*worst[1]+.0002*(abs(a[2]-b[2])+abs(b[2]-c[2]))
   candidates.append((score,(i,j,k),changes,worst))
if not candidates:raise RuntimeError("No continuous boot contact found")
_,choice,changes,worst=min(candidates)
final=[row[i] for i,row in zip(choice,variant_rows)]
region=Image.new("RGB",(1150,390),"#e1dccf")
draw=ImageDraw.Draw(region)
for i,(img,cap) in enumerate(zip([start,*(r[-1] for r in final),finish],("incoming",*headed,"outgoing"))):
 image=Image.fromarray(img)
 if 1<=i<=3:image.save(q/f"{cap}-pivot.png")
 crop=image.crop((43,50,238,353))
 left=i*230+15
 region.paste(crop,(left,28),crop)
 draw.text((left,8),cap,fill="black")
region.save(q/"planted-pivot-comparison.png")
report={"prior":max_direct,"new":worst,"edges":changes,"options":len(candidates),"poses":{d:{"fit":v[1],"plant_x":v[2]} for d,v in zip(headed,final)}}
(q/"planted-pivot-comparison.json").write_text(json.dumps(report,indent=2)+"\n","utf8")
print(report,flush=True)
