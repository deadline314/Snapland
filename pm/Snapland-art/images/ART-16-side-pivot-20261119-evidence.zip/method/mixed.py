from pathlib import Path
from PIL import Image,ImageDraw
from itertools import combinations,product
import numpy as np,json

q=Path("E:/Snapland-QA/art16-traveller-pivot-study-20261119")
root=Path("assets/characters")
before=Path("E:/Snapland-QA/art16-traveller-turn-baseline-20261119/turn-baseline-1119-102815-7d0032/captures")
compass=("front","front_right","back_right","back","back_left","front_left")
def pose(dir,action):
 if action=="idle":
  path=root/f"idle-stability-v1/{dir}.png"
  x=y=0
 elif action=="walk":
  path=root/f"walk-stability-v1/island-raw-{dir}.png"
  x,y=280*5,0
 else:
  i=(("left","right") if dir in ("left","right") else compass).index(dir)
  path=root/("traveller-"+action+("-sides-v1.png" if dir in ("left","right") else "-compass-v1.png"))
  x,y=280*(i%3),360*(i//3)
 return np.array(Image.open(path).convert("RGBA").crop((x,y,x+280,y+360)))
def diff(a,b):
 aa=a[:,:,3]>=128
 bb=b[:,:,3]>=128
 union=aa|bb
 d=(aa^bb)|(aa&bb&(np.abs(a[:,:,:3].astype(np.int16)-b[:,:,:3].astype(np.int16)).max(axis=2)>35))
 return [float(d[70:346].sum()/union[70:346].sum()),float(d[276:346].sum()/union[276:346].sum())]
canvas=Image.new("RGB",(1260,680),"#e1dccf")
draw=ImageDraw.Draw(canvas)
report={}
cases=[("side-to-side",("back_left","back","back_right"),"left-right",2),("back-to-front",("back_right","right","front_right"),"back-front",5)]
for row,(name,refs,replay,idx) in enumerate(cases):
 stacks=[[(np.array(Image.open(before/f"{replay}-slow-{idx:02d}.png").convert("RGBA")),"incoming")]]
 for i in range(4):
  png=q/f"{name}-candidate-{i+1}.png"
  stacks.append([(np.array(Image.open(png).convert("RGBA")),f"pivot {22.5+i*45:.1f}")])
  if i<3:
   heading=refs[i]
   stacks.append([(pose(heading,action),f"{heading} {action}") for action in ("idle","settle","departure","walk")])
 stacks.append([(np.array(Image.open(before/f"{replay}-slow-42.png").convert("RGBA")),"outgoing")])
 edge={}
 for i,a in enumerate(stacks):
  for j in range(i+1,min(i+4,len(stacks))):
   for x,(a_img,_a) in enumerate(a):
    for y,(b_img,_b) in enumerate(stacks[j]):
     edge[i,j,x,y]=diff(a_img,b_img)
 direct=diff(stacks[0][0][0],stacks[-1][0][0])
 options=[]
 for n in range(2,6):
  for idxs in combinations(range(1,8),n):
   steps=(0,*idxs,8)
   if any(steps[i+1]-steps[i]>3 for i in range(len(steps)-1)): continue
   for picks in product(*(range(len(stacks[i])) for i in steps)):
    seq=[edge[steps[k],steps[k+1],picks[k],picks[k+1]] for k in range(len(steps)-1)]
    maxs=np.max(seq,axis=0).tolist()
    cost=maxs[0]+.2*maxs[1]+.01*n
    options.append((cost,steps,picks,maxs,seq))
 chosen=min(options,key=lambda v:v[0])
 report[name]={"direct":direct,"best":chosen[3],"steps":[stacks[i][j][1] for i,j in zip(chosen[1],chosen[2])],"cases":len(options)}
 for x,(i,j) in enumerate(zip(chosen[1],chosen[2])):
  raw,title=stacks[i][j]
  im=Image.fromarray(raw).crop((40,45,240,349))
  im.thumbnail((176,265))
  at=(x*180+8,row*340+35)
  canvas.paste(im,at,im)
  draw.text((at[0],at[1]-16),title,fill="black")
 draw.text((8,row*340+312),str(report[name]),fill="black")
 print(name,report[name])
canvas.save(q/"mixed-pivot-comparison.png")
(q/"mixed-pivot-comparison.json").write_text(json.dumps(report,indent=2)+"\n","utf-8")
