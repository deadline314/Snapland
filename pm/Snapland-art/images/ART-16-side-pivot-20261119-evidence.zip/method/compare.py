from itertools import product
from pathlib import Path
from PIL import Image, ImageDraw
import numpy as np
import json

root=Path("assets/characters")
qa=Path("E:/Snapland-QA/art16-traveller-pivot-study-20261119")
case_files=Path("E:/Snapland-QA/art16-traveller-turn-baseline-20261119/turn-baseline-1119-102815-7d0032/captures")
compass=("front","front_right","back_right","back","back_left","front_left")
cases={
 "left-right":[("front_left","front","front_right"),("back_left","back","back_right")],
 "right-left":[("front_right","front","front_left"),("back_right","back","back_left")],
 "back-front":[("back_right","right","front_right"),("back_left","left","front_left")],
 "front-back":[("front_left","left","back_left"),("front_right","right","back_right")],
}
poses={}
for d in ("left","right",*compass):
 poses[d]={"idle":np.asarray(Image.open(root/f"idle-stability-v1/{d}.png").convert("RGBA").crop((0,0,280,360)))}
 for action in ("settle","depart"):
  file_prefix="traveller-"+("settle" if action=="settle" else "departure")
  if d in ("left","right"):
   i=("left","right").index(d)
   name=f"{file_prefix}-sides-v1.png"
   x=280*i
   y=0
  else:
   i=compass.index(d)
   x=280*(i%3)
   y=360*(i//3)
   name=f"{file_prefix}-compass-v1.png"
  poses[d][action]=np.asarray(Image.open(root/name).convert("RGBA").crop((x,y,x+280,y+360)))

def diff(a,b):
 alpha_a=a[:,:,3]>=128
 alpha_b=b[:,:,3]>=128
 union=alpha_a|alpha_b
 mismatched=(alpha_a^alpha_b)|(alpha_a&alpha_b&(np.abs(a[:,:,:3].astype(np.int16)-b[:,:,:3].astype(np.int16)).max(axis=2)>35))
 return [float(mismatched[70:346].sum()/union[70:346].sum()),float(mismatched[276:346].sum()/union[276:346].sum())]

board=Image.new("RGB",(880,1120),"#e1dccf")
draw=ImageDraw.Draw(board)
report={}
for i,(route,transitions) in enumerate(cases.items()):
 states=json.loads((case_files/"registration.json").read_text("utf-8"))
 movement,= [r for r in states if r["route"]==route and r["speed"]==.25]
 rows=movement["samples"]
 from_heading,to_heading=route.split("-")
 turn=next(j for j,r in enumerate(rows) if r[1].split("/")[0]==to_heading)
 start=next(j for j in reversed(range(turn)) if j==0 or rows[j-1][1]!=rows[j][1])
 endpoints=[np.asarray(Image.open(case_files/f"{route}-slow-{tick:02d}.png").convert("RGBA")) for tick in (start,turn)]
 old=diff(*endpoints)
 scores=[]
 for path in transitions:
  for choices in product(("idle","settle","depart"),repeat=3):
   frames=[endpoints[0],*(poses[d][a] for d,a in zip(path,choices)),endpoints[1]]
   changes=[diff(a,b) for a,b in zip(frames,frames[1:])]
   worst=np.max(changes,axis=0).tolist()
   scores.append((worst[0]+.15*worst[1],path,choices,changes,frames))
 scores.sort(key=lambda r:r[0])
 selected=scores[0]
 report[route]={"direct":old,"selected":selected[1:4],"maximum":np.max(selected[3],axis=0).tolist(),"tested":len(scores)}
 for j,a in enumerate(selected[-1]):
  im=Image.fromarray(a).crop((48,53,232,353))
  im.thumbnail((165,251))
  x=j*176+6
  y=i*280+21
  title=(route+" approach") if j==0 else "destination" if j==4 else selected[1][j-1]+"/"+selected[2][j-1]
  board.paste(im,(x,y),im)
  draw.text((x,y-16),title,fill="#172733")
board.save(qa/"compass-pivot-comparison.png")
(qa/"compass-pivot-comparison.json").write_text(json.dumps(report,indent=2)+"\n","utf-8")
for k,v in report.items():
 print(k,v["direct"],v["maximum"],v["selected"][:2])
