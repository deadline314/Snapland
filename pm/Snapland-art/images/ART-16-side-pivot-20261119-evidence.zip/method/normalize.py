from pathlib import Path
from itertools import product
import json
import hashlib
from PIL import Image, ImageDraw
import numpy as np

q=Path("E:/Snapland-QA/art16-traveller-pivot-study-20261119")
original=Path("C:/Users/stanl/.codex/generated_images/01a1e5dd-6423-7963-9dc5-b040851d2b6b")
sample=Path("E:/Snapland-QA/art16-traveller-turn-baseline-20261119/turn-baseline-1119-102815-7d0032/captures")
sources={
    "side-to-side":("exec-9520f49b-b6f1-4074-96bd-49b75171a74a.png","left-right",2,42,(125,135,150,170)),
    "back-to-front":("exec-3568c20f-f40e-4d51-b314-574dbd182b57.png","back-front",5,42,(146,165,177,163)),
}

def alf(arr):
 return np.array(arr.getchannel("A"))>=128

def diff(a,b):
 alpha_a=a[:,:,3]>=128
 alpha_b=b[:,:,3]>=128
 union=alpha_a|alpha_b
 discrepancy=(alpha_a^alpha_b)|(alpha_a&alpha_b&(np.abs(a[:,:,:3].astype(np.int16)-b[:,:,:3].astype(np.int16)).max(axis=2)>35))
 return [float(discrepancy[70:346].sum()/union[70:346].sum()),float(discrepancy[276:346].sum()/union[276:346].sum())]

def options(source,head,heights,ratio):
 piece=source.resize((round(source.width*ratio),round(source.height*ratio)),Image.Resampling.NEAREST)
 mask=alf(piece)
 yy,xx=np.where(mask[:82])
 anchor=(xx.min()+xx.max())//2
 for offset in (-12,-6,0,6,12):
  tile=Image.new("RGBA",(280,360))
  x=int(head-anchor+offset)
  y=346-piece.height
  tile.paste(piece,(x,y))
  visible=alf(tile)
  last=np.where(visible)[0].max()
  assert 344 <= last <=345
  yield np.asarray(tile),offset

board=Image.new("RGB",(1128,800),"#e1dccf")
draw=ImageDraw.Draw(board)
report={}
for index,(name,(filename,route,first,last,heads)) in enumerate(sources.items()):
 art=Image.open(original/filename).convert("RGBA")
 ww=art.width
 sources_cells=[]
 for i in range(4):
  cell=art.crop((ww*i//4,0,ww*(i+1)//4,art.height))
  bounds=cell.getchannel("A").point(lambda a:255 if a>=128 else 0).getbbox()
  sources_cells.append(cell.crop(bounds))
 fixed=[np.asarray(Image.open(sample/f"{route}-slow-{i:02d}.png").convert("RGBA")) for i in (first,last)]
 base=diff(*fixed)
 heights=[cell.height for cell in sources_cells]
 ratios=[n/np.median(heights) for n in (268,274,282)]
 findings=[]
 for ratio in ratios:
  row_opts=[list(options(cell,head,heights,ratio)) for cell,head in zip(sources_cells,heads)]
  scores={}
  stages=[[(fixed[0],0)],*row_opts,[(fixed[1],0)]]
  for i in range(len(stages)-1):
   for j,(a,dx) in enumerate(stages[i]):
    for k,(b,dx2) in enumerate(stages[i+1]):
     scores[i,j,k]=diff(a,b)
  for shifts in product(range(5),repeat=4):
   s=(0,*shifts,0)
   scores_seq=[scores[i,a,b] for i,(a,b) in enumerate(zip(s,s[1:]))]
   maxima=np.max(scores_seq,axis=0).tolist()
   findings.append((maxima[0]+maxima[1]*.15,ratio,s,maxima,scores_seq,[stages[i][j] for i,j in enumerate(s)]))
 rank,ratio,indices,maxima,scores_seq,res=min(findings,key=lambda i:i[0])
 for i,(a,offset) in enumerate(res):
  im=Image.fromarray(a)
  if 1<=i<=4: im.save(q/f"{name}-candidate-{i}.png")
  crop=im.crop((41,49,239,349))
  crop.thumbnail((178,268))
  x=i*188+5;y=index*400+35
  board.paste(crop,(x,y),crop)
  caps="incoming" if i==0 else "outgoing" if i==5 else f"pivot {i}"
  draw.text((x,y-18),caps,fill="#172733")
 draw.text((5,index*400+326),name+"  direct: "+str([round(v,4) for v in base])+"  with cels: "+str([round(v,4) for v in maxima]),fill="#172733")
 report[name]={"original":filename,"original_sha256":hashlib.sha256((original/filename).read_bytes()).hexdigest(),"direct":base,"maximum":maxima,"fixed_resize":ratio,
               "offsets":[r[1] for r in res[1:-1]],"connections":scores_seq}
 print(name,"direct",base,"candidate",maxima,flush=True)
board.save(q/"new-pivot-comparison.png")
(q/"new-pivot-comparison.json").write_text(json.dumps(report,indent=2)+"\n","utf8")
