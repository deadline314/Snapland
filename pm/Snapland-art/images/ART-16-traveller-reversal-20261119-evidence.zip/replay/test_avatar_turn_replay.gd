extends SceneTree

const World = preload("res://game/world/park_world.gd")
const ROUTES := [
	["left-right", ["move_left"], ["move_right"]],
	["right-left", ["move_right"], ["move_left"]],
	["back-front", ["move_up"], ["move_down"]],
	["front-back", ["move_down"], ["move_up"]],
	["right-back", ["move_right"], ["move_up"]],
	["back-diagonal", ["move_up"], ["move_up", "move_right"]],
	["front-diagonal", ["move_down"], ["move_down", "move_left"]],
]
var world: World

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	world = World.new()
	root.add_child(world)
	var folder := OS.get_environment("COTTON_CAPTURE_DIR")
	var results := []
	for scale: float in [1.0, 0.25]:
		Engine.time_scale = scale
		for index in ROUTES.size():
			var route: Array = ROUTES[index]
			var point := Vector3(-2.5 if index % 2 == 0 else -0.5, 0, -14.5)
			point.y = world.ground_surface_y(point)
			world.player.global_position = point
			for _tick in 5: await physics_frame
			for key: String in route[1]: Input.action_press(key)
			for _tick in (110 if scale < 1.0 else 27): await physics_frame
			var samples := []
			var previous := world.player.global_position
			var previous_state := ""
			await physics_frame
			for key: String in route[1]: Input.action_release(key)
			for key: String in route[2]: Input.action_press(key)
			for tick in (91 if scale < 1.0 else 23):
				var position := world.player.global_position
				var state := "%s/%s/%d" % [world.last_avatar_direction, world.last_avatar_source_action, world.last_avatar_frame]
				if previous_state != state:
					var img := world.avatar.texture.get_image()
					var filename := "%s-%s-%02d.png" % [route[0], "slow" if scale < 1.0 else "normal", tick]
					if img.save_png(folder.path_join(filename)) != OK:
						quit(1)
						return
				samples.append([tick, state, position.distance_to(previous),world.walk_distance_phase,world.player.velocity.x,world.player.velocity.z,world.player.is_on_floor()])
				previous = position
				previous_state = state
				await physics_frame
			for key: String in route[2]: Input.action_release(key)
			results.append({"route":route[0], "speed":scale, "samples":samples})
			for _tick in (42 if scale < 1.0 else 12): await physics_frame
	var out := FileAccess.open(folder.path_join("registration.json"),FileAccess.WRITE)
	out.store_string(JSON.stringify(results,"  "))
	out.close()
	print("PASS: real avatar turn input baseline")
	quit(0)
