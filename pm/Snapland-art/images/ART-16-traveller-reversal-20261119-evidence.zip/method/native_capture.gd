extends "res://game/tests/native_island_animation_acceptance.gd"

const ROUTES := [["left","right",KEY_A,KEY_D],["right","left",KEY_D,KEY_A],
	["back","front",KEY_W,KEY_S],["front","back",KEY_S,KEY_W]]

func _hero_actions() -> void:
	var original: Dictionary = _world.avatar_appearance.duplicate(true)
	for look: String in ["default", "rainvest-bob"]:
		var outfit := {"outfit":"outfit-tide","hat":"hat-none"}
		var appearance := original.duplicate()
		if look == "rainvest-bob":
			appearance.hair = "bob"
			outfit = {"outfit":"outfit-rainvest","hat":"hat-straw"}
		_world.set_avatar_look(appearance,outfit)
		_world.set_avatar_hair_motion_enabled(look == "rainvest-bob")
		for index in range(ROUTES.size()):
			var route: Array = ROUTES[index]
			var label: String = look+"-"+str(route[0])+"-"+str(route[1])
			var outcome := await _reversal(index,route,label)
			await _record_action(label+"-reversal","walk",route[1],"authored-walk-atlas",_actor_anchor(),bool(outcome.complete),outcome)
			if not bool(outcome.complete): return

func _reversal(index: int, route: Array, label: String) -> Dictionary:
	var point := Vector3(-2.5 if index%2==0 else -0.5,0,-14.5)
	point.y = _world.ground_surface_y(point)
	_world.player.global_position = point
	await _physics_frames(4)
	var from_key: Key = route[2]
	var to_key: Key = route[3]
	_press(from_key,true)
	await _observe_for(0.45)
	var begin: bool = _world.facing == route[0] and _world.last_avatar_source_action == "walk"
	_store_capture(label+"-approach",get_viewport().get_texture().get_image())
	_press(from_key,false)
	_press(to_key,true)
	var started := _simulated_seconds
	var samples: Array = []
	var idle_frames := 0
	var live_hair_frames := 0
	var turned := false
	var narrow_speed_sample := false
	while _simulated_seconds-started < 0.31 and _within_budget():
		await RenderingServer.frame_post_draw
		var velocity: Vector3 = _world.player.velocity
		var speed := Vector2(velocity.x,velocity.z).length()
		var phase: float = _world.walk_distance_phase
		var head: String = _world.facing
		var state: String = _world.last_avatar_source_action
		if state=="idle": idle_frames += 1
		if _world.avatar_hair_rig != null and _world.avatar_hair_rig.active: live_hair_frames += 1
		samples.append([_simulated_seconds-started,head,state,_world.last_avatar_frame,speed,phase])
		if speed < 0.15 and not narrow_speed_sample:
			_store_capture(label+"-slow-crossing",get_viewport().get_texture().get_image())
			narrow_speed_sample=true
		if head == route[1] and not turned:
			_store_capture(label+"-turned",get_viewport().get_texture().get_image())
			turned = true
	_press(to_key,false)
	var complete: bool = begin and turned and idle_frames == 0 and _world.last_avatar_source_action == "walk" and _world.facing == route[1]
	await _observe_for(0.24)
	return {"complete":complete,"samples":samples,"idle_frames":idle_frames,"live_hair_frames":live_hair_frames,
		"source_approach":begin,"source_turned":turned,"narrow_speed_sample":narrow_speed_sample}

func _observe_for(seconds: float) -> void:
	var start := _simulated_seconds
	while _simulated_seconds-start < seconds and _within_budget():
		await RenderingServer.frame_post_draw
