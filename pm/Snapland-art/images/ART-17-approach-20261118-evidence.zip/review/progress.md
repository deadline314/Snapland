# SDD ledger — plan: docs/superpowers/plans/2026-11-18-npc-approach-actions.md

Branch codex/npc-approach-actions-20261118, BASE4319464, main3ca0b9c. MAIN31 delivered before this work; no overlap with frozen MAIN31 sources/packages. Task1 may now extend its existing dialogue test.

## Preflight

| Task/pair | Produces/consumes and finding | Ruling |
|---|---|---|
| Task1 self | world boundary front selection vs all3roles/8approaches actual Main tests, old lifecycle assertions preserved | coherent, no generic fallback |
| Task2 self | native real E/player placement vs authored frame/idle captures and clean release | coherent; no action injection or NPC root movement |
| Task1→Task2 | world fix and existing Main/event APIs consumed by separate native fixture | wait for Task1 review/source freeze; production files ownership disjoint |
| Task2→root QA | new Node scene/helper consumed by explicit private export allowlist | root waits until fixture frozen; no existing accepted package mutation |

Ruling: user authorizes ongoing implementation, commits/push/main integration, and routine implementation decisions. No repeated approval for authorized Git. Existing ART17 is sufficient ticket scope; full artistic criteria stay unchecked.

## Status

- [x] Spec/plan committed and pushed4319464.
- [x] Task1 actual interaction regression + minimal fix + review.
- [ ] Task2 native/QA + review + delivery.

MAIN31 latest main CI44137880546 in progress; own duplicate44137859718 cancellation requested. Keep monitoring main without blocking independent ART17 work.

Task 1: complete (commits4319464..9ed34e6, review clean). Producer /root/npc_approach_fix, reviewer /root/npc_approach_task_review; spec+quality 0 findings. Baseline28PASS, decisiveRED21nonfrontactions absent, GREEN298markers +6focusedfixtures=7/7, preservedoriginal27checks/cleanup. Two frozen hashes in task1report. Native task2 /root/npc_approach_native owns only new nativeGD/tscn; root owns package.py and finalcases.

Root private package recipe prepared at .review/npc-approach-20261118/package.py, creation-only new D UUID directory, exact nativeGD/tscn/helper allowlist and normal actual embedded QA; not executed before Task2 source freeze. Task2 QA user args mirror existing native island fixture; receipt after resource release.

Previous MAIN31 main3ca0b9c all six jobs SUCCESS44137880546; no lifecycle ticket remains open.

Task2 scoped fixture review spec+quality PASS0findings, but root final reduced visual acceptance REJECTED: announcer frozen legacy walking image, baseline equality was semantically wrong. Packages ff518038/58632e77 all3 technically strictgreen but reduced full-standing notaccepted. Task3 added before final delivery; no PM delivery script executed. See root-visual-rejection.json/specaddendum. Preserve old evidence, do not publish allstanding claim.
Ruling: use existing formal front stand when valid on reduced-motion transition; retain original reset/fallback contract — satisfies original ART17 no frozen walking; wrong choice costs scoped regression/rework, no new art assumptions.

## Task3 preflight extension

| Task/pair | Produces/consumes and finding | Ruling |
|---|---|---|
| Task3 self | formal stand selection vs source assertions/old missing fallback and frozen-time checks | coherent, preserve all root reset/absence constraints |
| Task2→Task3 | frozen native predicate baseline branch contradicts original ART17 no frozen walking | task3 owns nativeGD after Task2 complete; original byte evidence retained/rejected |
| Task3→root QA | corrected sharedsetter/nativepredicate require new3mode package and actual reducedPNG review | old acceptedtechnicalpackages immutable; newUUID recipe + visualacceptance gate required before PM |

Task3 producer /root/npc_reduced_stand_fix, BASE115f57c. Task2 .tscn unchanged. Root deliver.py now refuses without matching package/root-visual-acceptance.json and reduced formal-standing verified. No PM/media copied yet.

Task3 scope extension authorized before edits: test_sprite_clearance.gd has old supported-source baseline assertions; producer owns only relevant reduced-pose expectations and preserves material/UV/size/root/shadow guards. Add focused fixture run. Missing-library test_npc_activity remains unchanged.

Task3 additional exact supported-source reduced assertion in test_npc_walk_motion.gd authorized: preserve rig hide/root/motion/costume checks and verify motion pause ordering does not override formal standing. Complete caller search before more edits; missing-library fixture remains unchanged.

Task3 last broad-search supported-source reduced baseline assertion in legacy native_npc_review.gd authorized (Sprite/material/UV only); targeted real GPU smoke if needed. Producer confirms all remaining broadmatches are unrelated or missing-library tests. Ownership7files total. Rig pause deactivation preserves texture; verify exact ordering.

Task3 producer frozen and committedb27913b (BASE115f57c);11headless +native90checks/12PNGs green, legacy fullentry expectedpreexistingfailure recorded/main32. Task3 gate reviewer /root/npc_reduced_task_review pending. Root independently viewed all3worker pass1 reduced standing screenshots: formal front stance/identity/body scale now replaces legacy stride. New final embedded QA94fdba32 running, sourcefrozenhashesa3caa.../ab35...; old QA586 reduced rejected remains preserved.

Task3: complete (commits115f57c..b27913b, review clean), spec/quality0findings. Root finalQA94fdba32 all3 strictclean,1188 exactsourcehashes/binarySHA6fd916...verified. Normal215frames/7.167s, truequarter+rebuild1564frames/52.133s, reduced+rebuild6role rows; MP4 full decodeclean. Root viewed final normal3actions, quarterannounceridle, finalreduced3poses. root-visual-acceptance.json gatespublication. Wholebranchreview/Git/main pending.

Wholebranch review4c44b12 Withfixes,1ImportantP2: native_sprite_clearance_review.gd dictionary-based reduced/resume expectedstates still legacybaseline. Root found during MAIN32 prep; reviewer confirmed separatechild_run path (notparentlegacy failure). Single finalfixwave started via originalTask3producer /root/npc_reduced_stand_fix, ownershiponlychildGD/privateevidence. Capture real RED/GREEN actualmethod, keep all body/depth/foot/materialguards. Runtime/main current3fileQAunchanged, no extraexport. Aftercoveringreport rootexactlyonescopedrereview then integrate; no secondwave.

Finalwave actual fullchild native run found earlier preexisting body-depth failure (announcerframe2,307/47406pixels); preservednotbypassed. Direct existing reducedmethod probe meaningfulRED reachesP2. MAIN33 opened immediately for separatefullnativeocclusion repair afterMAIN32; noframingimplementationinART17.
Ruling: formal source alpha bottom447 vs declaredfeetanchor448 uses existing headless onepixel edge/row convention; allowexactvalidatedsourcebottom with0..1 gap whileRGBA8/canvas/contact/depthguardunchanged — avoids falsely requiring legacybottom448, wrongrulingcostsonepixelposevalidationrework.

Final fix wave1/1:1P2 ADDRESSED,0open, no new Critical/Important breakage (commits4c44b12..e16cbc5). Scopedreview nativechild SHA6526bc...; actual inherited reducedmethod GREEN3roles, exactformal/source/row447+anchor448/contact/depth0covered/pausedresume. Fullchild earlierdepth failure remainsMAIN33; parentlegacy remainsMAIN32. Runtime/QA1188sourcehashes unchanged, no reexport.

Final review declined-items rulings: MAIN32oldroot/source debt repaired next; newart/generalizedfallback excluded because currentformalfrontsufficient; existingrootreset/teardown preserved toavoidunrelatedchange; fullart/naturalcamera/humanplay/hearing remain originaluncheckedARTcriteria; GPUcrossplatform/performance notinlocaltechnicalclaims, latestmainCI executor-owned. No silent exclusion of knownfailures.
