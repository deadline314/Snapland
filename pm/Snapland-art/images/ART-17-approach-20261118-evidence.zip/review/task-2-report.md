# Task 2 report — native NPC approach evidence fixture

Status: implemented, verified locally, sources frozen for root's independent review/capture/package. No commit. Ownership is only the two new native fixture files and private evidence/report. Task 1 production and regression source hashes remain unchanged.

## Contract and scope

Read task-2-brief.md, design/runtime/npc-approach-actions.md, plan Global Constraints through plan-path, task-1-report.md scope/regression paragraphs, pm-ticket and Ponytail instructions. Inspected existing native_island_animation_acceptance/native_npc_dialogue_review, Main keyboard/dialogue handling, ParkWorld physics/settings, NpcActivity action/idle/reduced-motion restoration, shared CharacterAnimationTiming, TestSaveGuard and audio_playback_release before implementation. No shared caller, asset, config, runner, production export, PM or Git change was needed. Root owns those integrations. No worker/subagent was spawned.

Added game/tests/native_npc_approach_review.gd and its actual .tscn Node entry. Each role uses only player placement at the current unmodified live NPC root plus normalized (-1,0,-1) × 1.6 plus (0,0.1,0), two real physics frames and one process frame. Actual E key events open Main's actual NPC dialogue. There is no nearest assignment, manual world/activity process call, request_action call, action/sequence/result injection, task/quest completion setup or NPC-root placement. Progress.reset_progress plus intro_seen=true initializes only the isolated profile.

The selected real world event must produce the existing finite complete front greet/interact source, available with at least seven cels and no legacy fallback. Native rendered frames are sampled through actual frame_post_draw; shared timing resolves expected source textures including production announcer costume composition. Multiple actual authored cels, an intermediate action screenshot, finite recovery to looping front standing, steady held dialogue/idle and safe Escape cancellation are asserted. All three NPC roots and interaction points are checked during each hold. No image array accumulates and no per-frame PNG dump occurs: only intermediate action + held idle per role/pass are saved.

After the actual interaction, only hero visibility and world camera-follow physics are changed for close review framing. Camera is placed at NPC root+(0,2,4.2), looks at root+(0,0.45,0), orthographic size 6.0, 1280×720 viewport. This is explicit scripted camera/player evidence, not natural player movement. Each screenshot checks the full source alpha silhouette above the actual DialoguePlaque and below top HUD-safe margin, visible/in-front-of-camera and a clear collision-geometry ray. Native PNGs were visually inspected for guide, imp and announcer intermediate actions; bodies, head and shoes are fully visible above the dialogue. This is static capture inspection only.

## Interface and modes

- `--animation-output=<new absolute empty directory>` writes `npc-approach-report.json` and role/pass/action-or-idle PNGs.
- `--quarter` sets actual Engine.time_scale=0.25; no render/encode speed trick.
- `--reduced-motion` first proves the real finite E action and front idle recovery, then applies the actual reduced-motion setting during steady held idle and checks the restored complete authored standing baseline and frozen timeline. NpcActivity intentionally restores its baseline when reduced motion is enabled; the fixture reflects that existing behavior rather than requiring the last normalized idle cel to remain. All root/point assertions remain.
- `--rebuild` runs the three real interactions, cleanly frees Main with audio release, then instantiates Main and repeats all three roles. Compatible with quarter or reduced separately.
- quarter+reduced is rejected. Headless is rejected. Missing/nonabsolute/virtual paths, existing save file/directory, project save location, root-level save parent, project/default-user-data/ancestor output location, overlapping output ancestor of save profile and nonempty output reuse are rejected before scene creation. Shared TestSaveGuard protects default player userdata. No accepted package/profile is touched.

Receipt status/failures are assigned after Main audio capture → shutdown → queue_free → two process-frame barrier → shared wait_for_release. Report open/write/flush failure records a real failure and forbids the success marker/zero exit. Exact final marker is `PASS: native NPC approach actions and idle recovery`, printed once only after successful teardown and receipt write. `human_played=false`, `complete_acceptance=false`; technical_status PASS requires no recorded failures.

## Isolated source stage and commands

Private runner: `C:/Users/stanl/Github/Snapland/.review/npc-approach-task2-20261118/task2_run.py`.

New stage: `D:/Snapland-QA/npc-approach-task2-20261118-0210`.

Stage created empty through prepare_runtime_stage using git ls-files tracked runtime only plus the exact explicit source allowlist:

1. game/tests/native_npc_approach_review.gd
2. game/tests/native_npc_approach_review.tscn
3. game/tests/audio_playback_release.gd

No broad test directory, untracked import, UID or existing .godot copy. Initial source manifest is `.review/npc-approach-task2-20261118/stage-manifest.json`; each subsequent run receipt records exact launched fixture/helper hashes after the bounded allowlist sync. The initial manifest intentionally remains initial rather than pretending to be the later source snapshot.

Every engine invocation goes only through tools.godot_entrypoints.run_validated_godot, exact `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe`. Native smoke uses `--path D:/Snapland-QA/npc-approach-task2-20261118-0210 --rendering-method gl_compatibility --audio-driver Dummy res://game/tests/native_npc_approach_review.tscn -- --animation-output=<label folder>`. Only the editor import used --headless; it is parser/import evidence, not native playback. Runtime log identifies Godot4.7.2, Windows display and AMD Radeon RX9070XT Compatibility renderer. Dummy audio is explicit; no hearing claim.

Save per label is `D:/Snapland-QA/npc-approach-task2-20261118-0210-profiles/<label>/progress.json`, APPDATA and LOCALAPPDATA are corresponding `<label>/appdata` and `<label>/localappdata`, all absolute isolated D paths. Output is `D:/Snapland-QA/npc-approach-task2-20261118-0210-evidence/<label>`. Runner receipts preserve exact command/save/exit/time/hash; logs preserve stdout/stderr. No deletion performed.

From repository root:

```powershell
python .review/npc-approach-task2-20261118/task2_run.py prepare
python .review/npc-approach-task2-20261118/task2_run.py frozen-normal
python .review/npc-approach-task2-20261118/task2_run.py reduced-selfcheck --reduced-motion
python .review/npc-approach-task2-20261118/task2_run.py reject-relative-save
python .review/npc-approach-task2-20261118/task2_run.py reject-relative-output --animation-output=relative-output
python .review/npc-approach-task2-20261118/task2_run.py reject-project-output --animation-output=D:/Snapland-QA/npc-approach-task2-20261118-0210/unsafe-output
python .review/npc-approach-task2-20261118/task2_run.py reject-reused-output --animation-output=D:/Snapland-QA/npc-approach-task2-20261118-0210-evidence/normal-final
python .review/npc-approach-task2-20261118/task2_run.py reject-conflicting-modes --quarter --reduced-motion
```

Creation-only prepare must not target the existing nonempty stage again. Successful smoke labels likewise require new save/output labels for reruns. The negative reused-output command deliberately references preserved normal-final evidence, and rejects without overwriting it. Relative-save rejection substitutes only that run's save with `relative.json`; shared Progress startup guard already rejects it before any write. Duplicate output flags in negative commands are intentional: the final user-argument value is the invalid candidate, while the runner's normal fresh label remains reserved for bookkeeping.

## Results and preserved failures

Evidence directory: `C:/Users/stanl/Github/Snapland/.review/npc-approach-task2-20261118`.

| Label | Exit | PASS markers | ERROR markers | Seconds |
|---|---:|---:|---:|---:|
| import | 0 | 0 | 0 | 18.498 |
| frozen-normal | 0 | 46 | 0 | 12.906 |
| reduced-selfcheck | 0 | 46 | 0 | 12.975 |
| reject-relative-save | 1 | 0 | 3 | 2.775 |
| reject-relative-output | 1 | 0 | 2 | 2.769 |
| reject-project-output | 1 | 0 | 2 | 2.771 |
| reject-reused-output | 1 | 0 | 2 | 2.793 |
| reject-conflicting-modes | 1 | 1 | 2 | 2.758 |

Normal and reduced final-source receipts each contain three role rows, six PNGs, technical_status PASS, no failures, true held-position/source-consistency checks, human_played false and complete_acceptance false. Each stdout contains exactly one final completion marker, zero ERROR/leaked/still-in-use text. Existing world unsupported-material OcclusionController warnings remain. The five intentional negative cases exit1 without a final success marker; conflict receipt correctly says FAIL with its exact reason. Path-failure runs do not write to unvalidated output.

Failures are preserved, not hidden: first normal-smoke had a GDScript inference parse error for a dynamically accessed ray result boolean; stopped only the matching owned Godot stage process after log inspection. normal-smoke-v2 ran actual actions correctly but failed six framing checks because it used the full-rect dialogue Control rather than actual plaque, also emitting six negative-Rect2 errors. Corrected by reading the existing DialoguePlaque and choosing size6.0. normal-smoke-v3 and normal-final were intermediate successful runs before final direction/path and reduced-source self-review. Their receipts retain their own original hashes. Final frozen-normal and reduced-selfcheck run the exact frozen hash below.

Five negative checks were run immediately before the final reduced-only source adaptation; their path/mode code is unchanged in final. They are not falsely presented as final-hash launches.

## Freeze and self-review

Machine-checked `.review/npc-approach-task2-20261118/self-review.json` asserts both final-source native receipts/statuses/capture counts/markers/zero errors, all five negative exits, no leaked/still-in-use diagnostics, and unchanged Task1 sources. Re-read source paths and teardown ordering. No production implementation is duplicated: shared timing, save guard, announcer costume composition and audio release are reused.

| Frozen source | SHA256 |
|---|---|
| game/tests/native_npc_approach_review.gd | a62a083b271220ac703a1680fd090402905d06f476a03b3187c1c79a013824a7 |
| game/tests/native_npc_approach_review.tscn | d30baef5279db7e01757542e4d9d6d8e4e79141ca03ef98648ae255b17d30acd |
| game/tests/audio_playback_release.gd (unchanged helper) | 1b61bba4e5c54e38050e8ba0b7170b18848198928937ca2c4dfdebc31cc37184 |

Untouched Task1 park_world.gd is f0c221dce3a71400300c37a67e0f1255be3b821a2b5a1a6d308483b32a8821c1; test_npc_dialogue_hold.gd is c8d4646d3251400435de7fd235e8a832ea6b02869e11dc7140092b80f2dffbef.

Not checked by this worker: quarter/rebuild MovieMaker capture, encoded MP4 review, embedded independent package, full suite/CI, human continuous viewing/play/listening or whole-art acceptance. Root owns final quarter+rebuild/reduced+rebuild/package/capture/review/delivery. Residual limitations: single representative back-left native approach per role (Task1 covers all eight), scripted close camera and hidden hero, collision ray is only geometry evidence; images require independent artistic review. Existing front-only source and explicit unsupported-direction behavior remain unchanged.

## Formatting-only final source update

After root completed the historical old-byte package, root authorized removal of only the extra final CRLF reported by `git diff --cached --check`. The GD file ended with its normal LF followed by an additional CRLF. Removed exactly those final two bytes; no body byte, executable statement, scene or other source changed. No engine rerun was performed for this formatting change. Existing successful evidence above retains its historical original source hash honestly; root owns the final exact-byte package rebuild.

- Previous GD SHA256: `a62a083b271220ac703a1680fd090402905d06f476a03b3187c1c79a013824a7`.
- Final GD SHA256: `a697e16254f31c3175a316fac0b0e8db49935007bfb5a1e63c96dcf8d4f735e6`.
- Asserted `old_bytes[:-2] == new_bytes` and `old_bytes.rstrip(CR/LF) + LF == new_bytes`. The normalized SHA256 equals the final SHA256 above; this proves exact normalized-body identity, not merely equivalent behavior.
- Machine-readable proof: `.review/npc-approach-task2-20261118/eof-formatting-proof.json`.
