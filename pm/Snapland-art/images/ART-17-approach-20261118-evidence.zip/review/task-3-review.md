# Task 3 independent review

Reviewed `review-115f57c..b27913b.diff`, Task 3 brief/report, reduced-motion addendum in `design/runtime/npc-approach-actions.md`, shared action/restoration/motion code, and preserved evidence under `.review/npc-reduced-stand-20261118`. Review performed read-only apart from this report; no engine rerun, source, Git or PM changes.

## Spec gate: PASS for bounded Task 3

The three-line production addition applies only when enabling reduced motion. It first retains existing complete restoration of roots, interaction points, registered scale/flip, patrol and shader baselines, then requests existing validated `stand/front` for active actors. Existing action selection normalizes the complete canvas and applies the announcer costume; shader freeze and optional rig pause/hide still follow visual selection. `_restore_record`, release and tree-exit paths are unchanged. Invalid/missing stand sources cannot use the legacy four-frame activity fallback: the existing shared action code restores complete baseline visuals, clears the sequence, freezes elapsed and records missing `stand/front`.

State coverage now exercises all three roles, interaction/walk interruption, repeated enable, source/time freeze through dialogue/pause and resume; damaged standing coverage is placed before teardown. World checks independently load formal idle/front pixels and require the canonical canvas, costume, stand/front state, frozen elapsed and shader source/UV/motion. Existing missing-library tests remain unchanged. Original root/point, pixel/flip, gesture, absence/release, dialogue/idle count, terrain/shadow/ground contact and rig visibility guards remain in the reviewed diff.

Supported-source assertion replacements are required contract corrections: registered baseline equality and legacy `record.frames[0]` were proving restoration of an old walking cel. Formal stand/front is now expected during reduced mode and immediately on resume. Corresponding material/UV checks remain present and target the selected formal texture/full canvas. General missing-action behavior is unchanged.

Current Main native `_source_matches` no longer accepts baseline equality in reduced mode: it checks the actual sequence/timing/canonical canvas/costume pixels, rejects legacy fallback and requires visible Sprite output. Re-reading the record after applying settings makes the freeze interval compare actual post-transition elapsed/source rather than a stale pre-transition dictionary. Normal-mode source checks and other native guards remain intact.

## Quality gate: PASS for bounded Task 3

No actionable defect found in the owned runtime/test changes. Reusing the shared action API is the smallest complete fix; no new runtime abstraction, configuration, dependency or art was introduced. Optional rig `set_paused` deactivates rig visibility without replacing the selected formal Sprite texture. There is no data migration or player-save behavior change.

Independently audited all twelve authoritative receipt/log pairs: eleven headless suites including Main dialogue (298 PASS markers) and current native reduced/rebuild (90 PASS markers), each exit 0, no `ERROR:`, recorded PASS counts matching the raw log and identical seven-source launch hashes. Current repository bytes match those source hashes. Preserved actual RED demonstrates state assertion failure and four world source/state errors even though the old world log also emitted a PASS marker. Intermediate failed attempts remain retained and are correctly excluded from final success evidence.

Native JSON reports technical PASS, no failures, six role/pass rows, twelve captures, reduced idle elapsed 0 for all rows, and false complete-acceptance/human-played flags. The twelve PNG files exist directly in the native output directory. Viewed the rejected old announcer reduced PNG and the new pass-1 PNG: the former is a right-walking stride; the latter displays the formal standing body and planted boots. This is static visual review with source assertions, not human play or continuous animation/art approval.

## Findings and limits

No blocking or nonblocking code finding in the reviewed Task 3 scope. MAIN-32 opening metadata is separate follow-up tracking, not implementation of legacy repair or evidence of its completion.

Full `native_npc_review.tscn` remains failing on its preexisting ticket root/identity expectation before reaching the changed reduced section (raw failure retained). Its revised reduced expression is parser checked only within that entry; this review does not call that fixture passing. Current Main native and state/world/rig/clearance provide runtime coverage for the supported-source correction. MAIN-32 correctly tracks the obsolete root/four-frame fixture repair separately.

Skipped engine reruns, full suite, full legacy repair, final packaged three-mode playback and whole ART-17 signoff. Root's independently running final exact-byte embedded QA and media review remain delivery requirements; this bounded PASS does not substitute for them.
