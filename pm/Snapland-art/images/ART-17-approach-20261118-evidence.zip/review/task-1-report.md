# Task 1 report — ART-17 existing-source NPC approach fix

Status: complete and frozen for fresh review. Only owned production/test files changed; no commit, PM/runner/docs production edits, engine/cache run in C, package mutation, or subagents.

## Scope and contract inspection

Read the task brief, design/runtime/npc-approach-actions.md, plan Global Constraints, applicable pm-ticket instructions, and the authoritative actionable PROGRAM audit in .review/art-remaining-20261118.md.

Inspected the full call chain before editing: ParkWorld.interact emits interaction_requested; ParkWorld's internal connection selects the event; Main's _on_world_interaction_requested → _interact → _start_dialogue sets the world dialogue hold and flushes the pending event. The world process can also flush an event when unblocked. All callers of _on_interaction_requested, _play_pending_npc_interaction and set_dialogue_hold were searched. Main cancellation/close releases the hold. Unrelated non-NPC IDs return before selection; story completion reactions already explicitly request front. NpcActivity.greet/interact/request_action and _play_actor_action plus CharacterAnimationLibrary exact direction lookup, normalization, complete-sequence rejection and standing restoration were inspected. No changed requirement or need for a shared fallback was found.

The complete production change removes event-only player/root position quantization and requests front for the three existing role actions. Sprite validity remains checked. Walking quantization, library directions, source validation, hold scheduling and missing-source behavior are unchanged. No new assets, aliases, dependencies, options or production branches.

## Regression fixture

The existing Main fixture retains all 27 original _check calls, its real-time guide greeting/idle/pause/reduced-motion assertions, and byte-equivalent _finish capture → shutdown → queue_free → two-frame barrier → wait_for_release. The new bounded matrix covers ticket/guide/greet, imp/quest-001/interact and announcer/quest-002/interact from these actual player offsets:

| Approach | XZ vector, normalized before positioning |
|---|---|
| front | (0, 1) |
| front_right | (1, 1) |
| right | (1, 0) |
| back_right | (1, -1) |
| back | (0, -1) |
| back_left | (-1, -1) |
| left | (-1, 0) |
| front_left | (-1, 1) |

For reuse by Task 2: assign only the player position to the current actor root plus normalized XZ offset × 1.6 plus Y 0.1. Wait two actual physics frames and one process frame, then inspect world.nearest and call world.interact. No NPC root movement, nearest assignment, pending request injection, action-record/sequence/success injection or story-result injection is used. Original Progress.intro_seen=true is the sole stage story setup; no quest/photo changes are required. Cancelling quest dialogue follows Main's real cancellation callback and may update the isolated profile normally.

Each of the 24 interactions checks real nearest selection, actual held Main dialogue, expected finite complete front action with at least seven cels, visible full normalized canvas, frame/elapsed advance, finite return to looping standing while dialogue remains open, all three NPC roots and their interaction points preserved, and safe cancellation/route resume. Matrix timing advances the actual world's already-selected action through its existing _process and _sequence_seconds methods: 0.24 seconds for a later frame, then its sequence duration plus 0.05 to settle. This bounds runtime and does not substitute a different sequence. Original real-time checks still run unchanged before the matrix.

For each role, unsupported direct back_left requests remain false, explicitly report missing direction, and restore the visible complete baseline after a valid gesture. A fresh library uses the existing damaged-source test pattern: invalidate the final front action cel's manifest region before cache creation, then swap that provider only for the negative case. Actual proximity/world.interact/Main dialogue still opens and restores the complete standing baseline rather than retaining the preceding valid gesture. Front missing-source reporting and safe cancel are asserted; original provider is restored. This is a deliberate invalid source fixture, not an injected action result.

## Stage, launcher and commands

Private diagnostic runner: .review/npc-approach-20261118/task1_run.py.

New owned stage: D:/Snapland-QA/npc-approach-task1-20261118-0145. Created empty, filled via prepare_runtime_stage using git ls-files tracked runtime only; explicit tests added: test_npc_dialogue_hold.gd/.tscn, audio_playback_release.gd, test_npc_activity.gd, test_npc_animation_states.gd, test_npc_world_activity.gd, test_character_animation_library.gd, test_npc_departure_lifecycle.gd, test_npc_authored_source_walking.gd. No broad repository/untracked import or UID copy. Every copied source hash is in .review/npc-approach-20261118/stage-manifest.json. Subsequent sync copies only the two owned changed sources.

All engine invocations use tools.godot_entrypoints.run_validated_godot with exactly C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe and --headless --path D:/Snapland-QA/npc-approach-task1-20261118-0145. Import log reports Godot 4.7.2. Node fixture uses its real .tscn; SceneTree regressions use --script. SNAPLAND_SAVE_PATH is an absolute, unique per-command path beneath D:/Snapland-QA/npc-approach-task1-20261118-0145-profiles/<label>/progress.json. APPDATA and LOCALAPPDATA are also isolated under that profile, keeping any test-generated user:// images off C. Existing projects/packages/profiles were neither deleted nor mutated.

Reproduction commands from C:/Users/stanl/Github/Snapland:

```powershell
python .review/npc-approach-20261118/task1_run.py prepare
python .review/npc-approach-20261118/task1_run.py red verified
python .review/npc-approach-20261118/task1_run.py green
python .review/npc-approach-20261118/task1_run.py regressions
```

prepare is intentionally creation-only; the existing stage must not be reused for a new prepare. The red command was run before the production edit. Raw source snapshots preserve that ordering; rerunning red after the fix would naturally be green. Each <label>.json stores the exact command, save path, runtime, exit, marker count, error count and both launched source hashes; corresponding <label>.log is raw stdout+stderr.

## Actual RED/GREEN evidence

Evidence folder: C:/Users/stanl/Github/Snapland/.review/npc-approach-20261118.

| Label / raw log | Exit | PASS markers | ERROR markers | Seconds |
|---|---:|---:|---:|---:|
| import | 0 | 0 | 0 | 18.885 |
| baseline-dialogue | 0 | 28 | 0 | 7.501 |
| red-dialogue-verified | 1 | 231 | 67 | 8.787 |
| green-dialogue | 0 | 298 | 0 | 9.003 |
| green-test_npc_activity | 0 | 1 | 0 | 0.582 |
| green-test_npc_animation_states | 0 | 1 | 0 | 0.651 |
| green-test_npc_world_activity | 0 | 1 | 0 | 3.063 |
| green-test_character_animation_library | 0 | 1 | 0 | 4.991 |
| green-test_npc_departure_lifecycle | 0 | 1 | 0 | 2.134 |
| green-test_npc_authored_source_walking | 0 | 1 | 0 | 1.393 |

Marker counts are printed PASS occurrences, not a fabricated count of every dynamic assert in the six SceneTree fixtures. Final affected verification is 7/7 runtime fixtures, 304 total PASS markers, zero ERROR markers, no leaked/still-in-use messages. Baseline real-time original fixture is separately preserved.

The verified RED has all 24 actual proximity/dialogue-open checks passing. All 21 nonfront cases omit the expected action, cannot advance it, and have no looping standing action sequence after it: 63 expected action/lifecycle failures. The three damaged-source front-report assertions also fail because the unfixed world requests back_left rather than front. One final failure-summary ERROR gives 67 ERROR markers. This is a runtime failure through Main, not a library-only reproduction. The provisional first red-dialogue.log additionally contained an erroneous texture-membership assertion against frame dictionaries; that test assertion was corrected before red-dialogue-verified and before the production edit. Its raw receipt remains for transparency.

Baseline production SHA256 was 56cf0c6391eba5a1e0e36382a6db991e38d83d23619b3baf0e436772569bd2e0; verified RED uses that same hash. Baseline original fixture SHA256 was c637522644c8d1122802fbb871d8c645cbcae3e94af31ad4933347fd85c3adeb. *.baseline.txt, *.red.txt and *.green.txt preserve source snapshots as non-runnable text.

GREEN retains known world OcclusionController unsupported-material warnings already present in the baseline, and deliberately emits three invalid-final-cel warnings for the damaged-source tests. These are expected diagnostics. No ERROR, parser failure, timeout or resource-leak message occurred in the green logs.

## Self-review and freeze

Machine-checked self-review receipt: .review/npc-approach-20261118/task1-self-review.json. Every original _check line remains; original _finish body is byte-equivalent; seven green logs contain zero ERROR, leaked or still-in-use messages. Owned-file diff is preserved in .review/npc-approach-20261118/task1-owned.diff and reproduced below. World/library call contracts were re-read after the fix; no unrelated production branch or source-validation change was introduced.

Frozen final SHA256 (matches the launched GREEN sources):

| File | SHA256 |
|---|---|
| game/world/park_world.gd | f0c221dce3a71400300c37a67e0f1255be3b821a2b5a1a6d308483b32a8821c1 |
| game/tests/test_npc_dialogue_hold.gd | c8d4646d3251400435de7fd235e8a832ea6b02869e11dc7140092b80f2dffbef |

No fresh review has been performed by this worker; root owns the independent review/delivery gates. This task does not prove human gameplay, hearing, artistic naturalness, native normal/slow playback, packaged playback or whole ART-16/ART-17 completion. Matrix action advancement is deterministic simulation in the actual Main fixture; Task 2 owns native evidence. Full suite/CI was not run by this worker; affected local fixtures passed. Primary residual product limitation is unchanged: source actions remain front-only, and direct unsupported directions still correctly fail.

## Complete owned-file diff

```diff
diff --git a/game/tests/test_npc_dialogue_hold.gd b/game/tests/test_npc_dialogue_hold.gd
index 231c77a..faba3c2 100644
--- a/game/tests/test_npc_dialogue_hold.gd
+++ b/game/tests/test_npc_dialogue_hold.gd
@@ -2,6 +2,7 @@ extends Node
 
 const MainScene := preload("res://game/main.tscn")
 const Release = preload("res://game/tests/audio_playback_release.gd")
+const Library = preload("res://game/world/character_animation_library.gd")
 
 var _failures: Array[String] = []
 
@@ -100,9 +101,94 @@ func _run() -> void:
 	_check(is_equal_approx(float(_activity_record(main,"ticket").action_elapsed),reduced_elapsed), "reduced motion stops NPC frames after dialogue")
 	world.apply_settings({"reduced_motion":false})
 	print("DIALOGUE-HOLD measured: greeting %.3f→%.3f s; idle after close %.3f→%.3f s; announcer route remained at %s" % [dialogue_start_elapsed,dialogue_elapsed,post_close_elapsed,float(post_close_end.action_elapsed),str(route_origin)])
+	await _check_approaches(main)
 	await _finish(main)
 
 
+func _check_approaches(main: Node) -> void:
+	var world: Node = main.world
+	var activity: Variant = world.npc_activity
+	var approaches := {
+		"front": Vector3(0,0,1), "front_right": Vector3(1,0,1),
+		"right": Vector3(1,0,0), "back_right": Vector3(1,0,-1),
+		"back": Vector3(0,0,-1), "back_left": Vector3(-1,0,-1),
+		"left": Vector3(-1,0,0), "front_left": Vector3(-1,0,1),
+	}
+	for role in ["ticket", "imp", "announcer"]:
+		var point_id := "guide" if role == "ticket" else ("quest-001" if role == "imp" else "quest-002")
+		var action := "greet" if role == "ticket" else "interact"
+		var actor := _actor_record(main, role)
+		var actor_root := actor.get("activity_root") as Node3D
+		var sprite := actor.get("sprite") as Sprite3D
+		for approach in approaches:
+			var label := "%s/%s" % [role, approach]
+			await _approach(main, actor_root, approaches[approach])
+			_check(String(world.nearest.get("id", "")) == point_id, label + " real physics proximity selects its NPC")
+			var held_roots := {}
+			var held_points := {}
+			for other in world.character_sprites:
+				held_roots[other.role] = other.activity_root.global_position
+				held_points[other.role] = world._point_by_id("guide" if other.role == "ticket" else ("quest-001" if other.role == "imp" else "quest-002")).position
+			world.interact()
+			_check(main.modal_kind == "dialogue" and world.blocked and world.npc_dialogue_hold and activity.statistics().dialogue_hold, label + " actual interaction opens held Main dialogue")
+			var record := _activity_record(main, role)
+			var sequence: Dictionary = record.action_sequence
+			_check(String(record.action) == action and String(record.direction) == "front" and bool(sequence.get("available", false)) and not bool(sequence.get("loop", true)) and sequence.get("frames", []).size() >= 7, label + " selects the complete finite front action")
+			_check(sprite.visible and sprite.texture.get_size() == Vector2(activity.ACTION_CANVAS_SIZE), label + " displays a complete authored action canvas")
+			var start_elapsed := float(record.action_elapsed)
+			var start_texture := sprite.texture
+			# Advance the actual selected sequence; keep the original real-time checks above.
+			activity._process(0.24)
+			record = _activity_record(main, role)
+			_check(float(record.action_elapsed) > start_elapsed + 0.2 and sprite.texture != start_texture, label + " held action advances to a later authored frame")
+			activity._process(activity._sequence_seconds(sequence) + 0.05)
+			record = _activity_record(main, role)
+			_check(String(record.action) in ["stand", "idle"] and bool(record.action_sequence.get("loop", false)) and sprite.texture != null and main.modal_kind == "dialogue", label + " action ends in complete looping standing during dialogue")
+			for other in world.character_sprites:
+				var point: Dictionary = world._point_by_id("guide" if other.role == "ticket" else ("quest-001" if other.role == "imp" else "quest-002"))
+				_check(other.activity_root.global_position.distance_to(held_roots[other.role]) < 0.001 and point.position.distance_to(held_points[other.role]) < 0.001, label + " preserves " + String(other.role) + " root and interaction point")
+			main._cancel_dialogue()
+			await _frames(2)
+			_check(main.modal_kind == "" and not world.blocked and not world.npc_dialogue_hold and not activity.statistics().dialogue_hold and activity._player.is_playing(), label + " cancellation safely releases Main hold and resumes the route")
+		await _check_unavailable_action(main, role, point_id, action, actor_root, sprite)
+	print("APPROACH coverage: 3 roles × 8 distinct geometric offsets; real physics nearest/interact/Main dialogue; direct missing direction and damaged front source per role")
+
+
+func _approach(main: Node, actor_root: Node3D, offset: Vector3) -> void:
+	main.world.player.global_position = actor_root.global_position + offset.normalized() * 1.6 + Vector3(0,0.1,0)
+	await get_tree().physics_frame
+	await get_tree().physics_frame
+	await get_tree().process_frame
+
+
+func _check_unavailable_action(main: Node, role: String, point_id: String, action: String, actor_root: Node3D, sprite: Sprite3D) -> void:
+	var activity: Variant = main.world.npc_activity
+	await _approach(main, actor_root, Vector3(-1,0,-1))
+	_check(activity.request_action(sprite, action, "front"), role + " valid action can precede an unsupported direct direction")
+	activity._process(0.24)
+	_check(not activity.request_action(sprite, action, "back_left"), role + " unsupported direct direction remains unavailable")
+	var record := _activity_record(main, role)
+	_check(String(record.action) == "stand" and record.action_sequence.is_empty() and sprite.texture == record.baseline_texture and sprite.visible, role + " missing direct direction restores its complete standing baseline")
+	_check(activity.coverage_report().missing_requests[role].has(action + "/back_left"), role + " missing direct direction remains explicitly reported")
+	_check(activity.request_action(sprite, action, "front"), role + " valid gesture can precede a damaged front source")
+	activity._process(0.24)
+	var previous_library: Variant = activity._animation_library
+	var damaged := Library.new()
+	# Existing damaged-source mechanism: invalidate a later source cel before caching.
+	damaged.manifest.actors[role][action].front.frames[-1].region = [99999,0,10,10]
+	activity._animation_library = damaged
+	_check(String(main.world.nearest.get("id", "")) == point_id, role + " damaged-source check retains real proximity selection")
+	main.world.interact()
+	record = _activity_record(main, role)
+	_check(main.modal_kind == "dialogue" and main.world.npc_dialogue_hold, role + " damaged front source still opens actual Main dialogue")
+	_check(String(record.action) == "stand" and record.action_sequence.is_empty() and sprite.texture == record.baseline_texture and sprite.visible, role + " damaged front source restores the complete actor instead of retaining a gesture")
+	_check(activity.coverage_report().missing_requests[role].has(action + "/front"), role + " damaged front source remains explicitly reported")
+	main._cancel_dialogue()
+	activity._animation_library = previous_library
+	await _frames(2)
+	_check(main.modal_kind == "" and not main.world.blocked and not main.world.npc_dialogue_hold and activity._player.is_playing(), role + " damaged-source dialogue cancels and releases safely")
+
+
 func _actor_record(main: Node, role: String) -> Dictionary:
 	for record in main.world.character_sprites:
 		if String(record.role) == role:
diff --git a/game/world/park_world.gd b/game/world/park_world.gd
index d23c316..73649d7 100644
--- a/game/world/park_world.gd
+++ b/game/world/park_world.gd
@@ -2404,11 +2404,8 @@ func _on_interaction_requested(id: String, _label: String) -> void:
 		_: return
 	var actor_record := _npc_record_for_role(role)
 	var sprite := actor_record.get("sprite") as Sprite3D
-	var actor_root := actor_record.get("activity_root") as Node3D
-	if not is_instance_valid(sprite) or not is_instance_valid(actor_root) or not is_instance_valid(player): return
-	var target_delta := Vector2(player.global_position.x - actor_root.global_position.x, player.global_position.z - actor_root.global_position.z)
-	var direction := quantize_walk_direction(target_delta, "front")
-	pending_npc_interaction = {"sprite": sprite, "action": action, "direction": direction}
+	if not is_instance_valid(sprite): return
+	pending_npc_interaction = {"sprite": sprite, "action": action, "direction": "front"}
 
 func _play_pending_npc_interaction() -> void:
 	if pending_npc_interaction.is_empty() or not is_instance_valid(npc_activity): return
```
