# Task 1 independent review

Date: 2026-11-18. Reviewed package: `4319464..9ed34e6`, using the supplied frozen diff, Task 1 brief/report, `design/runtime/npc-approach-actions.md`, applicable `AGENTS.md` and pm-ticket rules, current source/callers, and recorded evidence under `.review/npc-approach-20261118`.

**Spec verdict: PASS. Code quality verdict: PASS. No actionable findings (P0–P3: 0). Task 1 may proceed to its next gate.** This verdict is limited to Task 1; it does not close the native evidence or final delivery gates.

## Spec compliance

| Requirement | Review result |
|---|---|
| Explicit existing front action at the world boundary | PASS. `game/world/park_world.gd:2395–2408` maps guide→ticket/greet, quest-001→imp/interact and quest-002→announcer/interact, then stores explicit `front`. Unrelated IDs still return; sprite validity is retained. Only event-specific player/root lookup and quantization are removed. Walking quantization and the existing explicit-front story reaction remain intact. |
| Preserve shared exact-direction and complete-source rejection | PASS. The supplied diff touches neither `npc_activity.gd` nor `character_animation_library.gd`. Their inspected request/get-sequence paths still use the requested direction and reject incomplete sequences. New negative cases exercise a missing `back_left` request for every role and a fresh provider with a damaged final front cel; each requires explicit missing reporting and visible complete baseline restoration after a valid gesture. |
| Real Main interaction from 3 roles × 8 approaches | PASS. `game/tests/test_npc_dialogue_hold.gd:109–161` sets only the player position relative to the current NPC root using eight distinct normalized XZ vectors, waits two actual physics frames and one process frame, reads real `nearest`, and invokes `world.interact()`. It does not assign nearest, pending requests, action records, selected sequences or success results. `Progress.intro_seen = true` predates this change; no quest/photo completion is fabricated. |
| Action, hold, position, completion and cancel coverage | PASS. Each of the 24 cases checks the correct finite available front sequence (at least seven cels), visible normalized canvas, later frame/elapsed advancement, return to looping standing while dialogue stays open, all three NPC roots and interaction points, and real Main cancellation releasing the hold and resuming the route. Matrix advancement calls the actual controller on its already-selected sequence, rather than injecting action state. |
| Preserve original assertions, MAIN-31 cleanup and marker | PASS. Independently compared the baseline snapshot with current source: all 27 original `_check` lines remain; `_finish` is text-equivalent, preserving capture→shutdown→queue_free→two-frame barrier→wait_for_release and `PASS: Main NPC dialogue hold lifecycle`. Original real-time dialogue, pause and reduced-motion checks run before the added matrix. |
| Meaningful baseline/RED/GREEN and relevant regressions | PASS on recorded evidence. Baseline succeeds on old production/original fixture. Verified RED uses old production plus the same final expanded fixture as GREEN: all 24 nearest and dialogue-open checks pass, while 21 nonfront cases fail selection/advance/standing (63 failures), plus three front missing-source-report failures and one summary ERROR. GREEN and all six regression fixtures succeed. |
| Restrict scope; no invented sources/fallback framework | PASS. The review diff contains only the owned world event and existing dialogue fixture. No new art, aliases, dependencies, config, production branches or generic direction fallback appear. Damaged-manifest/provider changes occur solely inside the negative fixture and the original provider is restored. |

The authority's native normal/slow, reduced-motion/reentry and isolated-package evidence belongs to Task 2 and the final review. Its absence from this Task 1 gate is not a Task 1 defect.

## Code quality and standards

No documented-standard violation or actionable quality defect found. The production fix is a small deletion plus an explicit event choice, matches `react_story_npc`'s existing front-action policy, and leaves scheduling, error handling and shared validation in their existing layers. Removing player/root guards is appropriate because this event no longer reads either object; target validation remains in both event selection and playback.

The fixture reuses Main, existing record/frame helpers and the established damaged-source mechanism. Direct inspection of private controller state is consistent with surrounding runtime tests and is used for assertions and bounded timing; it does not manufacture the selection being tested. Repeated role→point expressions are small and confined to this fixed three-role fixture; an extra mapping abstraction is not warranted for this patch. No speculative framework or unrelated cleanup was added.

The code-review skill's two axes were performed directly under the delegated task's explicit no-subagents restriction. PM/Git delivery is owned by the root task and was not changed or judged complete here.

## Evidence checked

Independently read receipts and raw logs, recomputed marker/error counts, checked their consistency, compared current bytes with GREEN snapshots and checked preservation of original assertions/cleanup. No engine or test process was launched by this reviewer.

| Recorded run | Exit | PASS markers | ERROR markers |
|---|---:|---:|---:|
| import | 0 | 0 | 0 |
| baseline-dialogue | 0 | 28 | 0 |
| red-dialogue-verified | 1 | 231 | 67 |
| green-dialogue | 0 | 298 | 0 |
| six GREEN NPC/activity/library/departure/walking regressions | all 0 | 6 total | 0 |

The final affected run is seven runtime fixtures and 304 printed PASS markers, not 304 independently enumerated test cases. Every inspected receipt uses absolute `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe`, a D-drive staged project, and a distinct absolute save path below that stage's `-profiles` directory. Raw logs identify `Godot Engine v4.7.2.stable.official.ed1daf0bf`. The private runner uses `run_validated_godot` and isolates APPDATA/LOCALAPPDATA as well. Seven GREEN logs have zero ERROR, parser/script-error, leaked or still-in-use messages. Existing occlusion-material warnings and three deliberate invalid-final-cel warnings are correctly described in the report.

Current source equals the recorded GREEN snapshot and launched GREEN hashes:

- `game/world/park_world.gd`: `f0c221dce3a71400300c37a67e0f1255be3b821a2b5a1a6d308483b32a8821c1`
- `game/tests/test_npc_dialogue_hold.gd`: `c8d4646d3251400435de7fd235e8a832ea6b02869e11dc7140092b80f2dffbef`

Baseline production equals the RED production snapshot/hash (`56cf0c6391eba5a1e0e36382a6db991e38d83d23619b3baf0e436772569bd2e0`); the verified RED receipt identifies the final expanded fixture hash above. The earlier provisional RED's corrected texture-membership assertion is disclosed and was not used as the decisive RED.

## Evidence limits and residual risk

No tests were rerun, and no engine, Git, PM or source mutation was performed. This review verifies supplied execution records and source behavior, not independent execution. The 24-case matrix advances action time deterministically; only the retained original guide checks establish real-time action progression here. Headless canvas/availability assertions establish technical completeness, not artistic naturalness, continuous human viewing, listening or human gameplay.

Native playback, packaged playback, Task 2 artifacts, full CI and whole ART-16/ART-17 art acceptance remain outside this review. The product intentionally continues to use existing front-only actions; direct unsupported directions remain unavailable. No additional Task 1 risk requiring a source change was identified.

Two-axis result: **Spec 0 findings; Standards/quality 0 findings; no blocking issue in either axis.**
