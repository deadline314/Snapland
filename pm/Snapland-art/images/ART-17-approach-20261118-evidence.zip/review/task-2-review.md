# Task 2 scoped review

Spec verdict: PASS for the native fixture implementation and the recorded normal/reduced/path-negative evidence reviewed here. Code-quality verdict: PASS; no actionable findings. This is not a completion verdict for Task 2 delivery or ART-17.

Reviewed task-2-brief.md, task-2-report.md, review-9ed34e6..a07131d.diff and the authority design/runtime/npc-approach-actions.md. Read the live fixture, TestSaveGuard, shared audio release helper and relevant NpcActivity reduced-motion/dialogue behavior. This review made no source, PM, Git, engine or evidence mutations and launched no engine/tests. Only this review report was written.

## Contract checks

- The fixture uses the actual Main scene, live NPC roots, player-only back-left placement, real physics proximity and parsed E/Escape key events for ticket, imp and announcer. No NPC-root placement, nearest assignment, action/sequence/result injection or manual process advancement was found.
- Each real event must select a finite complete front source, render multiple matching authored action cels, return to authored front idle, retain the dialogue and all NPC roots/interaction points, and release the route after Escape. The fixture reuses shared timing and the existing announcer costume composition rather than rebuilding production animation logic.
- Scripted camera/player placement, hidden hero and disabled world camera-follow physics are disclosed. Screenshots use actual post-draw frames, alpha-based viewport/plaque bounds and a geometry ray. Independently inspected the three frozen-normal intermediate-action PNGs: each NPC's full body, head and feet are visible above the plaque. The ray and these stills do not establish continuous occlusion-free animation or artistic acceptance.
- Quarter mode sets Engine.time_scale to 0.25. Rebuild frees Main through audio shutdown, frame barriers and shared release wait before instantiating a fresh Main. Reduced mode first proves the normal finite action/idle transition, then enables the existing setting and verifies the complete authored standing baseline and frozen clock. This matches current NpcActivity semantics.
- Headless/path/mode/output-reuse rejection precedes Main creation/reset. Existing save files/directories are rejected; shared save protection and the additional project/output checks are reused. Output remains bounded to role/pass action/idle PNGs and scalar receipt data; no frame-image accumulation is present.
- Main teardown and shared playback-release verification precede receipt status and the exact final marker. Failures suppress the final marker and force a nonzero exit. Ordinary player export and shared production source are outside this diff.
- The added wardrobe coverage text distinguishes existing authored sources/event selection from new art and acceptance. It does not expand this task into missing-direction or whole-art signoff.

## Recorded evidence checked

- frozen-normal.json and reduced-selfcheck.json launch through the private runner's run_validated_godot path with Godot 4.7.2, Windows Compatibility rendering, Dummy audio and distinct absolute isolated save/output paths. Each exits 0 with 46 PASS lines and zero ERROR lines. Their actual JSON reports contain three roles, six captures, no failures, technical_status PASS, human_played false and complete_acceptance false.
- Both raw logs contain exactly one `PASS: native NPC approach actions and idle recovery`, after the audio-release and receipt-write checks. Existing unsupported-material warnings are disclosed; no leak/still-in-use failure is represented as successful playback.
- Each of the five recorded negative receipts exits 1 and its raw log contains zero final completion markers. Those launches used fixture SHA256 f80576feb225d7e6c4b911b3b062d9d66ffaf263fbd0b3b70e7f2acb232eb570, not the final normal/reduced bytes. The worker explicitly discloses this boundary.
- The reviewed frozen-normal/reduced fixture hash is a62a083b271220ac703a1680fd090402905d06f476a03b3187c1c79a013824a7; the scene is d30baef5279db7e01757542e4d9d6d8e4e79141ca03ef98648ae255b17d30acd and unchanged release helper is 1b61bba4e5c54e38050e8ba0b7170b18848198928937ca2c4dfdebc31cc37184. Independently checked these against the workspace before the formatting-only update.
- During review the original worker removed trailing blank whitespace. The current fixture hash is a697e16254f31c3175a316fac0b0e8db49935007bfb5a1e63c96dcf8d4f735e6. Independently compared the supplied diff's added fixture body against the current file: identical after trailing-whitespace removal. The old receipts remain old-byte evidence and must retain their original hashes.

## Evidence limits and delivery gate

Root reports its old-byte quarter/rebuild, reduced/rebuild and embedded checks have passed, but those independent packages/captures and final exact-byte rebuild are outside the three supplied review inputs and were not audited here. Final MP4 playback review, final-byte embedded package receipts/hashes, PM delivery, integration/CI and whole-branch review remain root-owned gates. This review neither marks them complete nor replaces them.

Skipped engine reruns, continuous human viewing/play/listening, the full suite and new art acceptance. Residual risk: scripted close framing and representative back-left native evidence do not prove natural-camera or all-direction artistic quality; Task 1 and root's independent final delivery retain their separate coverage obligations.
