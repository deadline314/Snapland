# Task 3 report — reduced-motion formal standing

Source review base: `115f57c`. Authority: `design/runtime/npc-approach-actions.md` reduced addendum and plan Global Constraints. Worker performed no Git mutations, PM/docs/runner changes, subagents, package edits, cleanup deletion, or external messages. Root owns packaging, final three-mode QA, review, PM and Git. Parent explicitly expanded ownership for supported-source expectations in `test_sprite_clearance.gd`, `test_npc_walk_motion.gd`, and `native_npc_review.gd`.

## Root cause and scope

`ParkWorld.apply_settings` calls `NpcActivity.set_reduced_motion`. Its enable path paused AnimationPlayer and called `_restore_baselines` → `_restore_record`, restoring the registration texture/material/UV, root, interaction point and patrol. Registration captures the legacy initial complete Sprite before selecting formal standing. Announcer's legacy initial Sprite is a right-walking cel. Equality with that baseline proves restoration, not standing; the rejected screenshot visibly shows this defect.

The only production change adds a loop after existing baseline restoration to request existing `stand/front` with reset=true for active records. `_play_actor_action` already chooses validated stand/idle/idle_stand, normalizes the complete canvas, applies role costume and shader full-canvas UV, and fails closed to the complete baseline with `stand/front` missing telemetry. No action lookup, alias, normalization, fallback or asset API changed. `_restore_record` itself is unchanged because release and tree-exit teardown also call it. Root/point restoration, shader freeze, optional rig pause/hide, missing/damaged-source behavior and teardown remain their existing owners.

Caller search covered all `set_reduced_motion`, `_restore_baselines`, `_restore_record`, `_play_actor_action`, reduced/baseline/texture/material/UV references across game scripts. Production callers: world settings; internal release and actor exit for `_restore_record`; action API, registration, patrol, dialogue hold, motion routes, idle/finite completion for `_play_actor_action`. Only setter enable is changed. Related regressions cover state/world/activity, sprite clearance, optional rig, departure, authored walking/patrol, direction lifecycle and actual Main dialogue. Native old fixture and current approach fixture contained incorrect supported-source baseline assertions. Other hits were unrelated component/avatar/attraction systems. `test_npc_activity.gd` intentionally injects a missing library; its original complete baseline/material/UV assertions remain byte-for-byte unchanged.

## Actual RED before production edit

Raw logs and exact source snapshots are in `.review/npc-reduced-stand-20261118/`:

- `red-test_npc_animation_states.log`: actual assertion `ticket reduced motion selects formal front standing` failed at line171. SceneTree coroutine assertion leaves engine running; bounded45s owned-process timeout captured the error. Original production SHA256: `94c65089fc0c6222bdf9b6dca2777ec4ca1da9c1892ed14661b11cda094d8afc`.
- `red-test_npc_world_activity.log`: four actual formal standing errors from the added helper. Exit0 and one old PASS marker were rejected because ERROR count4; demonstrates why marker/exit alone is insufficient.
- `*.red.txt` preserve exact tested state/world/native predicate and original production sources. Stage was prepared/imported before changing production.

First post-fix state run exposed my damaged-source check placed after the existing actors had been freed (`green-test_npc_animation_states.log`). I moved only the new check before existing teardown; old absence/release assertions remain. First/second post-fix world runs exposed an old immediate-resume expectation of legacy `record.frames[0]` (`green*-test_npc_world_activity.log`); corrected supported-source resume to formal current standing rather than resurrecting the legacy walking cel. All failure logs remain. Early receipts originally hashed at process completion; final runner captures launch hashes. The old world run overlapped final state-fixture copy without changing the world/runtime bytes, so only final green3/green receipts are authoritative final-source receipts.

## Assertion semantics

- Previously supported-source reduced checks equated registration baseline with standing; now state asserts all3roles have formal available stand/front, neutral first complete cel, frozen elapsed, repeated enable, active interaction/walk interruption, pause/dialogue hold, pixel size and safe resume.
- World independently loads the real library's formal idle/front first cel for all3roles and compares exact pixel bytes, canonical320×460 canvas, announcer costume output, current stand/front/time0, shader source/full UV and shader motion0. Original root/point, dialogue/pause, idle counts, ground, absence and marker assertions remain.
- Damaged formal stand+idle sources after a valid gesture restore the baseline, clear sequence, record missing `stand/front` and remain frozen. Existing missing-library3role checks unchanged and passing.
- Sprite clearance still checks size/flip/root/gesture baseline, full silhouette, foot row and terrain/shadow safeguards; formal source/material/UV and immediate formal resume replace legacy visual assumptions.
- Optional rig test still checks3role Sprite visible/rig hidden, frozen root/shader and resume; announcer formal source pixel bytes include existing bounded costume treatment.
- Current native `_source_matches` no longer has a reduced-motion baseline shortcut. Exact formal timeline/canvas/costume comparison runs in reduced mode too. Re-read record after settings because enable resets the standing action elapsed; frozen comparison starts from the actual post-transition state. Receipt says frozen complete authored front standing sequence.

## Execution isolation and commands

Private script: `.review/npc-reduced-stand-20261118/run.py`. Stage: `D:/Snapland-QA/npc-reduced-stand-20261118-c30b1ba5`. Built using `prepare_runtime_stage` from tracked runtime files plus exact fixture/helper allowlist, never whole-repo/C cache copy. Initial/final manifests retain file fingerprints. All engine launches go through `tools.godot_entrypoints.run_validated_godot`, exact executable `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe`, with independent absolute D save, APPDATA and LOCALAPPDATA per label. No player saves used.

Invoked commands (every exact engine command/environment/timeout result is in same-label JSON):

```text
python .review/npc-reduced-stand-20261118/run.py prepare
python .review/npc-reduced-stand-20261118/run.py red
python .review/npc-reduced-stand-20261118/run.py green
python .review/npc-reduced-stand-20261118/run.py green2
python .review/npc-reduced-stand-20261118/run.py green3
python .review/npc-reduced-stand-20261118/run.py regressions
python .review/npc-reduced-stand-20261118/run.py native
python .review/npc-reduced-stand-20261118/run.py legacy
python .review/npc-reduced-stand-20261118/report.py
```

## Final results

| Label | Exit | PASS markers | ERROR | Seconds |
|---|---:|---:|---:|---:|
| green3-test_npc_animation_states | 0 | 1 | 0 | 0.988 |
| green3-test_npc_world_activity | 0 | 1 | 0 | 3.648 |
| green-test_npc_activity | 0 | 1 | 0 | 0.92 |
| green-test_npc_walk_motion | 0 | 1 | 0 | 7.465 |
| green-test_sprite_clearance | 0 | 1 | 0 | 11.303 |
| green-test_npc_departure_lifecycle | 0 | 1 | 0 | 2.227 |
| green-test_npc_authored_source_walking | 0 | 1 | 0 | 1.402 |
| green-test_character_animation_library | 0 | 1 | 0 | 5.142 |
| green-test_npc_walk_direction_lifecycle | 0 | 1 | 0 | 1.319 |
| green-test_authored_npc_patrol | 0 | 1 | 0 | 0.573 |
| green-dialogue | 0 | 298 | 0 | 8.891 |
| green-native-reduced | 0 | 90 | 0 | 21.12 |

All11 final headless suites pass with zero ERROR. Actual Main dialogue preserves all original assertions plus three-role/eight-direction coverage (298 PASS markers). GPU current Main reduced+rebuild smoke has90 PASS markers, final exact success marker, technical_status=PASS, no failures,6 role/pass rows,12 screenshots, all reduced idle elapsed0. Native source output: `D:/Snapland-QA/npc-reduced-stand-20261118-c30b1ba5-native-reduced`.

Viewed rejected `D:/Snapland-QA/20261118-npc-approach-qa-58632e77/reduced-rebuild/captures/announcer-pass1-idle-reduced.png` and new `announcer-pass1-idle-reduced.png`. Old capture shows right-walking stride; new capture visibly shows formal front standing with planted boots and the formal body scale. This is static image inspection and scripted native evidence, not human play/continuous watching/listening or whole ART17 approval. Root must review final exact-byte three-mode embedded QA/media separately.

Legacy import parser check (`legacy-import`) exits0, zero ERROR. Full old `native_npc_review.tscn` is explicitly **not passing**: `legacy-native-preexisting-failure.log` exits1 with ticket label/root identity mismatch (old expected -5,0,10 vs current -3.8,0,5) before reaching the updated reduced section. Its obsolete root/four-legacy-frame assumptions remain unchanged; no bypass/fake PASS harness. Narrow revised reduced expression is parser checked but not runtime reached there; actual equivalent runtime is covered by current Main native + state/world/rig/clearance. Root opened MAIN32 for full legacy fixture repair.

## Final SHA256

- `game/world/npc_activity.gd`: `a3caa0a6a417e1512ea537999942dc37ef435c3c70c95ee1f1e002ede28f7a30`
- `game/tests/test_npc_animation_states.gd`: `fbb87b20c4b935fdf5ca903be4f55887d1efc47524574fd041e65c04eb5fa7cf`
- `game/tests/test_npc_world_activity.gd`: `9b7a834045d8240bd6003bde164a1ac3a55db804710f3f7756e2a54ee6392d34`
- `game/tests/native_npc_approach_review.gd`: `ab35a966de8a566ef8af126eb65eb59bc6d774132b1858a293df452b601921d3`
- `game/tests/test_sprite_clearance.gd`: `56aaf3f11bc60385e5e3b20a3458bb65bdd158ef3b42f3ac9c2e3ab1b32ec593`
- `game/tests/test_npc_walk_motion.gd`: `8b4f510f3b3597b582df2c90d67fbafbb964bcd48f94c818bbc87d6fde4d075a`
- `game/tests/native_npc_review.gd`: `95368df30dda7ce8fd01c24b76021e1375fb2c7dbf49adfbd075817c97d474eb`

`*.final.txt`, `task3-owned.diff`, `task3-self-review.json`, and `final-stage-manifest.json` freeze final reviewed inputs. Self-check verified every final source matches repository, D-stage and final receipt hashes, all final logs have zero errors/success markers, and native receipt/capture counts and flags are consistent. `git diff --check` for owned files passes (Git only emits existing newline normalization notice on approach fixture).

## Self-review and limits

Production diff is3 lines; reuses existing action validator and existing independent source contract, adds no assets/dependencies/options/helpers to runtime. Inactive records are skipped. Missing source fails closed; release/tree exit restoration untouched. Shader pause/hide ordering inspected: rig `set_paused`→`_deactivate` changes visibility only, leaves selected formal texture intact; optional rig test actually passes. Root/point reset remains before formal visual selection. No known player-facing correctness issue remains in this bounded change.

Skipped full suite, full legacy fixture repair, package/export, normal/quarter final re-record, manual continuous playback/listening and whole ART17 acceptance; root owns delivery and final review. Remaining risk/limitation is the explicitly failing obsolete legacy native fixture and final package still requiring root's exact-source media verification.


---

# Final fix wave — native clearance formal-standing caller

Reviewed finding: `.superpowers/sdd/2026-11-18-npc-approach-actions/final-review.md`, Important P2, review head `4c44b12`. Only source changed: `game/tests/native_sprite_clearance_review.gd`. Production, assets, prior seven task3 files, accepted approach fixture/scene/audio helper, PM, runner and Git untouched. This corrects the prior task3 report's overly broad completeness claim: native clearance's own `_run` was missed and is a distinct caller from MAIN32's parent legacy path.

## Fix and preserved guards

The existing directly callable `_review_reduced_motion_npcs` now obtains the real formal `idle/front` sequence through the existing activity source library and normalizer, requires it available/nonempty, validates the declared feet anchor448, applies existing announcer costume, and expects that exact neutral standing texture with full-canvas material UV. Reduced and paused-resume checks require `stand/front`, elapsed0 and synchronized source/material. Old baseline texture/material/UV expectations are removed only from this section.

The unchanged full-body, fixed320×460 canvas, RGBA8, pixel size, root/anchor/contact, billboard/ordinary opaque depth, scene geometry coverage, visibility and error paths remain. No tolerances in contact or depth were changed and no failure was skipped. The source-foot condition now requires exact formal opaque last-row equality, never below declared anchor448, and anchor-minus-lastrow<=1, matching the existing headless source-foot precedent. The declared registered guarded row448+guard and all actual world contact math remain unchanged.

Why the foot condition also needed correction: independent fresh `CharacterAnimationLibrary` diagnostics for all3roles returned RGBA8 format5, size320×460, last alpha>=0.5 row447, declared feet anchor[160,448]. Old equality to legacy row448 confused the anchor edge with the opaque pixel row. Existing headless `test_sprite_clearance.gd::_assert_npc_frames_share_feet_baseline` already requires source bottoms<=ACTION_FEET_ROW and variation<=1. Root explicitly authorized exact formal row equality plus <=anchor and <=1px gap; arbitrary floating-source gaps remain rejected.

## Actual RED/GREEN and bounded execution

Private evidence: `.review/npc-reduced-stand-20261118/finalwave/`. New D stage: `D:/Snapland-QA/native-clearance-finalwave-20261118-2b23a11a`, built with `prepare_runtime_stage` from tracked runtime plus exact test/helper allowlist. All engine starts use `tools.godot_entrypoints.run_validated_godot` and exact `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe`. Every save, APPDATA, LOCALAPPDATA, TEMP and TMP is independently isolated onD, recorded in same-label JSON. No repository import/player profile or frozen package was mutated.

Commands:

```text
python .review/npc-reduced-stand-20261118/finalwave/run.py prepare
python .review/npc-reduced-stand-20261118/finalwave/run.py red
python .review/npc-reduced-stand-20261118/finalwave/run.py green
python .review/npc-reduced-stand-20261118/finalwave/run.py diagnose
python .review/npc-reduced-stand-20261118/finalwave/run.py green2
python .review/npc-reduced-stand-20261118/finalwave/run.py final
python .review/npc-reduced-stand-20261118/finalwave/report.py
git diff --check -- game/tests/native_sprite_clearance_review.gd
```

Exact engine commands, source hashes, profiles, durations and raw output are retained per label. The full-entry target is real `res://game/tests/native_sprite_clearance_review.tscn`. Since it fails an earlier unrelated guard, a clearly labeled private Node scene `res://game/tests/finalwave_reduced_probe.tscn` inherits the real published child, creates genuine Main with the child's ordinary setup, and invokes the actual inherited `_review_reduced_motion_npcs`. It copies no method logic, overrides no body/depth/failure methods and injects no source or success results. Its success marker explicitly says **section only**, never full-entry PASS. Probe source is frozen as `probe-source.txt`.

- Actual original-child RED: full entry fails earlier announcer legacy frame2 rendered-depth coverage307/47406; raw `red-full-entry.log`, exit1/1ERROR. Its separate real method invocation reaches the P2 defect and rejects correct ticket formal standing at old baseline comparison; `red-reduced-section.log`, exit1/1ERROR, old child hash `b9a9d8972b60147442ea381b53f10d84d693368f39e2018461dfabf374ccacb1`.
- First corrected source expectation passes the old mismatch then exposes exact legacy opaque row448 assumption; `green-reduced-section.log` and `diagnose-reduced-section.log` retain failures. Fresh independent source measurements above establish the proper row447/anchor448 convention. No guard was silently removed.
- Final method GREEN: `final-reduced-section.log`, exit0/0ERROR, exactly one `PASS: existing native clearance reduced-motion section only`. All3roles complete source/layout/feet/contact/depth/capture and paused-resume checks. Depth reports zero covered body pixels: ticket0/46215, imp0/29752, announcer0/26749. Three actual PNGs saved under final-reduced-section profile `captures/`; hashes and depth JSON are audited in `final-audit.json`.
- Final **full entry remains failing**, `final-full-entry.log`, exit1/1ERROR, same preexisting announcer frame2 depth307/47406 before reduced section. Published entry retains that guard unchanged. No full-entry success, human play, continuous playback or art approval is claimed. Separate full legacy debt remains root-owned; no unrelated repair was attempted here.

## Frozen source proof and self-review

Final child SHA256: `6526bcf3f35e4dd36e864fdd98748e8dd058f689d5bbf80d1762e3f38872f225`. Matches repository, isolated stage and final full-entry/section receipts. `child.red.txt`, `child.final.txt`, `final-owned.diff` preserve exact inputs. `git diff --check` passes.

Runtime/accepted QA/prior-source before=after SHA256, checked at every launch and final audit:

- `game/world/park_world.gd`: `f0c221dce3a71400300c37a67e0f1255be3b821a2b5a1a6d308483b32a8821c1`
- `game/world/npc_activity.gd`: `a3caa0a6a417e1512ea537999942dc37ef435c3c70c95ee1f1e002ede28f7a30`
- `game/tests/native_npc_approach_review.gd`: `ab35a966de8a566ef8af126eb65eb59bc6d774132b1858a293df452b601921d3`
- `game/tests/native_npc_approach_review.tscn`: `d30baef5279db7e01757542e4d9d6d8e4e79141ca03ef98648ae255b17d30acd`
- `game/tests/audio_playback_release.gd`: `1b61bba4e5c54e38050e8ba0b7170b18848198928937ca2c4dfdebc31cc37184`
- `game/tests/test_npc_animation_states.gd`: `fbb87b20c4b935fdf5ca903be4f55887d1efc47524574fd041e65c04eb5fa7cf`
- `game/tests/test_npc_world_activity.gd`: `9b7a834045d8240bd6003bde164a1ac3a55db804710f3f7756e2a54ee6392d34`
- `game/tests/test_npc_walk_motion.gd`: `8b4f510f3b3597b582df2c90d67fbafbb964bcd48f94c818bbc87d6fde4d075a`
- `game/tests/test_sprite_clearance.gd`: `56aaf3f11bc60385e5e3b20a3458bb65bdd158ef3b42f3ac9c2e3ab1b32ec593`
- `game/tests/native_npc_review.gd`: `95368df30dda7ce8fd01c24b76021e1375fb2c7dbf49adfbd075817c97d474eb`

Only one production-independent caller contract changed; the final opaque-foot restriction rejects pixels below448 or farther than1px above the anchor, and exact expected formal source/normalizer validation remains. Existing body/depth/contact methods are unmodified and executed by the final section. Prior successful embedded package runtime inputs are byte-identical; no export or broad/full-suite rerun was needed or performed.

Skipped full-suite, re-export and unrelated earlier-depth/full-legacy repair. Remaining limitation: published full clearance entry still fails before this now-passing section at the retained frame2 geometry guard; report and evidence expose it explicitly.
