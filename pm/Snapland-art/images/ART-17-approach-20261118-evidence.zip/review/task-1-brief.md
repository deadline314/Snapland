## Task 1: Correct world selection and actual interaction regression

**Ownership:** game/world/park_world.gd and game/tests/test_npc_dialogue_hold.gd only; private diagnostic scripts/logs under .review/npc-approach-20261118 and new owned D stage. Root docs/runner/PM/Git not owned.

- [ ] Inspect all callers of the touched world interaction selection and existing source contracts before editing. Capture baseline local dialogue suite.
- [ ] Add focused coverage to the existing Main dialogue fixture: all three roles (ticket/guide/greet, imp/quest-001/interact, announcer/quest-002/interact), eight distinct geometric player-relative approach vectors. Use real world.nearest/world.interact and Main dialogue flow; do not write pending request, activity record, sequence, success, or nearest result to manufacture passing behavior. Allow real physics proximity and document any stage-state setup. Assert correct complete front action, hold/position preservation, action advance/end and safe cancel; preserve every old assertion. Keep runtime bounded, reuse existing routines rather than duplicate a framework.
- [ ] Before production edit, run meaningful RED showing side/back interactions open dialogue yet omit expected action. Save source snapshot, command, save path and raw logs.
- [ ] Minimal production fix selects existing front at world event boundary and removes unused position quantization only for this event. Leave shared exact-direction/fail-closed library untouched. If inspecting callers reveals a different requirement, report before changing scope.
- [ ] GREEN original plus new fixture; relevant NPC world/action/library/missing-source/departure regressions; explicitly prove unsupported direct directional request still fails and complete standing restores, including damaged front source via existing test mechanism when feasible. Avoid adding unrelated production branches.
- [ ] Write report with final hashes, actual RED/GREEN, commands, test counts and limitations. Freeze sources for fresh task review; no commit by worker.

