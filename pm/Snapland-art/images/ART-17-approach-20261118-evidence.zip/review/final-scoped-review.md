**P2: Native clearance reduced-motion and paused-resume expectations** — **ADDRESSED**. `game/tests/native_sprite_clearance_review.gd:153` obtains and normalizes the real formal `idle/front` source, rejects unavailable/empty sequences, applies the existing announcer costume, and validates the declared foot anchor. Lines 163–167 replace all three old baseline expectations with the formal source and full-canvas UV. Lines 181–202 require `stand/front`, elapsed zero, exact source/material synchronization, canonical dimensions/RGBA8, normal depth, visible body and ground contact. Lines 217–224 retain the same formal source/state/full UV after disabling reduced motion while activity remains paused.

### New Breakage in the Fix Diff

None found. The only source diff is this child fixture's reduced-motion section; the additional MAIN-33 ticket records the separately reproduced earlier geometry failure. No published entry or body/contact/depth/failure helper was bypassed or modified.

### Checks

- Read the supplied `4c44b12..e16cbc5` diff once, original Important finding, authority design, fix report, affected method and directly used normalization/costume/synchronization/geometry helpers. No Git or engine commands ran.
- Checked the foot-row calibration against code and retained diagnostic output, rather than treating authorization as a waiver. All three fresh formal sources report RGBA8, 320×460, bottom row 447 and declared feet `[160,448]`. The new condition at `game/tests/native_sprite_clearance_review.gd:190` requires exact formal expected bottom, forbids pixels below row 448, and permits at most one row above it. This fits the existing `game/tests/test_sprite_clearance.gd:86`–94 convention. The registered guarded row, `CONTACT_EPSILON`, visible-pixel floor check and rendered depth coverage remain unchanged in the actual called helpers.
- Read the private probe: it inherits the published child, creates genuine Main, uses the child's ordinary paused world setup, and directly awaits the inherited `_review_reduced_motion_npcs`. It copies no reviewed method or success/geometry logic and overrides no guard. Its explicit section-only success follows all three roles and the paused-resume loop.
- Read RED, intermediate foot-row failure, diagnostics and final GREEN raw logs and receipts. RED rejects ticket's formal standing at the old baseline comparison (exit 1, one ERROR). Final GREEN has exit 0, zero ERROR and exactly one section-only PASS; actual rendered coverage is ticket 0/46215, imp 0/29752 and announcer 0/26749. The final receipt records an isolated absolute save/profile and the required Godot 4.7.2 executable. This verifies the affected section, not full-entry completion.
- Independently hashed the current and staged child: both match final receipt `6526bcf3f35e4dd36e864fdd98748e8dd058f689d5bbf80d1762e3f38872f225`. Staged probe matches its retained source. All ten recorded frozen repository inputs match; the four of those included in the bounded stage also match. The three retained reduced captures match their audit hashes. Runtime and accepted approach QA inputs remain unchanged, supporting the decision not to re-export the previously accepted package.

### Out-of-Scope Observations

- Known non-blocking MAIN-33 debt: both original-child RED and final-child full-entry logs fail before this section at announcer frame 2, with the identical 307/47406 rendered body pixels covered. The original `_review_npc_frames`/depth path is outside this fix diff. MAIN-33 remains pending and preserves the full guards; this scoped verdict does not certify that entry or repair MAIN-32.

### Verdict

**Fix round: All findings addressed, no new Critical/Important breakage.** No open finding from this scoped fix review.

Skipped engine/test reruns, broad review, continuous media/art approval and re-export. Remaining risk: the published full clearance entry still stops at the separately tracked earlier geometry failure; only the actual reduced-motion section has GREEN evidence here.
