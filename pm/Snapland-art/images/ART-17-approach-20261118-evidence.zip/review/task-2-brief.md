## Task 2: Native existing-source evidence and delivery

**Ownership:** fresh worker only new game/tests/native_npc_approach_review.gd and .tscn plus private logs; root packaging/PM/Git/docs. Depends on reviewed Task1.

- [ ] Minimal scripted Main fixture reuses current actor/library/capture conventions, actual E input/nonfront proximity for all three roles; captures real intermediate authored actions then complete idle, checking held root position, correct texture/direction and finite sequence. Normal and true quarter-speed timeline; reduced-motion/reentry option only if needed by existing harness conventions. No NPC-root movement, manual action/sequence/result injection or duplicate production implementation.
- [ ] Output caller-save-folder receipt/screenshots with explicit scripted camera/player placement and no human acceptance claim. Use shared audio release capture/shutdown/free/barrier/wait for clean exit; independent source allowlist includes helper.
- Native QA interface follows existing island fixture user args: `--animation-output=<new absolute empty directory>`, `--quarter` (Engine.time_scale=0.25), `--reduced-motion`, `--rebuild`. Receipt `npc-approach-report.json` and role/action/idle PNGs inside that output; modes preserve unmodified NPC roots, actual dialogue and source checks. Exact final marker `PASS: native NPC approach actions and idle recovery`; technical_status=PASS only if no failures, complete_acceptance=false, human_played=false. Reject headless, nonabsolute/unsafe save or output paths, conflicting modes and reuse of nonempty output. Ordinary player export stays unchanged. Root records using MovieMaker30FPS then encodes MP4; no per-frame PNG dump or memory-accumulated frame list.
- [ ] Root runs/reviews normal/quarter/reduced/reentry captures, independent embedded Windows QA and exact source hashes. Preserve failures honestly. Fresh task review then most-capable whole-branch review.
- [ ] Root appends bounded ART17 Commit entry, keeps whole ticket in progress and unchecked art criteria; evidence zip/representative screenshots, affected checks and design links. Commit/push, fetch/rebase/latest main integration, CI, own delivered branch cleanup.

## Rulings

- Fixed front is the smallest current authored event policy; generic available-direction selection is unnecessary while all three actions have only front approved sources. Shared direction lookup stays strict, so future missing assets remain visible.
- ART17 exists and is in progress: this is a partial delivery of its interaction transition requirement, not a new ticket or full artistic signoff.
