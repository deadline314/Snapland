# Whole-branch final review — NPC approach actions

Reviewed base `3ca0b9c`, head `4c44b12`, supplied whole-branch diff, `design/runtime/npc-approach-actions.md`, implementation plan, progress ledger, all three task reports/reviews, affected source and callers, ART-17 delivery and MAIN-32 opening. Used the requested senior code-review template. This report is the only review mutation; no source, PM, Git, engine, test, worktree or subagent operations were performed.

## Strengths

- `game/world/park_world.gd:2395` makes the event policy explicit at the correct boundary. The three real world interactions select existing complete front sources; walking direction quantization, exact-direction source lookup and source validation are untouched. Removing unused player/root reads is appropriate.
- `game/world/npc_activity.gd:311` preserves baseline root/point/patrol restoration and reuses the existing validated action path to select formal standing before shader/rig freeze. Missing or damaged standing still uses the existing complete visual fallback and reports the missing request. Release and actor-exit restoration remain unchanged.
- The actual Main regression covers three roles and eight geometric approaches, preserves the original dialogue assertions and audio-release ordering, and includes direct unsupported directions and damaged final action cels. The native fixture uses real proximity and E/Escape input, shared timing, real rendered source checks, disclosed camera/player staging and bounded captures.
- The reduced-motion acceptance correction is substantive: old baseline-equality evidence was rejected, meaningful source-based failures were retained, and new final exact-source native evidence checks formal standing. No art, dependency, alias or generalized fallback was added.
- Documentation and ART-17 distinguish available sources, current behavior and artistic acceptance. The ticket remains in progress; the evidence does not claim human play, hearing or full artistic approval.

## Issues

### Critical

None found.

### Important — one P2 integration finding

**P2: Update the native clearance caller's reduced-motion expectations with the new standing contract.**

- Location: `game/tests/native_sprite_clearance_review.gd:153` (expected-state construction), consumed at lines 170 and 205–213. The triggering production change is `game/world/npc_activity.gd:317`.
- The clearance fixture still records `record.baseline_texture`, `baseline_shader_texture` and `baseline_shader_uv_rect` as the expected reduced pose. Enabling reduced motion now intentionally replaces those legacy registration visuals with the formal `stand/front` sequence. Consequently the check at line 170 rejects the correct new source. Its resume checks also require the old baseline, although this fixture keeps activity paused and therefore retains the formal standing frame after disabling reduced motion.
- This is a missed dependent contract, separate from MAIN-32's known obsolete root/four-frame checks. The clearance scene overrides `_run` and invokes its own `_review_reduced_motion_npcs`; it does not rely on the parent's failing `_review_role` path. Once this section is reached, the source mismatch follows directly from the setter and fixture code. This review did not execute the entry, so it does not claim where an entire current run would first fail.
- Impact: an existing native clearance acceptance path rejects the intended behavior and cannot complete its reduced/resume checks. The eleven recorded passing headless suites and the new native approach scene do not cover this caller. The task-3 broad-search/completeness claim is therefore too strong.
- Fix: update this fixture's reduced and paused-resume expectations to validated formal front standing with the existing announcer costume and full-canvas material/UV synchronization. Preserve full-body, foot-row, contact, depth, visibility and failure guards. Validate the affected native section/entry with an isolated save; preserve and report any earlier unrelated failure rather than bypassing it or claiming the full entry passed. This does not require expanding into MAIN-32's unrelated legacy repair.

### Minor

No additional actionable finding in the reviewed diff.

## Known failing entry assessed separately

`game/tests/native_npc_review.gd:90` still hardcodes obsolete birth positions, with additional legacy source/route assumptions at lines 110–139. The retained `legacy-native-preexisting-failure.log` reports the ticket root at `(-3.8, 0, 5)` against the old `(-5, 0, 10)` expectation; its receipt exits 1 and the raw log has one ERROR and no PASS markers. The failure occurs before this branch's updated reduced section. The problematic root/source/route assertions predate this branch and are tracked by MAIN-32.

That is real outstanding validation debt, not a passing fixture. It is not itself a reason to roll back the bounded production fix; current Main native and state/world/rig/clearance tests provide separate evidence. It also does not excuse the newly incompatible native clearance caller identified above. The revised reduced expression inside the old entry remains parser-checked but not runtime-reached there.

## Evidence audit

No tests were rerun. Independently read the final task-3 receipts and raw logs: eleven headless runs all exit 0 with zero ERROR, including 298 Main dialogue PASS markers; the current native reduced/rebuild run exits 0 with 90 PASS markers and zero ERROR. These are marker counts, not invented independent test totals. Earlier failed attempts and decisive RED logs remain retained.

Read final embedded package `D:/Snapland-QA/20261118-npc-approach-qa-94fdba32` build/acceptance metadata, all three raw engine logs and their capture reports. Normal has three role rows/six captures; quarter/rebuild and reduced/rebuild each have six rows/twelve captures. All reports have no failures, true source/held-position checks, false human-play/full-acceptance flags, and exactly one final completion marker per clean raw log. Quarter records time scale 0.25; all six reduced idle clocks are zero. The acceptance receipt records 1,188 source hashes and binary verification.

Independently compared the current two production files, native fixture/scene and release helper against build hashes; all match. Independently checked all seven image hashes listed in root's final visual-acceptance receipt; all match the final package. Root's receipt explicitly documents static review of the final action/idle/reduced images. This reviewer did not independently watch the videos or visually approve the artwork.

Movie metadata identifies 1280×720, 30 FPS, 215 frames/7.166667 seconds normal and 1,564 frames/52.133333 seconds quarter/rebuild. Full decoding is root-recorded evidence, not a decoding run repeated by this reviewer. Public evidence ZIP is 27,400,289 bytes with 226 entries and retains the final package receipts, RED logs and the legacy failure; it does not silently replace failures with success.

## Recommendations

Resolve the P2 caller mismatch with the smallest expected-state correction and targeted evidence, then obtain a focused follow-up review. Keep the current frozen successful package as evidence for its exact runtime bytes; update delivery records honestly if fixture-only coverage is added. Continue MAIN-32 separately and retain ART-17's unchecked full-art criteria. Final main integration/CI remain executor-owned delivery gates.

## Declined to judge

- Repairing all obsolete root, four-frame and one-route assumptions in the old native NPC entry: preexisting separate MAIN-32 scope; its actual failure is explicitly assessed above.
- New directional artwork or generalized direction fallback: intentionally excluded by the approved design; current exact-direction failure must remain visible.
- Changing legacy reduced-motion root/interaction-point reset or teardown policy: explicitly preserved by the approved design and not necessary for the standing fix.
- Whole-character naturalness, natural gameplay-camera occlusion, continuous human playback and hearing: representative scripted captures and technical source checks cannot establish these; ART-17 remains open.
- Cross-platform GPU/performance acceptance and full-suite/current-main CI completion: outside supplied affected-run evidence and this read-only review; no such success is claimed.

## Assessment

**Ready to merge? With fixes.**

The production implementation and current Main evidence satisfy the bounded event-selection and reduced-standing design, but one existing native clearance caller still enforces the superseded baseline contract. Fix that P2 integration gap before merge; the separately reproduced MAIN-32 legacy failure remains disclosed follow-up debt.

Skipped engine/test reruns, continuous media viewing, full-suite/CI and full-art approval. Residual risks are the identified caller mismatch and the explicitly failing legacy native entry, not a demonstrated production data-loss or source-validation regression.
