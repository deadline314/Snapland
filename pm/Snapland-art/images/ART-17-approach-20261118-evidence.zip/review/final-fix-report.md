# Final fix wave — native clearance formal-standing caller

Reviewed finding: `.superpowers/sdd/2026-11-18-npc-approach-actions/final-review.md`, Important P2, review head `4c44b12`. Only source changed: `game/tests/native_sprite_clearance_review.gd`. Production, assets, prior seven task3 files, accepted approach fixture/scene/audio helper, PM, runner and Git untouched. This corrects the prior task3 report's overly broad completeness claim: native clearance's own `_run` was missed and is a distinct caller from MAIN32's parent legacy path.

## Fix and preserved guards

The existing directly callable `_review_reduced_motion_npcs` now obtains the real formal `idle/front` sequence through the existing activity source library and normalizer, requires it available/nonempty, validates the declared feet anchor448, applies existing announcer costume, and expects that exact neutral standing texture with full-canvas material UV. Reduced and paused-resume checks require `stand/front`, elapsed0 and synchronized source/material. Old baseline texture/material/UV expectations are removed only from this section.

The unchanged full-body, fixed320×460 canvas, RGBA8, pixel size, root/anchor/contact, billboard/ordinary opaque depth, scene geometry coverage, visibility and error paths remain. No tolerances in contact or depth were changed and no failure was skipped. The source-foot condition now requires exact formal opaque last-row equality, never below declared anchor448, and anchor-minus-lastrow<=1, matching the existing headless source-foot precedent. The declared registered guarded row448+guard and all actual world contact math remain unchanged.

Why the foot condition also needed correction: independent fresh `CharacterAnimationLibrary` diagnostics for all3roles returned RGBA8 format5, size320×460, last alpha>=0.5 row447, declared feet anchor[160,448]. Old equality to legacy row448 confused the anchor edge with the opaque pixel row. Existing headless `test_sprite_clearance.gd::_assert_npc_frames_share_feet_baseline` already requires source bottoms<=ACTION_FEET_ROW and variation<=1. Root explicitly authorized exact formal row equality plus <=anchor and <=1px gap; arbitrary floating-source gaps remain rejected.

## Actual RED/GREEN and bounded execution

Private evidence: `.review/npc-reduced-stand-20261118/finalwave/`. New D stage: `D:/Snapland-QA/native-clearance-finalwave-20261118-2b23a11a`, built with `prepare_runtime_stage` from tracked runtime plus exact test/helper allowlist. All engine starts use `tools.godot_entrypoints.run_validated_godot` and exact `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe`. Every save, APPDATA, LOCALAPPDATA, TEMP and TMP is independently isolated onD, recorded in same-label JSON. No repository import/player profile or frozen package was mutated.

Commands:

```text
python .review/npc-reduced-stand-20261118/finalwave/run.py prepare
python .review/npc-reduced-stand-20261118/finalwave/run.py red
python .review/npc-reduced-stand-20261118/finalwave/run.py green
python .review/npc-reduced-stand-20261118/finalwave/run.py diagnose
python .review/npc-reduced-stand-20261118/finalwave/run.py green2
python .review/npc-reduced-stand-20261118/finalwave/run.py final
python .review/npc-reduced-stand-20261118/finalwave/report.py
git diff --check -- game/tests/native_sprite_clearance_review.gd
```

Exact engine commands, source hashes, profiles, durations and raw output are retained per label. The full-entry target is real `res://game/tests/native_sprite_clearance_review.tscn`. Since it fails an earlier unrelated guard, a clearly labeled private Node scene `res://game/tests/finalwave_reduced_probe.tscn` inherits the real published child, creates genuine Main with the child's ordinary setup, and invokes the actual inherited `_review_reduced_motion_npcs`. It copies no method logic, overrides no body/depth/failure methods and injects no source or success results. Its success marker explicitly says **section only**, never full-entry PASS. Probe source is frozen as `probe-source.txt`.

- Actual original-child RED: full entry fails earlier announcer legacy frame2 rendered-depth coverage307/47406; raw `red-full-entry.log`, exit1/1ERROR. Its separate real method invocation reaches the P2 defect and rejects correct ticket formal standing at old baseline comparison; `red-reduced-section.log`, exit1/1ERROR, old child hash `b9a9d8972b60147442ea381b53f10d84d693368f39e2018461dfabf374ccacb1`.
- First corrected source expectation passes the old mismatch then exposes exact legacy opaque row448 assumption; `green-reduced-section.log` and `diagnose-reduced-section.log` retain failures. Fresh independent source measurements above establish the proper row447/anchor448 convention. No guard was silently removed.
- Final method GREEN: `final-reduced-section.log`, exit0/0ERROR, exactly one `PASS: existing native clearance reduced-motion section only`. All3roles complete source/layout/feet/contact/depth/capture and paused-resume checks. Depth reports zero covered body pixels: ticket0/46215, imp0/29752, announcer0/26749. Three actual PNGs saved under final-reduced-section profile `captures/`; hashes and depth JSON are audited in `final-audit.json`.
- Final **full entry remains failing**, `final-full-entry.log`, exit1/1ERROR, same preexisting announcer frame2 depth307/47406 before reduced section. Published entry retains that guard unchanged. No full-entry success, human play, continuous playback or art approval is claimed. Separate full legacy debt remains root-owned; no unrelated repair was attempted here.

## Frozen source proof and self-review

Final child SHA256: `6526bcf3f35e4dd36e864fdd98748e8dd058f689d5bbf80d1762e3f38872f225`. Matches repository, isolated stage and final full-entry/section receipts. `child.red.txt`, `child.final.txt`, `final-owned.diff` preserve exact inputs. `git diff --check` passes.

Runtime/accepted QA/prior-source before=after SHA256, checked at every launch and final audit:

- `game/world/park_world.gd`: `f0c221dce3a71400300c37a67e0f1255be3b821a2b5a1a6d308483b32a8821c1`
- `game/world/npc_activity.gd`: `a3caa0a6a417e1512ea537999942dc37ef435c3c70c95ee1f1e002ede28f7a30`
- `game/tests/native_npc_approach_review.gd`: `ab35a966de8a566ef8af126eb65eb59bc6d774132b1858a293df452b601921d3`
- `game/tests/native_npc_approach_review.tscn`: `d30baef5279db7e01757542e4d9d6d8e4e79141ca03ef98648ae255b17d30acd`
- `game/tests/audio_playback_release.gd`: `1b61bba4e5c54e38050e8ba0b7170b18848198928937ca2c4dfdebc31cc37184`
- `game/tests/test_npc_animation_states.gd`: `fbb87b20c4b935fdf5ca903be4f55887d1efc47524574fd041e65c04eb5fa7cf`
- `game/tests/test_npc_world_activity.gd`: `9b7a834045d8240bd6003bde164a1ac3a55db804710f3f7756e2a54ee6392d34`
- `game/tests/test_npc_walk_motion.gd`: `8b4f510f3b3597b582df2c90d67fbafbb964bcd48f94c818bbc87d6fde4d075a`
- `game/tests/test_sprite_clearance.gd`: `56aaf3f11bc60385e5e3b20a3458bb65bdd158ef3b42f3ac9c2e3ab1b32ec593`
- `game/tests/native_npc_review.gd`: `95368df30dda7ce8fd01c24b76021e1375fb2c7dbf49adfbd075817c97d474eb`

Only one production-independent caller contract changed; the final opaque-foot restriction rejects pixels below448 or farther than1px above the anchor, and exact expected formal source/normalizer validation remains. Existing body/depth/contact methods are unmodified and executed by the final section. Prior successful embedded package runtime inputs are byte-identical; no export or broad/full-suite rerun was needed or performed.

Skipped full-suite, re-export and unrelated earlier-depth/full-legacy repair. Remaining limitation: published full clearance entry still fails before this now-passing section at the retained frame2 geometry guard; report and evidence expose it explicitly.
