import hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from tools.build_desktop_release import prepare_runtime_stage
from tools.godot_entrypoints import run_validated_godot
EVIDENCE=Path(__file__).resolve().parent
STAGE=Path('D:/Snapland-QA/npc-approach-task2-20261118-0210')
ENGINE='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
ALLOW=['game/tests/native_npc_approach_review.gd','game/tests/native_npc_approach_review.tscn','game/tests/audio_playback_release.gd']
def run(label,args,timeout=180,save_override=None):
 save=STAGE.parent/(STAGE.name+'-profiles')/label/'progress.json'
 env=dict(os.environ,SNAPLAND_SAVE_PATH=save_override or str(save),APPDATA=str(save.parent/'appdata'),LOCALAPPDATA=str(save.parent/'localappdata'))
 for k in ['APPDATA','LOCALAPPDATA']: Path(env[k]).mkdir(parents=True,exist_ok=True)
 command=[ENGINE,'--path',str(STAGE),'--rendering-method','gl_compatibility','--audio-driver','Dummy',*args]
 start=time.monotonic()
 try:
  result=run_validated_godot(STAGE,command,env,timeout)
  output,code=result.stdout+result.stderr,result.returncode
 except subprocess.TimeoutExpired as exc: output,code=str(exc.output or '')+str(exc.stderr or ''),'timeout'
 (EVIDENCE/(label+'.log')).write_text(output,encoding='utf-8')
 receipt=dict(command=command,save=env['SNAPLAND_SAVE_PATH'],exit=code,seconds=time.monotonic()-start,passes=output.count('PASS:'),errors=output.count('ERROR:'),hashes={p:hashlib.sha256((STAGE/p).read_bytes()).hexdigest() for p in ALLOW})
 (EVIDENCE/(label+'.json')).write_text(json.dumps(receipt,indent=2),encoding='utf-8')
 print(json.dumps(receipt),flush=True)
if sys.argv[1]=='prepare':
 if STAGE.exists(): raise ValueError('Owned stage must be new')
 STAGE.mkdir(parents=True)
 tracked=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT,text=True,encoding='utf-8').split('\0')
 copied=prepare_runtime_stage(ROOT,STAGE,tracked)
 for p in ALLOW:
  target=STAGE/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/p,target)
  copied[p]=hashlib.sha256(target.read_bytes()).hexdigest()
 (EVIDENCE/'stage-manifest.json').write_text(json.dumps(copied,indent=2),encoding='utf-8')
 run('import',['--headless','--editor','--import','--quit'],300)
else:
 for p in ALLOW: shutil.copy2(ROOT/p,STAGE/p)
 label=sys.argv[1]
 output=STAGE.parent/(STAGE.name+'-evidence')/label
 args=['res://game/tests/native_npc_approach_review.tscn','--','--animation-output='+str(output),*sys.argv[2:]]
 run(label,args,save_override='relative.json' if label=='reject-relative-save' else None)
# Fail-closed calls remain native and use fresh isolated profiles; no evidence overwrite.
