from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import uuid

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT))
from tools.build_desktop_release import prepare_runtime_stage
from tools.godot_entrypoints import run_validated_godot

base = Path('D:/Snapland-QA') / ('20261118-npc-approach-qa-' + uuid.uuid4().hex[:8])
base.mkdir()
stage, release = base / 'project', base / 'release'
stage.mkdir()
release.mkdir()
evidence = ROOT / '.review/npc-approach-20261118'
(evidence / 'package-location.json').write_text(json.dumps({'directory': str(base)}), encoding='utf-8')
tracked = subprocess.check_output(['git', 'ls-files', '-z'], encoding='utf-8').split('\0')
hashes = prepare_runtime_stage(ROOT, stage, tracked)
fixtures = ['native_npc_approach_review.gd', 'native_npc_approach_review.tscn', 'audio_playback_release.gd']
for name in fixtures:
    relative = 'game/tests/' + name
    target = stage / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ROOT / relative, target)
    hashes[relative] = hashlib.sha256((ROOT / relative).read_bytes()).hexdigest()
for filename, old, new in [
    ('project.godot', 'res://game/main.tscn', 'res://game/tests/native_npc_approach_review.tscn'),
    ('export_presets.cfg', 'game/tests/*,', ''),
]:
    p = stage / filename
    body = p.read_text(encoding='utf-8')
    assert old in body
    p.write_text(body.replace(old, new), encoding='utf-8')
templates = Path(os.environ['APPDATA']) / 'Godot/export_templates/4.7.2.stable'
preset = stage / 'export_presets.cfg'
body = preset.read_text(encoding='utf-8')
for kind in ['debug', 'release']:
    template = templates / ('windows_' + kind + '_x86_64.exe')
    assert template.is_file(), template
    body = body.replace('custom_template/' + kind + '=""', 'custom_template/' + kind + '="' + template.as_posix() + '"', 1)
preset.write_text(body, encoding='utf-8')
engine = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
exe = release / 'NpcApproachQA.exe'
env = dict(os.environ, SNAPLAND_SAVE_PATH=str(base / 'build-profile/progress.json'), APPDATA=str(base / 'appdata'), LOCALAPPDATA=str(base / 'local-appdata'))
steps = []
for label, args in [
    ('import', ['--editor', '--import', '--quit']),
    ('export', ['--editor', '--export-release', 'Windows Desktop', str(exe), '--quit']),
]:
    result = run_validated_godot(stage, [engine, '--headless', '--path', str(stage), *args], env=env, timeout=300)
    log = result.stdout + result.stderr
    (base / (label + '.log')).write_text(log, encoding='utf-8')
    assert result.returncode == 0 and 'ERROR:' not in log, log[-4000:]
    steps.append({'step': label, 'exit': result.returncode})
    print('PASS private NPC approach', label, flush=True)
manifest = {
    'source_commit_base': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'source_snapshot_uncommitted': True,
    'source_sha256': hashes,
    'fixtures': fixtures,
    'templates': {kind: {'path': str(templates / ('windows_' + kind + '_x86_64.exe')), 'sha256': hashlib.sha256((templates / ('windows_' + kind + '_x86_64.exe')).read_bytes()).hexdigest()} for kind in ['debug', 'release']},
    'steps': steps,
    'binary': {'file': exe.name, 'bytes': exe.stat().st_size, 'sha256': hashlib.sha256(exe.read_bytes()).hexdigest()},
    'scope': 'Private embedded NPC approach QA; exactly three fixture code files, player runtime main unchanged',
}
(base / 'build.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
cases = []
for mode, flags in [('normal', []), ('quarter-rebuild', ['--quarter', '--rebuild']), ('reduced-rebuild', ['--reduced-motion', '--rebuild'])]:
    out = base / mode
    out.mkdir()
    env['SNAPLAND_SAVE_PATH'] = str(out / 'profile/progress.json')
    movie = [] if mode == 'reduced-rebuild' else ['--write-movie', str(out / 'playback.avi'), '--fixed-fps', '30']
    command = [str(exe), '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', *movie, '--', '--animation-output=' + str(out / 'captures'), *flags]
    result = run_validated_godot(stage, command, env=env, timeout=240, release_directory=release)
    log = result.stdout + result.stderr
    (out / 'engine.log').write_text(log, encoding='utf-8')
    receipt = json.loads((out / 'captures/npc-approach-report.json').read_text(encoding='utf-8'))
    assert result.returncode == 0 and 'ERROR:' not in log and 'PASS: native NPC approach actions and idle recovery' in result.stdout.splitlines(), log[-4000:]
    assert 'leaked' not in log.lower() and 'still in use' not in log.lower(), log[-4000:]
    assert receipt['technical_status'] == 'PASS' and not receipt['failures'] and not receipt['complete_acceptance'] and not receipt['human_played']
    if movie:
        subprocess.run(['C:/ffmpeg/bin/ffmpeg.exe', '-v', 'error', '-i', str(out / 'playback.avi'), '-an', '-c:v', 'libx264', '-crf', '23', '-pix_fmt', 'yuv420p', str(out / 'playback.mp4')], check=True)
        subprocess.run(['C:/ffmpeg/bin/ffmpeg.exe', '-v', 'error', '-i', str(out / 'playback.mp4'), '-f', 'null', '-'], check=True)
        probe = json.loads(subprocess.check_output(['C:/ffmpeg/bin/ffprobe.exe', '-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(out / 'playback.mp4')]))
        (out / 'movie-metadata.json').write_text(json.dumps(probe, indent=2), encoding='utf-8')
    cases.append({'mode': mode, 'command': command, 'exit': result.returncode, 'strict_clean': True})
    (out / 'result.json').write_text(json.dumps(cases[-1], indent=2), encoding='utf-8')
    print('PASS private NPC approach', mode, flush=True)
assert all(hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest for name, digest in hashes.items())
assert hashlib.sha256(exe.read_bytes()).hexdigest() == manifest['binary']['sha256']
(base / 'acceptance.json').write_text(json.dumps({'cases': cases, 'verified_source_hashes': len(hashes), 'binary_sha256_verified': True, 'strict_clean': True}, indent=2), encoding='utf-8')
print('PASS private NPC approach actual three-role input/actions/idle, hashes', len(hashes), flush=True)
