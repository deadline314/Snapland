"""Private bounded task-1 evidence runner; no repository cache or player save use."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from tools.build_desktop_release import prepare_runtime_stage
from tools.godot_entrypoints import run_validated_godot

EVIDENCE = Path(__file__).resolve().parent
STAGE = Path('D:/Snapland-QA/npc-approach-task1-20261118-0145')
ENGINE = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
ALLOW = ['test_npc_dialogue_hold.gd', 'test_npc_dialogue_hold.tscn',
         'audio_playback_release.gd', 'test_npc_activity.gd',
         'test_npc_animation_states.gd', 'test_npc_world_activity.gd',
         'test_character_animation_library.gd', 'test_npc_departure_lifecycle.gd',
         'test_npc_authored_source_walking.gd']

def sync():
    for name in ['game/world/park_world.gd', 'game/tests/test_npc_dialogue_hold.gd']:
        shutil.copy2(ROOT / name, STAGE / name)

def run(label, args, timeout=180):
    save = STAGE.parent / (STAGE.name + '-profiles') / label / 'progress.json'
    env = dict(os.environ, SNAPLAND_SAVE_PATH=str(save), APPDATA=str(save.parent / 'appdata'),
               LOCALAPPDATA=str(save.parent / 'localappdata'))
    for key in ['APPDATA', 'LOCALAPPDATA']:
        Path(env[key]).mkdir(parents=True, exist_ok=True)
    command = [ENGINE, '--headless', '--path', str(STAGE), *args]
    start = time.monotonic()
    try:
        result = run_validated_godot(STAGE, command, env, timeout)
        output, code = result.stdout + result.stderr, result.returncode
    except subprocess.TimeoutExpired as exc:
        output, code = str(exc.output or '') + str(exc.stderr or ''), 'timeout'
    (EVIDENCE / (label + '.log')).write_text(output, encoding='utf-8')
    receipt = dict(label=label, command=command, save=str(save), exit=code,
                   seconds=round(time.monotonic()-start, 3), passes=output.count('PASS:'),
                   errors=output.count('ERROR:'),
                   hashes={name:hashlib.sha256((STAGE/name).read_bytes()).hexdigest()
                           for name in ['game/world/park_world.gd','game/tests/test_npc_dialogue_hold.gd']})
    (EVIDENCE / (label + '.json')).write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    print(json.dumps(receipt), flush=True)

mode = sys.argv[1]
if mode == 'prepare':
    if STAGE.exists() and any(STAGE.iterdir()):
        raise ValueError('Stage must be empty before preparing')
    STAGE.mkdir(parents=True, exist_ok=True)
    tracked = subprocess.check_output(['git','ls-files','-z'],cwd=ROOT,text=True,encoding='utf-8').split('\0')
    copied = prepare_runtime_stage(ROOT, STAGE, tracked)
    for name in ALLOW:
        relative = 'game/tests/' + name
        target = STAGE / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / relative, target)
        copied[relative] = hashlib.sha256((ROOT/relative).read_bytes()).hexdigest()
    (EVIDENCE/'stage-manifest.json').write_text(json.dumps(copied, indent=2),encoding='utf-8')
    for name in ['game/world/park_world.gd','game/tests/test_npc_dialogue_hold.gd']:
        (EVIDENCE/(Path(name).name+'.baseline.txt')).write_bytes((ROOT/name).read_bytes())
    run('import', ['--editor','--import','--quit'], 300)
    run('baseline-dialogue', ['res://game/tests/test_npc_dialogue_hold.tscn'])
elif mode in ['red', 'green']:
    sync()
    for name in ['game/world/park_world.gd','game/tests/test_npc_dialogue_hold.gd']:
        (EVIDENCE/(Path(name).name+'.'+mode+'.txt')).write_bytes((ROOT/name).read_bytes())
    run(mode+'-dialogue'+('-'+sys.argv[2] if len(sys.argv)>2 else ''), ['res://game/tests/test_npc_dialogue_hold.tscn'])
elif mode == 'regressions':
    for name in ALLOW:
        if name.startswith('test_') and name.endswith('.gd') and name != 'test_npc_dialogue_hold.gd':
            run('green-'+Path(name).stem, ['--script','res://game/tests/'+name])
