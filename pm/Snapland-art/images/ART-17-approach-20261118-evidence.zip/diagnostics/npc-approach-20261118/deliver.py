from pathlib import Path
import hashlib
import json
import shutil
import zipfile

root = Path.cwd()
evidence = root / '.review/npc-approach-20261118'
base = Path(json.loads((evidence / 'package-location.json').read_text(encoding='utf-8'))['directory'])
acceptance = json.loads((base / 'acceptance.json').read_text(encoding='utf-8'))
assert acceptance['strict_clean'] and len(acceptance['cases']) == 3
visual = json.loads((evidence / 'root-visual-acceptance.json').read_text(encoding='utf-8'))
assert Path(visual['package']) == base and visual['reduced_formal_front_standing_verified']
build = json.loads((base / 'build.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((root / p).read_bytes()).hexdigest() == digest for p, digest in build['source_sha256'].items())
public = root / 'pm/Snapland-art/images'
for role, action in [('ticket', 'greet'), ('imp', 'interact'), ('announcer', 'interact')]:
    shutil.copy2(base / f'normal/captures/{role}-pass0-{action}.png', public / f'ART-17-approach-20261118-{role}.png')
for mode, suffix in [('normal', 'normal'), ('quarter-rebuild', 'quarter')]:
    shutil.copy2(base / mode / 'playback.mp4', public / f'ART-17-approach-20261118-{suffix}.mp4')
snapshot = {
    'source_commit': build['source_commit_base'],
    'binary': build['binary'],
    'acceptance': acceptance,
    'scope': 'Scripted actual Main E interaction, back-left player placement, fixed close camera and hidden hero; no NPC root/action/result injection. Static PNG inspection and automated clip decode are not human continuous viewing/play/listening or complete art acceptance.',
    'visual_review': visual,
}
(evidence / 'final-review-summary.json').write_text(json.dumps(snapshot, indent=2), encoding='utf-8')
archive = public / 'ART-17-approach-20261118-evidence.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for folder in [evidence, root / '.review/npc-approach-task2-20261118', root / '.review/npc-reduced-stand-20261118']:
        for p in folder.rglob('*'):
            if p.is_file() and p.suffix in {'.json', '.log', '.md', '.txt', '.py', '.png'}:
                z.write(p, 'diagnostics/' + folder.name + '/' + p.relative_to(folder).as_posix())
    for p in base.rglob('*'):
        rel = p.relative_to(base)
        if p.is_file() and rel.parts[0] not in {'project', 'release', 'appdata', 'local-appdata'} and p.suffix in {'.json', '.log', '.png'}:
            z.write(p, 'final-package/' + rel.as_posix())
    workspace = root / '.superpowers/sdd/2026-11-18-npc-approach-actions'
    for p in workspace.glob('*'):
        if p.suffix in {'.md', '.diff'}:
            z.write(p, 'review/' + p.name)
    for name in ['game/world/park_world.gd', 'game/tests/test_npc_dialogue_hold.gd', 'game/tests/native_npc_approach_review.gd', 'game/tests/native_npc_approach_review.tscn', 'game/tests/audio_playback_release.gd', 'game/world/npc_activity.gd', 'game/tests/test_npc_animation_states.gd', 'game/tests/test_npc_world_activity.gd', 'game/tests/test_sprite_clearance.gd', 'game/tests/test_npc_walk_motion.gd', 'game/tests/native_npc_review.gd']:
        z.write(root / name, 'final-source/' + name)
ticket = next((root / 'pm/Snapland-art').glob('[[]ART-17]*.md'))
body = ticket.read_text(encoding='utf-8')
assert '# Commit — 2026-11-18 修正非正面靠近互動' not in body
body += '''
# Commit — 2026-11-18 修正非正面靠近互動

## 內文

玩家從側面或背面靠近時，對話雖能開啟，三位角色卻沒有播放應有的招呼或互動。現在會使用各自既有完整正面演出，結束後回到待機；對話期間人物與互動位置保持不動。直接請求不存在的方向、或完整來源損壞時，仍會明確回報並恢復完整人物，不保留上一張手勢。新增原畫數為零。

原生逐張檢視另發現降低動態會把阿浪還原成舊走姿，舊貼圖相等的技術檢查無法證明站姿。這輪拒收該畫面後補上反例；現在有正式完整來源時，三位均採正面靜止站姿，缺件時保留原有完整人物回退。既有路線根位置及互動點還原規則保留。

同步核對[逐角色正式來源與事件覆蓋](../../design/runtime/character-animation-wardrobe.md)，將目前可用來源、正式接線與藝術驗收分開記錄。本次交付對應互動與待機銜接，整票依原條件維持進行中。

### 測試結果

| 項目 | 結果 |
|---|---|
| 原始反例 | 24 種靠近方式均能開對話，其中 21 種非正面方式漏播；保留實際失敗日誌 |
| 正式對話及局部回歸 | 三位各八方位、動作前進／結束、對話保持、取消、暫停及降低動態通過；受影響十一項引擎回歸全通過 |
| 缺件與損壞 | 每位直接缺少方向及後段來源損壞皆明確回報，保留完整站姿與可取消對話 |
| 原生正常及慢速重入 | 三位皆經實際互動播放中間姿勢並回到待機；四分之一模擬時間與真正場景重建通過 |
| 降低動態及重入 | 實際設定回到完整靜止站姿，三位人物與互動位置均穩定 |
| 獨立 Windows 封裝 | 三種情境皆通過，1188 份來源指紋一致，無引擎錯誤或退出資源殘留 |
| 驗證輸出保護 | 五種不安全路徑／衝突模式如實拒絕，不覆寫既有證據 |
| 設計資料及連結 | 五範圍通過 |

正常與慢速影片採固定 30 FPS 錄製並完成全片解碼檢查，不作硬體性能數據。實際逐張檢視三位正常中間姿勢、待機及慢速／降低動態代表畫面。玩家擺位、隱藏主角及拉近鏡頭均為拍攝取景；不是真人自由遊玩、連續觀看、試聽或整套動畫自然度驗收。

![票票實際招呼中間姿勢](images/ART-17-approach-20261118-ticket.png)
![小角實際互動中間姿勢](images/ART-17-approach-20261118-imp.png)
![阿浪實際指路中間姿勢](images/ART-17-approach-20261118-announcer.png)

[正常影片](images/ART-17-approach-20261118-normal.mp4) · [四分之一速度及重入](images/ART-17-approach-20261118-quarter.mp4) · [反例、回歸、原生畫面、封裝指紋與審查](images/ART-17-approach-20261118-evidence.zip)。固定基準 `3ca0b9c`；分支 `codex/npc-approach-actions-20261118`。
'''
ticket.write_text(body, encoding='utf-8', newline='\n')
print(json.dumps({'archive_bytes': archive.stat().st_size, 'source_hashes': len(build['source_sha256'])}))
