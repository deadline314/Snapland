"""Audit bounded final receipts and write Task3 report, without launching Godot."""
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
STAGE = Path(json.loads((HERE / 'stage-location.json').read_text()))
labels = ['green3-test_npc_animation_states', 'green3-test_npc_world_activity',
          'green-test_npc_activity', 'green-test_npc_walk_motion', 'green-test_sprite_clearance',
          'green-test_npc_departure_lifecycle', 'green-test_npc_authored_source_walking',
          'green-test_character_animation_library', 'green-test_npc_walk_direction_lifecycle',
          'green-test_authored_npc_patrol', 'green-dialogue', 'green-native-reduced']
receipts = [json.loads((HERE / (label + '.json')).read_text()) for label in labels]
hashes = receipts[-1]['hashes']
for row in receipts:
    log = (HERE / (row['label'] + '.log')).read_text(encoding='utf-8')
    assert row['exit'] == 0 and row['errors'] == 0 and row['passes'] > 0
    assert 'ERROR:' not in log and 'PASS:' in log and row['hashes'] == hashes
for name, digest in hashes.items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest
    assert hashlib.sha256((STAGE / name).read_bytes()).hexdigest() == digest
    (HERE / (Path(name).name + '.final.txt')).write_bytes((ROOT / name).read_bytes())
native_path = Path(json.loads((HERE / 'native-location.json').read_text()))
native = json.loads((native_path / 'npc-approach-report.json').read_text())
assert native['technical_status'] == 'PASS' and native['failures'] == []
assert not native['complete_acceptance'] and not native['human_played']
assert len(native['roles']) == 6 and len(native['captures']) == 12
assert all(row['reduced_motion'] and row['idle_elapsed'] == 0 for row in native['roles'])
assert 'PASS: native NPC approach actions and idle recovery' in (HERE / 'green-native-reduced.log').read_text()
diff = subprocess.check_output(['git', 'diff', '115f57c', '--', *hashes], cwd=ROOT, encoding='utf-8')
(HERE / 'task3-owned.diff').write_text(diff, encoding='utf-8')
summary = dict(status='PASS bounded current fixtures', headless_suites=11, native_checks=90,
               captures=12, source_hashes=hashes, labels=labels,
               legacy_limit='parser checked; full legacy entry failed stale ticket root before reduced section')
(HERE / 'task3-self-review.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
manifest = json.loads((HERE / 'stage-manifest.json').read_text())
for path in (STAGE / 'game/tests').iterdir():
    if path.is_file() and path.suffix in {'.gd', '.tscn'}:
        manifest[path.relative_to(STAGE).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
for name, digest in hashes.items():
    manifest[name] = digest
(HERE / 'final-stage-manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')

report = '''# Task 3 report — reduced-motion formal standing

Source review base: `115f57c`. Authority: `design/runtime/npc-approach-actions.md` reduced addendum and plan Global Constraints. Worker performed no Git mutations, PM/docs/runner changes, subagents, package edits, cleanup deletion, or external messages. Root owns packaging, final three-mode QA, review, PM and Git. Parent explicitly expanded ownership for supported-source expectations in `test_sprite_clearance.gd`, `test_npc_walk_motion.gd`, and `native_npc_review.gd`.

## Root cause and scope

`ParkWorld.apply_settings` calls `NpcActivity.set_reduced_motion`. Its enable path paused AnimationPlayer and called `_restore_baselines` → `_restore_record`, restoring the registration texture/material/UV, root, interaction point and patrol. Registration captures the legacy initial complete Sprite before selecting formal standing. Announcer's legacy initial Sprite is a right-walking cel. Equality with that baseline proves restoration, not standing; the rejected screenshot visibly shows this defect.

The only production change adds a loop after existing baseline restoration to request existing `stand/front` with reset=true for active records. `_play_actor_action` already chooses validated stand/idle/idle_stand, normalizes the complete canvas, applies role costume and shader full-canvas UV, and fails closed to the complete baseline with `stand/front` missing telemetry. No action lookup, alias, normalization, fallback or asset API changed. `_restore_record` itself is unchanged because release and tree-exit teardown also call it. Root/point restoration, shader freeze, optional rig pause/hide, missing/damaged-source behavior and teardown remain their existing owners.

Caller search covered all `set_reduced_motion`, `_restore_baselines`, `_restore_record`, `_play_actor_action`, reduced/baseline/texture/material/UV references across game scripts. Production callers: world settings; internal release and actor exit for `_restore_record`; action API, registration, patrol, dialogue hold, motion routes, idle/finite completion for `_play_actor_action`. Only setter enable is changed. Related regressions cover state/world/activity, sprite clearance, optional rig, departure, authored walking/patrol, direction lifecycle and actual Main dialogue. Native old fixture and current approach fixture contained incorrect supported-source baseline assertions. Other hits were unrelated component/avatar/attraction systems. `test_npc_activity.gd` intentionally injects a missing library; its original complete baseline/material/UV assertions remain byte-for-byte unchanged.

## Actual RED before production edit

Raw logs and exact source snapshots are in `.review/npc-reduced-stand-20261118/`:

- `red-test_npc_animation_states.log`: actual assertion `ticket reduced motion selects formal front standing` failed at line171. SceneTree coroutine assertion leaves engine running; bounded45s owned-process timeout captured the error. Original production SHA256: `94c65089fc0c6222bdf9b6dca2777ec4ca1da9c1892ed14661b11cda094d8afc`.
- `red-test_npc_world_activity.log`: four actual formal standing errors from the added helper. Exit0 and one old PASS marker were rejected because ERROR count4; demonstrates why marker/exit alone is insufficient.
- `*.red.txt` preserve exact tested state/world/native predicate and original production sources. Stage was prepared/imported before changing production.

First post-fix state run exposed my damaged-source check placed after the existing actors had been freed (`green-test_npc_animation_states.log`). I moved only the new check before existing teardown; old absence/release assertions remain. First/second post-fix world runs exposed an old immediate-resume expectation of legacy `record.frames[0]` (`green*-test_npc_world_activity.log`); corrected supported-source resume to formal current standing rather than resurrecting the legacy walking cel. All failure logs remain. Early receipts originally hashed at process completion; final runner captures launch hashes. The old world run overlapped final state-fixture copy without changing the world/runtime bytes, so only final green3/green receipts are authoritative final-source receipts.

## Assertion semantics

- Previously supported-source reduced checks equated registration baseline with standing; now state asserts all3roles have formal available stand/front, neutral first complete cel, frozen elapsed, repeated enable, active interaction/walk interruption, pause/dialogue hold, pixel size and safe resume.
- World independently loads the real library's formal idle/front first cel for all3roles and compares exact pixel bytes, canonical320×460 canvas, announcer costume output, current stand/front/time0, shader source/full UV and shader motion0. Original root/point, dialogue/pause, idle counts, ground, absence and marker assertions remain.
- Damaged formal stand+idle sources after a valid gesture restore the baseline, clear sequence, record missing `stand/front` and remain frozen. Existing missing-library3role checks unchanged and passing.
- Sprite clearance still checks size/flip/root/gesture baseline, full silhouette, foot row and terrain/shadow safeguards; formal source/material/UV and immediate formal resume replace legacy visual assumptions.
- Optional rig test still checks3role Sprite visible/rig hidden, frozen root/shader and resume; announcer formal source pixel bytes include existing bounded costume treatment.
- Current native `_source_matches` no longer has a reduced-motion baseline shortcut. Exact formal timeline/canvas/costume comparison runs in reduced mode too. Re-read record after settings because enable resets the standing action elapsed; frozen comparison starts from the actual post-transition state. Receipt says frozen complete authored front standing sequence.

## Execution isolation and commands

Private script: `.review/npc-reduced-stand-20261118/run.py`. Stage: `D:/Snapland-QA/npc-reduced-stand-20261118-c30b1ba5`. Built using `prepare_runtime_stage` from tracked runtime files plus exact fixture/helper allowlist, never whole-repo/C cache copy. Initial/final manifests retain file fingerprints. All engine launches go through `tools.godot_entrypoints.run_validated_godot`, exact executable `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe`, with independent absolute D save, APPDATA and LOCALAPPDATA per label. No player saves used.

Invoked commands (every exact engine command/environment/timeout result is in same-label JSON):

```text
python .review/npc-reduced-stand-20261118/run.py prepare
python .review/npc-reduced-stand-20261118/run.py red
python .review/npc-reduced-stand-20261118/run.py green
python .review/npc-reduced-stand-20261118/run.py green2
python .review/npc-reduced-stand-20261118/run.py green3
python .review/npc-reduced-stand-20261118/run.py regressions
python .review/npc-reduced-stand-20261118/run.py native
python .review/npc-reduced-stand-20261118/run.py legacy
python .review/npc-reduced-stand-20261118/report.py
```

## Final results

'''
report += '| Label | Exit | PASS markers | ERROR | Seconds |\n|---|---:|---:|---:|---:|\n'
for row in receipts:
    report += f"| {row['label']} | {row['exit']} | {row['passes']} | {row['errors']} | {row['seconds']} |\n"
report += '''
All11 final headless suites pass with zero ERROR. Actual Main dialogue preserves all original assertions plus three-role/eight-direction coverage (298 PASS markers). GPU current Main reduced+rebuild smoke has90 PASS markers, final exact success marker, technical_status=PASS, no failures,6 role/pass rows,12 screenshots, all reduced idle elapsed0. Native source output: `D:/Snapland-QA/npc-reduced-stand-20261118-c30b1ba5-native-reduced`.

Viewed rejected `D:/Snapland-QA/20261118-npc-approach-qa-58632e77/reduced-rebuild/captures/announcer-pass1-idle-reduced.png` and new `announcer-pass1-idle-reduced.png`. Old capture shows right-walking stride; new capture visibly shows formal front standing with planted boots and the formal body scale. This is static image inspection and scripted native evidence, not human play/continuous watching/listening or whole ART17 approval. Root must review final exact-byte three-mode embedded QA/media separately.

Legacy import parser check (`legacy-import`) exits0, zero ERROR. Full old `native_npc_review.tscn` is explicitly **not passing**: `legacy-native-preexisting-failure.log` exits1 with ticket label/root identity mismatch (old expected -5,0,10 vs current -3.8,0,5) before reaching the updated reduced section. Its obsolete root/four-legacy-frame assumptions remain unchanged; no bypass/fake PASS harness. Narrow revised reduced expression is parser checked but not runtime reached there; actual equivalent runtime is covered by current Main native + state/world/rig/clearance. Root opened MAIN32 for full legacy fixture repair.

## Final SHA256

'''
for name, digest in hashes.items():
    report += f'- `{name}`: `{digest}`\n'
report += '''
`*.final.txt`, `task3-owned.diff`, `task3-self-review.json`, and `final-stage-manifest.json` freeze final reviewed inputs. Self-check verified every final source matches repository, D-stage and final receipt hashes, all final logs have zero errors/success markers, and native receipt/capture counts and flags are consistent. `git diff --check` for owned files passes (Git only emits existing newline normalization notice on approach fixture).

## Self-review and limits

Production diff is3 lines; reuses existing action validator and existing independent source contract, adds no assets/dependencies/options/helpers to runtime. Inactive records are skipped. Missing source fails closed; release/tree exit restoration untouched. Shader pause/hide ordering inspected: rig `set_paused`→`_deactivate` changes visibility only, leaves selected formal texture intact; optional rig test actually passes. Root/point reset remains before formal visual selection. No known player-facing correctness issue remains in this bounded change.

Skipped full suite, full legacy fixture repair, package/export, normal/quarter final re-record, manual continuous playback/listening and whole ART17 acceptance; root owns delivery and final review. Remaining risk/limitation is the explicitly failing obsolete legacy native fixture and final package still requiring root's exact-source media verification.
'''
(ROOT / '.superpowers/sdd/2026-11-18-npc-approach-actions/task-3-report.md').write_text(report, encoding='utf-8')
print(json.dumps(summary, indent=2))
