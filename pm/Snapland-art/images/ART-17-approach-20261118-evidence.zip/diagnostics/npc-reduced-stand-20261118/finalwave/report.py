"""Freeze final caller evidence and append its bounded report."""
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
STAGE = Path(json.loads((HERE / 'stage-location.json').read_text()))
CHILD = 'game/tests/native_sprite_clearance_review.gd'
frozen = json.loads((HERE / 'frozen-before.json').read_text())
assert all(hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest for name,digest in frozen.items())
labels = ['red-full-entry','red-reduced-section','green-full-entry','green-reduced-section',
          'diagnose-reduced-section','green2-full-entry','green2-reduced-section',
          'final-full-entry','final-reduced-section']
rows = [json.loads((HERE / (label + '.json')).read_text()) for label in labels]
assert all(row['frozen_hashes'] == frozen for row in rows)
final = rows[-1]
digest = hashlib.sha256((ROOT / CHILD).read_bytes()).hexdigest()
assert digest == final['child_sha256'] == hashlib.sha256((STAGE / CHILD).read_bytes()).hexdigest()
assert final['exit'] == 0 and final['errors'] == 0 and final['passes'] == 1
assert rows[-2]['exit'] == 1 and rows[-2]['errors'] == 1
assert 'announcer frame 2 has 307/47406' in (HERE / 'final-full-entry.log').read_text(encoding='utf-8')
profile = Path(final['environment']['SNAPLAND_SAVE_PATH']).parent
depth = json.loads((profile / 'sprite-depth-coverage.json').read_text())
assert len(depth) == 3 and all(row['covered_pixels'] == 0 and row['body_pixels'] > 0 for row in depth)
captures = list((profile / 'captures').glob('*.png'))
assert len(captures) == 3
audit = dict(child_sha256=digest, frozen_before=frozen, frozen_after=frozen,
             section_status='PASS actual inherited method only', full_entry_status='FAIL preexisting announcer frame2 depth',
             depth=depth, captures={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in captures})
(HERE / 'final-audit.json').write_text(json.dumps(audit,indent=2), encoding='utf-8')
(HERE / 'child.final.txt').write_bytes((ROOT / CHILD).read_bytes())
(HERE / 'final-owned.diff').write_text(subprocess.check_output(['git','diff','4c44b12','--',CHILD],cwd=ROOT,encoding='utf-8'),encoding='utf-8')
report = '''# Final fix wave — native clearance formal-standing caller

Reviewed finding: `.superpowers/sdd/2026-11-18-npc-approach-actions/final-review.md`, Important P2, review head `4c44b12`. Only source changed: `game/tests/native_sprite_clearance_review.gd`. Production, assets, prior seven task3 files, accepted approach fixture/scene/audio helper, PM, runner and Git untouched. This corrects the prior task3 report's overly broad completeness claim: native clearance's own `_run` was missed and is a distinct caller from MAIN32's parent legacy path.

## Fix and preserved guards

The existing directly callable `_review_reduced_motion_npcs` now obtains the real formal `idle/front` sequence through the existing activity source library and normalizer, requires it available/nonempty, validates the declared feet anchor448, applies existing announcer costume, and expects that exact neutral standing texture with full-canvas material UV. Reduced and paused-resume checks require `stand/front`, elapsed0 and synchronized source/material. Old baseline texture/material/UV expectations are removed only from this section.

The unchanged full-body, fixed320×460 canvas, RGBA8, pixel size, root/anchor/contact, billboard/ordinary opaque depth, scene geometry coverage, visibility and error paths remain. No tolerances in contact or depth were changed and no failure was skipped. The source-foot condition now requires exact formal opaque last-row equality, never below declared anchor448, and anchor-minus-lastrow<=1, matching the existing headless source-foot precedent. The declared registered guarded row448+guard and all actual world contact math remain unchanged.

Why the foot condition also needed correction: independent fresh `CharacterAnimationLibrary` diagnostics for all3roles returned RGBA8 format5, size320×460, last alpha>=0.5 row447, declared feet anchor[160,448]. Old equality to legacy row448 confused the anchor edge with the opaque pixel row. Existing headless `test_sprite_clearance.gd::_assert_npc_frames_share_feet_baseline` already requires source bottoms<=ACTION_FEET_ROW and variation<=1. Root explicitly authorized exact formal row equality plus <=anchor and <=1px gap; arbitrary floating-source gaps remain rejected.

## Actual RED/GREEN and bounded execution

Private evidence: `.review/npc-reduced-stand-20261118/finalwave/`. New D stage: `D:/Snapland-QA/native-clearance-finalwave-20261118-2b23a11a`, built with `prepare_runtime_stage` from tracked runtime plus exact test/helper allowlist. All engine starts use `tools.godot_entrypoints.run_validated_godot` and exact `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe`. Every save, APPDATA, LOCALAPPDATA, TEMP and TMP is independently isolated onD, recorded in same-label JSON. No repository import/player profile or frozen package was mutated.

Commands:

```text
python .review/npc-reduced-stand-20261118/finalwave/run.py prepare
python .review/npc-reduced-stand-20261118/finalwave/run.py red
python .review/npc-reduced-stand-20261118/finalwave/run.py green
python .review/npc-reduced-stand-20261118/finalwave/run.py diagnose
python .review/npc-reduced-stand-20261118/finalwave/run.py green2
python .review/npc-reduced-stand-20261118/finalwave/run.py final
python .review/npc-reduced-stand-20261118/finalwave/report.py
git diff --check -- game/tests/native_sprite_clearance_review.gd
```

Exact engine commands, source hashes, profiles, durations and raw output are retained per label. The full-entry target is real `res://game/tests/native_sprite_clearance_review.tscn`. Since it fails an earlier unrelated guard, a clearly labeled private Node scene `res://game/tests/finalwave_reduced_probe.tscn` inherits the real published child, creates genuine Main with the child's ordinary setup, and invokes the actual inherited `_review_reduced_motion_npcs`. It copies no method logic, overrides no body/depth/failure methods and injects no source or success results. Its success marker explicitly says **section only**, never full-entry PASS. Probe source is frozen as `probe-source.txt`.

- Actual original-child RED: full entry fails earlier announcer legacy frame2 rendered-depth coverage307/47406; raw `red-full-entry.log`, exit1/1ERROR. Its separate real method invocation reaches the P2 defect and rejects correct ticket formal standing at old baseline comparison; `red-reduced-section.log`, exit1/1ERROR, old child hash `b9a9d8972b60147442ea381b53f10d84d693368f39e2018461dfabf374ccacb1`.
- First corrected source expectation passes the old mismatch then exposes exact legacy opaque row448 assumption; `green-reduced-section.log` and `diagnose-reduced-section.log` retain failures. Fresh independent source measurements above establish the proper row447/anchor448 convention. No guard was silently removed.
- Final method GREEN: `final-reduced-section.log`, exit0/0ERROR, exactly one `PASS: existing native clearance reduced-motion section only`. All3roles complete source/layout/feet/contact/depth/capture and paused-resume checks. Depth reports zero covered body pixels: ticket0/46215, imp0/29752, announcer0/26749. Three actual PNGs saved under final-reduced-section profile `captures/`; hashes and depth JSON are audited in `final-audit.json`.
- Final **full entry remains failing**, `final-full-entry.log`, exit1/1ERROR, same preexisting announcer frame2 depth307/47406 before reduced section. Published entry retains that guard unchanged. No full-entry success, human play, continuous playback or art approval is claimed. Separate full legacy debt remains root-owned; no unrelated repair was attempted here.

## Frozen source proof and self-review

'''
report += f'Final child SHA256: `{digest}`. Matches repository, isolated stage and final full-entry/section receipts. `child.red.txt`, `child.final.txt`, `final-owned.diff` preserve exact inputs. `git diff --check` passes.\n\n'
report += 'Runtime/accepted QA/prior-source before=after SHA256, checked at every launch and final audit:\n\n'
for name, value in frozen.items():
    report += f'- `{name}`: `{value}`\n'
report += '''
Only one production-independent caller contract changed; the final opaque-foot restriction rejects pixels below448 or farther than1px above the anchor, and exact expected formal source/normalizer validation remains. Existing body/depth/contact methods are unmodified and executed by the final section. Prior successful embedded package runtime inputs are byte-identical; no export or broad/full-suite rerun was needed or performed.

Skipped full-suite, re-export and unrelated earlier-depth/full-legacy repair. Remaining limitation: published full clearance entry still fails before this now-passing section at the retained frame2 geometry guard; report and evidence expose it explicitly.
'''
target = ROOT / '.superpowers/sdd/2026-11-18-npc-approach-actions/final-fix-report.md'
target.write_text(report, encoding='utf-8')
with (target.parent / 'task-3-report.md').open('a', encoding='utf-8') as output:
    output.write('\n\n---\n\n' + report)
print(json.dumps(audit, indent=2))
