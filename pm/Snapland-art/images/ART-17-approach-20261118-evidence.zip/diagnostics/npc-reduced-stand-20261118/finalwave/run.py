"""Final P2 caller-only evidence, isolated on D; no production mutations."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import uuid

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from tools.build_desktop_release import prepare_runtime_stage
from tools.godot_entrypoints import run_validated_godot

HERE = Path(__file__).resolve().parent
ENGINE = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
CHILD = 'game/tests/native_sprite_clearance_review.gd'
ALLOW = ['native_sprite_clearance_review.gd', 'native_sprite_clearance_review.tscn',
         'native_npc_review.gd', 'native_layout_review.gd', 'native_review.gd',
         'audio_playback_release.gd']
FROZEN = ['game/world/park_world.gd', 'game/world/npc_activity.gd',
          'game/tests/native_npc_approach_review.gd', 'game/tests/native_npc_approach_review.tscn',
          'game/tests/audio_playback_release.gd', 'game/tests/test_npc_animation_states.gd',
          'game/tests/test_npc_world_activity.gd', 'game/tests/test_npc_walk_motion.gd',
          'game/tests/test_sprite_clearance.gd', 'game/tests/native_npc_review.gd']

def hashes(paths):
    return {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in paths}

PROBE = '''extends "res://game/tests/native_sprite_clearance_review.gd"
const Release := preload("res://game/tests/audio_playback_release.gd")
func _run() -> void:
	print("SECTION PROBE ONLY: invoking existing _review_reduced_motion_npcs with genuine Main; full entry is not claimed")
	progress = get_tree().root.get_node("Progress")
	progress.reset_progress()
	progress.intro_seen = true
	progress.settings["reduced_motion"] = false
	main = _instantiate_main()
	get_tree().root.add_child(main)
	await _frames(8)
	for record: Dictionary in main.world.npc_activity._records:
		if bool(record.get("active", false)):
			_npc_frame_records[String(record.role)] = record
	for role in NpcRoles:
		var sprite := _sprite_for_role(role)
		if sprite == null:
			await _fail("Section probe has no genuine NPC sprite: " + role)
			return
		_npc_material_baselines[role] = _capture_material_state(sprite.material_override as ShaderMaterial)
	main.world.set_physics_process(false)
	main.world.player.position = Vector3(15, 0.4, 24)
	main.world.set_time_of_day("noon")
	main.world.npc_activity.set_activity_paused(true)
	for role in NpcRoles:
		var sequence: Dictionary = load("res://game/world/character_animation_library.gd").new().get_sequence(role, "idle", "front")
		var texture := sequence.frames[0].texture as Texture2D
		print("FORMAL SOURCE DIAGNOSTIC ", role, " format=", texture.get_image().get_format(), " size=", texture.get_size(), " bottom=", _visible_alpha_bounds(texture.get_image()).end.y - 1, " anchor_row=", NpcActivityScript.ACTION_FEET_ROW, " anchors=", sequence.frames[0].anchors)
	if not await _review_reduced_motion_npcs(): return
	print("PASS: existing native clearance reduced-motion section only")
	main.quitting = true
	var playbacks := Release.capture(main.audio)
	main.audio.shutdown()
	main.queue_free()
	await _frames(2)
	if not await Release.wait_for_release(get_tree(), playbacks):
		push_error("Section probe audio teardown did not release")
		get_tree().quit(1)
		return
	get_tree().quit(0)
'''

def run(label, target, timeout=90, imported=False):
    assert hashes(FROZEN) == json.loads((HERE / 'frozen-before.json').read_text())
    profile = STAGE.parent / (STAGE.name + '-profiles') / label
    env = dict(os.environ, SNAPLAND_SAVE_PATH=str(profile / 'progress.json'),
               APPDATA=str(profile / 'appdata'), LOCALAPPDATA=str(profile / 'localappdata'),
               TEMP=str(profile / 'temp'), TMP=str(profile / 'temp'))
    for key in ['APPDATA','LOCALAPPDATA','TEMP']:
        Path(env[key]).mkdir(parents=True, exist_ok=True)
    cmd = [ENGINE, '--path', str(STAGE)] + (['--headless','--editor','--import','--quit'] if imported else [target])
    digest = hashlib.sha256((STAGE / CHILD).read_bytes()).hexdigest()
    start = time.monotonic()
    try:
        result = run_validated_godot(STAGE, cmd, env, timeout)
        output, code = result.stdout + result.stderr, result.returncode
    except subprocess.TimeoutExpired as exc:
        output, code = str(exc.output or '') + str(exc.stderr or ''), 'timeout'
    receipt = dict(label=label, command=cmd, environment={k: env[k] for k in ['SNAPLAND_SAVE_PATH','APPDATA','LOCALAPPDATA','TEMP','TMP']},
                   exit=code, seconds=round(time.monotonic()-start,3), errors=output.count('ERROR:'),
                   passes=output.count('PASS:'), child_sha256=digest, frozen_hashes=hashes(FROZEN))
    (HERE / (label + '.log')).write_text(output, encoding='utf-8')
    (HERE / (label + '.json')).write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    print(json.dumps(receipt), flush=True)

mode = sys.argv[1]
if mode == 'prepare':
    STAGE = Path('D:/Snapland-QA') / ('native-clearance-finalwave-20261118-' + str(uuid.uuid4())[:8])
    STAGE.mkdir()
    (HERE / 'stage-location.json').write_text(json.dumps(str(STAGE)), encoding='utf-8')
    (HERE / 'frozen-before.json').write_text(json.dumps(hashes(FROZEN), indent=2), encoding='utf-8')
    tracked = subprocess.check_output(['git','ls-files','-z'],cwd=ROOT,text=True,encoding='utf-8').split('\0')
    manifest = prepare_runtime_stage(ROOT, STAGE, tracked)
    for name in ALLOW:
        p = 'game/tests/' + name
        (STAGE / p).parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / p, STAGE / p)
        manifest[p] = hashlib.sha256((ROOT / p).read_bytes()).hexdigest()
    (HERE / 'stage-manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    (HERE / 'child.red.txt').write_bytes((ROOT / CHILD).read_bytes())
    (STAGE / 'game/tests/finalwave_reduced_probe.gd').write_text(PROBE, encoding='utf-8')
    (STAGE / 'game/tests/finalwave_reduced_probe.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://game/tests/finalwave_reduced_probe.gd" id="1"]\n[node name="ReducedSectionProbe" type="Node"]\nscript = ExtResource("1")\n', encoding='utf-8')
    (HERE / 'probe-source.txt').write_text(PROBE, encoding='utf-8')
    run('import', '', imported=True, timeout=300)
else:
    STAGE = Path(json.loads((HERE / 'stage-location.json').read_text()))
    if mode in ['red','green','green2','final']:
        shutil.copy2(ROOT / CHILD, STAGE / CHILD)
        (HERE / ('child.' + mode + '.txt')).write_bytes((ROOT / CHILD).read_bytes())
        if mode == 'green2':
            (STAGE / 'game/tests/finalwave_reduced_probe.gd').write_text(PROBE, encoding='utf-8')
            (HERE / 'probe-source.txt').write_text(PROBE, encoding='utf-8')
        run(mode + '-full-entry', 'res://game/tests/native_sprite_clearance_review.tscn')
        run(mode + '-reduced-section', 'res://game/tests/finalwave_reduced_probe.tscn')
    elif mode == 'diagnose':
        (STAGE / 'game/tests/finalwave_reduced_probe.gd').write_text(PROBE, encoding='utf-8')
        (HERE / 'probe-source.txt').write_text(PROBE, encoding='utf-8')
        run('diagnose-reduced-section', 'res://game/tests/finalwave_reduced_probe.tscn')
