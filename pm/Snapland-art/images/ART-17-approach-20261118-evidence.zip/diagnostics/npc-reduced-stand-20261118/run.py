"""Task-owned isolated evidence; engine launches use the project validator."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import uuid

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from tools.build_desktop_release import prepare_runtime_stage
from tools.godot_entrypoints import run_validated_godot

EVIDENCE = Path(__file__).resolve().parent
ENGINE = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
OWNED = ['game/world/npc_activity.gd', 'game/tests/test_npc_animation_states.gd',
         'game/tests/test_npc_world_activity.gd', 'game/tests/native_npc_approach_review.gd',
         'game/tests/test_sprite_clearance.gd', 'game/tests/test_npc_walk_motion.gd',
         'game/tests/native_npc_review.gd']
ALLOW = ['test_npc_animation_states.gd', 'test_npc_world_activity.gd',
         'test_npc_activity.gd', 'test_npc_walk_motion.gd', 'test_sprite_clearance.gd',
         'test_npc_departure_lifecycle.gd', 'test_npc_authored_source_walking.gd',
         'test_character_animation_library.gd', 'test_npc_dialogue_hold.gd',
         'test_npc_dialogue_hold.tscn', 'audio_playback_release.gd',
         'native_npc_approach_review.gd', 'native_npc_approach_review.tscn',
         'native_npc_motion_review.gd', 'native_npc_motion_review.tscn',
         'native_npc_review.gd', 'native_npc_review.tscn', 'native_layout_review.gd', 'native_review.gd',
         'test_npc_walk_direction_lifecycle.gd', 'test_authored_npc_patrol.gd']

def hashes():
    return {name: hashlib.sha256((STAGE / name).read_bytes()).hexdigest() for name in OWNED}

def snapshot(label):
    for name in OWNED:
        (EVIDENCE / (Path(name).name + '.' + label + '.txt')).write_bytes((ROOT / name).read_bytes())

def sync():
    for name in OWNED:
        shutil.copy2(ROOT / name, STAGE / name)
    for name in ALLOW:
        shutil.copy2(ROOT / 'game/tests' / name, STAGE / 'game/tests' / name)

def run(label, args, native=False, timeout=180):
    profile = STAGE.parent / (STAGE.name + '-profiles') / label
    env = dict(os.environ, SNAPLAND_SAVE_PATH=str(profile / 'progress.json'),
               APPDATA=str(profile / 'appdata'), LOCALAPPDATA=str(profile / 'localappdata'))
    for key in ['APPDATA', 'LOCALAPPDATA']:
        Path(env[key]).mkdir(parents=True, exist_ok=True)
    command = [ENGINE, *([] if native else ['--headless']), '--path', str(STAGE), *args]
    started = time.monotonic()
    launched_hashes = hashes()
    try:
        result = run_validated_godot(STAGE, command, env, timeout)
        output, code = result.stdout + result.stderr, result.returncode
    except subprocess.TimeoutExpired as exc:
        output, code = str(exc.output or '') + str(exc.stderr or ''), 'timeout'
    receipt = dict(label=label, command=command, environment={k:env[k] for k in ['SNAPLAND_SAVE_PATH','APPDATA','LOCALAPPDATA']},
                   exit=code, seconds=round(time.monotonic()-started,3), passes=output.count('PASS:'),
                   errors=output.count('ERROR:'), hashes=launched_hashes)
    (EVIDENCE / (label + '.log')).write_text(output, encoding='utf-8')
    (EVIDENCE / (label + '.json')).write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    print(json.dumps(receipt), flush=True)

mode = sys.argv[1]
if mode == 'prepare':
    STAGE = Path('D:/Snapland-QA') / ('npc-reduced-stand-20261118-' + str(uuid.uuid4())[:8])
    STAGE.mkdir()
    (EVIDENCE / 'stage-location.json').write_text(json.dumps(str(STAGE)), encoding='utf-8')
    tracked = subprocess.check_output(['git','ls-files','-z'],cwd=ROOT,text=True,encoding='utf-8').split('\0')
    copied = prepare_runtime_stage(ROOT, STAGE, tracked)
    for name in ALLOW:
        relative = 'game/tests/' + name
        (STAGE / relative).parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / relative, STAGE / relative)
        copied[relative] = hashlib.sha256((ROOT / relative).read_bytes()).hexdigest()
    (EVIDENCE / 'stage-manifest.json').write_text(json.dumps(copied, indent=2), encoding='utf-8')
    snapshot('red')
    run('import', ['--editor','--import','--quit'], timeout=300)
else:
    STAGE = Path(json.loads((EVIDENCE / 'stage-location.json').read_text()))
    sync()
    if mode in ['red','green','green2','green3']:
        snapshot(mode)
        for name in ['test_npc_animation_states','test_npc_world_activity']:
            run(mode + '-' + name, ['--script', 'res://game/tests/' + name + '.gd'], timeout=45)
    elif mode == 'regressions':
        for name in ['test_npc_activity', 'test_npc_walk_motion', 'test_sprite_clearance',
                     'test_npc_departure_lifecycle', 'test_npc_authored_source_walking',
                     'test_character_animation_library', 'test_npc_walk_direction_lifecycle',
                     'test_authored_npc_patrol']:
            run('green-' + name, ['--script', 'res://game/tests/' + name + '.gd'])
        run('green-dialogue', ['res://game/tests/test_npc_dialogue_hold.tscn'])
    elif mode == 'native':
        output = STAGE.parent / (STAGE.name + '-native-reduced')
        (EVIDENCE / 'native-location.json').write_text(json.dumps(str(output)), encoding='utf-8')
        run('green-native-reduced', ['res://game/tests/native_npc_approach_review.tscn', '--',
            '--animation-output=' + str(output), '--reduced-motion', '--rebuild'], native=True)
    elif mode == 'legacy':
        run('legacy-import', ['--editor','--import','--quit'], timeout=180)
        run('legacy-native-preexisting-failure', ['res://game/tests/native_npc_review.tscn'], native=True, timeout=30)
