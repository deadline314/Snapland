"""Launch a source-verified Main-backed walk input capture with a fresh profile."""
from pathlib import Path

here = Path(__file__).resolve().parent
template = here.parent / "art17-side-photo-20261119/final_checks.py"
source = template.read_text("utf8")
source = source.replace('local_stage = ROOT / ".review/art17-side-photo-20261119/runtime-staging"',
    'local_stage = ROOT / ".review/art17-walking-gesture-20261119/runtime-staging"')
source = source.replace("native_profile_photo_study", "native_walking_gesture_study")
source = source.replace("AvatarProfilePhotoQA.exe", "AvatarWalkingGestureQA.exe")
source = source.replace('d_stage if sys.argv[1] == "package" else local_stage', 'local_stage')
source = source.replace(
    "exec(compile(runner_source, str(helper), \"exec\"), runner.__dict__)",
    """
expected = next(line for line in runner_source.splitlines() if '"Asset donor differs in asset or configuration bytes"' in line)
runner_source = runner_source.replace(expected, '''
    old_asset_keys = {name for name in old if name.startswith("assets/") or name in {"project.godot", "export_presets.cfg"}}
    assert old_asset_keys == {name for name in manifest if name.startswith("assets/") or name in {"project.godot", "export_presets.cfg"}}
    for name in old_asset_keys:
        if old[name] != manifest[name]:
            prior, current = donor / "project" / name, stage / name
            assert name.endswith(".json") and sha(prior) == old[name] and sha(current) == manifest[name]
            assert prior.read_text("utf8") == current.read_text("utf8"), name
''')
exec(compile(runner_source, str(helper), "exec"), runner.__dict__)
""".replace("'''", '"""'))
begin = source.index('    if mode!="reduced":')
end = source.index("''' + source[end:]",begin)
source = source[:begin] + '''    labels = {"walk-key-f","walk-key-p","walking-talk"}
    cases = [item for item in report["actions"] if item["label"] in labels]
    assert len(cases) == 3 and {item["label"] for item in cases} == labels
    assert all(item["predicate"] for item in cases)
''' + source[end:]
exec(compile(source, str(here/"verify.py"), "exec"))
