extends "res://game/tests/native_island_animation_acceptance.gd"

func _hero_actions() -> void:
	_world.set_avatar_hair_motion_enabled(false)
	_press(KEY_W, true)
	await _physics_frames(25)
	for key in [KEY_F, KEY_P]:
		var label := "walk-key-" + OS.get_keycode_string(key).to_lower()
		var before := _walking_pose()
		_press(key, true)
		_press(key, false)
		var after := _walking_pose()
		await _physics_frames(3)
		var kept_walking: bool = _world.last_avatar_action == "walk" and _world.avatar_action.is_empty()
		await _record_action(label, "walk", "back", "authored", _actor_anchor(),
			before.direction == "back" and before == after and kept_walking,
			{"before":before, "after_key":after, "kept_walking":kept_walking})
		await _capture(label)
	_press(KEY_W, false)
	await _wait_hero_settle()

	var guide: Dictionary = _world._point_by_id("guide")
	var approach: Vector3 = Vector3(guide.position.x, 0, guide.position.z + 1.65)
	approach.y = _world.ground_surface_y(approach)
	_world.player.global_position = approach
	await _physics_frames(6)
	_press(KEY_W, true)
	await _physics_frames(10)
	var before := _walking_pose()
	var nearest: String = _world.nearest.get("id", "")
	var started_walking: bool = _world.avatar_is_walking and before.direction == "back"
	_press(KEY_E, true)
	_press(KEY_E, false)
	var after := _walking_pose()
	var opened: bool = _world.blocked and _main.modal_kind == "dialogue"
	_press(KEY_W, false)
	await _physics_frames(4)
	var planted: bool = not _world.avatar_is_walking and _world.last_avatar_action == "interact" and _world.avatar_action_elapsed == 0.0
	await _record_action("walking-talk", "interact", "front", "authored", _actor_anchor(),
		nearest == "guide" and started_walking and before == after and opened and planted,
		{"nearest":nearest, "before":before, "after_key":after, "dialogue_opened":opened, "planted":planted})
	await _capture("walking-talk")

func _walking_pose() -> Dictionary:
	return {"direction":_world.facing, "displayed_direction":_world.last_avatar_direction,
		"frame":_world.last_avatar_frame, "texture":_world.avatar.texture.get_instance_id()}
