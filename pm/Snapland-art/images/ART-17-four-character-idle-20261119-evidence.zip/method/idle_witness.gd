extends "res://game/tests/native_island_animation_acceptance.gd"

const RIGID_LOWER_BODY := Rect2i(0, 198, 280, 162)
var _reviewed_idle_frames: Dictionary = {}

func _hero_sprite_source_consistent() -> bool:
	var rig: SubViewport = _world.avatar_hair_rig
	if not is_instance_valid(rig) or not bool(rig.active):
		return super._hero_sprite_source_consistent()
	if not _world.avatar.is_visible_in_tree() or _world.avatar.texture != rig.get_texture():
		return false
	var direction: String = _world.last_avatar_direction
	var frame: int = _world.last_avatar_frame
	var action: String = _world.last_avatar_source_action
	if direction != "front" or action != "idle" or not String(rig.pose_key).begins_with("%s|%s|%d|" % [direction, action, frame]):
		return false
	if _reviewed_idle_frames.has(frame): return bool(_reviewed_idle_frames[frame])
	var source: Image = _world.avatar_renderer.texture(_world.avatar_appearance, _world.avatar_equipped, direction, frame, action).get_image()
	var visible: Image = _world.avatar.texture.get_image()
	if visible == null or visible.get_size() != source.get_size(): return false
	var expected := source.get_region(RIGID_LOWER_BODY).get_data()
	var actual := visible.get_region(RIGID_LOWER_BODY).get_data()
	var strong := 0
	var differences := 0
	for index in range(0, expected.size(), 4):
		if maxi(expected[index + 3], actual[index + 3]) < 128: continue
		strong += 1
		for channel in range(4):
			if absi(expected[index + channel] - actual[index + channel]) > 2:
				differences += 1
				break
	var valid := strong > 8000 and differences == 0
	var evidence: Dictionary = _report.get("live_idle_lower_body", {})
	evidence[str(frame)] = {"verified_pixels": strong, "changed_pixels": differences, "pose_key": String(rig.pose_key)}
	_report["live_idle_lower_body"] = evidence
	_reviewed_idle_frames[frame] = valid
	return valid
