"""Observe the stock Main scene for one full 30-second character cycle."""
from pathlib import Path
import importlib.util
import shutil
import subprocess
import sys

HERE=Path(__file__).resolve().parent
ROOT=Path("C:/Users/stanl/Github/Snapland")
HELPER=ROOT/".review/cotton-wind-20261118/final-fix/native_run.py"
spec=importlib.util.spec_from_file_location("native_role_coverage",HELPER)
runner=importlib.util.module_from_spec(spec)
source=HELPER.read_text("utf8")
source=source.replace('Path(keys[key]).drive.upper() == "D:"','Path(keys[key]).drive == base.drive')
source=source.replace('donor.drive.upper() == "D:" and donor.parent in {QA, QA.parent / "task4"}','donor.parent == QA')
strict=next(line for line in source.splitlines() if "Asset donor differs in asset or configuration bytes" in line)
source=source.replace(strict,'''
    names={name for name in old if name.startswith("assets/") or name in {"project.godot","export_presets.cfg"}}
    assert names=={name for name in manifest if name.startswith("assets/") or name in {"project.godot","export_presets.cfg"}}
    for name in names:
        if manifest[name]==old[name]: continue
        a,b=donor/"project"/name,stage/name
        assert name.endswith(".json") and sha(a)==old[name] and sha(b)==manifest[name]
        assert a.read_text("utf8")==b.read_text("utf8"),name
''')
exec(compile(source,str(HELPER),"exec"),runner.__dict__)
runner.QA=HERE/"native"
validate=runner.run_validated_godot


def validated_command(project, command, *args, **kwargs):
    if "--" in command and command[-2]=="--log-file":
        end=command[-2:]
        del command[-2:]
        command[command.index("--"):command.index("--")]=end
    return validate(project,command,*args,**kwargs)


runner.run_validated_godot=validated_command
scene="game/tests/native_island_animation_acceptance"
runner.FIXTURES=[scene+".gd",scene+".tscn"]
role=sys.argv[1]
donor=Path(sys.argv[2])
witness="game/tests/native_avatar_idle_witness"
if role=="traveller":
    scene=witness
    runner.FIXTURES.extend([witness+".gd",witness+".tscn"])
assert role in ("traveller","ticket","imp","announcer")
folder=runner.make_base("idle-"+role)
project=folder/"project"
project.mkdir()
files=subprocess.check_output(["git","ls-files","-z"],cwd=ROOT,encoding="utf8").split("\0")
graph=runner.prepare_runtime_stage(ROOT,project,files)
for name in runner.FIXTURES:
    file=project/name
    file.parent.mkdir(parents=True,exist_ok=True)
    fixture=HERE/("idle_witness"+Path(name).suffix) if name.startswith(witness+".") else ROOT/name
    shutil.copy2(fixture,file)
    graph[name]=runner.sha(file)
runner.dump(folder/"source-graph.json",{"base":subprocess.check_output(["git","rev-parse","HEAD"],cwd=ROOT,text=True).strip(),
    "source_raw_sha256":graph,"fixtures":runner.FIXTURES})
runner.copy_imports(donor,project,graph)
out=folder/"captures"
command=[runner.ENGINE,"--path",project,"res://"+scene+".tscn","--rendering-method","gl_compatibility",
    "--audio-driver","Dummy","--fixed-fps","30","--write-movie",folder/"capture.avi","--","--actor="+role,
    "--idle-only","--animation-output="+out.as_posix()]
receipt=runner.launch(folder,project,graph,"idle-"+role,command,runner.environment(folder))
report=runner.read(out/f"{role}-report.json")
assert receipt["passed"] and report["technical_status"]=="PASS",report["failures"]
idle,=[row["detail"] for row in report["actions"] if row["label"]=="natural-idle-30s" and row["predicate"]]
assert idle["simulation_seconds"]>=30.0 and idle["scheduler_live"] and idle["observable_source_cel_changes"]
print(folder)
print(role,idle["simulation_seconds"],idle["observed_actions"],len(idle["observed_source_frames"]))
