from pathlib import Path
import json
import math
from PIL import Image,ImageDraw,ImageOps

HERE=Path(__file__).resolve().parent
ROLES=("traveller","ticket","imp","announcer")
WITNESSES={
    "traveller":["natural-idle-front-0","natural-idle-front-4","natural-idle-front-6","natural-idle_gesture-front-0","natural-idle_gesture-front-1","natural-idle_gesture-front-2"],
    "ticket":["natural-stand-front-0","natural-stand-front-3","natural-idle_gesture-front-2","natural-emotion_happy-front-3","natural-depart-left-2","natural-settle-right-2"],
    "imp":["natural-stand-front-0","natural-stand-front-2","natural-dance-front-2","natural-emotion_proud-front-3","natural-depart-left-2","natural-settle-right-2"],
    "announcer":["natural-stand-front-0","natural-stand-front-3","natural-special-front-2","natural-emotion_curious-front-3","natural-depart-left-2","natural-settle-right-2"],
}
sheet=Image.new("RGB",(1320,1040),"#27313a")
draw=ImageDraw.Draw(sheet)
for row,role in enumerate(ROLES):
    choices=[]
    for run in (HERE/"native").glob(f"idle-{role}-1119-*"):
        if (run/"receipt.json").is_file() and json.loads((run/"receipt.json").read_text("utf8"))["passed"]:
            choices.append(run)
    assert len(choices)==1,(role,choices)
    captures=choices[0]/"captures"
    report=json.loads((captures/f"{role}-report.json").read_text("utf8"))
    rows={item["label"]:item["framing"] for item in report["captured_frame_framing"]}
    for column,label in enumerate(WITNESSES[role]):
        crop=rows[label]
        assert crop["full_silhouette_inside_hud_safe_viewport"]
        x,y,w,h=crop["sprite_alpha_screen_rect"]
        rect=(math.floor(x-9),math.floor(y-9),math.ceil(x+w+9),math.ceil(y+h+9))
        with Image.open(captures/f"{role}-{label}.png") as image:
            cel=ImageOps.contain(image.convert("RGB").crop(rect),(213,224))
        start_x=column*220+(220-cel.width)//2
        start_y=row*260+27+(224-cel.height)//2
        sheet.paste(cel,(start_x,start_y))
        draw.text((column*220+6,row*260+6),role+" / "+label.removeprefix("natural-"),fill="white")
sheet.save(HERE/"four-role-native-contact.png")
