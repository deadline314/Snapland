Merged HEAD a804d056e9b43651fc5ba44d5a0ce878be49b670
Command: python -m unittest tests.test_runtime_result_contract tests.test_godot_entrypoints -v
Observed root console: 38 tests,4.557s,OK, exit0. Both five syrup suite contracts and Pixel UI-only240s limit preserved.
