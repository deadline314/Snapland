# SG-43 whole-branch final review

Reviewed 2026-11-18. Base `fdcd751365d775ce1a9616c7bf73e629f6b7dc2a`; head `4d2acb5638ff79699845f85f3ff1f9311d551a82`. Nine commits, 51 changed files, 2668 insertions / 75 deletions, plus binary evidence. The reviewed head matches the checkout; tracked working files were clean.

## Strengths

- `game/minigames/syrup_flood_model.gd:13` implements a distinct, bounded thermal/material game rather than a renamed existing mode. Three fixed branches, one heater, one designated helper, real cold material and closed-valve settlement remain the single gameplay authority. The 166-line model adds no dependency or general fluid framework.
- `game/minigames/syrup_flood_model.gd:88` rejects invalid delta, caps/subdivides simulation, clips the final step and resolves success before timeout. Overflow counts once, draining preserves time and penalties, hot diversion cannot form a cold plug, and configuration pause cannot settle a reward. Inclusive target bands, participation and devil eligibility match the authority.
- `game/minigames/syrup_flood_driver.gd:31` and `game/minigames/syrup_flood_view.gd:64` keep input ownership and lifecycle cleanup explicit. Keyboard echo/repeated holds, Shift-Tab release, second touches, emulated mouse, outside releases and focus/reset/tree exit have meaningful coverage. The view displays model values and retains its 3D nodes/materials; it does not simulate a competing flow model.
- `game/core/game_catalog.gd:5`, `game/data/candy_games.json:34`, `game/ui/tutorial_catalog.gd:7` and `game/world/candy_world.gd:91` connect only actual game-027, candy local index 3 and its fixed identities. The 128-candidate baseline, existing game rows, old lessons, progress schema and reward machinery remain intact. Entry, maps, lesson, rules, book and retake paths all have consumers and checks.
- `game/tests/test_syrup_flood.gd:40`, `game/tests/test_syrup_flood_session.gd:32` and `game/tests/native_syrup_flood_main.gd:267` exercise actual operations, Session processing and natural results. Numerical checks are supplemented by actual parsed keyboard/mouse/touch GPU routes and separate-process original-image verification. Headless synthetic PNG I/O is explicitly distinguished from native photographic evidence.
- `tools/run_game_tests.py:25` registers all five suites with exact completion markers and the correct script/scene entry types. Negative catalogue and runner tests remain meaningful rather than merely raising expected counts. No production save-path, decoder, trust-boundary or economy bypass was introduced.

## Plan and ruling assessment

Read the authority specification, implementation plan, complete progress ledger including all rulings/deferred items, all four task reviews and relevant producer report sections. Reviewed the supplied whole-branch diff in sequential sections; the oversized first response truncated its middle, so omitted sections were recovered from the same package. Adjacent source reads were limited to concrete Session timing/input and photo-preservation questions. No source/Git mutation or engine/test rerun was performed; this report is the only written file.

- **Gameplay choice and calibration:** approved. Shared heat, inertia, real cold diversion, overflow recovery and manual/AI closure provide the requested different gameplay. The specified coefficients, 75 seconds, 100/110/90 capacities, 90–100% bands, cold threshold 0.30, 12-unit plug and 92% helper boundary are present. Actual A/B ordinary/devil and assisted routes establish feasibility without weakening success conditions.
- **C configuration versus Esc pause:** approved. Model-local configuration freezes time/material while allowing configuration. The unchanged Session driver branch returns before the legacy game clock, synchronizes elapsed from the model and suppresses processing while Session-paused (`game/minigames/session.gd:1004`, `:2235`). Task 2 configuration and Task 3 pause/retry evidence cover both contracts.
- **Tutorial allowlist and retake row ownership:** approved. Each is a required narrow integration point, with no unrelated framework change. The existing prop vocabulary is reused; this does not add another game or fabricate a challenge result.
- **In-place feature branch and D stages:** acceptable within the recorded authorization. The reviewed diff is isolated on the feature branch. Reported stages/profiles are separately identified, and pre-existing untracked import/UID files were left untouched. No cleanup/deletion action is part of this review.
- **Synthetic admission and controlled placement:** approved with the existing disclosure. Six welcome cards and opening context provide access; no game-027 state/result/card/reward is injected in the native acceptance path. Positioning the actor is not walking evidence. Headless retake PNG I/O is separately labelled synthetic; final native evidence uses actual rendered pixels.
- **MAIN-34 dependency and rebase:** approved. Shared small-window rules repair is already in the base. Final native coverage visits all five rules pages; the merged 2025-page PixelShell and Cookie Main evidence addresses the current integration. Canonical Git-blob identity and final source/runtime manifests account for CRLF checkout differences rather than passing off older raw hashes as current ones.
- **Deferred headless material warnings:** retain as the nonblocking Minor below. The ruling does not permit ERROR suppression or substitute headless output for native acceptance.

## Independent photo-policy assessment

The gameplay-refresh ruling is acceptable for this change. I read `design/runtime/photo-originals.md`, `design/runtime/free-photo-retake.md`, MAIN-16 and the current attachment/save paths; this conclusion is not based solely on the root ruling.

MAIN-16 requires ordinary/devil gameplay cards to share the captured source. `game/main.gd:2167` and `:2180` save gameplay thumbnails/originals under game/index paths; `game/core/progress.gd:266` updates gameplay attachment targets while explicitly excluding acquisition method `retake`. The existing native collection fixture at `game/tests/native_photo_collection_review.gd:135` checks shared paths after the subsequent devil run. SG-43 does not change any of these operations.

The free-retake document's general sentence about not automatically overwriting owned photos sits in the fixed-entry/retake flow; its detailed preservation contract specifically retains retake photos, their first acquisition source and later genuine challenge proof. The independent single-card retake save path and attachment exclusion implement that distinction. Reading the general sentence as immutable first-gameplay bytes would conflict with the established shared gameplay path behavior and require a separate policy/implementation change. Nothing in SG-43 promises that stronger invariant.

Accordingly, repeated card-dictionary equality is not proof of immutable gameplay pixels. The native report, archive README and PM delivery text correctly disclose successive ordinary/devil/assisted/timeout gameplay SHA changes. Genuine retake originals have separate byte/path/provenance checks after a real matching challenge and process restart (`game/tests/native_syrup_flood_main.gd:312`, `:366`). No photo-preservation defect requiring an SG-43 change was found. Earlier MAIN-16 failure-ineligibility wording predates the later explicit participation-collection policy; honest participated failure is now deliberately eligible and is tested as such.

## Evidence adequacy and limits

- Retained task reviews independently checked model **308**, driver **96**, view **104**, Session **46**, Main and **23 selected runtime suites**. Coverage includes actual input trajectories, final-step timing, no-operation exclusion, spill recovery, exact score rows, both prior factory games, catalogue identities, retakes and lesson integration. This is adequate affected-scope coverage; it is not a full old-26 winning-route replay.
- Task 4's fresh review independently hashed/decoded the final **194 PNGs**, checked **16 clean processes / 24 natural results**, all eight isolated writer/reader profiles, **1195 source/runtime identities**, engine/templates and actual embedded QA executable. It reviewed exact commands and exclusions, including executable writer/reader launches without a path/scene override. I rely on that retained independent artifact verification and did not repeat those checks.
- Root's raw-image review records direct inspection of every flow family, all three sizes, small-window large text/reduced motion, selected retakes and executable reopening. This closes the earlier standalone-view/headless limits without claiming subjective art or human gameplay acceptance. I read that review rather than duplicate its image-by-image inspection.
- Independently inspected the delivered archive inventory/README: **479 ZIP members**, comprising **477 manifest-listed evidence entries plus manifest/README**, including all four task review reports and root visual review. It correctly excludes the executable/player profile and states the admission, placement, photo-refresh and human-acceptance boundaries. Root reports CRC and all-entry SHA verification; I did not repeat it.
- Latest scoped shard/design/link/runtime-coverage checks and merged PixelShell/Cookie evidence are retained in the ledger. The MAIN-34 corrected-base full Python CI success is not asserted to be SG-43 final-main CI success. Root still owns final fetch/rebase/merge/push and checking the resulting main CI.

## Issues

### Critical (Must Fix)

None found.

### Important (Should Fix)

None found.

### Minor (Nice to Have)

- **Inherited headless occlusion warning noise remains deferred.** `.review/syrup-flood-20261118/integration/affected-syrup-Main-tests.log:18` contains unsupported-material diagnostics from the unchanged `game/world/occlusion_controller.gd:178`; the same warning appears in `baseline2-sugar-Main-tests.log:8`. This makes the headless run non-pristine but is not a new syrup failure: geometry is preserved rather than silently replaced, strict ERROR/exit/marker checks remain enabled, and the final 16 GPU logs are reported warning-free and independently checked by Task 4. Keep the disclosed baseline limitation; investigate material support separately if that rendering path needs support. No SG-43 implementation change is required.

## Recommendations

No additional same-code test rerun or code revision is justified by this review. Complete the already-planned Git delivery and inspect final-main CI before claiming delivery/CI completion. Keep the existing distinction between scripted acceptance and the open ART/MIC/story acceptance work.

## Declined to judge

- Human enjoyment/difficulty balance, human hearing and continuous art naturalness: automated numerical/GPU evidence cannot establish these; ART-16/17, MIC-1/2/3 and ST-5 remain open.
- Cross-device performance, multiplayer/P2P and physical touchscreen hardware: this is the requested single-player implementation with scripted modality checks on the recorded machine, not deployment evidence for those targets.
- Earned six-card admission and continuous walking from a fresh save: deliberately disclosed fixture setup/placement, outside the new game's acceptance route; existing admission/travel regressions remain separate.
- A full replay of all previous 26 games' winning trajectories: unaffected production implementations are unchanged and affected checks are retained; no such broad replay was claimed.
- Immutable historical first-gameplay photographs as a new product policy: considered explicitly above and not required by the current gameplay/retake contracts; existing retake-byte preservation was judged and covered.
- Final remote main/CI completion and deletion of the delivered branch: future root-owned delivery actions, not observable completion at this review head.

## Assessment

**Ready to merge? Yes.**

The complete branch implements the specified independent game with bounded state/rendering, preserves existing integration and identity contracts, and has adequate layered numerical/input/native/package/save evidence. No blocking correctness, regression, security or performance defect was found; the inherited headless warning and stated acceptance limits remain explicit.

Skipped: same-code test/export reruns, repeated full artifact hashing and duplicate raw-image inspection; no new unanswered concrete defect warranted them.
Remaining risk: final-main CI/delivery is pending, and automated acceptance does not establish human enjoyment, hearing, art naturalness or cross-device performance.
