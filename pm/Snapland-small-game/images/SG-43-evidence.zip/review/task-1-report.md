# Task 1 report — ready for review

Status: complete, uncommitted; root owns Git/PM and review. Only production changes are `game/minigames/syrup_flood_model.gd` and `game/tests/test_syrup_flood.gd`. No player save, accepted QA stage, other game source, index or HEAD was changed.

## Source freeze

- Base assigned: `46c1cbe`, branch `codex/syrup-flood-20261118`.
- Model SHA256: `07f23722692c4ca185f4a3a9d328f621dc60f29f4bbdeab514f07814f4333504`.
- Fixture SHA256: `e256156ff85d4204b1f885661a4e5e4f8a4dd75d911a72509a10bdc6ce706f79`.
- Authority: `design/runtime/syrup-flood-gameplay.md`; exact frozen APIs and all required snapshot fields implemented. RefCounted dictionary state, deep-copy snapshots, SceneTree public-operation fixture follow house CookieMold patterns.

## RED → GREEN evidence

Commands from repository root:

```powershell
python .review/syrup-flood-20261118/model/run.py red
python .review/syrup-flood-20261118/model/run.py green1
python .review/syrup-flood-20261118/model/run.py green2
python .review/syrup-flood-20261118/model/run.py green3
python .review/syrup-flood-20261118/model/run.py final
```

Each launcher invocation creates a new `D:/Snapland-QA/syrup-model-<label>-<uuid>/project`, calls `tools.build_desktop_release.prepare_runtime_stage` on the actual `git ls-files -z` runtime inventory, then copies only the two exact owned new source/test paths. It never copies C: import caches or the whole repository. Both import and actual SceneTree `--script` runs use `tools.godot_entrypoints.run_validated_godot`, exact engine `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe`, `--headless --path <fresh-stage>`. Import adds `--editor --import --quit`; test adds `--script res://game/tests/test_syrup_flood.gd`.

Fresh per-process D: `SNAPLAND_SAVE_PATH`, `APPDATA`, `LOCALAPPDATA`, `TEMP`, `TMP` are recorded verbatim with exact commands and all staged source hashes in `.review/syrup-flood-20261118/model/<label>-receipt.json`. Small logs/receipts remain in that private directory. Failed initial launcher encoding attempt created an unused new D directory only; it never started Godot. Launcher then explicitly decoded Git's UTF-8 filename inventory.

| Run | Import exit/errors | SceneTree exit/errors | Actual result |
|---|---|---|---|
| red | 0 / 0 | 1 / 1 | `Syrup flood tests: 1 checks, 1 failures`; missing-resource guard before model existed |
| green1 | 0 / 0 | 1 / 6 | All eight routes succeeded; rules exposed repeated-spill counting and subnanosecond floating cutoff residue |
| green2 | 0 / 0 | 0 / 0 | `Syrup flood tests: 273 checks, 0 failures` |
| green3 | 0 / 0 | 0 / 0 | `Syrup flood tests: 299 checks, 0 failures`; added true final-substep/helper contrast and preserved-tank spill recovery |
| final | 0 / 0 | 0 / 0 | **`Syrup flood tests: 308 checks, 0 failures`**; added frozen A/B calibration, assistance ratio and heat-off assertions |

Exact logs: `<label>-import.log`, `<label>-test.log`; final logs and receipt are the acceptance artifacts. No full suite was duplicated. This is scripted numerical/model validation, not human playtesting or GPU/native UI acceptance.

## Final numeric calibration

All authority coefficients unchanged: 75 seconds; effective step capped at 0.25, split into at most 1/60-second substeps; temperatures 0..1, initial 0.18; capacities `[100,110,90]`, target volume `[90,99,81]`; A length `[1,1.35,0.85]` / heat capacity `[1,1.4,0.8]`; B length `[1.3,0.85,1.1]` / heat capacity `[1.6,0.75,1.2]`. Heating `0.4*(1-T)/heat_capacity`, cooling `0.04*T`; nominal flow `(1.6+8.4*T*T)/length`; assistance factor 0.75; unsealed normal middle flow split 65% tank / 35% leak. Cold threshold 0.30; required actual material 12; hot bypass melts partial material at 0.6 per hot unit. Helper closes its sole designated tank at 92%; success band inclusive 90..100% and all three valves closed. Score `max(0,100*filled_tanks +100*success +100*devil -20*mistakes)`.

Viscosity is `1/(1.6+8.4*T*T)`, monotonic opposite to thermal flow, read from the model. A subnanosecond (`1e-9` seconds) floating cutoff residue is normalized to exactly 75, without permitting extra simulated material or a coarse early finish. No gameplay coefficient or eligibility/cold-plug/success rule was relaxed.

## Public recipes for Session translation

The fixture's `static solve(model, plug=false)` reads only `snapshot()` and invokes public operations. Session can translate each operation into genuine key/button input; no private state or generic adapter dependency is required. Observe each step at 1/60 seconds; release each input between commands.

1. Reset the selected A/B and assistance mode. Select each branch 0,1,2 and open its valve. Leave all three open initially.
2. Ordinary route: leave normal outlet throughout. Devil route: select middle branch 1 and toggle diversion before simulation. It must actually remain cold and flow until `cold_plugged`; no precomputed award or injected material.
3. Select branch 0 and turn on the shared heater. Each frame, close every still-open valve whose snapshot `fill >= capacity*0.92`.
4. Heat the lowest-index branch still below 92%, excluding middle while diversion is active. Change heater only if the selected heater differs. Thus initial heat remains on outer 0 while cold middle feeds the crack; on physical seal the model restores middle's tank outlet. Heat rotates 0→1→2 as each target is attained. Outer pipes continue filling with cold flow and residual heat meanwhile.
5. The final real valve close ends the round; never set success, score, elapsed, fill or plug amount directly. Snapshot result supplies all awards.

| Variant | Assistance | Route | Elapsed | Final fills 0/1/2 | Score |
|---|---|---|---:|---|---:|
| A | off | ordinary | 41.10000 | 92.01776 / 101.20952 / 82.83047 | 400 |
| A | off | cold plug/devil | 36.03333 | 92.01776 / 101.23798 / 82.82506 | 500 |
| A | on | ordinary | 53.71667 | 92.03141 / 101.20928 / 82.82283 | 400 |
| A | on | cold plug/devil | 46.45000 | 92.03141 / 101.22344 / 82.88418 | 500 |
| B | off | ordinary | 39.25000 | 92.09549 / 101.28457 / 82.85386 | 400 |
| B | off | cold plug/devil | 36.01667 | 92.09549 / 101.32074 / 82.85879 | 500 |
| B | on | ordinary | 50.43333 | 92.00609 / 101.23659 / 82.80067 | 400 |
| B | on | cold plug/devil | 46.08333 | 92.00609 / 101.23289 / 82.83654 | 500 |

All are genuine zero-mistake success, all ordinary eligible, and devil iff real cold material sealed the crack. The same threshold recipe works without AI. AI is tested separately through actual filling.

Final-substep evidence: use helper to fill/close 0 then 1; select and heat 2 with valve closed; delay opening 2 while it warms. Public bisection on opening time brackets success at `67.00373840` seconds and failure at `67.00378418` seconds. Success occurs at exactly `75.00000000`, final tank actual fill `82.80025407`, helper closes before timeout evaluation. A slightly later opening fails at the same cutoff. This calibrates only fixture input timing through public operations, not model coefficients.

## Snapshot/behavior notes for consumers

- `branches` is exactly three dictionaries, with actual units `length`, `heat_capacity`, `capacity`, `target`, `temperature`, `viscosity`, `flow`, `fill`, `valve`, `spoiled`, `leaked`. All spec top-level fields exist. UI must consume them rather than duplicate thermal/score formulas.
- `heater` and `helper` are `-1` or branch 0..2; `selected` always 0..2. Selecting heater's current branch again turns heat off. Selecting helper's current branch cancels helper. `variant` wraps into 0/1.
- `diversion` is a boolean for the sole middle outlet. A closed bypass creates no material; hot flow cannot seal and melts partial progress. Completion automatically restores outlet. `plug_amount` locks at 12; no second crack.
- `flow` is current simulated upstream flow and becomes zero on manual/helper/spill valve closure. `leaked` includes diverted crack flow, including the real cold material, and is cumulative through drains. `fill` deliberately remains slightly above capacity for spoiled overline display.
- Overflow increments mistakes once per event, closes the valve, and blocks reopening until drain. Drain only clears selected fill/spoil, preserves other completed tanks, mistakes, leakage and time. Empty drain grants no participation.
- `ordinary_eligible` settles only on normal finish/timeout from actual participation. Selection/helper/configuration/wait alone are ineligible. Session still excludes cancel/practice.
- Configuration stops heat/flow/time, allows commands and never awards a finished result while paused; resume's next step evaluates closed filled tanks. `clear_input()` deliberately does nothing to latched controls. Ended operations are inert; reset explicitly starts another round.
- Snapshot is recursively copied. No history arrays, injected state/results or external dependencies.

## Self-review and remaining scope

Reviewed APIs, initial values, real flow/heat differences, shared heat/cold reserve, bypass material/melt, helper restrictions, score source, 90% inclusive success band and closed-valve requirement, timeout precedence, finite/huge delta bounds, invalid indices, deep-copy isolation, overflow idempotence/recovery, paused command behavior, ended idempotence. Fixture assertions exercise public state/operations and meaningful controls; they do not call private methods or mutate model internals.

Skipped driver/view/Session/Main/catalog/runner/PM/Git by assigned ownership; no rendering, human playtesting, native GPU, packaging or real input verification is claimed. Those consumers still need to translate this recipe and verify their own input/retained 3D/save paths. No known remaining model defect; private launcher evidence is for this task only, not a replacement for integration acceptance.
