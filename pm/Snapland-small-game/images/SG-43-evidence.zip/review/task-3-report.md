# Task 3 report — integration ready for review

Status: implementation and assigned checks complete, uncommitted; root owns Git/PM, fresh review and native Task4 acceptance. BASE `65344a3`, branch `codex/syrup-flood-20261118`. Read only Task3 brief, authority gameplay spec, frozen Task1/2 reports and relevant house sources, not the whole implementation plan. No Git/index/HEAD mutations, player profile, prior QA package, model/driver/view or tutorial PNG edits. Root explicitly authorized the necessary narrow extra ownership of `game/ui/retake_panel.gd` for its27th existing-prop row `[lantern,sign,camera]`.

## Delivered behavior and scope

- Session registers the independent syrup driver. Catalog/data expose exactly27 actual games, candy local3/global027, `photo-candy-game-3`, `photo-candy-devil-3`, `ACH_GAME_027`. game028 onward remain unavailable.128 design candidates remain;027 status is `single_player_runtime_needs_full_acceptance`, not playtest acceptance.
- Actual factory entrance `(7,GROUND_Y,-6)`, existing observations/return path and two old games preserved. Physical sign reports3/12. Existing dynamic map, guide, stamp/book and progress reward APIs consume the third row without new framework/schema/itemdefs/audio profiles. Main rules and Book ordinary-card copy require actual participation; lesson explains cold/hot, actual12-unit plug,90..100%/three closed valves, helper, C vs Esc and free-drain/time consequences.
- Three tutorial images remain the frozen raw Task2 images, mapped01 cold reserve/hot flow,02 actual filled/closed success,03 actual plug plus overflow. No image synthesis/edit/crop.
- New Session fixture translates public snapshot decisions into genuine Session `_unhandled_input` keys/transformed pointer and `_process`. Eight complete routes cover A/B × ordinary/devil × assistance; assisted routes actually designate AI. No model private-state/result mutation. Checks also cover idle/nonparticipation timeout, participated truthful failure, pause/ownership-clear/resume, focus loss, retained driver/view and alternate retry, practice, cancellation, HUD/model agreement and exact400/500 score rows.
- New real Node Main `.tscn` fixture uses actual factory footing/nearest → `world.interact` signal, map button callback, first-entry lesson/seen/start, natural Session completion, ordinary participation timeout, true ordinary/devil, assistance, practice/cancel, one40-coin first-game receipt and repeated completion de-duplication. Selected ordinary AND selected devil retakes each start from only six synthetic welcome admission cards/opening seen, use actual practice/cancel and real retake set/navigation; verify selected-only card, no charge, receipt/provenance, actual later challenge and reload.
- Main retake PNG I/O fixture is explicitly **synthetic**, printed in raw logs. It passes a known1280×720 image only after actual set reaches its enabled shutter; validates exact original pixels/dimensions, decoded album thumbnail, preserved file SHA after challenge/reload. It does not claim GPU capture provenance. Headless Main itself intentionally has no gameplay captures. Task4 owns genuine GPU photo capture and new-process reopening acceptance.

## Files

Production: `game/minigames/session.gd`, `game/core/game_catalog.gd`, `game/data/candy_games.json`, `game/data/tutorials.json`, `game/ui/tutorial_catalog.gd`, `game/world/candy_world.gd`, `game/main.gd`, `game/ui/collection_book_panel.gd`, `game/ui/retake_panel.gd`.

Design/validation/runner: `design/02-minigames/catalog.json`, `design/02-minigames/catalog.md`, `design/runtime/full-game-delivery.md`, `tools/verify_design.py`, `tools/run_game_tests.py`, `tests/test_design_validation.py`, `tests/test_runtime_result_contract.py`.

Existing affected fixtures: `game/tests/test_candy_world.gd`, `test_game_catalog.gd`, `test_participation_results.gd`, `test_region_travel.gd`, `test_retake_panel.gd`, `test_sugar_bridge_session.gd`, `test_sugar_bridge_main.gd`, `test_cookie_mold_session.gd`, `test_cookie_mold_main.gd` (all under `game/tests/`). New: `game/tests/test_syrup_flood_session.gd`, `test_syrup_flood_main.gd`, `test_syrup_flood_main.tscn`.

No hardcoded-count production change was required in HarborMapPanel/IslandMapPanel; both already consume real snapshots/catalog rows. No progress or Steam definitions changed. Existing first2 candy rows, park+26 lessons and first26 design JSON rows were compared structurally against BASE and remain identical.

## RED → GREEN and corrections

Private launcher `.review/syrup-flood-20261118/integration/run.py`; exact executable `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe`. Every engine subprocess uses `tools.godot_entrypoints.run_validated_godot`, fresh absolute D runtime created by `prepare_runtime_stage` from UTF-8 tracked runtime inventory, then exact selected tracked fixtures/referenced helper closure plus the three owned new fixture files. No whole repository/test-tree copy, C import cache, old QA package or player profile. SceneTree entries use `--script`; Node Main uses `.tscn`.

Every process has fresh D `SNAPLAND_SAVE_PATH`, `APPDATA`, `LOCALAPPDATA`, `TEMP`, `TMP`. `<label>-receipt.json` records **every exact engine command, all five full environment paths, process exit, strict marker/error result, log path and staged source SHA256 manifest**. `<label>-<suite>.log` retains raw output. Full final working source hashes are `.review/syrup-flood-20261118/integration/final-source-hashes.json`.

Initial private launcher omitted tracked fixtures because release staging intentionally excludes tests; corrected to exact selected fixture/helper closure. First `red` consequently failed on a missing preloaded test helper, not the requested feature. Corrected **red2** has clean import and real `Syrup flood Session: 1 checks, 1 failures`, solely `game027 must be the delivered third factory game`, recorded before production wiring. Baseline2 recorded clean import plus **nine existing affected runtime suites** passing before production edits: retake progress, participation, retake panel, candy world, catalog, sugar Session/Main, cookie Session/Main. The subsequent tutorial command's filename slash caused private log writing to fail, so that unrecorded tutorial result is discarded, not called baseline green. Log names are now sanitized.

Green1 passed model308/driver96/view104, then exposed a harness error: final manual valve close ends the public model synchronously; solve stopped before Session's next `_process` naturally emitted completion. Corrected fixture advances that next frame instead of injecting/fixing a result. Green3 Session46/Main passed. Added physical Main footing and synthetic original pixel/SHA guards, then affected Main passed again. No frozen production file needed repair.

Affected run found5 stale two-game region-travel expectations (album source count, regional source counts, stamps, ticket2/12, two lessons), each exercised twice. Corrected them with third-game name,3/12,9-pending and third lesson assertions; narrowed travel-final is clean. Final participation fixture gives027 real valve operations/natural practice timeout rather than extending the older generic fixture's Session-result patch to027; narrowed participation-final is clean. Existing generic reward/PNG unit fixtures remain synthetic contract tests, not evidence of gameplay-earned results.

The final all-lesson pixel-page test also caught027 ordinary text clipping by10px at800×450/1.25 in each of its three steps; other lessons passed. Shortened only027 ordinary paragraph56→48 characters while retaining participation, selection/AI/configuration/wait exclusions, practice/cancel exclusions and free-retake/no-technique provenance. No UI layout or font-size weakening. Tutorial-final passes catalog/assets and full all-lesson paging with no engine errors.

A separate **controlled red-main**, after implementation, stages only owned Catalog/candy data from read-only `git show 65344a3:<path>` in a new D runtime. Main fails solely its missing027 guard; Session also fails the same intended guard. This demonstrates Main guard specificity but is explicitly not represented as a preimplementation Main RED. No working source or Git state was restored/mutated. Early launcher aggregate status did not mirror child errors; per-process receipts are authoritative; final launcher now exits nonzero if any selected child/marker check fails.

### Exact launcher commands

```powershell
python -m unittest tests.test_design_validation tests.test_runtime_result_contract -v
python .review/syrup-flood-20261118/integration/run.py baseline2 'delivered game' 'candy world' 'tutorial panel/catalog' 'tutorial image/control' 'participation result' 'retake panel' 'photo retake progress' 'sugar Session' 'sugar Main' 'cookie Session' 'cookie Main'
python .review/syrup-flood-20261118/integration/run.py red2
python .review/syrup-flood-20261118/integration/run.py green1 syrup
python .review/syrup-flood-20261118/integration/run.py green3 'syrup Session' 'syrup Main'
python .review/syrup-flood-20261118/integration/run.py affected 'delivered game' 'candy world' 'region travel' 'tutorial panel/catalog' 'tutorial image/control' 'tutorial seen' 'pixel tutorial' 'participation result' 'retake panel' 'photo retake progress' 'photo retake Main' 'harbor game progress' 'travel collection UI' 'sugar Session' 'sugar Main' 'cookie Session' 'cookie Main' 'welcome minigame' 'syrup Main'
python .review/syrup-flood-20261118/integration/run.py participation-final 'participation result'
python .review/syrup-flood-20261118/integration/run.py travel-final 'region travel'
python .review/syrup-flood-20261118/integration/run.py tutorial-final 'pixel tutorial' 'tutorial panel/catalog' 'tutorial image/control'
python .review/syrup-flood-20261118/integration/run.py red-main 'syrup Main'
python -m unittest tests.test_design_validation.GameTests -v
python -m unittest tests.test_runtime_shards tests.test_godot_entrypoints -v
python tools/check_runtime_tests.py
python tools/verify_design.py --scope games
python tools/verify_design.py --scope links
git diff --check
```

Python baseline67 passed; updated design/result-contract68 passed, including meaningful third-row runtime/scope/drift rejection, wrong028/duplicate026/local2/zone/order/missing/extra candy fixtures, and all15 regional driver entries/strict completion. Shard/validated-entrypoint28 passed; static runtime source command coverage passed. After final copy and tightening the first-unbuilt negative regex specifically to game028 scope, narrowed GameTests16/16 passed; games/links validations passed again. Diff whitespace check clean. These are data/source checks, not game playtests.

### Promoted runtime results

| Source | Result |
|---|---|
| green1 model | `Syrup flood tests: 308 checks, 0 failures` |
| green1 driver | `Syrup flood driver: 96 checks, 0 failures` |
| green1 view | `Syrup flood view: 104 checks, 0 failures` |
| green3 Session | `Syrup flood Session: 46 checks, 0 failures` |
| affected Main | `PASS: syrup Main factory entry, three real filled closed tanks, fixed rewards, selected retake originals and reload` |
| affected candy world |4293 checks,0 failures (baseline4278; new real interaction/connected-footing/position guards add15) |
| participation-final | exact shared participation marker, exit0/no errors |
| travel-final | exact region-travel marker, exit0/no errors |
| tutorial-final | exact catalog/assets/all-lesson paging markers, all exit0/no errors |

The affected sweep exercised19 distinct runtime suites; its stale-travel and clipping failures are replaced only by their passing narrowed reruns, and final participation by its passing real-input rerun. Across new-family plus affected suites, **23 distinct runtime suites** have passing promoted results in `promoted-results.json`, each exit0/strict marker/no engine errors, with import checks clean. This is a selected local regression set, not a full suite.

All five new-family markers/entries are registered exactly once in strict runner. Model/driver/view/Session are SceneTree scripts, Main is real Node scene. Python completion contracts reject quotes, suffixes, stderr-only, wrong completion, nonzero exit and engine diagnostics for all five; no missing fixture or engine skip was added.

### Isolated stage roots

- baseline2: `D:/Snapland-QA/syrup-integration-baseline2-8e1547d3/project`
- red2: `D:/Snapland-QA/syrup-integration-red2-77de4154/project`
- green1: `D:/Snapland-QA/syrup-integration-green1-1ff2fbbf/project`
- green3: `D:/Snapland-QA/syrup-integration-green3-a0c5be0c/project`
- affected: `D:/Snapland-QA/syrup-integration-affected-381c278f/project`
- participation-final: `D:/Snapland-QA/syrup-integration-participation-final-2c27651b/project`
- travel-final: `D:/Snapland-QA/syrup-integration-travel-final-e49f0323/project`
- tutorial-final: `D:/Snapland-QA/syrup-integration-tutorial-final-4ccc2b3f/project`
- controlled red-main: `D:/Snapland-QA/syrup-integration-red-main-69b3230c/project`

## Frozen/source checks

Model `07f23722692c4ca185f4a3a9d328f621dc60f29f4bbdeab514f07814f4333504`; driver `1c37d0074cf6ed4e39eece56aa20d096afbd94486f90c73a738d16a89e90e44f`; view `6b9e21f39ddc3f510d41ed2316ac8d8dcb573054ac839b8b99dd98a29c0b2d64` all match frozen reports.

PNG01 `bdbd972dcb9ef883e4b744b66ce55322f1349c41e5bc6a4b9169d2bc50f33e5e`;02 `4c8df903815e99e8ee0a983a84cc002e5f7b791608c678a97fbb3ebe2e6099e8`;03 `aa082a483a592b35da1595e2b250495e3ae73dbe8a9a451f6c7b8fddc763feeb` unchanged.

New Session fixture `8cfdad431065482a755342c516edaca2ced58636ce24e0ab7f04814740752df9`; Main gd `9097c39988ba9cae1133cb8058e652e932b324dd763ba1c7fae883bb89a73d86`; Main tscn `302348d713aa0f0964d181f6e80ccd3ef0cad79c3e21123ac30877f0cf37985f`. Full28 changed/new file hashes in private final manifest.

## Self-review and limits

Reviewed every count/identity consumer, caller, lesson/rules/card copy, fixed27th prop indexing, invalid/upcoming guards, actual entrance coordinates and old path retention; no unrelated abstraction, dependency, flow equation or production audio cleanup. Source/data prefix checks preserve all old content. Existing shared participation fixture actually exercised natural false/participation, practice/cancel contracts across all27 delivered games; it does **not** prove26 old winning gameplay routes. Existing welcome-minigame fixture exercised its twelve-game contract. Both factory Session/Main genuine winning routes regressed cleanly; harbor progress/retake unit fixtures exercise saved identities/transactions and failure handling. Remaining old-game success families were not individually replayed here; no full-suite/26-game winning-route claim.

No native screenshots, GPU rendering/capture provenance, packaging, separate-process save reopen, human playtesting, listening, art-naturalness or cross-device performance acceptance is claimed. Task4/root own those. Existing warning-only unsupported ShaderMaterial messages remain in headless Main logs; no promoted final engine ERROR. Preexisting untracked UID/import metadata was not touched. No known remaining production integration defect; final review still required.
