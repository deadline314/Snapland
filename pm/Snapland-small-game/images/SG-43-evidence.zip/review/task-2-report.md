# Task 2 report — ready for root review

Status: implementation and assigned validation complete; root owns review, Git, PM and integration. Assigned BASE `95fd3e0`; root-only plan/spec commits during work are separate. Read Task 2 brief, authority gameplay spec and frozen Task 1 report; did not read the whole implementation plan. No model, Session/Main/catalog/runner, PM, Git/index/HEAD or player-profile edits.

## Frozen source hashes

| Source | SHA256 |
|---|---|
| `game/minigames/syrup_flood_model.gd` | `07f23722692c4ca185f4a3a9d328f621dc60f29f4bbdeab514f07814f4333504` |
| `game/minigames/syrup_flood_driver.gd` | `1c37d0074cf6ed4e39eece56aa20d096afbd94486f90c73a738d16a89e90e44f` |
| `game/minigames/syrup_flood_view.gd` | `6b9e21f39ddc3f510d41ed2316ac8d8dcb573054ac839b8b99dd98a29c0b2d64` |
| `game/tests/test_syrup_flood_driver.gd` | `a3031c4d4c3b7829d7ec2f03edb8767dfb8f2a9e91288e3c1c9baf58390e567f` |
| `game/tests/test_syrup_flood_view.gd` | `993ec94989d216f1dbfc5939cc2e08f50a44a0cb6132fe45f78f537c93d77ee6` |
| `game/tests/native_syrup_flood_workbench_review.gd` | `19fcfd72725c79da5e0fddc4170ec569ad6b69cff3cd15ee818e01fd75bdc130` |
| `game/tests/native_syrup_flood_workbench_review.tscn` | `01fc9b848156618b58dff623195ea238525007d0aa5a256040845a5c4f32b27b` |

## RED → GREEN and exact launch commands

Initial `run.py red` was launched before production resources existed: Driver missing-resource guard failed 1/1; the initial View harness had a type-inference parse error. Corrected harness `run.py red2 --missing` then deliberately omitted the two new production resources from a fresh runtime and produced clean import plus Driver and View each **1 check / 1 failure**, for the intended missing-resource reason. This corrected controlled RED is recorded separately; it is not represented as a successful test or as the initial View run.

Early `green1` exposed a View `held` type-inference error; only the exact owned D-stage processes were stopped. `green2` passed Driver41 but failed eight View font-fit checks because its test root had no 1280 viewport; setting the actual test viewport fixed the harness rather than lowering font requirements. `green3` passed41/86. Candidate GPU captures then exposed clipped secondary 800 captions, corrected before final freeze. Later additions cover all 24 routes, all eight controls by all modalities, actual model footer feedback, pipe-end/target-band geometry and lifecycle. Only the final freeze runs below are promoted.

Launcher: `.review/syrup-flood-20261118/presentation/run.py`. Exact engine `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe`; every process goes through `tools.godot_entrypoints.run_validated_godot`. A fresh unique D runtime uses `prepare_runtime_stage` over UTF-8 `git ls-files -z` runtime inventory plus only the six exact new owned source/fixture paths above. No C import cache, whole repository or old QA/profile copy. Each process gets separate absolute D `SNAPLAND_SAVE_PATH`, `APPDATA`, `LOCALAPPDATA`, `TEMP` and `TMP` (verbatim below and in receipts). Final native runs were sequential; the unit stage is headless and independent.

```powershell
python .review/syrup-flood-20261118/presentation/run.py freeze-unit
python .review/syrup-flood-20261118/presentation/run.py freeze1280 1280x720
python .review/syrup-flood-20261118/presentation/run.py freeze1152 1152x648
python .review/syrup-flood-20261118/presentation/run.py freeze800 800x600
```

| Final run | Result |
|---|---|
| freeze-unit | import0/errors0; Driver96/0; View104/0 |
| freeze1280 | import0/errors0; GPU native60/0; 1280×720 |
| freeze1152 | import0/errors0; GPU native60/0; 1152×648 |
| freeze800 | import0/errors0; GPU native60/0; 800×600, Paper text1.25/reduced motion |

Strict reusable markers: `Syrup flood driver: 96 checks, 0 failures`, `Syrup flood view: 104 checks, 0 failures`. Each is a SceneTree `--script` fixture. Optional GPU marker `Syrup native workbench: 60 checks, 0 failures size=(WIDTH, HEIGHT)` comes from the real Node `.tscn`, never `--script` on a Node. Finalize checked one exact marker per log, every exit/error count, all seven source hashes and three actual parsed-input native routes. Final logs/receipts use each label with `-import`, `-driver`, `-view` or `-native` suffix in the private presentation directory.

### freeze-unit

import: `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --path D:\Snapland-QA\syrup-presentation-freeze-unit-38720d7e\project --headless --editor --import --quit`

```json
{
  "SNAPLAND_SAVE_PATH": "D:\\Snapland-QA\\syrup-presentation-freeze-unit-38720d7e\\import-profile\\progress.json",
  "APPDATA": "D:\\Snapland-QA\\syrup-presentation-freeze-unit-38720d7e\\import-profile\\appdata",
  "LOCALAPPDATA": "D:\\Snapland-QA\\syrup-presentation-freeze-unit-38720d7e\\import-profile\\localappdata",
  "TEMP": "D:\\Snapland-QA\\syrup-presentation-freeze-unit-38720d7e\\import-profile\\temp",
  "TMP": "D:\\Snapland-QA\\syrup-presentation-freeze-unit-38720d7e\\import-profile\\temp",
  "SNAPLAND_SYRUP_WORKBENCH_OUTPUT": "D:\\Snapland-QA\\syrup-presentation-freeze-unit-38720d7e\\captures",
  "SNAPLAND_SYRUP_WORKBENCH_SIZE": ""
}
```

driver: `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --path D:\Snapland-QA\syrup-presentation-freeze-unit-38720d7e\project --headless --script res://game/tests/test_syrup_flood_driver.gd`

```json
{
  "SNAPLAND_SAVE_PATH": "D:\\Snapland-QA\\syrup-presentation-freeze-unit-38720d7e\\driver-profile\\progress.json",
  "APPDATA": "D:\\Snapland-QA\\syrup-presentation-freeze-unit-38720d7e\\driver-profile\\appdata",
  "LOCALAPPDATA": "D:\\Snapland-QA\\syrup-presentation-freeze-unit-38720d7e\\driver-profile\\localappdata",
  "TEMP": "D:\\Snapland-QA\\syrup-presentation-freeze-unit-38720d7e\\driver-profile\\temp",
  "TMP": "D:\\Snapland-QA\\syrup-presentation-freeze-unit-38720d7e\\driver-profile\\temp",
  "SNAPLAND_SYRUP_WORKBENCH_OUTPUT": "D:\\Snapland-QA\\syrup-presentation-freeze-unit-38720d7e\\captures",
  "SNAPLAND_SYRUP_WORKBENCH_SIZE": ""
}
```

view: `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --path D:\Snapland-QA\syrup-presentation-freeze-unit-38720d7e\project --headless --script res://game/tests/test_syrup_flood_view.gd`

```json
{
  "SNAPLAND_SAVE_PATH": "D:\\Snapland-QA\\syrup-presentation-freeze-unit-38720d7e\\view-profile\\progress.json",
  "APPDATA": "D:\\Snapland-QA\\syrup-presentation-freeze-unit-38720d7e\\view-profile\\appdata",
  "LOCALAPPDATA": "D:\\Snapland-QA\\syrup-presentation-freeze-unit-38720d7e\\view-profile\\localappdata",
  "TEMP": "D:\\Snapland-QA\\syrup-presentation-freeze-unit-38720d7e\\view-profile\\temp",
  "TMP": "D:\\Snapland-QA\\syrup-presentation-freeze-unit-38720d7e\\view-profile\\temp",
  "SNAPLAND_SYRUP_WORKBENCH_OUTPUT": "D:\\Snapland-QA\\syrup-presentation-freeze-unit-38720d7e\\captures",
  "SNAPLAND_SYRUP_WORKBENCH_SIZE": ""
}
```

### freeze1280

import: `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --path D:\Snapland-QA\syrup-presentation-freeze1280-8cd76ccd\project --headless --editor --import --quit`

```json
{
  "SNAPLAND_SAVE_PATH": "D:\\Snapland-QA\\syrup-presentation-freeze1280-8cd76ccd\\import-profile\\progress.json",
  "APPDATA": "D:\\Snapland-QA\\syrup-presentation-freeze1280-8cd76ccd\\import-profile\\appdata",
  "LOCALAPPDATA": "D:\\Snapland-QA\\syrup-presentation-freeze1280-8cd76ccd\\import-profile\\localappdata",
  "TEMP": "D:\\Snapland-QA\\syrup-presentation-freeze1280-8cd76ccd\\import-profile\\temp",
  "TMP": "D:\\Snapland-QA\\syrup-presentation-freeze1280-8cd76ccd\\import-profile\\temp",
  "SNAPLAND_SYRUP_WORKBENCH_OUTPUT": "D:\\Snapland-QA\\syrup-presentation-freeze1280-8cd76ccd\\captures",
  "SNAPLAND_SYRUP_WORKBENCH_SIZE": "1280x720"
}
```

native: `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --path D:\Snapland-QA\syrup-presentation-freeze1280-8cd76ccd\project res://game/tests/native_syrup_flood_workbench_review.tscn`

```json
{
  "SNAPLAND_SAVE_PATH": "D:\\Snapland-QA\\syrup-presentation-freeze1280-8cd76ccd\\native-profile\\progress.json",
  "APPDATA": "D:\\Snapland-QA\\syrup-presentation-freeze1280-8cd76ccd\\native-profile\\appdata",
  "LOCALAPPDATA": "D:\\Snapland-QA\\syrup-presentation-freeze1280-8cd76ccd\\native-profile\\localappdata",
  "TEMP": "D:\\Snapland-QA\\syrup-presentation-freeze1280-8cd76ccd\\native-profile\\temp",
  "TMP": "D:\\Snapland-QA\\syrup-presentation-freeze1280-8cd76ccd\\native-profile\\temp",
  "SNAPLAND_SYRUP_WORKBENCH_OUTPUT": "D:\\Snapland-QA\\syrup-presentation-freeze1280-8cd76ccd\\captures",
  "SNAPLAND_SYRUP_WORKBENCH_SIZE": "1280x720"
}
```

### freeze1152

import: `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --path D:\Snapland-QA\syrup-presentation-freeze1152-0b7b9a87\project --headless --editor --import --quit`

```json
{
  "SNAPLAND_SAVE_PATH": "D:\\Snapland-QA\\syrup-presentation-freeze1152-0b7b9a87\\import-profile\\progress.json",
  "APPDATA": "D:\\Snapland-QA\\syrup-presentation-freeze1152-0b7b9a87\\import-profile\\appdata",
  "LOCALAPPDATA": "D:\\Snapland-QA\\syrup-presentation-freeze1152-0b7b9a87\\import-profile\\localappdata",
  "TEMP": "D:\\Snapland-QA\\syrup-presentation-freeze1152-0b7b9a87\\import-profile\\temp",
  "TMP": "D:\\Snapland-QA\\syrup-presentation-freeze1152-0b7b9a87\\import-profile\\temp",
  "SNAPLAND_SYRUP_WORKBENCH_OUTPUT": "D:\\Snapland-QA\\syrup-presentation-freeze1152-0b7b9a87\\captures",
  "SNAPLAND_SYRUP_WORKBENCH_SIZE": "1152x648"
}
```

native: `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --path D:\Snapland-QA\syrup-presentation-freeze1152-0b7b9a87\project res://game/tests/native_syrup_flood_workbench_review.tscn`

```json
{
  "SNAPLAND_SAVE_PATH": "D:\\Snapland-QA\\syrup-presentation-freeze1152-0b7b9a87\\native-profile\\progress.json",
  "APPDATA": "D:\\Snapland-QA\\syrup-presentation-freeze1152-0b7b9a87\\native-profile\\appdata",
  "LOCALAPPDATA": "D:\\Snapland-QA\\syrup-presentation-freeze1152-0b7b9a87\\native-profile\\localappdata",
  "TEMP": "D:\\Snapland-QA\\syrup-presentation-freeze1152-0b7b9a87\\native-profile\\temp",
  "TMP": "D:\\Snapland-QA\\syrup-presentation-freeze1152-0b7b9a87\\native-profile\\temp",
  "SNAPLAND_SYRUP_WORKBENCH_OUTPUT": "D:\\Snapland-QA\\syrup-presentation-freeze1152-0b7b9a87\\captures",
  "SNAPLAND_SYRUP_WORKBENCH_SIZE": "1152x648"
}
```

### freeze800

import: `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --path D:\Snapland-QA\syrup-presentation-freeze800-85314cf2\project --headless --editor --import --quit`

```json
{
  "SNAPLAND_SAVE_PATH": "D:\\Snapland-QA\\syrup-presentation-freeze800-85314cf2\\import-profile\\progress.json",
  "APPDATA": "D:\\Snapland-QA\\syrup-presentation-freeze800-85314cf2\\import-profile\\appdata",
  "LOCALAPPDATA": "D:\\Snapland-QA\\syrup-presentation-freeze800-85314cf2\\import-profile\\localappdata",
  "TEMP": "D:\\Snapland-QA\\syrup-presentation-freeze800-85314cf2\\import-profile\\temp",
  "TMP": "D:\\Snapland-QA\\syrup-presentation-freeze800-85314cf2\\import-profile\\temp",
  "SNAPLAND_SYRUP_WORKBENCH_OUTPUT": "D:\\Snapland-QA\\syrup-presentation-freeze800-85314cf2\\captures",
  "SNAPLAND_SYRUP_WORKBENCH_SIZE": "800x600"
}
```

native: `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --path D:\Snapland-QA\syrup-presentation-freeze800-85314cf2\project res://game/tests/native_syrup_flood_workbench_review.tscn`

```json
{
  "SNAPLAND_SAVE_PATH": "D:\\Snapland-QA\\syrup-presentation-freeze800-85314cf2\\native-profile\\progress.json",
  "APPDATA": "D:\\Snapland-QA\\syrup-presentation-freeze800-85314cf2\\native-profile\\appdata",
  "LOCALAPPDATA": "D:\\Snapland-QA\\syrup-presentation-freeze800-85314cf2\\native-profile\\localappdata",
  "TEMP": "D:\\Snapland-QA\\syrup-presentation-freeze800-85314cf2\\native-profile\\temp",
  "TMP": "D:\\Snapland-QA\\syrup-presentation-freeze800-85314cf2\\native-profile\\temp",
  "SNAPLAND_SYRUP_WORKBENCH_OUTPUT": "D:\\Snapland-QA\\syrup-presentation-freeze800-85314cf2\\captures",
  "SNAPLAND_SYRUP_WORKBENCH_SIZE": "800x600"
}
```

## Input, model and retained rendering evidence

- All eight actions have equal keyboard/mouse/touch outcomes, including previous/next, shared heater, valve, diversion, helper, actual nonempty drain and configuration. The 24 complete driver routes cover 3 inputs × assistance on/off × ordinary/devil × A/B. They reproduce all eight frozen Task 1 numeric outcomes; no score/result/physical-state injection or model edits.
- Native operations use `Input.parse_input_event` into the focused live View and actual transformed pointer coordinates. Spatial valves select/toggle; outside-up releases; canceled first touch, second finger, emulated mouse, echoed/repeated keys, ShiftTab release after Shift changes, held Tab with Shift changing, focus clear, held tree-exit/recreate and reset-late-up are checked. Release/clear never adds another action or resets latched model controls. Session pause itself remains Task 3 scope.
- Configuration leaves heat, fill, time and all-closed award state frozen; no stream/leak mesh is visible while paused. The all-closed real route remains score300/non-ended/ineligible while configured; after resume only the next real model step produces score500/success/devil. Status explicitly reads 停流配置中. C is local model configuration, not Session Esc pause.
- Real isolated SubViewport/World3D/orthographic camera, thick pipe channel floors and backs, valves, visible syrup columns, open tanks/actual liquid heights, target bands, shared heater, side outlet/tray/leak and growing physical cold plug. Pipe lengths and connected endpoints change with A/B; target bands and fill heights read model values. Temperature color, viscosity/flow/length/thermal capacity/capacity labels read the same copied snapshot; no thermal or flow formula in View/Driver.
- Retained count is exactly52 descendant nodes /46 MeshInstance3D /11 active StandardMaterial3D objects across actual reset, spill, seal, pause and three routes. Unit checks retain each mesh and material over120 presentations, finite geometry and teardown. Native GPU is Vulkan Forward+ on AMD Radeon RX9070XT. Reduced motion only fixes decorative stream-width fluctuation; actual level/valve/plug updates remain.
- Branch side material is labelled 旁路用糖, since model leaked includes real cold-plug material. Actual model feedback owns the footer (including reset, overflow, drain, success), matching Session driver-HUD contract. Result rows use model fields and reconcile model zero floor through house score_adjustment; practice text explicitly excludes cards.

## Native states and tutorial originals

Every final native folder has seven raw images: `01-cold-reserve-hot-flow`, `02-real-cold-plug`, `03-configuration-hot-paused`, `04-configuration-paused` (three filled/closed but no result), `05-filled-closed`, `06-overflow-cold-plug`, `07-overflow-recovery`. Logs retain real-operation snapshots for every image. At5s cold reserve has real6.7561/12 plug material and outer hot T0.829 vs middle cold T0.147; at11s material seals permanently and normal middle flow resumes. Actual overflow at14.25s closes tank0 at100.1066 and records one mistake; actual touch drain preserves time, other fills and sealed plug.

| Size | Final raw capture directory |
|---|---|
| 1280x720 | `D:\Snapland-QA\syrup-presentation-freeze1280-8cd76ccd\captures` |
| 1152x648 | `D:\Snapland-QA\syrup-presentation-freeze1152-0b7b9a87\captures` |
| 800x600 | `D:\Snapland-QA\syrup-presentation-freeze800-85314cf2\captures` |

Three player-facing tutorial originals are unchanged raw1280 captures; no crop, overlay edit, image generation or other-game art. Fixture title is 糖漿分洪｜冷糖與熱源; technical fixture wording remains only in source/log/report. `finalize.py` validates PNG signature, dimensions and byte-identical copy hashes before promoting:

| Asset | Raw source | Bytes | SHA256 |
|---|---|---:|---|
| `assets/ui/tutorials/game-027-step-01.png` | `D:\Snapland-QA\syrup-presentation-freeze1280-8cd76ccd\captures\01-cold-reserve-hot-flow.png` | 74788 | `bdbd972dcb9ef883e4b744b66ce55322f1349c41e5bc6a4b9169d2bc50f33e5e` |
| `assets/ui/tutorials/game-027-step-02.png` | `D:\Snapland-QA\syrup-presentation-freeze1280-8cd76ccd\captures\05-filled-closed.png` | 52039 | `4c8df903815e99e8ee0a983a84cc002e5f7b791608c678a97fbb3ebe2e6099e8` |
| `assets/ui/tutorials/game-027-step-03.png` | `D:\Snapland-QA\syrup-presentation-freeze1280-8cd76ccd\captures\06-overflow-cold-plug.png` | 66758 | `aa082a483a592b35da1595e2b250495e3ae73dbe8a9a451f6c7b8fddc763feeb` |

Lesson mapping: step01 demonstrates hot outer/cold reserve and live material; step02 shows all three real levels at92%, valves closed, success; step03 shows the permanent real cold plug alongside an actual spoiled tank and the visible free-drain/time consequence. Companion raw07 records the actual recovery. Task3 lesson copy should explain the matching controls and these states.

## Self-review and limits

Self-viewed final raw1280 tutorial candidates and overflow/recovery footer. Final three-size images use compact tank captions; all eight buttons are inside physical viewport, enlarged labels fit their rectangles, physical small-profile essential text is at least17.5px, and GPU checks verify compact tank captions fit. Root separately reviews final raw images before approval. No per-frame nodes/meshes/materials or gameplay formulas were added; no dependencies/framework/options or unrelated cookie physics. Existing production files and UID/import metadata were left alone.

Not checked here: production Session/Main entry, Session Esc pause/resume, tutorial catalog, player rewards/collections/save reopening, release package, full 26-game baseline/whole suite, human playtesting, listening, cross-device performance or visual-art naturalness. These require Task 3/4 integration; standalone success is not a player award or Main acceptance. No known remaining Task 2 defect. Root review and subsequent integration remain required.
