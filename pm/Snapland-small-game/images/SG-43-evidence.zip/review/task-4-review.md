# Task 4 independent spec and quality review

Reviewed 2026-11-18. Base `decdb9927191d68012f180485bb80d2703c77ea0`; head `8e542e8382d3770e1662f0a5623a1755e7515b2d`.

## Decisions

- Spec: ✅ Task 4's assigned fixture and local native/package evidence requirements are satisfied.
- Quality: **Approved** for the scoped Task 4 change.
- Findings: none. No actionable severity/file-line finding identified.

This decision covers the two new fixture files and their retained evidence. Root-owned PM/public archive, whole-branch final review, merge/push and CI delivery remain separate gates; this does not mark them complete or grant subjective ART/MIC acceptance.

## Review scope and method

Read `task-4-brief.md`, then `task-4-report.md`, then the supplied `review-decdb99..8e542e8.diff` once. It contains one commit, two new files and 393 added lines: `game/tests/native_syrup_flood_main.gd` (387) and its six-line scene. No production or inherited helper change is included.

Applied the repository's `AGENTS.md` quality/isolation rules and read `pm-ticket`. This is the requested read-only review of existing SG43 work, so no new ticket, Git operation or source mutation was performed. Reviewed both spec and quality directly; no subagents were created under the explicit task restriction.

Focused adjacent reads were limited to inherited native input/capture/finish helpers, the validated launcher, existing Main photo saving/attachment and Progress attachment behavior, normal project entry and export exclusions. These establish the fixture assumptions without reopening unrelated Tasks 1–3. Existing same-code engine tests and exports were not rerun. Independent read-only Python checks parsed retained JSON/logs, hashed artifacts and verified PNGs; only this review report was written.

## Spec assessment

| Requirement | Evidence and conclusion |
|---|---|
| Actual Main, honest isolated setup | Fixture lines 14–59 load actual Main, enforce an absolute save/capture location and GPU, seed only six welcome admission cards plus seen-opening context, and disclose controlled actor placement before actual nearest detection/E input. UI scale/reduced-motion are explicit fixture settings. No 027 model/result/reward/card/photo injection is present. Placement is correctly excluded from a walking claim. |
| Actual rules/tutorial/input/session routes | Lines 61–96 visit the five ordered rules pages through actual focused Next callbacks, verify indices and visible copy, visit regional map entries, and decode all three tutorial page textures before real Start. Lines 144–225 plus inherited `key`, `pointer` and `activate` use `Input.parse_input_event`; the eight view commands and real 3D valve mouse/touch paths are exercised. |
| Natural ordinary/devil/assist/timeout/practice/cancel | Lines 97–136 and 267–310 use real driver snapshots only for decisions, actual key events for controls, and bounded fixed-step Session processing. Natural Session `finished` emissions are retained; outcomes are not patched. The real cold plug and designated AI closure are guarded. Timeout honestly fails; practice and confirmed HUD cancel leave rewards unchanged. |
| Three sizes and complete visible controls | Native suite receipts cover 1280×720, 1152×648 and 800×600; the latter's fixture settings are UI 1.25/reduced motion. Recursive bounds checks cover visible overlay/HUD Buttons on every capture, plus transformed view controls. Five rules pages and three tutorial captures are retained for each suite. Root's separately recorded raw visual inspection covers every flow family, all sizes, retakes and the embedded package. |
| Selected retakes and new-process reload | Lines 312–362 use actual retake panel Next/choices/Shutter, compare saved original pixels with the arranged GPU viewport, guard selected-only initial award/truthful provenance, then run a genuine matching challenge and require original path/SHA preservation with no second reward. Lines 379–387 and the inherited finish path support retained reports/clean exit; `read_profile` checks saved receipt hashes, coins, tutorial/global achievement and readable originals/thumbnails in a separate reader process. Both targets run at 1280, with devil at 1152 and ordinary at 800. |
| Independent QA export and source provenance | Independent QA stage, import/export receipts, build/acceptance manifests and writer/reader commands match. The executable is launched as a one-element command with no path/scene override. Source inventory, fixture closure, runtime differences, engine/template/executable hashes were independently verified below. |
| Honest scope and recording | The brief requests a clip only if required by the baseline; no such requirement is present here. The report correctly limits acceptance to scripted input/GPU/save checks on this machine, without human play/hearing, fresh-save earned admission, full-island traversal or cross-device performance claims. |

## Independently checked evidence

All checks below read existing artifacts without launching the game or rewriting evidence.

- `native/promoted-native.json`: exactly **16 processes, 194 raw viewport PNGs and 24 natural result emissions**, across eight distinct writer/reader save profiles. Each pair shares only its own absolute D save; APPDATA, LOCALAPPDATA, TEMP/TMP and capture paths are absolute D paths recorded per process.
- Each promoted receipt equals its retained receipt file and reports exit 0, errors 0, completion marker count 1 and passing guards. Raw logs independently contain the exact marker once, official `4.7.2.stable.official.ed1daf0bf`, Vulkan/RX 9070 XT, and no `ERROR:`, leaked or still-in-use diagnostic. JSON failures are empty. Before-cleanup guard counts match all 16 report-table entries; the passing marker/exit additionally requires successful audio-release cleanup through the inherited finish path.
- All 194 PNGs match recorded SHA256, byte length and expected physical dimensions and pass Pillow's full `verify()` integrity check. Current original-frame files match every reported SHA. All **329** files in `public-archive-inputs.json` exist and match recorded SHA/bytes; category counts include 194 raw PNGs, 32 reports, 16 execution receipts/logs, eight original-provenance receipts, 22 originals and 22 thumbnails.
- All four suite writers (three native sizes plus embedded QA) emit exact ordered result tuples: ordinary 400, devil 500, assisted devil 500, participated failure 0, practice devil 500. IDs are 027, mistakes zero, totals equal score, practice is ineligible. The four retake writers emit one successful eligible non-practice natural result each: ordinary 400 or assisted devil 500 as appropriate. Readers emit none.
- `delivered1280-stage.json` and `qa-frozen-build.json` have the same **1195-file** source inventory. Every current workspace source and native-stage file matches it; every QA runtime file matches its runtime hash. Both stages contain exactly the explicit four `.gd/.tscn` fixture files, with no additional test source in that closure. The only source/runtime differences are `project.godot` and `export_presets.cfg`, as documented for private QA.
- Independently hashed actual engine: `c8f0a6bc45a19b33541501e57f6f7cd972ab18453743266339d495cbbe846643`. Both pinned Windows template hashes match. Actual 285631072-byte `D:/Snapland-QA/syrup-native-qa-frozen-0d37d3b0/release/SyrupFloodQA.exe` matches `d70f21c3a796e22c4771651a0461b6a9561635fa171e1faec8d967fd5aa99928`.
- Native import and independent QA import/export raw receipts/logs are clean exit 0/0 ERROR/no leaks. QA `acceptance.json` retains two actual executable receipts and verifies all 1195 source/runtime entries and executable SHA. `run.py` uses `run_validated_godot` with a 300-second timeout; the inherited fixture has a 180-second watchdog. The existing release launcher rejects path/scene/pack overrides and loose-project contamination and executes from the release directory.
- Normal source `project.godot` still starts `res://game/main.tscn`; both standard export presets exclude `game/tests/*`. This commit introduces no normal-player entry change.

## Quality and photo semantics

The new fixture reuses the house native base for input synthesis, rendering capture, watchdog and audio shutdown rather than cloning it. New logic is confined to the syrup-specific orchestration, guards and provenance reports. The recorded failed candidates are excluded from the promoted evidence; clean final artifacts correspond to the reviewed source hash `b513b2f17e28de5306f61f9d59a73ad3c68991f53ce27ef0ac0f23666a864003`.

The gameplay and retake invariants are correctly distinct. Existing Main saves gameplay originals under game/index paths before attaching them; `Progress.attach_game_photo_frames` refreshes eligible gameplay records and excludes records whose acquisition method is `retake`. Accordingly, unchanged card dictionaries/coin deduplication are not evidence of immutable first-gameplay pixels. The fixture explicitly records per-completion gameplay SHA changes and shared normal/devil gameplay paths. Retake checks separately require original path/byte preservation after a later matching challenge and reader restart. This is consistent with root's stated existing-gameplay-refresh ruling and does not treat a refresh as an undetected Task 4 regression. Whole-branch policy review remains root-owned.

## Verification limits

I did not rerun engine tests, rebuild the package or independently repeat root's image-by-image visual review. Visual fit conclusions rely on root's separately recorded raw inspection in `.review/syrup-flood-20261118/merged-checks/root-visual-review.md`; my direct image checks establish artifact integrity and dimensions, not subjective appearance. Logs, explicit environments, source inspection and hashes establish the retained execution evidence; no OS-wide filesystem audit or human play/listening was performed.

No Task 4 blocker remains in the reviewed scope. Final branch/PM/public archive/CI delivery and subjective art/audio acceptance are not checked by this report.
