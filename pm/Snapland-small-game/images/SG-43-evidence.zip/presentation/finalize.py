"""Validate final receipts and copy three unchanged native tutorial originals."""
import hashlib
import json
from pathlib import Path
import shutil
import struct
import subprocess

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
OWNED = ['game/minigames/syrup_flood_driver.gd', 'game/minigames/syrup_flood_view.gd',
         'game/tests/test_syrup_flood_driver.gd', 'game/tests/test_syrup_flood_view.gd',
         'game/tests/native_syrup_flood_workbench_review.gd', 'game/tests/native_syrup_flood_workbench_review.tscn']
MODEL = 'game/minigames/syrup_flood_model.gd'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
hashes = {name: sha(ROOT / name) for name in [MODEL, *OWNED]}
assert hashes[MODEL] == '07f23722692c4ca185f4a3a9d328f621dc60f29f4bbdeab514f07814f4333504'
labels = ['freeze-unit', 'freeze1280', 'freeze1152', 'freeze800']
records = {}
for label in labels:
    records[label] = json.loads((HERE / f'{label}-receipt.json').read_text(encoding='utf-8'))
    for receipt in records[label]:
        assert receipt['exit'] == 0 and receipt['errors'] == 0, label
        for name, digest in hashes.items():
            assert receipt['source_sha256'][name] == digest, (label, name)
        log = (HERE / f"{label}-{receipt['mode']}.log").read_text(encoding='utf-8')
        assert 'ERROR:' not in log
        marker = {'driver': 'Syrup flood driver: 96 checks, 0 failures',
                  'view': 'Syrup flood view: 104 checks, 0 failures',
                  'native': 'Syrup native workbench: 60 checks, 0 failures'}.get(receipt['mode'])
        if marker:
            assert log.count(marker) == 1, (label, marker)
        if receipt['mode'] == 'native':
            assert 'Forward+' in log and 'AMD Radeon RX 9070 XT' in log
            assert log.count('SYRUP_NATIVE_ROUTE ') == 3
            assert 'SYRUP_RETAINED nodes=52 meshes=46 material_pool=11' in log

native = records['freeze1280'][1]
capture_dir = Path(native['environment']['SNAPLAND_SYRUP_WORKBENCH_OUTPUT'])
tutorials = []
for index, label in enumerate(['01-cold-reserve-hot-flow', '05-filled-closed', '06-overflow-cold-plug'], 1):
    source = capture_dir / f'{label}.png'
    assert source.read_bytes()[:8] == b'\x89PNG\r\n\x1a\n'
    assert struct.unpack('>II', source.read_bytes()[16:24]) == (1280, 720)
    destination = ROOT / f'assets/ui/tutorials/game-027-step-{index:02d}.png'
    shutil.copy2(source, destination)
    assert sha(destination) == sha(source)
    tutorials.append(dict(path=destination.relative_to(ROOT).as_posix(), source=str(source), sha256=sha(source), bytes=source.stat().st_size))

lines = ['# Task 2 report — ready for root review', '',
         'Status: implementation and assigned validation complete; root owns review, Git, PM and integration. Assigned BASE `95fd3e0`; root-only plan/spec commits during work are separate. Read Task 2 brief, authority gameplay spec and frozen Task 1 report; did not read the whole implementation plan. No model, Session/Main/catalog/runner, PM, Git/index/HEAD or player-profile edits.', '',
         '## Frozen source hashes', '', '| Source | SHA256 |', '|---|---|']
lines.extend(f'| `{name}` | `{digest}` |' for name, digest in hashes.items())
lines += ['', '## RED → GREEN and exact launch commands', '',
          'Initial `run.py red` was launched before production resources existed: Driver missing-resource guard failed 1/1; the initial View harness had a type-inference parse error. Corrected harness `run.py red2 --missing` then deliberately omitted the two new production resources from a fresh runtime and produced clean import plus Driver and View each **1 check / 1 failure**, for the intended missing-resource reason. This corrected controlled RED is recorded separately; it is not represented as a successful test or as the initial View run.', '',
          'Early `green1` exposed a View `held` type-inference error; only the exact owned D-stage processes were stopped. `green2` passed Driver41 but failed eight View font-fit checks because its test root had no 1280 viewport; setting the actual test viewport fixed the harness rather than lowering font requirements. `green3` passed41/86. Candidate GPU captures then exposed clipped secondary 800 captions, corrected before final freeze. Later additions cover all 24 routes, all eight controls by all modalities, actual model footer feedback, pipe-end/target-band geometry and lifecycle. Only the final freeze runs below are promoted.', '',
          'Launcher: `.review/syrup-flood-20261118/presentation/run.py`. Exact engine `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe`; every process goes through `tools.godot_entrypoints.run_validated_godot`. A fresh unique D runtime uses `prepare_runtime_stage` over UTF-8 `git ls-files -z` runtime inventory plus only the six exact new owned source/fixture paths above. No C import cache, whole repository or old QA/profile copy. Each process gets separate absolute D `SNAPLAND_SAVE_PATH`, `APPDATA`, `LOCALAPPDATA`, `TEMP` and `TMP` (verbatim below and in receipts). Final native runs were sequential; the unit stage is headless and independent.', '',
          '```powershell',
          'python .review/syrup-flood-20261118/presentation/run.py freeze-unit',
          'python .review/syrup-flood-20261118/presentation/run.py freeze1280 1280x720',
          'python .review/syrup-flood-20261118/presentation/run.py freeze1152 1152x648',
          'python .review/syrup-flood-20261118/presentation/run.py freeze800 800x600', '```', '',
          '| Final run | Result |', '|---|---|',
          '| freeze-unit | import0/errors0; Driver96/0; View104/0 |',
          '| freeze1280 | import0/errors0; GPU native60/0; 1280×720 |',
          '| freeze1152 | import0/errors0; GPU native60/0; 1152×648 |',
          '| freeze800 | import0/errors0; GPU native60/0; 800×600, Paper text1.25/reduced motion |', '',
          'Strict reusable markers: `Syrup flood driver: 96 checks, 0 failures`, `Syrup flood view: 104 checks, 0 failures`. Each is a SceneTree `--script` fixture. Optional GPU marker `Syrup native workbench: 60 checks, 0 failures size=(WIDTH, HEIGHT)` comes from the real Node `.tscn`, never `--script` on a Node. Finalize checked one exact marker per log, every exit/error count, all seven source hashes and three actual parsed-input native routes. Final logs/receipts use each label with `-import`, `-driver`, `-view` or `-native` suffix in the private presentation directory.', '']
for label, receipts in records.items():
    lines += [f'### {label}', '']
    for receipt in receipts:
        lines += [f"{receipt['mode']}: `{subprocess.list2cmdline(receipt['command'])}`", '', '```json',
                  json.dumps(receipt['environment'], ensure_ascii=False, indent=2), '```', '']
lines += ['## Input, model and retained rendering evidence', '',
          '- All eight actions have equal keyboard/mouse/touch outcomes, including previous/next, shared heater, valve, diversion, helper, actual nonempty drain and configuration. The 24 complete driver routes cover 3 inputs × assistance on/off × ordinary/devil × A/B. They reproduce all eight frozen Task 1 numeric outcomes; no score/result/physical-state injection or model edits.',
          '- Native operations use `Input.parse_input_event` into the focused live View and actual transformed pointer coordinates. Spatial valves select/toggle; outside-up releases; canceled first touch, second finger, emulated mouse, echoed/repeated keys, ShiftTab release after Shift changes, held Tab with Shift changing, focus clear, held tree-exit/recreate and reset-late-up are checked. Release/clear never adds another action or resets latched model controls. Session pause itself remains Task 3 scope.',
          '- Configuration leaves heat, fill, time and all-closed award state frozen; no stream/leak mesh is visible while paused. The all-closed real route remains score300/non-ended/ineligible while configured; after resume only the next real model step produces score500/success/devil. Status explicitly reads 停流配置中. C is local model configuration, not Session Esc pause.',
          '- Real isolated SubViewport/World3D/orthographic camera, thick pipe channel floors and backs, valves, visible syrup columns, open tanks/actual liquid heights, target bands, shared heater, side outlet/tray/leak and growing physical cold plug. Pipe lengths and connected endpoints change with A/B; target bands and fill heights read model values. Temperature color, viscosity/flow/length/thermal capacity/capacity labels read the same copied snapshot; no thermal or flow formula in View/Driver.',
          '- Retained count is exactly52 descendant nodes /46 MeshInstance3D /11 active StandardMaterial3D objects across actual reset, spill, seal, pause and three routes. Unit checks retain each mesh and material over120 presentations, finite geometry and teardown. Native GPU is Vulkan Forward+ on AMD Radeon RX9070XT. Reduced motion only fixes decorative stream-width fluctuation; actual level/valve/plug updates remain.',
          '- Branch side material is labelled 旁路用糖, since model leaked includes real cold-plug material. Actual model feedback owns the footer (including reset, overflow, drain, success), matching Session driver-HUD contract. Result rows use model fields and reconcile model zero floor through house score_adjustment; practice text explicitly excludes cards.', '',
          '## Native states and tutorial originals', '',
          'Every final native folder has seven raw images: `01-cold-reserve-hot-flow`, `02-real-cold-plug`, `03-configuration-hot-paused`, `04-configuration-paused` (three filled/closed but no result), `05-filled-closed`, `06-overflow-cold-plug`, `07-overflow-recovery`. Logs retain real-operation snapshots for every image. At5s cold reserve has real6.7561/12 plug material and outer hot T0.829 vs middle cold T0.147; at11s material seals permanently and normal middle flow resumes. Actual overflow at14.25s closes tank0 at100.1066 and records one mistake; actual touch drain preserves time, other fills and sealed plug.', '',
          '| Size | Final raw capture directory |', '|---|---|']
for label in labels[1:]:
    env = records[label][1]['environment']
    lines.append(f"| {env['SNAPLAND_SYRUP_WORKBENCH_SIZE']} | `{env['SNAPLAND_SYRUP_WORKBENCH_OUTPUT']}` |")
lines += ['', 'Three player-facing tutorial originals are unchanged raw1280 captures; no crop, overlay edit, image generation or other-game art. Fixture title is 糖漿分洪｜冷糖與熱源; technical fixture wording remains only in source/log/report. `finalize.py` validates PNG signature, dimensions and byte-identical copy hashes before promoting:', '', '| Asset | Raw source | Bytes | SHA256 |', '|---|---|---:|---|']
for item in tutorials:
    lines.append(f"| `{item['path']}` | `{item['source']}` | {item['bytes']} | `{item['sha256']}` |")
lines += ['', 'Lesson mapping: step01 demonstrates hot outer/cold reserve and live material; step02 shows all three real levels at92%, valves closed, success; step03 shows the permanent real cold plug alongside an actual spoiled tank and the visible free-drain/time consequence. Companion raw07 records the actual recovery. Task3 lesson copy should explain the matching controls and these states.', '',
          '## Self-review and limits', '',
          'Self-viewed final raw1280 tutorial candidates and overflow/recovery footer. Final three-size images use compact tank captions; all eight buttons are inside physical viewport, enlarged labels fit their rectangles, physical small-profile essential text is at least17.5px, and GPU checks verify compact tank captions fit. Root separately reviews final raw images before approval. No per-frame nodes/meshes/materials or gameplay formulas were added; no dependencies/framework/options or unrelated cookie physics. Existing production files and UID/import metadata were left alone.', '',
          'Not checked here: production Session/Main entry, Session Esc pause/resume, tutorial catalog, player rewards/collections/save reopening, release package, full26-game baseline/whole suite, human playtesting, listening, cross-device performance or visual-art naturalness. These require Task3/4 integration; standalone success is not a player award or Main freeze. No known remaining Task2 defect. Root review and subsequent integration remain required.']
(ROOT / '.superpowers/sdd/2026-11-18-syrup-flood/task-2-report.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
(HERE / 'freeze-summary.json').write_text(json.dumps(dict(source_sha256=hashes, tutorials=tutorials, receipts=records), ensure_ascii=False, indent=2), encoding='utf-8')
print('Validated final source/markers; copied 3 raw originals; wrote task-2-report.md')
for item in tutorials:
    print(item['path'], item['sha256'])
