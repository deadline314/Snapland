"""Fresh D runtime, exact owned additions, isolated profiles and validated engine."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import uuid

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from tools.build_desktop_release import prepare_runtime_stage
from tools.godot_entrypoints import run_validated_godot

HERE = Path(__file__).resolve().parent
ENGINE = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
OWNED = ['game/minigames/syrup_flood_driver.gd', 'game/minigames/syrup_flood_view.gd',
         'game/tests/test_syrup_flood_driver.gd', 'game/tests/test_syrup_flood_view.gd',
         'game/tests/native_syrup_flood_workbench_review.gd', 'game/tests/native_syrup_flood_workbench_review.tscn']
label = sys.argv[1]
missing = '--missing' in sys.argv
native = len(sys.argv) > 2 and not missing
size = sys.argv[2] if native else ''
base = Path('D:/Snapland-QA') / ('syrup-presentation-' + label + '-' + uuid.uuid4().hex[:8])
stage = base / 'project'
stage.mkdir(parents=True)
tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT, text=True, encoding='utf-8').split('\0')
manifest = prepare_runtime_stage(ROOT, stage, tracked)
for name in OWNED:
    if missing and name.startswith('game/minigames/'):
        continue
    source = ROOT / name
    if source.exists():
        destination = stage / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        manifest[name] = hashlib.sha256(source.read_bytes()).hexdigest()
modes = [('import', ['--headless', '--editor', '--import', '--quit'])]
if native:
    modes.append(('native', ['res://game/tests/native_syrup_flood_workbench_review.tscn']))
else:
    modes.extend((name, ['--headless', '--script', f'res://game/tests/test_syrup_flood_{name}.gd']) for name in ['driver', 'view'])
receipts = []
for mode, args in modes:
    profile = base / (mode + '-profile')
    env = dict(os.environ, SNAPLAND_SAVE_PATH=str(profile / 'progress.json'), APPDATA=str(profile / 'appdata'),
               LOCALAPPDATA=str(profile / 'localappdata'), TEMP=str(profile / 'temp'), TMP=str(profile / 'temp'),
               SNAPLAND_SYRUP_WORKBENCH_OUTPUT=str(base / 'captures'), SNAPLAND_SYRUP_WORKBENCH_SIZE=size)
    for key in ['APPDATA', 'LOCALAPPDATA', 'TEMP']:
        Path(env[key]).mkdir(parents=True)
    cmd = [ENGINE, '--path', str(stage), *args]
    result = run_validated_godot(stage, cmd, env, 300 if mode in ['import', 'native'] else 90)
    output = result.stdout + result.stderr
    (HERE / (label + '-' + mode + '.log')).write_text(output, encoding='utf-8')
    receipt = dict(mode=mode, command=cmd, environment={k: env[k] for k in ['SNAPLAND_SAVE_PATH', 'APPDATA', 'LOCALAPPDATA', 'TEMP', 'TMP', 'SNAPLAND_SYRUP_WORKBENCH_OUTPUT', 'SNAPLAND_SYRUP_WORKBENCH_SIZE']},
                   exit=result.returncode, errors=output.count('ERROR:'), source_sha256=manifest)
    receipts.append(receipt)
    print(mode, 'exit', result.returncode, 'errors', receipt['errors'], flush=True)
    if mode != 'import':
        print(output, flush=True)
    if mode == 'import' and (result.returncode or 'ERROR:' in output):
        break
(HERE / (label + '-receipt.json')).write_text(json.dumps(receipts, indent=2), encoding='utf-8')
