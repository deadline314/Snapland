"""Independent explicit QA-only embedded export; source/player entry remain unchanged."""
from run import *

label='qa-frozen'
base,stage=stage_new(label)
normal_main=(ROOT/'project.godot').read_text(encoding='utf-8')
assert 'run/main_scene="res://game/main.tscn"' in normal_main
project=stage/'project.godot'
project.write_text(normal_main.replace('run/main_scene="res://game/main.tscn"','run/main_scene="res://game/tests/native_syrup_flood_main.tscn"'),encoding='utf-8')
templates=Path(os.environ['APPDATA'])/'Godot/export_templates/4.7.2.stable'
assert (templates/'version.txt').read_text().strip()=='4.7.2.stable'
preset=stage/'export_presets.cfg'
body=preset.read_text(encoding='utf-8')
# Only the explicit four-fixture closure exists in this QA stage.
assert sorted(p.as_posix().removeprefix(stage.as_posix()+'/') for p in (stage/'game/tests').iterdir() if p.is_file() and p.suffix in ['.gd','.tscn'])==sorted(FIXTURES)
body=body.replace('game/tests/*,','')
template_manifest={}
for kind in ['debug','release']:
    path=templates/('windows_'+kind+'_x86_64.exe')
    assert path.is_file()
    template_manifest[kind]=dict(path=str(path),sha256=sha(path),bytes=path.stat().st_size)
    body=body.replace('custom_template/'+kind+'=""','custom_template/'+kind+'="'+path.as_posix()+'"',1)
preset.write_text(body,encoding='utf-8')
release=base/'release';release.mkdir()
binary=release/'SyrupFloodQA.exe'
run(stage,[ENGINE,'--headless','--path',str(stage),'--editor','--export-release','Windows Desktop',str(binary),'--quit'],environment(base/'export',base/'export-profile'),label+'-export')
assert binary.is_file() and binary.stat().st_size>Path(template_manifest['release']['path']).stat().st_size and binary.read_bytes()[:2]==b'MZ'
source=json.loads((HERE/(label+'-stage.json')).read_text())
runtime={name:sha(stage/name) for name in source['source_sha256']}
manifest=dict(base=str(base),stage=str(stage),engine=dict(path=ENGINE,sha256=sha(Path(ENGINE)),version='4.7.2.stable.official.ed1daf0bf'),source_commit_base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),source_sha256=source['source_sha256'],runtime_sha256=runtime,
              qa_only_overrides=['project.godot main scene','export_presets.cfg explicit fixture closure and pinned Windows templates'],qa_fixture_allowlist=FIXTURES,templates=template_manifest,
              binary=dict(path=str(binary),sha256=sha(binary),bytes=binary.stat().st_size),normal_player_main_preserved=True)
(base/'build.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
(HERE/(label+'-build.json')).write_text(json.dumps(manifest,indent=2),encoding='utf-8')
profile=base/'acceptance-profile'
receipts=[]
for mode in ['suite','read']:
    process=base/(mode+'-process')
    receipts.append(run(stage,[str(binary)],environment(process,profile,mode,'1280x720'),label+'-'+mode,MARKER,release))
assert all(sha(ROOT/name)==digest for name,digest in source['source_sha256'].items())
assert sha(binary)==manifest['binary']['sha256']
assert (ROOT/'project.godot').read_text(encoding='utf-8')==normal_main
(base/'acceptance.json').write_text(json.dumps(dict(receipts=receipts,source_hashes_verified=len(runtime),binary_sha256_verified=True),indent=2),encoding='utf-8')
print('PASS: independent QA embedded executable writer and new-process reader',flush=True)
