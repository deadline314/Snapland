"""Owned D native/QA stage, explicit fixture closure, strict bounded validated launches."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import uuid

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from tools.build_desktop_release import prepare_runtime_stage
from tools.godot_entrypoints import run_validated_godot

ENGINE = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
FIXTURES = ['game/tests/native_syrup_flood_main.gd', 'game/tests/native_syrup_flood_main.tscn',
            'game/tests/native_sugar_bridge_main.gd', 'game/tests/audio_playback_release.gd']
MARKER = 'PASS: native syrup Main genuine inputs, tanks, cold plug, originals and restart'
KEYS = ['SNAPLAND_SAVE_PATH','APPDATA','LOCALAPPDATA','TEMP','TMP','SYRUP_CAPTURE_DIR','SYRUP_REVIEW_MODE','SYRUP_REVIEW_SIZE']

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def environment(base, profile, mode='', size='1280x720', output=None):
    env = dict(os.environ, SNAPLAND_SAVE_PATH=str(profile/'progress.json'), APPDATA=str(base/'appdata'),
               LOCALAPPDATA=str(base/'localappdata'), TEMP=str(base/'temp'), TMP=str(base/'temp'),
               SYRUP_CAPTURE_DIR=str(output or base/'captures'), SYRUP_REVIEW_MODE=mode, SYRUP_REVIEW_SIZE=size)
    for key in ['APPDATA','LOCALAPPDATA','TEMP']: Path(env[key]).mkdir(parents=True, exist_ok=True)
    return env

def run(stage, command, env, label, marker=None, release=None):
    result = run_validated_godot(stage,command,env,300,release_directory=release)
    raw = result.stdout+result.stderr
    log = HERE/(label+'.log')
    log.write_text(raw,encoding='utf-8')
    ok = result.returncode == 0 and 'ERROR:' not in raw and 'leaked' not in raw.lower() and 'still in use' not in raw.lower() and (marker is None or result.stdout.splitlines().count(marker)==1)
    receipt = dict(command=command,environment={k:env[k] for k in KEYS},exit=result.returncode,errors=raw.count('ERROR:'),marker_count=result.stdout.splitlines().count(marker) if marker else None,pass_all_guards=ok,log=str(log))
    (HERE/(label+'-receipt.json')).write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    print(label, result.returncode, receipt['errors'], ok, flush=True)
    if not ok: print(raw[-6000:],flush=True); raise RuntimeError(label+' failed strict guards')
    return receipt

def stage_new(label):
    base=Path('D:/Snapland-QA')/('syrup-native-'+label+'-'+uuid.uuid4().hex[:8])
    stage=base/'project'; stage.mkdir(parents=True)
    tracked=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT,text=True,encoding='utf-8').split('\0')
    manifest=prepare_runtime_stage(ROOT,stage,tracked)
    for name in FIXTURES:
        target=stage/name; target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(ROOT/name,target)
        manifest[name]=sha(ROOT/name)
    (base/'source-manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    (HERE/(label+'-stage.json')).write_text(json.dumps(dict(base=str(base),stage=str(stage),source_sha256=manifest,qa_fixture_allowlist=FIXTURES),indent=2),encoding='utf-8')
    run(stage,[ENGINE,'--headless','--path',str(stage),'--editor','--import','--quit'],environment(base/'import',base/'import-profile'),label+'-import')
    return base,stage

def native(label,size,mode,existing=None):
    if existing:
        info=json.loads((HERE/(existing+'-stage.json')).read_text()); base=Path(info['base']); stage=Path(info['stage'])
        for name in FIXTURES:
            shutil.copy2(ROOT/name,stage/name)
            info['source_sha256'][name]=sha(ROOT/name)
        assert all(sha(stage/name)==digest and sha(ROOT/name)==digest for name,digest in info['source_sha256'].items())
        (HERE/(label+'-stage.json')).write_text(json.dumps(info,indent=2),encoding='utf-8')
    else: base,stage=stage_new(label)
    profile=base/(label+'-'+mode+'-'+size+'-profile')
    assert not profile.exists(), 'Writer profile must be new; only its read process reuses it'
    for part in [mode,'read']:
        process=base/(part+'-'+size+'-'+uuid.uuid4().hex[:6])
        run(stage,[ENGINE,'--path',str(stage),'res://game/tests/native_syrup_flood_main.tscn'],environment(process,profile,part,size),label+'-'+part,MARKER)
    return base,stage

if __name__=='__main__':
    label,size,mode=sys.argv[1:4]
    native(label,size,mode,sys.argv[4] if len(sys.argv)>4 else None)
