"""Verify promoted frozen receipts and untouched PNG/source bytes, no image rewriting."""
from run import *
import struct

labels=sys.argv[1:]
assert labels
cases=[]
for label in labels:
    receipt=json.loads((HERE/(label+'-receipt.json')).read_text(encoding='utf-8'))
    assert receipt['pass_all_guards'] and receipt['exit']==0 and receipt['errors']==0 and receipt['marker_count']==1
    log=Path(receipt['log']).read_text(encoding='utf-8')
    assert log.splitlines().count(MARKER)==1 and 'ERROR:' not in log and 'leaked' not in log.lower() and 'still in use' not in log.lower()
    captures=Path(receipt['environment']['SYRUP_CAPTURE_DIR'])
    physical=json.loads((captures/'physical-report.json').read_text(encoding='utf-8'))
    report=json.loads((captures/'report.json').read_text(encoding='utf-8'))
    assert not physical['failures'] and not report['failures']
    assert 'Godot Engine v4.7.2.stable.official.ed1daf0bf' in log
    if receipt['environment']['SYRUP_REVIEW_MODE']=='suite':
        outcomes=[(r['success'],r['devil'],r['assisted'],r['practice'],r['ordinary_eligible'],r['score']) for r in report['results']]
        assert outcomes==[(True,False,False,False,True,400),(True,True,False,False,True,500),(True,True,True,False,True,500),(False,False,False,False,True,0),(True,True,False,True,False,500)]
        assert all(r['game_id']=='game-027' and r['mistakes']==0 and r['score_summary']['total']==r['score'] for r in report['results'])
    pngs=[]
    for path in sorted(captures.glob('*.png')):
        raw=path.read_bytes()
        assert raw[:8]==b'\x89PNG\r\n\x1a\n'
        width,height=struct.unpack('>II',raw[16:24])
        assert f'{width}x{height}'==receipt['environment']['SYRUP_REVIEW_SIZE']
        pngs.append(dict(path=str(path),sha256=sha(path),bytes=len(raw),size=[width,height]))
    assert len(pngs)==len(report['captures'])
    for photo,files in physical['original_hashes'].items():
        for name,digest in files.items(): assert sha(Path(name))==digest
    cases.append(dict(label=label,receipt=receipt,captures=pngs,guard_count_before_audio_release=physical['checks'],natural_results=report['results'],gameplay_capture_history=physical['gameplay_capture_history'],original_hashes=physical['original_hashes'],unsupported_material_warnings=log.count('unsupported ShaderMaterial')))
sources={name:sha(ROOT/name) for name in FIXTURES}
native_manifest=json.loads((HERE/'delivered1280-stage.json').read_text(encoding='utf-8'))
assert all(sha(ROOT/name)==digest and sha(Path(native_manifest['stage'])/name)==digest for name,digest in native_manifest['source_sha256'].items())
build=json.loads((HERE/'qa-frozen-build.json').read_text(encoding='utf-8'))
assert native_manifest['source_sha256']==build['source_sha256']
assert all(sha(ROOT/name)==digest for name,digest in build['source_sha256'].items())
assert all(sha(Path(build['stage'])/name)==digest for name,digest in build['runtime_sha256'].items())
assert sha(Path(build['binary']['path']))==build['binary']['sha256']
(HERE/'promoted-native.json').write_text(json.dumps(dict(cases=cases,fixture_source_sha256=sources,source_hashes_verified=len(native_manifest['source_sha256']),qa_build=build),indent=2),encoding='utf-8')
print('PASS promoted',len(cases),'processes',sum(len(case['captures']) for case in cases),'raw PNGs',flush=True)
