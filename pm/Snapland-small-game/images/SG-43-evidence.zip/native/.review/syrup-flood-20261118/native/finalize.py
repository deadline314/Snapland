from run import *
import runpy

prior=None
for label,size,mode in [('delivered1280','1280x720','suite'),('delivered1152','1152x648','suite'),('delivered800','800x600','suite'),('deliveredretakeordinary','1280x720','retake-ordinary'),('deliveredretakedevil','1280x720','retake-devil'),('deliveredretake1152','1152x648','retake-devil'),('deliveredretake800','800x600','retake-ordinary')]:
    native(label,size,mode,prior)
    prior=label
runpy.run_path(str(HERE/'package.py'),run_name='__main__')
