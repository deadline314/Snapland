"""Collate already-passing immutable evidence; does not launch or modify the game."""
from run import *

data=json.loads((HERE/'promoted-native.json').read_text(encoding='utf-8'))
cases=data['cases']; build=data['qa_build']
assert len(cases)==16 and sum(len(c['captures']) for c in cases)==194
engine=dict(path=ENGINE,sha256=sha(Path(ENGINE)),version='4.7.2.stable.official.ed1daf0bf')
(HERE/'engine-identity.json').write_text(json.dumps(engine,indent=2),encoding='utf-8')
by_label={c['label']:c for c in cases}
source=build['source_sha256']
core=['game/tests/native_syrup_flood_main.gd','game/tests/native_syrup_flood_main.tscn',
      'game/tests/native_sugar_bridge_main.gd','game/tests/audio_playback_release.gd',
      'game/main.gd','game/minigames/session.gd','game/core/game_catalog.gd',
      'game/minigames/syrup_flood_model.gd','game/minigames/syrup_flood_driver.gd','game/minigames/syrup_flood_view.gd',
      'assets/ui/tutorials/game-027-step-01.png','assets/ui/tutorials/game-027-step-02.png','assets/ui/tutorials/game-027-step-03.png']
lines=['# Task 4 report — scripted native/output-package evidence complete','',
'Status: assigned Task4 implementation and local verification complete; root owns fresh review, PM/public archive, Git/merge/CI and final delivery. No whole-branch or subjective acceptance claim. Final source base `'+build['source_commit_base']+'` on rebased SG43 after MAIN34 and its test-only CI followup. Only new native `.gd/.tscn` and private `native/` launchers/evidence were authored here. No production/base/helper, Git/index/HEAD, player save or prior accepted QA package was edited.','',
'## Frozen source and exact engine','',
'Raw SHA256 below describes the actual fresh checkout/staged bytes. Model/driver/view raw hashes differ from Tasks1–3 solely through Git CRLF checkout; `.review/syrup-flood-20261118/rebase-source-identity.json` records unchanged Git blob identity. Historical source bytes were not restored. All three tutorial PNGs remain byte-identical. Full1195-file source inventory is `native/delivered1280-stage.json` and the QA build manifest; the final collector compared every source file to current workspace and native stage, verified the identical QA source inventory, every exported-runtime file, and executable SHA.','',
'| File | SHA256 |','|---|---|']
lines += [f'| `{name}` | `{source[name]}` |' for name in core]
lines += ['',f'Engine: `{ENGINE}`, actual raw header `{engine["version"]}`, SHA256 `{engine["sha256"]}`. All accepted native logs identify AMD Radeon RX9070XT / Vulkan Forward+; this establishes this machine/render path only. Each engine/import/export/embedded-executable process uses `tools.godot_entrypoints.run_validated_godot` with bounded300-second launcher timeout; native fixture additionally has180-second watchdog. No error/leak/warning suppression.', '',
'## Promoted actual cases','',
'**16 separate accepted processes, eight writer/reader pairs;194 raw viewport PNGs;24 natural Session result emissions.** Each has actual exit0, zero `ERROR:`, exact completion marker once on stdout, no leaked/still-in-use diagnostic, empty report failures and successful inherited AudioRelease cleanup. Counts below are fixture guards captured immediately before its final additional audio-release guard. The collector also asserts exact actual result flags/scores and PNG/source/binary integrity.','',
'| Process | Guards before cleanup | Raw PNGs | Natural results |','|---|---:|---:|---:|']
lines += [f'| `{c["label"]}` | {c["guard_count_before_audio_release"]} | {len(c["captures"])} | {len(c["natural_results"])} |' for c in cases]
lines += ['',
'The1280×720,1152×648 and800×600 native suite writers each traverse actual Main factory entrance/invitation, all five ordered rules pages (goal/instructions/devil/participation/assist), actual regional map callback/three entries, all three decoded tutorial PNG pages, actual Session+3D View+MainHUD, ordinary, real cold-plug devil, assisted designated-AI devil, honest participated timeout, successful practice, real pause/HUD confirmation cancel, and collection book.800×600 uses1.25 UI/reduced motion. Each suite produces400/500/500/0/500 natural result scores respectively; all are mistake-free, practice is ineligible, timeout fails honestly, and first-game40coin/card/ACH_GAME_027 receipts never repeat. The successful model ends from the last real valve input; subsequent actual Session processing settles Main naturally. No result is patched.','',
'All eight main composite commands plus3D valves are exercised through actual `Input.parse_input_event` keyboard/mouse/touch routes with real focused View/GUI. Every captured flow recursively checks all visible Button bounds against the physical viewport; MainHUD and transformed eight View controls are also checked. All five rules pages use four actual focused Next button callbacks and verify page index/count/copy. No standalone workbench is presented as Main. The retake arrangement uses the existing scrollable house panel; viewport bounds checks are not a claim that every scrollable option is simultaneously exposed.','',
'Each selected ordinary/devil retake begins with zero027 cards: actual practice input then HUD cancel restores the selected retake; real demonstration/arrangement/Next/Shutter generate an actual GPU image. Stored full original pixels equal the arranged viewport pixels and thumbnails decode at320×180; retake provenance remains honest (`retake`, initially no challenge proof), only selected card is initially granted, global027 achievement and exactly one40coin receipt are recorded. A later genuine matching challenge preserves original SHA/path and acquisition method, adds actual devil proof where appropriate, and grants no second receipt. New process reads the same isolated save and verifies exact coins, local3/global027, tutorial, every current original SHA, valid originals/thumbnails and actual book rendering. Both selected targets run at1280; devil retake additionally runs1152, ordinary retake800.','',
'## Input/setup and photo semantics','',
'**Only six welcome admission cards and intro/prologue-seen context are synthetic.** Raw writers print this explicitly. No027 state, fill, temperature, plug, result, score, card, achievement, currency or photo is preseeded/injected. The factory actor is deliberately placed at `(7,GROUND_Y,-6)` as a disclosed controlled fixture, followed by actual physics nearest detection and E input; this is not walking evidence. Deterministic public-snapshot decisions and fixed-step Session `_process` drive real physics rather than real-time/human play. Practice/cancel award guards are real Main routes.','',
'Root ruled existing gameplay-photo refresh semantics are intentional: ordinary/devil gameplay cards share the current capture paths, and later completed gameplay refreshes their bytes. Card/coin deduplication does not mean first-gameplay-image immutability. Final1280 first-original observations by actual completion were:']
for h in by_label['delivered1280-suite']['gameplay_capture_history']:
    first=next(iter(h['hashes']['photo-candy-game-3'].values()))
    lines.append(f'- {h["label"]}: `{first}`')
lines += ['',
'Per-completion histories retain every measured original SHA; current originals decode at actual full viewport size, all current thumbnails at320×180, and normal/devil current paths/hashes match. The separate retake invariant is byte preservation after challenge/new-process reopening, verified above. The later challenge may legitimately earn the other normal card after an initially selected-only devil retake.','',
'## Fresh D stages, commands and package','',
'Native source stage: `D:/Snapland-QA/syrup-native-delivered1280-61401cf3/project`. `prepare_runtime_stage` consumes UTF-8 tracked runtime inventory and excludes the test tree; only the explicit four-file fixture closure is copied afterward: native syrup `.gd/.tscn`, existing native sugar base, existing AudioRelease. No whole repo/test tree, untracked UID/import cache or C import cache is copied. Each writer profile is newly created with a unique label; its reader alone shares it. Every process has its own fresh absolute D APPDATA/LOCALAPPDATA/TEMP/TMP; exact values and command arguments are retained in each `*-receipt.json`.','',
'Executed final family command:','',
'```powershell','python .review/syrup-flood-20261118/native/finalize.py','```','',
'This calls the validated engine with `--headless --path <fresh-stage> --editor --import --quit`, then GPU scene entry `--path <stage> res://game/tests/native_syrup_flood_main.tscn` per native case. Package uses a separate fresh stage, validates its import, exports `--headless --path <QA-stage> --editor --export-release "Windows Desktop" <SyrupFloodQA.exe> --quit`, then launches the actual embedded exe with **no path/scene override**, once as writer and once as reader. Exact fully expanded commands are in retained receipts/logs, not reconstructed from this shorthand.','',
f'Independent latest QA base: `{build["base"]}`. Executable `{build["binary"]["path"]}`; {build["binary"]["bytes"]} bytes; SHA256 `{build["binary"]["sha256"]}`. Official Windows4.7.2 release template `{build["templates"]["release"]["path"]}`, SHA256 `{build["templates"]["release"]["sha256"]}`; debug template SHA256 `{build["templates"]["debug"]["sha256"]}`. Template version file and PE version are4.7.2. Native/executable logs show the exact4.7.2 official engine build.', '',
'QA-only overrides are staged `project.godot` embedded Main entry and staged export preset enabling just the explicit four-fixture closure plus pinned custom Windows templates. `build.json` retains both original source and staged/exported runtime SHA inventories, template/executable identities and override description; `acceptance.json` retains both actual exe process receipts and final source/binary checks. Normal source project still launches `res://game/main.tscn`, and standard release staging/export exclusions omit QA fixtures. No player release was replaced by this private QA pack.','',
'Final collector command:','',
'```powershell','python .review/syrup-flood-20261118/native/collect.py '+' '.join(c['label'] for c in cases),'```','',
'Result: `PASS promoted 16 processes 194 raw PNGs`. `promoted-native.json` is the complete passing-source/PNG/receipt index. No engine tests/export were repeated after the final clean freeze. Metadata collation only reads/hashes artifacts. `engine-identity.json` separately records pinned engine SHA; the package metadata-only engine-field addition overlapped its execution, so its existing immutable `build.json` is retained as generated rather than retroactively edited.','',
'## Raw PNG/public archive inputs','',
'Representative files are raw uncropped captures; every PNG SHA/size/dimension is in `promoted-native.json`. For each suite directory use `factory-entrance.png`, `invite.png`, all five `rules-*.png`, `map.png`, `map-entries.png`, three `tutorial-*.png`, `configuration-controls.png`, `ordinary-live-heat-tanks.png`, `devil-actual-cold-plug.png`, `assisted-ai-live-heat-tanks.png`, ordinary/devil/assisted/timeout/practice results, `pause.png`, `album.png`. Each retake writer additionally retains `retake-demonstration/arranged/saved.png`, actual later challenge and `after-retake-result.png`; readers retain `restart-album.png`. Exact directories:','']
lines += [f'- `{c["label"]}`: `{c["receipt"]["environment"]["SYRUP_CAPTURE_DIR"]}`.' for c in cases]
lines += ['',
'`public-archive-inputs.json` is an explicit existing-file allowlist (actual path/SHA/bytes) of these194 PNGs, raw reports/logs/receipts, current GPU originals/thumbnails/provenance receipts, source/build/acceptance identities and reproduction scripts. It includes no superseded/failing run, player profile or whole repository; root chooses public representative copies/ZIP. The large QA executable stays at its recorded D path unless root explicitly archives it.','',
'## Corrections, self-review and limits','',
'The initial pre-MAIN34 native800 full scan correctly rejected six clipped shared-rules buttons; MAIN34 was separately ticketed/delivered by root, then this fixture was updated to traverse all five repaired pages. That failed evidence remains in `frozen800-suite*` and its D raw paths. Earlier candidate1 correctly failed for three harness references after Session naturally freed; the narrow native lifetime guard was fixed. Resumed `latest1280` was rejected for an inferred String parser error in the new visible-copy helper; only that owned helper received an explicit String type, the owned failed-parser process was stopped, and rejected stage `D:/Snapland-QA/syrup-native-latest1280-e2a606df`/logs remain untouched. No failed candidate is promoted. Older preliminary QA package `D:/Snapland-QA/syrup-native-qa-final-6424918d` remains untouched and superseded.','',
'Self-review covered owned-file scope, frozen source/line endings, retained stage isolation and release exclusions, full real input/Session trajectory, first40coin/card deduplication, intentional gameplay refresh vs retake-byte invariant, process-new reload, five ordered rule callbacks, all three real lesson textures, visible button/translated View bounds, PNG provenance, strict exit/marker/error/leak checks and cleanup. All16 promoted GPU/embedded logs have zero unsupported ShaderMaterial warnings; inherited Task3 headless warning-only material diagnostics remain disclosed in Task3 and were not suppressed or treated as a new defect.','',
'These are scripted input/numeric/GPU/save checks on this machine. No human play, human hearing, art-naturalness, fresh-save earned-admission/full-island play or cross-device performance acceptance is claimed. Controlled actor placement is not walking. Native actual retry/variant-B coverage is not claimed here; approved Task3 covered retry/A-B Session contracts. No recording was requested by this Task4 baseline, so no clip was produced. Tasks1–3/merged PixelShell/CookieMain suites were not rerun here. Root fresh task/whole-branch reviews and final Git/PM/CI delivery remain outstanding.','']
report=ROOT/'.superpowers/sdd/2026-11-18-syrup-flood/task-4-report.md'
report.write_text('\n'.join(lines),encoding='utf-8')
inputs={}
def include(path,category):
    path=Path(path)
    assert path.is_file(),path
    inputs[str(path)]=dict(path=str(path),category=category,sha256=sha(path),bytes=path.stat().st_size)
for c in cases:
    for png in c['captures']: include(png['path'],'raw-main-png')
    captures=Path(c['receipt']['environment']['SYRUP_CAPTURE_DIR'])
    for name in ['report.json','physical-report.json']: include(captures/name,'native-report')
    include(HERE/(c['label']+'-receipt.json'),'process-receipt');include(c['receipt']['log'],'raw-process-log')
    profile=Path(c['receipt']['environment']['SNAPLAND_SAVE_PATH']).parent
    include(profile/'native-originals.json','gpu-original-provenance')
    provenance=json.loads((profile/'native-originals.json').read_text(encoding='utf-8'))
    for photo,record in provenance['photos'].items():
        if not photo.startswith('photo-candy-'): continue
        for key in ['original_frames','frames']:
            for path in record.get(key,[]):include(path,'gpu-original' if key=='original_frames' else 'saved-thumbnail')
for name in ['delivered1280-stage.json','qa-frozen-stage.json','qa-frozen-build.json','promoted-native.json','engine-identity.json','run.py','finalize.py','package.py','collect.py','finish_report.py']:
    include(HERE/name,'manifest-or-reproduction')
for name in ['build.json','acceptance.json']:include(Path(build['base'])/name,'qa-build-acceptance')
for label in ['delivered1280-import','qa-frozen-import','qa-frozen-export']:
    include(HERE/(label+'-receipt.json'),'build-process-receipt');include(HERE/(label+'.log'),'raw-build-log')
include(report,'task4-report')
(HERE/'public-archive-inputs.json').write_text(json.dumps(dict(scope='Explicit final passing evidence only; no executable or player profile',files=list(inputs.values())),indent=2),encoding='utf-8')
print('Wrote final report and',len(inputs),'explicit archive input files',flush=True)
