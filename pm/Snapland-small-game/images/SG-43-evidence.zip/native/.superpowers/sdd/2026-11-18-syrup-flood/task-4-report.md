# Task 4 report — scripted native/output-package evidence complete

Status: assigned Task4 implementation and local verification complete; root owns fresh review, PM/public archive, Git/merge/CI and final delivery. No whole-branch or subjective acceptance claim. Final source base `decdb9927191d68012f180485bb80d2703c77ea0` on rebased SG43 after MAIN34 and its test-only CI followup. Only new native `.gd/.tscn` and private `native/` launchers/evidence were authored here. No production/base/helper, Git/index/HEAD, player save or prior accepted QA package was edited.

## Frozen source and exact engine

Raw SHA256 below describes the actual fresh checkout/staged bytes. Model/driver/view raw hashes differ from Tasks1–3 solely through Git CRLF checkout; `.review/syrup-flood-20261118/rebase-source-identity.json` records unchanged Git blob identity. Historical source bytes were not restored. All three tutorial PNGs remain byte-identical. Full1195-file source inventory is `native/delivered1280-stage.json` and the QA build manifest; the final collector compared every source file to current workspace and native stage, verified the identical QA source inventory, every exported-runtime file, and executable SHA.

| File | SHA256 |
|---|---|
| `game/tests/native_syrup_flood_main.gd` | `b513b2f17e28de5306f61f9d59a73ad3c68991f53ce27ef0ac0f23666a864003` |
| `game/tests/native_syrup_flood_main.tscn` | `47c9220d94455e98ab9188ddd976b894137ccddd1b41432e2992d422cf0aeb13` |
| `game/tests/native_sugar_bridge_main.gd` | `f802c6de3c6ae892ae2895a13cff7917a13d14b857082267ce1910a7024524d7` |
| `game/tests/audio_playback_release.gd` | `1b61bba4e5c54e38050e8ba0b7170b18848198928937ca2c4dfdebc31cc37184` |
| `game/main.gd` | `21dfcd21d77dd79c9702f3d787df187c8f261ab06f7860d39de8702e4228730e` |
| `game/minigames/session.gd` | `cd5b9e66f43a9fb1ab97ddf88fe1d6e27f8b9b5d2b0c80b59b88706740340e75` |
| `game/core/game_catalog.gd` | `9eb57e6e4cdec84d461e2d5df87b8a03acdecc68793c78e7d22d06441b7d360d` |
| `game/minigames/syrup_flood_model.gd` | `5b0f253ac0406334bf36ef162dbea3417ec50af9b04515ce9581dd453100c847` |
| `game/minigames/syrup_flood_driver.gd` | `18542b0bb1fdc648ee5dfa6f96562b2816d1046938c3468ac7694bdce8e94dda` |
| `game/minigames/syrup_flood_view.gd` | `4a578000b00d753662be7d37000b329711b7027ec9aa1e3b363bc33bd6b9340a` |
| `assets/ui/tutorials/game-027-step-01.png` | `bdbd972dcb9ef883e4b744b66ce55322f1349c41e5bc6a4b9169d2bc50f33e5e` |
| `assets/ui/tutorials/game-027-step-02.png` | `4c8df903815e99e8ee0a983a84cc002e5f7b791608c678a97fbb3ebe2e6099e8` |
| `assets/ui/tutorials/game-027-step-03.png` | `aa082a483a592b35da1595e2b250495e3ae73dbe8a9a451f6c7b8fddc763feeb` |

Engine: `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe`, actual raw header `4.7.2.stable.official.ed1daf0bf`, SHA256 `c8f0a6bc45a19b33541501e57f6f7cd972ab18453743266339d495cbbe846643`. All accepted native logs identify AMD Radeon RX9070XT / Vulkan Forward+; this establishes this machine/render path only. Each engine/import/export/embedded-executable process uses `tools.godot_entrypoints.run_validated_godot` with bounded300-second launcher timeout; native fixture additionally has180-second watchdog. No error/leak/warning suppression.

## Promoted actual cases

**16 separate accepted processes, eight writer/reader pairs;194 raw viewport PNGs;24 natural Session result emissions.** Each has actual exit0, zero `ERROR:`, exact completion marker once on stdout, no leaked/still-in-use diagnostic, empty report failures and successful inherited AudioRelease cleanup. Counts below are fixture guards captured immediately before its final additional audio-release guard. The collector also asserts exact actual result flags/scores and PNG/source/binary integrity.

| Process | Guards before cleanup | Raw PNGs | Natural results |
|---|---:|---:|---:|
| `delivered1280-suite` | 336 | 27 | 5 |
| `delivered1280-read` | 18 | 1 | 0 |
| `delivered1152-suite` | 335 | 27 | 5 |
| `delivered1152-read` | 17 | 1 | 0 |
| `delivered800-suite` | 345 | 27 | 5 |
| `delivered800-read` | 17 | 1 | 0 |
| `deliveredretakeordinary-retake-ordinary` | 220 | 19 | 1 |
| `deliveredretakeordinary-read` | 17 | 1 | 0 |
| `deliveredretakedevil-retake-devil` | 226 | 20 | 1 |
| `deliveredretakedevil-read` | 18 | 1 | 0 |
| `deliveredretake1152-retake-devil` | 225 | 20 | 1 |
| `deliveredretake1152-read` | 17 | 1 | 0 |
| `deliveredretake800-retake-ordinary` | 221 | 19 | 1 |
| `deliveredretake800-read` | 16 | 1 | 0 |
| `qa-frozen-suite` | 336 | 27 | 5 |
| `qa-frozen-read` | 18 | 1 | 0 |

The1280×720,1152×648 and800×600 native suite writers each traverse actual Main factory entrance/invitation, all five ordered rules pages (goal/instructions/devil/participation/assist), actual regional map callback/three entries, all three decoded tutorial PNG pages, actual Session+3D View+MainHUD, ordinary, real cold-plug devil, assisted designated-AI devil, honest participated timeout, successful practice, real pause/HUD confirmation cancel, and collection book.800×600 uses1.25 UI/reduced motion. Each suite produces400/500/500/0/500 natural result scores respectively; all are mistake-free, practice is ineligible, timeout fails honestly, and first-game40coin/card/ACH_GAME_027 receipts never repeat. The successful model ends from the last real valve input; subsequent actual Session processing settles Main naturally. No result is patched.

All eight main composite commands plus3D valves are exercised through actual `Input.parse_input_event` keyboard/mouse/touch routes with real focused View/GUI. Every captured flow recursively checks all visible Button bounds against the physical viewport; MainHUD and transformed eight View controls are also checked. All five rules pages use four actual focused Next button callbacks and verify page index/count/copy. No standalone workbench is presented as Main. The retake arrangement uses the existing scrollable house panel; viewport bounds checks are not a claim that every scrollable option is simultaneously exposed.

Each selected ordinary/devil retake begins with zero027 cards: actual practice input then HUD cancel restores the selected retake; real demonstration/arrangement/Next/Shutter generate an actual GPU image. Stored full original pixels equal the arranged viewport pixels and thumbnails decode at320×180; retake provenance remains honest (`retake`, initially no challenge proof), only selected card is initially granted, global027 achievement and exactly one40coin receipt are recorded. A later genuine matching challenge preserves original SHA/path and acquisition method, adds actual devil proof where appropriate, and grants no second receipt. New process reads the same isolated save and verifies exact coins, local3/global027, tutorial, every current original SHA, valid originals/thumbnails and actual book rendering. Both selected targets run at1280; devil retake additionally runs1152, ordinary retake800.

## Input/setup and photo semantics

**Only six welcome admission cards and intro/prologue-seen context are synthetic.** Raw writers print this explicitly. No027 state, fill, temperature, plug, result, score, card, achievement, currency or photo is preseeded/injected. The factory actor is deliberately placed at `(7,GROUND_Y,-6)` as a disclosed controlled fixture, followed by actual physics nearest detection and E input; this is not walking evidence. Deterministic public-snapshot decisions and fixed-step Session `_process` drive real physics rather than real-time/human play. Practice/cancel award guards are real Main routes.

Root ruled existing gameplay-photo refresh semantics are intentional: ordinary/devil gameplay cards share the current capture paths, and later completed gameplay refreshes their bytes. Card/coin deduplication does not mean first-gameplay-image immutability. Final1280 first-original observations by actual completion were:
- ordinary: `68b923e55892dd33893ae95721d3d08266ac360f93ecc00b74ae6e4b8bb2caad`
- devil: `7b6a683b534a6765f4b391f144af5a7ce8283cab41feca286ed76418d6d15977`
- assisted-ai: `3d762c3e2dcccf92ef917dc716a0abf250ea15abd62dbeed786f2c98ab26f038`
- timeout: `ea559d3858ade87a5e98d313cc48f8b42ecb9f4f8dc642029509a375144b08ef`

Per-completion histories retain every measured original SHA; current originals decode at actual full viewport size, all current thumbnails at320×180, and normal/devil current paths/hashes match. The separate retake invariant is byte preservation after challenge/new-process reopening, verified above. The later challenge may legitimately earn the other normal card after an initially selected-only devil retake.

## Fresh D stages, commands and package

Native source stage: `D:/Snapland-QA/syrup-native-delivered1280-61401cf3/project`. `prepare_runtime_stage` consumes UTF-8 tracked runtime inventory and excludes the test tree; only the explicit four-file fixture closure is copied afterward: native syrup `.gd/.tscn`, existing native sugar base, existing AudioRelease. No whole repo/test tree, untracked UID/import cache or C import cache is copied. Each writer profile is newly created with a unique label; its reader alone shares it. Every process has its own fresh absolute D APPDATA/LOCALAPPDATA/TEMP/TMP; exact values and command arguments are retained in each `*-receipt.json`.

Executed final family command:

```powershell
python .review/syrup-flood-20261118/native/finalize.py
```

This calls the validated engine with `--headless --path <fresh-stage> --editor --import --quit`, then GPU scene entry `--path <stage> res://game/tests/native_syrup_flood_main.tscn` per native case. Package uses a separate fresh stage, validates its import, exports `--headless --path <QA-stage> --editor --export-release "Windows Desktop" <SyrupFloodQA.exe> --quit`, then launches the actual embedded exe with **no path/scene override**, once as writer and once as reader. Exact fully expanded commands are in retained receipts/logs, not reconstructed from this shorthand.

Independent latest QA base: `D:\Snapland-QA\syrup-native-qa-frozen-0d37d3b0`. Executable `D:\Snapland-QA\syrup-native-qa-frozen-0d37d3b0\release\SyrupFloodQA.exe`; 285631072 bytes; SHA256 `d70f21c3a796e22c4771651a0461b6a9561635fa171e1faec8d967fd5aa99928`. Official Windows4.7.2 release template `C:\Users\stanl\AppData\Roaming\Godot\export_templates\4.7.2.stable\windows_release_x86_64.exe`, SHA256 `d34d36f3be1a6c49c56525ae86469b92e4f417ddf0b43cf00dd80c385c4b0562`; debug template SHA256 `51498b72b3a237f882ebd7d1787f06a4bc1eaf0572daab93837adcfd3cfdc107`. Template version file and PE version are4.7.2. Native/executable logs show the exact4.7.2 official engine build.

QA-only overrides are staged `project.godot` embedded Main entry and staged export preset enabling just the explicit four-fixture closure plus pinned custom Windows templates. `build.json` retains both original source and staged/exported runtime SHA inventories, template/executable identities and override description; `acceptance.json` retains both actual exe process receipts and final source/binary checks. Normal source project still launches `res://game/main.tscn`, and standard release staging/export exclusions omit QA fixtures. No player release was replaced by this private QA pack.

Final collector command:

```powershell
python .review/syrup-flood-20261118/native/collect.py delivered1280-suite delivered1280-read delivered1152-suite delivered1152-read delivered800-suite delivered800-read deliveredretakeordinary-retake-ordinary deliveredretakeordinary-read deliveredretakedevil-retake-devil deliveredretakedevil-read deliveredretake1152-retake-devil deliveredretake1152-read deliveredretake800-retake-ordinary deliveredretake800-read qa-frozen-suite qa-frozen-read
```

Result: `PASS promoted 16 processes 194 raw PNGs`. `promoted-native.json` is the complete passing-source/PNG/receipt index. No engine tests/export were repeated after the final clean freeze. Metadata collation only reads/hashes artifacts. `engine-identity.json` separately records pinned engine SHA; the package metadata-only engine-field addition overlapped its execution, so its existing immutable `build.json` is retained as generated rather than retroactively edited.

## Raw PNG/public archive inputs

Representative files are raw uncropped captures; every PNG SHA/size/dimension is in `promoted-native.json`. For each suite directory use `factory-entrance.png`, `invite.png`, all five `rules-*.png`, `map.png`, `map-entries.png`, three `tutorial-*.png`, `configuration-controls.png`, `ordinary-live-heat-tanks.png`, `devil-actual-cold-plug.png`, `assisted-ai-live-heat-tanks.png`, ordinary/devil/assisted/timeout/practice results, `pause.png`, `album.png`. Each retake writer additionally retains `retake-demonstration/arranged/saved.png`, actual later challenge and `after-retake-result.png`; readers retain `restart-album.png`. Exact directories:

- `delivered1280-suite`: `D:\Snapland-QA\syrup-native-delivered1280-61401cf3\suite-1280x720-fbbc67\captures`.
- `delivered1280-read`: `D:\Snapland-QA\syrup-native-delivered1280-61401cf3\read-1280x720-acd0e3\captures`.
- `delivered1152-suite`: `D:\Snapland-QA\syrup-native-delivered1280-61401cf3\suite-1152x648-51f0ac\captures`.
- `delivered1152-read`: `D:\Snapland-QA\syrup-native-delivered1280-61401cf3\read-1152x648-568ae4\captures`.
- `delivered800-suite`: `D:\Snapland-QA\syrup-native-delivered1280-61401cf3\suite-800x600-3c3d49\captures`.
- `delivered800-read`: `D:\Snapland-QA\syrup-native-delivered1280-61401cf3\read-800x600-d4e5c7\captures`.
- `deliveredretakeordinary-retake-ordinary`: `D:\Snapland-QA\syrup-native-delivered1280-61401cf3\retake-ordinary-1280x720-d7eef2\captures`.
- `deliveredretakeordinary-read`: `D:\Snapland-QA\syrup-native-delivered1280-61401cf3\read-1280x720-ca6619\captures`.
- `deliveredretakedevil-retake-devil`: `D:\Snapland-QA\syrup-native-delivered1280-61401cf3\retake-devil-1280x720-6d2491\captures`.
- `deliveredretakedevil-read`: `D:\Snapland-QA\syrup-native-delivered1280-61401cf3\read-1280x720-41ed7c\captures`.
- `deliveredretake1152-retake-devil`: `D:\Snapland-QA\syrup-native-delivered1280-61401cf3\retake-devil-1152x648-8c70ba\captures`.
- `deliveredretake1152-read`: `D:\Snapland-QA\syrup-native-delivered1280-61401cf3\read-1152x648-39f674\captures`.
- `deliveredretake800-retake-ordinary`: `D:\Snapland-QA\syrup-native-delivered1280-61401cf3\retake-ordinary-800x600-c99929\captures`.
- `deliveredretake800-read`: `D:\Snapland-QA\syrup-native-delivered1280-61401cf3\read-800x600-7e6cf1\captures`.
- `qa-frozen-suite`: `D:\Snapland-QA\syrup-native-qa-frozen-0d37d3b0\suite-process\captures`.
- `qa-frozen-read`: `D:\Snapland-QA\syrup-native-qa-frozen-0d37d3b0\read-process\captures`.

`public-archive-inputs.json` is an explicit existing-file allowlist (actual path/SHA/bytes) of these194 PNGs, raw reports/logs/receipts, current GPU originals/thumbnails/provenance receipts, source/build/acceptance identities and reproduction scripts. It includes no superseded/failing run, player profile or whole repository; root chooses public representative copies/ZIP. The large QA executable stays at its recorded D path unless root explicitly archives it.

## Corrections, self-review and limits

The initial pre-MAIN34 native800 full scan correctly rejected six clipped shared-rules buttons; MAIN34 was separately ticketed/delivered by root, then this fixture was updated to traverse all five repaired pages. That failed evidence remains in `frozen800-suite*` and its D raw paths. Earlier candidate1 correctly failed for three harness references after Session naturally freed; the narrow native lifetime guard was fixed. Resumed `latest1280` was rejected for an inferred String parser error in the new visible-copy helper; only that owned helper received an explicit String type, the owned failed-parser process was stopped, and rejected stage `D:/Snapland-QA/syrup-native-latest1280-e2a606df`/logs remain untouched. No failed candidate is promoted. Older preliminary QA package `D:/Snapland-QA/syrup-native-qa-final-6424918d` remains untouched and superseded.

Self-review covered owned-file scope, frozen source/line endings, retained stage isolation and release exclusions, full real input/Session trajectory, first40coin/card deduplication, intentional gameplay refresh vs retake-byte invariant, process-new reload, five ordered rule callbacks, all three real lesson textures, visible button/translated View bounds, PNG provenance, strict exit/marker/error/leak checks and cleanup. All16 promoted GPU/embedded logs have zero unsupported ShaderMaterial warnings; inherited Task3 headless warning-only material diagnostics remain disclosed in Task3 and were not suppressed or treated as a new defect.

These are scripted input/numeric/GPU/save checks on this machine. No human play, human hearing, art-naturalness, fresh-save earned-admission/full-island play or cross-device performance acceptance is claimed. Controlled actor placement is not walking. Native actual retry/variant-B coverage is not claimed here; approved Task3 covered retry/A-B Session contracts. No recording was requested by this Task4 baseline, so no clip was produced. Tasks1–3/merged PixelShell/CookieMain suites were not rerun here. Root fresh task/whole-branch reviews and final Git/PM/CI delivery remain outstanding.
