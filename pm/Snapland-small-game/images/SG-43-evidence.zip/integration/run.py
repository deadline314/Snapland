import sys,os,json,hashlib,uuid,subprocess,shutil,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT))
from tools.build_desktop_release import prepare_runtime_stage
from tools.godot_entrypoints import run_validated_godot
from tools import run_game_tests as runner
HERE=Path(__file__).parent
label=sys.argv[1]; selected=sys.argv[2:]
base=Path('D:/Snapland-QA')/('syrup-integration-'+label+'-'+uuid.uuid4().hex[:8]);stage=base/'project';stage.mkdir(parents=True)
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT,encoding='utf-8').split('\0')
manifest=prepare_runtime_stage(ROOT,stage,tracked)
for name in ['game/tests/test_syrup_flood_session.gd','game/tests/test_syrup_flood_main.gd','game/tests/test_syrup_flood_main.tscn']:
 p=ROOT/name
 if p.exists():
  (stage/name).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,stage/name);manifest[name]=hashlib.sha256(p.read_bytes()).hexdigest()
if label == 'red-main':
 for name in ['game/core/game_catalog.gd','game/data/candy_games.json']:
  original=subprocess.check_output(['git','show','65344a3:'+name],cwd=ROOT)
  (stage/name).write_bytes(original);manifest[name]=hashlib.sha256(original).hexdigest()
runner.ROOT=stage
engine='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
checks=runner.build_checks(engine)
checks=[row for row in checks if row[0]=='clean project import' or any(s in row[0] for s in selected)]
if label.startswith('red'):
 checks.append(('syrup Session RED',[engine,'--headless','--path',str(stage),'--script','res://game/tests/test_syrup_flood_session.gd']))
# Copy only exact selected tracked test entries and their referenced fixture helpers.
pending=[arg[6:] for _,cmd in checks for arg in cmd if arg.startswith('res://game/tests/')]
seen=set()
while pending:
 name=pending.pop()
 if name in seen:continue
 seen.add(name);source=ROOT/name
 if name not in tracked and name not in ['game/tests/test_syrup_flood_session.gd','game/tests/test_syrup_flood_main.gd','game/tests/test_syrup_flood_main.tscn']:raise ValueError(name)
 dest=stage/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest);manifest[name]=hashlib.sha256(source.read_bytes()).hexdigest()
 pending.extend(re.findall(r'res://(game/tests/[^"\\]+\.(?:gd|tscn))',source.read_text(encoding='utf-8-sig')))
receipts=[]
for name,cmd in checks:
 profile=base/(re.sub(r'[^A-Za-z0-9-]', '-',name)+'-profile');env=dict(os.environ,SNAPLAND_SAVE_PATH=str(profile/'progress.json'),APPDATA=str(profile/'appdata'),LOCALAPPDATA=str(profile/'localappdata'),TEMP=str(profile/'temp'),TMP=str(profile/'temp'))
 for key in ['APPDATA','LOCALAPPDATA','TEMP']:Path(env[key]).mkdir(parents=True)
 result=run_validated_godot(stage,cmd,env,300)
 out=result.stdout+result.stderr; log=label+'-'+re.sub(r'[^A-Za-z0-9-]', '-',name)+'.log';(HERE/log).write_text(out,encoding='utf-8')
 err=runner.result_error(name,result) if name in runner.PASS_MARKERS else (None if result.returncode==0 and 'ERROR:' not in out else 'failed')
 receipts.append(dict(label=name,command=cmd,environment={k:env[k] for k in ['SNAPLAND_SAVE_PATH','APPDATA','LOCALAPPDATA','TEMP','TMP']},exit=result.returncode,error=err,log=log,source_sha256=manifest))
 (HERE/(label+'-receipt.json')).write_text(json.dumps(receipts,indent=2),encoding='utf-8');print(name,result.returncode,err or 'PASS',flush=True)
 if name=='clean project import' and (result.returncode or 'ERROR:' in out):break

sys.exit(1 if any(row["error"] for row in receipts) else 0)
