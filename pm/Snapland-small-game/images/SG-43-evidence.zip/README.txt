SG-43 scripted numerical/input/GPU/save evidence. 27 actual games;128 candidates.
Final native:16 processes,194 raw PNGs,24 natural results; all clean strict receipts.
Only6 welcome admission cards/opening-seen context are synthetic. Actor placement is controlled, not walking. No027 result/state/reward/photo injection.
Gameplay cards retain existing latest-capture refresh semantics; retake originals/provenance remain byte-exact after actual challenge and process restart.
Tasks1-3 are earlier scoped evidence; final Task4/merged rules checks validate current integrated UI. CRLF identity differences are disclosed.
QA-only embedded executable remains at its recorded D path; no executable or player profile in this archive. Normal player entry unchanged.
This is not human play/listening/art-naturalness/cross-device performance acceptance. Rejected candidates remain private, explicitly documented in reports.
