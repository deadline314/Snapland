"""Archive explicitly promoted evidence and its review history; never edit images."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
WORK = ROOT / '.superpowers/sdd/2026-11-18-syrup-flood'
PUBLIC = ROOT / 'pm/Snapland-small-game/images'
FILES = {}

def add(path, name):
    path = Path(path)
    assert path.is_file(), path
    assert name not in FILES or FILES[name] == path, name
    FILES[name] = path

native = json.loads((HERE/'native/public-archive-inputs.json').read_text(encoding='utf-8'))
for row in native['files']:
    path = Path(row['path'])
    assert path.stat().st_size == row['bytes']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256'], path
    name = ('raw-native/' + path.relative_to('D:/Snapland-QA').as_posix()) if path.drive.lower() == 'd:' else ('native/' + path.relative_to(ROOT).as_posix())
    add(path, name)

changed = subprocess.check_output(['git','diff','--name-only','-z','origin/main..HEAD'],cwd=ROOT,encoding='utf-8').split('\0')
for name in changed:
    if name and not name.startswith('pm/'):
        add(ROOT/name, 'source/'+name)
for path in WORK.glob('*.md'):
    add(path, 'review/'+path.name)
for path in (HERE/'merged-checks').glob('*.md'):
    add(path, 'merged-checks/'+path.name)
for path in (HERE/'merged-checks').glob('*.json'):
    add(path, 'merged-checks/'+path.name)
for path in (HERE/'merged-checks').glob('*.log'):
    add(path, 'merged-checks/'+path.name)
add(HERE/'rebase-source-identity.json', 'source/rebase-source-identity.json')

for name in ['final-import.log','final-test.log','final-receipt.json','red-test.log','run.py']:
    add(HERE/'model'/name, 'model/'+name)
for path in (HERE/'presentation').glob('freeze-*'):
    add(path, 'presentation/'+path.name)
for prefix in ['freeze1280','freeze1152','freeze800']:
    for path in (HERE/'presentation').glob(prefix+'-*'):
        add(path, 'presentation/'+path.name)
for name in ['run.py','finalize.py']:
    add(HERE/'presentation'/name, 'presentation/'+name)
for base in ['syrup-presentation-freeze1280-8cd76ccd','syrup-presentation-freeze1152-0b7b9a87','syrup-presentation-freeze800-85314cf2']:
    for path in (Path('D:/Snapland-QA')/base/'captures').glob('*.png'):
        add(path, 'presentation/'+base+'/'+path.name)

integration = HERE/'integration'
promoted = json.loads((integration/'promoted-results.json').read_text(encoding='utf-8'))
assert len(promoted) == 23
add(integration/'promoted-results.json','integration/promoted-results.json')
add(integration/'final-source-hashes.json','integration/final-source-hashes.json')
for row in promoted.values():
    assert row['exit'] == 0 and row['error'] is None
    add(integration/row['log'],'integration/'+row['log'])
    path = integration/(row['run']+'-clean-project-import.log')
    if path.is_file(): add(path,'integration/'+path.name)
for name in ['run.py','red2-syrup-Session-RED.log']:
    path = integration/name
    if path.is_file(): add(path,'integration/'+name)
for run in ['merged27-pixel-fd0eb7','merged27-cookie-98cf9e','import-fc4d7e']:
    for name in ['run.log','launch.json']:
        add(Path('D:/Snapland-QA/syrup-merged-rules-20261118')/run/name,'merged-checks/'+run+'/'+name)

base = Path('D:/Snapland-QA/syrup-native-delivered1280-61401cf3')
representatives = {
    'SG-43-flow.png': base/'suite-1280x720-fbbc67/captures/ordinary-live-heat-tanks.png',
    'SG-43-plug.png': base/'suite-1152x648-51f0ac/captures/devil-actual-cold-plug.png',
    'SG-43-small.png': base/'suite-800x600-3c3d49/captures/assisted-ai-live-heat-tanks.png',
    'SG-43-result.png': base/'suite-1280x720-fbbc67/captures/devil-result.png',
    'SG-43-retake.png': base/'retake-ordinary-800x600-c99929/captures/retake-saved.png',
    'SG-43-restart.png': Path('D:/Snapland-QA/syrup-native-qa-frozen-0d37d3b0/read-process/captures/restart-album.png'),
}
for name, path in representatives.items():
    shutil.copyfile(path,PUBLIC/name)
    assert (PUBLIC/name).read_bytes() == path.read_bytes()

add(Path(__file__), 'reproduce/delivery.py')
manifest = {name:{'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size} for name,path in FILES.items()}
readme = '''SG-43 scripted numerical/input/GPU/save evidence. 27 actual games;128 candidates.\nFinal native:16 processes,194 raw PNGs,24 natural results; all clean strict receipts.\nOnly6 welcome admission cards/opening-seen context are synthetic. Actor placement is controlled, not walking. No027 result/state/reward/photo injection.\nGameplay cards retain existing latest-capture refresh semantics; retake originals/provenance remain byte-exact after actual challenge and process restart.\nTasks1-3 are earlier scoped evidence; final Task4/merged rules checks validate current integrated UI. CRLF identity differences are disclosed.\nQA-only embedded executable remains at its recorded D path; no executable or player profile in this archive. Normal player entry unchanged.\nThis is not human play/listening/art-naturalness/cross-device performance acceptance. Rejected candidates remain private, explicitly documented in reports.\n'''
archive = PUBLIC/'SG-43-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as out:
    for name,path in sorted(FILES.items()): out.write(path,name)
    out.writestr('manifest.json',json.dumps(manifest,indent=2))
    out.writestr('README.txt',readme)
with zipfile.ZipFile(archive) as inp:
    assert inp.testzip() is None
    for name,row in manifest.items():
        data = inp.read(name)
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'], name
result = {'archive':str(archive),'entries':len(manifest),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
(HERE/'archive-result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result),flush=True)
