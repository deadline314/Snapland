param(
    [Parameter(Mandatory)][ValidatePattern('^[a-z0-9][a-z0-9_-]*$')][string]$CaseName,
    [ValidateSet('pck','exe')][string]$Target='pck',
    [ValidateSet('normal','assisted','timeout','read','gap')][string]$Mode='normal',
    [int]$Width=1280,
    [int]$Height=720,
    [double]$Step=0.025,
    [switch]$LargeText,
    [string]$ProfilePath=''
)
$ErrorActionPreference='Stop'
$preview=(Resolve-Path -LiteralPath (Split-Path -Parent $PSScriptRoot)).Path
$case=Join-Path $PSScriptRoot $CaseName
if(Test-Path -LiteralPath $case){throw 'Refuse to overwrite an existing verification case'}
if($ProfilePath){
    $profile=[IO.Path]::GetFullPath($ProfilePath)
    if(-not $profile.StartsWith($preview+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Profile must remain inside this preview'}
    if($Mode -ne 'read' -or -not (Test-Path -LiteralPath $profile -PathType Leaf)){throw 'Only a real reader may reuse an existing profile'}
}else{
    if($Mode -eq 'read'){throw 'Reader requires an actual writer profile'}
    $profile=Join-Path $case 'profile.json'
}
New-Item -ItemType Directory -Path $case | Out-Null
$env:SNAPLAND_SAVE_PATH=$profile
$env:SNAPLAND_NATIVE_REVIEW_SCRIPT=Join-Path $PSScriptRoot 'native_rowing_main.gd'
$env:ROWING_CAPTURE_DIR=Join-Path $case 'captures'
$env:ROWING_REVIEW_MODE=$Mode
$env:ROWING_LARGE_TEXT=if($LargeText){'1'}else{'0'}
$env:ROWING_TUTORIAL_DIR=''
$env:ROWING_STEP=$Step.ToString('R',[Globalization.CultureInfo]::InvariantCulture)
$nativeArgs=@('--audio-driver','Dummy','--resolution',"${Width}x${Height}",'--script',(Join-Path $PSScriptRoot 'pack-bootstrap.gd'))
$empty=Join-Path $PSScriptRoot 'empty-pack-cwd'
if($Target -eq 'pck'){
    $binary='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
    $nativeArgs=@('--path',$empty,'--main-pack',(Join-Path $PSScriptRoot 'Snapland.pck'))+$nativeArgs
}else{
    $binary=Join-Path $preview 'Snapland.exe'
    if(Test-Path -LiteralPath (Join-Path $preview 'Snapland.pck')){throw 'Standalone proof requires no sidecar pack beside exe'}
}
$stdout=Join-Path $case 'stdout.log'
$stderr=Join-Path $case 'stderr.log'
$nativeProcess=Start-Process -FilePath $binary -ArgumentList $nativeArgs -WorkingDirectory $empty -WindowStyle Hidden -RedirectStandardOutput $stdout -RedirectStandardError $stderr -PassThru
Write-Output "Native $Target/$Mode running pid=$($nativeProcess.Id)"
if(-not $nativeProcess.WaitForExit(180000)){
    $nativeProcess.Kill()
    throw 'Native case exceeded 180seconds'
}
$log=(Get-Content -LiteralPath $stdout -Raw)+(Get-Content -LiteralPath $stderr -Raw)
$marker=switch($Mode){
    'read' {'PASS: native rowing saved harbor restart, earned card and original PNG'}
    'gap' {'PASS: native rowing exposed tide-gap public-input crossing'}
    default {'PASS: native rowing Main actual controls, truthful result, real photos, replay and restart'}
}
$result=@{target=$Target;mode=$Mode;source='123e769251903fa086f742f2a475668f6ab62422';exit=$nativeProcess.ExitCode;errors=([regex]::Matches($log,'ERROR:')).Count;warnings=([regex]::Matches($log,'WARNING:')).Count;pass=$log.Contains($marker);width=$Width;height=$Height;step=$Step;large_text=[bool]$LargeText;profile=$profile;default_forward_plus=$true;dummy_audio=$true}
$result | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $case 'verification.json') -Encoding utf8
$result | ConvertTo-Json -Compress
if($nativeProcess.ExitCode -ne 0 -or $result.errors -ne 0 -or -not $result.pass -or $log -match 'ObjectDB instances leaked|resources still in use|Orphan .*nodes'){
    Get-Content -LiteralPath $stderr -Tail 15
    throw 'Native verification failed'
}
