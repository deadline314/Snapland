param([Parameter(Mandatory)][ValidateSet('fresh','harbor','art')][string]$Kind)
$ErrorActionPreference='Stop'
$preview=(Resolve-Path -LiteralPath (Split-Path -Parent $PSScriptRoot)).Path
$case=Join-Path $PSScriptRoot ('exe-smoke-'+$Kind)
if(Test-Path -LiteralPath $case){throw 'Existing case'}
New-Item -ItemType Directory -Path $case | Out-Null
$env:SNAPLAND_SAVE_PATH=Join-Path $case 'profile.json'
if($Kind -eq 'harbor'){Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'pck-assisted-final/profile.json') -Destination $env:SNAPLAND_SAVE_PATH}
$argsList=@('--audio-driver','Dummy','--resolution','1280x720','--','--smoke-test')
if($Kind -eq 'art'){$argsList+='--smoke-art'}
$p=Start-Process -FilePath (Join-Path $preview 'Snapland.exe') -ArgumentList $argsList -WorkingDirectory (Join-Path $PSScriptRoot 'empty-pack-cwd') -WindowStyle Hidden -RedirectStandardOutput (Join-Path $case 'stdout.log') -RedirectStandardError (Join-Path $case 'stderr.log') -PassThru
if(-not $p.WaitForExit(180000)){$p.Kill(); throw 'Smoke timeout'}
$log=(Get-Content -LiteralPath (Join-Path $case 'stdout.log') -Raw)+(Get-Content -LiteralPath (Join-Path $case 'stderr.log') -Raw)
$result=@{kind=$Kind;exit=$p.ExitCode;errors=([regex]::Matches($log,'ERROR:')).Count;warnings=([regex]::Matches($log,'WARNING:')).Count;pass=$log.Contains('PASS:');standalone_without_sidecar=(-not(Test-Path -LiteralPath (Join-Path $preview 'Snapland.pck')));default_forward_plus=$log.Contains('Forward+');dummy_audio=$true}
$result | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $case 'verification.json') -Encoding utf8
$result | ConvertTo-Json -Compress
if($p.ExitCode -ne 0 -or $result.errors -ne 0 -or -not $result.pass -or $log -match 'ObjectDB instances leaked|resources still in use|Orphan .*nodes'){throw 'Smoke failure'}
