extends SceneTree

func _initialize() -> void:
	call_deferred("_start")

func _start() -> void:
	var path := OS.get_environment("SNAPLAND_NATIVE_REVIEW_SCRIPT")
	if not path.is_absolute_path() or not FileAccess.file_exists(path):
		push_error("External native review script is missing")
		quit(1)
		return
	var fixture_script := load(path)
	if fixture_script == null:
		quit(1)
		return
	var fixture: Node = fixture_script.new()
	fixture.name = "NativeRowingMain"
	root.add_child(fixture)
	current_scene = fixture
