# Task 1 report

Status: DONE

Commit: `0395d9b5db8d6860c5e1c768fc228de3bb1555b2` — `feat: add delivered harbor catalog and atomic game rewards`

Base supplied by controller: `d45ec484248cca0a17eccf91a1a3866ae8e5ddec`. No branch switches, pushes, subagents, runner registration, or unrelated source edits. Commit author and committer: `Stanley <stanley890314@gmail.com>`. Controller approved the additional one-line return-value fixture update in `test_photo_originals.gd` before modification.

## Source and contract mapping

- `game/core/game_catalog.gd`: lightweight RefCounted, only explicit welcome/harbor JSON paths, cached validated raw rows, deep copies from all APIs. Original welcome bare-array file and row shape remain unchanged. Validates both source arrays, exact delivered counts and global order, all ten required nonempty text fields, canonical IDs, identifier modes, global ID/mode uniqueness, optional zone/local_index agreement. Invalid fixtures fail closed before identity generation. No UI, Session, tutorial or model resource loads.
- `game/data/harbor_games.json`: exactly one delivered runtime row: game-013 / rowing_cargo / 浪間小艇. Exact requested instructions, ordinary and devil text. Explicit harbor/local_index 1. No game-014 or other planned IDs.
- `game/core/progress.gd`: catalog identity resolves canonical persistent game IDs; modes remain lookup aliases only in Catalog. Transaction stages ordinary/devil photos, one 40-coin reward, global receipt, global/regional milestones and platform pending achievements, writes once, then emits success signals while suppressing nested changed-triggered saves. Actual save failure restores all touched dictionaries, currency and arrays; no success signals. Replays preserve original metadata and produce no duplicate writes/money/signals when already complete. Existing ordinary photo without receipt gains only receipt, never retroactive coins. Welcome milestones still require twelve welcome card IDs; all-zone devil threshold remains unchanged.
- `game/core/progress.gd`: generalized attachment uses the existing PNG/header/dimension/byte/pixel limits, frame caps, fallback and rollback body with catalog photo identity. Compatible welcome wrapper retains its welcome-only restriction. Existing grant_photo/_unlock outside complete_game and welcome legacy-photo backfill remain unchanged. Tutorial/reward save validators now accept delivered canonical013 while rejecting014/unknown/malformed/mode aliases.
- `game/tests/test_game_catalog.gd`: default welcome equality/order, harbor1/all13, identity and aliases, deep-copy APIs, unsupported/malformed keys, explicit parser fixtures including duplicate modes, reordered/duplicate IDs, malformed rows/text, wrong region/local index, arbitrary mode paths, and no cached UI/Session dependency.
- `game/tests/test_harbor_game_progress.gd`: ordinary, devil, assistance, metadata preservation, idempotence, canonical validators, legacy no-retroactive coins, shared thumbnails/originals/fallback/restrictions, one-write transaction and after-save signal ordering, nested changed suppression, full welcome milestone thresholds, actual separate-process reload, actual blocked temporary-file failure and retry for completion and attachments. Child failure verifies exact expected diagnostics, no hidden errors.
- `game/tests/test_tutorial_seen_progress.gd`, `game/tests/test_wardrobe.gd`: only unsupported sentinel013→014.
- `game/tests/test_photo_originals.gd`: only obsolete null-return assertion→true saved-status assertion.

## Public signatures

```gdscript
GameCatalog.definitions(zone: String = "welcome") -> Array
GameCatalog.all_definitions() -> Array
GameCatalog.find(id_or_mode: String) -> Dictionary
GameCatalog.identity(id_or_mode: String) -> Dictionary
Progress.complete_game(game_id: String, devil: bool, assisted: bool = false) -> bool
Progress.attach_game_photo_frames(game_id: String, saved_frames: Array, include_devil: bool, saved_original_frames: Array = []) -> bool
Progress.attach_welcome_game_photo_frames(game_id: String, saved_frames: Array, include_devil: bool, saved_original_frames: Array = []) -> bool
```

Identity013: `{id: game-013, mode: rowing_cargo, zone: harbor, local_index: 1, photo_id: photo-harbor-game-1, devil_photo_id: photo-harbor-devil-1, achievement_id: ACH_GAME_013}`.

## Scope/caller inspection

Read task-1 brief, binding runtime spec, applicable root AGENTS.md, Progress, SteamBridge, wardrobe catalog, affected tests and runner conventions. Searched every complete_game/attachment caller and tutorial/reward validator. Main calls continue to accept bool-returning completion without Task1 changes; Main will consume saved status and generic attachment in its later task. SteamBridge is deliberately not modified: pending achievements are staged in the same persisted transaction before it observes achievement signals. No existing pending_changed listener exists in the codebase. Existing wardrobe/core/thumbnail/region consumers retain their APIs.

## Validation

Pinned engine: `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe`, reported `4.7.2.stable.official.ed1daf0bf`.

All direct engine invocations had absolute isolated `SNAPLAND_SAVE_PATH` under `C:/Users/stanl/AppData/Local/Temp/snapland-sg28-task1/`. No player profile was used. Every test/review child used the inherited isolated absolute path or a dedicated child subdirectory. No WSL engine run was needed.

Command shape, working directory repository root:

```text
SNAPLAND_SAVE_PATH=<absolute isolated folder>/profile.json
<engine> --headless --audio-driver Dummy --path . --editor --import --quit
<engine> --headless --audio-driver Dummy --path . <scene>
<engine> --headless --audio-driver Dummy --path . --script <script>
```

Logs are absolute Windows paths with prefix `C:/Users/stanl/AppData/Local/Temp/snapland-sg28-task1/` unless noted.

| Phase | Target | Result | Log |
|---|---|---|---|
| Baseline import | clean worktree import | exit0 | `C:/Users/stanl/AppData/Local/Temp/snapland-sg28-task1-import.log` |
| Baseline | `res://game/tests/test_core.tscn` | PASS exit0 | `baseline-core.log` |
| Baseline | `res://game/tests/test_tutorial_seen_progress.tscn` incl failed-save Main child | PASS exit0 | `baseline-tutorial.log` |
| Baseline | `res://game/tests/test_wardrobe.gd` script | PASS exit0 | `baseline-wardrobe.log` |
| Baseline | `res://game/tests/test_main_photo_thumbnails.tscn` | PASS exit0 | `baseline-thumbnails.log` |
| Baseline | `res://game/tests/test_photo_originals.tscn` | PASS exit0 | `baseline-originals.log` |
| RED | `res://game/tests/test_game_catalog.gd` script | expected exit1: missing catalog | `red-game_catalog.log` |
| RED | `res://game/tests/test_harbor_game_progress.gd` script | expected exit1: absent generic attachment, unsupported013/void saved status | `red-harbor_game_progress.log` |
| GREEN | `res://game/tests/test_game_catalog.gd` script | PASS exit0 | `green1-game_catalog.log` |
| GREEN | `res://game/tests/test_harbor_game_progress.gd` script | PASS exit0, includes real reload/failure child contracts | `green1-harbor_game_progress.log` |
| Focused | `res://game/tests/test_core.tscn` | PASS exit0 | `focused-core.log` |
| Focused | `res://game/tests/test_tutorial_seen_progress.tscn` incl failure child | PASS exit0 | `focused-tutorial.log` |
| Focused | `res://game/tests/test_wardrobe.gd` script | PASS exit0 | `focused-wardrobe.log` |
| Focused | `res://game/tests/test_main_photo_thumbnails.tscn` | PASS exit0 | `focused-thumbnails.log` |
| Focused | `res://game/tests/test_photo_originals.tscn` | PASS exit0 | `focused-originals.log` |
| Focused | `res://game/tests/test_region_progress.gd` script | PASS exit0 | `focused-region-progress.log` |

New pass markers:

- `PASS: delivered game catalog, copies, regional identity and malformed data`
- `PASS: harbor rewards, replay, legacy, captures, reload and atomic failure`

Harbor progress suite captures a real reload child using `-- --reload-child`: loads both harbor cards/captures, global reward receipt, tutorial, achievement/pending receipt, coins and unknown metadata. It captures a distinct `failure/profile.json` child using `-- --failure-child`: exactly two `Cannot write progress temporary file '<child>.tmp': Can't open file` diagnostics and one `Could not save gameplay thumbnail paths for 'photo-harbor-game-1'.`; failure child checks byte-for-byte prior save content and complete memory snapshot, no success signals, one completion save attempt, retry, then both-card attachment rollback. The outer suite checks child exit0, exact markers and exact diagnostics and has no ERROR lines. Expected malformed-input/missing-image WARNING lines remain visible in its log.

`git diff --cached --check` passed before commit. Self-review confirmed only eight owned source/data/test files in commit and no .import/.uid metadata. Every affected baseline was rerun once after implementation; no broad repeated runtime or Python suite.

## Concerns and remaining boundaries

No material Task1 contract concern. Integration intentionally remains for later tasks: runner registration, Session/Main/UI, native gameplay, exports and full CI were not changed or checked here. Generated tracked .import diffs and untracked .uid/.import files from the necessary Windows import remain in the shared worktree, unstaged and uncommitted; controller was notified for final cleanup. Native gameplay is not claimed by these catalog/save checks.

## Source signatures (SHA-256 of working file bytes at handoff)

- `game/core/game_catalog.gd`: `eba273309ca6db0eeba71401c01f0c55efd6138f381ea63be3148dbc74acd1b9`
- `game/core/progress.gd`: `37811650bb241a98f313f6b8915fecc8111067ba3ab236c2e1b4876234a159ba`
- `game/data/harbor_games.json`: `d78f5a9c6b0d72a4aa0fa84076d0d277d7bff3f7badd046b4108dd192c578c47`
- `game/tests/test_game_catalog.gd`: `ddcbe5f582af3dd82eaead1d23000a691764a362160fb9c8d75a0d7a486dfbd7`
- `game/tests/test_harbor_game_progress.gd`: `74f25befc39745bcaeb305d0647763ed55d972529db42770e95980a56316d149`
- `game/tests/test_photo_originals.gd`: `904e65030bdede3019d58aeb1783dc57cdea47de8c6c929690dc4371913a5677`
- `game/tests/test_tutorial_seen_progress.gd`: `058b896e7685e3f5b96d6b278a307576f659308b3817b8d9fe94e3711be418c3`
- `game/tests/test_wardrobe.gd`: `df6501432009640cddc169bb72fb077167fe9819d0f933a8997eb097a483cc54`
