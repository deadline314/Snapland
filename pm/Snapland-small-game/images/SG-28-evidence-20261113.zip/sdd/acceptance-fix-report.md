# SG28 acceptance fixture repair report

Status: complete. Commit `f6f9a8bf788e17ab02ab7c3e35b116019fb5aefb` (`fix(tests): restore isolated save and melody fixtures`). Author and committer: Stanley Li <stanley890314@gmail.com>. No push performed.

## Scope and root causes

Base: `123e769251903fa086f742f2a475668f6ab62422`; branch `codex/rowing-game-20261113`. Only the two owned fixtures were committed. No production, runner, deadline, catalog, save format, configuration, exports or other tests changed. Applicable AGENTS.md was read; the narrower brief's no-push and exact ownership requirements govern this acceptance repair. Existing SG28 work and other files were preserved.

1. `game/tests/test_test_save_guard.gd`: `_build_fixture_project()` cloned only four core dependencies. `Progress` now preloads `game_catalog.gd`, so even the isolated child probe produced a parse error and could exit zero while logging engine errors; later child modes could hang without a usable Progress autoload. Inspection of the entire catalog showed the exact additional runtime inputs are `game/data/welcome_games.json` and `game/data/harbor_games.json`. The fixture now copies the additional script and both original JSON files, with symmetric exact-file removal in `_cleanup_temp_fixture()`. It reuses the existing byte-copy helper. No recursive cleanup or additional dependencies were introduced.

2. `game/tests/test_melody_memory_view.gd`: the headless fixture assigned its already-ready root-owned view to `Session.presentation` before `Session.start()`. The new correct start lifecycle hides and queues the previous presentation for deletion, then clears the reference. The pointer could still reach the model synchronously but its response no longer refreshed that view; a subsequent frame freed it and the outer owner called `queue_free()` on a freed instance. The fixture now starts the real game first, attaches the borrowed headless view afterward, connects its original input signals and calls `_sync_presentation()` for initial state. It disconnects both signals and clears the borrowed presentation reference before freeing Session; the root owner continues freeing the fixture view once. Two assertions were added for initial synchronization and root ownership survival. The original pointer→model→view, atlas/cache, retry, practice, and native creation assertions remain intact. The native branch still lets Session create and own its actual presentation.

The touched functions' callers were searched with `rg`: save construction/cleanup are private to this fixture; melody lifecycle is awaited by `_run()`. Existing runner registration remains the save scene and melody script respectively. No callers, fixtures, exports or configuration outside the two owned files need updates. Real Snapland profile data is never opened by these validations: each launch has a fresh absolute SNAPLAND_SAVE_PATH; the save test's intentional invalid/missing overrides and ordinary-default branch run solely in its unique fake application project.

## Validation

Pinned engines: Windows `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe`; WSL Ubuntu as user `stanley`, `/home/stanley/.cache/snapland-boat-debug/Godot_v4.7.2-stable_linux.x86_64`. Both report `4.7.2.stable.official.ed1daf0bf`.

Every green command had a 90-second process deadline. The unchanged production runner and fixtures retain their existing deadlines. Red melody reproductions used a stricter 12-second outer deadline because the known freed-instance error leaves the engine running. Windows timeout handling killed the exact process tree; WSL launched engines in a new process session and killed that process group on timeout, then reaped it. No orphan engines remained in final Windows process/WSL pgrep checks. All green commands exited zero, emitted their required completion marker, and contained no `ERROR:` lines (including `SCRIPT ERROR:`); no diagnostic allowlist was used.

| Platform | Save guard | Melody view | Rowing Session reuse | Ribbon Session lifecycle |
|---|---|---|---|---|
| Windows headless | full PASS | 56 checks | 34 checks, 0 failures | 61 checks |
| Linux headless | full PASS | 56 checks | 34 checks, 0 failures | 61 checks |
| Windows native | not repeated | 55 checks | 50 checks, 0 failures | not repeated |

Save PASS includes the six existing rejected child paths, seeded original/`.bak`/`.tmp` SHA-256 preservation, positive isolated save/reload, and normal unique fake default-profile load/save/reopen. Both logs contain `NEGATIVE_FAKE_PROFILE_HASHES_UNCHANGED`, `NORMAL_DEFAULT_LOAD_SAVE_OK` and `NORMAL_DEFAULT_REOPEN_OK`. A separate exact-path self-check verified both platforms removed the unique fake default profile and temporary cloned project; the outer independent save directories are retained as evidence.

The unchanged rowing Session regression covers driver→legacy→driver replacement, paused overlay release, stopped old driver clocks, unknown-game teardown and cancellation without completion. Native Windows additionally exercises actual view teardown, GUI input, rendering ownership and three resize paths. Native melody verifies actual imported atlas creation, pointer response, retry, practice and final ownership. These are automated integration checks, not a claim of human gameplay or visual quality review.

## Red evidence

Before edits, the existing private old-dependency clone at `.review/ci-save-guard-probe/project` reproduced the missing `game_catalog.gd` preload and Progress autoload errors on Windows and Linux. This bounded probe exits zero despite errors, demonstrating why strict log scanning remains necessary. The full unmodified melody fixture reproduced the pointer response failure followed by `Cannot call method 'queue_free' on a previously freed instance` and was terminated at its bound on both platforms. The prior supplied `ci-save-guard-probe-red.log` and `ci-melody-probe-red.log` were preserved.

## Exact commands and logs

Executed through temporary harness `C:/Users/stanl/AppData/Local/Temp/snapland-acceptance-run.py`, invoked as `python <harness> <platform> <phase> <case>` (platform `windows`, `linux`, or `windows-native`; phase `red`/`green`; cases `save`, `melody`, `session`, `ribbon`). Below are each invocation's exact engine/wrapper argv, explicit isolated environment, deadline and result, also stored in the first line of its adjacent log. Linux save paths are Linux-native. Native commands omit `--headless`.

### acceptance-linux-green-melody.log

```json
{
  "command": [
    "wsl",
    "-d",
    "Ubuntu",
    "-u",
    "stanley",
    "--",
    "env",
    "SNAPLAND_SAVE_PATH=/home/stanley/.cache/snapland-boat-debug/acceptance-3e11c5aca6bd4edf8fbe8779c4a4b331/progress.json",
    "python3",
    "-c",
    "import os,signal,subprocess,sys\np=subprocess.Popen(sys.argv[2:],start_new_session=True)\ntry:\n rc=p.wait(timeout=float(sys.argv[1]))\nexcept subprocess.TimeoutExpired:\n os.killpg(p.pid,signal.SIGKILL);p.wait();print(\"BOUNDED_TIMEOUT\",flush=True);rc=124\nsys.exit(rc)",
    "90",
    "/home/stanley/.cache/snapland-boat-debug/Godot_v4.7.2-stable_linux.x86_64",
    "--headless",
    "--path",
    "/mnt/c/Users/stanl/Github/Snapland/.review/rowing-game-worktree",
    "--audio-driver",
    "Dummy",
    "--rendering-method",
    "gl_compatibility",
    "--script",
    "res://game/tests/test_melody_memory_view.gd"
  ],
  "SNAPLAND_SAVE_PATH": "/home/stanley/.cache/snapland-boat-debug/acceptance-3e11c5aca6bd4edf8fbe8779c4a4b331/progress.json",
  "timeout_seconds": 90,
  "returncode": 0,
  "elapsed_seconds": 5.7
}
```

Completion: Melody memory view: 56 checks passed.

### acceptance-linux-green-ribbon.log

```json
{
  "command": [
    "wsl",
    "-d",
    "Ubuntu",
    "-u",
    "stanley",
    "--",
    "env",
    "SNAPLAND_SAVE_PATH=/home/stanley/.cache/snapland-boat-debug/acceptance-99b853da8e754ce38621d5528db22d00/progress.json",
    "python3",
    "-c",
    "import os,signal,subprocess,sys\np=subprocess.Popen(sys.argv[2:],start_new_session=True)\ntry:\n rc=p.wait(timeout=float(sys.argv[1]))\nexcept subprocess.TimeoutExpired:\n os.killpg(p.pid,signal.SIGKILL);p.wait();print(\"BOUNDED_TIMEOUT\",flush=True);rc=124\nsys.exit(rc)",
    "90",
    "/home/stanley/.cache/snapland-boat-debug/Godot_v4.7.2-stable_linux.x86_64",
    "--headless",
    "--path",
    "/mnt/c/Users/stanl/Github/Snapland/.review/rowing-game-worktree",
    "--audio-driver",
    "Dummy",
    "--rendering-method",
    "gl_compatibility",
    "--script",
    "res://game/tests/test_ribbon_finish_session.gd"
  ],
  "SNAPLAND_SAVE_PATH": "/home/stanley/.cache/snapland-boat-debug/acceptance-99b853da8e754ce38621d5528db22d00/progress.json",
  "timeout_seconds": 90,
  "returncode": 0,
  "elapsed_seconds": 16.22
}
```

Completion: PASS: Ribbon Session lifecycle (61 checks).

### acceptance-linux-green-save.log

```json
{
  "command": [
    "wsl",
    "-d",
    "Ubuntu",
    "-u",
    "stanley",
    "--",
    "env",
    "SNAPLAND_SAVE_PATH=/home/stanley/.cache/snapland-boat-debug/acceptance-7587fde42b1b496396ec24624bdd5334/progress.json",
    "python3",
    "-c",
    "import os,signal,subprocess,sys\np=subprocess.Popen(sys.argv[2:],start_new_session=True)\ntry:\n rc=p.wait(timeout=float(sys.argv[1]))\nexcept subprocess.TimeoutExpired:\n os.killpg(p.pid,signal.SIGKILL);p.wait();print(\"BOUNDED_TIMEOUT\",flush=True);rc=124\nsys.exit(rc)",
    "90",
    "/home/stanley/.cache/snapland-boat-debug/Godot_v4.7.2-stable_linux.x86_64",
    "--headless",
    "--path",
    "/mnt/c/Users/stanl/Github/Snapland/.review/rowing-game-worktree",
    "--audio-driver",
    "Dummy",
    "--rendering-method",
    "gl_compatibility",
    "res://game/tests/test_test_save_guard.tscn"
  ],
  "SNAPLAND_SAVE_PATH": "/home/stanley/.cache/snapland-boat-debug/acceptance-7587fde42b1b496396ec24624bdd5334/progress.json",
  "timeout_seconds": 90,
  "returncode": 0,
  "elapsed_seconds": 5.67
}
```

Completion: NEGATIVE_FAKE_PROFILE_HASHES_UNCHANGED; NORMAL_DEFAULT_LOAD_SAVE_OK; NORMAL_DEFAULT_REOPEN_OK; PASS: save guard child processes use a unique verified fake Godot profile; every rejected-path case preserves seeded sidecars.

### acceptance-linux-green-session.log

```json
{
  "command": [
    "wsl",
    "-d",
    "Ubuntu",
    "-u",
    "stanley",
    "--",
    "env",
    "SNAPLAND_SAVE_PATH=/home/stanley/.cache/snapland-boat-debug/acceptance-44153d65fac5446a9b52e717775e5048/progress.json",
    "python3",
    "-c",
    "import os,signal,subprocess,sys\np=subprocess.Popen(sys.argv[2:],start_new_session=True)\ntry:\n rc=p.wait(timeout=float(sys.argv[1]))\nexcept subprocess.TimeoutExpired:\n os.killpg(p.pid,signal.SIGKILL);p.wait();print(\"BOUNDED_TIMEOUT\",flush=True);rc=124\nsys.exit(rc)",
    "90",
    "/home/stanley/.cache/snapland-boat-debug/Godot_v4.7.2-stable_linux.x86_64",
    "--headless",
    "--path",
    "/mnt/c/Users/stanl/Github/Snapland/.review/rowing-game-worktree",
    "--audio-driver",
    "Dummy",
    "--rendering-method",
    "gl_compatibility",
    "--script",
    "res://game/tests/test_rowing_session.gd"
  ],
  "SNAPLAND_SAVE_PATH": "/home/stanley/.cache/snapland-boat-debug/acceptance-44153d65fac5446a9b52e717775e5048/progress.json",
  "timeout_seconds": 90,
  "returncode": 0,
  "elapsed_seconds": 7.09
}
```

Completion: Rowing Session: 34 checks, 0 failures.

### acceptance-linux-red-melody.log

```json
{
  "command": [
    "wsl",
    "-d",
    "Ubuntu",
    "-u",
    "stanley",
    "--",
    "env",
    "SNAPLAND_SAVE_PATH=/home/stanley/.cache/snapland-boat-debug/acceptance-d0e311a6b7734943a267eb9292cc8e01/progress.json",
    "python3",
    "-c",
    "import os,signal,subprocess,sys\np=subprocess.Popen(sys.argv[2:],start_new_session=True)\ntry:\n rc=p.wait(timeout=float(sys.argv[1]))\nexcept subprocess.TimeoutExpired:\n os.killpg(p.pid,signal.SIGKILL);p.wait();print(\"BOUNDED_TIMEOUT\",flush=True);rc=124\nsys.exit(rc)",
    "12",
    "/home/stanley/.cache/snapland-boat-debug/Godot_v4.7.2-stable_linux.x86_64",
    "--headless",
    "--path",
    "/mnt/c/Users/stanl/Github/Snapland/.review/rowing-game-worktree",
    "--audio-driver",
    "Dummy",
    "--rendering-method",
    "gl_compatibility",
    "--script",
    "res://game/tests/test_melody_memory_view.gd"
  ],
  "SNAPLAND_SAVE_PATH": "/home/stanley/.cache/snapland-boat-debug/acceptance-d0e311a6b7734943a267eb9292cc8e01/progress.json",
  "timeout_seconds": 12,
  "returncode": 124,
  "elapsed_seconds": 12.13
}
```

Completion: BOUNDED_TIMEOUT.

### acceptance-linux-red-save.log

```json
{
  "command": [
    "wsl",
    "-d",
    "Ubuntu",
    "-u",
    "stanley",
    "--",
    "env",
    "SNAPLAND_SAVE_PATH=/home/stanley/.cache/snapland-boat-debug/acceptance-fbf1556c495e49c5823ea870e60ecfca/progress.json",
    "python3",
    "-c",
    "import os,signal,subprocess,sys\np=subprocess.Popen(sys.argv[2:],start_new_session=True)\ntry:\n rc=p.wait(timeout=float(sys.argv[1]))\nexcept subprocess.TimeoutExpired:\n os.killpg(p.pid,signal.SIGKILL);p.wait();print(\"BOUNDED_TIMEOUT\",flush=True);rc=124\nsys.exit(rc)",
    "90",
    "/home/stanley/.cache/snapland-boat-debug/Godot_v4.7.2-stable_linux.x86_64",
    "--headless",
    "--path",
    "/mnt/c/Users/stanl/Github/Snapland/.review/rowing-game-worktree/.review/ci-save-guard-probe/project",
    "--audio-driver",
    "Dummy",
    "--rendering-method",
    "gl_compatibility",
    "--script",
    "res://game/tests/test_save_guard_child.gd",
    "--",
    "probe"
  ],
  "SNAPLAND_SAVE_PATH": "/home/stanley/.cache/snapland-boat-debug/acceptance-fbf1556c495e49c5823ea870e60ecfca/progress.json",
  "timeout_seconds": 90,
  "returncode": 0,
  "elapsed_seconds": 2.81
}
```

Completion: expected missing-preload and autoload errors; see full log.

### acceptance-windows-green-melody.log

```json
{
  "command": [
    "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe",
    "--headless",
    "--path",
    "C:\\Users\\stanl\\Github\\Snapland\\.review\\rowing-game-worktree",
    "--audio-driver",
    "Dummy",
    "--rendering-method",
    "gl_compatibility",
    "--script",
    "res://game/tests/test_melody_memory_view.gd"
  ],
  "SNAPLAND_SAVE_PATH": "C:\\Users\\stanl\\Github\\Snapland\\.review\\rowing-game-worktree\\.superpowers\\sdd\\2026-11-13-rowing-cargo\\acceptance-51b72367b70f4762a492b81e972719c0\\progress.json",
  "timeout_seconds": 90,
  "returncode": 0,
  "elapsed_seconds": 1.53
}
```

Completion: Melody memory view: 56 checks passed.

### acceptance-windows-green-ribbon.log

```json
{
  "command": [
    "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe",
    "--headless",
    "--path",
    "C:\\Users\\stanl\\Github\\Snapland\\.review\\rowing-game-worktree",
    "--audio-driver",
    "Dummy",
    "--rendering-method",
    "gl_compatibility",
    "--script",
    "res://game/tests/test_ribbon_finish_session.gd"
  ],
  "SNAPLAND_SAVE_PATH": "C:\\Users\\stanl\\Github\\Snapland\\.review\\rowing-game-worktree\\.superpowers\\sdd\\2026-11-13-rowing-cargo\\acceptance-6cb0158761804ab1950debf6f767a02d\\progress.json",
  "timeout_seconds": 90,
  "returncode": 0,
  "elapsed_seconds": 8.68
}
```

Completion: PASS: Ribbon Session lifecycle (61 checks).

### acceptance-windows-green-save.log

```json
{
  "command": [
    "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe",
    "--headless",
    "--path",
    "C:\\Users\\stanl\\Github\\Snapland\\.review\\rowing-game-worktree",
    "--audio-driver",
    "Dummy",
    "--rendering-method",
    "gl_compatibility",
    "res://game/tests/test_test_save_guard.tscn"
  ],
  "SNAPLAND_SAVE_PATH": "C:\\Users\\stanl\\Github\\Snapland\\.review\\rowing-game-worktree\\.superpowers\\sdd\\2026-11-13-rowing-cargo\\acceptance-0e3a25f66b39461fa661b13589983168\\progress.json",
  "timeout_seconds": 90,
  "returncode": 0,
  "elapsed_seconds": 3.39
}
```

Completion: NEGATIVE_FAKE_PROFILE_HASHES_UNCHANGED; NORMAL_DEFAULT_LOAD_SAVE_OK; NORMAL_DEFAULT_REOPEN_OK; PASS: save guard child processes use a unique verified fake Godot profile; every rejected-path case preserves seeded sidecars.

### acceptance-windows-green-session.log

```json
{
  "command": [
    "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe",
    "--headless",
    "--path",
    "C:\\Users\\stanl\\Github\\Snapland\\.review\\rowing-game-worktree",
    "--audio-driver",
    "Dummy",
    "--rendering-method",
    "gl_compatibility",
    "--script",
    "res://game/tests/test_rowing_session.gd"
  ],
  "SNAPLAND_SAVE_PATH": "C:\\Users\\stanl\\Github\\Snapland\\.review\\rowing-game-worktree\\.superpowers\\sdd\\2026-11-13-rowing-cargo\\acceptance-3a0267117a9740fc96898d91091c0fea\\progress.json",
  "timeout_seconds": 90,
  "returncode": 0,
  "elapsed_seconds": 3.4
}
```

Completion: Rowing Session: 34 checks, 0 failures.

### acceptance-windows-native-green-melody.log

```json
{
  "command": [
    "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe",
    "--path",
    "C:\\Users\\stanl\\Github\\Snapland\\.review\\rowing-game-worktree",
    "--audio-driver",
    "Dummy",
    "--rendering-method",
    "gl_compatibility",
    "--script",
    "res://game/tests/test_melody_memory_view.gd"
  ],
  "SNAPLAND_SAVE_PATH": "C:\\Users\\stanl\\Github\\Snapland\\.review\\rowing-game-worktree\\.superpowers\\sdd\\2026-11-13-rowing-cargo\\acceptance-81fb1f83df424c0590e5ec0aa264610d\\progress.json",
  "timeout_seconds": 90,
  "returncode": 0,
  "elapsed_seconds": 3.44
}
```

Completion: Melody memory view: 55 checks passed.

### acceptance-windows-native-green-session.log

```json
{
  "command": [
    "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe",
    "--path",
    "C:\\Users\\stanl\\Github\\Snapland\\.review\\rowing-game-worktree",
    "--audio-driver",
    "Dummy",
    "--rendering-method",
    "gl_compatibility",
    "--script",
    "res://game/tests/test_rowing_session.gd"
  ],
  "SNAPLAND_SAVE_PATH": "C:\\Users\\stanl\\Github\\Snapland\\.review\\rowing-game-worktree\\.superpowers\\sdd\\2026-11-13-rowing-cargo\\acceptance-45fa7e1f534245d4bf56f335d3957b9b\\progress.json",
  "timeout_seconds": 90,
  "returncode": 0,
  "elapsed_seconds": 7.3
}
```

Completion: Rowing Session: 50 checks, 0 failures.

### acceptance-windows-red-melody.log

```json
{
  "command": [
    "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe",
    "--headless",
    "--path",
    "C:\\Users\\stanl\\Github\\Snapland\\.review\\rowing-game-worktree",
    "--audio-driver",
    "Dummy",
    "--rendering-method",
    "gl_compatibility",
    "--script",
    "res://game/tests/test_melody_memory_view.gd"
  ],
  "SNAPLAND_SAVE_PATH": "C:\\Users\\stanl\\Github\\Snapland\\.review\\rowing-game-worktree\\.superpowers\\sdd\\2026-11-13-rowing-cargo\\acceptance-fb51bc362a2044c79e23e3a4cbe6bbe3\\progress.json",
  "timeout_seconds": 12,
  "returncode": 1,
  "elapsed_seconds": 12.17
}
```

Completion: BOUNDED_TIMEOUT.

### acceptance-windows-red-save.log

```json
{
  "command": [
    "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe",
    "--headless",
    "--path",
    "C:\\Users\\stanl\\Github\\Snapland\\.review\\rowing-game-worktree/.review/ci-save-guard-probe/project",
    "--audio-driver",
    "Dummy",
    "--rendering-method",
    "gl_compatibility",
    "--script",
    "res://game/tests/test_save_guard_child.gd",
    "--",
    "probe"
  ],
  "SNAPLAND_SAVE_PATH": "C:\\Users\\stanl\\Github\\Snapland\\.review\\rowing-game-worktree\\.superpowers\\sdd\\2026-11-13-rowing-cargo\\acceptance-097d4152747f4573a27150e47b6b0a51\\progress.json",
  "timeout_seconds": 90,
  "returncode": 0,
  "elapsed_seconds": 0.61
}
```

Completion: expected missing-preload and autoload errors; see full log.

## Final checks and limitations

- `git diff --check` passed before commit.
- `git show --format=fuller --stat -1` confirms exactly the two owned files and the requested author/committer email, without coauthor/model/assistant branding.
- Windows `Get-CimInstance Win32_Process` filtered to Godot engines and Linux `pgrep` for the exact pinned engine showed no remaining engines.
- Both fake-profile cleanup self-checks passed; no recursive deletion or real profile access occurred.
- Full local suite and Linux native rendering were intentionally not repeated. Parent owns fresh full CI, release verification and delivery documentation. No known unresolved fixture failure; future new Progress/catalog dependencies must continue being mirrored by this deliberately exact fixture clone.
