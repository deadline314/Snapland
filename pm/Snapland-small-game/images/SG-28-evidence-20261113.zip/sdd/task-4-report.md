# Task 4 — Session lifecycle and regional collection UI

Status: DONE in assigned scope. Commit `6a2191e901513ebcefc6f27de4cb6f2868a6772a` (`feat(rowing): integrate session lifecycle and harbor collection`). Author and committer: Stanley Li <stanley890314@gmail.com>. No assistant/model trailers. No branch switch, push, subagent, Main/world/tutorial/runner/metadata change, dependency, model or Task3 view edit.

Seven owned source/test files committed: Session, collection_book_panel, achievement_stamp_book, the approved minigame_hud accessor promotion, test_rowing_session, test_harbor_collection, and the one concretely affected harbor-empty expectation in test_region_travel. Generated import/uid files and controller design/plan changes were not staged. This ignored report/logs/images are local handoff evidence.

## Scope and self-review

Read root AGENTS, Task4 brief, binding design/runtime/rowing-cargo.md, Task3 report, relevant Session/driver/HUD/album/stamp callers and affected test fixtures; did not read the whole plan. Pre-change baselines passed before source edits: minigames84 cases and collection UI suite. Existing collection UI baseline emits OcclusionController unsupported-material warnings.

One optional `DRIVERS` map contains only rowing_cargo. Existing twelve modes retain their model/view branches and default catalog. Driver reset returns before legacy resets/prompts; model step returns before legacy elapsed/timeout. Driver state owns elapsed/score/mistakes and normalized HUD time/progress. No second timer, new driver pause API, broad game framework, repeated mode cases or new dependency.

Starting any delivered game clears previous driver input, presentation ownership, paused overlay, stale delta, pending legacy finale/music, and old view. Invalid014 also tears down the previous active game before cancellation; it cannot keep simulating or finish under an empty/wrong ID. Retry/practice reuse the same driver and native view. Pause/help/blur clear all command owners, block direct view GUI input using IGNORE, and preserve existing SubViewport final-frame/focus/discard-delta flows; resume restores PASS. Leave stops model advancement without a finished result. Finished emits once.

Native review found two actual integration overlaps, fixed after controller recorded scope rulings: the shared feedback popup at y130 covered the rowing instruments, and accessible shared HUD text at800px reached the first status row. Driver view already owns immediate normalized feedback below its controls, so only driver sessions suppress the duplicate shared popup. Shared title/objective/score/time/progress remain intact. Existing HUD header clearance math is exposed as gameplay_top without changing its body or legacy layout. Active driver layout keeps the existing centered uniform factor where room allows, moves its content below measured HUD clearance, and reduces the uniform factor only when remaining bottom space requires it. Both axes stay equal; pointer fallback uses the actual presentation affine inverse. No blind text reduction or view-specific physics change.

Album game definitions now always come from Catalog for the actual selected region, including setup called with a harbor array then switching back to welcome. This intentionally makes the legacy supplied definitions argument positional compatibility only. Catalog identity supplies local harbor1 normal/devil IDs; welcome keeps twelve games plus six non-game sources. Switching welcome time→harbor returns to normal category. Existing bounded thumbnail/original readers and generic legacy-image bounds are preserved. Quotas remain18/12 and counts use selected source region.

Stamps resolve ACH_GAME_013 by Catalog identity, never local list position. Explicit zone selects authoritative Catalog rows; omitted zone preserves supplied games and infers their zone for heading. Both full/compact headings are regional. Existing milestone data remains welcome-scoped where specified.

Self-review inspected staged changes; git diff --cached --check passed. Final focused logs have no ERROR/SCRIPT ERROR/WARNING, renderer/resource leak or orphan warning. No old game background overlays native rowing frames.

## Exact APIs and next-task contract

- Session.definitions(zone:String="welcome")->Array returns Catalog copies; zero arguments remains twelve welcome games, harbor has exactly013.
- Session.start(id:String,assisted_mode:bool=false)->void accepts delivered global ID or mode, including game-013/rowing_cargo; unknown014 emits cancelled after releasing prior ownership.
- Session.active_driver:RefCounted is null for legacy modes, otherwise owns the existing Task3 driver. `_driver_state:Dictionary` is its normalized snapshot. `_sync_driver_state(state:Dictionary)->void` copies only common elapsed/game_time/score/mistakes.
- Existing reset_round, set_paused(value:bool), set_practice_mode(value:bool), request_help, score_summary and finished/cancelled signals keep their signatures. Driver score_summary delegates practice eligibility text to the existing driver.
- MinigameHUD.gameplay_top()->float is the former private `_feedback_top`, with unchanged max(130,header-bottom+18) calculation; internal callers were renamed, no wrapper added.
- Album.setup(progress:Node,_definitions_source:Array,phases:Array,photo_loader:Callable,region:String="welcome")->void keeps its five positional parameters; the supplied game array no longer overrides the selected region's authoritative Catalog. Main may keep its existing call or pass regional rows. Actual selector owns regional changes.
- AchievementStampBook.setup(progress:Node,games:Array,zone:String="")->void preserves old two-argument callers. Task5 should pass world_region as third argument to choose the actual game's regional stamp page. Omitted zone infers from first supplied game; harbor rows still resolve013 correctly.

`finished(result:Dictionary)` fields remain game_id,success,devil,score,assisted,practice,mistakes,score_summary. Driver results additionally include ordinary_eligible = natural model eligibility AND not practice. Natural timeout has success=false,devil=false,ordinary_eligible=true; successful three-delivery route has score300,success=true and true real model devil when earned. Practice carries practice=true and ordinary_eligible=false. Legacy results omit ordinary_eligible, preserving the existing fallback meaning. Leave/unknown do not emit finished. Main/reward/photo/tutorial integration remains Task5; do not interpret ordinary eligibility as mission success.

## Focused checks and evidence

Pinned Windows engine C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe, 4.7.2.stable.official.ed1daf0bf. Every direct invocation used a separate absolute SNAPLAND_SAVE_PATH under C:/Users/stanl/AppData/Local/Temp/. No player profile used. Native renderer Vulkan1.4.359 Forward+, AMD Radeon RX9070XT.

Final results:

| Log | Result |
|---|---|
| task-4-baseline-minigames.log | PASS welcome84 cases before changes |
| task-4-baseline-ui.log | PASS existing collection/map/stamp/tutorial baseline |
| task-4-red-session.log | Expected missing definitions(zone) parse error before Session API integration |
| task-4-red-collection.log | Expected missing optional stamp zone parameter before UI integration |
| task-4-session.log | Rowing Session34 checks,0 failures |
| task-4-collection.log | Harbor collection22 checks,0 failures |
| task-4-native-session.log | Native Session51 checks,0 failures,1280 capture |
| task-4-native-session-800.log | Native Session51 checks,0 failures,800 capture with1.25 text/reduced motion |
| task-4-native-collection-1280.log | Native collection24 checks,0 failures |
| task-4-native-collection-800.log | Native collection24 checks,0 failures,1.25 text |
| task-4-regression-minigames.log | PASS welcome84 cases, old12/pause/practice/score/model outcomes |
| task-4-regression-ui.log | PASS collection/map/stamp/tutorial UI suite |
| task-4-regression-region-travel.log | PASS admission/lifecycle/scoped UI/restart/unchanged rewards |
| task-4-hud.log | PASS HUD/pause/results/invite/dialogue/photo frame/three sizes after gameplay_top rename |
| task-4-album-final.log | PASS actual thumbnail viewer/focus return/immutable progress after authoritative Catalog source change |
| task-4-originals-final.log | PASS bounded originals/shared metadata/safe viewer after Catalog source change |

Originals regression intentionally emits three warnings for huge dimensions/oversized bytes; no unexpected errors. Main-host UI/regional regressions retain pre-existing OcclusionController warnings. First region-travel attempt incorrectly used --script for a Node fixture (unresolved autoload identifier); corrected invocation uses its existing .tscn and final log passes. No production change was made for that invocation mistake.

Session focused suite runs a real three-cargo route through Session._unhandled_input key press/releases and Session._process, reusing the existing public navigator through a small test-only command adapter. It neither moves the boat directly nor writes score/end state. It validates actual three-delivery success/devil/300 score result, timeout qualification, practice denial, finish-once, retry/view reuse, pause/help/blur/leave, invalid times, stale-delta discard and driver→legacy→driver/unknown active reuse. Native cases additionally dispatch real engine GUI mouse events, verify IGNORE blocks paused input, verify retained final native render frame, and resize800x450/800x600/1280x720 while asserting equal scales, HUD clearance, GUI pointer alignment and Session fallback affine mapping.

Collection fixture awards013 through real isolated Progress and attaches actual320x180/960x540 PNG fixtures through attach_game_photo_frames. Images are flat-color test fixtures, not gameplay capture claims. Tests switch welcome→harbor→welcome, normal/devil/original viewer, missing frames, quotas, no postcard/extra6 leakage, unchanged records, global stamp identity, misleading ACH001 denial, explicit regional scope and welcome milestone numerator.

Repro command patterns from worktree:

```powershell
$env:SNAPLAND_SAVE_PATH='C:/Users/stanl/AppData/Local/Temp/snapland-task4-session.json'
& 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe' --headless --path . --script game/tests/test_rowing_session.gd
$env:SNAPLAND_SAVE_PATH='C:/Users/stanl/AppData/Local/Temp/snapland-task4-collection.json'
& 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe' --headless --path . --script game/tests/test_harbor_collection.gd
$env:SNAPLAND_SAVE_PATH='C:/Users/stanl/AppData/Local/Temp/snapland-task4-native-session-800.json'
$env:ROWING_SESSION_CAPTURE='C:/Users/stanl/Github/Snapland/.review/rowing-game-worktree/.superpowers/sdd/2026-11-13-rowing-cargo/task-4-session-800.png'
$env:ROWING_LARGE_TEXT='1'
& 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe' --path . --resolution 800x600 --script game/tests/test_rowing_session.gd
```

Native1280: use isolated native-session-1280.json, ROWING_SESSION_CAPTURE ending session-1280.png, ROWING_LARGE_TEXT=0, and --resolution 1280x720. Native collection uses the same pattern with HARBOR_COLLECTION_CAPTURE instead and its own native-collection-1280/800 profiles. Test scripts explicitly disable project canvas stretch to match real root coordinates, then use Session's own fit.

All final images were opened and visually inspected:
- task-4-session-1280.png — real Session shared HUD, native basin, controls and immediate feedback with no old backdrop/popup overlap.
- task-4-session-800.png —1.25 text/reduced motion, measured top clearance and complete controls/instruments.
- task-4-collection-1280.png / task-4-collection-800.png — authoritative harbor row/local quotas/actual bounded PNG thumbnail fixture.
- task-4-collection-1280-stamps.png / task-4-collection-800-stamps.png — global13 stamp and regional title at standard/enlarged text.

## Limits and next gate

No full broad suite, Linux duplicate, packaged export,1920 native Session capture, OS-level physical keyboard playthrough, human playtest or listening was performed. Native GUI events are engine-dispatched synthetic input; full route keys call Session's public event path. Main/world/tutorial/reward/card-save-failure/player screenshot flow/CI registration remain Task5, and supplied album game definitions now intentionally cannot override Catalog. Controller's design/plan edits and generated metadata remain unstaged. No unresolved issue in owned implementation is known.
