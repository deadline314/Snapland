### Spec Compliance

- ❌ Issues found: the explicit successful-story-event-once constraint is not enforced on attachment retry (`game/main.gd:1470`, `game/main.gd:1500`). Other inspected Task 5 requirements match the brief.
- ⚠️ Full four-shard CI, externally bootstrapped packed PCK, Windows executable provenance, and final human/native acceptance remain controller gates. Source logs and screenshots are evidence for the recorded source runs, not those release gates.

### Strengths

- Catalog lookup reaches delivered global013 while default welcome definitions remain twelve; harbor interaction and the regional map action open the existing invitation without a teleport (`game/main.gd:1255`, `game/main.gd:1346`, `game/main.gd:1791`; `game/world/harbor_world.gd:62`). No map framework, dependency, export configuration, or unsupported014 implementation was added.
- Ordinary eligibility, genuine success, practice, devil qualification, saved reward claims, and photo attachment are separately gated. Timeout keeps the failure heading while earning its eligible ordinary card; completion failure cannot claim a saved card (`game/main.gd:1450`, `game/main.gd:1461`, `game/main.gd:1482`, `game/main.gd:1555`).
- Native evidence plans using public model commands and replays Session input/step events. The emitted actual result is compared against the actual driver snapshot and delivery ledger independently; six synthetic welcome cards are explicitly labeled (`game/tests/native_rowing_main.gd:55`, `game/tests/native_rowing_main.gd:149`, `game/tests/native_rowing_main.gd:156`, `game/tests/native_rowing_main.gd:166`; `game/tests/rowing_input_route.gd:25`). No earned-result path in this diff writes boat, score, completion, or result state.
- Native fixture loads its explicitly adjacent helper with no excluded-test fallback; screenshots check actual dimensions and PNG write status (`game/tests/native_rowing_main.gd:4`, `game/tests/native_rowing_main.gd:237`). Practice/cancel/pause/help and map non-teleport checks use the real Main/Session routes (`game/tests/native_rowing_main.gd:136`, `game/tests/native_rowing_main.gd:196`).
- All required listed production/test/data files have corresponding changes. Three actual tutorial PNGs add013 to the existing schema and ordered required lessons; the design row retains truthful acceptance-pending status while014+ remain design only (`game/data/tutorials.json:465`, `game/ui/tutorial_catalog.gd:7`, `design/02-minigames/catalog.json:339`, `tools/verify_design.py:92`).
- Nine registrations are added to the sole runner with exact markers and valid script/scene entrypoints; no existing registration is removed. Existing stable sharding, 90-second defaults, and per-suite profile directories apply automatically (`tools/run_game_tests.py:24`, `tools/run_game_tests.py:162`, `tools/run_game_tests.py:182`, `tools/run_game_tests.py:310`, `tools/run_game_tests.py:383`).

### Issues

#### Critical (Must Fix)

- None.

#### Important (Should Fix)

- `game/main.gd:1470`, `game/main.gd:1500`: a successful run whose reward saves but whose photo attachment fails dispatches `_record_story_mission_event` on the original result, then dispatches it again whenever “重試保存” re-enters `_game_finished` and `complete_game` returns its idempotent true. This breaks the supplied event-once constraint and makes photo repair replay a gameplay completion side effect. Current quest cursors reject already completed steps and guard the story photo, so this review does **not** claim duplicate coins or an observed duplicate quest reward. Preserve per-result notification state across retry, or restrict retry to the unfinished persistence work. Add one focused successful-result attachment-failure/retry check asserting a single story dispatch; the current failure child only finishes a timeout (`game/tests/test_rowing_main.gd:138`) and therefore cannot exercise this branch.

#### Minor (Nice to Have)

- `.superpowers/sdd/2026-11-13-rowing-cargo/task-5-focused.log:16`: the superseded failing Main run contains unsupported ShaderMaterial/OcclusionController warnings (also lines28,40,52,64,76). The report identifies them as inherited welcome-world noise; they are not a new rowing defect or an acceptance blocker. Final runner summaries suppress successful child output, so they do not independently prove warning-free Main output. Native final evidence reviewed here is clean.

### Checks and Limits

- Read the supplied 1,740-line review package exactly once in four bounded, nonoverlapping chunks (1–510,511–960,961–1410,1411–1740); no git commands, implementation edits, subagents, rerenders, or test reruns.
- Named risk: retry callbacks and retained shared photo state. Focused unchanged-code check of `_launch_game`, `_cancel_game`, `_append_photo_snapshot`, both photo writers and `_open`/`_close`: a new session clears retained images, retry without a live Session cannot capture result UI, and partial writes can regenerate the retained gameplay buffers (`game/main.gd:1404`, `game/main.gd:1434`, `game/main.gd:1945`, `game/main.gd:1958`, `game/main.gd:2178`). Bounds remain the existing four-megapixel writer/preparation rules (`game/main.gd:1971`, `game/main.gd:2198`).
- Named risk: retry money/story effects. Focused unchanged-code check of `Progress.complete_game` and `attach_game_photo_frames` confirms receipt/idempotency and rollback, while `_record_story_mission_event` and `Story.mission_event_result` prevent duplicate existing completed mission rewards (`game/core/progress.gd:167`, `game/core/progress.gd:230`, `game/main.gd:1650`, `game/story/story_director.gd:297`). This mitigates effects but does not eliminate the duplicate dispatch finding.
- Named risk: generalized attachment eligibility and old API callers. Focused caller search found the single production signal connection and existing Main thumbnail/original fixtures; the one-result signal interface, legacy success fallback, and welcome compatibility wrapper remain valid (`game/main.gd:1421`, `game/main.gd:1555`, `game/core/progress.gd:225`; `game/tests/test_main_photo_thumbnails.gd:30`, `game/tests/test_photo_originals.gd:48`). No broader code crawl.
- Reviewed final saved evidence: registration final import/Main/preflight PASS; Python87 tests OK; five design scopes PASS; native View32/0 with eight lifecycle cycles nodes4→4/resources26→26; final800 normal actual three-delivery ledger and300/devil; final1920 natural timeout success=false/ordinary=true/score0; independent saved reader; exposed gap crossing. Also read normal1280 and assisted1280 logs. No duplicate suite run was needed to assess this diff.
- Visually inspected all three committed1280×720 tutorial PNGs and final800 result/map plus final1920 timeout result: real gameplay originals appear in result thumbnails; ordinary timeout and failure coexist truthfully; the regional map invitation action is visible. No rerender performed.
- Earlier focused Main failure is explicitly superseded by the final registration log. Normal/assisted1280 logs predate the final independent-ledger diagnostic; final800 supplies that diagnostic for the final source. Packed/executable evidence and human listening/playtest were not inspected or claimed.

### Assessment

**Task quality:** Needs fixes.

**Reasoning:** The implementation is narrowly scoped and has substantial genuine input-driven source evidence, transactional reward handling, and clean registration integration. One small retry-state fix is needed to honor the explicit single successful story dispatch contract; current persistence idempotency prevents a duplicate-money finding.

Skipped repeated tests, full CI, packed/export execution, and human playtest; those remain controller acceptance risks.
