# Task 5 — Main entry, truthful saved rewards, tutorials and verification

Status: DONE in assigned implementation scope; controller final acceptance/publication remains open. Commit: **da505379446ea38e61172b40445a65aac770c565** (`feat(rowing): finish harbor entry, saved rewards and tutorials`),24 owned source/data/test/real-asset files. Base supplied: d6ca67e35e0fb26e431238192a253fb8f546c77b. Author and committer stanley890314@gmail.com. No branch switch, push, delegation, export configuration change, dependency or unrelated refactor.

## Scope and interfaces

Read task-5-brief.md, binding design/runtime/rowing-cargo.md, Task4 exact APIs/evidence, Task1 Progress signatures, root AGENTS.md, relevant Main/HarborWorld/tutorial/validator/runner and fixtures. Confirmed actual HarborWorld path **game/world/harbor_world.gd** before editing. Did not read entire plan/history.

Main keeps `definitions=Session.definitions()` (zero arguments: twelve welcome games), while `_definition(id:String)->Dictionary` now uses `Catalog.find(id)` for all thirteen delivered records;014 remains refused. HarborWorld replaces its former game-preparation interaction at(12,0.2,0) with real `game-013` kiosk, simple actual cabinet/canopy, specific sign and an honest remaining-eleven preparation sign. Its map snapshot naturally includes the real kiosk. Existing free ferry, tides, land, bounds and reentry contracts remain. Main harbor interactions open the normal invite. No harbor story, quest, exploration card or other game was invented.

Main harbor map preserves the read-only HarborMapPanel and its snapshot/legend. A regional Catalog-derived `HarborGamegame-013` Paper button in existing modal_footer opens `_show_game_info("game-013")`; it never relocates the player. No map-panel implementation edit or new map framework. Regional stamp setup is `stamp_book.setup(Progress,Catalog.definitions(world_region),world_region)`; regional guide/stamp headings reflect harbor. Album already uses Task4's authoritative regional Catalog.

`_game_finished(result:Dictionary,saved_frames:Array[String]=[],saved_original_frames:Array[String]=[])->void` preserves the existing one-result signal/call interface. Optional image arrays support retry of the **same** genuine result. `ordinary_eligible` falls back to old `success`, and practice always denies eligibility. Eligible natural timeout captures/awards ordinary while retaining false success/miss sound/failure heading and no successful mission event. Devil is accepted only with actual success. Story mission event and celebration require true non-practice success and a successfully saved reward; ordinary eligibility alone never substitutes for success. Original12 behavior retains its fallback.

Main consumes `Progress.complete_game(...)->bool`. Only true return shows saved card claims. Failed reward rolls back in Progress and Main presents explicit unsaved status plus `RetryGameSave`/重試保存. Generic `_sync_finished_photo_thumbnails` now calls `attach_game_photo_frames`; it checks eligibility/practice, and cannot attach a devil for false success. Attachment/file write failure is displayed separately, with the same retry action. Partial thumbnail/original writes compare actual retained image counts; retries regenerate missing files from retained gameplay images. With no live Session, retry does not photograph the result UI. Existing bounded originals and welcome wrapper remain intact.

Added `game-013` to existing tutorial schema/required lesson list: three steps, actual native1280x720 PNGs. Lessons total14 (park+13); screenshots/steps42. First entry, rules lesson, practice and session help retain existing Main tutorial flow; ordinary natural-end vs true success, W/S/A/D/Q/E/space, speed/angle, long/short passage, wave crest, assist/devil and no-award practice/cancel are explicit. Design catalog row013 is `single_player_runtime_needs_full_acceptance`/`rowing_cargo`;014+ retain design-only status. Python alignment now reads both actual welcome/harbor JSON, checks welcome canonical twelve and harbor exactly013/local1, and compares only delivered rows. Existing unbuilt sentinel changed from013 to014 only where concretely necessary.

## Test helper and native fixture contract

Extracted the existing fixed public navigator and Session command adapter into narrow test-only **game/tests/rowing_input_route.gd**; existing model, driver and Session tests now use it. No production automation hook. Model arranged-state tests remain labelled unit fixtures; native code never writes boat position, score, completion flags or manufactured result dictionaries.

Helper public classes/functions:
- `SessionCommands.new(session:Control)`: snapshot, key/tap, paddle, sideslip, interact, digital set_rudder/clear_input and step. Key press/releases go through Session._unhandled_input; step calls its existing `_process` with auto processing disabled.
- `RecordingCommands.new(assisted:bool,delta:float=0.025)`: a fresh production Model driven exclusively through public commands records the fixed event list and planner snapshot. No model-state assignments. `solve`, `navigate` and `steer` are the extracted existing feedback algorithm.
- Native fixture plans through this helper, then replays each recorded press/release and model-step event through the real Main-created Session, allowing one real rendered frame after every8fixed steps. Session starts with a few natural presentation frames, so actual ledger timestamps/angles can differ slightly from planner output; actual emitted result and model ledger are independently checked. This is accelerated automated input, not human play or hardware keyboard timing.

Source fixture: `game/tests/native_rowing_main.tscn` (Node script `native_rowing_main.gd`). Root/viewport stretch disabled to match actual requested window pixels. Every image asserts actual viewport dimensions and PNG save OK. Native wall guard180seconds; launcher calls below also had explicit external timeout180seconds. Fixture provides actual rules/tutorial practice, pause/rudder release/help/close/resume stale-delta discard/leave-confirm, first normal lesson start, real success or physical timeout, saved photo/original, actual40coin receipt, album/stamps/map, invitation without teleport, successful replay with no duplicate reward and actual writer. No game013 reward is seeded: fresh setup explicitly prints **six synthetic welcome eligibility cards**, then earns013.

Environment (all paths absolute/private):
- `SNAPLAND_SAVE_PATH`: actual profile writer/reader.
- `ROWING_CAPTURE_DIR`: required output directory; captures tutorial, step-01/02/03, album, stamps, map (read/gap modes have their own captures).
- `ROWING_REVIEW_MODE`: empty/normal, assisted, timeout, read, gap. `read` never resets the supplied profile; checks actual saved harbor startup/card/receipt/ACH/tutorial and real PNG originals. `gap` drives a private tutorial practice across(-4,0)->(4,0), captures near/far tide geometry, then verifies pause/help/resume/cancel and no award.
- `ROWING_LARGE_TEXT=1`: ui_scale1.25 and reduced motion.
- `ROWING_STEP`: optional fixed command cadence, default0.025; bounded1/120..0.05. Controller already verified independent Session30/60Hz paths; no duplicate physics-only repeat here.
- `ROWING_TUTORIAL_DIR`: optional absolute directory for initial real lesson asset capture; this explicitly labelled asset-bootstrap route marks the valid tutorial ID and launches actual gameplay. Ordinary source review leaves it empty and exercises the real unseen lesson/UI route. Final committed PNGs come from genuine assisted1280 gameplay/crest dock/Main result.

**External PCK/exe contract:** release excludes all game/tests. Explicitly copy **native_rowing_main.gd and rowing_input_route.gd adjacent to each other** beside a controller-owned external SceneTree bootstrap. Bootstrap loads Node script by absolute path and adds `.new()` to root; source .tscn is unnecessary externally. Native script loads exactly its adjacent helper using `get_script().resource_path.get_base_dir().path_join("rowing_input_route.gd")`; there is **no res://game/tests fallback**. Helper only preloads production `res://game/minigames/rowing_cargo_model.gd`. Main scene, data, production drivers and assets resolve from pack via production res paths. External bootstrap/pack invocation and release provenance are controller's next gate, not claimed here.

Native completion markers:
- normal/assisted/timeout: `PASS: native rowing Main actual controls, truthful result, real photos, replay and restart`
- read: `PASS: native rowing saved harbor restart, earned card and original PNG`
- gap: `PASS: native rowing exposed tide-gap public-input crossing`
- CI headless `-- --rowing-preflight`: `PASS: rowing native fixture adjacent helper and three real tutorial PNGs` (does not claim GPU play).

## Verification and evidence

Pinned Windows engine C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe,4.7.2.stable.official.ed1daf0bf; native Vulkan1.4.359 Forward+,AMD Radeon RX9070XT. Every Godot invocation used separate absolute SNAPLAND_SAVE_PATH; no real player profile. Python runner creates a separate absolute directory for each suite and children inherit or explicitly isolate further.

Logs/evidence root: **C:/Users/stanl/Github/Snapland/.review/rowing-game-worktree/.superpowers/sdd/2026-11-13-rowing-cargo/**.

- task-5-baseline.log: pre-edit import, region travel, tutorial panel/catalog, Main story, shared photo thumbnails, island game entry all PASS.
- task-5-red-main.log: expected Main global013 lookup failure before integration. Initial fixture authoring had a wrong count API parse attempt, corrected before meaningful red. Early native fixture had a Vector2i/Vector2 comparison parse error, fixed; those attempts are not acceptance evidence.
- task-5-focused.log:15 affected suites PASS: harborworld7017, regiontravel, Session34, tutorial panel/catalog, tutorial seen/failure, tutorial image/assets, Main story, shared thumbnails, bounded originals, old12 entry, Main scene integration, pixel collection/map/stamp/tutorial, tutorial42step paged3size/1.25, HUD/invite/results3size. Main initially failed its newly authored child-diagnostic check; final below supersedes that one failure.
- task-5-registered.log: Catalog, atomic harbor Progress, model58, driver39, view32, Session34, harbor collection22 all PASS through the sole runner. It exposed the same test-only child teardown failure; no production reward defect was hidden.
- task-5-registration-final.log: final runner import + rowing Main (10.97s) + native fixture preflight PASS. Failed-save child now uses exact three expected diagnostics only: two writes to its exact isolated profile.tmp plus one exact harbor thumbnail-save error. It tests actual natural timeout, complete rollback/no saved claim, retry saves once, then actual-result attachment with an explicitly synthetic PNG fixture, attachment rollback/no saved-photo claim, and attachment retry/no duplicate money. Raw child output is preserved in each private profile's failure-output.log. Child audio shutdown must wait0.15s **before** node free, then12frames, matching established test teardown; this removed actual headless leaked-resource diagnostics. Joining child output strings preserves real paths rather than escaped Array rendering.
- task-5-model.log / driver.log / view.log:58/39/32 checks,0failures after narrow helper extraction. No repeated broad suite.
- task-5-python-final.log:87 affected Python tests PASS (design validation, runner exact completion, shard partition and entrypoint/deadline/isolation contracts).
- task-5-design-final.log: all five design scopes PASS; explicitly not gameplay/playtest acceptance.

Native source evidence (each log ends exact marker, no ERROR/SCRIPT ERROR/resource leak):
- task-5-native-lifecycle.log: existing native View unit suite32checks/0failures, eight create/free cycles: nodes4->4 and resources26->26. Its labelled view synchronization fixtures arrange view snapshots; they are not earned gameplay/reward evidence.
- task-5-native-real.log / native-real/: normal1280x720 genuine300/three deliveries/devil,40coins once, gameplay originals and full replay.
- task-5-native-assisted.log / native-assisted/: independent assisted1280x720 genuine300/three deliveries/devil and metadata; final real lesson PNG capture.
- task-5-native-800-final.log / native-800-final/: final800x600,1.25text/reducedmotion. Real visible tutorial buttons are selected from active tutorial panel (not hidden rules controls). Practice/pause/help/resume/cancel; first-entry lesson, genuine standard300/devil, actual model ledger3distinct deliveries to docks1,2,1,0crateimpacts/0walls; actual Main result, originals, regional album/stamps/map and replay. Dock capture now uses actual dock radius, not an x>dock-center threshold that omitted a valid near-side approach. Assert requires actual docking gameplay screenshot. Native800 screenshot set visually inspected: complete HUD, controls, lesson, result and regional map action; no overlap in new content.
- task-5-native-timeout-final.log / native-timeout-final/:1920x1080 ui1.25/reducedmotion, actual natural zero-delivery timeout: success=false,ordinary_eligible=true,devil=false,score0; ordinary saved, failure heading retained, no successful mission; practice/cancel no new reward, real originals. Visually inspected failure+ordinary coexist truthfully.
- task-5-native-read-final.log / native-read-final/: separate process reader loads the actual assisted saved file and original PNG; no reset/reseeding.
- task-5-native-gap-final.log / native-gap-final/: actual exposed near(-4.421156,-0.030049)->far(3.589994,0.146904), elapsed12.869908, current gap half-width0.4632496,0walls; actual near/far screenshots plus pause/help/resume/cancel, no practice reward. Route crosses while evolving actual tide permits it, not a seeded gap state.

Actual writer archives copied byte-for-byte with photos under `task-5-actual-profiles/{normal,assisted,timeout-1920}`. Original saved absolute image paths remain unchanged and still refer to the original private Temp folders `snapland-task5-native-real`, `snapland-task5-native-assisted`, `snapland-task5-native-timeout`; do not rewrite the archive and call it the original writer. The final800 writer is directly inside `native-800-profile/profile.json`, so its actual file and originals already reside in the evidence root.

Committed tutorial assets (all opened/visually inspected, actual1280x720 PNG):
- assets/ui/tutorials/game-013-step-01.png — real empty boat and separate waiting cargo; SHA2563312d946fa6ecf446e40ae4b3b3eef5537625f7499694dadd75ea09775220bb4.
- game-013-step-02.png — actual first loaded cargo at crest, near dock1 with low speed/aligned angle; SHA2565f7e624173010c9f11549977a285c8ffe75e2c7e530bd6bfb51388c92ef56728.
- game-013-step-03.png — actual assisted300 Main saved ordinary/devil result; SHA25648052142eea490e7ef47125d37c48e8632d21a3f58035ca2514bdc85dd12cb4f.

## Sole runner registrations

All nine new suites have exact completion comparisons, valid entrypoints, default90second per-suite limit, isolated directories and automatic stable four-shard membership. Existing106 runtime suites retained; total115. No old suite was skipped or removed.

| Label | Entry under res://game/tests/ | Exact marker |
|---|---|---|
| delivered game catalog tests | --script test_game_catalog.gd | PASS: delivered game catalog, copies, regional identity and malformed data |
| harbor game progress tests | --script test_harbor_game_progress.gd | PASS: harbor rewards, replay, legacy, captures, reload and atomic failure |
| rowing cargo model tests | --script test_rowing_cargo.gd | Rowing cargo: 58 checks, 0 failures |
| rowing cargo driver tests | --script test_rowing_cargo_driver.gd | Rowing driver: 39 checks, 0 failures |
| rowing cargo view tests | --script test_rowing_cargo_view.gd | Rowing view: 32 checks, 0 failures |
| rowing Session tests | --script test_rowing_session.gd | Rowing Session: 34 checks, 0 failures |
| harbor collection tests | --script test_harbor_collection.gd | Harbor collection: 22 checks, 0 failures |
| rowing Main tests | test_rowing_main.tscn | PASS: rowing Main entry, regional map, tutorial, truthful timeout, practice, assisted reward and reload |
| rowing native fixture tests | native_rowing_main.tscn -- --rowing-preflight | PASS: rowing native fixture adjacent helper and three real tutorial PNGs |

Existing tutorial page marker updates39->42steps, tutorial catalog fixtures13->14lessons; actual harbor-world fixture permits only newly delivered013 among game IDs and its exact7017 completion remains unchanged. Python tests reject decorated/partial new markers and unbuilt014/alignment drift. No .tscn used as --script; Node fixtures use scenes and SceneTree fixtures use --script.

Reproduce from worktree PowerShell (set fresh private profile/capture directory for each invocation):
```powershell
$env:GODOT_BIN='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
python tools/run_game_tests.py --only 'rowing' --only 'delivered game catalog' --only 'harbor game progress' --only 'harbor collection'
python -m unittest tests.test_design_validation tests.test_runtime_result_contract tests.test_runtime_shards tests.test_godot_entrypoints -v
python tools/verify_design.py --scope all
$env:SNAPLAND_SAVE_PATH='C:/absolute/private/native/profile.json'
$env:ROWING_CAPTURE_DIR='C:/absolute/private/native/captures'
$env:ROWING_REVIEW_MODE='assisted' # or timeout/read/gap; read uses a genuinely written profile
$env:ROWING_LARGE_TEXT='0'
$env:ROWING_TUTORIAL_DIR=''
& $env:GODOT_BIN --path . --resolution 1280x720 game/tests/native_rowing_main.tscn
```

## Self-review, limits and controller handoff

Owned diff reviewed for Catalog reach, legacy fallback, transactional saved status, no practice/cancel/story false positives, photo retry and missing file handling, region-specific collection/stamps/map, exact runner/shard contracts, actual PNG provenance and excluded-test dependencies. Focused source diff check and staged `git diff --cached --check` passed; verified exact24file stage, no.import/.uid and correct author/committer after commit. Stage only these source/data/tests/assets; no generated.import/.uid files. Shared existing generated metadata is left untouched/unstaged for controller cleanup.

Pre-existing unsupported ShaderMaterial/OcclusionController warnings remain in welcome-world Main baselines/regressions; atomic image tests retain their deliberate malformed-image warnings. Final native modes have no unexpected warnings/errors. No native score, boat position or ending mutation and no artificial reward013 seeding.

Skipped full broad CI, Linux duplication of already approved core, packed PCK/Windows executable external bootstrap, listening/human playtest and publication/ticket closure. Controller owns final evidence review/three-size and release provenance gates, whole four-shard CI, ticket/docs/main publication and cleanup. Current source has thirteen delivered games, not the whole planned game. Actual profile/image archives retain original absolute paths as noted.


## Fix round 1 — per-outcome successful story dispatch

FIX_BASE da505379446ea38e61172b40445a65aac770c565. Fix commit: **83c88b39ba970e5a3ed9b37a8cd8e937ef0c7aee** (`fix(rowing): dispatch story once across photo save retries`). Owned scope only game/main.gd and game/tests/test_rowing_main.gd; no schema, mode case, new fixture file, native matrix, dependency, docs or generated metadata staged.

Reviewer finding (Important), verbatim:
> game/main.gd:1470, game/main.gd:1500: a successful run whose reward saves but whose photo attachment fails dispatches _record_story_mission_event on the original result, then dispatches it again whenever “重試保存” re-enters _game_finished and complete_game returns its idempotent true. This breaks the supplied event-once constraint and makes photo repair replay a gameplay completion side effect. Current quest cursors reject already completed steps and guard the story photo, so this review does not claim duplicate coins or an observed duplicate quest reward. Preserve per-result notification state across retry, or restrict retry to the unfinished persistence work. Add one focused successful-result attachment-failure/retry check asserting a single story dispatch; the current failure child only finishes a timeout (game/tests/test_rowing_main.gd:138) and therefore cannot exercise this branch.

Shared fix: `_game_finished(...,story_notified:bool=false)` adds one optional in-memory outcome flag. On the first successfully saved true success, it sets the flag before dispatch; the same result's retry button carries that flag. Photo repair therefore cannot redispatch story success. Failed reward saves retain false until successful retry. Separate genuine replay uses the existing one-result signal/default false and dispatches its own event. Incoming result Dictionary stays immutable. No saved fields/global game-ID deduplication or special rowing branch. Existing one-argument callers and first three arguments remain compatible.

Focused regression extends the existing failure child with a test-only ObservedMain subclass that counts minigame-result dispatches and still calls the real parent story handler. The real Main scene is a single Node with that script, so inherited construction preserves its actual setup. It earns true assisted success through the existing Session key adapter/solver, retains the exact unmodified emitted result, then exercises: failed reward save => zero events; reward saved followed by attachment failure => one event; another failed photo repair => still one; successful photo repair => still one; a genuinely separate real successful Session replay => two total. Existing timeout/practice/cancel/atomic receipt/photo checks remain; coins stay exactly one 40-coin receipt. The labelled synthetic PNG is only an attachment fixture, not a native gameplay claim.

Red evidence: `task-5-fix-1-red.log`, isolated actual save in `fix-1-red-profile/profile.json`, original production code exited1. Expected new assertion failures were precisely repeated failed photo repair, successful photo repair and separate replay event count; existing actual-success/reward-failure checks passed. Deliberate failed-save diagnostics remain visible in this raw child log.

Green command, worktree root:
```powershell
$env:GODOT_BIN='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
python tools/run_game_tests.py --keep-going --only 'rowing Main' --only 'main story integration' --only 'shared photo thumbnail'
```
`task-5-fix-1-green.log`: clean import PASS5.19s; rowing Main PASS12.36s; Main story integration PASS25.70s; shared photo thumbnail PASS2.90s; runner exit0. Runner creates separate absolute private profiles, and failure child uses its own subdirectory. Exact outer completion markers unchanged. Extended child contract captures exactly eight intended diagnostics: five exact isolated temporary-save errors and three exact harbor attachment-save errors, no hidden script/parse/resource leak errors. Existing welcome OcclusionController warnings remain as previously recorded. No native repeat was needed for this retry-state-only fix.

Self-review: searched all Main completion/story/attachment callers; verified shared per-outcome flag, immutable result, no suppression of separate replays, zero dispatch before successful reward persistence, and no new ordinary/practice/cancel eligibility. `git diff --check` passed for owned paths; staged check and author/committer verified at commit. Parent will recheck amended Main on pinned Linux and run FIX_BASE..HEAD re-review. Full CI/release/publication remains controller-owned.
