# Task 3 — rowing view and small driver

Status: DONE (isolated driver/view scope; Session integration remains Task 4).

Commit: `05efea5cb8870ae1aa05269be5ff828f3684c81b` — feat(rowing): add native cargo view and digital driver. Author and committer: Stanley Li <stanley890314@gmail.com>. Only the six owned source/test files were committed; this report/images/logs are ignored local handoff evidence.

## Scope and review

Read binding design/runtime/rowing-cargo.md, Task 3 brief, Task 2 report, root AGENTS, nearest SignBalance native SubViewport and focused test pattern, shared Paper/FontProfiles, and Session layout/input/summary conventions. No entire implementation plan was read. No branch switch, push, dependency, world duplication, native avatar artwork manipulation, Session/Main change, generated uid/import staging, or other agent's edit was made.

Originally owned four new driver/view/test files. The first native image revealed a concrete model/view contract defect: the initial empty hull and waiting crate-1 had exactly the same center. Controller recorded the expansion before changes: only Model.START moved from (-8,-3) to (-8.9,-3); cargo anchors, 0.32 radii, 1.05 pickup reach, every tolerance and physical rule stay unchanged. Added a red initial separation/reach assertion. Its focused run failed before the constant change as expected. Updating START exposed one affected arranged wall-recovery fixture: it previously navigated START assuming that was the crate. After controller approval it navigates CARGO_STARTS[0] instead, through the existing public navigator. No solver or production rule adjustment.

Six owned staged files:
- game/minigames/rowing_cargo_driver.gd
- game/minigames/rowing_cargo_view.gd
- game/tests/test_rowing_cargo_driver.gd
- game/tests/test_rowing_cargo_view.gd
- game/minigames/rowing_cargo_model.gd (START only)
- game/tests/test_rowing_cargo.gd (initial separation check and affected pickup target)

Self-review: complete staged source/tests inspected; git diff --cached --check passes. Fixed early snapshot ordering (view may enter tree before its first snapshot), touch-emulated mouse duplicate ownership, focus-loss keyboard ownership, initial hull/cargo overlap, physical phase units in decorative wave offset, and player-facing canonical cargo ID exposure. Final focused/native logs contain no ERROR, SCRIPT ERROR, WARNING, parse failure, orphan/resource warning, or failed check.

## Exact API and caller ownership

Driver is RefCounted and owns one Model plus at most one optional Control view:
- reset(assisted:bool,time_phase:String)->void clears all owners, resets model, refreshes current presentation.
- create_view()->Control returns null under headless, otherwise creates once and reuses the same valid view. Its first snapshot is already supplied; caller adds it to the tree and owns its scene-tree lifetime.
- handle_input(event:InputEvent,design_point:Vector2)->bool consumes recognized non-echo digital key press/releases and pointer button events. The point is already in the 1280x720 design plane. No analog control exists.
- clear_input()->void clears keyboard/pointer owners and model rudder, preserves real inertia.
- step(delta:float)->Dictionary calls only Model.step then returns normalized snapshot. No process callback, timer or second simulation exists.
- snapshot()->Dictionary retains every model field and adds progress_text/time_text/feedback_text. It returns elapsed,score,mistakes,ended,success,devil,ordinary_eligible directly from real model state. feedback_text translates canonical crate IDs to Chinese cargo numbers for display; raw model identifiers remain intact.
- present(time_phase:String,reduced_motion:bool)->void supplies read-only current snapshot to optional view, never steps the model.
- score_summary(practice:bool)->Dictionary uses existing total,label,rule,rows,qualification_text. Deliveries are real ledger count/score; crate impacts and wall collisions are separate zero-point progress rows. Practice explicitly has no card qualification. Normal natural timeout retains ordinary eligibility, and assistance does not suppress devil.

Session must call clear_input on pause/tutorial/focus loss/leave, stop calling handle_input and step while paused, and disable direct view pointer input with mouse_filter=IGNORE while paused/tutorial/result overlays own input (restore PASS for play). Merely stopping driver.step does not disable view._gui_input. Session must use its existing uniform centered DESIGN_SIZE fit, place presentation before shared HUD sibling, and call present when state/time phase/reduced motion changes. View does not draw in the shared top HUD region (status starts y140, 3D stage y208). This is the same low-overhead rendering ownership as existing native views. View tree_exiting and window-focus-out automatically release driver ownership as additional safeguards.

## Bounded command signal and digital parity

View signal: command_requested(command:String,pressed:bool,source:String).

Commands: left/right/stroke/reverse/slip_left/slip_right/interact, plus only the lifecycle sentinel clear,false,lifecycle. Pointer sources are mouse and touch:<index>. Driver keyboard sources are key:<physical-or-logical-keycode>. GUI view press/release and driver's design-point pointer forwarding use the same source token and view pointer registry, so duplicate propagation cannot apply a command twice. Touch-generated emulated mouse events are rejected.

W/Up = discrete forward stroke; S/Down = discrete reverse stroke; A/Left and D/Right = held digital rudder; Q/E = discrete -/+ sideslip; Space = interact. Every recognized release is consumed; keyboard echo rejected. Left and right owner presence cancel, and releasing either restores any remaining opposite owner. Key aliases remain independent. Pointer release outside its button releases its original owner. Multiple touch owners remain distinct. clear_input removes owners across both registries. These commands are identical digital Model calls, with the model's own cooldowns; held stroke does not auto-repeat.

## Snapshot to native scene mapping

One SubViewportContainer / independent World3D / fixed orthographic Camera3D, UPDATE_WHEN_VISIBLE, GUI-disabled embedded viewport. Camera is 23 degrees above horizontal; fixed basin remains fully visible. Existing Paper palette/font patterns, no external resource dependency.

Model Vector2(x,y) maps to world(X,Z), boat yaw=-heading. Boat is a pointed extruded hull with deck/bow/gunwales/oars and a whole primitive seated crew (body/head/hat/two arms/two legs). Physical hull remains Model.BOAT_RADIUS; visual bow/stern and extended oars are presentation geometry. No avatar image is split or stretched. Stroke cooldown from Model.PADDLE_COOLDOWN drives oars/arms; after a stroke's cooldown they return idle, with no independent clock. Sideslip uses actual model movement/heading/feedback, not a second motion simulation.

Three stable cargo nodes retain IDs/destination labels. Waiting/delivered positions map directly from snapshot. Carried cargo uses a small stern mount offset (-0.3 along forward, y0.3, 0.65 visual scale) to show it stowed separately from crew; its rule position remains the model boat center. Dock roots use exact snapshot position; deck sits just behind the docking center as a visual loading edge, with plank seams/mooring posts and numbered signs. Dynamic breakwater meshes match snapshot Rect2 spans, including real tide gap. Shelter water uses snapshot shelter region, and the always-open long route is visibly dashed. Model remains the collision authority.

Wave crest geometry size, forecast text, tide/clearance, signed force arrow, heading and docking speed/parallel angle remain visible under reduced motion and without audio. Optional small wave lateral sway is the only reduced decoration. Fixed labeled wave-force instrument represents actual local water.force sign/strength without overlapping cargo labels. Real sun color/direction/energy refresh on dawn/noon/dusk/night. Material/mesh/node allocations occur at construction, not during present. Player text shows 第1箱 → 碼頭1 rather than crate-1.

## Focused checks and native evidence

Pinned Windows engine: C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe (4.7.2.stable.official.ed1daf0bf). Every direct call set an isolated absolute SNAPLAND_SAVE_PATH under C:/Users/stanl/AppData/Local/Temp/. No player save was used. Native renderer: Vulkan1.4.359 Forward+, AMD Radeon RX9070XT.

Results:
- task-3-red.log: before implementation, expected missing driver/view preload failure.
- task-3-start-red.log: 58 model checks, 1 expected failure for overlapping initial empty hull/cargo, before START edit.
- task-3-model.log: 58 checks, 0 failures, including normal/assisted/shifted real public digital routes and recovered crate/wall impact routes after START correction.
- task-3-driver.log: headless driver39 checks, 0 failures. Headless create_view is null; actual pickup/reverse/slip/stroke, release/echo/aliases/opposition/mixed ownership, invalid time, normalized timeout, truthful summary/practice, snapshot-only repeated present, actual assisted solver devil verified.
- task-3-view.log: headless direct view32 checks, 0 failures. Test explicitly creates the optional view to inspect scene structure; the production headless driver still creates none.
- task-3-native-driver.log: native driver42 checks, 0 failures; adds view reuse, view signal ownership, focus-loss keyboard/pointer release and tree-exit cleanup.
- task-3-native.log: native1280x720 view34 checks, 0 failures, captures saved, no engine errors.
- task-3-native-800.log: native800x600 view34 checks, 0 failures with1.25 text, including reduced-motion crest capture; no engine errors.

All final repeated-lifecycle logs: after initial view freed, baseline4 nodes/26 resources; after8 sequential create/present/free cycles, final4 nodes/26 resources. Thirty repeated presents preserve mesh instance and node counts; presentation snapshot remains unmodified. Early node cleanup race in test observation was fixed by allowing two process frames before baseline sampling.

Exact command pattern (run from worktree, separately for each listed test):

```powershell
$env:SNAPLAND_SAVE_PATH='C:/Users/stanl/AppData/Local/Temp/snapland-rowing-task3-model.json'
& 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe' --headless --path . --script game/tests/test_rowing_cargo.gd *> .superpowers/sdd/2026-11-13-rowing-cargo/task-3-model.log
$env:SNAPLAND_SAVE_PATH='C:/Users/stanl/AppData/Local/Temp/snapland-rowing-task3-driver.json'
& 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe' --headless --path . --script game/tests/test_rowing_cargo_driver.gd *> .superpowers/sdd/2026-11-13-rowing-cargo/task-3-driver.log
$env:SNAPLAND_SAVE_PATH='C:/Users/stanl/AppData/Local/Temp/snapland-rowing-task3-view.json'
& 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe' --headless --path . --script game/tests/test_rowing_cargo_view.gd *> .superpowers/sdd/2026-11-13-rowing-cargo/task-3-view.log
$env:SNAPLAND_SAVE_PATH='C:/Users/stanl/AppData/Local/Temp/snapland-rowing-task3-native-driver.json'
& 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe' --path . --resolution 1280x720 --script game/tests/test_rowing_cargo_driver.gd *> .superpowers/sdd/2026-11-13-rowing-cargo/task-3-native-driver.log
```

Native view command (1280):
```powershell
$env:SNAPLAND_SAVE_PATH='C:/Users/stanl/AppData/Local/Temp/snapland-rowing-task3-native.json'
$env:ROWING_VIEW_CAPTURE='C:/Users/stanl/Github/Snapland/.review/rowing-game-worktree/.superpowers/sdd/2026-11-13-rowing-cargo/task-3-native-1280.png'
$env:ROWING_LARGE_TEXT='0'
& 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe' --path . --resolution 1280x720 --script game/tests/test_rowing_cargo_view.gd *> .superpowers/sdd/2026-11-13-rowing-cargo/task-3-native.log
```
For800: save snapland-rowing-task3-native-800.json; capture task-3-native-800.png; ROWING_LARGE_TEXT=1; --resolution 800x600 (separate argument as in1280); log task-3-native-800.log. View test uses the same uniform centered1280-design fit as Session and explicitly disables project window canvas scaling to avoid double scaling in this standalone fixture.

Native images, all generated by actual GPU viewport and visually inspected:
- .superpowers/sdd/2026-11-13-rowing-cargo/task-3-native-1280.png (true reset: empty hull separate from first anchored cargo)
- .superpowers/sdd/2026-11-13-rowing-cargo/task-3-native-1280-reduced.png (public pickup/stroke/step to crest, dusk and reduced motion)
- .superpowers/sdd/2026-11-13-rowing-cargo/task-3-native-800.png (1.25 text)
- .superpowers/sdd/2026-11-13-rowing-cargo/task-3-native-800-reduced.png (1.25 text/reduced motion; final Chinese cargo header)

Controller also inspected both image sizes and approved the separation/depth/layout improvement; final cargo copy was corrected after that review. Fixed top HUD region is intentionally blank in the standalone fixture. All seven controls and information lines fit both captured window sizes; real shared HUD integration remains the next task.

## Actual model route outcomes after corrected START

Normal digital: elapsed139.425,300 score,3 true deliveries,0 crate impacts,0 wall collisions,devil true; docking angles0.01622696/0.01898388/0.01402940.
Assisted digital: elapsed139.425,300 score,3 true deliveries,0 crate impacts,0 wall collisions,devil true; angles0.00918894/0.01595360/0.01158243.
Shifted strokes: elapsed151.425,three real deliveries; angles0.01923438/0.01734409/0.01657728. Same route still produces physically different angles. Model/driver tests use existing public digital solver, never teleport/score/end writes for these routes. Existing specially arranged negative/collision fixtures are separately labeled in their test.

## Limits and next gate

This is driver/native presentation smoke and focused model verification, not native Session completion, real OS keyboard/pointer playthrough, reward/save verification, full packaged export proof,1920 render proof, human playtest or sound listening. Native test InputEvent calls exercise driver/view public forwarding, not operating-system delivery. The render-only screenshot fixtures use public model commands and are not full game-completion claims. No broad game suite was run; CI registration and Session/Main/UI/tutorial/reward integration remain their assigned tasks. Controller will repeat cadence QA after START change. Physics retains the existing circle-vs-expanded-rectangle hull; view cosmetics do not alter collisions.


