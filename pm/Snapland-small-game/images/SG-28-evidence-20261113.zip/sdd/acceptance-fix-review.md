# SG28 acceptance fixture repair review

Verdict: **APPROVED for the scoped acceptance repair. Both reported defects are ADDRESSED. No actionable introduced regression found.**

Reviewed 2026-11-13, BASE `123e769251903fa086f742f2a475668f6ab62422` through HEAD `f6f9a8bf788e17ab02ab7c3e35b116019fb5aefb`, against `acceptance-fix-brief.md` and the implementation report. The immutable `review-123e769..f6f9a8b.diff` exactly matches the pinned Git diff using its ten-line context. HEAD resolves to the supplied commit; the inspected fixture and production-context files have no working-tree changes against it. This review covers only the two-file repair, not the previously approved whole branch.

## Findings and acceptance verdicts

### 1. Exact cloned save fixture dependencies and cleanup — ADDRESSED

`game/tests/test_test_save_guard.gd:79` copies `game_catalog.gd` alongside the original four core scripts. Lines 89–92 create the data directory and copy the original `welcome_games.json` and `harbor_games.json` through the existing byte-copy helper, preserving its source/destination checks and close behavior. These are the complete catalog inputs: `game/core/game_catalog.gd:3` lists exactly these two data paths, and the rest of that script has no further resource/script dependency. This resolves the missing Progress preload and supplies the catalog's actual runtime data rather than a fake catalog.

Cleanup mirrors every addition: `game/tests/test_test_save_guard.gd:273` removes the added core script; lines 275–277 remove precisely the two copied JSON files and their empty directory before the parent directories. The cleanup remains exact-file removal inside the generated fixture root, with the existing final empty-root assertion. No recursive or expanded profile cleanup was introduced.

The unique fake app prefix and profile verification are unchanged (`:4`, `:16`–`:39`). All six child rejection paths remain intact (`:171`), as do each rejected process's startup-guard/nonzero assertions and per-case original/backup/temp SHA-256 checks (`:175`–`:177`, `:237`–`:244`). Positive isolated save/load and exact fake-default load/save/reopen checks remain intact (`:180`–`:214`). Only the fake application profile is used by the intentional missing/default-path cases; the repair adds no access to the real Snapland profile.

### 2. Borrowed melody view lifecycle, synchronization and ownership — ADDRESSED

`game/tests/test_melody_memory_view.gd:130` starts the actual game before the headless branch borrows the already-ready root view. Lines 133–138 install the borrowed presentation and matching mode, connect the original input signals, invoke the actual Session synchronization path, and assert the initial model/view snapshot equality. This matches the existing production lifecycle: `game/minigames/session.gd:244` clears old input/presentation state before lookup, and `:252`–`:257` hides and queues any prior presentation. Production lifecycle cleanup remains unchanged.

The original integration assertions are preserved. `game/tests/test_melody_memory_view.gd:142` still requires the actual atlas/cache readiness; lines 152–165 advance the actual Session/model and send an instrument-center `InputEventMouseButton` through `_gui_input`, asserting both model input advancement and the view's response event. Retry and practice still test the same model lifecycle (`:166`–`:169`). These checks were not replaced by directly setting a response snapshot. The native branch still lets Session create its own real presentation (`:130`, `:140`–`:150`), including the rendering/capture path.

Before freeing Session, the headless fixture disconnects both borrowed-view signals and clears only its borrowed presentation reference and mode (`:170`–`:174`). Session is then freed and a frame is awaited (`:175`–`:176`); the added assertion checks that the root-owned fixture view survives (`:177`). Its existing outer owner frees it once at `:21`. The native Session-owned presentation is not detached. This corrects ownership in the fixture without weakening driver-to-legacy-to-driver or unknown-game teardown.

## Introduced-breakage and scope checks

- No actionable correctness, ownership, profile-isolation or standards finding in the fix diff. The existing patterns and helpers are reused, and no abstraction, new dependency or production workaround was added.
- The pinned commit changes only `game/tests/test_test_save_guard.gd` and `game/tests/test_melody_memory_view.gd` (20 insertions, 6 deletions). Production, runner, deadlines, error-scanning rules, data, configuration and exports are unchanged. Author and committer are Stanley Li with `stanley890314@gmail.com`.
- Searched the touched helpers' callers. Save build/cleanup are private to this fixture; melody lifecycle is awaited by `_run()`. No external caller or registration requires adjustment.
- A read-only comparison of assertion-line multisets at BASE and HEAD confirmed every original `_check(...)` in the save fixture and every original `_expect(...)` in the melody fixture is retained verbatim. Save adds no assertions; melody adds the initial-sync and owner-survival assertions. The execution order changes are consistent with the intended start/borrow/detach lifecycle.
- Production cleanup and the affected Session regression remain intact. `game/tests/test_rowing_session.gd:127`–`:148` still cover replacing a paused driver with legacy, releasing input/overlay/view, stopping the old clock, returning to a fresh driver and tearing down an unknown start without completion. Cancellation remains checked at `:159`–`:161`.

## Validation evidence inspected

No engine tests were rerun: the supplied focused evidence and source inspection leave no concrete unanswered doubt requiring repetition. Independently parsed the metadata and scanned all fourteen saved `acceptance-*.log` files for `ERROR:` (which also catches `SCRIPT ERROR:`).

| Evidence | Result inspected |
| --- | --- |
| Windows and Linux red save | Both show missing `game_catalog.gd` preload and Progress autoload errors despite exit zero, confirming why exit status alone is insufficient. |
| Windows and Linux red melody | Both show the original pointer/view response assertion failure and freed-instance `queue_free` error, followed by bounded timeout. |
| Windows and Linux green save | Exit 0, 90-second deadline, zero error lines, fake-profile hash-preservation marker, normal-default load/save and reopen markers, final PASS. |
| Windows and Linux green melody | Exit 0, 90-second deadline, zero error lines, 56 checks passed on each. |
| Windows and Linux green rowing Session | Exit 0, 90-second deadline, zero error lines, 34 checks and 0 failures on each. |
| Windows and Linux green ribbon lifecycle | Exit 0, 90-second deadline, zero error lines, 61 checks on each. |
| Windows native green melody / rowing Session | Exit 0, 90-second deadline, zero error lines, 55 melody checks / 50 Session checks and 0 failures. |

The ten green logs use explicit absolute unique `SNAPLAND_SAVE_PATH` values and the pinned Godot 4.7.2 engines; WSL paths are Linux-native. The supplied report additionally records exact fake-project/profile removal self-checks and final no-orphan process checks; those one-off environment checks were not repeated or independently reconstructed. No diagnostic allowlist or weakened assertion is present in the repair.

## Limits and remaining risk

This is a scoped review, not a repeat of the approved broad review, fresh full CI, Linux native rendering review, or human gameplay/visual signoff. No source or Git state was changed; this requested report is the only review artifact written. No subagents were used.

There is no known unresolved issue in this repair. The deliberately exact cloned fixture must continue mirroring future Progress/catalog runtime dependencies; adding another dependency later can require the same paired copy/cleanup update. Parent owns the fresh full-CI result and final delivery decision.
