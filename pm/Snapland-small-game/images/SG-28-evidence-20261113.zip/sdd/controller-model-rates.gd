extends SceneTree

const Model = preload("res://game/minigames/rowing_cargo_model.gd")
const Solver = preload("res://game/tests/test_rowing_cargo.gd")

class RateProxy extends RefCounted:
	var model: RefCounted
	var frame_delta: float
	func _init(target: RefCounted, delta: float) -> void:
		model = target
		frame_delta = delta
	func snapshot() -> Dictionary: return model.snapshot()
	func set_rudder(value: float) -> void: model.set_rudder(value)
	func paddle(value: float = 1.0) -> void: model.paddle(value)
	func sideslip(value: float) -> void: model.sideslip(value)
	func interact() -> void: model.interact()
	func clear_input() -> void: model.clear_input()
	func step(_requested_delta: float) -> Dictionary: return model.step(frame_delta)

func _initialize() -> void:
	var failures := 0
	for fps in [30, 60]:
		for assisted in [false, true]:
			var model := Model.new()
			model.reset(assisted)
			var proxy := RateProxy.new(model, 1.0 / float(fps))
			Solver.solve(proxy)
			var state := model.snapshot()
			var passed: bool = state.success and state.devil and state.delivery_ledger.size() == 3 and state.crate_impacts == 0
			print("RATE_ROUTE fps=%d assisted=%s success=%s devil=%s delivered=%d crate_impacts=%d elapsed=%.3f" % [fps, assisted, state.success, state.devil, state.delivery_ledger.size(), state.crate_impacts, state.elapsed])
			if not passed:
				failures += 1
	print("RATE_ROUTE failures=%d (model command cadence only; no native UI claim)" % failures)
	quit(0 if failures == 0 else 1)
