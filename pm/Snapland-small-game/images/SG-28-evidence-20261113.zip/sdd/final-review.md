# SG28 whole-branch final review

Reviewed immutable BASE `42cde560b8c67c90fb9ed437f8443e2ae8f72a99` through HEAD `123e769251903fa086f742f2a475668f6ab62422`, using `review-42cde56..123e769.diff` as the authoritative 45-file package. Binding requirements: `design/runtime/rowing-cargo.md`, `docs/superpowers/plans/2026-11-13-rowing-cargo.md`, and recorded rulings in `progress.md`. Review performed 2026-11-13.

## Strengths

- **The delivered-data boundary is small and explicit.** `game/core/game_catalog.gd:3` permits only welcome and harbor data, validates canonical IDs, unique modes, required copy, regional numbering and exact delivered counts, and returns independent copies. Default definitions remain the original ordered twelve; global013 resolves harbor/local1/photo1/ACH_GAME_013. Planned014 is not admitted through reward, tutorial or game launch lookups. No Session/UI/model is loaded by Progress's catalog dependency.
- **Reward persistence is corrected at the shared boundary.** `game/core/progress.gd:167` stages cards, the one-time 40-coin receipt, achievements and the offline platform queue in one write, restores all touched state on failure, and signals only after successful persistence. Replays preserve existing metadata and do not back-pay old cards without receipts. Welcome milestones continue to require the actual twelve welcome cards. The old attachment API remains a welcome-restricted wrapper around the same bounded validation/rollback implementation (`:225`, `:230`). Save version and unknown metadata preservation are unchanged.
- **The gameplay is a real deterministic simulation.** `game/minigames/rowing_cargo_model.gd:5` centralizes time, geometry and physical tolerances; `:197` bounds finite stepping and substeps. Heading-relative stroke/slip impulses, inertia, rudder torque, waves, shelter and tide all affect position and approach. Cargo identity, assigned dock, distance, speed and parallel angle are checked before a single delivery ledger entry (`:155`). The devil rule measures actual lateral travel after a crest slip near the dock and distinguishes crate impacts from wall bumps. Assistance changes forces/tolerances/attraction without manufacturing completion or denying devil eligibility.
- **Lifecycle ownership is coherent.** `game/minigames/rowing_cargo_driver.gd:28` merges physical keyboard aliases and pointer owners, rejects repeats, and handles opposition/release. Session routes the new driver before generic timeouts (`game/minigames/session.gd:1015`), clears input on pause/help/focus/leave, blocks the view's direct GUI path while paused or ended, and discards suspended elapsed time. Replacement and unknown-game starts tear down the previous owner before lookup (`:244`). The model remains the sole clock; view presentation does not simulate another world.
- **The presentation contract is modest and reusable.** One optional native view owns one small SubViewport and reuses its geometry. Headless driver creation does not require it. The shared HUD reserves measured top clearance while the view owns immediate feedback once (`game/minigames/session.gd:433`, `:615`; `game/ui/minigame_hud.gd:524`). Actual affine transforms govern pointer fallback. Essential tide, wave, speed, angle, cargo and input information remains visible with reduced motion and without relying on audio or color alone.
- **Main keeps gameplay truth separate from awards.** `game/main.gd:1447` uses new ordinary eligibility with legacy success fallback, independently gates real success/devil/story, preserves practice/cancel behavior, checks reward and attachment persistence, and provides truthful retry messages. The prior successful-story retry finding is fixed by per-outcome notification state carried by the retry callback (`:1469`, `:1501`); separate replays remain new outcomes. No save-schema flag or permanent per-game suppression was introduced.
- **Regional reach is complete for this slice.** Kiosk and map open the real invitation; map entry does not teleport the player. Main resolves all delivered definitions but retains the welcome twelve default. Album switching loads authoritative regional definitions, keeps welcome's six non-game sources out of harbor, preserves 18/12 quotas and original-image viewing, and maps stamps by global identity rather than local position. The three real tutorial PNGs are appended through the existing lesson schema and first-entry/help/practice flow.
- **Tests address behavior and provenance.** Arranged collision fixtures are labeled separately from earned input routes. The production model, driver, Session and Main result are actually exercised. Failure tests block the real temporary writer; reload uses a second process. Native earning replays digital input through a Main-created Session and checks the actual model/result/ledger independently. The sole runner retains the previous 106 registrations and adds nine exact completion contracts; unchanged four-shard workflow selection covers the resulting 115 suites.

## Issues

### Critical — must fix

None found in the reviewed branch.

### Important — should fix

None outstanding. The Task5 story-dispatch retry defect is addressed by `83c88b3`, with an actual successful-result regression covering failed reward save, failed attachment, repeated failed repair, successful repair, caller-result immutability and a separate successful replay (`game/tests/test_rowing_main.gd:174`).

### Minor — inherited and explicitly deferred

- **Existing welcome-world unsupported material/cutaway warning:** `.superpowers/sdd/2026-11-13-rowing-cargo/task-5-focused.log:16`, emitted from `game/world/occlusion_controller.gd:178`. The warning explicitly preserves the unsupported ShaderMaterial without cutaway; therefore it describes a limited existing occlusion effect and log noise, not a missing rowing material or a new gameplay fault. It also appears in the amended Linux Main baseline. Keep it tracked as inherited deferred work; do not call every Main run warning-free. No SG28 change to the older material system is justified by this review. Final native rowing logs reviewed here have no unexpected warning/error diagnostics.

No new Minor finding is raised.

## Plan and ruling assessment

All five planned implementation areas are present and agree at their producer/consumer boundaries. The scoped expansions are justified and completed: returning a saved-result boolean updates the concretely affected old assertion; START separation fixes the actual empty-boat/cargo overlap; the recovery test now targets the actual crate; promoted HUD clearance and single feedback ownership resolve observed layout overlap; regional catalog selection removes stale/custom-subset ambiguity; map launch reuses invitation UI without expanding terrain interaction. The story retry flag fixes a concrete side effect at the shared Main boundary.

The temporary coexistence of legacy modes and new drivers is reasonable. Adding another delivered game has clear seams in validated data, the driver registry, tutorial data and focused tests; no generic gameplay framework or migration of twelve mature modes is warranted. The driver view must continue to honor the reserved-top and own-feedback convention. Static catalog count/start tables are appropriate to an explicitly delivered catalog, with no arbitrary script-loading surface.

Generalized reward persistence touches the old games, but their default definitions, mode implementations, legacy success fallback, save version, reward receipt behavior, attachment wrapper and welcome milestones remain compatible. The album's formal catalog ownership intentionally changes custom-subset behavior, as recorded; this is not an unacknowledged API regression. SG29 remains the separate policy delivery for legacy participation and free three-step retake.

## Verification reviewed

No suite was rerun. Reviewed the full supplied diff in bounded, nonoverlapping source sections, binding documents and ledger, Task1–4 reviews, Task5 report/review and successful fix re-review. Named follow-up source reads were limited to retained photo buffers and retry writers, Session pause/focus restoration, Progress atomic writer, SteamBridge queue consumers, and the existing full-test workflow. No implementation, index, HEAD or branch mutation occurred; this report is the only written artifact.

Accepted focused evidence includes model58, driver39 headless/42 native, view32 headless/34 native, Session34 headless/51 native and collection22 headless/24 native checks. Eight view create/free cycles return nodes4→4 and resources26→26. Existing affected old12/Main/photo/story/region/UI/tutorial regressions and 87 Python contract tests are documented in the task reports. The amended fix log directly records import, Main, Main story and shared-thumbnail PASS; the amended pinned-Linux Main log ends its exact PASS marker. The child contract requires exactly eight deliberate write/attachment diagnostics rather than accepting arbitrary errors.

Directly read final source800, source1920 timeout, independent saved reader, exposed-gap and lifecycle logs. Source800 records three distinct deliveries to docks1/2/1, score300, zero crate impacts, crest sideslip and a single genuine result. Timeout records success=false, ordinary=true, devil=false, score0. Gap mode crosses the evolving exposed gap by public inputs and exits practice without reward. The reader loads an actually written profile and original PNG, without resetting or seeding013. Reviewed reported normal/assisted1280 and 30/60Hz evidence with their stated scope; these are not human tests.

Direct visual inspection covered all three committed1280 tutorial PNGs, source800 enlarged-text/reduced-motion gameplay and result, and source1920 timeout result. Boat and initial crate are visibly separate; cargo/docks/routes and essential indicators are visible; controls and result actions remain contained; the successful and failed result screens distinguish actual score/success from ordinary eligibility. Existing screenshots were inspected, not regenerated.

The native helper contains no boat-position, score, ending or earned-result assignments. Its six welcome eligibility cards are explicitly synthetic prerequisites. It records a public-command model route, then sends digital key events through Session's input handler with fixed simulation steps and periodic rendering. Native pointer tests also use the input pipeline for GUI/resize/pause coverage. This is legitimate automated functional evidence under the spec, not a claim of operating-system keyboard delivery, human reaction-time playability, enjoyment or listening acceptance. Headless native preflight only checks helper/assets; its marker does not claim a GPU playthrough. External release helpers load only their explicit adjacent helper plus packed production resources, with no excluded-test fallback in the inspected code.

## Recommendations

Complete and record the exact-HEAD cloud and clean packaged/executable acceptance gates before ticket closure or final publication. Preserve their artifact/profile provenance and distinguish source evidence from release evidence. Keep inherited material warnings and human listening status explicit. No production refactor or speculative extension is requested by this review.

## Declined to judge

- The remaining115 games, regional stories/endings/rifts and whole-game completion: outside the approved SG28 slice; only13 games are delivered.
- Shared old12 participation rewards and free three-step retake: explicitly assigned to separate pending SG29, not silently treated as completed here.
- Full1–4-player/P2P implementation or a new Steam service: this slice preserves the single-player/data/save/offline-adapter boundaries; it does not deliver those broader systems.
- Human enjoyment, real hardware keyboard timing and human listening for MIC1/2/3/ST5: automated input and screenshots cannot establish these; listening is explicitly unfinished.
- ART16/17 completion or redesign of existing character art: separately open work, not implemented or accepted by this branch.
- Rewriting the old welcome ShaderMaterial/occlusion system: the concrete inherited warning is triaged above, with no new rowing regression established.
- Cloud run43289380117, clean tracked-stage/default-Forward+ PCK and Windows release execution outcomes: controller gates were in progress at dispatch; this review does not infer their results or rerun them.
- Final public evidence/ticket/README/index publication, merge and cleanup: controller delivery work, not an implementation defect or a completed action in this review.

## Assessment

**Implementation verdict: APPROVED.** The integrated change satisfies the bounded specification, retains backward compatibility at the touched boundaries, has meaningful failure/lifecycle/identity coverage, and keeps a practical extension seam without unnecessary framework work. No new actionable Critical, Important or Minor defect was found.

**Ready to merge: conditional on outstanding acceptance gates.** There is no code-review fix request. Exact-HEAD full CI, clean PCK/Windows acceptance and controller publication/closure remain separate requirements; this report alone does not mark them passed or SG28 finished. Human listening and the wider game remain explicitly incomplete.

Skipped duplicate passed suites, new renders, hardware play and listening. Remaining delivery risk is the pending exact-source release/CI evidence; only the reviewed thirteen-game slice is approved.
