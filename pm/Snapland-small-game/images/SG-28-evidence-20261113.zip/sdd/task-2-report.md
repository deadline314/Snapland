# Task 2 — deterministic rowing/cargo model

Status: DONE

Commit: `808e45e4d20127e96f8077f30b96978b9b0f4125` — `feat(rowing): implement deterministic cargo and tide physics`.
Author and committer: Stanley Li <stanley890314@gmail.com>. Only the two owned GDScript paths were staged/committed; no generated import/uid or other agents' edits were staged. This report and focused log are ignored local handoff artifacts.

## Scope and implementation

Created `game/minigames/rowing_cargo_model.gd` and `game/tests/test_rowing_cargo.gd`. Read root AGENTS, closest sign-balance model/test, canonical harbor game013 row, task-2 brief (including digital-control clarification), and binding `design/runtime/rowing-cargo.md`. No saving, UI, resources, new dependencies, wall-clock time, random source, destination setter, completion setter, or production autopilot. No callers/config/exports existed for this new model; downstream driver/view and suite registration remain their assigned tasks.

Model is RefCounted, owns all elapsed time, bounds each supplied frame to 0.25 s and each physical slice to 0.02 s, drops invalid/nonpositive deltas and excess catchup, freezes after natural success/timeout. Commands are exactly `reset(assisted=false)`, `set_rudder(value)`, `paddle(direction=1)`, `sideslip(direction)`, `interact()`, `clear_input()`, `step(delta)`, `snapshot()`. Finite strengths clamp to [-1,1]; nonfinite strengths are ignored. Repeated stroke/slip commands cannot add impulses before their independent cooldowns expire. `clear_input` releases held rudder without removing velocity. Pausing/cancelling must stop calling `step`; model has no independent timer. A fresh/unended model has no ordinary eligibility; natural timeout and successful delivery do. Session must retain its practice suppression because the specified model reset interface only accepts assisted.

Forward/reverse impulses follow current heading; rudder yaw gain depends on actual forward speed, waves apply force/torque, drag treats longitudinal/lateral motion separately. Waiting cargo is anchored and recoverable. Carrying updates its real position. Pickup requires proximity and safe speed; delivery requires assigned dock, proximity, speed and parallel heading (either bow direction). Only three successful identity transitions can enter the ledger. Hull-wall collisions are distinct from fast hull contact with waiting crates; wall bumps alone do not deny devil. Closing tide ejects into playable free water, including near the outer boundary. Assistance halves wave strength, widens actual docking tolerances, adds modest nearby attraction, never grants delivery/score or disables devil.

Actual crest dock requires slip initiated during a crest within 1.9 units of the eventual dock, at least 0.08 units actual projected lateral travel, and safe delivery within 1.1 s of that slip. Immediate key press + interact without lateral travel fails this condition. Devil additionally requires all three genuinely delivered and zero crate impacts; wall collisions are not included.

## Public snapshot / view contract

Every snapshot constructs independent deep copies of cargo, docks and ledger; its dictionaries/arrays may be treated as read-only, and caller mutations cannot change rules. Vector2 `(x,y)` maps to world `(X,Z)`. Heading zero is +X. Positive heading and positive sideslip turn/move toward +Z. Positive lateral_speed shares the positive sideslip convention. Geometry Rect2 also uses X/Z. A 3D boat oriented along +X uses world yaw `-heading`.

- Round/result: `assisted, elapsed, remaining, ended, success, devil, devil_success` (compatibility alias), `ordinary_eligible, score, mistakes` (crate impacts), `crate_impacts, wall_collisions`.
- Boat/control: `position, heading, velocity, speed, angular_velocity, forward_speed, lateral_speed, rudder, boat_radius`; `paddle_ready, paddle_ready_in, sideslip_ready, sideslip_ready_in`.
- Cargo: `cargo` has exactly 3 dictionaries `{id, position, destination, status}`; status is waiting/carried/delivered. `carrying` is empty or crate ID. `delivery_ledger` has at most 3 `{cargo_id, dock_id, elapsed, speed, angle, crest_sideslip}`. No event-per-frame history.
- Geometry/environment: `bounds, docks` (`id,position,heading,size`), `shelter` Rect2, `breakwaters` Array[Rect2], `tide` 0..1, `gap` `{center,half_width,navigable_half_width}`, `water` `{force,torque,sheltered,strength,phase,crest,next_crest_seconds}`, plus `crest, crest_forecast, crest_dock, sheltered`.
- HUD: `dock_radius, dock_speed_limit, dock_angle_limit, dock_angle_error, nearest_dock, feedback, last_event` (feedback alias). `dock_angle_error` is for nearest dock, in radians, minimum parallel error in either direction. Crest forecast reports seconds to the next crest window start; while currently crest, use `crest` to display current state.

## Central constants and chosen layout

All gameplay/physical/layout constants are grouped at the top of the model; no external tuning resource.

| Constant / geometry | Value |
|---|---|
| Round / supplied-frame cap / substep cap | 240 / 0.25 / 0.02 seconds |
| Bounds / start / boat and crate radii | Rect2(-11,-7,22,14) / (-8,-3) / 0.32 each |
| Crate IDs / positions / destination docks | crate-1 (-8,-3) →1; crate-2 (-8,0) →2; crate-3 (-8,3) →1 |
| Dock 1 / Dock 2 / heading / visual size | (8,-3) / (8,3) / 0 radians / (2.5,1.1) |
| Breakwater X half width / shelter threshold / safe long-route Z | 0.45 / 3.8 / 5.3 |
| Tide period / gap half width range | 18 seconds / 0.45..1.55 |
| Wave period / crest center / half window | 6 / 1.5 / 0.5 seconds (crest window [1,2] modulo 6) |
| Wave force / torque / lateral ratio / spatial phase | 0.30 / 0.15 / 0.6 / 0.2 |
| Shelter wave factor / assisted wave factor | 0.12 / 0.5 |
| Paddle impulse / cooldown | 0.72 / 0.32 seconds |
| Slip impulse / cooldown / crest boost | 0.42 / 0.7 seconds / 1.35 |
| Maximum linear / angular speed | 3.6 units/s / 1.5 radians/s |
| Longitudinal / lateral / angular drag | 0.72 / 1.65 / 3.6 |
| Rudder torque / idle gain / speed gain / gain speed cap | 2.8 / 0.4 / 0.3 / 2.0 |
| Pickup radius / speed | 1.05 / 1.0 units/s |
| Dock radius / speed / parallel angle tolerance | 1.15 / 0.90 / 0.35 radians (~20°) |
| Assisted dock radius / speed / angle multipliers | 1.15 / 1.2 / 1.4 |
| Assisted attraction strength / radius / max speed | 0.16 / 1.7 / 1.3 |
| Crate impact speed / cooldown / rebound | 1.15 / 0.6 seconds / 0.2 |
| Wall restitution / minimum counted impact speed | 0.2 / 0.05 |
| Crest dock time / travel / initiation radius | 1.1 seconds / 0.08 units / 1.9 units |
| Delivered crate X spacing / Z offset | 0.45 / -0.6 |
| Delivery score | 100 per distinct crate; 300 maximum |

Gap walls run from Z=-7 to -gap and +gap to +3.8. The exposed short passage is the actual gap near (0,0). The long sheltered passage above Z=3.8 stays open at every tide. Minimum gap still permits carefully centered traversal, while high tide gives materially wider collision clearance.

## Public digital solver and downstream native reuse

Test script provides **static** `solve(model, stroke_shift=0)`, `navigate(model,target,dock_align=false,stroke_shift=0)` and `steer(model,heading)`; invoke `preload("res://game/tests/test_rowing_cargo.gd").solve(model)` without instantiating another SceneTree. They use public commands and snapshots only. No position, terminal, ledger, score, cargo or private property writes occur in those helpers. Fixtures elsewhere in the suite explicitly arrange private states for rejection/collision edges and are not clean native earned evidence.

Every command on the successful routes is actually player-accessible: rudder -1/0/+1, paddle -1/+1, sideslip -1/+1, interact, clear_input. Steps are 0.025 s. Static solver owns only test orchestration, not a production clock. The native verifier should mirror these decisions through actual key press/release with model stepping through Session and snapshot feedback, or use a command-forwarding fixture; it must not call this synchronous helper and also advance Session simultaneously. Release packaging excludes tests, so copy these explicit test-only static helper bodies into the external native fixture (or load the script copied beside that fixture and adapt its model preload to the PCK resource). Production has no test/helper dependency. All solver dependencies are standard math, the public model API, and its geometry constants.

Route for each crate: pickup (crate 1 starts within range), go (-4,5.3), (4,5.3), dock-(2,0), dock with heading 0 alignment. Before crates 2/3 return via (5,5.3), (-4,5.3), its anchored pickup. Arrival threshold is distance <0.45 and speed <0.6; final dock additionally heading error <0.15. PD steering computes `4*angle_difference(current,target)-2*angular_velocity`; digital sign outside 0.1 deadband. Travel desired speed is min(2.5,0.9*distance) when heading error <0.5; otherwise brake toward zero. Dock-aligned desired forward speed is clamp(offset.x,-1,1) if error <0.2; lateral error >0.2 uses digital side stroke toward `0.8*offset.y-velocity.y`. Paddle when ready if forward speed differs by >0.35. At dock wait for crest, slip toward dock's Z center, steer heading zero for 16 frames (0.4 s), then interact. All loops have finite guards.

`stroke_shift=0.2` keeps identical waypoints/steering algorithm but gates strokes until phase >=0.2 of each 0.5 s interval. This genuinely changes physical docking angles, while still delivering all three; no score-only substitution.

## Exact checks and evidence

Red command, before implementation (isolated save path `C:/Users/stanl/AppData/Local/Temp/snapland-rowing-task2-red.json`):

```powershell
$env:SNAPLAND_SAVE_PATH='C:/Users/stanl/AppData/Local/Temp/snapland-rowing-task2-red.json'
& 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe' --headless --path . --script game/tests/test_rowing_cargo.gd
```

Observed exit 1: `Parse Error: Preload file "res://game/minigames/rowing_cargo_model.gd" does not exist.` The initial test file existed before production implementation.

Final focused command, same pinned Windows 4.7.2 engine, isolated absolute save path:

```powershell
$env:SNAPLAND_SAVE_PATH='C:/Users/stanl/AppData/Local/Temp/snapland-rowing-task2-focused.json'
& 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe' --headless --path . --script game/tests/test_rowing_cargo.gd *> .superpowers/sdd/2026-11-13-rowing-cargo/task-2-focused.log
```

Exit 0, **Rowing cargo: 57 checks, 0 failures**, no script/parse/runtime error. Full exact ledger/output is in `.superpowers/sdd/2026-11-13-rowing-cargo/task-2-focused.log`.

| Public route | Elapsed | Dock 1 / dock 2 / dock 1 delivery times | Recorded docking angles (radians) | Cargo/wall impacts |
|---|---|---|---|---|
| Normal digital | 139.425 | 31.425 / 85.425 / 139.425 | 0.01941162 / 0.01748526 / 0.01687469 | 0 / 0 |
| Assisted digital | 139.425 | 31.425 / 85.425 / 139.425 | 0.00900449 / 0.01651257 / 0.00915604 | 0 / 0 |
| Normal, shifted strokes | 151.425 | 37.400 / 97.425 / 151.425 | 0.01695088 / 0.01726479 / 0.01528137 | clean successful deliveries |

Every normal/assisted ledger entry records `crest_sideslip=true`; both end success/devil/ordinary_eligible true. Crate identities/dock IDs are crate-1→1, crate-2→2, crate-3→1. Additional arranged-collision routes physically recover through public controls: crate impact permits successful ordinary but denies devil; wall bump still permits actual devil. Other checks cover deterministic repeated inputs, nested snapshot independence, released inertia, heading-relative forward/reverse/slip, cooldown repeat spam and readiness, invalid/huge time/inputs, clear_input, finite speed/boundaries, natural timeout eligibility, terminal freeze, pickup/delivery speeds, wrong dock/angle, duplicate delivery, assisted limits/attraction, no-motion crest rejection, actual wave force/torque and shelter reduction, changing tide collision gap, tide ejection including boundary edge, short-gap traversal and always-open long path, recoverable impacted cargo, and bounded storage.

Self-review found and fixed boundary-adjacent tide ejection choosing a point beyond playable bounds, and aligned lateral_speed sign with positive sideslip. `git diff --cached --check` passed before commit; reviewed the complete two-file implementation. No broad whole-game suite was run, as requested.

## Limits / downstream verification

No task-2 blocker. This is model + headless input evidence, not a native UI playthrough, human playtest, sound test, screenshot, packaged build proof, or Session/practice/reward persistence proof. Native window-size/input/pause/export verification and CI suite registration remain downstream. The preserved solver was validated with 0.025 s decisions on Windows 4.7.2; frame-rate variation and native input forwarding must be checked by the native verifier. Physics uses a circular hull against expanded rectangular breakwaters and anchored waiting crates; no hull polygon or freely drifting/lost-cargo system was added.
