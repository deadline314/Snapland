from pathlib import Path
import ast,os,json,time
from tools.godot_entrypoints import run_validated_godot
from tools.run_game_tests import result_error
r=Path.cwd();b=r/'work/tutorial-current-20261020';stage=b/'validation-project';out=r/'work/bubble-final-20261021/checks-final';out.mkdir(exist_ok=False);engine=str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64');common=[engine,'--headless','--path',str(stage),'--audio-driver','Dummy','--rendering-method','gl_compatibility']
tree=ast.parse((r/'tools/run_game_tests.py').read_text());assignment=next(n for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='checks' for t in n.targets));checks=eval(compile(ast.Expression(assignment.value),'<official selectors>','eval'),{'executable':engine,'common':common,'ROOT':stage,'str':str});names={'bubble photo model tests','bubble photo view tests','welcome minigame tests','main scene integration tests','pixel UI minigame tests','pixel UI shell tests'};assert names=={n for n,_ in checks if n in names};results=[]
for i,(name,cmd) in enumerate((n,c) for n,c in checks if n in names):
 start=time.monotonic();p=run_validated_godot(stage,cmd,dict(os.environ,SNAPLAND_SAVE_PATH=str(out/str(i)/'progress.json')),90);log=p.stdout+p.stderr;(out/(name.replace(' ','-').replace('/','-')+'.log')).write_text(log);error=result_error(name,p);results.append(dict(name=name,exit=p.returncode,seconds=round(time.monotonic()-start,2),errors=log.count('ERROR:'),error=error));(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(results[-1],flush=True)
 if error:print(log[-2200:],flush=True);raise SystemExit(1)
