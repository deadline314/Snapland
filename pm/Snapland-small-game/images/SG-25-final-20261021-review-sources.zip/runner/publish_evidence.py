from pathlib import Path
import json,hashlib,shutil,zipfile,re,subprocess
r=Path.cwd();b=r/'work/bubble-final-20261021';dest=r/'pm/Snapland-small-game/images';prefix='SG-25-final-20261021-';files=[]
def cp(path,label):
 q=dest/(prefix+label);assert not q.exists(),q
 if path.suffix=='.log':
  s=re.sub(r'\x1b\[[0-9;]*m','',path.read_text());q.write_text('\n'.join(x.rstrip() for x in s.splitlines()).rstrip()+'\n')
 else:shutil.copyfile(path,q)
 files.append({'file':q.name,'source':str(path.relative_to(r)),'sha256':hashlib.sha256(q.read_bytes()).hexdigest(),'bytes':q.stat().st_size})
for case in ['controls-v2','outcomes-v2','lesson']:
 result=json.loads((b/case/'result.json').read_text());assert result['exit']==0 and result['errors']==0 and result['passes']
 for p in sorted((b/case/'captures').glob('*.png')):cp(p,case+'-'+p.name)
 for name in ['result.json','result.log','source-provenance.json','natural-results.json','outcomes.json','video-metadata.json','play.mp4']:
  p=b/case/name
  if p.is_file():cp(p,case+'-'+name)
for p in sorted((b/'checks-final').glob('*')):
 if p.is_file():cp(p,'checks-'+p.name)
checks=json.loads((b/'checks-final/results.json').read_text());assert len(checks)==6 and all(x['exit']==0 and x['error'] is None for x in checks)
for name in ['research.md','reference-camera-ready.webp','reference-provenance.json']:
 cp(b/name,name)
for p in sorted(b.glob('bubble*overview*.jpg')):cp(p,p.name)
for name in ['result.json','result.log','source-provenance.json']:cp(b/'controls'/name,'rejected-controls-'+name)
components=['game/minigames/session.gd','game/minigames/bubble_photo_model.gd','game/minigames/bubble_photo_view.gd','game/tests/native_bubble_photo_review.gd','game/tests/native_bubble_outcomes_review.gd','game/tests/test_minigames.gd','game/main.gd','assets/ui/tutorials/game-010-step-01.png','assets/ui/tutorials/game-010-step-02.png','assets/ui/tutorials/game-010-step-03.png'];hashes={n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in components};(b/'source-sha256.json').write_text(json.dumps(hashes,indent=2)+'\n');cp(b/'source-sha256.json','source-sha256.json')
archive=b/'sources.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for case in ['controls','controls-v2','outcomes-v2','lesson']:
  for p in (b/case).glob('*'):
   if p.suffix in ['.gd','.tscn']:z.write(p,str(p.relative_to(b)))
 for p in b.glob('*.py'):z.write(p,'runner/'+p.name)
 for name in ['work/tutorial-current-20261020/private_main.gd','work/tutorial-current-20261020/private_main.tscn',*components[:6]]:z.write(r/name,'repository/'+name)
cp(archive,'review-sources.zip')
manifest={'ticket':'SG-25','date':'2026-10-21 Asia/Taipei','runtime':'Godot4.7.2 Compatibility llvmpipe1280x720 Dummy audio','scope':'Actual key/pointer-driven Main/Session routes. Station relocation and returning-player fixtures; separate actual new-player tutorial lifecycle. Focus loss is explicitly delivered as an engine notification, not external OS focus. No score/clock/model/award injection.','new_behavior':'Result labels distinguish perfect, qualified, bubble/frame failure and timeout. Scoring, bounds, bubble size/path and success criteria unchanged.','controls':json.loads((b/'controls-v2/result.json').read_text()),'outcomes':json.loads((b/'outcomes-v2/outcomes.json').read_text()),'lesson':json.loads((b/'lesson/result.json').read_text()),'checks':checks,'evidence_limits':'Two silent20FPS movies fully decoded.27 gameplay/result captures and6 lesson captures reviewed; not continuous movie watching, new slow-motion acceptance, human play or listening. Prior quarter-speed acceptance remains separately cited in ticket.','earlier_attempt':'First current run reached earned295, then looked for legacy auxiliary button directly in compact invitation. Fixture now actually opens existing options before auxiliary control.48.96s exit1 retained, no gameplay acceptance threshold removed.','files':files};(dest/(prefix+'verification.json')).write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print('SG25 artifacts',len(files))
