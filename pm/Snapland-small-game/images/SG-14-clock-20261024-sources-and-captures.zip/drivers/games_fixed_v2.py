from pathlib import Path
import os,json,time,shutil
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd(); stage=r/'work/tutorial-current-20261020/validation-project'
out=r/'work/remaining-20261024/games-fixed-v2';out.mkdir(exist_ok=False)
engine=r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'
routes=['balloon_controls','kite_outcomes','fountain_acceptance','crowd_acceptance','hat_rescue_outcomes','ribbon_rhythm','pipe_outcomes','sign_outcomes','shadow_outcomes','bubble_outcomes','bench_outcomes','melody_memory']
first=json.loads((r/'work/remaining-20261024/games-batch/results.json').read_text())
assert len(first)==12, 'Wait for the initial GPU batch to finish'
retry={row['game'] for row in first if row.get('exit') != 0 or row.get('errors') != 0 or not row.get('passes')}
retry.add(6) # Replace the standalone view check with actual Main integration.
results=[]
for index,route in enumerate(routes,1):
 if index not in [6,12]:continue
 d=out/('%02d-%s'%(index,route));d.mkdir()
 before={p:p.stat().st_mtime_ns for p in stage.rglob('*.png') if '.godot' not in p.parts and 'assets' not in p.parts}
 t=time.monotonic();args=[str(engine),'--path',str(stage),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--resolution','1280x720','--fixed-fps','60','res://game/tests/native_%s_review.tscn'%route]
 args+=['--','--review-fixed-clock']
 try:
  p=run_validated_godot(stage,args,dict(os.environ,SNAPLAND_SAVE_PATH=str(d/'progress.json'),SNAPLAND_NATIVE_CAPTURE='1'),420)
  s=p.stdout+p.stderr;record=dict(game=index,route=route,exit=p.returncode,errors=s.count('ERROR:'),seconds=round(time.monotonic()-t,2),passes=[line for line in s.splitlines() if line.startswith('PASS:')])
 except Exception as e:
  s=repr(e);record=dict(game=index,route=route,exception=s,seconds=round(time.monotonic()-t,2))
 (d/'result.log').write_text(s)
 copied=[]
 for root in [stage]:
  if not root.exists():continue
  for p in root.rglob('*.png'):
   if '.godot' in p.parts or 'assets' in p.parts or before.get(p)==p.stat().st_mtime_ns:continue
   relative=p.relative_to(stage);target=d/'captures'/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target);copied.append(str(relative))
 record['captures']=copied;results.append(record);(out/'results.json').write_text(json.dumps(results,indent=2));print(json.dumps({k:v for k,v in record.items() if k!='captures'}),flush=True)
print('BATCH COMPLETE',flush=True)
