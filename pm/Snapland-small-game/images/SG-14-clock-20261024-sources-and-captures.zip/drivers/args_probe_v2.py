from pathlib import Path
import os
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();s=r/'work/tutorial-current-20261020/validation-project';o=r/'work/remaining-20261024/args-probe-v2';o.mkdir(exist_ok=False)
p=s/'work/remaining-20261024/args_probe_v2.gd'
p.write_text('extends SceneTree\nfunc _initialize() -> void:\n var review = load("res://game/tests/native_review.gd").new()\n print("ENGINE_ARGS:", OS.get_cmdline_args(), " USER_ARGS:", OS.get_cmdline_user_args(), " FIXED_REVIEW:", review._uses_fixed_review_clock())\n review.free()\n quit(0)\n')
res=run_validated_godot(s,[str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'),'--headless','--path',str(s),'--fixed-fps','60','--script','res://work/remaining-20261024/args_probe_v2.gd','--','--review-fixed-clock'],dict(os.environ,SNAPLAND_SAVE_PATH=str(o/'progress.json')),20)
a=res.stdout+res.stderr;(o/'result.log').write_text(a);print(a);assert res.returncode==0 and 'FIXED_REVIEW:true' in a and 'ERROR:' not in a
