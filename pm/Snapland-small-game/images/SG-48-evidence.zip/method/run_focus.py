from pathlib import Path
import sys

q=Path("E:/Snapland-QA/bean-seesaw-20261119")
source=(q/"run.py").read_text("utf8")
start=source.index("mode=sys.argv[1]")
end=source.index("print(folder.as_posix()",start)
source=source[:start]+'''test=sys.argv[1]
donor=Path(sys.argv[2])
relative="game/tests/"+test
fixtures.clear()
fixtures[relative]=ROOT/relative
for dependency in sys.argv[3:]:
    relative_dep="game/tests/"+dependency
    fixtures[relative_dep]=ROOT/relative_dep
runner.FIXTURES=list(fixtures)
folder,path,graph=stage("focused-"+Path(test).stem,donor)
entry="res://"+relative
command=[runner.ENGINE,"--headless","--path",path,"--rendering-method","gl_compatibility","--audio-driver","Dummy"]
command.extend(["--script",entry] if test.endswith(".gd") else [entry])
runner.launch(folder,path,graph,"focused",command,runner.environment(folder))
print((folder/"stdout.log").read_text("utf8").splitlines()[-1])
'''+source[end:]
exec(compile(source,str(q/"run_focus.py"),"exec"))
