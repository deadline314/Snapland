"""Stage bean seesaw runtime and write receipts for isolated native sessions."""
from pathlib import Path
import sys

here=Path(__file__).resolve().parent
base=here.parent/"art16-longitudinal-pivot-study-20261119/verify.py"
source=base.read_text("utf8")
source=source.replace("donor.parent == QA", "donor.parent == QA or donor.parent.as_posix() == " + chr(34) + "E:/Snapland-QA/animation-suite-20261119/native" + chr(34))
start=source.index('FIXTURE="game/tests/native_avatar_depth_pivot_study"')
stop=source.index('def stage(',start)
source=source[:start]+'''FIXTURE="game/tests/native_bean_seesaw_review"
fixtures={FIXTURE+ext:HERE/("play_fixture"+ext) for ext in (".gd",".tscn")}
runner.FIXTURES=list(fixtures)
runner.MARKER="PASS: bean seesaw native preview"


'''+source[stop:source.index("def record(")]
source=source.replace('folder=runner.make_base("depth-"+label)','folder=runner.make_base("beans-"+label)')
source+='''
mode=sys.argv[1]
donor=Path(sys.argv[2]) if len(sys.argv)>2 else None
folder,path,graph=stage(mode,donor)
if mode=="import":
    runner.launch(folder,path,graph,"import",[runner.ENGINE,"--headless","--path",path,"--editor","--import","--quit"],runner.environment(folder))
    runner.collect_imports(folder,path,graph)
else:
    runner.launch(folder,path,graph,mode,[runner.ENGINE,"--path",path,"res://"+FIXTURE+".tscn",
        "--rendering-method","gl_compatibility","--audio-driver","Dummy","--fixed-fps","60"],runner.environment(folder))
    status=runner.read(folder/"receipt.json")
    assert status["marker_counts_engine_stdout_stderr"]==[1,1,0] and len(status["capture_outputs"])==4
print(folder.as_posix(),flush=True)
'''
exec(compile(source,str(here/"run.py"),"exec"))

