extends SceneTree

const Catalog = preload("res://game/core/game_catalog.gd")
const Session = preload("res://game/minigames/session.gd")
var _failures: Array[String] = []
var _checks := 0

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var save := OS.get_environment("SNAPLAND_SAVE_PATH")
	var before := FileAccess.get_sha256(save)
	var progress := root.get_node("Progress")
	_check(not before.is_empty() and save.is_absolute_path(), "exact isolated legacy profile exists")
	_check(progress.current_region == "candy" and progress.coins == 160, "legacy region and coins are loaded")
	_check(progress.has_seen_tutorial("game-030") and progress.has_attempted_game("game-030") and progress.achievements.has("ACH_GAME_030"), "old lesson, attempt and achievement survive")
	for id in ["photo-candy-game-6", "photo-candy-devil-6"]:
		var record: Dictionary = progress.photos.get(id, {})
		_check(record.get("game_id") == "game-030" and not record.get("original_frames", []).is_empty(), "intact legacy collection " + id)
		for path in record.get("original_frames", []):
			var image := Image.load_from_file(path)
			_check(image != null and image.get_size() == Vector2i(800, 600), "intact legacy rendered original")
	_check(not progress.has_attempted_game("game-031") and not progress.achievements.has("ACH_GAME_031"), "new station is unplayed in the old save")
	_check(not progress.photos.has("photo-candy-game-7") and not progress.photos.has("photo-candy-devil-7"), "new station never creates old-save rewards")
	var session := Session.new()
	root.add_child(session)
	session.set_process(false)
	session.start("game-031")
	_check(session.game_id == "game-031" and not session.ended and Catalog.identity("game-031").local_index == 7, "old profile can still launch the new canonical game")
	session.free()
	_check(FileAccess.get_sha256(save) == before, "read-only compatibility proof leaves the translated snapshot unchanged")
	for failure in _failures:
		push_error(failure)
	print("Bean legacy save: %d checks, %d failures" % [_checks, _failures.size()])
	quit(0 if _failures.is_empty() else 1)

func _check(ok: bool, message: String) -> void:
	_checks += 1
	if not ok:
		_failures.append(message)
