extends Node

const Catalog = preload("res://game/core/game_catalog.gd")
const Session = preload("res://game/minigames/session.gd")
const View = preload("res://game/minigames/bean_seesaw_view.gd")
const SaveGuard = preload("res://game/core/test_save_guard.gd")
const Paper = preload("res://game/ui/paper_ui.gd")
const Release = preload("res://game/tests/audio_playback_release.gd")
const GAME := "game-031"
const ORDINARY := "photo-candy-game-7"
const DEVIL := "photo-candy-devil-7"
const ACHIEVEMENT := "ACH_GAME_031"

var _main: Node
var _game: Control
var _mode := ""
var _out := ""
var _save := ""
var _size := Vector2i.ZERO
var _checks := 0
var _errors: Array[String] = []
var _captures: Array[String] = []
var _results: Array[Dictionary] = []
var _data: Dictionary = {}

func _ready() -> void:
	call_deferred("_run")

func _run() -> void:
	_mode = OS.get_environment("COTTON_REVIEW_MODE")
	_out = OS.get_environment("COTTON_CAPTURE_DIR")
	_save = OS.get_environment("SNAPLAND_SAVE_PATH")
	if not _mode in ["suite", "retake-devil", "read"] or not _out.is_absolute_path() or not _save.is_absolute_path() \
		or _out == _save.get_base_dir() or not SaveGuard.validate_save_path(_save, OS.get_user_data_dir()).is_empty() \
		or not SaveGuard.validate_save_path(_out, OS.get_user_data_dir()).is_empty():
		push_error("Bean native QA requires fresh isolated output and save paths.")
		get_tree().quit(1)
		return
	var parts := OS.get_environment("COTTON_REVIEW_SIZE").split("x")
	if parts.size() != 2:
		push_error("Bean native QA needs a viewport size.")
		get_tree().quit(1)
		return
	_size = Vector2i(int(parts[0]), int(parts[1]))
	get_window().content_scale_mode = Window.CONTENT_SCALE_MODE_DISABLED
	get_window().size = _size
	if _mode != "read":
		Progress.reset_progress()
		Progress.intro_seen = true
		Progress.prologue_seen = true
		Progress.settings.ui_scale = 1.25
		Progress.settings.reduced_motion = true
		Progress.settings.fullscreen = false
		for index in range(1, 7):
			Progress.grant_photo("photo-welcome-game-%d" % index)
		check(Progress.set_current_region("candy"), "six synthetic admission cards open the factory")
	_main = load("res://game/main.tscn").instantiate()
	get_tree().root.add_child(_main)
	_main.ui.child_entered_tree.connect(func(child: Node):
		if child.get_script() == Session:
			child.ready.connect(func(): child.set_process(false), CONNECT_ONE_SHOT)
	)
	await frames(8)
	check(get_viewport().get_visible_rect().size == Vector2(_size), "actual native viewport dimension")
	check(Paper.text_scale() == 1.25 and Paper.reduced_motion(), "live 1.25 text scale and reduced motion")
	check(Catalog.identity(GAME) == {"id": GAME, "mode": "bean_seesaw", "zone": "candy", "local_index": 7,
		"photo_id": ORDINARY, "devil_photo_id": DEVIL, "achievement_id": ACHIEVEMENT}, "fixed seventh regional identifiers")
	if _mode == "read":
		await read_profile()
	elif await station():
		if _mode == "suite":
			await run_suite()
		else:
			await run_retake()
		check(Progress.save_progress(), "save accepts the live profile")
		var profile := profile_data()
		write_json(_save.get_base_dir().path_join("native-originals.json"),
			{"save_path": _save, "save_sha256": FileAccess.get_sha256(_save), "profile": profile})
		_data["profile"] = profile
	if is_instance_valid(_main):
		_main.quitting = true
		var playbacks: Array[WeakRef] = Release.capture(_main.audio)
		_main.audio.shutdown()
		_main.queue_free()
		await frames(3)
		check(await Release.wait_for_release(get_tree(), playbacks), "native audio releases all stopped playback before exit")
	for error in _errors:
		push_error(error)
	write_json(_out.path_join("bean-evidence.json"), {"mode": _mode, "size": [_size.x, _size.y], "checks": _checks,
		"errors": _errors, "results": _results, "captures": _captures, "data": _data})
	print("Bean seesaw native: %d checks, %d failures" % [_checks, _errors.size()])
	if _errors.is_empty():
		print("PASS: bean seesaw native flow")
	get_tree().quit(0 if _errors.is_empty() else 1)

func station() -> bool:
	check(_main.world_region == "candy", "normal Main loads saved candy region")
	var point: Dictionary = _main.world._point_by_id(GAME)
	check(not point.is_empty(), "real factory has a seventh station")
	if point.is_empty():
		return false
	_main.world.player.position = point.position
	_main.world.player.velocity = Vector3.ZERO
	for tick in 4:
		await get_tree().physics_frame
	check(_main.world.nearest.get("id", "") == GAME, "grounded actor can select the seventh physical station")
	await capture("factory-entrance")
	await key(KEY_E)
	await frames(4)
	return check(_main.modal_kind == "game_info" and _main.overlay.find_child("InviteTitle", true, false).text == "糖豆蹺蹺板", "actual E opens the station invitation")

func run_suite() -> void:
	await activate(_main.overlay, "InviteRules")
	check(_main.modal_kind == "game_rules", "actual invitation opens the rules")
	await capture("rules")
	await key(KEY_ESCAPE)
	await key(KEY_M)
	await activate(_main.overlay, "TicketAction0")
	await activate(_main.overlay, "RegionGamesButton")
	var grid := _main.overlay.find_child("RegionalGameEntriesGrid", true, false) as Control
	check(grid != null and grid.get_child_count() == 7, "region map lists the full seven playable stations")
	await capture("factory-map")
	await activate(_main.overlay, "HarborGame" + GAME)
	if not await start_first(true) or not await solve(false):
		return
	check(_main.modal_kind == "result" and Progress.coins == 160 and Progress.wardrobe_rewarded_games.count(GAME) == 1
		and Progress.achievements.has(ACHIEVEMENT), "formal ordinary clear grants the fixed achievement and 40 coins once")
	check(Progress.photos.has(ORDINARY) and not Progress.photos.has(DEVIL), "ordinary result awards just the ordinary card")
	await capture("ordinary-result")
	var first_layout: int = _data.layout
	await press(find_button(_main.modal_footer, "輔助重試"))
	if not bind_game():
		return
	check(_game._driver_state.layout != first_layout and _game._driver_state.assisted, "assisted replay switches hopper positions and widens the target")
	await key(KEY_R)
	check(_game._driver_state.helper, "native R enables the real beam helper")
	if not await solve(true):
		return
	check(_results.size() == 2 and _results[1].success and _results[1].devil and Progress.coins == 160, "rebound on the other layout never duplicates the reward")
	check(Progress.photos.get(DEVIL, {}).get("challenge_earned", false), "true rebound grants the devil challenge card")
	await capture("devil-result")
	await press(find_button(_main.modal_footer, "練習操作"))
	if not bind_game():
		return
	check(_game.practice_mode, "actual result button starts practice")
	await pause_and_leave()
	check(Progress.coins == 160 and _results.size() == 2, "practice cancellation leaves rewards unchanged")

func run_retake() -> void:
	await activate(_main.overlay, "InviteRules")
	await activate(_main.overlay, "KioskRetakeDevil")
	if not bind_game():
		return
	check(_game.practice_mode, "selected retake opens actual practice first")
	await pause_and_leave()
	var panel: Control = _main.retake_panel
	check(is_instance_valid(panel) and panel._valid and _main.retake_target == {"id": GAME, "devil": true}, "practice exit opens only the selected retake set")
	if not is_instance_valid(panel):
		return
	await activate(panel, "RetakeNext")
	await activate(panel, "FramingChoice")
	await activate(panel, "RetakeNext")
	var shots: Array[Image] = []
	panel.capture_requested.connect(func(image: Image): shots.append(image))
	await activate(panel, "RetakeShutter")
	await frames(7)
	var original: Dictionary = Progress.photos.get(DEVIL, {}).duplicate(true)
	check(shots.size() == 1 and panel._saved and original.get("acquisition_method") == "retake" and not original.get("challenge_earned", true)
		and not Progress.photos.has(ORDINARY) and Progress.coins == 160, "real shutter saves only the selected retake and one award")
	if shots.size() != 1 or original.get("original_frames", []).is_empty():
		return
	var stored := Image.load_from_file(original.original_frames[0])
	var camera := shots[0]
	camera.convert(Image.FORMAT_RGBA8)
	stored.convert(Image.FORMAT_RGBA8)
	check(stored.get_size() == Vector2i(1280, 720) and camera.get_data() == stored.get_data(), "saved original matches the live shutter pixel for pixel")
	check(camera.save_png(_out.path_join("shutter-original.png")) == OK, "record actual retake original")
	_captures.append("shutter-original.png")
	var original_hash: String = FileAccess.get_sha256(original.original_frames[0])
	await capture("retake-saved")
	await activate(panel, "RetakeClose")
	await key(KEY_E)
	if not await start_first(false) or not await solve(true):
		return
	var updated: Dictionary = Progress.photos.get(DEVIL, {})
	check(updated.get("acquisition_method") == "retake" and updated.get("challenge_earned", false)
		and updated.get("original_frames") == original.original_frames and updated.get("frames") == original.frames
		and FileAccess.get_sha256(original.original_frames[0]) == original_hash and Progress.coins == 160,
		"matching formal challenge preserves retake original and still recognises the real achievement")

func start_first(review_lesson: bool) -> bool:
	await activate(_main.overlay, "InviteStart")
	var panel: Control = _main.tutorial_panel
	if not check(is_instance_valid(panel) and _main.tutorial_target == GAME, "first entry displays the real 031 tutorial"):
		return false
	if review_lesson:
		for slide in 3:
			var texture: Texture2D = panel._image.texture
			check(texture != null and texture.resource_path == "res://assets/ui/tutorials/game-031-step-%02d.png" % (slide + 1)
				and texture.get_size() == Vector2(1280, 720), "native screenshot binds to the correct tutorial slide")
			var covered: Array = []
			for page in panel._copy_pages.size():
				if page > 0:
					await activate(panel, "TutorialCopyNext")
				var group: Control = panel._copy_pages[page]
				covered.append_array(group.get_meta("semantic_indices"))
				check(panel._copy_page == page and group.is_visible_in_tree(), "all tutorial copy can be read in order")
				await capture("tutorial-%d-page-%d" % [slide + 1, page + 1])
			check(covered == [0, 1, 2, 3, 4], "all five semantic fields are reachable")
			if slide < 2:
				await press(panel._next_button)
	await press(panel._start_button)
	check(Progress.has_seen_tutorial(GAME) and Progress.has_attempted_game(GAME), "normal entry saves tutorial and actual attempt")
	return bind_game()

func bind_game() -> bool:
	_game = _main.session
	if not check(is_instance_valid(_game) and _game.game_id == GAME and is_instance_valid(_game.presentation), "normal Main creates the real 3D Session"):
		return false
	_game.set_process(false)
	_game.finished.connect(func(result: Dictionary): _results.append(result.duplicate(true)))
	return true

func solve(rebound: bool) -> bool:
	var board: Control = _game.presentation
	var layout: int = _game._driver_state.layout
	_data["layout"] = layout
	for index in View.BUTTONS.size():
		var hitbox := View.button_rect(index)
		var button: Button = board._buttons[index]
		check(button.get_rect() == hitbox, "rendered control matches the full active hitbox")
		var rect: Rect2 = board.get_global_transform_with_canvas() * hitbox
		check(get_viewport().get_visible_rect().encloses(rect) and rect.size.y >= 44.0, "control fits with 44px touch height")
		check(not board._get_tooltip(View.button_rect(index).get_center()).is_empty(), "control offers concise hover")
	await tap(board, 2, false)
	check(_game.active_driver.snapshot().pedal == 0, "real mouse moves the pedal to its centre")
	advance(0.55)
	await tap(board, View.HOPPER_LEFT, true)
	check(_game.active_driver.snapshot().beans[0].phase == 1, "real single-finger GUI event releases the left bean")
	await key(KEY_E)
	check(_game._driver_state.beans[1].phase == 1, "real keyboard opens the right hopper")
	advance(0.35)
	await capture("layout-%d-drops" % layout)
	advance(2.5)
	if not check(_game._driver_state.paired and not _game._driver_state.side_catch, "real timed drops hit both pans before the rebound"):
		return false
	_data["pair-%d" % layout] = _game._driver_state.duplicate(true)
	await capture("layout-%d-synchronised" % layout)
	if rebound:
		await key(KEY_END)
		advance(0.60)
		await tap(board, View.HOPPER_RIGHT, true)
		advance(0.50)
		await key(KEY_HOME)
		for tick in 50:
			advance(1.0 / 120.0)
			if _game._driver_state.beans[1].rebounded:
				break
		check(_game._driver_state.beans[1].rebounded, "right rising end launched a genuinely light bean")
		advance(0.31)
		await capture("right-light-rebound")
		advance(1.15)
	else:
		await key(KEY_F)
		advance(0.02)
	await frames(6)
	return check(_main.session == null and _main.modal_kind == "result" and not _results.is_empty()
		and _results.back().success and _results.back().devil == rebound, "real Main resolves the expected formal result")

func pause_and_leave() -> void:
	await key(KEY_ESCAPE)
	var before: Dictionary = _game._driver_state.duplicate(true)
	if not check(_game.paused, "real Escape pauses"):
		return
	await key(KEY_HOME)
	advance(1.0)
	check(_game._driver_state == before, "paused input does not move the seesaw or advance time")
	await capture("practice-paused")
	await activate(_game.minigame_hud, "LeaveButton")
	await activate(_game.minigame_hud, "ConfirmAction")
	check(_main.session == null, "real HUD cancellation returns to Main")

func profile_data() -> Dictionary:
	var hashes := {}
	for id in [ORDINARY, DEVIL]:
		var record: Dictionary = Progress.photos.get(id, {})
		var width := Vector2i(1280, 720) if record.get("acquisition_method") == "retake" else _size
		var originals: Array = record.get("original_frames", [])
		var thumbs: Array = record.get("frames", [])
		check(not originals.is_empty() and thumbs.size() == originals.size(), "each published card has paired originals and thumbnails")
		for group in [[originals, width],[thumbs, Vector2i(320, 180)]]:
			for path: String in group[0]:
				var image := Image.load_from_file(path)
				check(image != null and image.get_size() == group[1], "actual saved image decodes at expected size")
				hashes[path] = FileAccess.get_sha256(path)
	return {"coins": Progress.coins, "region": Progress.current_region, "photos": Progress.photos.duplicate(true),
		"hashes": hashes, "achievement": Progress.achievements.has(ACHIEVEMENT), "reward": Progress.wardrobe_rewarded_games.count(GAME),
		"tutorial": Progress.has_seen_tutorial(GAME), "attempt": Progress.has_attempted_game(GAME)}

func read_profile() -> void:
	var meta: Variant = JSON.parse_string(FileAccess.get_file_as_string(_save.get_base_dir().path_join("native-originals.json")))
	if not check(meta is Dictionary and meta.get("save_path") == _save and meta.get("save_sha256") == FileAccess.get_sha256(_save), "fresh process reads the exact paired writer save"):
		return
	var expected: Dictionary = meta.profile
	var actual := profile_data()
	check(actual.photos == expected.photos and actual.hashes == expected.hashes and actual.coins == 160 and actual.region == "candy"
		and actual.achievement and actual.reward == 1 and actual.tutorial and actual.attempt, "reload retains original pixels, provenance, region, tutorial, attempt and award")
	await key(KEY_M)
	await activate(_main.overlay, "TicketAction2")
	check(_main.modal_kind == "album", "reopened normal Main album")
	await capture("reopened-album")
	_data["profile"] = actual

func advance(seconds: float) -> void:
	for tick in roundi(seconds * 120.0):
		if not is_instance_valid(_game) or _main.session != _game:
			return
		_game._process(1.0 / 120.0)

func tap(board: Control, button: int, touch: bool) -> void:
	var point: Vector2 = board.get_global_transform_with_canvas() * View.button_rect(button).get_center()
	for down in [true, false]:
		var event: InputEvent
		if touch:
			var input := InputEventScreenTouch.new()
			input.index = 0
			input.pressed = down
			input.position = point
			event = input
		else:
			var input := InputEventMouseButton.new()
			input.button_index = MOUSE_BUTTON_LEFT
			input.button_mask = MOUSE_BUTTON_MASK_LEFT if down else 0
			input.pressed = down
			input.position = point
			input.global_position = point
			event = input
		Input.parse_input_event(event)
		Input.flush_buffered_events()
		await frames(1)

func key(code: int) -> void:
	for down in [true, false]:
		var event := InputEventKey.new()
		event.keycode = code
		event.physical_keycode = code
		event.pressed = down
		Input.parse_input_event(event)
		Input.flush_buffered_events()
		await frames(1)

func press(button: Button) -> void:
	if not check(is_instance_valid(button) and button.is_visible_in_tree() and not button.disabled, "visible GUI button is interactive"):
		return
	button.grab_focus()
	await key(KEY_ENTER)
	await frames(4)

func activate(parent: Node, name_to_find: String) -> void:
	await press(parent.find_child(name_to_find, true, false) as Button)

func find_button(parent: Node, label: String) -> Button:
	for child in parent.find_children("*", "Button", true, false):
		if child.text == label:
			return child
	return null

func frames(count: int) -> void:
	for frame in count:
		await get_tree().process_frame

func capture(label: String) -> void:
	await frames(2)
	await RenderingServer.frame_post_draw
	var shot := get_viewport().get_texture().get_image()
	check(shot != null and shot.get_size() == _size and shot.save_png(_out.path_join(label + ".png")) == OK, "actual GPU screenshot " + label)
	_captures.append(label + ".png")

func check(ok: bool, message: String) -> bool:
	_checks += 1
	if not ok:
		_errors.append(message)
	return ok

func write_json(path: String, value: Dictionary) -> void:
	var stream := FileAccess.open(path, FileAccess.WRITE)
	if stream == null:
		push_error("Cannot write isolated native evidence " + path)
		get_tree().quit(1)
		return
	stream.store_string(JSON.stringify(value, "  ") + "\n")
