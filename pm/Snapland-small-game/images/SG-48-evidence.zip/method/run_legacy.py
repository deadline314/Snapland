"""Open an accepted pre-seesaw QA save in a disposable current project."""
from pathlib import Path
import json
import shutil
import sys

q=Path(__file__).resolve().parent
source=(q.parent/"art16-longitudinal-pivot-study-20261119/verify.py").read_text("utf8")
exec(compile(source[:source.index("def record(")],str(q/"run_legacy.py"),"exec"))
fixture="game/tests/test_bean_legacy_profile.gd"
fixtures={fixture:HERE/"legacy_fixture.gd"}
runner.FIXTURES=list(fixtures)
runner.MARKER="Bean legacy save:"
prior=Path("D:/Snapland-QA/cotton-wind/final-fix/small-suite-1119-043557-38fc28")
old=prior/"save/progress.json"
receipt=runner.read(prior/"receipt.json")
assert receipt["passed"] and Path(receipt["environment"]["SNAPLAND_SAVE_PATH"])==old
provenance=runner.read(prior/"save/native-originals.json")
assert provenance["save_sha256"]==runner.sha(old)
folder,project,graph=stage("legacy",Path(sys.argv[1]))
keys=runner.environment(folder)
runner.preflight(folder,project,keys)
target=Path(keys["SNAPLAND_SAVE_PATH"])
source_digest=runner.sha(old)
record=runner.read(old)
mapped={}
def fix(value):
    if isinstance(value,dict):
        return {key:fix(item) for key,item in value.items()}
    if isinstance(value,list):
        return [fix(item) for item in value]
    if isinstance(value,str) and value.replace("\\","/").startswith(old.parent.as_posix()+"/"):
        original=Path(value).resolve()
        relative=original.relative_to(old.parent.resolve())
        copied=target.parent/relative
        copied.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(original,copied)
        assert runner.sha(original)==runner.sha(copied)
        mapped[value]={"fixture_copy":copied.as_posix(),"sha256":runner.sha(copied)}
        return copied.as_posix()
    return value
target.write_text(json.dumps(fix(record),ensure_ascii=False)+"\n","utf8")
assert mapped
copied_sha=runner.sha(target)
runner.dump(folder/"migration-proof.json",{"before_source":prior.as_posix(),"old_sha256":source_digest,
    "test_copy_sha256":copied_sha,"localized_original_and_thumbnail_files":mapped})
def confirmed(actual,stage,env):
    assert actual==folder and stage==project and env==keys and runner.sha(target)==copied_sha
runner.preflight=confirmed
runner.launch(folder,project,graph,"legacy",[runner.ENGINE,"--headless","--path",project,"--script","res://"+fixture],keys)
assert runner.sha(target)==copied_sha and runner.sha(old)==source_digest
print((folder/"stdout.log").read_text("utf8").splitlines()[-1])
print(folder.as_posix())
