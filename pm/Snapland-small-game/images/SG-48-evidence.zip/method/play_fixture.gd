extends Node

const Session = preload("res://game/minigames/session.gd")
var _game: Control
var _out := ""
var _checks := 0
var _failed := false

func _ready() -> void:
	call_deferred("_run")

func _run() -> void:
	_out = OS.get_environment("COTTON_CAPTURE_DIR")
	var save := OS.get_environment("SNAPLAND_SAVE_PATH")
	if not _out.is_absolute_path() or not save.is_absolute_path() or save.get_base_dir() == _out:
		finish(false)
		return
	get_window().content_scale_mode = Window.CONTENT_SCALE_MODE_DISABLED
	get_window().size = Vector2i(1280, 720)
	_game = Session.new()
	add_child(_game)
	_game.set_process(false)
	_game.start("game-031")
	check(_game.active_driver != null, "seesaw Session")
	if _failed:
		finish(false)
		return
	await frames(5)
	await key(KEY_A)
	advance(0.55)
	await key(KEY_Q)
	await key(KEY_E)
	advance(0.33)
	await capture("game-031-step-01")
	advance(2.55)
	check(_game._driver_state.paired and not _game.ended, "separate catches within the live pair window")
	await capture("game-031-step-02")
	await key(KEY_END)
	advance(0.6)
	await key(KEY_E)
	advance(0.50)
	await key(KEY_HOME)
	for tick in 50:
		advance(1.0 / 120.0)
		if _game._driver_state.beans[1].rebounded:
			break
	check(_game._driver_state.beans[1].rebounded, "right end launched a live light bean")
	advance(0.34)
	await capture("game-031-step-03")
	advance(2.0)
	check(_game.won and _game.devil_won, "rebound landed in the real side slot")
	await capture("seesaw-result-preview")
	finish(not _failed)

func check(ok: bool, message: String) -> void:
	_checks += 1
	if not ok:
		_failed = true
		push_error(message)

func advance(seconds: float) -> void:
	for tick in roundi(seconds * 120.0):
		_game._process(1.0 / 120.0)

func frames(count: int) -> void:
	for frame in count:
		await get_tree().process_frame

func key(code: int) -> void:
	for down in [true, false]:
		var event := InputEventKey.new()
		event.physical_keycode = code
		event.keycode = code
		event.pressed = down
		Input.parse_input_event(event)
		await frames(1)

func capture(name: String) -> void:
	await frames(2)
	await RenderingServer.frame_post_draw
	var image := get_viewport().get_texture().get_image()
	check(image != null and image.save_png(_out.path_join(name + ".png")) == OK, "rendered " + name)

func finish(ok: bool) -> void:
	print("BEAN QA: %d checks" % _checks)
	if ok:
		print("PASS: bean seesaw native preview")
	get_tree().quit(0 if ok else 1)

