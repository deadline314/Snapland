"""Run Main-based seesaw proof in fresh isolated staging directories."""
from pathlib import Path
import sys

q=Path(__file__).resolve().parent
source=(q.parent/"art16-longitudinal-pivot-study-20261119/verify.py").read_text("utf8")
source=source[:source.index("def record(")]
marker='exec(compile(source,str(HELPER),"exec"),runner.__dict__)'
assert source.count(marker)==1
source=source.replace(marker, 'source=source.replace("cotton-evidence.json","bean-evidence.json")'+chr(10)+marker)
exec(compile(source,str(q/"run_main.py"),"exec"))
FIXTURE="game/tests/native_bean_seesaw_review"
fixtures={FIXTURE+ext:HERE/("main_fixture"+ext) for ext in (".gd",".tscn")}
fixtures["game/tests/audio_playback_release.gd"]=ROOT/"game/tests/audio_playback_release.gd"
runner.FIXTURES=list(fixtures)
runner.MARKER="PASS: bean seesaw native flow"

def launch_game(mode,donor,size,save=None,binary=None,pinned=None):
    folder,path,graph=stage(mode+("-embedded" if binary else ""),donor)
    flags=["--rendering-method","gl_compatibility","--audio-driver","Dummy","--fixed-fps","60"]
    if binary:
        runner.qa_override(path,pinned)
        build=runner.read(binary.parent.parent/"build.json")
        assert runner.sha(binary)==build["binary"]["sha256"]
        assert all(runner.sha(path/name)==digest for name,digest in build["runtime_sha256"].items())
        command=[binary,*flags]
    else:
        command=[runner.ENGINE,"--path",path,"res://"+FIXTURE+".tscn",*flags]
    runner.launch(folder,path,graph,mode,command,runner.environment(folder,mode,size,save),binary.parent if binary else None)
    report=runner.read(folder/"captures/bean-evidence.json")
    assert report["mode"]==mode and not report["errors"] and report["checks"]>0
    print(folder.as_posix(),report["checks"],flush=True)
    return folder


def export(donor):
    folder,path,graph=stage("export",donor)
    pinned=runner.templates(folder)
    runner.SCENE=FIXTURE+".tscn"
    runner.qa_override(path,pinned)
    release=folder/"release"
    release.mkdir()
    exe=release/"BeanSeesawQA.exe"
    runner.launch(folder,path,graph,"export",[runner.ENGINE,"--headless","--path",path,"--editor","--export-release","Windows Desktop",exe,"--quit"],runner.environment(folder))
    assert exe.stat().st_size>pinned["release"]["bytes"] and sorted(release.glob("*.pck"))==[]
    runner.dump(folder/"build.json",{"binary":runner.describe(exe),"templates":pinned,
        "source":runner.describe(folder/"source-graph.json"),"runtime_sha256":runner.read(folder/"runtime-graph.json"),
        "export":runner.describe(folder/"receipt.json")})
    return folder, exe, pinned


mode=sys.argv[1]
donor=Path(sys.argv[2])
size=sys.argv[3] if len(sys.argv)>3 else "1280x720"
if mode=="package":
    folder,exe,pinned=export(donor)
    writer=launch_game("suite",donor,size,binary=exe,pinned=pinned)
    reader=launch_game("read",donor,size,writer/"save/progress.json",binary=exe,pinned=pinned)
    runner.dump(folder/"embedded-acceptance.json",{"writer":runner.describe(writer/"receipt.json"),"reader":runner.describe(reader/"receipt.json")})
elif mode=="suite" or mode=="retake-devil":
    writer=launch_game(mode,donor,size)
    launch_game("read",donor,size,writer/"save/progress.json")
else:
    raise ValueError(mode)
