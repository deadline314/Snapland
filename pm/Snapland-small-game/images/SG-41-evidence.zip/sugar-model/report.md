# SG-41 Task 1 model evidence

Owned files: `game/minigames/sugar_bridge_model.gd`, `game/tests/test_sugar_bridge.gd`.
No shared runtime, registry, ticket or Git edits. No editor/import launch.

## Scope and routes

The pure RefCounted model has the frozen public API:
`reset(assisted=false, variant=0)`, `select_next(direction)`, `grab_selected()`,
`move_selected(Vector2)`, `release_selected()`, `toggle_pin()`, `recall_selected()`,
`cycle_helper()`, `load_ball()`, `clear_input()`, `step(delta)`, `snapshot()`.
`step` returns a detached snapshot. No extra public query helpers were needed.

Long bridge: endpoints 0/1 to anchors 0/2, load one ball and advance 14 seconds;
repeat three times. Short bridge: 0/1 to anchors 0/1, 2/3 to anchors 1/2;
three simultaneous loads and 14 seconds deliver all. Both layouts pass unchanged
frozen material constants. Capacity = 5.5 * (4 / max(.25,length))^2 * elasticity;
long capacities approximately 1.375 / 1.273 exceed a single .85 / .95 ball,
and are less than two balls. Short capacities exceed all three balls.

Sling route: pin first end at origin, drag second to
`(hopper + Vector2(0,2.4*.9*.9)) / (1-4*elasticity*.9)`, release, advance 1.2s.
The bean follows exact ballistic substeps and swept segment/circle contact, not
an injected hit. Pin the same band's two ends to the banks, then actually deliver
three balls. A delivered ball must record a traversal after the hit in the current
generation. Recalled/broken material clears all old generation references.

## RED and GREEN

Both launches used this command in a Python script run from repository root:

```python
import os
from pathlib import Path
from tools.godot_entrypoints import run_validated_godot
root = Path.cwd()
env = os.environ.copy()
env['SNAPLAND_SAVE_PATH'] = str(root / '.review/sugar-model/green-save.json')
result = run_validated_godot(root, [
    'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',
    '--headless', '--path', str(root),
    '--script', 'res://game/tests/test_sugar_bridge.gd'], env, 40)
print(result.returncode, result.stdout, result.stderr)
```

RED used `red-save.json`, before creating the model. Corrected an initially
untyped Vector2 test local, then reran RED to isolate the intended failure:

```text
RED exit: 1
SCRIPT ERROR: Parse Error: Preload file "res://game/minigames/sugar_bridge_model.gd" does not exist.
```

Initial GREEN: 39 checks, 0 failures. Added negative generation/traversal,
drag cancellation, clamped motion, active-ball duplication, central dead-end,
moving-ball disconnect and assisted devil checks. Final GREEN:

```text
GREEN exit: 0
Godot Engine v4.7.2.stable.official.ed1daf0bf
Sugar bridge: 48 checks, 0 failures
```

Full launch output: `red.log`, `green.log` in this directory.

## Snapshot contract

- Required outcomes: `elapsed`, `remaining`, `ended`, `success`, `devil`,
  `devil_success`, `ordinary_eligible`, `score`, `mistakes`, `falls`, `breaks`,
  `delivered`, `participated`, `feedback`, `last_event`.
- Configuration: `assisted`, `variant`, `variant_name`, `weight`, `elasticity`,
  `bounds:Rect2`, `anchors:Array[Vector2]`, `hopper:Vector2`, `hopper_radius`.
- Input: `selected:int` 0..3, `grabbed:int` (-1 means none), `helper:Array[bool]` length4.
- `endpoints` length4: `{id, band, position:Vector2, pin:int, held:bool}`.
  `pin` is -1 free or 0..2 anchor. `held` includes AI and human ownership.
- `bands` length2: `{id,generation,broken,hit,length,thickness,capacity,load,sag,
  connected,points:Array[Vector2]}`. Curves have 17 ordered left-to-right points.
- `balls` length3: `{id,state,position,velocity,band,progress,traversed}`.
  State is `unused`, `rolling`, `falling`, `fallen`, `delivered`; progress is 0..1;
  `band=-1` when absent; `traversed` has two generation slots (-1 absent).
- `bean`: `{active,position,velocity,band,generation,hit}`; one reusable projectile.
- `preview:Array[Vector2]`: empty or 31 ballistic points while holding a
  free endpoint whose opposite end is pinned.

All returned nested dictionaries/arrays are detached. Storage consists of
two material records, four endpoints, three balls, one bean and bounded generation
references. No histories grow over time.

## Checks and limits

The 48 checks exercise actual commands, geometry, integration and contact;
tests do not inject score, hit, success or internal material state. They cover
all required model paths, malformed floating-point deltas/motion, zero length,
maximum extension, detached nested snapshot data, safe single drag cancellation,
AI holding only and ordinary-card participation truthfulness.

Analytic sag is a deterministic quasi-static material curve, not a full soft-body
simulation. Ball transport integrates curve slope/arc distance; bean integration
uses ballistic motion and continuous segment contact. Assistance changes only
snap/hopper tolerance; AI never chooses anchors or loads balls. Models do not
touch player saves. Practice/cancel rewards, input mapping, 3D presentation,
native screenshots and full session integration are owned by the other tasks;
this evidence is scripted model validation, not human playtesting.

## Fresh review fix round 1: physical AI holding

The reviewer correctly found that an unpinned free endpoint stayed stationary,
so the original helper flag did not change physical behavior. Added bounded
vertical gravity for exactly four endpoint velocities. A free endpoint settles
to the existing workbench lower boundary, y=-3; pinned, grabbed or AI-held ends
remain where the player put them. Explicit pointer movement, grabbing, pinning,
helper changes and recall clear the affected stale velocity. No public API or
snapshot shape changed. Helper still cannot choose positions, pin, shoot or load.

Six additional checks compare the same initial endpoint held/free, disable the
helper to release it, keep a grabbed point stationary, cancel without shooting
with reset velocity, pin after falling, and stop safely at the lower catch.

Command: same `run_validated_godot` Python launch above, with save paths
`.review/sugar-model/helper-red-save.json` and `helper-green-save.json`.
Logs: `helper-red.log`, `helper-green.log`.

```text
RED exit: 1
Sugar bridge: 54 checks, 4 failures
ERROR: AI physically holds the specified endpoint while a free endpoint settles
ERROR: disabling AI releases endpoint to gravity
ERROR: pointer motion resets velocity and cancel releases without shooting
ERROR: free endpoints stop at the bounded workbench catch

GREEN exit: 0
Sugar bridge: 54 checks, 0 failures
```

All existing 48 actual transport, projectile, qualification, recovery and safety
checks continue passing with gravity. No material constants were calibrated.

## Fresh review fix round 2: bounded physical feed spacing

Root identified three immediate loads were superimposed throughout transport.
The same three ball records now enter `queued` on the left bank at x=-0.45,
-0.90 and -1.35 with 0.45 spacing. Each moves toward x=0 at the existing 1.6
transport speed, then enters the actual outgoing bridge (or falls if absent).
Only supported `rolling` balls count toward material load. No extra queue
container, fake progress, additional ball or visual offset was introduced.

Public API and snapshot fields remain unchanged; ball state's value set now
also includes `queued`, which the controls/view worker was notified to render.
Short-bridge simultaneous-three sampling starts at 1.1 seconds after real feed;
all original delivery, overload/recovery and qualification routes still pass.

Same validated launcher command above, save files
`.review/sugar-model/queue-red-save.json` and `queue-green-save.json`;
full logs `queue-red.log`, `queue-green.log`.

```text
RED exit: 1
Sugar bridge: 60 checks, 7 failures
ERROR: three real feed positions stay visibly separate before entering
ERROR: left bank feed queue does not count as bridge load
ERROR: three actually rolling balls remain visibly separated
ERROR: loading never duplicates an active feed ball

GREEN exit: 0
Sugar bridge: 63 checks, 0 failures
```

The seven RED failures are the three spacing/load checks in each layout and
the fixed-pool active feed check. Final GREEN adds whole-route half-second
rolling-separation samples for both layouts and proves the second queued ball
does not overload a long bridge before it enters. Once both actually enter,
the long material breaks and actual falls/recovery retain their expected score.
