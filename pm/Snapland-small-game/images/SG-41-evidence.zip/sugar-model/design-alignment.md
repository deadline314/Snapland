# SG-41 Candy design/runtime alignment

Owned follow-up files only:

- `tools/verify_design.py`
- `tests/test_design_validation.py`
- `design/02-minigames/catalog.json`

Added `CANDY_DELIVERED = 1` to the existing delivered-count rule and an explicit
Candy runtime input to `validate_runtime_game_alignment` plus every Python
caller. Candy coverage must contain exactly local index 1, zone `candy`,
ID `game-025`. Existing Harbor count/order/zone/local-index enforcement remains.
Alignment now compares Candy's live name, instructions, ordinary requirement,
devil requirement and mode using the same drift checks as the earlier games.

Catalog game-025 now matches current `game/data/candy_games.json` exactly for:

- action: `抓端、拉糖搭橋，再逐球上料`
- goal: `三顆運料球送到右岸`
- demon: `同一條糖帶先彈中料斗再運糖`
- runtime_mode: `sugar_bridge`
- implementation: `single_player_runtime_needs_full_acceptance`

Other mechanics stay intact. Game-026 is now the first unbuilt game, and the
existing test that rejects fabricated runtime delivery was moved to that row.

## RED

Before validator/catalog changes, ran:

```text
python -m unittest discover -s tests -p test_design_validation.py -v
Ran 43 tests in 0.237s
FAILED (failures=1, errors=8)
```

The new delivery assertion failed because game-025 still claimed design-only;
the explicit Candy API calls failed because alignment still accepted only three
arguments. New tests require exact delivered Candy coverage and reject mutated
name/action/goal/demon/mode rules.

## GREEN

After the scoped changes, ran:

```text
python -m unittest discover -s tests -p test_design_validation.py -v
Ran 43 tests in 0.179s
OK

python tools/verify_design.py --scope games
PASS games
PASS 1 design scope(s); gameplay/playtesting not executed
```

Both commands exited 0. No engine, Git mutations or ticket operations were run. This is
data and validator verification; it does not claim game playtest acceptance.
