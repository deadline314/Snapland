# SG-41 runtime suite registration

Status: DONE. Owned changes only `tools/run_game_tests.py` and `tests/test_runtime_result_contract.py`. No engine launch, Git, PM, Main/session or other shared-file edits.

Read the actual print statements in the five sugar GDScript suites before registering their existing source entries and exact completion markers:

| Label | Entry | Exact marker |
|---|---|---|
| sugar model tests | test_sugar_bridge.gd | Sugar bridge: 63 checks, 0 failures |
| sugar driver tests | test_sugar_bridge_driver.gd | Sugar bridge driver: 51 checks, 0 failures |
| sugar view tests | test_sugar_bridge_view.gd | Sugar bridge view: 55 checks, 0 failures |
| sugar Session tests | test_sugar_bridge_session.gd | Sugar bridge Session: 21 checks, 0 failures |
| sugar Main tests | test_sugar_bridge_main.tscn | PASS: sugar Main candy entry, tutorial, real results, fixed rewards, selected retake originals and reload |

The four SceneTree suites use `--script`; Main uses its real `.tscn` scene. Added `sugar ` to the established exact-prefix tuple so marker suffixes cannot pass. No new execution mechanism or dependencies.

Two focused Python tests verify all five distinct registered labels/entries/markers, script-versus-scene launch syntax, clean CRLF completion, rejection of absent/quoted/suffixed/nonzero-failure/FAIL markers, stderr-only completion, ERROR/SCRIPT ERROR on both streams, and a nonzero exit despite the correct marker. Existing fake-engine runner tests also cover the enlarged catalog, per-suite profile isolation, complete dispatch, stop/keep-going and contract completeness. They mock engine processes and do not launch Godot.

Red command:
```text
python -m unittest tests.test_runtime_result_contract.SugarRunnerTests -v
```

Before registration: `Ran 2 tests ... FAILED (failures=6)` — all five labels had no completion marker and zero sugar suites were registered. After adding entries/markers but before strict-prefix registration: `Ran 2 tests ... FAILED (failures=5)` — each `... suffix` marker was incorrectly accepted. This second red specifically proves the exact-prefix guard matters.

Green command:
```text
python -m unittest tests.test_runtime_result_contract -v
```

Exact final summary:
```text
Ran 22 tests in 4.074s

OK
```

No actual Godot suites reran under this scoped task, per root instruction; registration uses the root-verified 63/51/55/21 counts and actual source completion casing. No unresolved issue found.
