# Task 2: Sugar bridge driver and retained 3D workbench

Status: DONE; ready for controller's fresh task review. No Git, ticket, registry, Main, model or shared session changes.

Owned files:
- game/minigames/sugar_bridge_driver.gd
- game/minigames/sugar_bridge_view.gd
- game/tests/test_sugar_bridge_driver.gd
- game/tests/test_sugar_bridge_view.gd

Scope inspected before writing: frozen model API and detached snapshot fields, existing anchor/tide driver and view, session input forwarding/pause/score-result contract, Paper physical scaling, validated Godot launcher. Root owns callers/config/export/test registration. No dependency added and no save writes introduced by this task.

Driver shares one key map with focused view input. Keyboard Space toggles grab; arrows integrate absolute work coordinates; F pins/releases; Tab selects; Enter loads/retries; X recalls; R holds selected endpoint only. Actual mouse movement and touch drag go through the same model API, with one drag owner. Pointer release outside remains owned, nonfinite release cancels, emulated mouse is excluded. Lifecycle cancellation clears held keys and pointers without release/shot. Ended rounds clear input. Reset uses actual alternate material configurations.

View uses one isolated SubViewport/World3D with an orthographic Camera3D and real workbench, support meshes, material bands, four handle meshes, three delivery balls, a trial bean and side hopper. Fixed 64 band segments and 30 preview markers are allocated once; frame updates change transforms/material references only. Selection, held, pinned, helper and hit states are visible. Reduced motion removes no required physics and adds no decorative movement. Visible instructions and two-line controls retain a minimum physical font size of 14 pixels before text scaling; the 800-width/1.25 simulation checks the 17.5-pixel minimum and command/status widths. Actual native screenshots remain root's delivery verification.

Exact command used from the repository root (PowerShell here-string piped to Python):

```python
from pathlib import Path
import os
from tools.godot_entrypoints import run_validated_godot
root=Path.cwd(); out=root/'.review/sugar-controls'
for name in ['driver','view']:
    env=os.environ.copy(); env['SNAPLAND_SAVE_PATH']=str(out/f'{name}-save.json')
    cmd=['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--headless','--path',str(root),'--script',f'res://game/tests/test_sugar_bridge_{name}.gd']
    result=run_validated_godot(root,cmd,env,timeout=20)
    log=result.stdout+result.stderr
    (out/f'{name}-green.log').write_text(log,encoding='utf-8')
    print(name,result.returncode,log,flush=True)
```

Final output:
```text
driver 0 Godot Engine v4.7.2.stable.official.ed1daf0bf - https://godotengine.org
Sugar bridge driver: 44 checks, 0 failures
view 0 Godot Engine v4.7.2.stable.official.ed1daf0bf - https://godotengine.org
Sugar bridge view: 42 checks, 0 failures
```

Driver evidence includes complete keyboard-only short bridge with all three simultaneous balls, mouse/touch long bridge with real delivery, actual pointer sling trajectory hitting the hopper followed by same-band three-ball delivery and 500-point devil result, truthful practiced/idle/participated-timeout score summaries, retry configuration, invalid inputs, helper release, duplicate source and drag-owner rules. View evidence includes independently checked actual Camera3D.unproject_position against hit mapping for every endpoint; 100 frame updates, alternate layout and repeated teardown retain bounded nodes/meshes/materials; actual Input.parse_input_event focused Tab press/release routes to game selection instead of leaving it to normal focus navigation.

Earlier red checks: initial driver run reported `40 checks, 1 failures` because the F test attempted to pin outside the model snap tolerance; fixture now moves inside tolerance before F. First view run timed out after accessing an unnamed camera; production camera is explicitly named and projection checks pass. Physical-font test initially failed because headless SceneTree's tiny default root viewport was not configured; test now explicitly sets 1280×720 before simulating 800-width scale. These were fixture/presentation setup fixes; no physics or qualification shortcuts.

No editor/import/native process was launched, no game/ticket integration was finalized, and no assets outside ownership were edited. Controller should review task and run native three-size evidence as planned. No known unresolved implementation finding.

## Task 2 fix round 1/5

Addressed both fresh-review P2 findings in owned files only:

- After `cycle_helper()` cancels model grabbing, driver now clears its drag owner when the snapshot has no grabbed endpoint. Regression drives Space → R → immediate mouse grab, then Space → R → immediate touch grab; both previously failed and now succeed.
- Eight retained Label3D nodes now update pixel size from the actual SubViewport/orthographic-camera projection, parent world scale, physical canvas scale and Paper text scale. Their existing base size is preserved where readable, with a 14 physical-pixel minimum before the 1.25 preference. No nodes, meshes, fonts or materials are constructed in the update. Regression measures actual Camera3D.unproject_position for all eight label font heights at 0.625 canvas scale and 1.25 text: each is at least 17.5 physical pixels; every label also changes by exactly 1.25 when the preference changes. Fixed world spacing remains unchanged.

Covering tests: game/tests/test_sugar_bridge_driver.gd and game/tests/test_sugar_bridge_view.gd. Latest model queue state is rendered by the existing visibility policy and all real routes still pass.

Exact red/green command is the report's original Python invocation with these two substitutions: `env['SNAPLAND_SAVE_PATH']=str(out/f'{name}-fix1-save.json')` and log file `(out/f'{name}-fix1-red.log')` / `(out/f'{name}-fix1-green.log')`. It still uses `run_validated_godot`, `--headless`, project-local SceneTree scripts, and the same validated 4.7.2 executable; timeout 20 seconds. No import/editor/native run.

Red output before the production fix:
```text
driver 1
Sugar bridge driver: 47 checks, 2 failures
ERROR: mouse can grab immediately after Space then R
ERROR: touch can grab immediately after Space then R
view 1
Sugar bridge view: 50 checks, 8 failures
ERROR: world label respects enlarged physical font size [all 8 retained world labels]
```

Green output after the production fix and extra exact-1.25 regression:
```text
driver 0 Godot Engine v4.7.2.stable.official.ed1daf0bf - https://godotengine.org
Sugar bridge driver: 47 checks, 0 failures
view 0 Godot Engine v4.7.2.stable.official.ed1daf0bf - https://godotengine.org
Sugar bridge view: 51 checks, 0 failures
```

Native appearance at three sizes remains assigned to root; no further known open finding from this scoped fix.

## Standalone GPU visual preflight follow-up

Added only the authorized standalone fixture `game/tests/native_sugar_bridge_workbench_review.gd/.tscn`, plus scoped view/readability regression fixes. This fixture launches the real Driver.create_view() and uses Input.parse_input_event mouse press/move/release and key press/release events through actual focused GUI dispatch. It does not launch Main, inject model flags or award/save cards. Controlled stepping uses the normal driver step interface. Capture occurs after actual GPU `RenderingServer.frame_post_draw`.

Two requested native sizes completed: 800×600 with 1.25 text/reduced motion, and 1280×720 with default text. Each output directory has seven physical-size screenshots, actual-window/viewport assertions, actual command-rectangle bounds assertions, font width checks, report.json with snapshot provenance, and run.log:

- `.review/sugar-controls/native/800x600/`
- `.review/sugar-controls/native/1280x720/`

Screenshots are `01-initial`, `02-short-loaded`, `03-short-rolling`, `04-long-loaded`, `05-trial-pull`, `06-trial-hit`, `07-same-band-rolling`. They show distinct queued balls and real rolling on a short bridge; two actual queued loads on a long bridge; assisted pull held with trajectory; actual release/hopper hit; same-band rolling after the hit. The route then actually delivers three balls and asserts devil/500.

First native 800 run correctly failed `Sugar bridge standalone GPU: 36 checks, 1 failures` on the right-column legend `金色固定 · 白色抓取`. Shortening it to `金固定 · 白抓取` preserves meaning and fits. Visual inspection also found central endpoint numbers 2/3 overlapping when pinned together, and support names touching free-end numbers after the unused band settled. Endpoint labels now spread the finite coincident endpoint IDs horizontally; support names sit on the pedestals. Retained nodes/materials and actual endpoint positions do not change. Added the coincident-number regression, changing the view marker from 51 to 52 checks; root notified before registry changes.

Exact native command, from repository root:

```python
from pathlib import Path
import os
from tools.godot_entrypoints import run_validated_godot
root=Path.cwd(); base=root/'.review/sugar-controls/native'
for size in ['800x600','1280x720']:
    out=base/size
    env=os.environ.copy()
    env['SNAPLAND_SAVE_PATH']=str(out/'isolated-save-v3.json')
    env['SNAPLAND_SUGAR_WORKBENCH_OUTPUT']=str(out)
    env['SNAPLAND_SUGAR_WORKBENCH_SIZE']=size
    result=run_validated_godot(root,[
        'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe',
        '--path',str(root),'res://game/tests/native_sugar_bridge_workbench_review.tscn'
    ],env,timeout=90)
    log=result.stdout+result.stderr
    (out/'run.log').write_text(log,encoding='utf-8')
    print(size,result.returncode,log,flush=True)
```

Each launched process used a separate absolute save (v1/v2/v3 were distinct during iteration; viewport directories are distinct). No editor/import was needed.

Final output for both dimensions:
```text
Godot Engine v4.7.2.stable.official.ed1daf0bf - https://godotengine.org
Vulkan 1.4.359 - Forward+ - Using Device #0: AMD - AMD Radeon RX 9070 XT
Sugar bridge standalone GPU: 36 checks, 0 failures
```

Affected headless tests reran through the original validated commands using absolute `driver-native-fix-save.json`/`view-native-fix-save.json`:
```text
Sugar bridge driver: 47 checks, 0 failures
Sugar bridge view: 52 checks, 0 failures
```

Root has the paths for independent visual acceptance. 1920×1080 has not run, per instruction to stop after the first two sizes; Main/session integration, catalog, screenshots in pm, and delivery are still root-owned. GPU slot released.

## Task 2 fix round 2/5

Addressed shared-support pointer parity. `endpoint_at` first finds the ordinary nearest hit within the existing strict 30-design-pixel radius. It then prefers the current selection only if that endpoint's distance ties the nearest within 0.001 design pixels. A genuinely closer endpoint still wins, including when the selected endpoint is also inside its own hit circle. This does not move model endpoints or visible handles. The 換端 button tooltip explains: 共用支點先換端，再抓端點。

Covering regressions in driver/view tests reproduce the original failure, then pass on-screen Next-button selection → press shared central knob → continuous drag of endpoint 2 while endpoint 1 remains pinned. Separate tests retain distinct-nearest behavior and reject selected priority for a genuinely closer hit even inside overlapping hit circles. A driver regression also confirms the on-screen Grab button intentionally toggles a keyboard/arrow-controlled grab after pointer release; the ordinary pointer route remains direct endpoint dragging.

Red command: original validated headless loop with saves `{name}-fix2-red-save.json` and logs `{name}-fix2-red.log`. Output:
```text
Sugar bridge driver: 51 checks, 1 failures
ERROR: shared knob drag moves the selected second material only
Sugar bridge view: 54 checks, 1 failures
ERROR: shared support hit prefers selected endpoint on nearest-distance tie
```

Green command: same validated headless loop with saves `{name}-fix2-green-save.json` and logs `{name}-fix2-green.log`; final extra overlapping-circle check reran view with `view-fix2-final-save.json`. Output:
```text
Sugar bridge driver: 51 checks, 0 failures
Sugar bridge view: 55 checks, 0 failures
```

Native fixture now drives the same shared-support regression using actual Input.parse_input_event Next-button press/release and mouse movement before repinning and completing the original route. Fresh GPU run used the exact native command above with only `base=root/'.review/sugar-controls/native-fix2'`, `size='800x600'`, and `SNAPLAND_SAVE_PATH=.../native-fix2/800x600/isolated-save.json`. All previously accepted capture paths were preserved. New evidence includes `02a-shared-support-drag.png` plus the original seven stages, report.json and run.log.

```text
Godot Engine v4.7.2.stable.official.ed1daf0bf - https://godotengine.org
Vulkan 1.4.359 - Forward+ - Using Device #0: AMD - AMD Radeon RX 9070 XT
Sugar bridge standalone GPU: 40 checks, 0 failures
```

Root notified of final 51/55 markers for registry updates and fresh evidence path for independent acceptance. No shared integration/Git/editor/import changes. GPU slot released; 1920/Main integration remains root-owned.
