# SG-41 Task 3 integration read-only preflight

No tracked mutation or Godot run. Waiting for root literal `SG-41 mutate now`, after MAIN-26 and MAIN-27 commits.

## Owned production seams

- `game/core/game_catalog.gd`: DATA_PATHS candy JSON, ZONE_STARTS 25, ZONE_COUNTS 1. all_definitions should iterate known delivered zones in dictionary insertion order (welcome, harbor, candy), no future-zone placeholders. Existing validation enforces count/order/duplicates/text/identity. Identity automatically gives photo-candy-game-1, photo-candy-devil-1, ACH_GAME_025. Retain twelve welcome and twelve harbor.
- New `game/data/candy_games.json`: one game-025/sugar_bridge/candy/local_index1 row. Goal material delivery, concise real inputs, honest ordinary participation and same-band post-sling three-ball devil rule.
- `game/minigames/session.gd`: add sugar_bridge driver to DRIVERS only. Existing driver branch already supplies reset, step, state, view, practice, retry, pause/focus/exit clear, score_summary, ordinary_eligible. No parallel lifecycle.
- `game/world/candy_world.gd`: existing six points include pending-game info at (0,.2,-9). Convert it to actual game-025 entry, replace pending sign with 拉糖橋; material observation points retain no rewards. Existing map snapshots automatically export game point.
- `game/main.gd`: candy branch needs actual game ID invite before return; HUD and pause local card totals currently hardcoded zero; info copy/ticket currently twelve upcoming; game rules nonharbor title incorrectly welcome; _can_access_game only guards harbor, must guard candy with existing six-welcome admission/current-region exception. _show_region_tutorial should open025 lesson, guide label match. Map already loops delivered catalog (existing action name HarborGamegame-025 acceptable though can name CandyGame if tests align). Keep local planned progress 1/12 accurate while actual delivered album denominator 1. Photo attachment is already Catalog-backed via Progress.
- `game/ui/collection_book_panel.gd`: two candy0/0 overrides, empty copy, and `_saved_texture` recognizer hardcodes welcome/harbor. Use delivered definitions/identity for game-photo recognition so candy uses bounded validated decode/cache. Preserve welcome18 (six attraction+12 games), harbor12 and candy1 totals.
- `game/ui/achievement_stamp_book.gd`: remove empty local summary overrides when _games is nonempty. First local card yields ACH_GAME_025 through Catalog already.
- `game/ui/tutorial_catalog.gd`, `game/data/tutorials.json`: expected025 plus three steps grab/pin/transport, sling same-band bridge, result/recovery. Root-generated real paths assets/ui/tutorials/game-025-step-01.png through03; never substitute other games or placeholder images.

## Existing production paths requiring no change

Progress.complete_game/complete_retake/_award_game_cards and attach_game_photo_frames already use Catalog identity, global game receipt, fixed achievement, original/thumbnail validation, first provenance, transaction rollback and reload migration. Root's native/save tests must verify these with candy IDs, not infer from source. Existing Session driver lifecycle excludes practice and cancellation from ordinary eligibility and passes model ordinary_eligible.

## Tests owned

- test_game_catalog: 25 total, ordered welcome+harbor+candy, candy one identity, sources candy required; preserve every old assertion and malformed boundary. Bad candy=[] becomes invalid count and wrong unknown extra key stays covered.
- test_candy_world: six actual interactions now include025; replace no-game assertion with one exact game point, keep floor collision/reachability/map detached/resource bounds checks.
- test_region_travel: candy local UI album1/achievement1/count1, ticket1/12 and guide025; synthetic menu/observation flow must remain progress-neutral. Region album sizes [18,12,1]. Entry loop game025 should avoid accidentally granting via button tests. Preserve return/admission/restart/local temperature checks.
- New test_sugar_bridge_session.gd: public keyboard and driver commands, actual bridge solution; idle timeout no participation no ordinary; participated timeout ordinary; success, devil, practice, cancel; pause/focus/retry same driver/view and changed variant; previous24routes covered existing tests.
- New test_sugar_bridge_main.gd/.tscn: six welcome admission, real candy world/map/invite/rules lesson start; actual success and participated timeout result; practice/cancel no awards, assistdevil, ACH025 and40coins once, othercards absent, reload. Use isolated absolute save path.
- New candy progress/album/retake checks can reside in Main test if clear fixture IO: valid thumbnail+original first retake, preservation/dedup and reload; album saved candy image renders through proper validated decoder. No Progress edit unless behavior fails.

## Root-owned gaps and dependencies

- tools/verify_design.py currently HARBOR_DELIVERED12 and i<=24 supportedruntime; alignment only takes welcome/harbor. Add actual candy coverage and scope.
- design/02-minigames/catalog.json game025 state/copy/runtime_mode, docs/runtime counts as needed; tests/test_design_validation.py assumes index24 unbuilt. Root handles scope and docs.
- Shared runner/contracts registry to include new tests. root handles.
- Driver/view/model fixtures and actual solution routes supplied by respective builder; no edits by Task3.
- Three real tutorial captures/assets delivered by root; no images by Task3.

Validation is pending authorization and engine slot; nothing here constitutes game play success.


## Authorized implementation and checks

Root authorized `SG-41 mutate now` after MAIN-27 e0b2cbf7. Production now includes one candy game025, Session driver route, actual six-point factory entry, delivered regional counts, title/guide/information, regional access guard, generic saved-game-photo detection, real local stamp and three tutorial paths. No model/driver/view/runner/validator/PM/Git/image edits.

New Session/Main test files use actual Session pointer and keyboard routes; Main retake image is explicitly a valid synthetic persistence fixture, not native shutter evidence. Initial RED both exit1 for precise missing game025 boundary, no parse errors. First actual Session run exposed fixture-only Control.to_global invalid; replaced with CanvasItem transform; no production change needed.

Validated launcher: `tools.godot_entrypoints.run_validated_godot` with executable `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe`, `--headless --audio-driver Dummy --path C:/Users/stanl/Github/Snapland`, separate absolute SNAPLAND_SAVE_PATH per listed test. Exact command repr and full output are next to each profile below.

| Log directory | Result |
|---|---|
| red-session | Expected missing025 RED exit1 |
| red-main | Expected missing025 RED exit1 |
| green1/test_game_catalog | PASS exit0 |
| green1/test_participation_results | PASS every25 delivered result/practice/cancel exit0 |
| green2/test_sugar_bridge_session | 21 checks,0 failures exit0 |
| green2/test_candy_world | 4263 checks PASS exit0 |
| green2/test_photo_retake_progress | PASS exit0; expected invalid-fixture warnings |
| green2/test_tutorial_seen_progress | PASS exit0; expected invalid-fixture warnings |
| green2/test_tide_lock_session | 24 checks,0 failures exit0 |
| green3/test_harbor_collection | 22 checks,0 failures exit0 |

Harbor collection's old assertion expected18 ordinary despite twelve entries; truthful generic denominator now12, welcome remains18. Updated scoped assertion and green3 passed. Tutorial/Main/region-travel pending root-generated actual PNGs; no fake placeholders used. Runtime ordinary objective changed on root request to `三顆運料球送到右岸` for design alignment; model ordinary eligibility retains participated natural completion.


Additional green3 checks: test_region_progress PASS exit0; test_harbor_game_progress PASS exit0 with deliberate invalid-boundary fixture warnings. game/tests/test_region_travel.gd adjusted harbor HUD1/18->1/12 after delivered denominator change, candy1/1 local slot and1/12 open games, tutorial guide now checks actual tutorial_panel then calls _tutorial_close before closing ticket. MAIN27 map test path opens RegionGamesButton before HarborGamegame-025. Root informed all engine slots free for actual Main native capture and tutorial assets.


### Superseding collection target ruling

Root explicitly preserves planned collection targets18 ordinary/12 devil for all nonempty delivered regions (historical forward-compatible harbor story/explore/quest metadata must not become18/12). Main HUD/pause and album restored fixed18/12; original HarborCollection1/18 and regionaltravelHarbor1/18 assertions restored. Candy has one actual game entry/stamp,0/18 and0/12 targets, and separate info/ticket/world sign show actual games1/12. Previous green3HarborCollection denominator assertion is superseded; final verification will use restored original check. No Progress/canonical counts or180 target changes.


Final-target green4: restored original HarborCollection22/0 exit0. Existing AlbumPhotoViewer PASS exit0 using scene entry; validated launcher rejected an initial --script attempt before engine launch because it extendsNode, then correct .tscn used. No source changes from this launch correction. Pending asset-dependent tests remain newMain, regionaltravel and tutorial panel/viewport.


### Fresh review and asset-dependent completion

Reviewer found album detail region still harbor-versus-welcome. Fixed candy region name and pinned both ordinary/devil card instructions in newMain. Sugar ordinary detail explicitly requires participation. No remaining binary harbor/welcome region-name choices in owned production. NewMain teardown adopts actual MAIN28 WeakRef audio-playback drain after owner free, bounded2s, no fixed150ms delay.

Before import green5 Main exercised all real routes but failed one fixture reset: Progress.reset_progress schedules Main deferred region replacement; immediate practice was blocked by changing_region. Fixed test to await resetframes and real candy reentry before retake. No production change. green5 regionTravel PASSexit0; tutorialPanel failed only three newPNG import checks. Root-generated actual PNGs copied correctly; authorized validated editor --import exit0 imported exactly3 assets, log import6/output.log.

Final green6/test_sugar_bridge_main exit0 exactPASS `sugar Main candy entry, tutorial, real results, fixed rewards, selected retake originals and reload`; no ERROR/SCRIPTERROR or production missing-image warnings. Checks global six ordinary admission and saved-current-region recovery, actual400ordinary/500assisteddevil, idle/participatedtimeout, practice/cancel, fixedACH025, dedup, both albumregiondetails, validated candyphoto decode and selectedretakeoriginals preserved after real challenge/reload. Final green6/test_tutorial_panel exit0 PASS; one expected deliberately-missing fixture warning only.


Final green6/test_region_travel exit0 exactPASS `region travel admission, lifecycle, scoped UI, restart, and unchanged rewards`; imported game025images had no missing warnings and no engine errors. green6/test_tutorial_paged_viewport found qualification field252px versus242px viewport at800x450/1.25 across all3steps. Shortened only newlessonordinary text to `參與操作後正常結算，不限勝負可得普通卡；未操作、練習或取消不發卡。練習後可免費補拍，不記技巧。`, preserving conditions. No shared UI or test-golden relaxation. Source frozen and root notified; green7 pagedviewport rerun pending, no further owned production/test mutation planned unless a real check failure is reported first.


## Final scoped handoff / source frozen

Root native actual shutter discovered a real missing integration: RetakePanel PROPS had24 rows. Root extended ownership to `game/ui/retake_panel.gd` and `game/tests/test_retake_panel.gd`. New tests require _valid+3realprops then actualNext2->enabledShutter for EVERY delivered25game, and upcoming026 failsclosed. RED retake-red8 exit1 exactly two game025 failures. Appended one existing atlas row `[bench,sign,camera]`; retained source/index failclosed guards and no new assets. NewMain now asserts valid3props and actualNext2/enabledShutter BEFORE its explicit synthetic persistence fixture, so it cannot bypass invalid themed sets again.

Fresh performance review removed quadratic per-thumbnail definition scanning: game-photo detection now iterates three declared Catalog.DATA_PATHS zonekeys with two prefixes, preserving strict savedPNG decoding and old known-zone prefix compatibility. No helper or newdependency.

| Final log | Result |
|---|---|
| green7/test_tutorial_paged_viewport | PASS exit0 all26lessons, all5semanticfields,3sizes/1.25; no clippedcopy |
| green8/test_retake_panel | PASS exit0 all25canonicalsets+enabledshutter, upcoming026failsclosed |
| green8/test_sugar_bridge_main | PASS exit0 fullrealroutes+validretakeset+selectedoriginals+O3candydecoder |
| green9/test_album_photo_viewer | PASS exit0 completeimage/focus/immutableprogress |
| green9/test_harbor_collection | 22checks0failures exit0 original18/12golden preserved |
| green9/test_main_photo_thumbnails | PASS exit0 sharedphotoCPUbudget, replayidempotence, malformedfallback |

No engine remains active after these runs. Final source freeze sent to root; no further owned production or test mutation planned without explicit notice. Root owns actualnative3sizes/shutter/restart/privatepackage/export/PM/Git and sharedrunner/validator/designsource edits. Earlier green5 assets were unimported; finalimportedgreen6/7/8 logs supersede them.

### Final owned changes

- game/core/game_catalog.gd, game/data/candy_games.json
- game/minigames/session.gd (one driver routing entry only)
- game/world/candy_world.gd, game/main.gd
- game/ui/collection_book_panel.gd, achievement_stamp_book.gd, tutorial_catalog.gd, retake_panel.gd
- game/data/tutorials.json
- game/tests/test_game_catalog.gd, test_candy_world.gd, test_region_travel.gd, test_participation_results.gd, test_retake_panel.gd
- new game/tests/test_sugar_bridge_session.gd, test_sugar_bridge_main.gd/.tscn

No model,driver,view,sharedrunner,validator,PM,Git,artworkimage production edits. Editor-generated import/UID outputs were left for root; no unrelated untracked outputs removed. Existing test_harbor_collection.gd source is restored unchanged.
