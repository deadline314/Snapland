from pathlib import Path
import sys,os,json,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from tools.godot_entrypoints import run_validated_godot
size,mode,tag=sys.argv[1:4]
assert size in ['800x600','1280x720','1920x1080'] and mode in ['asset','devil','ordinary','assisted','timeout','read','retake'] and tag.isalnum()
out=ROOT/'.review/sugar-main-20261117'/f'{size}-{mode}-{tag}'
assert not out.exists();out.mkdir(parents=True)
profile=Path(sys.argv[4]).resolve() if len(sys.argv)>4 else out/'profile/progress.json'
env=dict(os.environ,SNAPLAND_SAVE_PATH=str(profile),SUGAR_CAPTURE_DIR=str(out),SUGAR_REVIEW_SIZE=size,SUGAR_REVIEW_MODE=mode)
if mode=='asset':env['SUGAR_TUTORIAL_DIR']=str(out/'tutorials')
sources=list(ROOT.glob('game/minigames/sugar_bridge*.gd'))+[ROOT/'game/tests/native_sugar_bridge_main.gd',ROOT/'game/main.gd',ROOT/'game/data/candy_games.json']
(out/'sources.json').write_text(json.dumps({str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},indent=2),encoding='utf-8')
r=run_validated_godot(ROOT,[r'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--path',str(ROOT),'--log-file',str(out/'engine.log'),'--rendering-method','gl_compatibility','--audio-driver','Dummy','--fixed-fps','60','res://game/tests/native_sugar_bridge_main.tscn','--quit-after','10800'],env=env,timeout=185)
log=r.stdout+r.stderr+'\n'+(out/'engine.log').read_text(encoding='utf-8');(out/'native.log').write_text(log,encoding='utf-8')
print(log[-1600:]);assert r.returncode==0 and 'ERROR:' not in log and 'PASS: native sugar Main' in log and 'screenshot missing' not in log
print('PASS',size,mode,out)
