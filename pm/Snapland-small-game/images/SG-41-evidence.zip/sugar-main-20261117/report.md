# SG-41 delivery evidence ledger

Automated actual input and native GPU capture, not human play, listening, or hardware performance acceptance. Every process uses validated Godot4.7.2 and isolated absolute save. Only six welcome admission cards are synthetic; all game025 scores, ball transports, sling hits and target cards are earned through actual controls and natural results.

## Native fixture correction

Initial `asset-first`, `asset-selected`, `asset-diagnostic` processes failed sling. Model diagnostic showed correct short bridges/selected1 but paused automatic processing left retained view at initial endpoints. `Session._process(0)` after actual events and before captures restores the ordinary presentation lifecycle without physics-time advancement or injected state. These failed raw reports/PNGs remain archived and are not successful play evidence. `1280x720-asset-sync` naturally produced500, same-band devil, real result PNGs, and three actual tutorial sources.

An initial800 assisted run before importing new PNGs completed500 but warned missing lesson images. It is superseded by `800x600-assisted-imported` with no missing screenshot warning. Main source tests use deliberately synthetic retake image fixtures; actual native shutter must pass separately.

## Completed native cases

- 1280x720 asset-sync: real short bridge, actual pull, same-band post-hit threeball transport,500/ordinary+devil, originals/thumbnails, album/map.
- 800x600 assisted-imported:125%text/reducedmotion, real firstlesson and same route500.
- 1280x720 ordinary-final: actual longbridge with sequentialloads,400/no devil.
- 1280x720 timeout-final: actual unsupported load/fall then150s model timeout,0score/participatedordinary only.
- 1920x1080 devil-final: firstlesson, shortbridge+sling500.

## Actual shutter finding

`1280x720-retake-final` failed honestly: RetakePanel has only24 themed prop rows and refuses delivered025. Next/shutter remain disabled, no card issued. The headless synthetic-image persistence test could not establish rendered-set readiness. Original integrationworker is fixing the new row and adding actual ready-state regression assertions. Private package initialsnapshot is stale (qualificationcopy and prop fix); final stage/export must refresh exact changed runtime and nativefixture hashes before being accepted.

## Final source review scope

Fresh full-branch review found no new major issue beyond actual retake and thumbnail lookup. Root thumbnail finding: per-thumbnail all_definitions then every identity scanned/deep-copied25 definitions repeatedly. Original implementer now recognizes existing known zone prefixes directly in O(number of released zones), preserving legacy prefix behavior and validated image decoding; no new abstraction or dependency.

Minor ruling: ballistic pull preview is visible in ordinary and assisted mode to avoid blind aiming; assist adds numeric capacity and wider tolerances, not automatic hits. Design prose updated to actual behavior. This does not change existing qualification or add testing scope.

Private initial embedded output completed actual500 and a cold profile restart but failed shutter identically. Its logs/manifest remain historical; it is not final release acceptance. A refreshed exact snapshot and native shutter/cold restart are required.

## Final standalone acceptance

Final embeddedWindows QA snapshot compared 1178 runtime/allowlistedfixture source hashes against current workspace: zero mismatches; executable SHA verified. Actual500 writer, cold saved restart, actual rendered selecteddevil shutter and retake cold restart all exit0 with noERROR or missing tutorial warnings. Release boot uses no loose project, scene or pack override. Build is QA-entry private output, not a published player installer. Initial stale binary removed only after matching its recordedSHA; failed reports/source text retained.
