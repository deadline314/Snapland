SG29 acceptance evidence, 2026-11-13
Actual native UI/input evidence is automated, not human enjoyment/audio acceptance.
All tests use private profiles. Retake photographs are labelled static themed sets, separate from actual challenge results.
Contract fixtures may contain synthetic or deliberately malformed data; source-native/release target attempts, shutter images and awards are real routes. Harbor writers seed only six explicitly labelled OLD welcome prerequisites.
Eight source-native rows distinguish final small/restart runs from earlier unchanged wide routes; see Task4 report. Final packed and standalone proof uses the final production code.
Initial cloud run43317813870 failed one stale HUD-copy assertion; two existing checks were corrected and reviewed, with Windows/Linux red-to-green. Final cloud data is in release/final-ci-verification.json.
Transport ANSI color sequences alone are removed from retained GitHub job logs. No diagnostic text is discarded. Source/native engine diagnostics retain known material warnings and exactly measured intentional write failures.
Raw source-profile paths are preserved as provenance. Stable final packed/EXE profiles/photos remain under the local release qa directory. The full local SDD archive retains all failed development evidence and screenshots; this Git bundle deliberately contains a lean selection to avoid repository bloat.
All chronological decisions/costs are in release/rulings.md. Later user steering is authoritative: deliver SG29 and stop; open no subsequent tickets. Main/publication/cleanup completion is recorded in the handoff document.
