### Task 2: Reversible themed photo set

**Files:** Create game/ui/retake_panel.gd and game/tests/test_retake_panel.gd. Reuse game/ui/paper_ui.gd, tutorial_catalog.gd and original authored assets without edits unless concrete API gap is reported first.

**Interfaces:**
- Produce Control setup(definition: Dictionary, devil: bool, lesson: Dictionary) -> void, signal capture_requested(image: Image), signal close_requested(), set_capture_result(saved: bool, message: String) -> void.
- Parent creates/configures before add_child; target immutable for panel lifetime. Step0 observe,1 adjust,2 shutter. Public UI buttons advance/back and shutter; step index is readable for tests only, never a production external bypass.
- Three bounded cyclic keyboard/pointer choices: framing left/center/right, decoration one of three theme-appropriate whole props, near/normal/wide composition. Each choice visibly changes actual set; preserve on Back. Reuse real lesson PNG as explicitly labelled demonstration/backdrop and whole authored sprites/props, with clear "補拍布景／非挑戰成績" distinction. No re-simulated physics or copied demonstration claimed as this player's gameplay.
- One reusable 1280x720 SubViewport photo set, no per-frame allocation; displayed preview is exactly shutter source. Actual shutter waits render, reads its image, disables double shutter until set_capture_result. Missing/invalid/oversized source has readable fallback and refuses empty capture. Headless tests validate state without pretending rendered capture.

- [ ] Add failing state/invalid setup tests covering canonical delivered target, lesson mismatch, ordered steps/back/preserved choices, keyboard/button focus, no early/duplicate shutter, failure enables retry, success blocks duplicate award, close/destroy invalidates deferred capture.
- [ ] Implement minimal Paper layout with concise hints and named accessible controls; adaptive 800x600/1.25 text, reduced-motion with no mandatory motion. Frame composition never includes controls or demonstration explanation as fake gameplay.
- [ ] Verify headless tests and native 800x600/1280x720 actual preview changes, shutter pixels/dimensions/zero empty capture, keyboard sequential navigation, missing image fallback and eight open/close cycles stable node/resource counts. Record actual PNGs as set photographs, not earned-game photos.
- [ ] Self-review single viewport and capture lifetime, input ownership and source validation; commit owned files and report.

