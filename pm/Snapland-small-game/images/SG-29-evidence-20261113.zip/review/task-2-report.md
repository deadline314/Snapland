# SG-29 Task 2 report

Status: implementation and affected checks complete. Commit: d203d356d9c7f5b456656ff7f88047fc5cc335e8 (feat: add reversible themed photo retake panel).

## Scope and APIs

Only new `game/ui/retake_panel.gd` and `game/tests/test_retake_panel.gd` are owned/staged. No production test bypass, no Main/Progress/Session changes, no dependencies, no PhotoStage/tutorial/Paper edits. Native fixture/evidence remain ignored under `.review/`.

- `setup(definition: Dictionary, devil: bool, lesson: Dictionary) -> void`: call exactly once before add_child. Requires the exact GameCatalog canonical definition with canonical delivered id and matching exact TutorialCatalog lesson; stores isolated data. Unknown/mode aliases/planning-only IDs and mismatches produce readable disabled fallback. Repeated setup cannot retarget the panel.
- `capture_requested(image: Image)`: actual current 1280x720 SubViewport readback, after process_frame and RenderingServer.frame_post_draw. Owner must persist/award against its already-bound target and answer `set_capture_result`.
- `set_capture_result(saved: bool, message: String) -> void`: only accepts a pending acknowledgement. Failure permits retry; success permanently blocks another shutter for this panel. No Progress, file writing, score, challenge evidence, eligibility or award calls exist in panel.
- `close_requested()`: Escape or close button; closes capture lifetime before emit. Owner frees the panel. `_exit_tree` invalidates lifetime and safely restores prior valid focus.
- `current_step` readable state: observe0, adjust1, shutter2. Changes only through actual navigation button callbacks. Back preserves choices. No public skip/capture injection API.
- Named controls: RetakeBack/RetakeNext/RetakeShutter/RetakeClose, FramingChoice/DecorationChoice/DistanceChoice, PhotographPreview, RetakePhotoViewport.

## House reuse and source validation

Read PhotoStage first: it hardcodes five quest scenes, lacks tutorial backdrop and whole-prop swapping; changing it would expand ownership and affect existing quest scenes. New inner SetPicture is a small static composition, reusing whole hero from AvatarRenderer and whole authored prop regions from tidal-props-v2. Three per-theme prop choices reuse existing authored assets. No character parts are copied or reconstructed. Paper supplies all typography, buttons, bevels, theme, text scale, physical44px adaptation; no mandatory motion or new animation.

Tutorial source is exactly first image of the matching validated canonical lesson under res://assets/ui/tutorials. ResourceLoader.exists/load(Texture2D) respects imported resource remaps. Dimensions are checked before get_image: positive and at most4Mi pixels, then nonempty decoded image and exact reported dimensions. Missing/invalid source clears preview and refuses capture. This avoids assumptions that exported raw PNG paths remain ordinary files. Props are validated against atlas bounds. Target UI and actual photograph say 補拍布景／非挑戰成績; backdrop separately says 示範背景. Demo first step explicitly says not current gameplay and displays actual canonical lesson goal. Captured composition preserves source aspect and contains whole hero/selected prop plus labels; it does not claim a gameplay result or copy the demo as a new earned gameplay screenshot.

One fixed1280x720 SubViewport per panel, one SetPicture and one displayed viewport texture in steps1/2; UPDATE_ONCE only at construction, choice change and shutter. No process loop, per-frame texture/image allocation or new viewport per shutter. Three cyclic controls change actual framing, whole prop, distance. Preview byte comparison to native shutter is exact.

## Red/green and commands

Pinned engine: C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe (4.7.2.stable.official.ed1daf0bf). Workdir: C:/Users/stanl/Github/Snapland/.review/photo-retake-worktree.

Initial failing state suite: `.review/task2-red.log` records missing retake panel and FAIL before implementation. Early native fixture-only issues (PackedByteArray nonexistent hash method; eager preload before autoload registration; consequent inferred type error) were fixed in ignored fixture. Logs retained `.review/task2-native1280{,b,c}.log/.err`; no such errors in successful final runs. Visual review fixed title zero-height autowrap and backdrop aspect, and source fallback clears invalid placeholder instead of rendering magenta.

Final headless command arguments:
```
--headless --path C:/Users/stanl/Github/Snapland/.review/photo-retake-worktree --script res://game/tests/test_retake_panel.gd
```
Environment SNAPLAND_SAVE_PATH=C:/Users/stanl/Github/Snapland/.review/photo-retake-worktree/.review/task2-headless-complete/save.json. Output `.review/task2-headless-complete.log`, stderr `.review/task2-headless-complete.err` empty, exit0/PASS. Internal85s watchdog plus external90s process guard. Covers all13 actual delivered targets, noncanonical ids, lesson mismatch/path mutation, immutable target, step order/back preserving all choices, bounded cycles, Enter and focus, early shutter, explicitly headless no-fabricated readback, state-only failure retry/success/late acknowledgement, close invalidation, missing decoded source, oversized texture rejection. State-only tests set pending acknowledgement field locally; production contains no test bypass and these do not claim GPU capture.

Final native fixture `.review/task2-native.gd` is ignored. Exact engine arguments:
```
--path C:/Users/stanl/Github/Snapland/.review/photo-retake-worktree --script res://.review/task2-native.gd --resolution 800x600
--path C:/Users/stanl/Github/Snapland/.review/photo-retake-worktree --script res://.review/task2-native.gd --resolution 1280x720
```
For800: RETAKE_SIZE=800; RETAKE_CAPTURE_DIR=C:/Users/stanl/Github/Snapland/.review/photo-retake-worktree/.review/task2-reviewed800; SNAPLAND_SAVE_PATH=<that directory>/save.json. Logs `.review/task2-reviewed800.log/.err` (stderr empty, exit0). Actual viewport800x600 via canvas_items, design1280x720 + EXPAND; Paper text_scale1.25/reduced_motion true.
For1280: RETAKE_SIZE=1280; RETAKE_CAPTURE_DIR=C:/Users/stanl/Github/Snapland/.review/photo-retake-worktree/.review/task2-reviewed1280; SNAPLAND_SAVE_PATH=<that directory>/save.json. Logs `.review/task2-reviewed1280.log/.err` (stderr empty, exit0). Actual viewport1280x720, text_scale1.0.

Each native launch used Start-Process -WindowStyle Hidden -PassThru with separate stdout/stderr, WaitForExit(90000), Stop-Process only on that returned pid if expired, nonzero exit throws; native fixture internal85s watchdog. Every launch including red/probes used an absolute unique task2-* save path, never a real profile. Native Vulkan Forward+ AMD Radeon RX9070XT.

Native assertions pass: real keyboard Enter observation->adjust->shutter, Tab sequential option/navigation focus, each of3 choices changes actual viewport pixels, actual emitted Image1280x720 nonempty and byte-for-byte equal to preview source, duplicate shutter disabled until acknowledgement, native save failure retry emits second actual capture, success no further emit; fixed footer in viewport and>=44px physical hit targets;8 open/close cycles including pending-shutter destroy and closed-before-render. Latest1280 additionally awaits close without freeing first, proving close invalidation independently from destruction. Missing decoded image is simulated with a PlaceholderTexture2D owning the canonical imported resource path; this is fixture-only cache replacement restored afterwards, not a changed production lesson or missing raw-PNG assumption. Fallback screenshot has readable message, blank preview and disabled next/shutter.

## Actual images and review

Final800 evidence `.review/task2-reviewed800/` and final1280 `.review/task2-reviewed1280/` each contain observe-{size}, adjust-before-{size}, adjust-after-{size}, shutter-{size}, saved-{size}, missing-fallback-{size}.png; set-before-{size}.png and set-photograph-{size}.png are actual fixed1280x720 themed-set images, NOT earned gameplay photos. No profile card or game proof was seeded/awarded.

Personally inspected final800 observe after goal addition, earlier final800 adjusted/capture/fallback (same final composition); inspected final1280 observation and actual set photograph, plus earlier same final adjusted layout. Title, lesson goal, provenance, full source aspect and fixed footer are visible; keyboard focus scrolls choices into view. Parent inspected800 observe/adjust/actual set before commit and requested no visual change. Native800 goal revision remains readable; parent notified exact revised image path before commit.

Lifetime/resource evidence after each of8 open/close cycles:
-800: every sample [nodes4, resources30, texture memory5982464bytes].
-1280: every sample [nodes4, resources30, texture memory6441216bytes].
These are observed post-close engine counts, not a claim of absolute zero global allocations. Source/props/viewport lifetime belongs to panel and freed with it; global imported resource cache remains engine-owned. Pending capture token/closed checks prevent stale image emission, with native close-only and freed-node tests. Shutter does not change composition or create another viewport. No temporary capture files are created by production panel.

## Self-review and limitations

Self-reviewed immutable target validation, canonical source/import remaps and size checks, no per-frame allocations, generation/close/exit lifetime, in-flight/awaiting/saved guards, failure retry, separate owner acknowledgement, keyboard focus+44px footer, static reduced-motion path, demonstration/gameplay distinction. Only two owned source/test files were committed with author+committer stanley890314@gmail.com; no assistant/coauthor attribution.

Skipped Main/persistence/album integration, packaged build smoke, and broad regression because these belong to later tasks/controller/CI. No real human fun/audio/physical input playtest claimed; native automation exercised actual rendering and normal UI callbacks. Headless cannot prove GPU capture and is labelled accordingly. The set is a labelled static authored composition rather than13 game simulators. Parent must bind capture signal to the selected immutable target, validate/persist the Image atomically, acknowledge only actual save success, and dispose panel on close. Eligibility is intentionally not checked in this isolated view.

Final git diff --cached --check passed after trimming trailing blank lines; commit contains exactly two owned files (473 inserted lines). Final author and committer both Stanley Li <stanley890314@gmail.com>. No UID generated for these direct-loaded new scripts. No push/branch change. Parent plan edits and all unrelated untracked files preserved.

