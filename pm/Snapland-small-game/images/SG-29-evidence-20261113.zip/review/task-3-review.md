# SG-29 Task 3 review

Date: 2026-11-13. Reviewed BASE `d4eeec595acde6f4cfffbd638091fd81f8fc67cf` through HEAD `b3e598167137a8f9686fb014523d0ec67142b578` in `C:/Users/stanl/Github/Snapland/.review/photo-retake-worktree`.

## Verdicts

- **Spec: changes required.** Integration, persistence, lifetime guards and the controller-corrected playable save-failure fallback meet the reviewed Task 3 requirements. One collection-achievement explanation contradicts the supported devil-first acquisition path.
- **Code quality: changes required.** One P2 user-visible correctness issue in the changed achievement copy. No additional implementation, abstraction, dependency, or style findings.

Both verdicts refer to the same finding. No Core reward change, RetakePanel change, UI redesign, or new release-matrix requirement is requested.

## Actionable finding

### P2 — Describe the per-game stamp as first-card collection, including devil-first retakes

**Locations:** `game/ui/achievement_stamp_book.gd:146` and `game/ui/achievement_stamp_book.gd:242`.

The new condition says `條件：收藏這款遊戲的普通拍貼`, and the compact explanation says `灰色：收藏普通拍貼後蓋章`. Neither matches the actual achievement contract. `Progress.complete_retake` selects only the requested missing card (`game/core/progress.gd:195-203`), then `_award_game_cards` includes the per-game achievement regardless of card kind (`game/core/progress.gd:221`). The achievement tile reads this achievement directly (`game/ui/achievement_stamp_book.gd:129`).

A supported sequence is therefore: first practice and cancel game-001, retake only its devil card, then open the stamp book. `ACH_GAME_001` is unlocked while `photo-welcome-game-1` remains absent, yet the tile says its condition requires that absent ordinary card. This is exactly the devil-first flow covered by the Main/native fixtures, not an unsupported forged save. The wording also incorrectly suggests to an uncollected player that devil-only collection will not count.

**Smallest correction:** describe collection of this game's first photo/either card kind in both lines, e.g. `條件：首次收藏這款遊戲的拍貼` and `灰色：首次收藏遊戲拍貼後蓋章`. Keep the welcome ordinary-set milestone explicitly ordinary and preserve the existing Core award behavior. Align the existing wide first-completion heading with collection wording if editing the same explanation. Add a small assertion to the existing devil-first flow/achievement fixture that the stamp can be unlocked with ordinary still absent and its copy no longer requires ordinary.

**Requirement affected:** the Task 3 brief requires first-card/collection achievements to use truthful collection language; the runtime spec treats first-photo achievements as collection semantics. Replacing formal-round wording with an ordinary-only requirement does not describe the actual either-kind first-photo reward.

**Evidence:** deterministic source trace above, compared with the retained native helper's devil-only assertion before ordinary capture and the Main test's selected-kind/metadata assertions. No engine rerun is needed to establish this literal mismatch; this review did not claim to have newly exercised the UI sequence.

## Spec compliance otherwise observed

- `_launch_game` resolves accepted aliases to a canonical delivered definition, checks zone access and existing Session ownership, starts a real Session, checks its initialized identity/end state, applies practice mode, then saves the attempt. Invitation/rules/tutorial-only paths do not call attempt persistence. Harbor uses the existing six-normal-card threshold with legitimate saved-current-harbor recovery.
- The ephemeral practice target retains canonical ID and ordinary/devil selection through immediate cancellation and natural practice results. Result Back and the explicit return action reopen the selected entrance. The new shortcut disposes an unsuccessfully recorded Session, restores the world, clears its target and shows retry copy.
- The current controller ruling is implemented: ordinary/generic practice remains one initialized playable Session after attempt-save failure, including tutorial-seen-save failure. Progress rolls back the attempted ID; a six-second shared HUD notice survives both legacy feedback and driver feedback suppression. The added Session logic resets on start and changes neither gameplay feedback events nor actual goals/counters/conditions/points.
- Main binds the owner instance, generation and canonical target/kind to capture. Quit, queued owner/Main, detached owner, closed/replaced panel, generation mismatch and target mismatch are refused. RetakePanel remains unchanged and provides the actual shutter Image. The synchronous write/award path has no await gap.
- Capture validates the real 1280x720 Image and generates unique selected-card paths. Thumbnail/original writes precede `complete_retake`; only its persisted success is acknowledged. On failure only this capture's new unreferenced files are removed. Repeated capture cannot overwrite an existing selected card or pay another 40 coins. No Session finish, story-success event, score or technique is fabricated.
- The common image writer retains its signature and checks image/PNG bounds, writes a unique same-directory staging file, flushes/checks it, then renames it. Failures remove staging only. Gameplay thumbnails and originals use the common writer; postcard capture now uses a unique namespace before its existing stale/save-failure cleanup, protecting older bytes.
- The collection book keeps setup's five arguments, region selection, non-game entries and original-photo viewer. Missing game cards expose canonical card ID, fixed named kiosk/region and practice-or-retake action. Collected cards show provenance and distinguish actual devil technique. Collection detail height adapts through the existing layout path.
- All three source-model edits are string-literal changes only. Session/HUD changes beyond the bounded notice are qualification/result wording. The two FakeProgress additions, tutorial-failure assertions and exact tutorial text fixture are within the approved scope. No Core or RetakePanel implementation changed.

## Evidence checked

Read the immutable `review-d4eeec5..b3e5981.diff`, current task brief, global constraints, report, runtime spec, ledger rulings, root AGENTS.md, all changed source/test diffs, relevant Main callers and the existing Progress/RetakePanel contracts. The superseded universal-abort assumption was not applied. HEAD is the requested commit; tracked game working copies match it. The commit has exactly 16 approved source/data/test paths and the required author/committer identity. `git diff --check d4eeec5 b3e5981` passes. Parent documentation and existing import/UID noise were left untouched.

Audited all 20 rows in `task3-evidence/final-verification.json` against their named raw logs: all record exit 0 and all logs have zero ERROR/SCRIPT ERROR lines. Each has its normal success summary, including the three suites that use `checks passed`/`0 failures` rather than a `PASS:` prefix. These cover region travel, rowing Main, story, shell/collection/minigame UI, tutorials, thumbnails/originals/viewer, harbor/time postcards, source models, minigames and the new Main flow. The retained runner enforces 90-second subprocess timeouts and unique absolute isolated save paths; the new fixture has its own 85-second watchdog. The initial Main red log retains the three missing-method failures and its reported shutdown resource error; it was not counted as green evidence.

Reviewed the new Main fixture's real Session starts/cancels, alias and harbor gate/recovery cases, natural bench practice input and no-input fountain failure, selected regional kinds, old metadata/byte preservation, duplicate/stale/quit/queued-owner checks, attempt/award rollback, partial original-write failure and retry. Its image injection is state/persistence evidence, not a headless GPU capture claim. Its failure child asserts four exact intended write diagnostics, and the revised tutorial child/parent preserve exactly one playable Session plus exactly two intended diagnostics. The writer cases use actual filesystem obstruction/held Windows destination and an oversized encoded PNG rather than accepting broad error patterns.

For both final native directories (`native800-finalcopy-1e083e28-d94a-4078-bbcb-c7164a822338` and `native1280-finalcopy-a4c2f640-554e-48aa-a0f0-fed52e7108f3`), checked raw PASS markers, 14 PNG artifacts each, and exactly three intended write-error lines with no additional error lines. Read the native helper: it emits real UI button signals, uses actual Session cancellation and rendered shutter capture, and labels programmatic entrances. Only old harbor prerequisites are fabricated. Both actual `attempt-only.json` snapshots contain only attempted game-001, empty photos and no reward receipts. No attempted/card/finished result is injected to manufacture the target qualification.

The controller's prior/current visual observations were accepted as scoped evidence; this reviewer did not repeat screenshot inspection or run an engine suite. No unanswered implementation doubt justified repeating the already-passed suites.

## Cannot verify / limits

- This is the Task 3 review, not full CI, Linux integration, export/standalone/PCK verification, actual 800x600/1920 release rendering, or new-suite registration. Those remain explicitly assigned to Task 4/parent.
- Retained logs establish reported results, not independent recreation of every historical run. Native logs/helper/artifacts corroborate successful native flows; this review did not independently relaunch the native windows or re-observe their process exit codes.
- Direct button-signal automation is programmatic UI coverage, not physical pointer/key routing, human playtesting or audio/hardware acceptance. Headless image injection does not establish rendered pixels; the separate native runs provide that evidence.
- Same-directory replacement protects an individual image file. Cross-file power-loss atomicity is neither implemented nor claimed. The earlier pinned platform rename probes were inherited evidence, not rerun here.

Only this private report was written. No source, test, index, HEAD, branch, existing evidence, or player profile was modified; no subagents were spawned.
