# SG-29 Task 1 review

Date: 2026-11-13. Reviewed BASE `83ae664a189253ecf34222c73a69fff866ccd409` through HEAD `f6c25a972f957bcc84713e7246fd577a6d1c35e3` in `C:/Users/stanl/Github/Snapland/.review/photo-retake-worktree`.

## Verdicts

- **Spec: changes required.** The requested Task 1 interfaces and reward transaction are present, but the mixed retake/gameplay attachment fallback can misrepresent a staged image as a gameplay image and overwrite a previously valid gameplay thumbnail.
- **Code quality: changes required.** One actionable P2 correctness regression in the shared attachment code; no separate architectural, dependency, or style findings. The small shared award extraction is appropriate and avoids a parallel transaction implementation.

These verdicts refer to the same single finding below, not two separate defects. No Task 2/3 launch, UI, capture-writing, cleanup, or CI-registration work is required by this review.

## Actionable finding

### P2 — Keep fallback images within their acquisition source

**Location:** `game/core/progress.gd:284-285` (assignment at `293`), in `attach_game_photo_frames`.

The new target filter correctly excludes retake records from writes, but the fallback source is still always the ordinary record. With an ordinary retake card and a genuinely earned gameplay devil card, unreadable incoming frames therefore cause the staged ordinary retake frames to be copied into the gameplay devil record. If the devil already had a valid gameplay thumbnail, that thumbnail is replaced. Its existing gameplay original remains unchanged when no new original validates, producing a staged thumbnail paired with an unrelated gameplay original. The function returns true and persists the result.

Concrete sequence against the reviewed HEAD:

1. Record an attempt for game-013; complete its ordinary retake with a teal thumbnail and matching original.
2. Complete a genuine devil game; attach a coral gameplay thumbnail and original. The ordinary retake is preserved and the gameplay devil correctly contains coral images.
3. Call `attach_game_photo_frames("game-013", [missing_path], true, [])`.
4. Observed: return true; gameplay devil `frames` now equals the teal retake paths; its `original_frames` still equals the coral gameplay original; ordinary retake metadata is unchanged.

The public attachment API already supports an invalid-replay fallback, so this is a supported error path rather than a malformed private call. Main's existing `_sync_finished_photo_thumbnails` invokes this shared API. The migration at lines 313-315 already avoids the equivalent source mixing during load, but attachment does not.

**Requirement affected:** Task 1 brief line 10 requires that first acquisition provenance and retake photos remain truthful while existing gameplay cards preserve replay behavior. The runtime spec distinguishes actual set photographs from gameplay photographs and requires the acquisition source to remain clear. Preserving the retake record itself does not make copying its set image into a gameplay record truthful.

**Smallest correction:** retain ordinary fallback for the existing gameplay-only pair; when ordinary is retake, never use it as a gameplay target's fallback. Preserve/validate the target's own existing gameplay frames, or report failure if no valid gameplay source exists. Keep the retake record untouched. Add one focused mixed-provenance invalid-replay regression; assert the existing gameplay thumbnail/original and retake record stay unchanged and no staged image is borrowed. Cover an empty gameplay target as well if the correction distinguishes it.

**Evidence:** a single focused probe ran with Godot `4.7.2.stable.official.ed1daf0bf`, a fresh absolute isolated `SNAPLAND_SAVE_PATH`, and a temporary script outside the repository. Exit 0; one expected missing-file warning; output:

```text
REVIEW fallback_return=true
REVIEW gameplay_devil_now_has_retake_thumbnail=true
REVIEW gameplay_original_still_unrelated=true
REVIEW ordinary_retake_unchanged=true
```

Probe and isolated files: `C:/Users/stanl/AppData/Local/Temp/snapland-task1-review-207b1638-0230-426b-aab7-7c1a309ebfa5/`. No existing suite was rerun.

## Spec compliance otherwise observed

- Canonical delivered IDs are checked through GameCatalog; aliases, whitespace variants, and undelivered game-014 are rejected. Attempt histories are catalog-ordered, deduplicated, bounded by delivered definitions, validated on load/save, recognized as a known field, and cleared on reset. Missing legacy history infers only actual canonical card keys; unknown root/photo metadata is preserved.
- `mark_game_attempted` saves before success and rolls back a failed insertion. Main launch timing remains Task 3; the current absence of launch callers is not a Task 1 defect.
- `complete_retake` requires a recorded attempt, a missing selected card, one to three fully validated 320x180 thumbnails, equally many fully validated bounded originals, and no partially invalid list. Selected devil retake does not silently grant ordinary.
- `complete_game` keeps its signature and boolean contract. `_award_game_cards` shares the existing transaction with snapshots of photos, achievements, coins, receipts, and platform queue; failure restores those fields before any success signal. The one global receipt is shared by both paths, and either old ordinary or old devil prevents retroactive money.
- Retake cards store acquisition_method=retake and challenge_earned=false. Genuine devil completion sets challenge_earned=true while preserving the original retake provenance and photo metadata. Direct attachment targets and load migration protect retake records; the fallback exception above remains.
- Session's common legacy natural finish now explicitly supplies ordinary_eligible without changing success, score, or devil truth. Driver eligibility is retained and combined with not-practice. Cancellation sets ended for legacy and driver paths, preventing late finish after cancel from emitting an award-eligible natural result.
- Concrete affected expectations were updated rather than weakened: test_core's saved payload includes attempted_games, and rowing Session requires ordinary_eligible for a legacy natural result. The new UIDs and the two focused test suites are included. No production image-writing code, dependency, or speculative framework was added.

## Evidence and scope checked

Read the immutable review diff, task-1-brief.md, global-constraints.md, task-1-report.md, design/runtime/free-photo-retake.md, AGENTS.md, changed production/test files, GameCatalog, existing image validators/save/load/reset logic, and complete_game/attachment/result callers. The provided explicit no-subagent/read-only review scope was observed; only this private review report was written inside the worktree.

Verified HEAD equals the reviewed commit, the commit contains exactly the eight owned source/test/UID files, and the working copies of all eight match HEAD. The earlier force-tracked implementation report is absent from the final diff. No code, index, commit, branch, or existing evidence log was mutated.

Inspected the retained final evidence rather than rerunning passing suites: `.review-task1-results.json`, `.review-task1-final-results.json`, `.review-task1-verified-progress.log`, `.review-task1-green-participation.log`, and the regression log markers/error counts. Final progress and participation logs report PASS with zero ERROR lines. Core, wardrobe, photos, originals, harbor, save guard, rowing Session, ribbon startup, and ribbon finish logs are consistent with the report's green results. The retained clean participation red log contains 36 intended failures. An earlier `.review-task1-green-progress.log` contains three errors and is superseded by the zero-error final/verified progress evidence; it was not treated as final green evidence.

The current tests exercise successful mixed acquisition attachments, preservation through reload, exact write-block rollback, receipts, attempt persistence, selected-only grants, later genuine challenge proof, and all thirteen Session result contracts. They omit the mixed-acquisition invalid-replay fallback that exposed the finding.

## Cannot verify / limits

This was a Task 1 review, not full CI or native playtesting. No Windows native UI/capture flow, Linux run, photo-writing atomic replacement, stale shutter callback, launch gating, or three-step UI was verified; those belong to later tasks. Retained logs establish reported run outputs, not independent recreation of the complete historical red/green process. The initial missing-API red claim was reviewed against the API additions and report; no retained initial progress-red log was found in the inspected evidence set. The focused reproduction above independently verifies only the identified fallback defect.

**Summary:** one P2 finding. Task 1 is otherwise narrowly implemented and supported by the supplied local evidence; repair the shared mixed-provenance fallback and add its focused regression before approving it.
