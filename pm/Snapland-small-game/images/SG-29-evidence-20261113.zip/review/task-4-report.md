# SG-29 Task4 report

Date: 2026-11-13. Base: 6404ce5da0fa54e1a96f4da5cdce4fa75bafec91. Branch: codex/free-photo-retake-20261113. Worktree: C:/Users/stanl/Github/Snapland/.review/photo-retake-worktree. This report, scripts, logs and screenshots stay ignored beside this report; none is force-added. Commit recorded below after submission.

## Scope and final behavior

Exactly nine owned paths: tools/run_game_tests.py; tests/test_runtime_result_contract.py; game/tests/native_photo_retake.gd; game/tests/native_photo_retake.tscn; game/tests/retake_native_route.gd; game/tests/test_retake_native_fixture.gd; game/ui/collection_book_panel.gd; game/tests/test_harbor_collection.gd; game/tests/test_pixel_ui_collections.gd. The plan originally named a nonexistent test_game_test_runner.py; parent explicitly corrected ownership to the existing house result-contract module. The temporary new test file was removed; no duplicate registry/golden115 list remains. Parent owns docs/spec/plan changes, exports, whole-branch checks, PCK/EXE QA, ticket and publishing.

Runner registers all five new suites in the existing single build_checks catalog and requires exact whole-line completions for those labels. No timeout, engine selection, error handling, old-suite command/marker, independent suite directory or shard hashing behavior changed. Parent independently compared immutable6404 baseline to current runner: all115 old labels/argv/relative order/markers retained; exactly120 runtime suites plus import. Existing house tests exercise real-catalog stable four-shard exact-once/order, independent profiles, default90seconds and unchanged avatar-renderer240seconds exception.

Two concrete controller-authorized production corrections were necessary for native acceptance:

1. Game-card tooltips now contain only the next action: 查看原圖 / 免費補拍 / 先練習再免費補拍. Complete canonical ID, region, fixed kiosk, eligibility and acquisition/technique provenance remain in visible album details. Non-game tooltips are unchanged. Existing harbor fixture assertions cover collected/missing actions without changing its22-check completion contract; native covers attempted missing action.
2. True800x600/1.25 revealed two full-height card rows beneath the fixed pager. Narrow noncompact page capacity now compares real grid-to-pager space to two maximum natural current-category content heights plus the existing gap. All current entries participate so page changes cannot alter capacity merely because another caption is taller. Wide4-column and compact450 behavior remain. Deferred responsive rebuild preserves the selected full detail; before remapping visibility, it moves to the page containing the actual focused tile, and after rebuilding restores that same tile's focus. No extra state, helper, option, component, automatic action or redesign was added.

Every caller of the touched album capacity/remap/rebuild/tile methods was searched; they are internal album layout/category/page paths plus concrete fixtures. Fixed controls, region selector, photo IDs, category ordering, original viewer, non-game entries, collection and reward persistence retain their existing interfaces.

## Native fixture APIs and truthful inputs

Source entry: res://game/tests/native_photo_retake.tscn. Node script: native_photo_retake.gd. Its only test-only dependency is retake_native_route.gd, resolved exclusively from get_script().resource_path.get_base_dir(). No res://game/tests fallback, repository absolute path, debug export or production automation switch exists. The helper delivers normal Viewport.push_input key events, including Tab and Enter; buttons are focused and activated through actual GUI event dispatch. Entry methods opening kiosk/rules/album and category selection are explicitly labelled programmatic. Supplemental repeated already-collected _request_retake is labelled programmatic and cannot mutate gameplay results.

Required environment: absolute unique SNAPLAND_SAVE_PATH, absolute RETAKE_CAPTURE_DIR, RETAKE_REVIEW_MODE=welcome|harbor|read. Optional RETAKE_LARGE_TEXT=1 sets1.25 text and reduced motion in fresh writers. GPU is required; writer refuses an existing nonempty profile. Both writers launch real Main, enter real selected practice, then GUI PauseButton -> LeaveButton -> ConfirmAction. The actual saved attempt is copied raw to attempt-only.json before either selected target award. It is not reconstructed or edited JSON. Welcome snapshot contains attempted_games=[game-001], photos={}, receipts=[]; harbor contains the six explicitly labelled synthetic OLD welcome prerequisites, attempted_games=[game-013], no harbor target and no receipt. Harbor prerequisite loop only grants missing old IDs and never overwrites an acquired photo record.

The fixture walks observation -> adjustable set -> actual shutter using visible controls, Tab/Enter choice changes, Back and Next. It compares actual rendered set bytes before/after adjustment, then verifies the saved decoded original equals the actual arranged SubViewport image pixel-for-pixel. It collects devil first while ordinary remains absent, checks the actual first-card stamp, shows retake/technique provenance, opens the actual original viewer, checks repeated request produces no payout, cancels/reopens ordinary, and completes ordinary without another40coins. Existing devil metadata and both PNG byte arrays are preserved. Harbor exercises free return and genuine reentry.

Welcome creates one real isolated progress.json.tmp directory obstruction at shutter, verifies no target award and visible retry copy, removes only that obstruction, and retries the real shutter successfully. It then launches actual game-003 formal fountain with no input. Automatic Session processing is disabled solely to call normal Session._process(0.1) at fixed steps; no timer, score, model state, result, card, attempt or finish field is assigned, and no finish method is called. Actual result remains success=false, devil=false, ordinary_eligible=true, practice=false, score=0, mistakes=3; only ordinary participation is collected and no success celebration occurs.

Reader uses an independent process/profile containing a raw byte copy of an actual completed writer. It validates actual saved attempts, one receipt, truthful retake/challenge provenance,320x180 thumbnail and1280x720 original decoding, album and stamps, and exact unchanged JSON bytes. It never resets or saves progress in read mode. Absolute original-photo references remain pointed to the completed writer directory.

## Package dependency preflight and bootstrap

res://game/tests/test_retake_native_fixture.gd loads the source fixture and helper, copies the actual fixture into its isolated profile sidecar directory, and proves it has NO helper while the repository helper still exists. After explicitly copying only the adjacent helper, it proves the external fixture resolves that own helper path. The entry scene, real production Main, real RetakePanel, every delivered lesson's actual1280x720 tutorial PNG, prop atlas and prop-regions JSON load. Latest preflight: task4-evidence/preflight-1280x720-41b7d02549ad4ce6b2e631e5fa6ed3b4, exit0, exact one PASS marker, zero ERROR lines. This checks explicit dependencies; actual independent PCK remains parent gate.

For parent isolated pack: exclude game/tests before importing/exporting production. Copy native_photo_retake.gd AND retake_native_route.gd into one absolute external directory. Do not use the source .tscn, which intentionally references source-only tests. External bootstrap:

```gdscript
extends SceneTree
func _initialize() -> void:
    call_deferred("_run")
func _run() -> void:
    root.add_child(load("C:/absolute/external/native_photo_retake.gd").new())
```

Pinned command template (run from independent pack directory, no repository fallback):

```text
C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --main-pack C:/absolute/isolated/Snapland.pck --script C:/absolute/external/bootstrap.gd --resolution 800x600 --audio-driver Dummy
```

Set required absolute isolated save/capture paths and mode; set RETAKE_LARGE_TEXT=1 for800x600. Use1280x720/1920x1080 as needed. Every fresh writer gets its own profile directory. For read, copy actual writer progress.json bytes into a new private profile and retain the writer's absolute photo files; set mode=read. Native internal watchdog85seconds, outer launch timeout90seconds. Actual release template ignores external --script; use pinned editor for independent PCK and actual UI on the genuine standalone EXE. No production automation shortcut is introduced.

Native completion is exactly one line:

```text
PASS: native retake welcome actual UI, selected photos, provenance and restart contract
PASS: native retake harbor actual UI, selected photos, provenance and restart contract
PASS: native retake read actual UI, selected photos, provenance and restart contract
```

For a welcome writer, accept EXACTLY one error line, matching its complete unique path:

```text
ERROR: Cannot write progress temporary file '<SNAPLAND_SAVE_PATH>.tmp': Can't open file
```

Harbor/read/preflight accept zero ERROR lines. No broad allowlist, suppression, script/parse error or shutdown/leak error is accepted. Inherited welcome OcclusionController material warnings remain visible:15 per welcome construction. Welcome writers/read-welcome have15; harbor writers start welcome and later return there, so30; read-harbor starts directly there and has0. They are not missing resources or retake diagnostics.

## Registry completion contracts and checks

All five runner labels and actual source completion lines:

- photo retake progress tests -> PASS: attempt history, selected retake awards, provenance and atomic rollback
- participation result tests -> PASS: thirteen participation results, practice, cancellation and driver eligibility
- retake panel tests -> PASS: retake panel canonical targets, reversible state, keyboard and capture guards
- photo retake Main tests -> PASS: Main selected retakes, actual attempts, truthful awards and safe PNG replacement
- retake native fixture tests -> PASS: retake native fixture adjacent helper, isolated packaging and real resources

Actual runner command (GODOT_BIN set to pinned path):

```text
python tools/run_game_tests.py --only "photo retake progress" --only "participation result" --only "retake panel" --only "photo retake Main" --only "retake native fixture"
```

Evidence task4-evidence/focused-runner.log: import + all5 RUN/PASS rows, exit0, standard90second limits. Timings12.31/0.95/9.28/17.29/33.15/2.27seconds. This registry run preceded the subsequently authorized narrow album/focus corrections; current preflight and affected UI suites were rerun afterward. Parent owns full exact-commit runner/four-shard repetition.

```text
python -m unittest tests.test_runtime_result_contract tests.test_runtime_shards tests.test_godot_entrypoints -q
```

Latest task4-evidence/focused-python.log:48 tests, OK. New entry/marker contracts reject missing/quoted/suffixed completions and engine/script errors, using the existing house module. Existing tests prove current real catalog partition/profile/timeout contracts. Initial missing-registration red produced five missing-entry plus dispatch/count failures before registration; the initially created parallel test file was then removed per parent correction.

Affected engine command helper uses pinned engine, absolute fresh temp profile per invocation and subprocess timeout90:

```text
python .superpowers/sdd/2026-11-13-free-photo-retake/run-task3.py task4-album-focus-green test_pixel_ui_collections.tscn test_harbor_collection.gd test_album_photo_viewer.tscn test_main_photo_thumbnails.tscn
```

All4 exit0/zero errors after final focus correction. Raw JSON/logs remain task3-evidence/task4-album-focus-green*. Full geometry includes actual800x450,800x600,1280x720,1920x1080 at1.25, first empty render, filled selected full retake detail, stable capacity/details, all ordinary/devil/time pages exactly once, harbor->welcome region switches, fixed controls/return and actual original viewer. A real Main fourth-card1280->800600 reflow keeps game004 visible on page1 and focused; GUI Enter launches that exact Main practice target. Earlier task4-album600-final group also passed Main owner retake suite before this final focus-only correction.

Red evidence retained: task4-tooltip-red has exactly2 expected concise-tooltip assertions; task4-album600-red has exactly2 true600 overlap assertions; focus-resize-probe.log reproduces game004 capacity4/focus -> capacity2/page0/NONE; task4-album-focus-red has exactly2 expected focus/Enter assertions. Final green resolves those findings. Failed preflight parse/type inference and early native fixture pause/collected-kiosk assumptions are retained as FAILED development evidence, not claimed as delivered passes. Early native ordinary-provenance800 images showing four clipped cards are FAILED visual evidence and superseded below.

## Source-native evidence and exact provenance

All directories below are under .superpowers/sdd/2026-11-13-free-photo-retake/task4-evidence. Each has launch.json (full args/env/profile/exit/errors), stdout.log, stderr.log, native-report.json, captures and actual profile/photos. The byte-level audit is final-source-verification.json: current9owned file SHA256, each accepted run's exact one completion marker, precise errors/warning counts, actual result, raw attempt SHA256 and per-output hashes/dimensions. No prediction is treated as execution evidence.

FINAL production album/focus source, freshly rerun:

- welcome800x600: welcome-800x600-c61a48f545ad41408452458c1ceca1b0.15 PNGs,1 deliberate error,15 inherited warnings.
- harbor800x600: harbor-800x600-e8f9b511691c4a32987c73384119bc79.14 PNGs,0 errors,30 inherited warnings.
- Independent reader of that welcome writer: read-1280x720-b33f22d5be234059976a2658c1c00838.2 PNGs,0 errors,15 inherited warnings.
- Independent reader of that harbor writer: read-1920x1080-817916d6476044f6ba46d36040efc9aa.2 PNGs,0 errors,0 warnings.

Earlier successful unchanged retake-route evidence, RETAINED ONLY for unchanged tutorial/set pixels, GUI/shutter/original/persistence workflow, not labelled identical final-runtime/HEAD album snapshots:

- welcome1280x720: welcome-1280x720-c76ff7110f2b408891b1c46e09ab1906.15 PNGs,1 deliberate error,15 inherited warnings.
- welcome1920x1080: welcome-1920x1080-8ba1869048b5426e8f5e7b491db752ee.15 PNGs,1 deliberate error,15 inherited warnings.
- harbor1280x720: harbor-1280x720-51db8fa29ebb4ea7b5b627c57d52def1.14 PNGs,0 errors,30 inherited warnings.
- harbor1920x1080: harbor-1920x1080-f92667c307584f45b37f9580f9b4f529.14 PNGs,0 errors,30 inherited warnings.

Those four wide runs use the exact same final native_photo_retake.gd/.tscn/retake_native_route.gd; later delta is solely approved album capacity/focus and its existing geometry fixture. Wide capacity still exits immediately with original4-column behavior. Final focused geometry covers all4sizes; final800native/read revalidate changed behavior. Parent final exact-commit PCK/EXE1280 will additionally cover the final wide album. The audit records current source hashes, not a false claim that all8 complete runtime processes loaded identical source.

Every800600 capture records OS client800x600, PNG800x600 and logical viewport1280x960 with canvas_items/EXPAND; none is800x450 letterboxing.1280x720 captures record logical1280x720;1920x1080 captures record physical1920x1080/logical1280x720. Photograph originals remain1280x720 by actual panel contract. PNG headers independently checked against recorded OS windows. Both final small writers use1.25 and reduced motion.

Personally inspected actual PNG files: corrected final welcome/harbor800 ordinary-provenance (all cards/captions above fixed pager), first-devil-only stamps,800 adjusted set and real original viewer,1280 before-set/provenance and1920 save-failure. Controller independently inspected corrected800 collection,1920 retake and800 stamp/adjustment. This is automated GUI/native visual evidence; it is not human fun or audio acceptance.

## Self-review and remaining ownership

Reviewed source/adjacent-helper loading, missing-helper refusal, fresh writer guard, read-only actual writer copy, raw attempt snapshot timing, synthetic prerequisite boundaries, actual practice/HUD cancel, GUI Tab/Enter routing, three reversible steps, true shutter/pixel identity, save-failure retry, first-devil-only stamp, ordinary independence, original viewer, existing photo metadata/bytes, one global receipt, genuine no-input failure, free travel/return, exact diagnostics, resource shutdown and timeout. Also reviewed responsive current-category minima, fixed-band capacity, selected detail preservation, stable pagination and focused latter-half target/page/Enter after resize. All required focused checks pass; git diff --check passes owned paths. No branch switch/push/subagent/dependency/forced scratch commit/unrelated cleanup occurred. Other workers' docs and untracked import/UID metadata are preserved.

Not rerun here: full exact-commit Python/source/four-shard CI, clean independent PCK, genuine final standalone EXE, cloud and unchanged exhaustive SG28 physics; parent owns them. Earlier wide native route evidence is explicitly pre-album-fix as above. No production changes beyond the two approved album defects. No claim of human play/audio approval or cross-file crash atomicity.

## Commit

90ee94c08ceddf5d0ca038e7269be335261cedf5 — test: register retake suites and validate native delivery. Exactly nine owned paths; author and committer Stanley Li <stanley890314@gmail.com>. Owned working copies match HEAD; index empty. No push.
