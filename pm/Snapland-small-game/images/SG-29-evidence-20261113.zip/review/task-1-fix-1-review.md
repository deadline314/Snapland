# SG-29 Task 1 fix round 1 rereview

Date: 2026-11-13. FIX_BASE `f6c25a972f957bcc84713e7246fd577a6d1c35e3`; reviewed HEAD `7adc04e60767ec7f30bc7ac67f04c66634e7122d`.

## Verdict

**ADDRESSED.** The original P2 source-mixed fallback is fixed. Scoped spec and quality review both pass. **New breakage: None found within the fix diff.**

## Fix assessment

`game/core/progress.gd:285-286` now takes its fallback from the already filtered gameplay `targets[0]`, rather than unconditionally reading ordinary-card frames. The earlier empty-target return makes indexing safe. The target filter guarantees the source is an existing Dictionary with acquisition_method other than retake.

For gameplay-only pairs, the ordinary record remains first, preserving the previous shared ordinary fallback. For ordinary-retake/devil-gameplay pairs, only the genuine gameplay devil is eligible: its validated existing thumbnail is retained, or the call returns false before changing/saving anything when no valid gameplay source exists. Reverse mixed pairs still use the gameplay ordinary record. Retake metadata/images, original handling, reward logic, and failed-save rollback are unchanged.

The seven added test lines in `game/tests/test_photo_retake_progress.gd:119-128` exercise both welcome and harbor, in both mixed-acquisition directions. They cover no valid gameplay image (false return, identical memory snapshot and saved bytes) and a previously valid gameplay thumbnail/original (successful fallback, identical snapshot and genuine image paths retained). These assertions directly cover the reported defect and its empty-target-image case without changing existing assertions.

## Evidence inspected

Read task-1-fix-1.md, the appended fix section of task-1-report.md, immutable review-f6c25a9..7adc04e.diff, the changed attachment body/test context, and retained fix evidence. Verified current HEAD is the reviewed commit, the commit changes only Progress and test_photo_retake_progress, and both working copies match HEAD.

The retained `.review-task1-fix1-red.json` and `.review-task1-fix1-red.log` show exit 1 with exactly six intended assertions: three source-mixing failures for each ordinary-retake/gameplay-devil region pair. The reverse pairs were not the broken path.

The retained `.review-task1-fix1-green.json` and corresponding logs agree:

| Suite | Exit | ERROR lines | Result |
|---|---:|---:|---|
| Complete photo-retake progress | 0 | 0 | PASS; 1.13 seconds |
| Shared photo thumbnails | 0 | 0 | PASS; 2.89 seconds |
| Photo originals | 0 | 0 | PASS; 2.53 seconds |

All report the pinned Windows Godot 4.7.2 commands and separate absolute private SNAPLAND_SAVE_PATH profiles. The implementation report records a 90-second timeout for each run. No existing suite was rerun during this rereview because the diff and focused red/green evidence resolve the finding without an unanswered runtime doubt.

## Limits

This is a scoped rereview of the original P2 and introduced breakage only, not a fresh broad Task 1 review. No code, index, HEAD, branch, or retained evidence was mutated; only this private report was written. No subagents were used. Full CI, native UI/capture flows, later tasks, and the parent's planned Linux progress repeat were not checked here.

The original P2 is closed; no remaining concern was found in this correction's scope.
