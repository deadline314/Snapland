**Stale formal/practice HUD result copy assertions** — ADDRESSED — [test_minigame_hud.gd:130](game/tests/test_minigame_hud.gd:130) asserts the exact approved ordinary-and-devil qualification and trailing score `816`; [test_minigame_hud.gd:132](game/tests/test_minigame_hud.gd:132) retains the no-collection practice message, exact trailing `816`, and rejects qualification claims. Production HUD copy at `game/ui/minigame_hud.gd:114-116` matches both assertions.

### New Breakage in the Fix Diff

None. The immutable diff changes only those two existing assertion expressions/messages; it does not touch production behavior or remove checks.

### Out-of-Scope Observations

None.

### Evidence Checks

- Confirmed `windows-red` and `linux-red` manifests/logs record only the expected stale formal-result assertion failure, with exit 1 and no PASS marker.
- Confirmed `windows-green` and `linux-green` manifests record exit 0, no errors, and `PASS: minigame HUD hierarchy checks (71 checks)`.
- Confirmed all four manifests use the same HUD script and fresh isolated save paths; no test suite was rerun during this review.

### Verdict

**Fix round:** All findings addressed, no new Critical/Important breakage.
