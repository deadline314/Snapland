# SG-29 Task 2 review

Reviewed immutable range `7040d6062540f09c0c3cdc676418850ad01ca647..d203d356d9c7f5b456656ff7f88047fc5cc335e8` using `review-7040d60..d203d35.diff`, Task 2 brief, global constraints, runtime spec and Task 2 report. Scope: the reusable panel, state and native capture only. Main eligibility, persistence, awards, album, packaged build and suite registration belong to later tasks.

## Spec verdict: PASS

No actionable specification findings in the reviewed scope.

- `game/ui/retake_panel.gd:89`: one-time setup checks the complete canonical delivered definition and exact matching validated lesson; copies isolate the target from caller mutation. Canonical IDs are required rather than accepting the catalog's mode aliases. Invalid setup reaches a readable disabled fallback.
- `game/ui/retake_panel.gd:120`: imported `Texture2D` loading, bounded positive dimensions before readback, decoded image/dimension checks, atlas-region bounds and whole-avatar validation protect the photograph source. Missing data clears the source and blocks navigation/capture. The panel does not write files or award anything.
- `game/ui/retake_panel.gd:233`: ordered observe/adjust/shutter navigation, preserved cyclic choices, named buttons, keyboard focus and Paper sizing implement the three reversible untimed steps. Observation shows the canonical lesson goal. Demonstration and the arranged set are explicitly distinguished from earned gameplay/challenge results.
- `game/ui/retake_panel.gd:178`: one fixed 1280x720 viewport supplies the displayed adjusted preview and shutter readback. Static authored backdrop, whole avatar and selected whole prop avoid duplicating thirteen game simulations. Existing quest `photo_stage.gd` remains untouched; its five scene-specific drawings and processing are not an existing equivalent of this static tutorial-backed set.
- `game/ui/retake_panel.gd:280`: capture waits for rendering, checks image dimensions/nonempty content, blocks double shutter, waits for owner acknowledgement, permits retry after failure and makes success terminal. Close/generation/tree checks invalidate pending work. Capture controls are outside the photograph; provenance labels are part of the set.

## Quality verdict: PASS

No actionable correctness, safety, resource-lifetime or maintainability findings in the reviewed change. No severity/file:line issue is being requested for correction.

The change is limited to the two planned new files (331 production + 142 test lines). It reuses Paper, TutorialCatalog, GameCatalog, AvatarRenderer and the authored prop atlas without changing their contracts. One viewport, event-driven redraw/UPDATE_ONCE and one image readback per shutter avoid per-frame texture construction. Source/viewport ownership remains with the panel; the prior focus is weakly referenced and checked before restoration. Awaiting/saved/closed guards prevent unsolicited acknowledgements and further capture after completion/close. No new dependency, production test hook, synthetic gameplay result or persistence side effect was introduced.

The committed tests intentionally inspect internal state and emulate pending acknowledgement only for state coverage. They do not present headless execution as rendered-image proof. The ignored native fixture separately exercises actual render/readback and deferred-capture cancellation.

## Evidence reviewed

- Confirmed the working source/test blob hashes equal the pinned HEAD blobs (`1d8fcd0f7b5a99e945a04e0fecd81b6607a94c49` and `212dcde2955a15f57c690142def25428f66c8981`). The saved immutable diff contains exactly the two planned files. Read-only `git diff BASE HEAD --check` passed. Pinned commit author and committer are Stanley Li <stanley890314@gmail.com>, without coauthor attribution.
- `.review/task2-red.log` records the missing-panel failure before implementation. `.review/task2-headless-complete.log` records PASS under pinned Godot 4.7.2; its stderr is empty. The committed suite covers all thirteen delivered targets, invalid aliases/planning IDs, mismatched/mutated lessons, immutable setup, reversible ordered steps, cyclic keyboard choices/focus, early/headless shutter rejection, acknowledgement state, close and invalid/oversized source.
- Read `.review/task2-native.gd` and both final `.review/task2-reviewed800.log` / `.review/task2-reviewed1280.log`; both record PASS and have empty stderr. The fixture uses absolute isolated save/output directories, an 85-second watchdog and real Vulkan rendering. Logs record actual choice pixel differences, exact shutter-to-preview source byte equality, 1280x720 nonempty captures, duplicate blocking, failure retry with a second real capture, terminal success, keyboard Tab/Enter and contained 44px footer targets.
- Native cancellation evidence covers destroy-before-render at both sizes and close-without-freeing-before-render at 1280. All eight post-close samples are identical within each run: nodes 4/resources 30/texture memory 5,982,464 bytes at 800 and 6,441,216 bytes at 1280. This supports stable post-close ownership rather than claiming zero global/cache allocations.
- The final evidence directories contain observe, adjust-before/after, shutter, saved, missing-fallback and actual set-before/set-photograph PNGs at both sizes. Parent visual inspection of final 800 observation/adjustment/actual photograph/fallback and 1280 adjustment found readable layout, contained footer and visible provenance; no visual correction was requested. This review does not replace that inspection with an invented additional playtest.

## Limits and integration obligations

No passing suites were rerun because no specific unanswered defect required it. Saved native evidence covers representative welcome/harbor sets; all thirteen canonical targets are covered by the state suite, not thirteen separate native gameplay sessions. No packaged-export, audio or human fun/input playtest is claimed.

Later owner integration must bind the signal to its immutable selected target, validate and atomically persist the supplied image, acknowledge each current request once after its real save outcome, and dispose the panel on close. Eligibility/card receipts, existing photo preservation and stale owner callbacks after disposal require controller/persistence checks in the later task; their absence here is the explicit task boundary, not a panel review failure.

Only this review report was written. Source, index, HEAD and branch were not modified; no subagents were used.
