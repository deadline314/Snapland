### Task 1: Attempt history, honest natural results and atomic selected-card awards

**Files:** Modify game/core/progress.gd, game/minigames/session.gd; create game/tests/test_photo_retake_progress.gd and game/tests/test_participation_results.gd. Existing affected progress/save guard fixtures may be amended only for concrete changed contract/dependencies.

**Interfaces:**
- Consume GameCatalog.identity(id), existing validated thumbnail/original helpers and save_progress() -> bool.
- Produce Progress.has_attempted_game(game_id: String) -> bool, mark_game_attempted(game_id: String) -> bool, complete_retake(game_id: String, devil: bool, saved_frames: Array, saved_original_frames: Array) -> bool.
- Persist attempted_games as validated deduplicated canonical IDs, maximum delivered count; reset clears, old valid game cards infer historical attempts, unknown future metadata stays preserved.
- Session natural _finish results always contain ordinary_eligible; legacy = not practice, driver retains its own natural eligibility AND not practice. Cancel remains separate.
- Existing complete_game signature/boolean and attach APIs stay compatible. Share the existing atomic reward transaction by a narrow private extraction, rather than a parallel copy. Retake metadata contains acquisition_method="retake" and challenge_earned=false. Genuine devil completion records challenge_earned=true; retain first acquisition provenance and retake photo paths (attachment must not replace an existing retake card's photos). Existing gameplay cards preserve replay behavior.

- [ ] Write focused failing tests: all thirteen natural false results remain success=false but ordinary eligible, practice/cancel excluded; bad/alias/unbuilt attempt IDs rejected; one attempt save/reload/reset; failed attempt save rolls back; canonical old-card inference.
- [ ] Add award tests: missing ordinary/devil selected independently, no other-card mutation, valid decoded 320x180 thumbnails and bounded originals required, no blank grants; one40coin receipt across both paths/replays; old ordinary OR devil without receipt no money; invalid target and no attempt fail; actual blocked save restores all photos/coins/receipts/achievements/platform queue/signals; real later devil proof updates without falsely winning from retake.
- [ ] Run red with pinned engine and private profiles, implement minimal shared changes, run green plus core/wardrobe/photos/original/harbor reward/save guard and Session affected regressions. No weakening assertions or limits.
- [ ] Self-review callers, apply-save known-fields/validation/payload/reset, exact image ownership and emitted signals. Commit only owned scope; report exact APIs/results.

