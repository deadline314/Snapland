# SG-29 Task 1 implementation report

Date: 2026-11-13. Worktree: `C:/Users/stanl/Github/Snapland/.review/photo-retake-worktree`. Branch: `codex/free-photo-retake-20261113`. Implementation base: `83ae664a189253ecf34222c73a69fff866ccd409`. Final implementation commit: `f6c25a972f957bcc84713e7246fd577a6d1c35e3` (author and committer `stanley890314@gmail.com`).

## Scope and APIs

Owned production files: `game/core/progress.gd`, `game/minigames/session.gd`. New tests: `game/tests/test_photo_retake_progress.gd`, `game/tests/test_participation_results.gd`, plus their Godot UID files. Concrete contract fixtures: core's persisted-payload snapshot adds attempted_games; rowing Session's legacy result assertion now requires ordinary_eligible. No callers outside that scope changed.

- `Progress.has_attempted_game(game_id: String) -> bool`: only delivered canonical IDs qualify.
- `Progress.mark_game_attempted(game_id: String) -> bool`: idempotent history update; performs a real save before reporting success; failed save erases only this insertion, emits no success signals. Main must call this only for an actual game launch, including practice; wiring belongs to Task 3.
- Persisted `attempted_games`: validated, deduplicated, catalog-ordered, at most thirteen delivered IDs. Both save payload and load sanitize the field; it is recognized as a known field and reset clears it. For legacy saves lacking the field, canonical ordinary OR devil card IDs infer attempts. Explicit present histories are retained after validation; arbitrary photo game_id metadata and planning-only card IDs cannot infer history. Unknown future root/photo metadata is preserved.
- `Progress.complete_retake(game_id: String, devil: bool, saved_frames: Array, saved_original_frames: Array) -> bool`: requires a recorded attempt, missing selected card, one to three decoded 320x180 thumbnails, an equal nonzero count of validated bounded originals. Reuses existing PNG size/decode checks; rejects any partly invalid list rather than granting a blank/partial capture. Existing selected cards return false without writes or rewards.
- Existing `complete_game(game_id, devil, assisted=false) -> bool` and both attach APIs remain compatible. A narrow `_award_game_cards` extraction shares the existing snapshot/save/rollback/signals transaction. No duplicate reward implementation or framework was introduced.
- Both award paths use one global game receipt. If either ordinary OR devil existed before the first receipt, no retroactive 40 coins are granted. Retake awards exactly its selected card with acquisition_method=retake, challenge_earned=false, and the supplied validated paths. Only complete_game(devil=true) writes genuine devil challenge_earned=true. It never changes a retake card's provenance or captures.
- Attach updates only gameplay-acquired records. Retake records retain their photos/originals. Legacy devil-photo migration skips either-card retake pairs to prevent borrowing staged retake images into a gameplay record. Existing gameplay-only sharing, fallback validation and exact failed-save rollback remain tested.
- Every natural Session result now has ordinary_eligible. Legacy uses not practice; the delivered driver retains its own eligibility AND not practice. success, devil, score and summary stay truthful. Cancellation remains a separate signal. Red tests exposed legacy _leave_from_hud setting ended only inside the driver branch: ended=true now applies to every cancelled Session, preventing cancel followed by late _finish from producing a natural result. Existing driver input/view/finale cleanup remains intact.

## Red, implementation, green

Pinned engine for every launch: `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe` (reported `4.7.2.stable.official.ed1daf0bf`). Every direct test/import launch supplied a fresh absolute SNAPLAND_SAVE_PATH under Windows TEMP. No real player profile was used. Child write-failure probes use a separate absolute `failed/profile.json` within the fresh suite directory; existing save-guard suite continues to verify a uniquely named fake default profile for its negative-path tests.

Initial new progress red command:

```powershell
$env:SNAPLAND_SAVE_PATH = Join-Path $env:TEMP ('snapland-task1-red-progress-' + [guid]::NewGuid() + '/progress.json')
& C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --audio-driver Dummy --path . --script res://game/tests/test_photo_retake_progress.gd
```

Result: exit 1, exactly the three missing API assertions (has_attempted_game, mark_game_attempted, complete_retake). The first participation red also encountered missing imported textures, so it is not used as a clean red baseline. Imported the fresh worktree with:

```powershell
$env:SNAPLAND_SAVE_PATH = Join-Path $env:TEMP ('snapland-task1-import-' + [guid]::NewGuid() + '/progress.json')
& C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --editor --import --path . *> .review-task1-import.log
```

Import exit 0. Clean participation red before production edits:

```powershell
$env:SNAPLAND_SAVE_PATH = Join-Path $env:TEMP ('snapland-task1-clean-red-' + [guid]::NewGuid() + '/progress.json')
& C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --audio-driver Dummy --path . --script res://game/tests/test_participation_results.gd *> .review-task1-red-participation.log
```

Result: exit 1, 36 intended assertions: twelve legacy modes each lacked explicit natural/practice eligibility and allowed a finish after cancel. No missing-import diagnostics in the clean red run. Driver contracts already passed.

Green participation command:

```powershell
$env:SNAPLAND_SAVE_PATH = Join-Path $env:TEMP ('snapland-task1-green-participation-' + [guid]::NewGuid() + '/progress.json')
& C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --audio-driver Dummy --path . --script res://game/tests/test_participation_results.gd *> .review-task1-green-participation.log
```

Result: exit 0, zero ERROR lines; PASS: thirteen participation results, practice, cancellation and driver eligibility. Natural failures use the common real finish path for each legacy game and actual model timeout for harbor; this is automated result-contract verification, not human playtesting.

The new progress suite verifies malformed/alias/unbuilt IDs, canonical bounds, one saved/reloaded/reset attempt, inferred ordinary/devil history for every delivered game, malformed-card rejection, future metadata, one-to-three matching capture requirements, wrong-size/missing/over-limit images, selected ordinary/devil independence, receipts/replays, old ordinary and old devil without receipts, other-card metadata/PNG preservation, mixed gameplay/retake attachments and legacy reload, later genuine challenge proof, and exact write-failure rollback. Its isolated child blocks the real `.tmp` write with a directory: two repeated attempt-save failures, one selected award failure and one genuine-technique update failure. It validates all memory fields, unchanged saved bytes, zero success signals, successful retries, and exactly four deliberate engine diagnostics. Outer suite contains zero ERROR lines.

## Targeted regressions (90-second timeout each)

Each command below ran from this worktree with `SNAPLAND_SAVE_PATH` set to the exact separate path listed. Commands were executed via Python subprocess.run(..., timeout=90); output scanned for ERROR lines. All exits 0, all outer logs have zero ERROR lines, none timed out. The save-guard negative/fake-profile exceptions are the established suite's existing isolated contracts.

### core

Save: `C:\Users\stanl\AppData\Local\Temp\snapland-task1-core-_6vz0kys\progress.json`.

```text
C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --audio-driver Dummy --path . res://game/tests/test_core.tscn
```

Exit 0; 0.76 seconds; ERROR lines: 0. PASS: core runtime checks

### wardrobe

Save: `C:\Users\stanl\AppData\Local\Temp\snapland-task1-wardrobe-l1dmoa8c\progress.json`.

```text
C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --audio-driver Dummy --path . --script res://game/tests/test_wardrobe.gd
```

Exit 0; 0.47 seconds; ERROR lines: 0. PASS: wardrobe runtime checks

### photos

Save: `C:\Users\stanl\AppData\Local\Temp\snapland-task1-photos-89zbkzpq\progress.json`.

```text
C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --audio-driver Dummy --path . res://game/tests/test_main_photo_thumbnails.tscn
```

Exit 0; 3.69 seconds; ERROR lines: 0. PASS: MAIN-13 shared photo paths, replay idempotence, legacy backfill, malformed/missing fallback

### originals

Save: `C:\Users\stanl\AppData\Local\Temp\snapland-task1-originals-g6e1_qqs\progress.json`.

```text
C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --audio-driver Dummy --path . res://game/tests/test_photo_originals.tscn
```

Exit 0; 4.2 seconds; ERROR lines: 0. PASS: bounded photo originals, shared collection metadata, safe viewer loading

### harbor

Save: `C:\Users\stanl\AppData\Local\Temp\snapland-task1-harbor-6ax4dh99\progress.json`.

```text
C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --audio-driver Dummy --path . --script res://game/tests/test_harbor_game_progress.gd
```

Exit 0; 1.79 seconds; ERROR lines: 0. PASS: harbor rewards, replay, legacy, captures, reload and atomic failure

### save-guard

Save: `C:\Users\stanl\AppData\Local\Temp\snapland-task1-save-guard-cgsvod4a\progress.json`.

```text
C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --audio-driver Dummy --path . res://game/tests/test_test_save_guard.tscn
```

Exit 0; 3.47 seconds; ERROR lines: 0. PASS: save guard child processes use a unique verified fake Godot profile; every rejected-path case preserves seeded sidecars

### rowing-session

Save: `C:\Users\stanl\AppData\Local\Temp\snapland-task1-rowing-session-eeg1vkgu\progress.json`.

```text
C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --audio-driver Dummy --path . --script res://game/tests/test_rowing_session.gd
```

Exit 0; 4.38 seconds; ERROR lines: 0. Rowing Session: 34 checks, 0 failures

### ribbon-startup

Save: `C:\Users\stanl\AppData\Local\Temp\snapland-task1-ribbon-startup-iqa26jib\progress.json`.

```text
C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --audio-driver Dummy --path . --script res://game/tests/test_ribbon_session_startup.gd
```

Exit 0; 4.84 seconds; ERROR lines: 0. PASS: Ribbon Session startup (3 checks)

### ribbon-finish

Save: `C:\Users\stanl\AppData\Local\Temp\snapland-task1-ribbon-finish-0wecw8z2\progress.json`.

```text
C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --audio-driver Dummy --path . --script res://game/tests/test_ribbon_finish_session.gd
```

Exit 0; 8.37 seconds; ERROR lines: 0. PASS: Ribbon Session lifecycle (61 checks)

### final-progress

Save: `C:\Users\stanl\AppData\Local\Temp\snapland-task1-final-progress-dw1byqw0\progress.json`.

```text
C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --audio-driver Dummy --path . --script res://game/tests/test_photo_retake_progress.gd
```

Exit 0; 1.25 seconds; ERROR lines: 0. PASS: attempt history, selected retake awards, provenance and atomic rollback

### final-photos

Save: `C:\Users\stanl\AppData\Local\Temp\snapland-task1-final-photos-bj1x32fx\progress.json`.

```text
C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --audio-driver Dummy --path . res://game/tests/test_main_photo_thumbnails.tscn
```

Exit 0; 2.64 seconds; ERROR lines: 0. PASS: MAIN-13 shared photo paths, replay idempotence, legacy backfill, malformed/missing fallback

### final-originals

Save: `C:\Users\stanl\AppData\Local\Temp\snapland-task1-final-originals-4a8w07ta\progress.json`.

```text
C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --audio-driver Dummy --path . res://game/tests/test_photo_originals.tscn
```

Exit 0; 2.64 seconds; ERROR lines: 0. PASS: bounded photo originals, shared collection metadata, safe viewer loading

Final progress rerun after adding persisted-reset and old-owned-selected no-op assertions:

```powershell
$env:SNAPLAND_SAVE_PATH = Join-Path $env:TEMP ('snapland-task1-verified-progress-' + [guid]::NewGuid() + '/progress.json')
& C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --audio-driver Dummy --path . --script res://game/tests/test_photo_retake_progress.gd *> .review-task1-verified-progress.log
```

Exit 0; zero ERROR lines; PASS: attempt history, selected retake awards, provenance and atomic rollback.

## Self-review and limits

Reviewed complete_game and attach callers using rg across Main/tests; all complete_game signatures retained. Reviewed apply-save known fields, validation, payload merging and reset; exact rollback snapshots include photos, achievements, coins, receipts, pending platform queue and history, while existing nested-signal suppression is retained. Reviewed thumbnail/original ownership, no PNG writes in Progress, canonical target IDs, selected-only behavior and gameplay replay compatibility. `git diff --check -- game/core/progress.gd game/minigames/session.gd game/tests/test_core.gd game/tests/test_rowing_session.gd` passed.

Production diff: Progress +80/-44 lines; Session +2/-2. Two concrete fixtures: +2/-1 total. New test files and UIDs are included. Import-generated existing .import metadata changes and parent SG-29 ticket edits were left unstaged and unmodified by cleanup. No branch switch, push, broad test run, subagent or new dependency.

Not checked: full CI, Linux, native screenshots, entry-flow wiring and three-step UI (parent/other tasks own those). Progress validates actual images and atomically persists reward state; image-file capture/writing/cleanup and caller launch timing remain Task 2/3 responsibilities. No highscore subsystem, new story success event, or fabricated challenge result was added.


Controller correction: this report stays ignored/private on disk and is not part of the implementation commit. Removed only this report from the index and amended the unpublished commit. Verified `git diff f3e0d41e83387da99769aa10a28bb051c820cc6b f6c25a972f957bcc84713e7246fd577a6d1c35e3 --` the eight owned source/test/UID paths has no changes; working copies also match HEAD. `git check-ignore` confirms this report is ignored and Test-Path confirms it remains on disk. No push or parent-edit changes.


## Fix round 1 — mixed-provenance fallback (review P2)

Fix base: `f6c25a972f957bcc84713e7246fd577a6d1c35e3`. Read task-1-fix-1.md and complete task-1-review.md. Finding: attachment filtered out retake write targets but still borrowed ordinary retake frames as fallback for a genuine gameplay devil. This replaced a valid gameplay thumbnail with a staged thumbnail while keeping an unrelated gameplay original.

Scope stayed exactly `game/core/progress.gd` and `game/tests/test_photo_retake_progress.gd`. Rechecked public attachment call sites before editing. Small correction: fallback comes from `targets[0]`, which is the gameplay ordinary record for existing gameplay-only pairs, or the gameplay devil when ordinary is excluded as retake. Targets are already validated existing Dictionary records excluding acquisition_method=retake, and the empty-target return precedes indexing. The existing bounded decoder revalidates the selected source. If no valid gameplay capture exists, return false before modifying cards/saving. No new helper, framework, API, default, dependency, or provenance rule.

Focused regression now checks both welcome and harbor with ordinary-retake/devil-gameplay and ordinary-gameplay/devil-retake pairs. Before any gameplay target has a valid capture, an invalid incoming frame must return false with all reward/photo metadata and saved bytes unchanged. After a genuine gameplay thumbnail and original are attached, an invalid replay must succeed by retaining the valid gameplay thumbnail and original, keep the retake record unchanged, and never borrow staged paths.

All runs used the pinned Windows Godot 4.7.2 executable and a fresh absolute private profile. Exact invocations and result evidence follow. Each subprocess.run call used timeout=90, stdout=PIPE, stderr=STDOUT, UTF-8 decoding; ERROR lines were scanned without suppressing diagnostics. No broad suite rerun.

### Focused red before source edit

SNAPLAND_SAVE_PATH: `C:\Users\stanl\AppData\Local\Temp\snapland-task1-fix1-red-cxnejom1\progress.json`.

```text
C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --audio-driver Dummy --path . --script res://game/tests/test_photo_retake_progress.gd
```

Exit 1; six intended assertion failures, three for each ordinary-retake/gameplay-devil region pair. Existing reverse-pair gameplay fallback remained green. Exact errors:

```text
ERROR: FAIL: mixed invalid replay fails when gameplay target has no valid image
ERROR: FAIL: failed mixed fallback cannot borrow staged captures or mutate saved cards
ERROR: FAIL: mixed fallback preserves genuine thumbnail and original without staged borrowing
ERROR: FAIL: mixed invalid replay fails when gameplay target has no valid image
ERROR: FAIL: failed mixed fallback cannot borrow staged captures or mutate saved cards
ERROR: FAIL: mixed fallback preserves genuine thumbnail and original without staged borrowing
```

Log: `.review-task1-fix1-red.log`; structured evidence: `.review-task1-fix1-red.json`.

### Green progress

SNAPLAND_SAVE_PATH: `C:\Users\stanl\AppData\Local\Temp\snapland-task1-fix1-progress-zxh_705l\progress.json`.

```text
C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --audio-driver Dummy --path . --script res://game/tests/test_photo_retake_progress.gd
```

Exit 0; 1.13 seconds; zero ERROR lines. PASS: attempt history, selected retake awards, provenance and atomic rollback. Log: `.review-task1-fix1-progress.log`.

### Green photos

SNAPLAND_SAVE_PATH: `C:\Users\stanl\AppData\Local\Temp\snapland-task1-fix1-photos-23v32fto\progress.json`.

```text
C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --audio-driver Dummy --path . res://game/tests/test_main_photo_thumbnails.tscn
```

Exit 0; 2.89 seconds; zero ERROR lines. PASS: MAIN-13 shared photo paths, replay idempotence, legacy backfill, malformed/missing fallback. Log: `.review-task1-fix1-photos.log`.

### Green originals

SNAPLAND_SAVE_PATH: `C:\Users\stanl\AppData\Local\Temp\snapland-task1-fix1-originals-jd1xwx0a\progress.json`.

```text
C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --audio-driver Dummy --path . res://game/tests/test_photo_originals.tscn
```

Exit 0; 2.53 seconds; zero ERROR lines. PASS: bounded photo originals, shared collection metadata, safe viewer loading. Log: `.review-task1-fix1-originals.log`.

Structured green evidence: `.review-task1-fix1-green.json`.

Self-review: one production branch changed, sharing the same target eligibility filter used for writes. Gameplay-only targets still fall back to ordinary exactly as before; mixed pairs fall back only to their eligible gameplay record. Invalid-source failure precedes any photo mutation, original assignment or save. Original handling, retake preservation, atomic save rollback and reward transaction are unchanged. `git diff --check -- game/core/progress.gd game/tests/test_photo_retake_progress.gd` passed. Diff: Progress +2/-1; new regression +7 lines. No parent edits or import metadata staged; every .superpowers file remains ignored/private.

Not rerun: unchanged Session/attempt suites separately, full CI, native UI or Linux. The complete progress suite still exercises history/transaction checks in this scoped green run; parent owns the next Linux progress repeat and scoped rereview.

Fix round 1 commit: `7adc04e60767ec7f30bc7ac67f04c66634e7122d`. Author and committer: `stanley890314@gmail.com`. Only Progress and test_photo_retake_progress are in this commit (9 insertions, 1 deletion); their working copies match HEAD. Report remains ignored on disk. No push.
