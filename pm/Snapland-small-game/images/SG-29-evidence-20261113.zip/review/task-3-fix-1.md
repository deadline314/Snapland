# Task3 fix round1 — complete findings

FIX_BASE b3e598167137a8f9686fb014523d0ec67142b578. Same worktree/author/ownership/privacy/no-push/no-subagents rules. Resume original implementer. One reviewer P2 and one controller-confirmed Linux fixture defect; fix together, preserve actual award/score rules.

## 1. Reviewer P2, verbatim

> Describe the per-game stamp as first-card collection, including devil-first retakes. Locations game/ui/achievement_stamp_book.gd:146 and242. The new condition says `條件：收藏這款遊戲的普通拍貼`, and the compact explanation says `灰色：收藏普通拍貼後蓋章`. Neither matches the actual achievement contract. Progress.complete_retake selects only the requested missing card, then _award_game_cards includes the per-game achievement regardless of card kind. A supported sequence is first practice and cancel game-001, retake only its devil card, then open stamp book. ACH_GAME_001 is unlocked while photo-welcome-game-1 remains absent, yet the tile says its condition requires that absent ordinary card.

Full review task-3-review.md. Correct both explanations to first/either-kind photo; align same wide summary heading if it still claims first game completion. Welcome ordinary-set milestone remains explicitly ordinary. No Core award change, no silently granting ordinary. Add a small focused assertion to existing devil-first Main/achievement fixture: stamp unlocked while ordinary absent, displayed copy truthfully permits either/first card.

## 2. Controller confirmed CI-blocking Linux diagnostic assumption

game/tests/test_tutorial_seen_progress.gd hardcodes `File not found` for obstructed-parent FileAccess error. Pinned Linux suite now fails only `child captures exactly tutorial and attempt unwritable-profile diagnostics`; new Main and postcards pass with zero ERROR. Parent directly ran existing child with new absolute private Linux profile: child exit0/PASS, exactly TWO `Cannot write progress temporary file '<that exact isolated path>.tmp': Can't open file` diagnostics. Windows report measured `File not found`. Raw evidence controller-linux-tutorial-seen-task3.log and controller-linux-tutorial-child-diagnostic.log.

Make the exact diagnostic contract account for these measured supported platform results; keep exactly two complete path-specific expected lines, identical intended failures and zero other ERROR/SCRIPT ERROR lines. No catchall allowlist, warning suppression, weakened child assertions or timeout increases. Keep tutorial failure playable fallback/attempt rollback and exact result marker. Use native error mapping/strict known-platform strings or bounded exact alternatives justified by actual two-engine evidence, not broad text matching.

## Covering checks and report

Owned fix scope: achievement_stamp_book.gd, existing new Main/achievement fixture for regression, test_tutorial_seen_progress.gd (child only if concretely required). Run focused red→green for stamp case and Windows tutorial-seen contract, plus affected UI collection/stamp/layout test if changed copy impacts layout. Parent will repeat only amended Linux tutorial suite after commit; do not duplicate all20 passed suites or Main GPU matrix for literal/fixture-only changes.

Append fix commands/log/results/commit to task-3-report.md; keep scratch ignored, commit only exact owned code/tests with both user emails. Return concise status/commit/tests/concerns for single scoped rereview of both findings.
