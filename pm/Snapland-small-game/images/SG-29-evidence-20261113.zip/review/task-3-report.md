# SG-29 Task 3 implementation report

Date: 2026-11-13. Worktree: C:/Users/stanl/Github/Snapland/.review/photo-retake-worktree. Branch: codex/free-photo-retake-20261113. Task base: d4eeec595acde6f4cfffbd638091fd81f8fc67cf. Implementation commit is recorded below after committing. Private evidence and this report remain ignored; no report/scratch force-add.

## Final behavior and scope

Main connects selected ordinary/devil signals from the existing five-argument regional album and provides matching buttons in the kiosk rules' existing objective heading. Missing game cards identify region, fixed named kiosk, canonical card ID and practice-first/free-retake action; exploration/story/time cards retain their routes. Collected game cards retain the original viewer and show gameplay/retake provenance, with devil technique state distinct from card collection. Detail height responds to its actual wrapped text. First-card/complete-collection achievements use collection language.

Main canonicalizes accepted launch aliases before Session start, attempt persistence and audio context. Invitations, rules and tutorials do not record attempts. It validates delivered IDs and six-card harbor access, including legitimate saved-current-harbor recovery. Only a fully initialized actual Session is marked attempted. The selected kind survives first practice plus immediate HUD cancellation, or natural practice result/back. New retake practice shortcut failure disposes its Session, restores the park and gives a retry notice; it never opens retake without the saved attempt.

Controller compatibility correction superseded the initial universal-abort interpretation: a pre-existing ordinary/generic practice launch remains fully playable when attempt history cannot save, including when tutorial-seen persistence also fails. Its unsaved attempt is rolled back, no retake eligibility is claimed, and the next launch can retry. Session.show_launch_notice(message) displays a six-second notice using existing shared feedback styling even for a delivered driver, which normally suppresses shared feedback. It resets on start, does not rewrite gameplay prompt/score or emit gameplay feedback, and does not introduce another panel/router. Legacy and driver tests, plus native captures, verify actual visibility after 0.5 seconds.

Main owns the immutable canonical target/kind, panel instance and generation. Panel setup is called once before add_child. Capture receives the actual Image and accepts only 1280x720; owner mismatch, generation mismatch, close, queued deletion and shutdown refuse stale capture. Main creates cryptographically unique selected-card paths, derives the existing 320x180 thumbnail and bounded original, then calls the shared Progress.complete_retake transaction. Only persisted success receives collection-success acknowledgement; retry removes only this capture's generated unreferenced files. Another card's metadata and PNG bytes remain unchanged. Retake never fabricates Session.finished, success, score, technique, story results or duplicate 40 coins.

The unchanged _save_bounded_photo_image(image,path) signature now validates dimensions/4-Mpixel bounds, encodes to a bounded PNG buffer, writes/flushed-checks a same-directory temporary PNG, validates its stored size and renames over the destination. Failure never deletes the existing destination. Gameplay thumbnail/original callers use the same writer. Time postcard capture uses a unique new namespace before its existing stale/save-failure cleanup, so cleanup also cannot remove an old same-name image. This protects individual file replacement; it is not a cross-file power-loss transaction.

Approved scope expansions were exact affected fixtures (two album FakeProgress implementations; tutorial-seen failure child/parent; one tutorial copy expectation in test_minigames), Session's bounded launch notice and qualification/score-summary copy, MinigameHUD ended collection copy, and string literals only in HatRescueModel/RibbonRhythmModel/MelodyMemoryModel public qualification/score-rule helpers. Actual counters, goals, conditions, technique constants, scoring, GameCatalog/game data objectives and validators are unchanged. No Core or RetakePanel implementation change.

## APIs/callers reviewed

- CollectionBookPanel: retake_requested(game_id:String,devil:bool), practice_requested(game_id:String,devil:bool); setup's five positional arguments unchanged. Required Progress.has_attempted_game is implemented by the two concrete FakeProgress fixtures, with no production compatibility branch for stubs.
- Main private flow: _practice_for_retake, _request_retake, _retake_capture; _cancel_game's default preserves existing no-argument signal callers, with false used only for result/save-failure teardown. Practice result Back and the explicit return action both retain the selected kind.
- Reviewed every _launch_game/_cancel_game and shared writer call in Main and repository tests, including alias launches, tutorial paths, story completion, replay photographs, time postcards, region travel, quit and delayed shutter lifetime.
- Session.show_launch_notice(message) is the one narrow new caller API. Existing Session/Progress result and attachment APIs remain compatible. Model copy edits contain string literals only; collection policy is no longer mislabeled as a gameplay success threshold.

## Baseline, red and corrected failures

Every direct engine launch used pinned C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe (4.7.2.stable.official.ed1daf0bf) and an absolute unique SNAPLAND_SAVE_PATH. No player profile was used. Private runner run-task3.py captures combined output, enforces subprocess timeout=90 seconds, records arguments/save path and scans every ERROR/SCRIPT ERROR line. New Main fixture also has an 85-second watchdog.

Baseline seven suites (story integration, Main thumbnails, originals, time of day, harbor collection, album original viewer, tutorial panel) all exit0/zero errors; baseline.json and baseline-*.log record commands/paths. Initial new Main red exit1 identified exactly the three missing owner-flow methods; initial abrupt cleanup additionally logged resource shutdown diagnostics. The first integration diagnostic caught the test-only practice property name (practice_mode), corrected before green.

Real failures remain visible and exact. Main's isolated failure child deliberately obstructs progress.json.tmp with a directory: four exact Cannot write progress temporary file '<isolated path>.tmp': Can't open file errors are captured/asserted, covering retake shortcut abort, generic legacy practice continuation, generic driver continuation, and retake award rollback. No other error is accepted. The existing tutorial failure child obstructs the profile parent with a real file: exactly two '<blocked path>/progress.json.tmp': File not found errors are asserted, preserving exactly one playable ordinary Session. No broad allowlist or disabled diagnostic printing.

The new owner test proves canonical attempt timing, immediate cancel, natural bench practice result via normal seat keys/read-only house solver, natural no-input fountain failure ordinary-only/no success story, both selected kinds in both regions, one receipt, metadata/byte preservation, shutdown/queued-panel guards, failed attempt/award/partial-image cleanup and retry. Direct image delivery in headless owner tests is explicitly state/persistence evidence, not GPU shutter evidence. Shared writer negatives include invalid source/dimensions, a real >16-MiB encoded random PNG, real held valid Windows destination (replacement failure preserving prior bytes), directory replacement failure, and a file blocking the staging parent. No staged leftovers remain.

Intermediate regressions found overly long tutorial copy at800x450; shortened the policy text instead of changing layout. The added standalone kiosk button row clipped the footer; using the existing objective heading passed the actual fixed-footer suite. The old tutorial failure expectation was restored to playable generic behavior per controller compatibility ruling. Exact old tutorial objective assertion in test_minigames now checks natural-end/free-retake copy while preserving six-seat input and exact-minimum devil checks. Transient audio shutdown resource errors in the new fixture were addressed by the existing house 0.15-second shutdown drain, not ignored. All diagnostic/failing logs remain private for audit.

## Green affected checks

Common command: pinned engine --headless --audio-driver Dummy --path <worktree> [--script for .gd] res://game/tests/<entry>. Every row's full command, unique absolute save path and raw output are in the named JSON/log group below. Successful rows have exit0 and zero ERROR/SCRIPT ERROR lines. Unchanged Task1/Task2 broad suites were not repeated.

| Entry | Evidence group | Result |
|---|---|---|
| test_region_travel.tscn | affected-final | exit0; errors0 |
| test_rowing_main.tscn | affected-final | exit0; errors0 |
| test_story_integration.tscn | affected-final | exit0; errors0 |
| test_pixel_ui_shell.tscn | final-checks | exit0; errors0 |
| test_pixel_ui_collections.tscn | final-checks | exit0; errors0 |
| test_tutorial_paged_viewport.gd | final-checks | exit0; errors0 |
| test_tutorial_panel.gd | final-checks | exit0; errors0 |
| test_main_photo_thumbnails.tscn | final-checks | exit0; errors0 |
| test_photo_originals.tscn | final-checks | exit0; errors0 |
| test_album_photo_viewer.tscn | final-checks | exit0; errors0 |
| test_harbor_collection.gd | final-checks | exit0; errors0 |
| test_time_of_day.gd | final-checks | exit0; errors0 |
| test_fountain.gd | final-compatibility | exit0; errors0 |
| test_hat_rescue_model.gd | final-compatibility | exit0; errors0 |
| test_ribbon_rhythm_model.gd | final-compatibility | exit0; errors0 |
| test_melody_memory_model.gd | final-compatibility | exit0; errors0 |
| test_pixel_ui_minigames.tscn | final-compatibility | exit0; errors0 |
| test_minigames.gd | completion-green | exit0; errors0 |
| test_tutorial_seen_progress.tscn | completion-green | exit0; errors0 |
| test_photo_retake_main.tscn | final-main | exit0; errors0 |

Full arguments and fresh save paths are consolidated in task3-evidence/final-verification.json. Raw group-entry.log files retain PASS markers and all warnings. The existing park OcclusionController unsupported-material warnings also appear in baseline; they were not treated as missing resources or hidden by a filter.

## Native evidence and exact diagnostics

Private helper: task3-native.gd + task3-native.tscn adjacent to this report. It uses normal UI buttons/navigation/choices/shutter and actual Session HUD Leave/Confirm; kiosk/map entry helper calls are explicitly programmatic. No attempted/card target flags, finished result, score or retake-panel step are forged. Only six old welcome prerequisites for the harbor gate are synthetic and labelled. The helper does not manufacture qualification from invitations.

Pinned native arguments:

```
--path C:/Users/stanl/Github/Snapland/.review/photo-retake-worktree --resolution 800x450 res://.superpowers/sdd/2026-11-13-free-photo-retake/task3-native.tscn
--path C:/Users/stanl/Github/Snapland/.review/photo-retake-worktree --resolution 1280x720 res://.superpowers/sdd/2026-11-13-free-photo-retake/task3-native.tscn
```

Each launch: Start-Process -WindowStyle Hidden -PassThru with separate native.log/native.err, returned process WaitForExit(90000), timeout stops only that PID. Internal85s watchdog. RETAKE_SIZE=800/1280; RETAKE_CAPTURE_DIR is the corresponding absolute directory below; SNAPLAND_SAVE_PATH=<that directory>/progress.json. No real profile. Vulkan Forward+ on Radeon RX9070XT.

Final evidence directories:

- task3-evidence/native800-finalcopy-1e083e28-d94a-4078-bbcb-c7164a822338: actual800x450, text scale1.25 and reduced motion.
- task3-evidence/native1280-finalcopy-a4c2f640-554e-48aa-a0f0-fed52e7108f3: actual1280x720, text scale1.0 and reduced motion.

Both exit0/PASS. Each native.err contains exactly three deliberate errors at that directory's progress.json.tmp: one retake award save failure and two generic legacy/driver attempt-save failures, all exactly "Cannot write progress temporary file '<absolute path>.tmp': Can't open file". Per-directory diagnostics.json records exact asserted error lines; there are no script/parse errors, resource-leak errors or broad allowed error patterns.

Each directory has14 screenshots: kiosk-rules, kiosk-devil-observe, save-error, saved-devil, album-provenance, album-missing, welcome-ordinary, driver-unsaved-practice, harbor-devil, harbor-kiosk, harbor-ordinary, harbor-provenance, time-postcard, generic-unsaved-practice (with resolution suffix). These prove actual four selected-region/kind shutters, safe failed save then retry, both warning paths visible after0.5s while controls remain available, original postcard capture still producing decoded thumbnail/original, free return from harbor, and provenance without false technique. Native previews and saved photos remain labelled themed retake sets and demonstration backgrounds, not earned gameplay results.

Personally inspected final800 kiosk rules/footer, album missing/provenance, save-error and both unsaved launch warnings; inspected final1280 harbor provenance, save-error and generic warning. Controller additionally inspected800 warning paths/kiosk/footer and regional provenance800/1280, with no requested visual change. Existing responsive/paged suites remain green.

Each directory's attempt-only.json is an unedited copy immediately after real game-001 practice start and immediate normal HUD cancellation, before the first shutter/award. A separate assertion verified attempted_games=[game-001], photos={}, wardrobe_rewarded_games=[]; no target eligibility/card flag was edited. Parent can reuse this exact saved snapshot for packaged/standalone UI verification.

## Self-review, exclusions and remaining ownership

Reviewed callbacks and signal binding, selected target through cancel/result return, canonical aliases, actual launch timing/half-start cleanup, region gates/recovery, close/queued-node/quit lifetime, retry and ownership of every generated path, existing ordinary/devil metadata/bytes, success/story distinction and single global receipt. Checked every touched public copy helper caller and old photo/time/original caller. git diff --check passed for every owned path; only explicit owned source/data/tests are staged. Unrelated import metadata, parent plan/docs, and private scratch/evidence are preserved and unstaged. No push, branch switch, subagent, new dependency, generic framework or forced report commit.

Not rerun: unchanged Task1/Task2 broad suites, full CI/Linux, exports/standalone matrix and real human play/audio/hardware evaluation. Parent owns registration, Linux check, full CI and packaged native matrix. Retake is the approved static themed set, not13 physical game simulators. Single-file PNG replacement is safe on the pinned Windows rename behavior and previously proven pinned Linux rename probe; no cross-file crash-atomic promise. Generic launch warning intentionally expires after six seconds; an unsaved attempt remains ineligible until a later successful attempt save.

## Commit

b3e598167137a8f9686fb014523d0ec67142b578 — feat: connect free photo retakes to album and kiosks. Author and committer: Stanley Li <stanley890314@gmail.com>. Exactly16 approved source/data/test paths; no assistant/coauthor text. Owned working copies match HEAD. No push. Final committed source is the source validated by final-main/completion-green and the scoped green evidence above; the last owner-only queued-deletion guard was verified by final-main.


## Fix round 1 — devil-first stamps and measured native diagnostics

FIX_BASE: b3e598167137a8f9686fb014523d0ec67142b578. Read task-3-fix-1.md and reviewer finding. Exact owned fix paths: game/ui/achievement_stamp_book.gd, game/tests/test_photo_retake_main.gd, game/tests/test_tutorial_seen_progress.gd. No Core/gameplay/award changes and no tutorial failure-child change.

The actual achievement already unlocks for the first selected devil card while ordinary is absent. Corrected per-game condition to first-photo collection, compact explanation to first-photo collection, wide heading to 初次收藏, and wide summary/tooltip explicitly permit 普通或小惡魔. The welcome ordinary-set milestone remains ordinary-only. Extended the real Main devil-first award fixture to assert saved ACH_GAME_001 + devil card + absent ordinary, then inspect the displayed condition, wide heading/either-kind explanation and compact first-card explanation at1280 and800 widths. It does not seed the achievement or grant ordinary to satisfy the display.

The tutorial fixture now maps only the two measured supported native results through Godot error_string: Windows ERR_FILE_NOT_FOUND (File not found); Linux ERR_FILE_CANT_OPEN (Can't open file). Controller evidence is the retained controller-linux-tutorial-child-diagnostic.log from pinned Linux: child exit0/PASS and exactly two complete same-path Can't open file errors. Unknown platforms return no expected diagnostic. Native assertion remains strict equality to exactly two identical complete path-specific lines; every other ERROR/SCRIPT ERROR fails, and the child success marker, playable ordinary fallback, visible notice and seen/attempt rollback checks remain unchanged. Deterministic mapping assertions exercise Windows, Linux and refusal of an unmeasured platform on the Windows test host. No catchall matching, suppression or timeout increase.

Pinned engine and isolated profile/timeout rules are unchanged. Exact red command:

```
python .superpowers/sdd/2026-11-13-free-photo-retake/run-task3.py fix1-red test_photo_retake_main.tscn test_tutorial_seen_progress.tscn
```

fix1-red.json/logs: Main exit1 with exactly three intended display assertion failures; actual devil-only achievement/ordinary-absent assertion already passes. Tutorial exit1 with exactly the intended measured-Linux-mapping assertion failure; existing Windows native child contract passes. No unrelated errors.

Exact focused green command:

```
python .superpowers/sdd/2026-11-13-free-photo-retake/run-task3.py fix1-green test_photo_retake_main.tscn test_tutorial_seen_progress.tscn test_pixel_ui_collections.tscn
```

All three exit0/zero ERROR or SCRIPT ERROR lines. Raw logs and full arguments/profile paths: task3-evidence/fix1-green.json and fix1-green-<entry>.log.

- test_photo_retake_main.tscn — SNAPLAND_SAVE_PATH=C:\Users\stanl\AppData\Local\Temp\snapland-task3-fix1-green-46qd1nsq\progress.json
- test_tutorial_seen_progress.tscn — SNAPLAND_SAVE_PATH=C:\Users\stanl\AppData\Local\Temp\snapland-task3-fix1-green-w960pig8\progress.json
- test_pixel_ui_collections.tscn — SNAPLAND_SAVE_PATH=C:\Users\stanl\AppData\Local\Temp\snapland-task3-fix1-green-mrtx2v1r\progress.json

Self-review confirms six stamp-copy literal replacements only, no ordinary-set milestone change, real devil-only regression, and strict exactly-two path-specific native diagnostic equality. git diff --check passes for the three owned paths. Report/evidence stay ignored. Skipped unchanged20-suite/GPU matrix and full CI; controller owns the amended Linux tutorial repeat. Only pinned Windows/Linux diagnostic mappings are measured; an unmeasured platform deliberately fails this fixture contract.

Fix commit: 567c21f430271a84cf1bddfdc705527e6231f0e1 (fix: describe first-card stamps and native save diagnostics). Exactly3 owned paths; author and committer Stanley Li <stanley890314@gmail.com>. Owned working copies match HEAD, index empty, no push.


## Post-final full-CI compatibility fix — Task3 fix round 2

FIX_BASE: dc693bf4c201201ebf21bd2aafc155a8379b3fed. Read exact post-ci-fix.md. Full CI43317813870, shard3job131532730391 reported one stale formal HUD result literal; production qualification wording is correct and remains unchanged. Ownership is ONLY game/tests/test_minigame_hud.gd, exactly the two existing formal/practice result-copy assertions. No production source, conditions, lifecycle, geometry, input, exports, skip, error filter, timeout or test-count changes.

The formal assertion now checks the approved full 普通與小惡魔拍貼資格已達成 wording and an exact trailing actual score816 (ends_with ideographic-space+816). Practice still positively checks 練習結果・不會收藏拍貼, now also checks the exact816 score tail and rejects any 拍貼資格已達成 claim. Both existing checks remain in place; all71 hierarchy/theme/contrast/geometry/input/lifecycle assertions execute, retaining the exact standard completion marker.

Measured RED before editing on both pinned Windows and pinned Linux: exit1 with exactly ERROR: FAIL: formal result shows earned outcome and actual total; no other ERROR/SCRIPT ERROR or PASS marker. Measured GREEN after the two-assertion edit on both: exit0, zero ERROR/SCRIPT ERROR, exact PASS: minigame HUD hierarchy checks (71 checks).

Evidence lives only in post-ci-evidence/{windows-red,linux-red,windows-green,linux-green}.{log,json}. JSON records every exact argument, native absolute private SNAPLAND_SAVE_PATH, mkdir prerequisite (Linux), process exit, all error lines and completion marker. Helper scripts are private/ignored. Both raw engine logs identify4.7.2.stable.official.ed1daf0bf. No player profile, import prerequisite, repeated broad suite or native/EXE/export run.

Exact execution forms:

```
C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --audio-driver Dummy --path C:/Users/stanl/Github/Snapland/.review/photo-retake-worktree --script res://game/tests/test_minigame_hud.gd
wsl.exe -d Ubuntu -u stanley -- mkdir -p <unique native directory>
wsl.exe -d Ubuntu -u stanley -- timeout 90s env SNAPLAND_SAVE_PATH=<unique native directory>/profile.json /home/stanley/.cache/snapland-boat-debug/Godot_v4.7.2-stable_linux.x86_64 --headless --path /mnt/c/Users/stanl/Github/Snapland/.review/photo-retake-worktree --script res://game/tests/test_minigame_hud.gd --audio-driver Dummy
```

Windows subprocess timeout90seconds; Linux engine uses timeout90s and outer orchestration95seconds. These preserve the existing suite timeout. Fresh profiles by run:

- windows-red: C:\Users\stanl\AppData\Local\Temp\snapland-postci-windows-red-dpww4xe2\profile.json
- linux-red: /home/stanley/.cache/snapland-postci-hud-linux-red-688f3fd1811949f0a2042095ddfbbe8f/profile.json
- windows-green: C:\Users\stanl\AppData\Local\Temp\snapland-postci-windows-green-t92ojsej\profile.json
- linux-green: /home/stanley/.cache/snapland-postci-hud-linux-green-8f8bb30a44bc43e38471e93b85eeef6e/profile.json

Before committing, internally checked with controller for additional initial CI findings. Controller confirmed initial CI complete:199Python testsPASS, runtime-sourcePASS, runtime0/1/2SUCCESS; only shard3 stale-HUD literal failed. No additional finding. Controller authorized the scoped one-file commit and owns immutable rereview, exact amended-HEAD full CI, export equivalence, publication/main and cleanup. git diff --check passed; unrelated parent docs/import metadata/evidence preserved. No subagent, push, branch switch or forced ignored report commit.

Fix round2 commit: 2b9eaf2e89981dbdbbd8e1f86b34c97f204ea42c (test: align HUD result assertions with collection qualification). Exactly one owned test file, two assertions replaced; author and committer Stanley Li <stanley890314@gmail.com>. Owned working copy matches HEAD; index empty. No production/export edits or push.
