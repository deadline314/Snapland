# SG-29 Task 3 fix round 1 re-review

Date: 2026-11-13. Scoped review of FIX_BASE `b3e598167137a8f9686fb014523d0ec67142b578` through HEAD `567c21f430271a84cf1bddfdc705527e6231f0e1`, using immutable `review-b3e5981..567c21f.diff`. This closes the two findings in `task-3-fix-1.md`; it is not a fresh broad Task 3 review.

## Verdicts

### 1. P2 devil-first stamp explanation — ADDRESSED

`game/ui/achievement_stamp_book.gd:146` now describes collecting this game's first photo. Initial wide summary and heading use first collection and explicitly permit ordinary or devil (`:107`, `:108`). Responsive wide/compact copy and tooltip remain consistent (`:241`, `:242`, `:243`). No displayed condition requires an ordinary card for the per-game stamp.

The added check runs after the existing real selected-devil retake, before the loop collects ordinary (`game/tests/test_photo_retake_main.gd:77`, `:90`, `:107`). It asserts the actual achievement and devil card exist while ordinary remains absent (`:133`), then inspects the displayed tile condition, wide first/either-card explanation and compact first-card explanation (`:138`, `:142`, `:145`). It neither seeds the achievement nor grants ordinary to satisfy the assertion. The welcome ordinary-set milestone still counts ordinary photo IDs and explicitly requires 12 ordinary photos (`game/ui/achievement_stamp_book.gd:165`, `:175`). Core award code is outside this three-file diff and unchanged.

### 2. Controller Linux exact-diagnostic fixture failure — ADDRESSED

`game/tests/test_tutorial_seen_progress.gd:68` maps only the two measured platforms: Windows `ERR_FILE_NOT_FOUND`, Linux `ERR_FILE_CANT_OPEN`, rendered with native `error_string` (`:69`, `:71`). The full expected line includes the exact inherited isolated blocked profile path (`:63`, `:64`). Equality still requires exactly two identical expected lines and rejects all additional ERROR/SCRIPT ERROR lines (`:58` through `:66`); child exit and the exact existing success marker are retained (`:61`, `:62`). Unknown platforms return an empty expectation (`:70`), which cannot equal the two captured ERROR-prefixed lines and therefore fails rather than silently passing. Windows/Linux/unknown mappings also have focused assertions (`:43` through `:45`).

The unchanged failure child still checks one initialized playable ordinary Session, the visible unsaved notice, tutorial/attempt rollback and reload absence (`game/tests/test_tutorial_seen_failure_child.gd:42` through `:58`), and retains `PASS: tutorial and attempt failed-save cleanup` (`:75`). No catchall, timeout increase, error suppression or fallback change was introduced.

## New breakage

**None found in the fix diff.** The production change is six stamp-copy literal replacements; the other changes add the focused Main assertion and strict measured-platform diagnostic mapping. No award/scoring rule, persistence implementation, public interface, dependency or additional configuration changed.

## Checks and evidence

- Read the current Task 3 brief/binding runtime spec, original review, complete fix request, appended fix report and immutable fix diff. HEAD matches the requested commit. The three reviewed working files match HEAD; index is empty. `git diff --check b3e5981 567c21f` passes. Commit author/committer are Stanley Li with the required user email.
- Audited `task3-evidence/fix1-red.json` against both raw logs: Main has exactly the three intended copy failures, tutorial has exactly the Linux-mapping assertion failure. The real devil-only achievement assertion was already passing.
- Audited `task3-evidence/fix1-green.json` and all three raw green logs: Main, tutorial progress and collection/layout each report exit 0, the expected PASS summary and zero ERROR/SCRIPT ERROR lines. The retained runner uses unique absolute private profiles, the pinned Windows engine and 90-second subprocess limits. Collection evidence includes the unchanged achievement pagination/capacity checks.
- The pre-fix controller Linux parent log fails only the exact-diagnostic assertion. `controller-linux-tutorial-child-diagnostic.log:180` and `:187` contain exactly two identical full-path `Can't open file` errors, and `:195` has the child PASS marker. The now-present amended `controller-linux-tutorial-seen-fix1.log:19` has the parent PASS marker and zero ERROR/SCRIPT ERROR lines. This is retained controller evidence, not a reviewer engine rerun; process-exit verification remains the controller's record.

## Limits

No engine suite or GPU matrix was repeated: the focused retained evidence and source inspection leave no concrete unanswered fix-scope doubt. This review does not expand to full CI, standalone/export/PCK, new-suite registration, human play/input/audio acceptance, or a new visual inspection. Only pinned Windows/Linux obstructed-parent diagnostics are measured; another platform intentionally fails this fixture until its exact diagnostic is established.

Only this private review report was written. No source/test, existing evidence, player profile, index, HEAD or branch was modified; no subagents were spawned.
