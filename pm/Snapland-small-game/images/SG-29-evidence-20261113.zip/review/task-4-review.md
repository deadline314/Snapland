# Task 4 review — 6404ce5..90ee94c

## Spec Compliance

- ✅ Spec compliant within Task 4's owned scope. All nine authorized paths have corresponding hunks; no unrelated production feature was added. `tools/run_game_tests.py:25,187` registers the five suites in the existing catalog, and `tools/run_game_tests.py:174` requires their complete exact-line markers without changing existing timeout/error/profile/shard infrastructure. `tests/test_runtime_result_contract.py:209,219` covers registration, exact completions, missing/suffixed/quoted output, and engine/script errors.
- ✅ `game/tests/native_photo_retake.gd:14,23` resolves only the adjacent helper and requires absolute save/capture paths, a supported mode, and a graphical renderer. `game/tests/native_photo_retake.tscn:3` supplies the source entry; `game/tests/retake_native_route.gd:4` sends real viewport key events. `game/tests/test_retake_native_fixture.gd:18` checks the absent external helper before copying the adjacent helper and loading actual production/tutorial/prop resources.
- ✅ `game/tests/native_photo_retake.gd:74` launches real Main practice, cancels through real HUD controls, and copies the actual attempt-only save before either target award (`:90`). Only missing old welcome prerequisites are synthetic (`:57`); neither harbor target nor attempts are manufactured. `:94,103,131,149` checks rollback/retry, devil-first ordinary independence, repeat no payout, one receipt, and preservation of the existing other card's metadata and PNG bytes.
- ✅ `game/tests/native_photo_retake.gd:158,184,198` exercises demonstration → adjustable set → shutter, reversible Back/Next, normal Tab/Enter delivery, changed actual set pixels, exact captured-original pixels, dimensions, and truthful retake provenance. `:207` advances the ordinary Session processing path without assigning result/score/timer/model/finish state; retained actual welcome results are success=false, devil=false, ordinary_eligible=true, score=0, mistakes=3. `:54,228` checks restart decoding/provenance and unchanged reader JSON.
- ✅ The authorized tooltip correction is confined to game-card next actions (`game/ui/collection_book_panel.gd:439`), with existing harbor assertions updated (`game/tests/test_harbor_collection.gd:56,73`). The responsive correction measures natural current-category content against the fixed pager (`game/ui/collection_book_panel.gd:357`), remaps the focused tile's page (`:294`), and restores its stable-name focus/details after rebuild (`:320`). Added actual800×600 geometry and genuine resized-target Enter checks are in `game/tests/test_pixel_ui_collections.gd:128,496,552`.
- ⚠️ Cannot verify from this diff: Task 1–3's complete persistence, image validation, eligibility/result behavior, delivered catalog contents, old-save/no-retroactive-money migration, genuine later devil-technique provenance, and all trust boundaries. The native checks cover selected welcome/harbor paths; whole-branch review must verify the underlying contracts rather than treating this fixture as their implementation.
- ⚠️ Cannot verify from this diff: final exact-HEAD full Python/source/four-shard CI, complete original115/exact-once execution, independent clean production PCK with tests excluded, genuine standalone Windows EXE UI/smoke, export settings/assets, public ticket/docs/archive, author/committer identity, latest-main integration, publishing, and cleanup. Those remain explicit parent gates. The retained1280/1920 writer runs precede the final album-only adjustment and must not be relabelled as final-HEAD complete runtime evidence; final800 writers/readers and final affected geometry tests do cover that adjustment.

## Strengths

- `game/tests/native_photo_retake.gd:90` preserves unedited attempt-only evidence before awards; `:94` tests an actual isolated write obstruction rather than mocking persistence success. The raw welcome snapshot has only game-001 attempted and no photos/receipts; harbor has game-013 attempted and only the six stated old welcome cards.
- `game/tests/native_photo_retake.gd:184` compares actual arranged-set pixels with the saved decoded original. This distinguishes a genuine shutter from merely showing a screenshot while granting a card.
- `game/tests/test_pixel_ui_collections.gd:552` checks the real regression consequence: the latter-half game004 remains visible/focused after four-to-two reflow, then GUI Enter launches game004 practice. Retained `task3-evidence/task4-album-focus-green-test_pixel_ui_collections.tscn.log:368,369` confirms both assertions passed.
- `game/tests/test_retake_native_fixture.gd:32` explicitly proves a missing external adjacent helper fails closed even while the repository helper exists. This is useful dependency evidence without claiming it replaces independent packed verification.

## Issues

### Critical (Must Fix)

- None found in the scoped diff.

### Important (Should Fix)

- None found in the scoped diff.

### Minor (Nice to Have)

- P3 — `task4-evidence/welcome-800x600-c61a48f545ad41408452458c1ceca1b0/stderr.log:1` (also the other welcome-containing native runs): retained successful runs contain existing OcclusionController unsupported StandardMaterial3D warnings,15 per welcome construction. This is visible diagnostic noise, not a pristine test output. It is outside this task's nine changed paths and does not invalidate the exact expected temporary-write failure or the behavior checks; parent should track the existing warning source separately and continue distinguishing it from new errors rather than suppressing all diagnostics.

## Checks and Evidence

- Read applicable repository AGENTS, exact Task 4 brief/report, reviewer instructions, and immutable review package. Initial tool output truncated the package's middle; reread that package segment, not changed-file copies. No git command, suite rerun, branch/index/code mutation, or subagent was used. This ignored report is the only written file.
- Named risk: dynamic page-capacity/focus remapping might invalidate manual paging or invoke another photo. Focused outside-diff inspection covered the cut-off album refresh/page/category/resize callers and the tile focus-details callback in `game/ui/collection_book_panel.gd:197,202,207,257,517`. Refresh rebuilds detached old tiles, and the new responsive path restores the same stable tile; retained final geometry/pagination and actual Enter results answer the named risk. No new runtime probe was necessary.
- Read `task4-evidence/focused-python.log:2`:48 tests, OK; `task4-evidence/focused-runner.log:1`: import plus all five RUN/PASS pairs with90-second limits. These are existing retained runs, not reruns or claims of full exact-HEAD CI.
- Read final affected-run manifest `task3-evidence/task4-album-focus-green.json:1` and corresponding raw logs: pixel UI, harbor collection, original viewer, and Main thumbnails all exit0 with no ERROR diagnostics. Harbor retains22 checks; viewer closes back to the selected tile without mutating progress. Negative-input thumbnail warnings remain visible.
- Read latest preflight raw output `task4-evidence/preflight-1280x720-41b7d02549ad4ce6b2e631e5fa6ed3b4/stdout.log:3`: exact preflight completion; its raw stderr has no error/warning output.
- Followed `task4-evidence/final-source-verification.json:1` to all eight stated run directories and read each actual launch manifest, native report, stdout completion and stderr diagnostics. All exit0 with empty fixture-failure arrays and exactly the stated completion. Welcome has exactly its complete isolated-path intentional write error; harbor/read have none. Launch environments use independent absolute saves; both800×600 writers set large text1/reduced motion.
- Independently recomputed SHA256 for all nine current owned files and every output listed in that audit: no mismatch. Compared completed800 welcome/harbor writer JSON bytes against the corresponding independent reader JSON bytes: both identical. This confirms retained artifact consistency; it does not prove earlier wide processes loaded the final album revision.
- Personally viewed actual final800×600 welcome/harbor `ordinary-provenance.png`, welcome `observe-devil.png`, `devil-set-after.png`, and `first-devil-only-stamp.png`. Cards/captions remain above the fixed pager; the demo is clearly labelled, set choices are visible, and the first-devil stamp does not invent ordinary ownership. Raw capture metadata records OS/render800×600 and logical1280×960, rather than800×450 letterboxing.

## Assessment

**Task quality: Approved.** The small production correction has behavior-level regression evidence, and the fixture uses actual inputs, captures, saves and truthful failed gameplay. No blocking defect was found in the immutable Task 4 package; the minor inherited diagnostic noise and parent delivery gates remain explicit.

Not rerun: existing suites, full CI, export/PCK/EXE, or exhaustive SG28 physics. Risk: this task approval is not final branch/release approval; earlier wide-native evidence predates the final album correction.
