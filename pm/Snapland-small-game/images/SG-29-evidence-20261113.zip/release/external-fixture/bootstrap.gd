extends SceneTree
func _initialize() -> void: call_deferred("_run")
func _run() -> void: root.add_child(load("C:/Users/stanl/Github/Snapland/build/Snapland-preview-20261113-retake-r2/qa/external-fixture/native_photo_retake.gd").new())
