from pathlib import Path
import subprocess,sys
r=Path.cwd()
for case in ['controls-final-v2','sources-v2','outcomes-final-v2']:
 subprocess.run([sys.executable,str(r/'work/balloon-final-20261022/run_native.py'),case],check=True)
