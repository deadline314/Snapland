from pathlib import Path
import json,re,hashlib,shutil,zipfile,subprocess
r=Path.cwd();b=r/'work/balloon-final-20261022';out=r/'pm/Snapland-small-game/images';prefix='SG-16-final-20261023-'
def copy(path,name=None):
 p=b/path;q=out/(prefix+(name or path.replace('/','-')))
 if p.suffix=='.log':q.write_text('\n'.join(x.rstrip() for x in re.sub(r'\x1b\[[0-9;]*m','',p.read_text()).splitlines()).rstrip()+'\n')
 else:shutil.copyfile(p,q)
for case in ['controls-trace','outcomes-counted','retry-v2','sources-v2','wind-probe-v2','lesson-import','lesson-final','release-smoke-final']:
 d=json.loads((b/case/'result.json').read_text());assert d['exit']==0 and d['errors']==0,(case,d)
 for name in ['result.json','result.log','source-provenance.json','video-metadata.json','natural-results.json','pixel-comparison.json']:
  if (b/case/name).exists():copy(case+'/'+name)
 for p in (b/case/'captures').glob('*.png'):copy(str(p.relative_to(b)))
 if case in ['controls-trace','outcomes-counted','retry-v2']:copy(case+'/play.mp4',case+'.mp4')
 for p in b.glob(case+'-review-*.jpg'):copy(p.name)
for name in ['before-actual-subviewport.png','after-actual-subviewport.png']:copy('wind-probe-v2/'+name)
for name in ['nintendo-official-capture.jpg','mini-metro-official-capture.jpg','reference-images.json','updated-tutorial-sources.json','attempt-history.json','ci-94-runtime.log','ci-94-full.log','ci-94-verification.json','python-tests.log','python-design-final.log','python-final.log','twelve-game-comparison-1.jpg','twelve-game-comparison-2.jpg','twelve-game-source-sha256.json']:copy(name)
checks={}
for folder in ['checks-v2','checks-wind','delivery-counted']:
 d=json.loads((b/folder/'results.json').read_text());assert all(x['exit']==0 and x['errors']==0 and x['error'] is None and x['seconds']<90 for x in d);checks[folder]=d
 for p in (b/folder).glob('*'):
  if p.is_file():copy(str(p.relative_to(b)))
assert re.search(r'Ran 143 tests', (b/'python-final.log').read_text()) and (b/'python-final.log').read_text().rstrip().endswith('OK')
for name in ['build.json','import.log','export.log']:copy('release-counted/'+name)
copy('release-smoke-final/profile/art-smoke-game-001.png','actual-release-balloon-initial.png')
refs=['game/minigames/session.gd','game/minigames/balloon_harbor_view.gd','game/data/welcome_games.json','game/data/tutorials.json','game/tests/test_balloon.gd','game/tests/test_balloon_harbor_view.gd','game/tests/test_minigames.gd','game/tests/native_balloon_controls_review.gd','game/tests/native_balloon_outcomes_review.gd','game/tests/native_balloon_outcomes_review.tscn','game/tests/native_balloon_lesson_capture_review.gd','game/tests/native_balloon_lesson_capture_review.tscn',*[f'assets/ui/tutorials/game-001-step-{i:02}.png' for i in [1,2,3]]]
runtime=refs[:4]+refs[-3:];stage=r/'work/tutorial-current-20261020/validation-project';build=json.loads((b/'release-counted/build.json').read_text())
for rel in runtime:
 assert (r/rel).read_bytes()==(stage/rel).read_bytes(),rel
 assert build['source_sha256'][rel]==hashlib.sha256((r/rel).read_bytes()).hexdigest(),rel
assert not any(x.startswith(('tools/','work/','game/tests/')) for x in build['source_sha256'])
assert len(re.findall(r'ART SMOKE DRAW: game-\d{3} renderer=',(b/'release-smoke-final/result.log').read_text()))==12
record={'starting_commit':'94de1a95373007f17cd9abf7692b795d025c9bc6','client_delivery_date':'2026-10-23 Asia/Taipei','scope':'SG16 actual game001 acceptance only. Not full ART20/21, hardware performance, human feel, hearing or Windows acceptance.','core_checks':checks,'python':'143/143 final full suite; earlier single catalog alignment failure retained, fixed both runtime and source design strings,39design tests also pass.','final_native':{case:json.loads((b/case/'result.json').read_text()) for case in ['controls-trace','outcomes-counted','retry-v2','sources-v2','lesson-final']},'wind_comparison':json.loads((b/'wind-probe-v2/pixel-comparison.json').read_text()),'source_sha256':{rel:hashlib.sha256((r/rel).read_bytes()).hexdigest() for rel in refs},'review_scope':'All listed final capture contacts and key full-size result/tutorial images viewed; final input videos fully decoded, not continuous watching. Real-clock controls/outcomes at external silent15FPS; retry and lesson retain fixed60 simulation contract. No new quarter-speed run.','source_timing':'Final lesson PNGs and clearer tutorial/catalog text changed after controls/outcome films; fresh lesson process/import validates updated lesson. Counted outcome is final per-cause-count UI; zero-mistake controls source predates adding progress_only for mistake rows, which are absent from its precise result. Runtime wind/physics/rules unchanged after final routes.','release':{'binary':build['binary'],'source_base':build['source_commit'],'provenance':'Built from current tracked working-tree runtime bytes including SG16, not a clean94de release. SHA map verified. Tests/tools/work and rejected art excluded.','steps':build['steps'],'smoke':json.loads((b/'release-smoke-final/result.json').read_text()),'scope':'Real embedded-PCK Linux executable boots its own Main and all12 initial renderers. Not packaged full balloon input or listening.'},'baseline_ci':json.loads((b/'ci-94-verification.json').read_text())}
(out/(prefix+'verification.json')).write_text(json.dumps(record,indent=2)+'\n')
with zipfile.ZipFile(out/(prefix+'sources-and-diagnostics.zip'),'w',zipfile.ZIP_DEFLATED) as z:
 for rel in refs:z.write(r/rel,'current-source/'+rel)
 for p in b.iterdir():
  if p.is_file() and p.suffix in ['.py','.gd','.txt','.json','.html']:z.write(p,'drivers/'+p.name)
 for p in b.rglob('*.log'):
  if 'release-counted/project' not in str(p) and 'release-final/project' not in str(p):z.write(p,'raw-logs/'+str(p.relative_to(b)))
 for case in ['controls-v1','controls-v2','controls-v4','controls-final','controls-final-v2','controls-trace','outcomes-v2','outcomes-final-v3','outcomes-counted','retry-v2','sources-v2','wind-probe','wind-probe-v2','lesson-final']:
  for p in (b/case).iterdir():
   if p.is_file() and p.suffix in ['.gd','.tscn','.json']:z.write(p,'cases/'+case+'/'+p.name)
 for i in [1,2,3]:z.write(b/f'previous-lesson-{i:02}.png',f'previous-lessons/step-{i:02}.png')
 for case in ['controls-v4','outcomes-final-v3']:
  for p in (b/case/'captures').glob('*.png'):z.write(p,'superseded-visuals/'+case+'/'+p.name)
files=sorted(p for p in out.glob(prefix+'*') if p.name!=prefix+'manifest.json');(out/(prefix+'manifest.json')).write_text(json.dumps({'scope':'SG16 final evidence, manifest excludes itself','files':[{'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]},indent=2)+'\n')
print('Packaged',len(files),'files',sum(p.stat().st_size for p in files),'bytes')
