import ast,re,json
from pathlib import Path
r=Path.cwd();b=r/'work/balloon-final-20261022';s=(b/'ci-94-runtime.log').read_text();full=(b/'ci-94-full.log').read_text()
tree=ast.parse((r/'tools/run_game_tests.py').read_text());n=next(n for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='checks' for t in n.targets));checks=eval(compile(ast.Expression(n.value),'<official selectors>','eval'),{'executable':'godot','common':['godot'],'ROOT':r,'str':str});expected=[name for name,_ in checks]
runs=re.findall(r'RUN: (.+?) \((\d+)/93, limit (\d+)s\)',s);passes=re.findall(r'PASS: (.+?) \(([\d.]+)s\)',s)
assert len(runs)==len(passes)==len(expected)==93
assert [x[0] for x in runs]==[x[0] for x in passes]==expected
for idx,((name,count,cap),(_,duration)) in enumerate(zip(runs,passes),1):
 assert int(count)==idx and int(cap)==(240 if name=='avatar renderer tests' else 90),(name,cap)
 assert float(duration)<int(cap)
assert 'Ran 143 tests' in full and re.search(r'Z OK\s',full) and 'PASS 5 design scope(s)' in full
v={'commit':'94de1a95373007f17cd9abf7692b795d025c9bc6','run':39742027025,'python':143,'godot_runs':93,'godot_passes':93,'design_scopes':5,'names_order_original_caps_verified':True,'scope':'Successful delivered SG17 main baseline; excludes current uncommitted SG16 changes.'};(b/'ci-94-verification.json').write_text(json.dumps(v,indent=2)+'\n');print(v)
