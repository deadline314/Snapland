from pathlib import Path
import subprocess,sys
r=Path.cwd()
for case in ['sources-v2','outcomes-final-v3']:
 subprocess.run([sys.executable,str(r/'work/balloon-final-20261022/run_native.py'),case],check=True)
