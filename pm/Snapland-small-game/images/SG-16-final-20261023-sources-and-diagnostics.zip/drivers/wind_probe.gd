extends Node

var started := Time.get_ticks_msec()
func _process(_delta: float) -> void:
	if Time.get_ticks_msec()-started > 20000:
		push_error("Wind visibility probe exceeded20-second wall guard")
		get_tree().quit(1)

func _ready() -> void:
	call_deferred("_run")

func _run() -> void:
	var folder := OS.get_environment("SNAPLAND_SAVE_PATH").get_base_dir()
	var results: Array = []
	for source in ["res://work/balloon-final-20261022/before-wind-harbor.gd", "res://game/minigames/balloon_harbor_view.gd"]:
		var view: Control = load(source).new()
		add_child(view)
		view.initialize()
		view.present(Vector2(500,330),Vector2.ZERO,Vector2(34,0),Vector2(-26,0),0,0.0,false,2.0,true,"night",0)
		for frame in 5: await get_tree().process_frame
		await RenderingServer.frame_post_draw
		var picture: Image = view.texture().get_image()
		var counts: Array = []
		for index in 2:
			var ink := Color("#62c3b0") if index == 0 else Color("#efbd71")
			var pixels := 0
			for y in range(593 + index*60,629 + index*60):
				for x in range(130,218):
					var color := picture.get_pixel(x,y)
					if absf(color.r-ink.r)+absf(color.g-ink.g)+absf(color.b-ink.b) < 0.05: pixels += 1
			counts.append(pixels)
		var label := "before" if results.is_empty() else "after"
		var path := folder.path_join(label + "-actual-subviewport.png")
		if FileAccess.file_exists(path) or picture.save_png(path) != OK:
			push_error("Cannot preserve exclusive wind evidence");get_tree().quit(1);return
		results.append({"source":source, "direction_pixels":counts, "capture":path})
		view.queue_free()
		for frame in 3: await get_tree().process_frame
	FileAccess.open(folder.path_join("pixel-comparison.json"),FileAccess.WRITE).store_string(JSON.stringify(results,"  "))
	if results[0].direction_pixels != [0,0] or results[1].direction_pixels[0] < 20 or results[1].direction_pixels[1] < 20:
		push_error("Wind visibility counterexample did not distinguish covered from visible arrows");get_tree().quit(1);return
	print("PASS: actual rendered wind direction pixels reject covered old arrows and retain both foreground directions in night/reduced-motion")
	get_tree().quit(0)
