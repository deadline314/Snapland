# SG-47 Task 2 retained 3D workbench and input

DONE. Based on Task 1 product `aad912f` and the Task 2 PNG ruling. Driver, View, their focused tests, and three byte-identical workbench PNGs are ready for the controller to freeze. The Model and public target recipe were consumed unchanged. No session, catalog, ticket, or Git mutation was made here.

## Product allowlist

| Workspace path | Bytes | SHA-256 |
|---|---:|---|
| game/minigames/cotton_wind_driver.gd | 5622 | `3c822de411bb95c8bbba402cc1eb3f87a0231c2b8f9afbb31586cec3b60914a4` |
| game/minigames/cotton_wind_view.gd | 23038 | `53032548d5e117d486af359f7def98c1e623288ea217c436ee060b0003257b38` |
| game/tests/test_cotton_wind_driver.gd | 8588 | `e6822aa3afedb32bc707621b84b2dd8b651daf91cf98840f8cd6e56107c6cc48` |
| game/tests/test_cotton_wind_view.gd | 19318 | `43f416657eb7b2dfa6ecd88058dd2146371663e69973279371c76d3f2935cf07` |
| assets/ui/tutorials/game-030-step-01.png | 36375 | `c8a5623b23ec61cc54782900623e13a6e53b61a760abe755a38fe380fb61784b` |
| assets/ui/tutorials/game-030-step-02.png | 38451 | `a1238d7906b576298ce6783678f4749873e225b75ad4eca95045402abbdc3236` |
| assets/ui/tutorials/game-030-step-03.png | 38067 | `8a8a1e293d42897b769e453cea140bbae5717e60340c27aac422ff2fb2867411` |

The frozen stage dependency hashes were `bea36ef93e1aee775ccad0c0dbab99bec014e9c1862bd5bddd7e7389a107ea54` for `cotton_wind_model.gd` and `1c005e67c5cbe040e8b88d1bed8cbeb95cbaf7a47d51674e21569082bb607027` for `cotton_wind_route.gd`. All four product scripts matched the relevant strict green manifests. The copied PNGs match the source from the strict 1280×720 run byte for byte. The reports and runner in this plan workspace are private QA artifacts.

## Reproduction and isolation

From `C:/Users/stanl/Github/Snapland` in PowerShell, use these exact commands. Run RED before adding the Driver files. Its stage intentionally includes only the RED fixture, public route, and autoload dependencies. The importer uses a private asset-only `project.godot` containing the runtime's rendering settings. It imports seven tracked pixel control SVGs and seven fonts, producing 28 files under `.godot/imported`.

```powershell
$env:PYTHONIOENCODING = 'utf-8'
$task2Runner = '.superpowers/sdd/2026-11-18-cotton-wind/task-2-run.py'
python -B $task2Runner red
python -B $task2Runner import
$task2Seed = 'D:/Snapland-QA/cotton-wind/task2/import-1280x720-0d1a4a83e16e'
python -B $task2Runner driver --seed $task2Seed
python -B $task2Runner view-headless --seed $task2Seed
python -B $task2Runner view --size 1280x720 --seed $task2Seed --capture
python -B $task2Runner view --size 1152x648 --seed $task2Seed --capture
python -B $task2Runner view --size 800x600 --seed $task2Seed --capture
```

The runtime fixtures use `--script` with the actual SceneTree test. `prepare_runtime_stage` copies tracked project/core/data, Paper/font support and the exact asset dependencies. The runner then copies the exact uncommitted fixtures and product files. It checks staged bytes against their input, then verifies the asset-only seed by engine and asset hashes before copying its 28 import files and matching metadata. Each process uses newly created absolute D: `project`, `save/progress.json`, `appdata`, `local`, `temp`, `tmp`, `captures`, and `export` paths. The four fault-child parents, all other test fixtures, repository UID caches, C: editor caches, and old packages are outside the stage. The import command uses `--editor --import --quit`. The output paths in each actual process argument and environment are in its prelaunch manifest.

Each stage's complete script/config set was checked for process APIs and reviewed through its direct preload/path references and dynamic calls before launch. The final runtime manifest carries 93 file hashes and the 18 audited source files. The fixtures read only their private capture location and the existing core guards read the private save path. No direct or indirect fixture path invoked a child process. The only external process site in the validated-launch helper is its owned timeout cleanup, and no timeout occurred. The importer staged one audited config and no GDScript. The launch used the pinned console wrapper and backing editor (both checked on every launch).

| Tool or runtime | SHA-256 |
|---|---|
| `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe` | `c8f0a6bc45a19b33541501e57f6f7cd972ab18453743266339d495cbbe846643` |
| `C:/Tools/Godot/Godot_v4.7.2-stable_win64.exe` | `ab1824f85bfd8e0e4128182c000c4003a3e042245b2967848d089b2a04b22424` |
| `tools/godot_entrypoints.py` | `7e126f059e6477b586019852967cbea6bc1049380237895427d6a9da188f3ed3` |
| `tools/build_desktop_release.py` | `ff5e8c6238b09e839013a2732820dc7d64057dd56f82e37a8094b29d612dce98` |
| `task-2-run.py` used for final Driver and Vulkan runs | `1dfa0c1ab73a0573b85548cb34a804414fc01ca2b2996f8528acdc5faa419286` |
| `task-2-run.py` with the added headless View mode | `ab3ecfa9957c2cbb5818f8b31e94ce7aa5b7984a13a36cd8a7416a5cfabe99ff` |

The engine identified itself as `v4.7.2.stable.official.ed1daf0bf`. The three graphical fixtures used Vulkan 1.4.359, Forward+, and an AMD Radeon RX 9070 XT. No export template was needed for the standalone workbench fixture.

## RED and GREEN raw receipts

Every linked receipt records actual exit, unique marker count in both unsuppressed stdio and UTF-8 engine log, clean-error/leak check, and hashes of the stored logs. Every manifest records source fingerprints, complete staged script audit results, fixture closure, engine, profiles, and actual argv. Marker counts were 1/1 in each accepted row. GREEN engine stderr was empty and both channels passed the zero-error/leak check. Output files linked in full preserve route metrics and intermediate markers.

| Command | Engine exit | Output marker | Evidence |
|---|---:|---|---|
| `red` | 1 | `FAIL: missing Cotton Wind Driver at res://game/minigames/cotton_wind_driver.gd` | [manifest](D:/Snapland-QA/cotton-wind/task2/red-1280x720-a619a0f4f88a/manifest.json) · [receipt](D:/Snapland-QA/cotton-wind/task2/red-1280x720-a619a0f4f88a/receipt.json) · [stdout](D:/Snapland-QA/cotton-wind/task2/red-1280x720-a619a0f4f88a/stdout.txt) · [stderr](D:/Snapland-QA/cotton-wind/task2/red-1280x720-a619a0f4f88a/stderr.txt) · [engine](D:/Snapland-QA/cotton-wind/task2/red-1280x720-a619a0f4f88a/engine.log) |
| `import` | 0 | `[ DONE ] loading_editor_layout` | [manifest](D:/Snapland-QA/cotton-wind/task2/import-1280x720-0d1a4a83e16e/manifest.json) · [receipt](D:/Snapland-QA/cotton-wind/task2/import-1280x720-0d1a4a83e16e/receipt.json) · [stdout](D:/Snapland-QA/cotton-wind/task2/import-1280x720-0d1a4a83e16e/stdout.txt) · [stderr](D:/Snapland-QA/cotton-wind/task2/import-1280x720-0d1a4a83e16e/stderr.txt) · [engine](D:/Snapland-QA/cotton-wind/task2/import-1280x720-0d1a4a83e16e/engine.log) |
| `driver` | 0 | `Cotton wind driver: 62 checks, 0 failures` | [manifest](D:/Snapland-QA/cotton-wind/task2/driver-1280x720-815202a99b57/manifest.json) · [receipt](D:/Snapland-QA/cotton-wind/task2/driver-1280x720-815202a99b57/receipt.json) · [stdout](D:/Snapland-QA/cotton-wind/task2/driver-1280x720-815202a99b57/stdout.txt) · [stderr](D:/Snapland-QA/cotton-wind/task2/driver-1280x720-815202a99b57/stderr.txt) · [engine](D:/Snapland-QA/cotton-wind/task2/driver-1280x720-815202a99b57/engine.log) |
| `view-headless` | 0 | `Cotton wind view: 7 checks, 0 failures` | [manifest](D:/Snapland-QA/cotton-wind/task2/view-headless-1280x720-4cd2aea4f31f/manifest.json) · [receipt](D:/Snapland-QA/cotton-wind/task2/view-headless-1280x720-4cd2aea4f31f/receipt.json) · [stdout](D:/Snapland-QA/cotton-wind/task2/view-headless-1280x720-4cd2aea4f31f/stdout.txt) · [stderr](D:/Snapland-QA/cotton-wind/task2/view-headless-1280x720-4cd2aea4f31f/stderr.txt) · [engine](D:/Snapland-QA/cotton-wind/task2/view-headless-1280x720-4cd2aea4f31f/engine.log) |
| `view --size 1280x720 --capture` | 0 | `Cotton wind view: 69 checks, 0 failures` | [manifest](D:/Snapland-QA/cotton-wind/task2/view-1280x720-68ce39cd9fa7/manifest.json) · [receipt](D:/Snapland-QA/cotton-wind/task2/view-1280x720-68ce39cd9fa7/receipt.json) · [stdout](D:/Snapland-QA/cotton-wind/task2/view-1280x720-68ce39cd9fa7/stdout.txt) · [stderr](D:/Snapland-QA/cotton-wind/task2/view-1280x720-68ce39cd9fa7/stderr.txt) · [engine](D:/Snapland-QA/cotton-wind/task2/view-1280x720-68ce39cd9fa7/engine.log) |
| `view --size 1152x648 --capture` | 0 | `Cotton wind view: 69 checks, 0 failures` | [manifest](D:/Snapland-QA/cotton-wind/task2/view-1152x648-616db65dd252/manifest.json) · [receipt](D:/Snapland-QA/cotton-wind/task2/view-1152x648-616db65dd252/receipt.json) · [stdout](D:/Snapland-QA/cotton-wind/task2/view-1152x648-616db65dd252/stdout.txt) · [stderr](D:/Snapland-QA/cotton-wind/task2/view-1152x648-616db65dd252/stderr.txt) · [engine](D:/Snapland-QA/cotton-wind/task2/view-1152x648-616db65dd252/engine.log) |
| `view --size 800x600 --capture` | 0 | `Cotton wind view: 69 checks, 0 failures` | [manifest](D:/Snapland-QA/cotton-wind/task2/view-800x600-87e9af93dc18/manifest.json) · [receipt](D:/Snapland-QA/cotton-wind/task2/view-800x600-87e9af93dc18/receipt.json) · [stdout](D:/Snapland-QA/cotton-wind/task2/view-800x600-87e9af93dc18/stdout.txt) · [stderr](D:/Snapland-QA/cotton-wind/task2/view-800x600-87e9af93dc18/stderr.txt) · [engine](D:/Snapland-QA/cotton-wind/task2/view-800x600-87e9af93dc18/engine.log) |

Other attempts are preserved in the same D: QA directory. The first RED `red-1280x720-9c798572a70d` exited 1 with identical RED stdout and engine bytes before raw-log hashes were added to the runner. Its stdout, stderr, and engine SHA-256 are `1d4d398634dadf07a2e6f755e55ba45f5d6aeb7a0526e26c58e38eb4d18ccc45`, `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`, and `127691e4f95f06ef4b1b18a0d0d7337832dc82adadcaa8522113d9e7cfe2a37f`. The first import `import-1280x720-ada69054e6bf` exited 0 with a missing Main scene editor error and was rejected. `driver-1280x720-5e2312b44b68` exited 0 with a missing Paper preload and was rejected before the full Paper script closure was staged. `view-1280x720-544dbc72d037` exited 1 for two fixture WeakRef annotations. `driver-1280x720-4b91df67e0dc` was intermediate GREEN. Both `view-1280x720-28df0394f151` and `view-1280x720-974305ae8634` exited 1 on actual label/control bounds and are preserved as unpromoted raw candidates. These candidate failures led to two-line measured quality columns, an in-bounds footer and matching 90 px control boxes.

## All 24 Driver routes

Each route resets the game through the Driver and sends real Godot event objects through its public input boundary. Each retains the frozen `Route.target` and uses observed Model state. Keyboard holds native E plus bounded cardinal/diagonal inputs at 120 Hz, steering toward each target with a half-unit dead zone. Mouse and single-finger routes latch spin, hold the workbench, and pursue each projected target through matched drag events at 30 Hz. All routes press F or the finish control only after physical uniformity and the requested real catch. All 24 reached ordinary eligibility, ended successfully, and cleared held commands. Every final band had 12/12 covered cells. There were 12 scores of 400 and 12 of 500.

| Source | Variant | Assisted | Catch | Seconds | Score | Rejoins | Final masses left / center / right |
|---|---|---|---|---:|---:|---:|---|
| Keyboard | A | off | no | 17.150000 | 400 | 0 | 19.5255 / 25.7836 / 20.4858 |
| Keyboard | A | off | yes | 30.091667 | 500 | 1 | 36.0463 / 40.8121 / 30.4322 |
| Keyboard | A | on | no | 9.791667 | 400 | 0 | 12.0675 / 13.0397 / 12.0692 |
| Keyboard | A | on | yes | 11.358333 | 500 | 1 | 12.7544 / 14.1579 / 12.2504 |
| Keyboard | B | off | no | 19.041667 | 400 | 0 | 18.5652 / 22.9010 / 17.1205 |
| Keyboard | B | off | yes | 46.766667 | 500 | 1 | 43.2844 / 46.9685 / 35.1490 |
| Keyboard | B | on | no | 16.600000 | 400 | 0 | 14.4963 / 21.3459 / 15.9648 |
| Keyboard | B | on | yes | 20.658333 | 500 | 1 | 19.4970 / 24.5299 / 16.6026 |
| Mouse | A | off | no | 17.033333 | 400 | 0 | 19.0292 / 25.2771 / 20.9498 |
| Mouse | A | off | yes | 30.366667 | 500 | 1 | 35.3257 / 41.2931 / 30.6563 |
| Mouse | A | on | no | 9.800000 | 400 | 0 | 12.0607 / 13.0312 / 12.0641 |
| Mouse | A | on | yes | 11.866667 | 500 | 1 | 12.7340 / 15.0468 / 13.9969 |
| Mouse | B | off | no | 19.033333 | 400 | 0 | 18.5499 / 22.8806 / 17.1103 |
| Mouse | B | off | yes | 46.933333 | 500 | 1 | 43.3150 / 46.8402 / 34.8710 |
| Mouse | B | on | no | 16.933333 | 400 | 0 | 14.9773 / 21.8150 / 15.9580 |
| Mouse | B | on | yes | 20.233333 | 500 | 1 | 19.5242 / 24.2852 / 16.3928 |
| Touch | A | off | no | 17.033333 | 400 | 0 | 19.0292 / 25.2771 / 20.9498 |
| Touch | A | off | yes | 30.366667 | 500 | 1 | 35.3257 / 41.2931 / 30.6563 |
| Touch | A | on | no | 9.800000 | 400 | 0 | 12.0607 / 13.0312 / 12.0641 |
| Touch | A | on | yes | 11.866667 | 500 | 1 | 12.7340 / 15.0468 / 13.9969 |
| Touch | B | off | no | 19.033333 | 400 | 0 | 18.5499 / 22.8806 / 17.1103 |
| Touch | B | off | yes | 46.933333 | 500 | 1 | 43.3150 / 46.8402 / 34.8710 |
| Touch | B | on | no | 16.933333 | 400 | 0 | 14.9773 / 21.8150 / 15.9580 |
| Touch | B | on | yes | 20.233333 | 500 | 1 | 19.5242 / 24.2852 / 16.3928 |

Boundary cases cover native alias overlap, opposite-key neutralization and release restoration, repeated echo, mouse and finger latch/drag/release, second finger and emulated mouse rejection, nonowner versus owner canceled touch, NaN press/motion, no immediate teleport, actual speed bound, outside release, temporary keyboard spin ownership, and pause-style clear. `create_view` returns null headless. The validated 24-route test is input/Model evidence. GUI delivery evidence comes from the separate native fixture.

For CI registration, `--headless --script res://game/tests/test_cotton_wind_view.gd` completes with exactly `Cotton wind view: 7 checks, 0 failures`. The seven checks cover eight fixed commands, five projection round trips, and the capture-path guard. The graphical 69-check marker applies only to native runs with PNG export enabled.

## Native geometry, lifetime and raw PNGs

All three native sizes ran at Paper 1.25 with reduced motion. Each parsed 1,447 Godot input events into the actual focused GUI, used ordinary Driver steps, confirmed the mouse ordinary route at 400, and confirmed the touch rejoin route at 500. The parsed physical E/Right pair concurrently spun/moved the workbench. Moving actual Control focus cleared the physical input, simulated window focus loss cleared the latch, the paused filter rejected a parsed key, and removing the actual view cleared active drag and latch. No private handler rescue, material, position, result, or tail seeding was used.

The independent native SubViewport is exactly 880×390. Five round trips at movement plane corners and center agreed with the actual camera ray and `unproject_position` to 0.001 world/design units. The player/helper meshes each contained 194 finite vertices and 864 indices. Both axial rings for each of the three bands and both angular samples per cell matched all of the measured Model radii, and transformed polar samples resolved to the correct local cells. Helper material came from a real separate public input route. Each visible strand instance mapped to its exact previous/current world points out of 128 retained slots. Tail transforms mapped to the actual anchor and free end, and the wire receiver used the opposite band with only the outside end capped. The inner boundary remained at the actual ±30 axial cutoff.

Each size checked all eight retained controls against the real hit rectangles and actual minimums. Five layout checkpoints checked full native-window enclosure and y≥140 design reserve, with 18 visible labels normally and 20 while the tail endpoint labels were active. Font shaping confirmed all three quality readouts fit their separate columns. In each run 120 presentations and 10 resets retained 59 view descendants and 150 tracked node/font/style/material/mesh/batch identities. Resource counts were 28→28 and process node counts 66→66. The unchanged-revision presentations emitted zero mesh change events. Ten reset revisions emitted ten player mesh change events while reusing the same mesh. Actual teardown released the view and its independent World3D.

| Size | Uneven collection | Three uniform bands | Live near-break and opposite receiver | Warm RGB samples, frames 1/2/3 | Changed RGB samples, frames 2/3 | Receiver-color samples |
|---|---|---|---|---|---|---:|
| 1280×720 | [01](D:/Snapland-QA/cotton-wind/task2/view-1280x720-68ce39cd9fa7/captures/game-030-step-01.png) | [02](D:/Snapland-QA/cotton-wind/task2/view-1280x720-68ce39cd9fa7/captures/game-030-step-02.png) | [03](D:/Snapland-QA/cotton-wind/task2/view-1280x720-68ce39cd9fa7/captures/game-030-step-03.png) | 4251 / 4575 / 5272 | 7000 / 9784 | 130 |
| 1152×648 | [01](D:/Snapland-QA/cotton-wind/task2/view-1152x648-616db65dd252/captures/game-030-step-01.png) | [02](D:/Snapland-QA/cotton-wind/task2/view-1152x648-616db65dd252/captures/game-030-step-02.png) | [03](D:/Snapland-QA/cotton-wind/task2/view-1152x648-616db65dd252/captures/game-030-step-03.png) | 3311 / 3562 / 4115 | 6376 / 8849 | 116 |
| 800×600 | [01](D:/Snapland-QA/cotton-wind/task2/view-800x600-87e9af93dc18/captures/game-030-step-01.png) | [02](D:/Snapland-QA/cotton-wind/task2/view-800x600-87e9af93dc18/captures/game-030-step-02.png) | [03](D:/Snapland-QA/cotton-wind/task2/view-800x600-87e9af93dc18/captures/game-030-step-03.png) | 1624 / 1730 / 2001 | 3058 / 4236 | 57 |

All PNGs are raw backbuffer exports at the exact native dimensions. Frame 01 at 4.000 s has 13.2538 player material with masses 0.0000/2.3642/10.8896, confirming real uneven distribution. Frame 02 at 17.033 s has 65.2561 material across 19.0292/25.2771/20.9498 and is physically uniform just before F. Frame 03 at 2.600 s has live tension 80.229, age 0.716667 s, anchor band 0, receiver band 2, and 0.09652 hanging material. Its left anchor is approximately (−80.5453,94.8434,145.9408), and free end (3.8804,94.4297,136.2095). The route then actually catches it. The 1280 set alone was copied without transformation into the product paths and checked byte-identical. The controller inspected the final 1280 set, 800 uniform/near-break, and 1152 uniform raw frames before formal review.

## Self-review and scope

The View uses a 10° orthographic yaw so scenes expose actual capped volume. The orthographic axes also drive the inverse Y=90 plane used for drag targets. Cotton meshes share the Model radius function and use retained material and geometry instances. Angular edge samples join between cell profiles and the 1.4-unit axial transition joins adjacent band samples. Those are render interpolation choices. The actual Model remains the authority for contact. The receiver's outer cap wire approximates the contact surface with bounded arc subdivisions. Reduced motion keeps every essential transform, strand, and tail. No decorative elapsed-animation substitute is present.

The native tests used parsed synthetic events and a standalone workbench. Physical touch, human play, Session/Main lessons, world access, audio listening, packaged saves, and the complete suite remain outside this scoped run. Optional PNG output has a plain absolute filesystem gate and pixel checks precede it. Acceptance runs supplied a fresh explicit path to preserve the nine frames. There is no known Task 2 blocker.
