# SG-47 Task 1 frozen review · afff21c..f024e27

## Spec compliance

❌ **Issues found.** The player and helper can deposit material in a different angular cell from the one their strand physically touched. This breaks the shared contact/thickness geometry specified in `design/runtime/cotton-wind-gameplay.md:3` and `:9`. The single Important finding below blocks approval.

All three Task 1 files are present. The controller's specification changes define variant emission intervals, confirmation bonuses and bounded target pursuit (`design/runtime/cotton-wind-gameplay.md:11`, `:27`, `:29`). The catalog-count addition to the later integration task is planning text (`docs/superpowers/plans/2026-11-18-cotton-wind.md:56`).

## Strengths

- Targets reject nonfinite coordinates and move the real stick at most 120 units/s. Directional input replaces a target, and clearing input cancels both pursuit and rotation. The loop caps elapsed time and tests finite relative strand segments against the finite moving stick axis. See `game/minigames/cotton_wind_model.gd:48`, `:97`, `:186` and `game/tests/test_cotton_wind.gd:65`.
- The model handles cold loss, expiry, overflow and snapped-tail material explicitly. Collection gives the player the first opportunity, limits each cell to four units, and keeps helper deposits independent. The fixture independently sums the cells, flying strands and hanging material. See `game/minigames/cotton_wind_model.gd:162`, `:225`, `:250`, `:272` and `game/tests/test_cotton_wind.gd:46`, `:147`.
- Rejoining requires a live extension window, angular motion and opposite-band contact. The focused receiving test reconstructs the free end, rotating anchor and receiving cell across one public substep, and verifies the material transfer. See `game/minigames/cotton_wind_model.gd:238` and `game/tests/test_cotton_wind.gd:220`. This receiving code already uses the radial position of the free end.
- Mass, coverage, coefficient of variation and inter-band balance determine quality. Participation requires real player collection, travel and spin. Only a confirmed successful finish awards the completion and rejoin bonuses. A fully shaped, rejoined but unconfirmed work reaches the deadline with 300 points. See `game/minigames/cotton_wind_model.gd:76`, `:126`, `:293` and `game/tests/test_cotton_wind.gd:254`.
- The eight ordinary/rejoin, assisted/unassisted, A/B routes use only public targets, spin, time steps and finish. Frozen exact-4.7.2 evidence reports 98 passing checks, zero errors or genuine leaks. The routes certify reachability with the existing bin selection. See `game/tests/cotton_wind_route.gd:7`, `game/tests/test_cotton_wind.gd:28` and the eight measured trajectories in the implementer's report.

## Issues

### Critical

None.

### Important

**The regular strand collector uses the flight direction to select both the contacted surface radius and the receiving cell.** At `game/minigames/cotton_wind_model.gd:194` the closest points provide the actual strand and axis positions. At `:204` the function computes the polar angle from the *negative velocity*. That angle indexes the radius at `:207`, sets the tail anchor at `:213` and selects the deposit at `:222`. A passing strand can therefore thicken a different side of the stick. Once cells have different thicknesses, the same mismatch can produce a false hit or miss. Player and helper use this function.

The discrepancy follows directly from the first A strand's initial conditions at `:149` and ballistic update at `:158`. Public regression recipe: reset without assist, target (0,65), leave spin at zero, then advance at 1/120 s until the first positive deposit. The stick arrives before the first emission. In the relevant substep the strand's (Y,Z) offset from the axis goes from (+2.16389, −5.66667) at age 89/120 to (+2.5, −5) at age 90/120. Its distance falls from 6.06577 to 5.59017, crossing the bare six-unit surface in the middle axial band. The radial angle is in cell 9 throughout. The incoming velocity at the latter sample yields atan2(−80,−40), in cell 8. These are analytic predictions for a new regression, not observations from an engine run.

Use the radial offset between the closest-point pair in the existing Y-cos/Z-sin coordinate convention, subtract the stick's interpolated angle, and use that cell consistently for contact radius, deposit and anchor. Handle the on-axis angular degeneracy explicitly if needed. Assert the first measured deposit changes middle cell 9 and leaves 8 empty; then rerun all eight public routes against the corrected geometry before refreezing. The current first-deposit test at `game/tests/test_cotton_wind.gd:127` compares material quantities. It does not check the angular location.

### Minor

None.

## Cannot verify from this diff

- Driver/source ownership and input clearing through real input events, retained 3D rendering of the angular cells/free end, native viewport layout, tutorial images and text, Session reward eligibility, catalog/entry and packaged execution belong to Tasks 2–4. The design assigns these contracts at `design/runtime/cotton-wind-gameplay.md:31`, `:33`, `:35` and `:39`. Their respective integration, native and export gates must supply evidence.
- No launch was performed for this review. The RED/GREEN logs, staged-byte and engine hashes, launch isolation and absence of leaks are external to the diff. The controller separately verified the frozen GREEN artifacts. The public routes' reachability and exact scores after correcting the contact geometry require a fresh run on the changed bytes.

## Assessment

**Task quality: Needs fixes.** The bounded simulation, material ledger and public-route tests provide a sound foundation. The regular collector's surface choice is inconsistent with physical contact, and its current tests allow that error to pass.
