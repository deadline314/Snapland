# SG-47 Task 3 factory integration

Status **DONE**. Base `c6c3f0a`. Game 030 uses the frozen model and Driver through the existing Session and Main reward route. The factory now offers six games, the complete runtime catalog 30, and the lesson catalog 31 including park. The design keeps 128 candidates with 98 awaiting implementation and game 031 next. Cotton Wind is `game-030` / `cotton_wind` / candy local 6, with `photo-candy-game-6`, `photo-candy-devil-6` and `ACH_GAME_030`. The existing retake prop vocabulary supplies flower horn, lantern and camera. No progress schema, audio, economy, player entry framework, or export exclusions changed.

## Test scope and observations

- Headless Session made 24 independent event-driven routes by crossing keyboard, mouse and single-finger events with A/B, general/assisted, and ordinary/rejoin. The fixture uses headless synthetic events at Session dispatch and advances its clock with bounded steps. All 12 ordinary routes scored 400 and all 12 rejoin routes scored 500. All final bands had all 12 angles covered. The fixture asserts each bounded loop emits the expected single natural result. It covers actual separately deposited helper material with zero player movement, invalid early F, participated timeout, confirmed rejoin vs. an unconfirmed uniform rejoined timeout at 300, practice, pause, focus-loss notification, touch cancel, HUD retry and HUD leave.
- Headless Main measured all five unchanged station coordinates and the new lower-right station. After controlled placement at (6.5, 0.2, 10), Player body origin settled to (6.5, 0.100061, 10), collider feet to (6.5, 0.200061, 10), and the independent floor ray hit (6.5, 0.2, 10). The nearest real point was game-030 and a viewport E event opened the invitation. The capsule bottom's +0.10 local offset explains the different body origin. The six admission cards and intro-seen flag were labelled synthetic setup. No walking or fresh-file admission playthrough is claimed.
- The factory map and ticket list six games, and the existing collection book maps global row 30 to factory slot six. First entry opens all three ordered, real workbench PNGs, and tutorial start records the seen marker and starts the current mode. All seven rules pages fit the real headless 800×600 viewport at 1.25 text scale. Rules and lesson text explain the distinction between lower CV around one band and three band weights close to each other.
- Main's idle helper deadline, practice and cancelled attempts award nothing. Natural participated timeout gets the ordinary card and first 40 points. Later ordinary success preserves its first record, while real rejoin plus uniform F gets the fixed devil card and proof. There is one 40-point receipt across formal replays and reload, the fixed achievement is saved, and neighboring cards remain absent. No Cotton material, tail, results, photos or awards were seeded.
- Each selected retake starts from a fresh isolated save, goes through practice and the real set to its enabled shutter, then emits a 1280×720 synthetic image solely for storage I/O. The chosen card stores the image's exact pixels and a 320×180 thumbnail decoded through the collection book. Replay reaches the genuine ordinary or rejoin result, preserving selected retake provenance and original bytes, with no duplicate receipt. Isolated memory reset and disk load verify persistence. The synthetic originals hash to `6f78de88a00e33dc261570e8de43af8448da95d500b752c73911fb3aaf62c021` and thumbnails to `c3340a25b1f3af919241d1307041547eaffc62ad87fa496997d3e46c9459afbb` for both selections. This is synthetic PNG input and actual file/save/book I/O.
- The four-size existing tutorial pager validated complete semantic fields and footer targets for all 31 lessons. Cotton step page groups at 1.25 were 5/5/5 for 800×600, 5/5/5 for 800×450, 3/3/2 for 1280×720, and 1/1/1 for 1920×1080. These are headless Control and font measurements. Task 4 covers actual Main Input.parse input paths, GPU retake, native size checks, latest gameplay photos and packaged persistence.
- Representative prior Chocolate Main still covered its genuine old results and exact IDs. The prior regional retake, catalog, participation and world regression entries also passed. The CI-only fault parents stayed out of every local stage. Counts in the excluded region travel fixture and both old native Main fixtures received mechanical updates. Other old factory Main/count fixtures were reviewed by diff and are left to CI.

## Exact entrypoints and isolation

All processes used the exact Godot `v4.7.2.stable.official.ed1daf0bf`. SHA-256 values were checked before every launch.

- Console `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe` — `c8f0a6bc45a19b33541501e57f6f7cd972ab18453743266339d495cbbe846643`.
- Backing executable `C:/Tools/Godot/Godot_v4.7.2-stable_win64.exe` — `ab1824f85bfd8e0e4128182c000c4003a3e042245b2967848d089b2a04b22424`.

From the repository directory in PowerShell:

```powershell
$env:PYTHONIOENCODING = 'utf-8'
$task3Runner = '.superpowers/sdd/2026-11-18-cotton-wind/task-3-run.py'
$task3Narrow = 'D:/Snapland-QA/cotton-wind/task2/import-1280x720-0d1a4a83e16e'
python -B $task3Runner red --seed $task3Narrow
python -B $task3Runner import
$task3Full = 'D:/Snapland-QA/cotton-wind/task3/import-746a3968ef4c'
python -B $task3Runner model --seed $task3Narrow
python -B $task3Runner driver --seed $task3Narrow
python -B $task3Runner view --seed $task3Narrow
python -B $task3Runner session --seed $task3Full
python -B $task3Runner main --seed $task3Full
python -B $task3Runner catalog --seed $task3Full
python -B $task3Runner world --seed $task3Full
python -B $task3Runner tutorial --seed $task3Full
python -B $task3Runner tutorial-paged --seed $task3Full
python -B $task3Runner retake --seed $task3Full
python -B $task3Runner participation --seed $task3Full
python -B $task3Runner chocolate-main --seed $task3Full
python -B -m unittest discover -s tests -p test_design_validation.py -v
python -B -m unittest discover -s tests -p test_runtime_result_contract.py -v
python -B tools/verify_design.py --scope games
python -B tools/verify_design.py --scope links
git -c core.safecrlf=false diff --check
```

RED was actually run before changing runtime registration, and exits 1 for the missing 030 live Session. For replaying RED independently, combine the recorded fixture and launcher with the runtime at base. The two Python suites passed 48 and 23 tests, with `PASS games` and `PASS links`. Both scopes report design verification rather than gameplay or playtesting. The working product diff passed `diff --check`.

The launcher works through the existing `prepare_runtime_stage` and `run_validated_godot`. Each manifest contains fully expanded engine argv, fresh absolute D: profiles and file fingerprints. The import is editor headless asset-only. Standalone SceneTree suites use `--script`, Node suites use their real `.tscn`. All use `--headless --path <run>/project --log-file <run>/engine.log`. The profile is a new `<run>/save/progress.json`, with private appdata, local, temp, tmp, captures, and export directories. The stage contains tracked runtime assets and scripts plus only the recursively named fixture closure. Asset-only imported resources and metadata were reused after verifying the raw source list and SHA-256, exact engine pair, strict clean import receipt and hashes of imported files. No repository UIDs, cached script/class metadata, old package, C: staging or whole test tree entered any stage.

Before each launch, the complete staged GDScript, scene, shader and project config set was audited. OS access was limited to environment, arguments and user data path lookups. No native extension or process-capable Engine, OS or bridge API exists in the staged runtime and fixture closure. Callback inspection covered Main's local UI closures, collection photo readers, world's grounding and obstacle accessors and existing SteamBridge's unset sender. Capturing and native rule helper scripts reached as preloaded types did not execute entry methods. `test_photo_retake_main`, `test_region_travel`, `test_photo_retake_progress`, and `test_region_progress` were excluded before every local launch, with their CI registrations preserved. The launch helper creates one engine process and has a bounded Windows `taskkill` fallback for its own timeout. One intermediate malformed scene fixture hit that validated cleanup path. There was no unexpected OS child request.

## Strict engine evidence

The receipt beside each manifest contains the stored stdout/stderr/engine log SHA-256 and length. Accepted markers appeared once in both engine log and combined raw stdio. Every GREEN exited 0 with no ERROR or genuine leaked or still-in-use diagnostics. Existing welcome-scene warnings about preserving a ShaderMaterial without cutaway remain recorded unfiltered in the Main log.

| Invocation | Actual exit and completion | Manifest SHA-256 | Evidence |
|---|---|---|---|
| `red` | 1 · `Cotton wind Session: 1 checks, 1 failures` | `1489a59de32b4a68a6b1b2b2355b9ac802f44a40ec27edf0dceeb54405a901d4` | [manifest](D:/Snapland-QA/cotton-wind/task3/red-da808cc91e31/manifest.json) · [receipt](D:/Snapland-QA/cotton-wind/task3/red-da808cc91e31/receipt.json) · [stdout](D:/Snapland-QA/cotton-wind/task3/red-da808cc91e31/stdout.txt) · [stderr](D:/Snapland-QA/cotton-wind/task3/red-da808cc91e31/stderr.txt) · [engine](D:/Snapland-QA/cotton-wind/task3/red-da808cc91e31/engine.log) |
| `import` | 0 · `[ DONE ] loading_editor_layout` | `e22b8b15d1347655af51c22064c7a28f89057f4643b7dc74681477f6810cd60e` | [manifest](D:/Snapland-QA/cotton-wind/task3/import-746a3968ef4c/manifest.json) · [receipt](D:/Snapland-QA/cotton-wind/task3/import-746a3968ef4c/receipt.json) · [stdout](D:/Snapland-QA/cotton-wind/task3/import-746a3968ef4c/stdout.txt) · [stderr](D:/Snapland-QA/cotton-wind/task3/import-746a3968ef4c/stderr.txt) · [engine](D:/Snapland-QA/cotton-wind/task3/import-746a3968ef4c/engine.log) |
| `model` | 0 · `Cotton wind model: 99 checks, 0 failures` | `fad852b8d6e989342a6c6f9e64e0ce2a803173b1be901e7e577087b59e394be9` | [manifest](D:/Snapland-QA/cotton-wind/task3/model-062a293cde42/manifest.json) · [receipt](D:/Snapland-QA/cotton-wind/task3/model-062a293cde42/receipt.json) · [stdout](D:/Snapland-QA/cotton-wind/task3/model-062a293cde42/stdout.txt) · [stderr](D:/Snapland-QA/cotton-wind/task3/model-062a293cde42/stderr.txt) · [engine](D:/Snapland-QA/cotton-wind/task3/model-062a293cde42/engine.log) |
| `driver` | 0 · `Cotton wind driver: 62 checks, 0 failures` | `4cf838c4499e77c15e03205ea22564ee2e78d020359a40191a0fd004fe9d6aa7` | [manifest](D:/Snapland-QA/cotton-wind/task3/driver-4ee68af05e98/manifest.json) · [receipt](D:/Snapland-QA/cotton-wind/task3/driver-4ee68af05e98/receipt.json) · [stdout](D:/Snapland-QA/cotton-wind/task3/driver-4ee68af05e98/stdout.txt) · [stderr](D:/Snapland-QA/cotton-wind/task3/driver-4ee68af05e98/stderr.txt) · [engine](D:/Snapland-QA/cotton-wind/task3/driver-4ee68af05e98/engine.log) |
| `view` | 0 · `Cotton wind view: 7 checks, 0 failures` | `f6810da5748bd8b60d341ccbc1c018b3c1859d2c5a82c50e75b81b75b3b79329` | [manifest](D:/Snapland-QA/cotton-wind/task3/view-12b4fd94b1ef/manifest.json) · [receipt](D:/Snapland-QA/cotton-wind/task3/view-12b4fd94b1ef/receipt.json) · [stdout](D:/Snapland-QA/cotton-wind/task3/view-12b4fd94b1ef/stdout.txt) · [stderr](D:/Snapland-QA/cotton-wind/task3/view-12b4fd94b1ef/stderr.txt) · [engine](D:/Snapland-QA/cotton-wind/task3/view-12b4fd94b1ef/engine.log) |
| `session` | 0 · `Cotton wind Session: 98 checks, 0 failures` | `e147f697464007fd72581532045fab322b19b2b8c8f5d0b93a87c84746c87d1f` | [manifest](D:/Snapland-QA/cotton-wind/task3/session-fa656c62b284/manifest.json) · [receipt](D:/Snapland-QA/cotton-wind/task3/session-fa656c62b284/receipt.json) · [stdout](D:/Snapland-QA/cotton-wind/task3/session-fa656c62b284/stdout.txt) · [stderr](D:/Snapland-QA/cotton-wind/task3/session-fa656c62b284/stderr.txt) · [engine](D:/Snapland-QA/cotton-wind/task3/session-fa656c62b284/engine.log) |
| `main` | 0 · `Cotton wind Main: 70 checks, 0 failures` | `fa5e36873bf16e092de16c043e0bd07b1c8812f2af5b2ab6baba79a91fddf058` | [manifest](D:/Snapland-QA/cotton-wind/task3/main-40a63d624baf/manifest.json) · [receipt](D:/Snapland-QA/cotton-wind/task3/main-40a63d624baf/receipt.json) · [stdout](D:/Snapland-QA/cotton-wind/task3/main-40a63d624baf/stdout.txt) · [stderr](D:/Snapland-QA/cotton-wind/task3/main-40a63d624baf/stderr.txt) · [engine](D:/Snapland-QA/cotton-wind/task3/main-40a63d624baf/engine.log) |
| `catalog` | 0 · `PASS: delivered game catalog, copies, regional identity and malformed data` | `2ede9b8c57e1f82db935d5bd3530e7b81fadfe5b43ef626c8115caced5348f6e` | [manifest](D:/Snapland-QA/cotton-wind/task3/catalog-9d5b8f4983ab/manifest.json) · [receipt](D:/Snapland-QA/cotton-wind/task3/catalog-9d5b8f4983ab/receipt.json) · [stdout](D:/Snapland-QA/cotton-wind/task3/catalog-9d5b8f4983ab/stdout.txt) · [stderr](D:/Snapland-QA/cotton-wind/task3/catalog-9d5b8f4983ab/stderr.txt) · [engine](D:/Snapland-QA/cotton-wind/task3/catalog-9d5b8f4983ab/engine.log) |
| `world` | 0 · `PASS: candy world connected terrain, temperature, safe reset, map and bounded reentry` | `0f2f152a9eb84a97f26d0ac5b44ddc313a15244b50107ae23c2547444635433c` | [manifest](D:/Snapland-QA/cotton-wind/task3/world-1882d5954b80/manifest.json) · [receipt](D:/Snapland-QA/cotton-wind/task3/world-1882d5954b80/receipt.json) · [stdout](D:/Snapland-QA/cotton-wind/task3/world-1882d5954b80/stdout.txt) · [stderr](D:/Snapland-QA/cotton-wind/task3/world-1882d5954b80/stderr.txt) · [engine](D:/Snapland-QA/cotton-wind/task3/world-1882d5954b80/engine.log) |
| `tutorial` | 0 · `PASS: tutorial panel/catalog checks` | `5894325bbc6aa22a3a6d7c8ef2313a6fec601334701b643678487c20622a1196` | [manifest](D:/Snapland-QA/cotton-wind/task3/tutorial-941f45a534c8/manifest.json) · [receipt](D:/Snapland-QA/cotton-wind/task3/tutorial-941f45a534c8/receipt.json) · [stdout](D:/Snapland-QA/cotton-wind/task3/tutorial-941f45a534c8/stdout.txt) · [stderr](D:/Snapland-QA/cotton-wind/task3/tutorial-941f45a534c8/stderr.txt) · [engine](D:/Snapland-QA/cotton-wind/task3/tutorial-941f45a534c8/engine.log) |
| `tutorial-paged` | 0 · `PASS: native-matching tutorial steps for every lesson, all five semantic fields in capacity-driven page groups, three sizes/1.25, visible copy clip/line height and blocked wheel` | `da3dfcd66e4b6f95c3c7e428eb64791a6c6f13d505b71bce41bf08718fbbc0c1` | [manifest](D:/Snapland-QA/cotton-wind/task3/tutorial-paged-c5e1ad50e832/manifest.json) · [receipt](D:/Snapland-QA/cotton-wind/task3/tutorial-paged-c5e1ad50e832/receipt.json) · [stdout](D:/Snapland-QA/cotton-wind/task3/tutorial-paged-c5e1ad50e832/stdout.txt) · [stderr](D:/Snapland-QA/cotton-wind/task3/tutorial-paged-c5e1ad50e832/stderr.txt) · [engine](D:/Snapland-QA/cotton-wind/task3/tutorial-paged-c5e1ad50e832/engine.log) |
| `retake` | 0 · `PASS: retake panel canonical targets, reversible state, keyboard and capture guards` | `32312ebc50db594fb17bc8d9e9ab74362e56307cb5b2df7a949c69eeca98acdd` | [manifest](D:/Snapland-QA/cotton-wind/task3/retake-254dd3ad8c29/manifest.json) · [receipt](D:/Snapland-QA/cotton-wind/task3/retake-254dd3ad8c29/receipt.json) · [stdout](D:/Snapland-QA/cotton-wind/task3/retake-254dd3ad8c29/stdout.txt) · [stderr](D:/Snapland-QA/cotton-wind/task3/retake-254dd3ad8c29/stderr.txt) · [engine](D:/Snapland-QA/cotton-wind/task3/retake-254dd3ad8c29/engine.log) |
| `participation` | 0 · `PASS: every delivered participation result, practice, cancellation and driver eligibility` | `051f6d19934c9e74281b5bc677ed8842b1425357b7d3ef0d2afb373b09b8d914` | [manifest](D:/Snapland-QA/cotton-wind/task3/participation-e3154675a673/manifest.json) · [receipt](D:/Snapland-QA/cotton-wind/task3/participation-e3154675a673/receipt.json) · [stdout](D:/Snapland-QA/cotton-wind/task3/participation-e3154675a673/stdout.txt) · [stderr](D:/Snapland-QA/cotton-wind/task3/participation-e3154675a673/stderr.txt) · [engine](D:/Snapland-QA/cotton-wind/task3/participation-e3154675a673/engine.log) |
| `chocolate-main` | 0 · `PASS: chocolate Main factory entrance, three-wheel and leftover idler results, fixed rewards, selected PNG I/O and reload` | `d9ce3cf86b889034ac8960c9bbcd4d4b7728ae6780b20d6dd27295cea3bf66ef` | [manifest](D:/Snapland-QA/cotton-wind/task3/chocolate-main-f9c6d031c8df/manifest.json) · [receipt](D:/Snapland-QA/cotton-wind/task3/chocolate-main-f9c6d031c8df/receipt.json) · [stdout](D:/Snapland-QA/cotton-wind/task3/chocolate-main-f9c6d031c8df/stdout.txt) · [stderr](D:/Snapland-QA/cotton-wind/task3/chocolate-main-f9c6d031c8df/stderr.txt) · [engine](D:/Snapland-QA/cotton-wind/task3/chocolate-main-f9c6d031c8df/engine.log) |

The RED diagnostic before its marker was `FAIL: game-030 must open a live Cotton Wind Session`. The first intermediate Main fixture at `main-243b36676420` had two typed-Control inference errors and did not initialize the fixture watchdog. The validated launcher handled the bounded timeout. Its unpromoted engine log and manifest remain in that run. The next Main candidate at `main-e708f5b70478` ran 68 checks with seven failures. It used the body origin where the test should have used the feet, and expected global definitions in a region-scoped album. The final Main tests assert actual collider feet and catalog-to-region row mapping, and add both book thumbnail decodes. None of those failures required moving the new game point.

## Actual Session route record

| Source | Variant | Assisted | Rejoin | Seconds | Score | Rejoins | Band masses left / center / right |
|---|---|---|---|---:|---:|---:|---|
| keyboard | A | False | False | 17.150000 | 400 | 0 | 19.5255 / 25.7836 / 20.4858 |
| keyboard | A | False | True | 30.091667 | 500 | 1 | 36.0463 / 40.8121 / 30.4322 |
| keyboard | B | False | False | 19.041667 | 400 | 0 | 18.5652 / 22.9010 / 17.1205 |
| keyboard | B | False | True | 46.766667 | 500 | 1 | 43.2844 / 46.9685 / 35.1490 |
| keyboard | A | True | False | 9.791667 | 400 | 0 | 12.0675 / 13.0397 / 12.0692 |
| keyboard | A | True | True | 11.358333 | 500 | 1 | 12.7544 / 14.1579 / 12.2504 |
| keyboard | B | True | False | 16.600000 | 400 | 0 | 14.4963 / 21.3459 / 15.9648 |
| keyboard | B | True | True | 20.658333 | 500 | 1 | 19.4970 / 24.5299 / 16.6026 |
| mouse | A | False | False | 17.033333 | 400 | 0 | 19.0292 / 25.2771 / 20.9498 |
| mouse | A | False | True | 30.366667 | 500 | 1 | 35.3257 / 41.2931 / 30.6563 |
| mouse | B | False | False | 19.033333 | 400 | 0 | 18.5499 / 22.8806 / 17.1103 |
| mouse | B | False | True | 46.933333 | 500 | 1 | 43.3150 / 46.8402 / 34.8710 |
| mouse | A | True | False | 9.800000 | 400 | 0 | 12.0607 / 13.0312 / 12.0641 |
| mouse | A | True | True | 11.866667 | 500 | 1 | 12.7340 / 15.0468 / 13.9969 |
| mouse | B | True | False | 16.933333 | 400 | 0 | 14.9773 / 21.8150 / 15.9580 |
| mouse | B | True | True | 20.233333 | 500 | 1 | 19.5242 / 24.2852 / 16.3928 |
| touch | A | False | False | 17.033333 | 400 | 0 | 19.0292 / 25.2771 / 20.9498 |
| touch | A | False | True | 30.366667 | 500 | 1 | 35.3257 / 41.2931 / 30.6563 |
| touch | B | False | False | 19.033333 | 400 | 0 | 18.5499 / 22.8806 / 17.1103 |
| touch | B | False | True | 46.933333 | 500 | 1 | 43.3150 / 46.8402 / 34.8710 |
| touch | A | True | False | 9.800000 | 400 | 0 | 12.0607 / 13.0312 / 12.0641 |
| touch | A | True | True | 11.866667 | 500 | 1 | 12.7340 / 15.0468 / 13.9969 |
| touch | B | True | False | 16.933333 | 400 | 0 | 14.9773 / 21.8150 / 15.9580 |
| touch | B | True | True | 20.233333 | 500 | 1 | 19.5242 / 24.2852 / 16.3928 |

## Source and raw image seals

The product allowlist below excludes intermediate reports, launcher and import sidecars. Model, Driver, View and raw PNG sources were already frozen. Supplemental edits approved by the controller are the retake prop row and affected retake test, plus count-only changes to the two old native fixtures.

| Product path | Bytes | SHA-256 |
|---|---:|---|
| `design/02-minigames/catalog.json` | 181271 | `d2da623d23c9de9f69a743e2821242bf4968fd3300653241bf30e5b4b9120146` |
| `design/02-minigames/catalog.md` | 152871 | `b76f1795e5f7969d56b09fecd422980057c546c20d0ec8d75e615e781019b569` |
| `design/runtime/full-game-delivery.md` | 4793 | `4df3855d0476d90d206ac317b52f373bfb68bcf80b634cc9b175ea0a4477f702` |
| `game/core/game_catalog.gd` | 3012 | `0d958c94542445aa7a522cfd950f6de68486ab107d93d3305df32d071739e15b` |
| `game/data/candy_games.json` | 4697 | `cdeaf7e1b49ef2e7134256f6b87e4899225f263d073ea2aab74221a91d158b94` |
| `game/data/tutorials.json` | 72335 | `31b606f73f28dd7ca6644612365e050c82777f26487edb024d5d75842ae56800` |
| `game/main.gd` | 116195 | `adfc5078c682503eef8476d5b8a0fb080cfc7f42ea64501ca968a8039ce59073` |
| `game/minigames/session.gd` | 144839 | `af7e2a69a21003f8d0d1b8abd666a2208fc76e88a57ccf61b6a7d45cdf520a89` |
| `game/tests/native_chocolate_etching_main.gd` | 36979 | `fc9824bee1bb08b787a795afd3c3ee27fc7f87e2e0978e6b1a8eb4bcfd93d93d` |
| `game/tests/native_jelly_trampoline_main.gd` | 27653 | `3e8bb5205dd65c0ef8c429a5829a218fb825cb3c37133140b9f8df3d5db01028` |
| `game/tests/test_candy_world.gd` | 12242 | `85d5ba3da95c8ba29b7ba2d74f9c76bf15d0e2be9b8658294d961376e73f0f1a` |
| `game/tests/test_chocolate_etching_main.gd` | 16465 | `96d7ece94de0ace171a594fddde25dcc18b94af7388cbcbdca365b0ae0540ff2` |
| `game/tests/test_cookie_mold_main.gd` | 11595 | `50df0175ceae0c75663b40da56c942fa7cc9164f2f9a0b574835b1e94cfa3890` |
| `game/tests/test_cookie_mold_session.gd` | 8077 | `831eb82ba31d8db0f4dddc9b30b23e53ce5c60693b8ef71133b986ff0f43d862` |
| `game/tests/test_cotton_wind_main.gd` | 17177 | `88cebd558cf45b967172810600049bebee5963903f5bfe5cf07335d925a8ccf5` |
| `game/tests/test_cotton_wind_main.tscn` | 191 | `28328c866be9f361ffbbc2b3198ecf83d6d2e368bd4252fe8cdd44da107d1d20` |
| `game/tests/test_cotton_wind_session.gd` | 11312 | `909200e94c94420e11f706fe6d5e245247941d13a9e7a2b502ae6aa5b50860e4` |
| `game/tests/test_game_catalog.gd` | 11253 | `3aa9b1a062e96e5f927bf04831354149a387f573225c6b6da6863db1379e7945` |
| `game/tests/test_jelly_trampoline_main.gd` | 14882 | `8bf3c8c4b5b3c91af42878a4d5418f3415e17b26f92a4713b98de2a75c01b3e6` |
| `game/tests/test_participation_results.gd` | 4532 | `14e1fba1326e3205ce0c3e6aee1dcc038b7b1a5b68ca3d45b959d829d2853c58` |
| `game/tests/test_region_travel.gd` | 28131 | `07b9585b5e4231c0de1cdb0c8be11d2e3358aef5f076f64c16623b7d9eebafd1` |
| `game/tests/test_retake_panel.gd` | 7155 | `cbccab5009fae90d1bf4355973e04f336dc14815b79f316a18fa06d757cb1812` |
| `game/tests/test_sugar_bridge_main.gd` | 10599 | `6d81de11491cf91f5db8de6f760758342b4ac07c0c6b8d151b0f9666af068d73` |
| `game/tests/test_sugar_bridge_session.gd` | 6904 | `a385602fbd39156c8fdc280f817234d7d83c91a5cbdc158030a7c18f14fb5e74` |
| `game/tests/test_syrup_flood_main.gd` | 12702 | `f66d6012f70885451165495d0f50eed19ed8cb79126d766be420898a87c5d6de` |
| `game/tests/test_tutorial_paged_viewport.gd` | 5199 | `7d42ca38403e824d26b716275def7eb04324f0c293c283803921ec53cf627e37` |
| `game/ui/collection_book_panel.gd` | 32290 | `58398b7771ad10be8719344be27a908caf438dfabbd8c40cca9a8cff542e21cf` |
| `game/ui/retake_panel.gd` | 14873 | `6088ba258722cb490a6b854df1e490e8eb8f31400adbd5461be75cfe764451a1` |
| `game/ui/tutorial_catalog.gd` | 4632 | `e9a3e6d7d6ef546f6f4c3974a0fe99eb01717ab7c0e6c1e88e3563e17d0667ad` |
| `game/world/candy_world.gd` | 8852 | `48812ae031b3a80a9b9e6c9b9cca8b0a955c711f5caaaa8877c2a23de292e0d3` |
| `tests/test_design_validation.py` | 17666 | `c0a29c786a0d223c62be706524a444fee102a0c604efeb6f283d0792c9325ddd` |
| `tests/test_runtime_result_contract.py` | 24907 | `87aa5f0de94bd899de9947ecb0502e01b11ff09cb9a41d2bd4c14ed18f84b2c0` |
| `tools/run_game_tests.py` | 54181 | `03353aabfebef143d3c0dcb24a0d755c6768e9a6a61041f10dbb4cbf3352a13e` |
| `tools/verify_design.py` | 17596 | `48dc55f9ac269fdf8b0e57601bc9da382b8557ce308c98d33a5f3dcae8661557` |

| Frozen source or reviewed helper | Bytes | SHA-256 |
|---|---:|---|
| `assets/ui/tutorials/game-030-step-01.png` | 36375 | `c8a5623b23ec61cc54782900623e13a6e53b61a760abe755a38fe380fb61784b` |
| `assets/ui/tutorials/game-030-step-02.png` | 38451 | `a1238d7906b576298ce6783678f4749873e225b75ad4eca95045402abbdc3236` |
| `assets/ui/tutorials/game-030-step-03.png` | 38067 | `8a8a1e293d42897b769e453cea140bbae5717e60340c27aac422ff2fb2867411` |
| `game/minigames/cotton_wind_model.gd` | 12209 | `bea36ef93e1aee775ccad0c0dbab99bec014e9c1862bd5bddd7e7389a107ea54` |
| `game/minigames/cotton_wind_driver.gd` | 5622 | `3c822de411bb95c8bbba402cc1eb3f87a0231c2b8f9afbb31586cec3b60914a4` |
| `game/minigames/cotton_wind_view.gd` | 23038 | `53032548d5e117d486af359f7def98c1e623288ea217c436ee060b0003257b38` |
| `game/tests/cotton_wind_route.gd` | 873 | `1c005e67c5cbe040e8b88d1bed8cbeb95cbaf7a47d51674e21569082bb607027` |
| `tools/build_desktop_release.py` | 5591 | `ff5e8c6238b09e839013a2732820dc7d64057dd56f82e37a8094b29d612dce98` |
| `tools/godot_entrypoints.py` | 12242 | `7e126f059e6477b586019852967cbea6bc1049380237895427d6a9da188f3ed3` |
| `.superpowers/sdd/2026-11-18-cotton-wind/task-3-run.py` | 10557 | `512f26117ced0254266d815039ef5dda12ffcca22958e57e78a7edf1cb618b0b` |

The three lesson PNGs are Task 2's original raw 1280×720 workbench frames. Their hashes match the green Main manifest and Task 2 Vulkan receipt. Frame 1 shows actual uneven buildup, frame 2 actual uniform bands before confirmation, and frame 3 actual near-break tail and opposite receiver. Task 3 used the existing files without editing pixels.

## Self-review limitations

The fixture uses deterministic headless event dispatch for route characterization, a viewport E event at controlled positions, and synthetic RGBA input to exercise photo storage. Native focused GUI delivery, GPU capture and fresh packaged verification remain with Task 4. The full suite and four fault-child parents remain CI scope. The older source-specific warning path above was preserved in raw evidence. No further Task 3 blocker is known.
