# SG-47 supplemental final verification

The final-fix wave starts from `1ca72ff838b5141ae6beead03b869b641c58bea9`. A 1280×720 native standalone run produced the replacement first lesson frame. An 800×600 Main writer and its separate reader verified the compact captions and gameplay photos. A newly exported 1280×720 Windows build booted twice from the same embedded executable. Each successful gameplay launch exited 0 with exactly one marker in the original engine log and one in stdout, zero errors, warnings or genuine leak diagnostics. Refusal tests deliberately exit 1. Native keyboard, mouse and touch events in these runs came from scripted Input.parse_input_event. The six-card admission, seen opening and controlled actor placement precede the actual E interaction.

## Reproduction and audit

Commands ran in the repository. The reviewed Task 4 console runner was copied and adapted in `.review/cotton-wind-20261118/final-fix`. Every Godot or embedded invocation ran through run_validated_godot with a separate absolute D: project, profiles, two temp directories, capture and export directory. Only the paired reader shared a writer's isolated save. The separate refusal cases use freshly created disposable sentinels. All runs re-hashed the pinned console and editor, audited the staged script/scene/resource/config graph and exact fixture dependency closure before child launch, and excluded test_photo_retake_main, test_region_travel, test_photo_retake_progress and test_region_progress. Per-run prelaunch-audit.json, source-graph.json, runtime-graph.json and receipt.json retain argv and hashes. No runtime script came from an import cache.

```powershell
$fix = '.review/cotton-wind-20261118/final-fix'
$runner = "$fix/native_run.py"
$previous = 'D:/Snapland-QA/cotton-wind/task4/cotton-a-donor-1119-040639-9854fe'
$donor = 'D:/Snapland-QA/cotton-wind/final-fix/donor-1119-043400-30b24a'
python -B $runner view-red --donor $previous
python -B $runner view --donor $previous
# Controller inspected and promoted the byte-identical 1280px partial frame here.
python -B $runner import
python -B "$fix/test_preflight.py"
python -B $runner refuse-profile --donor $donor
python -B $runner refuse-capture --donor $donor
python -B $runner small --donor $donor
python -B $runner embedded --donor $donor
python -B "$fix/check_ordinary_guard.py" --base 1ca72ff
python -B "$fix/check_ordinary_guard.py"
python -B "$fix/seal.py"
```

The historical view-red run used the new GUI assertion against the previous View before the display change. Its source graph records those exact staged bytes. The two standalone runs preceded asset promotion and used the previously verified donor with identical asset/config bytes. The new donor rebuilt the full final asset set, with one completed editor import marker. It supplied only addressed asset imports to the final native and export stages. The final release export recorded one completed savepack marker. Both use Godot `4.7.2.stable.official.ed1daf0bf`, console SHA-256 `c8f0a6bc45a19b33541501e57f6f7cd972ab18453743266339d495cbbe846643`, sibling `ab1824f85bfd8e0e4128182c000c4003a3e042245b2967848d089b2a04b22424`.

## Writer refusal and reader identity

The pre-fix source can be inspected with `git show 1ca72ff:game/tests/native_cotton_wind_main.gd`. An accumulated fresh-save check fell through to reset and grants, and a pre-populated capture directory reached the inherited overwriting PNG writer. All prior accepted runs used fresh paths. The current launcher rejects a dirty destination before starting Godot. The scene validates both paths with SaveGuard, requires empty/listable, writable writer and capture directories, and returns a nonzero diagnostic before reset, grants or capture. Reader provenance binds the absolute writer save and its SHA-256. The validated launcher also checks the writer's successful receipt.

Nine Python cases verify zero child calls and identical directory inventories, including hashes of every sentinel. The old migration-eligible save contains a legacy welcome devil card with an empty frames field and no ordinary photo. Other cases cover solitary backup and temporary files, a directory at the intended save, hidden capture content, a file as capture directory, a missing save parent or stage, and an unpaired reader. [Preflight test results](C:/Users/stanl/Github/Snapland/.review/cotton-wind-20261118/final-fix/preflight-results.json)

The two direct-scene negative tests deliberately exercise only newly synthesized disposable paths. Both emitted exactly one expected `ERROR: Native cotton preflight: expected a fresh empty directory` with the appropriate save/capture path. Neither reached synthetic admission or wrote a receipt/capture at the destinations. The before/after save hash is `19974e436facbef04cddc748bf9c3f35e9e27248f6862f6d9a7e8410f3cf06e9`. The distinct backup is `0db9db6740070cc25217187b2fdcf87fa9ad0225cdb79349e2198be7ba9befb6`. The used capture is `6fd44c39ce0befcbba299420ff10a0feee4c30819e43ad5fb7321f7a8f23bc05`. [Save and backup sentinels](D:/Snapland-QA/cotton-wind/final-fix/refuse-profile-1119-043531-00f2d5/sentinels.json) · [Capture sentinel](D:/Snapland-QA/cotton-wind/final-fix/refuse-capture-1119-043544-07e378/sentinels.json)

Directly launching the scene or a QA executable outside the validated launcher with a migration-eligible legacy save can still let the shared Progress autoload migrate that save before any scene guard can run. The launcher catches this before process creation. The in-scene sentinel tests use a current-schema save. Production Progress and its migration behavior remain unchanged.

The first direct refusal candidate diagnosed `Cannot infer the type of "restored" variable because the value doesn't have a set type` while parsing the new zoom check. Its owned engine process was stopped. An explicit bool annotation resolved it before the accepted native tests. [Discarded candidate receipt](D:/Snapland-QA/cotton-wind/final-fix/refuse-profile-1119-043454-5670a8/receipt.json)

## Empty band and terminal ordinary route

The RED standalone 1280 rendered the old numeric ratio with an empty band. Its only failure was `ERROR: partial collection identifies the empty band` (71 checks, 1 failure). GREEN uses the model's finite zero sentinel to show 先補滿空段. At 4.000 s the actual masses were 0, 2.3642 and 10.8896. At 17.0333 s they were 19.0292, 25.2771 and 20.9498, with measured ratio 1.32833224728312 and displayed 厚薄比 1.33. The standalone GUI reported 71/0. The original no-GPU 7-check branch exits before any changed native assertions. No headless run was required by this fix. [RED engine log](D:/Snapland-QA/cotton-wind/final-fix/view-red-1119-043153-798bf3/engine.log) · [GREEN engine log](D:/Snapland-QA/cotton-wind/final-fix/view-1119-043228-178335/engine.log)

The private structural regression on the base commit exited 1 and diagnosed that falling through 1,200 route iterations reached reset without an unconditional ended/success/400/eligibility check. The same check on final source exited 0. The native GREEN additionally recorded `{"ended":true,"ordinary_eligible":true,"score":400,"success":true}` following parsed controls. The model, rotation, contact, readiness, F confirmation and score code did not change. [Historical check](C:/Users/stanl/Github/Snapland/.review/cotton-wind-20261118/final-fix/ordinary-guard-before.txt) · [Fixed check](C:/Users/stanl/Github/Snapland/.review/cotton-wind-20261118/final-fix/ordinary-guard-after.txt)

The promoted native full-frame partial is 1280×720, 36,479 bytes, SHA-256 `1b447bbd7223b406ae363aa5c25abfefd96b16def18dca1fcdbda5dc8ad88dbd`. It came directly from the mouse-replayed backbuffer; the controller verified and promoted these exact bytes. The two other lesson frames retain their previously accepted bytes. [Standalone lesson source PNG](D:/Snapland-QA/cotton-wind/final-fix/view-1119-043228-178335/captures/game-030-step-01.png)

## Compact tutorial

The original 800 receipt reported the entire slide 1 caption fitting a 281×31 inline rectangle. No screenshot zoom observations existed for any slide. The final 800×600 UI at 1.25 and reduced motion records each of the three inline captions as abbreviated with full text_fits false. All five text fields remain accessible through the lesson pagination. Parsed Tab events reached each screenshot button, Enter opened its zoom with real focus on Back, and a second Enter restored focus to that slide's preview. [Original measurements](D:/Snapland-QA/cotton-wind/task4/cotton-800-suite-1119-041149-e8a6cf/captures/cotton-evidence.json) · [Final measurements](D:/Snapland-QA/cotton-wind/final-fix/small-suite-1119-043557-38fc28/captures/cotton-evidence.json)

The full captions matched their lesson texts. Each occupied one untrimmed line with measured width 713, 589 and 667 px, respectively, inside a 776×31 rectangle at (12,490). The actual zoom texture matched the lesson's texture; its rectangle was 776×436.5 at (12,12). The fully visible 180×55 Back control began at (310,533). The scene measured the ancestors' clipping and tested the distinct rectangles. All three screenshot focus returns passed.

| Actual 800 capture | Raw SHA-256 |
| --- | --- |
| [Ordinary partial](D:/Snapland-QA/cotton-wind/final-fix/small-suite-1119-043557-38fc28/captures/ordinary-partial.png) | `7ed01f8693b0101d87e4e469f32f40961d65ee25d61b0de941e06baa60eee3ad` |
| [Ordinary ready](D:/Snapland-QA/cotton-wind/final-fix/small-suite-1119-043557-38fc28/captures/ordinary-ready.png) | `649b4e8c7d803a68c336b863fa0fc7ff1571552b650dc1d57ff9c5463ff0eba4` |
| [Collection caption](D:/Snapland-QA/cotton-wind/final-fix/small-suite-1119-043557-38fc28/captures/tutorial-1-zoom.png) | `b173c2994b5e14a2701ffc6d5243a75dbbcd19e16c05ecce3d43f44a60c840f8` |
| [Uniform caption](D:/Snapland-QA/cotton-wind/final-fix/small-suite-1119-043557-38fc28/captures/tutorial-2-zoom.png) | `e57e4c9481a78dbdad57e822b32d304b4f8fd71d73dff56b05166ba45368da05` |
| [Rejoin caption](D:/Snapland-QA/cotton-wind/final-fix/small-suite-1119-043557-38fc28/captures/tutorial-3-zoom.png) | `9105495e0954dd98b84f416747ff49e7b93cc595d77ac98b5bb918041faba072` |

## Process output, package and continuity

Task 4's report called stdout and stderr “both raw streams.” The shared validated launcher uses text mode, UTF-8 decoding with replacement and universal newline handling. The runner saved those unsuppressed decoded process streams encoded as UTF-8, alongside the original engine log. The acceptance markers, warnings and per-file hashes apply to those preserved files. All previously accepted receipts and log files retain their original bytes. The source and archived runner establish the representation directly, without an extra process run for this wording correction.

The 800 writer/reader each passed with engine-log check counts 1,279 and 38. The same EXE's independent 1280 writer/reader passed with 1,116 and 38. These are the printed pre-shutdown counts. The JSON counts differ because the final profile photo checks run later. Both pairs persisted the same two earned IDs, gameplay provenance, achievement, 160 coins and one +40 receipt, and retained the writer's three original PNGs and three decoded 320×180 thumbnails with matching SHA-256. Each reader's profile matches its own writer, including the exact progress hash after the reader exits. Ordinary and devil gameplay cards use the house latest gameplay photo set. The prior four genuine retake pairs remain the evidence for arranged originals; this fix did not rerun that matrix. [800 pair](D:/Snapland-QA/cotton-wind/final-fix/small-read-1119-043621-b9bfb9/pair.json) · [Embedded pair and build](D:/Snapland-QA/cotton-wind/final-fix/embed-export-1119-043647-447431/embedded-acceptance.json)

The embedded executable is 285,996,984 bytes, SHA-256 `51f8ae1fcd3450973e33bc34fc076345f4e73c8cf96516860288397dda727f7c`. The release template SHA-256 is `d34d36f3be1a6c49c56525ae86469b92e4f417ddf0b43cf00dd80c385c4b0562`, debug template `51498b72b3a237f882ebd7d1787f06a4bc1eaf0572daab93837adcfd3cfdc107`. Both executable boots used only the EXE and absolute engine log arguments, without a loose PCK. The two launch runtime graphs match the export runtime graph byte for byte, including the promoted lesson and fixture. Only staged player-entry and Windows export configuration were overridden for the fixture. [Build and runtime hashes](D:/Snapland-QA/cotton-wind/final-fix/embed-export-1119-043647-447431/build.json)

| Final staged changed source | Raw file SHA-256 |
| --- | --- |
| Native Main fixture | `f43bee9feb26166f8aff0e01f94c6b7bf5606f60fe3373fe02ad637d096e2e1c` |
| View | `ae98cadf44ee8e7c11f315cf8d2fdec8134779b3b0e41a1bc85cbcd49239e4b9` |
| Standalone View fixture | `fc67b0deeda49afdcefb29bfafddb9b3f25dae5a58ee630e623734fdc9c329a8` |

The explicit supplemental archive allowlist contains 233 existing files, 13,538,159 bytes. Each entry specifies a unique archive path, existing absolute source, byte length and SHA-256. The allowlist is `df0191e75f87b591abe7c8f7711320e4e4d354016576f22ac2d1f6cc02a6a2f1`. Project tree, imported blobs, templates and executable stay outside the ticket archive. The controller appends the entries under a separate post-fix prefix to the original package and owns the review and Git delivery. This supplemental evidence covers scripted native behavior, with no new human handling, hardware touch or listening assessment. [Supplemental allowlist](C:/Users/stanl/Github/Snapland/.review/cotton-wind-20261118/final-fix/promoted-allowlist.json) · [Receipt hashes and per-pair verification](C:/Users/stanl/Github/Snapland/.review/cotton-wind-20261118/final-fix/run-summary.json)
