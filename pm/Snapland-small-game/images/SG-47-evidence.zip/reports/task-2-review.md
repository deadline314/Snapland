# Task 2 review · aad912f → c6c3f0a

## Spec compliance

**✅ Spec compliant.** The four scripts and three tutorial images in the brief are present. The workbench processes the frozen Model’s actual positions, angles, deposits, airborne strands and tail. The Driver owns input sources and delegates target pursuit to the Model. The capture move is the controller’s documented sequencing change. See `game/minigames/cotton_wind_driver.gd:36`, `game/minigames/cotton_wind_view.gd:420`, `game/tests/test_cotton_wind_view.gd:95` and the plan’s Task 2 capture requirement at line 51.

**⚠️ Deferred verification.** Session pause/resume and reward eligibility through Main, world interaction, lesson pages, packaged saves and retakes belong to Tasks 3–4. This review covers parsed input in the standalone workbench. Physical touch and human play were outside the run. See the plan at lines 54, 60 and 67.

## Strengths

- The physical-key set preserves aliases after a sibling release and restores the surviving direction after opposites cancel. Pointer ownership excludes a second contact and emulated mouse input. The spin latch persists across the release into a drag. Focus loss, hiding and tree exit reach the same cleanup. The 24 Driver routes assert score, eligibility, rejoin count and cleared commands. See `game/minigames/cotton_wind_driver.gd:32`, `:39`, `:79`, `:104`, `game/minigames/cotton_wind_view.gd:66`, `:109` and `game/tests/test_cotton_wind_driver.gd:22`, `:46`, `:86`.
- Player and helper have distinct retained meshes. Each samples its own 36 masses, shares the Model radius function, and rotates about X by its actual angle. Model revisions gate surface updates. The fixed-capacity strand batch and the single tail segment use the supplied world endpoints. The geometry tests inspect vertices, world angles, endpoint transforms and the receiver’s axial limits. See `game/minigames/cotton_wind_view.gd:303`, `:339`, `:386`, `:424` and `game/tests/test_cotton_wind_view.gd:224`, `:252`, `:318`.
- One camera basis drives both the rendered view and inverse drag coordinates. The native fixture compares forward projection and camera-ray intersection at five positions, checks actual label and button bounds, and proves that the independent world is released. Visible rules cover near/far, three-band quality, a rotating opposite-end catch, helper independence and formal participation. See `game/minigames/cotton_wind_view.gd:92`, `:132`, `:181`, `:201`, `:284`, `:476` and `game/tests/test_cotton_wind_view.gd:66`, `:191`, `:353`.
- Reviewed the three 1280×720 raw pixels from the verified capture directory. The first shows uneven accumulation, the second shows three passing bands and the third shows an anchored tail and the highlighted opposite receiver at tension 80. The native fixture captures the states reached by parsed input before confirming 400/500 through the GUI. The root freeze records the same three PNG digests as the native receipt. See `game/tests/test_cotton_wind_view.gd:98`, `:117`, `:138`, `:285` and `.review/cotton-wind-20261118/root/task-2-final-evidence-verification.json:13`.

## Issues

**Critical and important.** None.

**Minor — ordinary native route can exhaust its loop without failing the fixture.** At `game/tests/test_cotton_wind_view.gd:104`, the ordinary score assertion runs only inside the uniform/ended branch. After 1,200 unsuccessful steps the reset at line 112 discards the round. A future native mouse regression could thus skip the uniform capture and the 400-point assertion while this script still exits successfully. Move the ordinary score/eligibility assertion after the loop and before the reset. The current receipts independently contain the uniform frame and score, so this affects future regression detection.

## Evidence and assessment

**Named outside-diff check.** The visible receiver could disagree with Model contact at its inner boundary, outer cap, angular cell or assist margin. Compared `game/minigames/cotton_wind_view.gd:386` and `:435` against the frozen Model at `game/minigames/cotton_wind_model.gd:174`, `:223` and `:261`. The axial clipping, per-cell radius, margins and outward tip agree, within the documented wireframe interpolation.

**Task quality: Approved.** The checked-in workbench has an independently verified Driver run of 62/62 including all 24 routes, native View runs of 69/69 at each of the three required sizes, and a 7/7 headless contract run. Counts and source fingerprints are recorded in `task-2-report.md:59`, `.review/cotton-wind-20261118/root/task-2-freeze.json:2` and `.review/cotton-wind-20261118/root/task-2-final-evidence-verification.json:2`. Review used the frozen diff and existing receipts. No engine process was launched.
