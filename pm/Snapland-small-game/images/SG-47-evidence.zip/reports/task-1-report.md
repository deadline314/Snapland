# SG-47 Task 1 bounded collection model

Status **DONE**. Scope is a deterministic public-API Godot Model test. Controller owns Git and spec. Task 1 base afff21c; controller clarified emission A .12/B .15, target pursuit, and successful-F score bonuses during implementation. No calibration threshold required adjustment.

## Product allowlist and frozen bytes

| File | Bytes | SHA-256 |
|---|---:|---|
| game/minigames/cotton_wind_model.gd | 12057 | 547b4e66a91c41d738c3bcfc7860ae09b596b6083aa1168c0093942a1fb993c7 |
| game/tests/test_cotton_wind.gd | 12135 | 1d4ffddc87c4fa61f3b309618bb063442171a8176cb5ba00fb9f14ad125b260a |
| game/tests/cotton_wind_route.gd | 873 | 1c005e67c5cbe040e8b88d1bed8cbeb95cbaf7a47d51674e21569082bb607027 |

Private launcher and this report are in the task workspace. The launcher stages the tracked project/autoload/JSON closure and exact route/test/model sources on D. No import, export, executable package, full suite, scene, GPU, or human playtest is part of this result.

## TDD and launch evidence

From C:/Users/stanl/Github/Snapland with PYTHONIOENCODING=utf-8, run `python -B .superpowers/sdd/2026-11-18-cotton-wind/task-1-run.py red` before adding Model, or use final argument `green` on the implementation. Each launch allocates its own UUID. Both used the checked-in run_validated_godot and prepare_runtime_stage, with Godot v4.7.2.stable.official.ed1daf0bf. The actual console and backing editor hashes are c8f0a6bc45a19b33541501e57f6f7cd972ab18453743266339d495cbbe846643 and ab1824f85bfd8e0e4128182c000c4003a3e042245b2967848d089b2a04b22424 respectively.

| | RED | Final GREEN |
|---|---|---|
| Absolute run root | D:/Snapland-QA/cotton-wind/task1/red-6e69f85f49d0 | D:/Snapland-QA/cotton-wind/task1/green-607823dff4ef |
| manifest.json SHA-256 | 7ff835cce6f40d3ff592adb7a67191048e8d08450310d69ab28d67047875cf13 | 3455c3cdd0346106553dd48708fa9f5ed6c400b64a105340c38c38a05b1a7256 |
| Exit and marker | 1; Cotton wind model: 1 checks, 1 failures | 0; Cotton wind model: 98 checks, 0 failures |
| Diagnostic | Expected “Cotton wind requires its bounded collection model” | Marker once in stdout and once in engine.log, zero ERROR/leaked/still-in-use |

Exact command for either column, replacing RUN with its full absolute path: `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --path RUN/project --log-file RUN/engine.log --script res://game/tests/test_cotton_wind.gd`. Each manifest records the fully expanded argument vector, engine hashes, staged file byte sizes and hashes, individual script audit and profile mappings. Each run retains project/, stdout.txt, stderr.txt and UTF-8 engine.log. Profiles point to RUN/save/progress.json, RUN/appdata, RUN/local, RUN/temp, RUN/tmp and RUN/captures, with separate empty RUN/export. No player data or other process's stage/cache reused.

Private runner SHA-256 6bb7665ab9df8b04c1f4d986fa5453f4fb516030148fbc76094edde9f32e2ec1; godot_entrypoints.py 7e126f059e6477b586019852967cbea6bc1049380237895427d6a9da188f3ed3; build_desktop_release.py ff5e8c6238b09e839013a2732820dc7d64057dd56f82e37a8094b29d612dce98. Before each process the launcher verifies staged bytes against sources, scans every staged script/config for direct/indirect process-capable calls, disallows unapproved OS APIs and native/dynamic access, and restricts the tests subtree to the two named fixtures. Autoload dependency walk included Localization, Progress, its four explicit core preloads, SteamBridge and its unset achievement callback. The only OS accesses were the Progress argument, environment and userdata reads. The script entry defers its own _run, loads the named model, and the route uses only public methods. No four fault-child parents or helpers thereof, plugin/native extension, engine child request or UID/cache staged. The validated launcher's Windows process-tree termination fallback is bounded and was not needed.

An earlier test parser failure was fixed before verifying the intended missing-model RED. In a later intermediate negative case the chosen outer anchor was too far from center for slack opposite-end contact. Changing only its operation from X=60 to X=40 produced the intended measured pre-threshold contact. Other cases still use X=60.

## Consumer contract

Public methods: reset(assisted: bool = false, variant: int = 0), set_motion(direction: Vector2), move_stick_to(point: Vector2), set_spin(direction: int), finish(), toggle_helper(), clear_input(), step(delta: float), snapshot() -> Dictionary. Model.radius(mass: float) is the shared cell-to-radius function. Position methods accept X/Z. Pursuit and directional input replace one another. Snapshot returns independent recursive copies.

| Snapshot keys | Semantics |
|---|---|
| elapsed, remaining, ended, success, devil, ordinary_eligible, participated, assisted, variant, score, mistakes, feedback | Seconds; frozen end state; F-confirmed success; F-confirmed success with a real rejoin; eligibility after end; participation from actual material, travel and spin; options; score and text |
| stick, angle, omega, travel, spin_travel | World Vector3, local rotation radians, rad/s, accumulated actual linear and angular travel |
| bands, helper_bands | Independent Array of three Array[float] of twelve masses each. Bands run from negative X to positive X. Cell k spans local angle k·TAU/12 through (k+1)·TAU/12. Local/world angles use Y=cos, Z=sin; add the stick angle when rendering |
| quality, uniform, ratio, revision | Three dictionaries {mass, coverage, cv, ready}; physical quality including global ratio; max/min (0 if minimum is zero); monotonic revision across resets and each positive player/helper deposit. Retain both material meshes until revision changes; transform sticks each frame |
| wind, strands | Signed lateral wind velocity; at most 128 dictionaries {previous, position, velocity, age, material, collectible}. Positions/velocity are world Vector3; raw .6 and age-dependent collectible are distinct |
| helper, helper_stick, helper_angle, helper_yielding | Enabled; real world Vector3; angle radians; physically yielding and excluded from collection |
| tail, rejoins | Empty dictionary or {anchor_band, axial, local_angle, anchor, free_end, material, rest_length, length, tension, age, near_break, receiver_band, receiver_margin}; number of actual opposite-end live catches that deposited positive material |
| material | Dictionary {emitted, in_flight, player, helper, hanging, lost} in material units. Whole raw strand leaves in_flight once; cold fraction, overflow and snapped tails enter lost |

Tail anchor/free_end are world Vector3. Axial offset runs along X; local_angle stays attached while stick rotates. Tension equals positive extension. The receiving outer segment spans [-90,-30) or [30,90]; its axial ends are capped. For the free end relative to the receiving stick, use local polar angle atan2(z,y) minus stick angle to choose the surface cell, then Model.radius(mass) + receiver_margin. Ordinary margin is 4; assist margin is 8. The live extension window is [80,140], age below 3 seconds (3.5 assist). The initial wind settings are A 5·sin(1.1t), B 8·sin(1.4t+1.2), assist wind ×.55. Flight decays collectible fraction to clamp(1−.34·age,.15,1). Normal contacts use the local surface radius; assist adds 4.

## Public route measurements

Route.DT = 1/30 and Route.NEAR_Z = 56. Reusable functions are Route.target(snapshot, rejoin) -> Vector2, and Route.solve(model, rejoin) -> Dictionary. After reset, hold set_spin(1); each frame pursue the returned target with move_stick_to, then step(DT). For rejoin first pursue (60,146), then the actual free end's Z and its X minus the opposite outer ±60 center offset. Once rejoined, or immediately for ordinary, cycle X −60, 0, +60 in three-second intervals at Z=56. Confirm only when uniform is physically true and requested rejoin complete. Each route uses zero AI assistance, zero injected material/state, zero mistakes. The 98-check fixture separately verifies actual helper collection/yielding/toggle behavior.

| Variant | Assist | Rejoin | Seconds | Linear travel | Spin rad | Final masses L/M/R | Score |
|---|---|---|---:|---:|---:|---|---:|
| A | off | no | 17.033333 | 421.6117 | 51.1 | 19.0292 / 25.2720 / 20.9498 | 400 |
| A | off | yes | 37.900000 | 1191.8041 | 113.7 | 44.3770 / 47.0307 / 35.2053 | 500 |
| A | on | no | 9.800000 | 277.6117 | 29.4 | 12.0556 / 13.0346 / 12.0573 | 400 |
| A | on | yes | 11.966667 | 473.6825 | 35.9 | 12.7289 / 15.0349 / 12.1904 | 500 |
| B | off | no | 19.033333 | 541.6117 | 57.1 | 18.5550 / 22.8823 / 17.1018 | 400 |
| B | off | yes | 46.800000 | 1410.2139 | 140.4 | 43.3150 / 47.3195 / 35.1898 | 500 |
| B | on | no | 16.900000 | 421.6117 | 50.7 | 14.9739 / 21.8184 / 15.9512 | 400 |
| B | on | yes | 20.833333 | 714.7642 | 62.5 | 19.5242 / 24.2903 / 16.4439 | 500 |

All 24 bands reached 12/12 occupied cells. Full CVs are retained in stdout.txt. Across these runs ordinary routes had zero rejoins and devil routes each had one. Independent 1/120-second public contact probe observed a receive at 2.608333 s, pre-step tail age .716667 s, physical extension 83.135873, receiver axial +30.577614, point-to-axis distance 5.082142, exact transfer .096520000 to the measured cell. Ledger comparisons use absolute tolerance 1e−5, travel checks .001, time/capped spin 1e−7/1e−4.

Self-review covered finite/bounded inputs, clipping/relative swept segments, once-only depots, 3×12 caps, helper isolation and downstream yielding, deep copies, immutable ended state, nonrotating, wrong-band, slack and expired tails, material conservation, successful F and physically uniform/rejoined timeout with ordinary eligibility and 300 (no goal/devil bonuses). No known Task 1 blocker. Driver/UI/Session/native/export acceptance belongs to later tasks.


## Fix round 1 — actual surface polar angle (base f024e27)

The shared player/helper collector now takes Y/Z from strand closest point minus axis closest point and subtracts interpolated stick angle. The corresponding local material cell determines collision radius, regular deposit, and tail's local attachment angle. At a mathematically on-axis contact the previous relative point gives the approach side; a purely axial approach uses +Y. Snapshot keys, public route recipe, geometry convention, coefficient values, and score contract remain as documented above.

The sole additional check lives in game/tests/test_cotton_wind.gd. After a real target move to (0,65) with zero spin and 1/120 s public steps, the first A deposit at t=.875 now goes entirely into the physically intersected middle cell 9. The full 99-check focused suite on the repaired bytes passed; all eight clean routes scored 400/500, in 9.8–46.933333 seconds. The contact probe independently measured extension 83.187833 with .096520000 transferred at 2.608333 s. The route helper was unmodified. All eight updated timings, material values, CVs, spin and actual travel are in the final run below; that set supersedes the original measurements.

The existing isolated runner re-audited each staged closure and copied exact allowlisted bytes before each independent validated launch, with fresh per-process D profiles and logs. Every profile, source hash and script audit is in the corresponding manifest. Both runs used the same exact wrapper/backing engine and launcher hash pair recorded above. No broader launches were made. The new assertion was run first against the frozen model hash, then the shared model was edited.

### RED provenance and complete output

Shell environment PYTHONIOENCODING=utf-8, cwd C:/Users/stanl/Github/Snapland.

`python -B .superpowers/sdd/2026-11-18-cotton-wind/task-1-run.py fix1-red`

`C:\Tools\Godot\Godot_v4.7.2-stable_win64_console.exe --headless --path D:\Snapland-QA\cotton-wind\task1\fix1-red-780c3b2584ce\project --log-file D:\Snapland-QA\cotton-wind\task1\fix1-red-780c3b2584ce\engine.log --script res://game/tests/test_cotton_wind.gd`

Manifest D:/Snapland-QA/cotton-wind/task1/fix1-red-780c3b2584ce/manifest.json SHA-256 `07901fee6abf698bd7f22a66d36fa86192860e0b1b6299e0d36e534f30524010`. Actual engine exit 1.

- game/minigames/cotton_wind_model.gd, 12057 bytes, SHA-256 547b4e66a91c41d738c3bcfc7860ae09b596b6083aa1168c0093942a1fb993c7
- game/tests/test_cotton_wind.gd, 12581 bytes, SHA-256 2831b4082db4ec81af8399e5678ef84a7fa311e3ee080363f7e6e3ca5716cc5b
- game/tests/cotton_wind_route.gd, 873 bytes, SHA-256 1c005e67c5cbe040e8b88d1bed8cbeb95cbaf7a47d51674e21569082bb607027

stdout

```text
Godot Engine v4.7.2.stable.official.ed1daf0bf - https://godotengine.org

COTTON_FIRST elapsed=0.875000 middle8=0.447000000 middle9=0.000000000
COTTON_REJOIN elapsed=2.608333 tail_age=0.716667 tension=83.135873 axial=30.577614 gap=5.082142 material=0.096520000
COTTON_ROUTE variant=0 assist=false rejoin=false elapsed=17.033333 score=400 travel=421.6117 spin=51.1000 bands=[{ "mass": 19.0292, "coverage": 12, "cv": 0.31070783425591, "ready": true }, { "mass": 25.272, "coverage": 12, "cv": 0.23716338553658, "ready": true }, { "mass": 20.9498, "coverage": 12, "cv": 0.32401024927508, "ready": true }] rejoins=0
COTTON_ROUTE variant=0 assist=false rejoin=true elapsed=37.900000 score=500 travel=1191.8041 spin=113.7000 bands=[{ "mass": 44.377, "coverage": 12, "cv": 0.1122430959526, "ready": true }, { "mass": 47.0307, "coverage": 12, "cv": 0.04610814637704, "ready": true }, { "mass": 35.20528, "coverage": 12, "cv": 0.27154423591088, "ready": true }] rejoins=1
COTTON_ROUTE variant=0 assist=true rejoin=false elapsed=9.800000 score=400 travel=277.6117 spin=29.4000 bands=[{ "mass": 12.0556, "coverage": 12, "cv": 0.36674302627048, "ready": true }, { "mass": 13.0346, "coverage": 12, "cv": 0.45257510097952, "ready": true }, { "mass": 12.0573, "coverage": 12, "cv": 0.41632152180434, "ready": true }] rejoins=0
COTTON_ROUTE variant=0 assist=true rejoin=true elapsed=11.966667 score=500 travel=473.6825 spin=35.9000 bands=[{ "mass": 12.72888, "coverage": 12, "cv": 0.35289761344375, "ready": true }, { "mass": 15.0349, "coverage": 12, "cv": 0.39175374084937, "ready": true }, { "mass": 12.19038, "coverage": 12, "cv": 0.45454661937537, "ready": true }] rejoins=1
COTTON_ROUTE variant=1 assist=false rejoin=false elapsed=19.033333 score=400 travel=541.6117 spin=57.1000 bands=[{ "mass": 18.555, "coverage": 12, "cv": 0.44176185018478, "ready": true }, { "mass": 22.8823, "coverage": 12, "cv": 0.41273913218891, "ready": true }, { "mass": 17.1018, "coverage": 12, "cv": 0.27484489751804, "ready": true }] rejoins=0
COTTON_ROUTE variant=1 assist=false rejoin=true elapsed=46.800000 score=500 travel=1410.2139 spin=140.4000 bands=[{ "mass": 43.315, "coverage": 12, "cv": 0.10090876994322, "ready": true }, { "mass": 47.3195, "coverage": 12, "cv": 0.0287680067526, "ready": true }, { "mass": 35.18982, "coverage": 12, "cv": 0.22466675943338, "ready": true }] rejoins=1
COTTON_ROUTE variant=1 assist=true rejoin=false elapsed=16.900000 score=400 travel=421.6117 spin=50.7000 bands=[{ "mass": 14.9739, "coverage": 12, "cv": 0.29660131388118, "ready": true }, { "mass": 21.8184, "coverage": 12, "cv": 0.42790273200136, "ready": true }, { "mass": 15.9512, "coverage": 12, "cv": 0.40072823758434, "ready": true }] rejoins=0
COTTON_ROUTE variant=1 assist=true rejoin=true elapsed=20.833333 score=500 travel=714.7642 spin=62.5000 bands=[{ "mass": 19.52418, "coverage": 12, "cv": 0.33081763361866, "ready": true }, { "mass": 24.2903, "coverage": 12, "cv": 0.50975014347707, "ready": true }, { "mass": 16.4439, "coverage": 12, "cv": 0.26510889493004, "ready": true }] rejoins=1
Cotton wind model: 99 checks, 1 failures
```

stderr

```text
ERROR: First offset contact must deposit on middle radial cell 9; cell 8 remains empty
   at: push_error (core/variant/variant_utility.cpp:1023)
   GDScript backtrace (most recent call first):
       [0] expect (res://game/tests/test_cotton_wind.gd:12)
       [1] _material (res://game/tests/test_cotton_wind.gd:135)
       [2] _run (res://game/tests/test_cotton_wind.gd:24)
```
### GREEN provenance and complete output

Shell environment PYTHONIOENCODING=utf-8, cwd C:/Users/stanl/Github/Snapland.

`python -B .superpowers/sdd/2026-11-18-cotton-wind/task-1-run.py fix1-green`

`C:\Tools\Godot\Godot_v4.7.2-stable_win64_console.exe --headless --path D:\Snapland-QA\cotton-wind\task1\fix1-green-f485bcff6bb2\project --log-file D:\Snapland-QA\cotton-wind\task1\fix1-green-f485bcff6bb2\engine.log --script res://game/tests/test_cotton_wind.gd`

Manifest D:/Snapland-QA/cotton-wind/task1/fix1-green-f485bcff6bb2/manifest.json SHA-256 `ab545a225e345dd2bcf154e3d609625e751d9a0a115a36d3d8bf217126a8d7fc`. Actual engine exit 0.

- game/minigames/cotton_wind_model.gd, 12209 bytes, SHA-256 bea36ef93e1aee775ccad0c0dbab99bec014e9c1862bd5bddd7e7389a107ea54
- game/tests/test_cotton_wind.gd, 12581 bytes, SHA-256 2831b4082db4ec81af8399e5678ef84a7fa311e3ee080363f7e6e3ca5716cc5b
- game/tests/cotton_wind_route.gd, 873 bytes, SHA-256 1c005e67c5cbe040e8b88d1bed8cbeb95cbaf7a47d51674e21569082bb607027

stdout

```text
Godot Engine v4.7.2.stable.official.ed1daf0bf - https://godotengine.org

COTTON_FIRST elapsed=0.875000 middle8=0.000000000 middle9=0.447000000
COTTON_REJOIN elapsed=2.608333 tail_age=0.716667 tension=83.187833 axial=30.577614 gap=5.082142 material=0.096520000
COTTON_ROUTE variant=0 assist=false rejoin=false elapsed=17.033333 score=400 travel=421.6117 spin=51.1000 bands=[{ "mass": 19.0292, "coverage": 12, "cv": 0.31070783425591, "ready": true }, { "mass": 25.2771, "coverage": 12, "cv": 0.286698025204, "ready": true }, { "mass": 20.9498, "coverage": 12, "cv": 0.30386041686228, "ready": true }] rejoins=0
COTTON_ROUTE variant=0 assist=false rejoin=true elapsed=30.366667 score=500 travel=991.8041 spin=91.1000 bands=[{ "mass": 35.32568, "coverage": 12, "cv": 0.17581865132733, "ready": true }, { "mass": 41.2931, "coverage": 12, "cv": 0.19391874116136, "ready": true }, { "mass": 30.6563, "coverage": 12, "cv": 0.26655428462434, "ready": true }] rejoins=1
COTTON_ROUTE variant=0 assist=true rejoin=false elapsed=9.800000 score=400 travel=277.6117 spin=29.4000 bands=[{ "mass": 12.0607, "coverage": 12, "cv": 0.46123302425621, "ready": true }, { "mass": 13.0312, "coverage": 12, "cv": 0.41367377831374, "ready": true }, { "mass": 12.0641, "coverage": 12, "cv": 0.50209917919634, "ready": true }] rejoins=0
COTTON_ROUTE variant=0 assist=true rejoin=true elapsed=11.866667 score=500 travel=473.6825 spin=35.6000 bands=[{ "mass": 12.73398, "coverage": 12, "cv": 0.44122305130675, "ready": true }, { "mass": 15.0468, "coverage": 12, "cv": 0.53549937960154, "ready": true }, { "mass": 13.99692, "coverage": 12, "cv": 0.79054723089098, "ready": true }] rejoins=1
COTTON_ROUTE variant=1 assist=false rejoin=false elapsed=19.033333 score=400 travel=541.6117 spin=57.1000 bands=[{ "mass": 18.5499, "coverage": 12, "cv": 0.38319202760635, "ready": true }, { "mass": 22.8806, "coverage": 12, "cv": 0.39933884043623, "ready": true }, { "mass": 17.1103, "coverage": 12, "cv": 0.41258956394819, "ready": true }] rejoins=0
COTTON_ROUTE variant=1 assist=false rejoin=true elapsed=46.933333 score=500 travel=1410.2139 spin=140.8000 bands=[{ "mass": 43.315, "coverage": 12, "cv": 0.10090876994322, "ready": true }, { "mass": 46.8402, "coverage": 12, "cv": 0.04906153895703, "ready": true }, { "mass": 34.87102, "coverage": 12, "cv": 0.24905020429831, "ready": true }] rejoins=1
COTTON_ROUTE variant=1 assist=true rejoin=false elapsed=16.933333 score=400 travel=421.6117 spin=50.8000 bands=[{ "mass": 14.9773, "coverage": 12, "cv": 0.37296152136869, "ready": true }, { "mass": 21.815, "coverage": 12, "cv": 0.39918363055355, "ready": true }, { "mass": 15.958, "coverage": 12, "cv": 0.47744772156676, "ready": true }] rejoins=0
COTTON_ROUTE variant=1 assist=true rejoin=true elapsed=20.233333 score=500 travel=714.7642 spin=60.7000 bands=[{ "mass": 19.52418, "coverage": 12, "cv": 0.37441791089329, "ready": true }, { "mass": 24.2852, "coverage": 12, "cv": 0.333715589922, "ready": true }, { "mass": 16.3928, "coverage": 12, "cv": 0.5913512913441, "ready": true }] rejoins=1
Cotton wind model: 99 checks, 0 failures
```

stderr

(empty)
