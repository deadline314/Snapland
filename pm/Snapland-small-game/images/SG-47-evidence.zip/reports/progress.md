# SDD ledger — plan: docs/superpowers/plans/2026-11-18-cotton-wind.md

Branch codex/cotton-wind-20261118. Base main 382194dd8a7c9a1d425f1caec5c58044c988da7a, opening 2a7de62. Authority design/runtime/cotton-wind-gameplay.md. Root owns all Git mutations. No implementation dispatched yet.

Ruling: Continue the established in-place feature-branch workspace with tracked files clean at baseline — user authorizes continuous delivery and cleanup, previous tickets used this checkout — no second worktree/caches or relocation of preexisting untracked assets. Engine work is isolated on D, never player save.
Ruling: User authorization for ticket creation, commits, pushes, rebases, main merges and delivered branch cleanup remains in force — no skill confirmation gate repeats it — only remove owned fully delivered branches.
Ruling: Use gpt-6.2-sol high for standard production/scoped reviews and gpt-6.2-astra high for complex model design/final broad review — SDD explicitly requires model selection and delegation; no descendant agents.

## Preflight conflict scan

| Pair / task | Produces → consumes / internal consistency | Finding and ruling |
|---|---|---|
| 1→2 | public Model/snapshot/routes → Driver/View | Task1 must freeze named fields and pursuit semantics before2; no2 rule tweaks. |
| 1→3 | participation/score/endings → Session | Ordinary participation and uniform success distinct in authority;3 copies both accurately. |
| 1→4 | public solution recipe → real input | Native may translate recipe into real events only; no state injection. |
| 2→3 | Driver and projection → Session | House signatures, native GUI focus and clear_input must match;3 no renderer rewrite. |
| 2→4 | actual projection/resources and inputs → captures | Three-size render checks belong2, final full native proof4; reuse immutable passed same-source evidence, no broad repeated suites. |
| 3→4 | lessons/assets and retake plumbing → tutorial frames/package | Three final raw tutorial images supplied4, lesson text may be integrated3 using placeholder paths without fabricated PNG.3 validators that need missing finalfiles explicitly defer to4, cannot claim pass. |
| Task1 | RED→puremodel→eightrecipes | Initial kinematics require calibration; infeasibility goes to root with measurements, no silent coefficient changes. |
| Task2 | RED→input+3D→24routes | Pointer move is bounded target pursuit; latch spin survives ordinary pointer release, cancellation clears it. |
| Task3 | integration→contracts | Scope list includes only impacted029callers/counts. Legacy four excludedparent suites remain CI-only. |
| Task4 | actualnative/retake→embedded→freeze | Exact code frozen before tests; later fixes invalidate only affected evidence and must be explicitly reverified. |

Task1: pending; BASE will be recorded after plan commit. Tasks2–4 pending.

Task1: running — BASE afff21c, producer /root/cotton_model (gpt-6.2-astra high), report task-1-report.md. Opening/plan pushed; games+links baseline PASS. SG46 exact main382 CI44253051210 all6SUCCESS; owned branch local/remote deleted.

Ruling: Clarify A emission interval .12s and B .15s — authority requested distinct bundle spacing but originally named one interval — preserves bounded capacity and gameplay, initial calibration still subject to measured route proof. Producer notified before freeze. Baseline runtime result contracts23/23 PASS.

Ruling: Model owns bounded pointer target pursuit — remove ambiguous immediate-position wording; move_stick_to sets target only, step pursues120units/sec, set_motion switches control and clear_input drops target — one kinematics implementation protects material conservation and all consumers. Producer notified. Baseline GameTests18/18 PASS.

Task1 interim: producer measured all8routes9.80–39.27s with400/500 and no coefficient changes. Final collision interpolation/negative checks pending.
Ruling: Goal100 requires actual successful F — authority deadline cannot claim success, house scoring tied to goals — physically uniform unconfirmed deadline yields band300 only, success/devilfalse and honest participation eligibility. Producer adds focused regression; initial material/quality thresholds unchanged.

Ruling: Add game/core/game_catalog.gd and tools/verify_design.py to Task3 explicit ownership — existing house catalog/validator each fix candy count at5 — necessary callers for sixgame integration, no new behavior beyond count contracts. Task3 brief not yet extracted/dispatched.

Task1: frozen f024e27, scope3files, 98/0 exactGodot4.7.2, 8publicroutes9.80–46.80s400/500, no coefficient changes. Root22stage+workinghashes/engine/markers/stderr independently verified; proof .review/cotton-wind-20261118/root/task-1-source-hashes.json, rawred/green paths and manifests in task-1-report.md. Fresh reviewer /root/cotton_model_review gpt-6.2-astra high, diff review-afff21c..f024e27.diff; verdict pending. Tasks2–4 not started.

Task1 review: specFAIL / qualityNeedsfixes,1Important regularcollector selects angular cell from flight rather than actualradialcontact. Fixround1/5 assigned originalproducer /root/cotton_model; FIX_BASEf024e27. New firstdeposit cell9-vs8 regression plus eightpublicroutes required. Cannotverify1(UI/sourceownership/render/layout/tutorial/Session/catalog/export) explicitly assignedTask2–4 gates, not Task1 gaps. Cannotverify2(externalruntimeaudit/hashes) rootverified22sources+engine/logs; changedgeometry requires fresh focusedrun, assignedround1. No Minor/deferred findings.

Task1: fix round1/5 (1 addressed,0open — actualradialcontact selects radius/cell/deposit/anchor; commitsf024e27..aad912f). Scopedrereview task-1-rereview-1.md Approved, no newbreakage/outofscope. Cannotverifylogs/hashes rootalreadyverified; downstreamTasks2–4remainrequired.
Task1: complete (commits afff21c..aad912f, review clean).
Task2: running — BASE aad912f, producer /root/cotton_view_driver (gpt-6.2-sol high), frozenconsumercontract in task-1-report.md + task-2-handoff.md; Model/rules unchanged.

Ruling: Supply3realnativeworkbench tutorial PNGs inTask2 beforeTask3 integration — missing lesson assets could prevent meaningful TutorialCatalog/Main checks; avoid fake interim images or knowingly incomplete validation. Task2 actualfocusedGUI Input.parse_input_event+normalDriver.step on standaloneworkbench is genuine native operation without030stateinjection; Task4 verifies inMain and may replace onlyifclearer. Exact3assetfiles addedTask2 ownership, no extra productfeature/framework. Preflight2→3 now suppliesrealassetdependency;3→4 verifiesfinalMain. Producer notified andbrief regenerated.

Task2: frozen c6c3f0a (7productfiles1245lines+3rawPNGs), basedaad912f. Driver62/0 and24routes400/500; VulkanView69/0each1280/1152/800UI1.25reduced; headlessView7/0 actualCIstaticcontract. Root independentlyverified5finalruns allsource/receipt/rawhashes,all7producthashes,3rawassetcopies; rawframes visuallyinspected. Rootproofs task-2-final-evidence-verification.json and task-2-freeze.json in .review/.../root/. Earlierqualityoverlap/footer3px and89vs90buttonmin correctedbeforefreeze; geometryyaw10degsharedprojection. Freshreview /root/cotton_view_review gpt-6.2-astra high (dynamicgeometry/ownershiprisk), review-aad912f..c6c3f0a.diff; reporttask-2-review.md pending. Task3notdispatched.

Task2: complete (commits aad912f..c6c3f0a, review clean;1nonblockingMinorrecorded). Freshreport task-2-review.md speccompliant/Approved. Cannotverify Session/Main/world/lessons/retake/package assignedTask3–4; physicaltouch/humanplay excluded honestly. Existing5runs/hashproof independentlyverified.
Task2: minor (deferred): game/tests/test_cotton_wind_view.gd:104 ordinarynative loop can exhaust1200iterations thenresetwithout unconditional400/eligibility assertion; actualaccepted3size receipts containuniformframe+400 so currentrunverified. Carrytofinalwholebranchreview+unifiedfixwave, no controllerproductfix/extraTask2loop. Task4 newnativefixtures mustassertcompletionunconditionallyafterloops.
Task3: running — BASEc6c3f0a, producer /root/cotton_integration gpt-6.2-sol high;3realteachingPNGssuppliedTask2; reporttask-3-report.md pending.

Ruling: Task3 additionally owns game/ui/retake_panel.gd + game/tests/test_retake_panel.gd — fixed game030 prop mapping required by existinghouse retake contract, omittedfromexplicitmap — reusecurrentpropvocabulary no newscene/assetframework. Mechanical globalcount maintenance in affected oldnative_chocolate_etching_main/native_jelly_trampoline_main allowed, nooldnative runs/identitychanges. Producerrequestedandnotified; no consumerproductscope expansion.

Task3 producer resumed after usage interruption, final DONE. Main corrected test feet vs body origin and regional book count; true floor y=.2 / collider feet y=.200061 / nearest/E game030. All 34 product hashes confirmed and integration frozen/pushed e48caab. Godot99/62/7/98/70 and24 Session routes; catalog/world4341/retake/participation/tutorial/paged/oldChocolateMain green; 71 Python; games/links. Root raw artifact audit .review/cotton-wind-20261118/root/task-3-evidence.json, exact Main green and earlier unused-main/copy drift documented. Fresh /root/cotton_integration_review gpt-6.2-astra high dispatched via packaged c6c3f0a..e48caab diff; gate pending. Private Task4 launcher .review/cotton-wind-20261118/root/native_run.py statically compiled only; Task4 fresh stage/native not started.

Task3: complete (c6c3f0a..e48caab, spec PASS + quality approved, no blocking findings). Private task-3-review.md. Report precision warmup warnings: 12 StandardMaterial3D + 33 ShaderMaterial, retained raw unchanged; no application fix. Task4 producer /root/cotton_native gpt-6.2-sol high started on e48caab; no prior product writes; root launcher prepared and described in handoff.

CI on e48caab 44386030617 shard3 caught stale album selector expectation [18,12,5]. Root CI maintenance changed only last test literal to6 in excluded test_region_travel.gd, 51 Python runtime contracts passed, pushed 9fc1f78; rerun exact commit via CI required. Native closure unaffected. First strict 1280 writer candidate C passed, root visually inspected actual E prompt/nearbreak/catch+updatedHUD/500result from native-first-writer-visual.json; remaining pairs pending.

Task4 frozen fixture 1ca72ff, pushed. Native producer DONE: 8 pairs, 16 clean launches, 5970 checks in pre-teardown stdout counts (6166 including checks generated while assembling receipts/teardown, detailed in report), 3 sizes/4 GPUretakes/1 embedded. Controller independently verified all 16 receipts/staged raw file hashes/captures, same writer/reader save and fresh per-process absolute profiles, fixture/control raw hashes, pinned binary/templates. .review/cotton-wind-20261118/root/task-4-pair-verification.json. Embedded initial writer verifier assumed empty stdout; raw exit0 and both streams have one marker, supplemental accepted-receipt preserved alongside raw, fresh actual reader on same EXE passed, verified independent. Task4 producer report + 329file rawallowlist. Fresh /root/cotton_native_review scoped gate pending.

Task4: complete (9fc1f78..1ca72ff, spec compliant, quality approved, no Critical/Important). Fresh task-4-review.md independently rehashed 329 promoted files, 981 export runtime files, 1122 asset imports, EXE/templates/logs, decoded 4 shutter original pixel pairs and compared 8 exact restart profiles. Deferred Minor for actual zoom readability of the compact/ellipsis caption at 800; all 5 lesson semantic fields already visible. Also minor reporting precision: stored engine log and decoded/recaptured UTF-8 stdout/stderr, not untouched process bytes. Carry to final review and one fix wave.

Final whole-branch review 382194d..1ca72ff complete; With fixes (0C/1I/4M), final-review.md. Unified producer /root/cotton_final_fix gpt-6.2-astra high, FIX_BASE1ca72ff. Important native QA writer stale save/captures fail-open; prove refusal/preservation on disposable D sidecars. Minor empty band misleading ratio0; bounded ordinary native test assertion; compact full caption actual zoom focus proof at 800; decoded stdout/stderr terminology. No reruns of unaltered broad matrix, preserve receipt/source before fix. Autoload legacy migration before fixture guards explicitly inspected and producer asked for minimal scoped solution ruling if necessary. Expect actual post-fix raw partial/zoom screenshots.

Final unified wave 1ca72ff..9a15daf: all5 addressed, no new findings, Ready to merge YES, final-rereview-1.md. Private sentinel guarded native destinations + 9 pre-exec checks, early safe failure, immutable current/schema sentinel bytes. Production Progress startup migration untouched. Empty band hint and exactly copied raw lesson01; unconditional ordinary result; 800 actual 3 zoom captions/focus; stream provenance corrected. Post-fix source Git match 981 across all4 supplemental passes; 71 nativeView,800 writer1279 reader38, new embedded writer1116 reader38, all zero failures. Agent and controller separately verified raw bytes, 233-file allowlist and EXE. Declined items human/physical/art/listening/otherhardware/manual admission/info/WIP variants beyond scope; main CI/delivery controller still gating.
