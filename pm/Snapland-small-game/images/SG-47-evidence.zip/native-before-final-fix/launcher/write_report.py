from pathlib import Path
from collections import Counter
import re
import sys

from evidence import BASE, ENGINE_HASH, EDITOR_HASH, HERE, MARKER, ROOT, TASK, describe, read, save_json, verify
from continue_matrix import DONOR, PLAN, passed

ORDINARY = "photo-candy-game-6"
DEVIL = "photo-candy-devil-6"
EXCLUDED = ["test_photo_retake_main", "test_region_travel", "test_photo_retake_progress", "test_region_progress"]
IDENTITY = HERE / "source-identity-041105.json"
REPORT = ROOT / ".superpowers/sdd/2026-11-18-cotton-wind/task-4-report.md"

def markdown(path):
    file = Path(path)
    return f"[{file.name}]({file.as_posix()})"

def table(headers, rows):
    yield "| " + " | ".join(headers) + " |"
    yield "| " + " | ".join("---" for _ in headers) + " |"
    for row in rows:
        yield "| " + " | ".join(str(cell) for cell in row) + " |"

def pair_receipts(label, purpose):
    completion, = passed(label, purpose)
    proof = read(completion)
    for description in proof["launches" if purpose == "embedded" else "runs"]:
        verify(description)
        yield Path(description["path"])

def verify_receipt(receipt_path, identity):
    directory = receipt_path.parent
    receipt = read(receipt_path)
    assert receipt["passed"] and receipt["exit_code"] == 0 and not receipt["errors"] and not receipt["leak_diagnostics"]
    assert receipt["engine"]["sha256"] == ENGINE_HASH and receipt["editor_sibling"]["sha256"] == EDITOR_HASH
    for entry in receipt["logs"] + receipt["capture_outputs"] + [receipt["audit"], receipt["runtime_graph"], receipt["source_graph"]]:
        verify(entry)
    audit = read(receipt["audit"]["path"])
    assert not audit["child_launch_candidates"] and audit["excluded_fault_parents"] == EXCLUDED
    manifest = read(receipt["source_graph"]["path"])
    assert manifest["source_raw_sha256"] == identity
    effective = read(receipt["runtime_graph"]["path"])
    assert all(effective[name] == identity[name] for name in identity if name not in {"project.godot", "export_presets.cfg"})
    assert audit["fixture_closure"] == manifest["fixtures"]
    assert all(not any(fault in file for fault in EXCLUDED) for file in audit["fixture_closure"])
    native = receipt["kind"] in {"suite", "read", "retake-ordinary", "retake-devil"}
    data = None
    if native:
        assert receipt["marker"] == MARKER
        expected_markers = [1, 1, 0]
        assert receipt["marker_counts_engine_stdout_stderr"] == expected_markers
        names = ["engine.log", "stdout.log", "stderr.log"]
        assert [(directory / log).read_text(encoding="utf-8-sig").splitlines().count(MARKER) for log in names] == expected_markers
        data = read(directory / "captures/cotton-evidence.json")
        assert not data["failures"] and not read(directory / "captures/report.json")["failures"]
        assert data["ui_scale"] == 1.25 and data["reduced_motion"]
        profile = data["profile"]
        assert profile["coins"] == 160 and profile["reward_receipts"] == 1 and profile["achievement"] and profile["attempted"] and profile["lesson_seen"]
        for paths in profile["hashes"].values():
            for file, hash in paths.items():
                assert describe(file)["sha256"] == hash, file
    return receipt, data

def report():
    proof = read(IDENTITY)
    identity = {name: entry["raw_sha256"] for name, entry in proof["files"].items()}
    all_pairs = [("cotton-c-1280", "suite", "1280x720"), *PLAN]
    archive = []
    seen = set()
    def add(file, location):
        entry = describe(file)
        if entry["sha256"] not in seen:
            seen.add(entry["sha256"])
            archive.append({"archive_path": location, **entry})

    for rel in ["game/tests/native_cotton_wind_main.gd", "game/tests/native_cotton_wind_main.tscn",
                "game/tests/native_sugar_bridge_main.gd", "game/tests/cotton_wind_route.gd", "game/tests/audio_playback_release.gd"]:
        assert describe(ROOT / rel)["sha256"] == identity[rel]
        add(ROOT / rel, "fixture/" + Path(rel).name)
    add(IDENTITY, "fixture/source-identity.json")
    for rel in ("native_run.py", "native_run_console.py", "resume_embedded.py", "continue_matrix.py", "evidence.py", Path(__file__).name):
        add(HERE / rel, "launcher/" + rel)
    add(HERE.parent / "root/native_run.py", "launcher/initial-bootstrap.py")
    for step in range(1, 4):
        rel = f"assets/ui/tutorials/game-030-step-{step:02}.png"
        assert describe(ROOT / rel)["sha256"] == identity[rel]
        add(ROOT / rel, f"tutorial/{Path(rel).name}")

    receipt_rows = []
    route_rows = []
    retake_rows = []
    layout_rows = []
    total = 0

    def archive_receipt(directory, slot, png_selector=lambda name: True):
        for name in ("receipt.json", "accepted-receipt.json", "prelaunch-audit.json", "source-graph.json", "runtime-graph.json",
                     "engine.log", "stdout.log", "stderr.log", "asset-import-reuse.json", "asset-import-files.json"):
            path = directory / name
            if path.is_file():
                add(path, f"runs/{slot}/{name}")
        for item in sorted((directory / "captures").glob("*")):
            if item.suffix == ".json" or png_selector(item.name):
                add(item, f"runs/{slot}/captures/{item.name}")

    for label, kind, width in all_pairs:
        writer_path, reader_path = pair_receipts(label, kind)
        writer, write = verify_receipt(writer_path, identity)
        reader, reread = verify_receipt(reader_path, identity)
        w_profile = writer["environment"]
        r_profile = reader["environment"]
        assert r_profile["SNAPLAND_SAVE_PATH"] == w_profile["SNAPLAND_SAVE_PATH"]
        assert writer["stage"] != reader["stage"] and writer["release_directory"] == reader["release_directory"]
        assert all(r_profile[key] != w_profile[key] for key in ("APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "COTTON_CAPTURE_DIR", "SNAPLAND_QA_EXPORT_DIR"))
        assert write["profile"] == reread["profile"] and write["viewport"] == reread["viewport"]
        assert "x".join(str(x) for x in write["viewport"]) == width
        actual = read(Path(w_profile["SNAPLAND_SAVE_PATH"]).parent / "native-originals.json")
        assert actual["profile"] == write["profile"] and actual["mode"] == write["mode"]
        checks = [write["checks"] + 2, reread["checks"] + 2]
        total += sum(checks)
        flag = f"EXE {width}" if kind == "embedded" else f"{width} {kind}"
        writer_evidence = writer_path.parent / "captures/cotton-evidence.json"
        reader_evidence = reader_path.parent / "captures/cotton-evidence.json"
        receipt_rows.append([flag, f"{checks[0]} / {checks[1]}", f'{writer["wall_seconds"]:.2f} / {reader["wall_seconds"]:.2f}',
                             markdown(writer_path) + " · " + markdown(writer_evidence), markdown(reader_path) + " · " + markdown(reader_evidence)])
        for r in write["routes"]:
            assert r["score"] == (500 if r["rejoins"] else 400)
            assert abs(r["simulated_seconds"] - r["session_elapsed"]) < 1e-7
            quality = " / ".join(f'{q["mass"]:.2f}' for q in r["quality"])
            assert all(q["ready"] and q["coverage"] == 12 for q in r["quality"])
            route_rows.append([flag, r["label"], r["source"], "AB"[r["variant"]], r["score"], r["rejoins"],
                               f'{r["simulated_seconds"]:.3f} / {r["wall_seconds"]:.3f}', quality])
        if write["mode"] == "suite":
            assert [r["label"] for r in write["routes"]] == ["ordinary", "rejoin", "practice"]
            controls = [row for row in write["layouts"] if "controls" in row]
            assert controls and all(len(row["controls"]) == 8 for row in controls)
            leaves = [leaf for row in write["layouts"] for leaf in row.get("leaves", [])]
            assert leaves and all(leaf["bounds_fit"] and leaf["text_fits"] for leaf in leaves)
            rule_pages = sum(row["capture"].startswith("rules-") for row in write["layouts"])
            assert rule_pages == 7
            groups = Counter(Path(row["image"]).name for row in write["lessons"])
            assert sum(len(row["semantic_indices"]) for row in write["lessons"]) == 15 and len(groups) == 3
            near, far = write["near_far"]["near"], write["near_far"]["far"]
            assert near["variant"] == far["variant"] and near["mass"] > far["mass"] > 0
            rejoin = write["routes"][1]
            assert rejoin["near_break"]["tension"] >= 80 and rejoin["catch"]["receiver_band"] == 2 - rejoin["catch"]["anchor_band"]
            layout_rows.append([flag, rule_pages, " / ".join(str(groups[name]) for name in sorted(groups)), len(controls), len(leaves),
                                f'{near["mass"]:.5f} / {far["mass"]:.5f}',
                                f'{rejoin["near_break"]["tension"]:.5f}',
                                f'{rejoin["catch"]["anchor_band"] + 1} → {rejoin["catch"]["receiver_band"] + 1}'])
        else:
            shot = write["retake"]
            target = DEVIL if kind == "retake-devil" else ORDINARY
            assert shot["target"] == target and shot["equal_original_pixels"] and shot["initial"]["acquisition_method"] == "retake"
            assert not shot["initial"]["challenge_earned"] and shot["after_challenge"]["acquisition_method"] == "retake"
            assert shot["after_challenge"]["challenge_earned"] == (target == DEVIL)
            original, = shot["initial"]["original_frames"]
            thumb, = shot["initial"]["frames"]
            assert original in shot["after_challenge"]["original_frames"] and thumb in shot["after_challenge"]["frames"]
            assert describe(original)["sha256"] == shot["files"][original] and describe(thumb)["sha256"] == shot["files"][thumb]
            retake_rows.append([flag, target, markdown(shot["gpu_capture"]), f'{markdown(original)} `{shot["files"][original]}`',
                                f'{markdown(thumb)} `{shot["files"][thumb]}`', str(shot["after_challenge"]["challenge_earned"])])
            add(original, f"runs/{label}/saved/retake-original.png")
            add(thumb, f"runs/{label}/saved/retake-thumbnail.png")
        add(Path(w_profile["SNAPLAND_SAVE_PATH"]).parent / "native-originals.json", f"runs/{label}/writer-profile.json")
        for id, paths in write["profile"]["hashes"].items():
            for saved in paths:
                add(saved, f"runs/{label}/saved/{Path(saved).name}")
        archive_receipt(writer_path.parent, label + "/writer",
            lambda name: kind != "embedded" or name in ["factory-entrance.png", "ordinary-ready.png", "rejoin-near-break.png",
                                                      "rejoin-opposite-catch.png", "rejoin-result.png", "achievement-book.png"])
        archive_receipt(reader_path.parent, label + "/reader")
        completion, = passed(label, kind)
        add(completion, f"runs/{label}/{completion.name}")

    export_summary, = passed("cotton-embed", "embedded")
    export = export_summary.parent
    build = read(export / "build.json")
    verify(build["binary"])
    verify(build["source"])
    verify(build["export"])
    verify(build["normal_main"])
    verify(build["normal_export"])
    verify(read(export_summary)["writer_initial_receipt"])
    for entry in build["templates"].values():
        verify(entry)
    assert all(Path(row).suffix != ".pck" for row in (export / "release").iterdir())
    export_l, _ = verify_receipt(export / "receipt.json", identity)
    assert export_l["kind"] == "export" and export_l["release_directory"] is None
    assert build["runtime_sha256"] == read(export / "runtime-graph.json")
    packed = set(re.findall(r"res://(game/tests/[^\s]+\.remap)", (export / "engine.log").read_text(encoding="utf-8-sig")))
    assert {path.removesuffix(".remap") for path in packed} == set(read(export / "source-graph.json")["fixtures"])
    archive_receipt(export, "cotton-embed/export")
    add(export / "build.json", "runs/cotton-embed/export/build.json")
    for directory in (DONOR, TASK / "cotton-a-version-1119-040633-0cfabf"):
        verify_receipt(directory / "receipt.json", read(directory / "source-graph.json")["source_raw_sha256"])
        archive_receipt(directory, directory.name)
    candidates = []
    for directory in sorted(TASK.iterdir()):
        path = directory / "receipt.json"
        if path.is_file() and not read(path)["passed"]:
            failures = read(path)["errors"]
            if (directory / "accepted-receipt.json").is_file():
                diagnostic = "Exit 0, clean logs and one exact marker in each actual stream. The launcher expected empty GUI stdout. " + markdown(directory / "accepted-receipt.json")
            else:
                diagnostic = " · ".join(failures)
            candidates.append((directory.name, markdown(path), diagnostic))
    assert len({item["archive_path"] for item in archive}) == len(archive)
    archive_path = HERE / "promoted-allowlist.json"
    save_json(archive_path, {"base": BASE, "canonical_source": describe(IDENTITY), "files": archive})
    lines = [
        "# SG-47 Task 4 native input, GPU retakes and embedded Windows evidence", "",
        f"**DONE.** Eight writer/reader pairs and one fresh embedded Windows export passed. The native fixture performed {total} checks across 16 native process launches, including the evidence-write and teardown checks. The game's fixed identity is `game-030` / `cotton_wind` / candy slot six, with `{ORDINARY}`, `{DEVIL}` and `ACH_GAME_030`. Factory availability is 6/12 and the delivered catalog is 30.", "",
        "## Native acceptance and receipts", "",
        "Each desktop pair used a genuinely rendered Main, focused GUI and `Input.parse_input_event` for keyboard, mouse and scripted screen touch. Writers seeded only six welcome admission cards and opening-seen flags, used 1.25 text scale and reduced motion at all three viewport sizes, and labeled the controlled factory placement at (6.5, GROUND_Y, 10). Actual E opened the invitation. The map's sixth factory entry, tutorial controls, result actions, pause/retry/leave, album observations and achievement stamp used the visible UI. The factory sign capture was taken near the separate sign. The entrance frame and invitation establish the 030 interaction.", "",
        "The fixture invokes the regular Session process with bounded 1/120-second keyboard or 1/30-second pointer deltas after disabling only automatic per-frame Session scheduling for repeatability. Other scene frames remain live for GUI and graphics. A QA-only HUD refresh displays the actual latest summary inside the normal refresh interval. The fixture never sets Cotton material, geometry, clock state, score, photo records or rewards. Native scripted touch does not establish operation on physical touch hardware. No play, walk, fresh-file admission, listening, or art acceptance is inferred.", "",
        *table(["Pair", "Checks W/R", "Process wall seconds W/R", "Writer", "New reader"], receipt_rows), "",
        "Every accepted native process exited 0, and its UTF-8 logs contain zero ERROR and zero genuine ObjectDB/resource/RID leak diagnostics. The exact marker appeared once in the engine log and once in stdout for both the scene and EXE launches. Stderr carries no marker. The preserved process logs and SHA-256 receipts retain both raw streams and their warnings. Check totals add the final evidence JSON write and audio-backend release checks to the counts in the evidence JSON. The earlier stdout count precedes the last profile file checks.", "",
        "## Actual routes and bounds", "",
        "Keyboard produced the ordinary 400. A mouse route produced natural 500 and visualized both real near-break and catch. The single-finger scripted event route reached 500 in practice, then a separate participated practice run paused and cancelled without a result. Practice/cancel left photos, original and thumbnail hashes, achievement and coins identical. Every bounded gameplay loop required the expected completion and score. The optional touch replay can cross and catch inside one 1/30 sample, while the native formal route visibly proves the near-break window.", "",
        *table(["Pair", "Route", "Device events", "Wind", "Score", "Rejoins", "Simulated / route wall s", "Final band masses"], route_rows), "",
        *table(["Pair", "Rules", "Lesson pages by step", "Workbench layouts × eight controls", "Measured text/control leaves", "Near / far first deposited mass", "Near-break tension", "Anchor → receiver"], layout_rows), "",
        "The captured JSON enumerates each visible leaf's actual text, transformed rectangle, ancestor clipping rectangle, and font/count fit. It records all eight control texts and measured hit bounds at each board checkpoint. For each actual lesson page it records the current texture path, measured image bounds, ancestor clip, actual visible copy and semantic indices. All three Task 2 tutorial assets remain the exact raw native standalone captures. They show uneven collected strands, a genuinely uniform ready workpiece, and the near-break free-end setup. Main embeds the same images across the measured pages.", "",
        "## Shutter originals, thumbnail decode and restart", "",
        f"The selected practice returned through actual pause/leave to the matching set without a reward. Decoration, framing and distance all changed through the UI. Each real shutter emitted one GPU image. Its pixels equaled the arranged 1280×720 preview and the saved original after comparing both decoded images in RGBA8. A genuine matching subsequent challenge preserved the selected retake method, frame paths and exact original/thumbnail SHA-256. A devil retake starts with only the selected card and no challenge proof. Real later play adds the ordinary card independently and attaches challenge proof to the preserved devil retake. Ordinary challenge after ordinary retake does not award the devil card.", "",
        *table(["Pair", "Selected ID", "Raw emitted image", "Stored original SHA-256", "Stored 320×180 thumbnail SHA-256", "Genuine challenge proof after replay"], retake_rows), "",
        "Ordinary and devil gameplay albums in suite mode share the automatically refreshed latest gameplay frame set. Retake originals remain protected and retain the original frame paths. Each new process independently reads the exact photo IDs, paths, acquisition method, challenge proof, achievement and first 40-coin receipt (120 → 160). The album itself decodes the bound 320×180 thumbnail. Adjacent factory IDs remained absent.", "",
        "## Source, engine, templates and package", "",
        f"Prelaunch audited runtime and fixtures were based on `{BASE}`. A CI-only count correction in `test_region_travel.gd` changed HEAD during collection. The four fault-child parents stayed outside every local stage. All accepted native and export receipts have identical unmodified source maps. The donor comes from an earlier fixture candidate with identical asset and import configuration bytes. The source identity records Git blobs separately from SHA-256 of actual bytes, preserving raw legacy files and normalizing checkout CRLF only for the blob comparison. {markdown(IDENTITY)}", "",
        f"- Godot `4.7.2.stable.official.ed1daf0bf`, console SHA-256 `{ENGINE_HASH}`, backing editor SHA-256 `{EDITOR_HASH}`.",
        f'- Pinned Windows release template `{build["templates"]["release"]["sha256"]}`, debug template `{build["templates"]["debug"]["sha256"]}`. {markdown(export / "build.json")}',
        f'- Fresh package `CottonWindQA.exe`, {build["binary"]["bytes"]:,} bytes and SHA-256 `{build["binary"]["sha256"]}`. {markdown(build["binary"]["path"])} · {markdown(export_summary)}',
        f'- The export manifests enumerate raw hashes of all {len(identity):,} staged source/runtime files. The source graph SHA-256 is `{build["source"]["sha256"]}` and the effective QA runtime graph SHA-256 is `{describe(export / "runtime-graph.json")["sha256"]}`. {markdown(export / "source-graph.json")} · {markdown(export / "runtime-graph.json")}', "",
        "Every launch used the validated process launcher, a fresh absolute D: stage, APPDATA, LOCALAPPDATA, TEMP, TMP, capture and export directories, and the paired reader uses its writer's isolated save plus verification sidecar. Only the exact recursive fixture closure and tracked runtime were staged. The complete staged script/scene/resource/custom configuration scan found zero possible child-launch calls. The four local fault-child parents were absent, and CI registration was preserved. Asset-only import files were verified against unchanged asset/configuration hashes and pinned engine before copying. No script/UID/editor cache was imported into native stages.", "",
        "The package stage changed only its private main scene and Windows test exclusions/template file references. The production configurations were untouched. The QA EXE has an embedded PCK, no loose PCK, and both actual Windows boots use only the EXE and absolute log-file option. There is no project-path, script, main-pack, or scene override. The receipt records actual argv, Windows profile locations, source/runtime/audit receipts, exact engine/executable and log hashes.", "",
        "The first two parser candidates were stopped by selecting their exact owned stage processes after the diagnostics. Subsequent nonzero candidates identified fixture checks for sampled tension and automatic first-frame scheduling. Product bytes stayed frozen. The raw EXE writer receipt was retained and independently rechecked with the observed marker pattern before the paired reader boot. Both native EXE executions used the same fresh binary.", "",
        *table(["Candidate", "Receipt", "Diagnostic"], candidates), "",
        "## Explicit archive allowlist", "",
        f"The separate allowlist contains {len(archive)} existing raw files ({sum(item['bytes'] for item in archive):,} bytes), each with the absolute source path, relative archive name, byte count and SHA-256. It includes one canonical source snapshot, unique receipts/logs and PNGs, all measured layout JSONs, actual shutter and stored PNG comparisons and the embedded build receipt. Staged project trees, cached imports and executable binaries stay outside the archive. {markdown(archive_path)}", "",
        "ART-16/17, MIC-1/2/3 and ST-5 require their own human criteria. Human play, listening and physical touch were outside this automated evidence.",
    ]
    REPORT.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    print(f"Report {REPORT}; explicit archive {archive_path}; {total} native checks")

if __name__ == "__main__":
    report()
