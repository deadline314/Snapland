"""Run one isolated audited Godot process per fresh D stage and profile."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import uuid


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT))
from tools.build_desktop_release import prepare_runtime_stage
from tools.godot_entrypoints import run_validated_godot


BASE = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
ENGINE = Path("C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe")
ENGINE_HASH = "c8f0a6bc45a19b33541501e57f6f7cd972ab18453743266339d495cbbe846643"
EDITOR = ENGINE.with_name("Godot_v4.7.2-stable_win64.exe")
EDITOR_HASH = "ab1824f85bfd8e0e4128182c000c4003a3e042245b2967848d089b2a04b22424"
VERSION = "4.7.2.stable.official.ed1daf0bf"
TEMPLATE_HASH = {
    "debug": "51498b72b3a237f882ebd7d1787f06a4bc1eaf0572daab93837adcfd3cfdc107",
    "release": "d34d36f3be1a6c49c56525ae86469b92e4f417ddf0b43cf00dd80c385c4b0562",
}
SCENE = "game/tests/native_cotton_wind_main.tscn"


def fixture_closure(entry):
    paths = set()
    pending = [entry]
    while pending:
        name = pending.pop()
        if name in paths:
            continue
        assert name.startswith("game/tests/") and Path(name).stem not in EXCLUDED
        paths.add(name)
        pending.extend(re.findall(r'res://(game/tests/[^"\s]+\.(?:gd|tscn))"',
                                  (ROOT / name).read_text(encoding="utf-8-sig")))
    return sorted(paths)


EXCLUDED = ["test_photo_retake_main", "test_region_travel", "test_photo_retake_progress", "test_region_progress"]
MARKER = "PASS: native cotton Main parsed input, actual strands, GPU originals and restart"
SCRIPT_SUFFIXES = {".gd", ".tscn", ".tres", ".gdshader", ".gdshaderinc", ".gdextension", ".cs", ".py", ".ps1", ".bat", ".cmd", ".sh"}
CHILD_API = re.compile(r"\b(?:execute|execute_with_pipe|create_process|create_instance|shell_open|shell_show_in_file_manager|open_with_program|load_extension|JavaScriptBridge|GDExtension)\b|System\.Diagnostics\.Process|Process\.Start")
ERROR = re.compile(r"(?im)^.*\b(?:SCRIPT )?ERROR:.*$")
LEAK = re.compile(r"(?im)^.*(?:ObjectDB instances leaked|resources? still in use|still in use at exit|Leaked instance:|\b\d+\s+RIDs?\b.*(?:were leaked|leaked)|RID allocations?\b.*leak|leaked [1-9]\d* allocations).*$")
WARNING = re.compile(r"(?im)^.*\b(?:WARNING|WARN):.*$")


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def dump(path, data):
    with Path(path).open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(data, stream, indent=2, ensure_ascii=False)
        stream.write("\n")


def read(path):
    return json.loads(Path(path).read_bytes())


def describe(path):
    path = Path(path).resolve()
    return {"path": path.as_posix(), "bytes": path.stat().st_size, "sha256": sha(path)}


def make_base(label):
    parent = Path("D:/Snapland-QA/cotton-wind/task4")
    base = parent / f"{label}-{datetime.now():%m%d-%H%M%S}-{uuid.uuid4().hex[:6]}"
    base.mkdir(parents=True)
    return base


def stage_source(base):
    stage = base / "project"
    stage.mkdir()
    tracked = subprocess.check_output(["git", "ls-tree", "-r", "--name-only", "-z", BASE], cwd=ROOT, encoding="utf-8").split("\0")
    tracked = [name for name in tracked if not name.endswith((".uid", ".import"))]
    manifest = prepare_runtime_stage(ROOT, stage, tracked)
    for name in FIXTURES:
        target = stage / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / name, target)
        manifest[name] = sha(target)
    dump(base / "source-graph.json", {"commit_base": BASE, "source_raw_sha256": manifest, "fixtures": FIXTURES})
    return stage, manifest


def check_stage(stage, manifest):
    assert all(sha(stage / name) == digest for name, digest in manifest.items()), "Staged runtime/source bytes changed"
    assert all(sha(ROOT / name) == digest for name, digest in manifest.items()), "Repository source changed during evidence collection"


def audit(stage, base, manifest):
    tests = sorted(path.relative_to(stage).as_posix() for path in (stage / "game/tests").rglob("*")
                   if path.is_file() and path.suffix not in {".uid", ".import"})
    assert tests == sorted(FIXTURES), tests
    scripts, launch_calls = {}, {}
    for path in sorted(stage.rglob("*")):
        if not path.is_file() or (path.suffix not in SCRIPT_SUFFIXES and path.name not in {"project.godot", "export_presets.cfg"}):
            continue
        if path.relative_to(stage).parts[0] == ".godot":
            continue
        name = path.relative_to(stage).as_posix()
        scripts[name] = sha(path)
        for number, line in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), 1):
            if not line.lstrip().startswith(("#", ";")) and (CHILD_API.search(line) or any(fault in line for fault in EXCLUDED)):
                launch_calls.setdefault(name, []).append([number, line.strip()])
    assert all(name in manifest for name in scripts), "Unexpected staged script/scene/configuration"
    path = base / "prelaunch-audit.json"
    dump(path, {"stage": stage.as_posix(), "fixture_closure": FIXTURES, "excluded_fault_parents": EXCLUDED,
                "scope": "entire staged script/scene/resource/configuration graph including inherited base, unchanged helpers, runtime autoloads and dynamic loads",
                "audited_raw_sha256": scripts, "child_launch_candidates": launch_calls,
                "runner": describe(Path(__file__)), "helpers": [describe(ROOT / "tools" / file) for file in ("build_desktop_release.py", "godot_entrypoints.py")]})
    assert not launch_calls, launch_calls
    return path


def collect_imports(base, stage, manifest):
    wrapped = {}
    sidecars = [p for p in (stage / "assets").rglob("*.import") if p.relative_to(stage).as_posix().removesuffix(".import") in manifest]
    for path in sidecars:
        name = path.relative_to(stage).as_posix()
        wrapped[name] = sha(path)
        imported = set(re.findall(r'"res://(\.godot/imported/[^"/]+)"', path.read_text(encoding="utf-8")))
        assert imported, path
        for name in imported:
            wrapped[name] = sha(stage / name)
    assert wrapped
    dump(base / "asset-import-files.json", wrapped)


def copy_imports(donor, stage, manifest):
    donor = donor.resolve()
    assert donor.drive.upper() == "D:" and donor.parent == stage.parent.parent
    old = read(donor / "source-graph.json")["source_raw_sha256"]
    assert old == manifest, "Asset donor does not have the exact current source inputs"
    strict = read(donor / "receipt.json")
    assert strict["kind"] == "import" and strict["passed"] and strict["engine"]["sha256"] == ENGINE_HASH
    imported = read(donor / "asset-import-files.json")
    for name, digest in imported.items():
        source = donor / "project" / name
        target = stage / name
        assert ((name.startswith("assets/") and name.endswith(".import")) or
                (Path(name).parts[:2] == (".godot", "imported") and len(Path(name).parts) == 3))
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        assert sha(target) == digest, name
    dump(stage.parent / "asset-import-reuse.json", {"donor": donor.as_posix(), "donor_manifest": describe(donor / "asset-import-files.json"), "copied": imported})


def environment(base, mode="", size="1280x720", paired_save=None):
    keys = {}
    for key in ("APPDATA", "LOCALAPPDATA", "TEMP", "TMP"):
        path = base / key.lower()
        path.mkdir()
        keys[key] = path.as_posix()
    capture = base / "captures"
    capture.mkdir()
    (base / "export").mkdir()
    if paired_save is None:
        save = base / "save" / "progress.json"
        save.parent.mkdir()
    else:
        assert mode == "read" and paired_save.is_file() and paired_save.parent.parent != base
        save = paired_save
    keys.update(SNAPLAND_SAVE_PATH=save.as_posix(), GODOT_BIN=ENGINE.as_posix(), COTTON_CAPTURE_DIR=capture.as_posix(),
                COTTON_REVIEW_MODE=mode, COTTON_REVIEW_SIZE=size, SNAPLAND_QA_EXPORT_DIR=(base / "export").as_posix())
    assert all(Path(keys[key]).is_absolute() and Path(keys[key]).drive.upper() == "D:" for key in (
        "APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "SNAPLAND_SAVE_PATH", "COTTON_CAPTURE_DIR"))
    return keys


def launch(base, stage, manifest, kind, command, keys, release=None):
    assert sha(ENGINE) == ENGINE_HASH and sha(EDITOR) == EDITOR_HASH
    audit_path = audit(stage, base, manifest)
    engine_log = base / "engine.log"
    full_command = [str(part) for part in command]
    if kind != "version":
        full_command.extend(["--log-file", engine_log.as_posix()])
    effective = {name: sha(stage / name) for name in manifest}
    assert [name for name, digest in manifest.items() if effective[name] != digest] == (
        [name for name in manifest if name in {"project.godot", "export_presets.cfg"}] if release is not None or kind == "export" else [])
    dump(base / "runtime-graph.json", effective)
    print(f"{kind} {base}", flush=True)
    start = time.monotonic()
    now = datetime.now(timezone.utc).isoformat()
    try:
        process = run_validated_godot(stage, full_command, dict(os.environ, **keys), timeout=300, release_directory=release)
        code, stdout, stderr = process.returncode, process.stdout, process.stderr
    except subprocess.TimeoutExpired as error:
        code, stdout, stderr = 124, error.stdout or "", error.stderr or ""
    elapsed = time.monotonic() - start
    (base / "stdout.log").write_bytes(stdout.encode("utf-8"))
    (base / "stderr.log").write_bytes(stderr.encode("utf-8"))
    raw = engine_log.read_bytes().decode("utf-8-sig") if engine_log.exists() else ""
    evidence = [raw, stdout, stderr]
    errors = sorted(set(line for log in evidence for line in ERROR.findall(log)))
    leaks = sorted(set(line for log in evidence for line in LEAK.findall(log)))
    warnings = sorted(set(line for log in evidence for line in WARNING.findall(log)))
    marker_counts = [log.splitlines().count(MARKER) for log in evidence]
    native = kind in {"suite", "retake-ordinary", "retake-devil", "read"}
    passed = code == 0 and not errors and not leaks and (bool(raw) if kind != "version" else stdout.strip() == VERSION)
    if native:
        passed = passed and marker_counts[0] == 1 and max(marker_counts) == 1 and (base / "captures/cotton-evidence.json").is_file()
    logs = [describe(base / name) for name in ("engine.log", "stdout.log", "stderr.log") if (base / name).is_file()]
    captures = sorted((base / "captures").glob("*"))
    receipt = {"kind": kind, "command": full_command, "environment": keys, "started_utc": now, "wall_seconds": elapsed,
               "stage": stage.as_posix(), "release_directory": release.as_posix() if release else None, "exit_code": code,
               "engine": describe(ENGINE), "editor_sibling": describe(EDITOR), "version": VERSION,
               "errors": errors, "leak_diagnostics": leaks, "warnings": warnings, "marker": MARKER if native else None,
               "marker_counts_engine_stdout_stderr": marker_counts if native else None, "passed": passed, "logs": logs,
               "audit": describe(audit_path), "source_graph": describe(base / "source-graph.json"),
               "runtime_graph": describe(base / "runtime-graph.json"), "capture_outputs": [describe(path) for path in captures],
               "asset_import_reuse": describe(base / "asset-import-reuse.json") if (base / "asset-import-reuse.json").is_file() else None}
    dump(base / "receipt.json", receipt)
    print(f"{kind} exit={code} errors={len(errors)} leaks={len(leaks)} markers={marker_counts} wall={elapsed:.2f}s passed={passed}", flush=True)
    if not passed:
        print("\n".join(errors + leaks) or (raw or stdout or stderr)[-5000:], flush=True)
        raise RuntimeError(f"Strict launch failed in {base}")
    return receipt


def templates(base):
    source_dir = Path(os.environ["APPDATA"]) / "Godot/export_templates/4.7.2.stable"
    assert (source_dir / "version.txt").read_text().strip() == "4.7.2.stable"
    target_dir = base / "templates"
    target_dir.mkdir()
    selected = {}
    for kind, digest in TEMPLATE_HASH.items():
        source = source_dir / f"windows_{kind}_x86_64.exe"
        target = target_dir / source.name
        assert sha(source) == digest
        shutil.copy2(source, target)
        assert sha(target) == digest
        selected[kind] = describe(target)
    return selected


def qa_override(stage, pinned):
    project = stage / "project.godot"
    source = project.read_bytes()
    player = b'run/main_scene="res://game/main.tscn"'
    assert source.count(player) == 1
    project.write_bytes(source.replace(player, f'run/main_scene="res://{SCENE}"'.encode()))
    preset = stage / "export_presets.cfg"
    windows, linux = preset.read_bytes().split(b"[preset.1]", 1)
    assert windows.count(b"game/tests/*,") == 1
    windows = windows.replace(b"game/tests/*,", b"", 1)
    for kind, entry in pinned.items():
        empty = f'custom_template/{kind}=""'.encode()
        assert windows.count(empty) == 1 and sha(entry["path"]) == TEMPLATE_HASH[kind]
        windows = windows.replace(empty, f'custom_template/{kind}="{entry["path"]}"'.encode(), 1)
    preset.write_bytes(windows + b"[preset.1]" + linux)


def prepare(label, donor=None):
    base = make_base(label)
    stage, manifest = stage_source(base)
    check_stage(stage, manifest)
    if donor is not None:
        copy_imports(donor, stage, manifest)
    return base, stage, manifest


def bootstrap(label):
    base, stage, manifest = prepare(label + "-version")
    launch(base, stage, manifest, "version", [ENGINE, "--version"], environment(base))
    base, stage, manifest = prepare(label + "-donor")
    launch(base, stage, manifest, "import", [ENGINE, "--headless", "--path", stage, "--editor", "--import", "--quit"], environment(base))
    collect_imports(base, stage, manifest)
    print(f"ASSET DONOR {base.as_posix()}", flush=True)
    return base


def pair(label, size, mode, donor, binary=None, pinned=None):
    runs = []
    writer_save = None
    for part in (mode, "read"):
        base, stage, manifest = prepare(f"{label}-{part}", donor)
        keys = environment(base, part, size, writer_save)
        if binary is None:
            release = None
            command = [ENGINE, "--path", stage, "--resolution", size, "--position", "10,40", "res://" + SCENE]
        else:
            qa_override(stage, pinned)
            release = binary.parent
            command = [binary]
            build = read(release.parent / "build.json")
            assert sha(binary) == build["binary"]["sha256"] and all(sha(stage / name) == digest for name, digest in build["runtime_sha256"].items())
        launch(base, stage, manifest, part, command, keys, release)
        runs.append(describe(base / "receipt.json"))
        if part != "read":
            writer_save = Path(keys["SNAPLAND_SAVE_PATH"])
    dump(runs[-1]["path"].removesuffix("receipt.json") + "pair.json", {"label": label, "size": size, "writer_mode": mode, "runs": runs})
    return runs


def embedded(label, donor):
    base, stage, manifest = prepare(label + "-export", donor)
    pinned = templates(base)
    qa_override(stage, pinned)
    release = base / "release"
    release.mkdir()
    binary = release / "CottonWindQA.exe"
    launch(base, stage, manifest, "export", [ENGINE, "--headless", "--path", stage, "--editor", "--export-release", "Windows Desktop", binary, "--quit"], environment(base))
    with binary.open("rb") as stream:
        assert stream.read(2) == b"MZ"
    assert binary.stat().st_size > pinned["release"]["bytes"] and not any(release.glob("*.pck"))
    info = {"binary": describe(binary), "templates": pinned, "source": describe(base / "source-graph.json"),
            "runtime_sha256": read(base / "runtime-graph.json"), "export": describe(base / "receipt.json"),
            "qa_overrides": ["staged main points to explicit QA scene", "Windows export includes only staged QA files", "Windows templates point to pinned D files"],
            "normal_main": describe(ROOT / "project.godot"), "normal_export": describe(ROOT / "export_presets.cfg")}
    dump(base / "build.json", info)
    runs = pair(label + "-exe", "1280x720", "suite", donor, binary, pinned)
    dump(base / "embedded-acceptance.json", {"build": describe(base / "build.json"), "launches": runs})


def main():
    global FIXTURES
    FIXTURES = fixture_closure(SCENE)
    parser = argparse.ArgumentParser()
    parser.add_argument("label")
    parser.add_argument("action", choices=["bootstrap", "suite", "retake-ordinary", "retake-devil", "matrix", "embedded"])
    parser.add_argument("--donor", type=Path)
    parser.add_argument("--size", default="1280x720", choices=["1280x720", "1152x648", "800x600"])
    args = parser.parse_args()
    if args.action == "bootstrap":
        bootstrap(args.label)
        return
    assert args.donor is not None
    if args.action == "embedded":
        embedded(args.label, args.donor)
    elif args.action == "matrix":
        for mode, size in [("suite", "1280x720"), ("suite", "1152x648"), ("suite", "800x600"),
                           ("retake-ordinary", "1280x720"), ("retake-devil", "1280x720"), ("retake-ordinary", "800x600"), ("retake-devil", "1152x648")]:
            pair(f"{args.label}-{size}", size, mode, args.donor)
    else:
        pair(args.label, args.size, args.action, args.donor)


if __name__ == "__main__":
    main()
