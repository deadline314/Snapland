from pathlib import Path
import json
import subprocess
import sys

from evidence import TASK, describe

HERE = Path(__file__).resolve().parent
RUNNER = HERE / "native_run.py"
DONOR = TASK / "cotton-a-donor-1119-040639-9854fe"
PLAN = [
    ("cotton-1152", "suite", "1152x648"),
    ("cotton-800", "suite", "800x600"),
    ("cotton-rt1280-ordinary", "retake-ordinary", "1280x720"),
    ("cotton-rt1280-devil", "retake-devil", "1280x720"),
    ("cotton-rt800-ordinary", "retake-ordinary", "800x600"),
    ("cotton-rt1152-devil", "retake-devil", "1152x648"),
    ("cotton-embed", "embedded", "1280x720"),
]

def matching(label, filename):
    return sorted(path / filename for path in TASK.glob(label + "-*") if (path / filename).is_file())

def passed(label, purpose):
    receipts = matching(label + ("-export" if purpose == "embedded" else "-read"),
                        "embedded-acceptance.json" if purpose == "embedded" else "pair.json")
    return [path for path in receipts if path.exists()]

if __name__ == "__main__":
    for label, purpose, size in PLAN:
        if len(sys.argv) > 1 and label not in sys.argv[1:]:
            continue
        completed = passed(label, purpose)
        if completed:
            print(f"Already passed {label}: {completed[-1]}", flush=True)
            continue
        subprocess.run([sys.executable, "-B", str(RUNNER), label, purpose, "--size", size, "--donor", str(DONOR)], check=True)
        completion, = passed(label, purpose)
        with (HERE / "accepted-pairs.jsonl").open("a", encoding="utf-8", newline="\n") as session:
            session.write(json.dumps({"label": label, "size": size, "purpose": purpose, "proof": describe(completion)}) + "\n")
        print(f"PASS LEDGER {label} {completion}", flush=True)
