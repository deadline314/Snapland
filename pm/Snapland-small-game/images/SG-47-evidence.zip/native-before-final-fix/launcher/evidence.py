from datetime import datetime
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[3]
BASE = "e48caab22b05e61c98e2870ae58ae1aeebcc2f74"
HERE = Path(__file__).resolve().parent
MARKER = "PASS: native cotton Main parsed input, actual strands, GPU originals and restart"
ENGINE_HASH = "c8f0a6bc45a19b33541501e57f6f7cd972ab18453743266339d495cbbe846643"
EDITOR_HASH = "ab1824f85bfd8e0e4128182c000c4003a3e042245b2967848d089b2a04b22424"
TASK = Path("D:/Snapland-QA/cotton-wind/task4")

def read(path):
    return json.loads(Path(path).read_bytes())

def digest(data):
    return hashlib.sha256(data).hexdigest()

def describe(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return {"path": path.as_posix(), "bytes": len(raw), "sha256": digest(raw)}

def verify(description):
    assert describe(description["path"]) == description, description["path"]

def save_json(path, data):
    with path.open("x", encoding="utf-8", newline="\n") as output:
        json.dump(data, output, ensure_ascii=False, indent=2)
        output.write("\n")

def source_proof(sample):
    tree = {}
    for line in subprocess.check_output(["git", "ls-tree", "-rz", BASE], cwd=ROOT).split(b"\0"):
        if line:
            meta, _, path = line.partition(b"\t")
            tree[path.decode("utf-8")] = meta.split()[2].decode("ascii")
    source = read(sample / "source-graph.json")
    assert source["commit_base"] == BASE
    proof = {}
    for name, stage_hash in source["source_raw_sha256"].items():
        raw = (ROOT / name).read_bytes()
        assert digest(raw) == stage_hash and digest((sample / "project" / name).read_bytes()) == stage_hash, name
        blob = tree.get(name)
        comparison = "fixture added in Task4"
        if blob:
            raw_blob = hashlib.sha1(f"blob {len(raw)}\0".encode() + raw).hexdigest()
            comparison = "raw bytes equal Git blob"
            if blob != raw_blob:
                committed = subprocess.check_output(["git", "cat-file", "blob", blob], cwd=ROOT)
                assert raw.replace(b"\r\n", b"\n") == committed.replace(b"\r\n", b"\n"), name
                comparison = "CRLF normalization only"
        else:
            assert name in ["game/tests/native_cotton_wind_main.gd", "game/tests/native_cotton_wind_main.tscn"], name
        proof[name] = {"git_base_blob": blob, "raw_sha256": stage_hash, "bytes": len(raw), "comparison": comparison}
    path = HERE / ("source-identity-" + datetime.now().strftime("%H%M%S") + ".json")
    save_json(path, {"base": BASE, "sample": sample.as_posix(), "files": proof})
    return path

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        print(source_proof(Path(sys.argv[1])))
