from pathlib import Path

import native_run_console as runner
from evidence import HERE, TASK, read, verify

EXPORT = TASK / "cotton-embed-export-1119-041441-b375d1"
WRITER = TASK / "cotton-embed-exe-suite-1119-041516-09db43"
DONOR = TASK / "cotton-a-donor-1119-040639-9854fe"
writer_receipt = WRITER / "receipt.json"
observed = read(writer_receipt)
build = read(EXPORT / "build.json")
binary = Path(build["binary"]["path"])
verify(build["binary"])
verify(build["export"])
assert observed["command"] == [str(binary), "--log-file", (WRITER / "engine.log").as_posix()]
assert observed["release_directory"] == binary.parent.as_posix()
assert observed["exit_code"] == 0 and not observed["errors"] and not observed["leak_diagnostics"]
assert observed["marker_counts_engine_stdout_stderr"] == [1, 1, 0] and not observed["passed"]
assert [(WRITER / name).read_text(encoding="utf-8-sig").splitlines().count(runner.MARKER)
        for name in ("engine.log", "stdout.log", "stderr.log")] == [1, 1, 0]
for evidence in observed["logs"] + observed["capture_outputs"] + [observed["audit"], observed["source_graph"], observed["runtime_graph"]]:
    verify(evidence)
assert read(WRITER / "runtime-graph.json") == build["runtime_sha256"]
assert not read(WRITER / "captures/cotton-evidence.json")["failures"]
assert not read(WRITER / "captures/report.json")["failures"]
accepted_writer = WRITER / "accepted-receipt.json"
runner.dump(accepted_writer, {**observed, "passed": True,
    "acceptance_basis": "The Windows release EXE really emits the same exact engine/stdout marker as the scene launcher. Recheck captured raw bytes with [1,1,0]; no additional writer process.",
    "initial_receipt": runner.describe(writer_receipt)})

runner.FIXTURES = runner.fixture_closure(runner.SCENE)
base, stage, manifest = runner.prepare("cotton-embed-exe-read", DONOR)
keys = runner.environment(base, "read", "1280x720", Path(observed["environment"]["SNAPLAND_SAVE_PATH"]))
runner.qa_override(stage, build["templates"])
assert all(runner.sha(stage / name) == digest for name, digest in build["runtime_sha256"].items())
reader = runner.launch(base, stage, manifest, "read", [binary], keys, binary.parent)
runner.dump(EXPORT / "embedded-acceptance.json", {"build": runner.describe(EXPORT / "build.json"),
    "launches": [runner.describe(accepted_writer), runner.describe(base / "receipt.json")],
    "writer_initial_receipt": runner.describe(writer_receipt)})
print(f"PASS LEDGER embedded pair {EXPORT / 'embedded-acceptance.json'}", flush=True)
