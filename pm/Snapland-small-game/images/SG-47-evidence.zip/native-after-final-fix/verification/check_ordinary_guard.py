"""Check the bounded route cannot reset before it checks the terminal result."""
import argparse
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument("--base")
args = parser.parse_args()
source = "game/tests/test_cotton_wind_view.gd"
text = (subprocess.check_output(["git", "show", args.base + ":" + source], encoding="utf-8")
        if args.base else Path(source).read_text(encoding="utf-8"))
route = text.split("\tfor i in 1200:\n", 1)[1].split("\n\t_reset_a()", 1)[0]
checks = [line.strip() for line in route.splitlines() if line.startswith("\tcheck(")]
assert any(all(term in line for term in (".ended", ".success", ".score == 400", ".ordinary_eligible")) for line in checks), (
    "Falling through 1,200 iterations reaches reset with no unconditional ended/success/400/ordinary eligibility check")
print("PASS: unconditional terminal check before ordinary route reset")
