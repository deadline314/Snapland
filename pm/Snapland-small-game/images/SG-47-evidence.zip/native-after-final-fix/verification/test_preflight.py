"""Reject misconfigured QA invocations before a Godot process or Progress autoload exists."""
import json
from pathlib import Path
from unittest.mock import patch

import native_run as runner


def exercise(case):
    base = runner.make_base("preflight-" + case)
    stage = base / "project"
    stage.mkdir()
    keys = runner.environment(base, "suite")
    if case != "missing-stage":
        (stage / "project.godot").write_bytes((runner.ROOT / "project.godot").read_bytes())
    save = Path(keys["SNAPLAND_SAVE_PATH"])
    capture = Path(keys["COTTON_CAPTURE_DIR"])
    if case == "migration":
        # Without preflight, Progress erases frames on this old devil card and writes the migration.
        runner.dump(save, {"version": 1, "photos": {"photo-welcome-devil-1": {"frames": []}}})
        runner.dump(save.with_suffix(".json.bak"), {"version": 1, "coins": 17})
    elif case in {"backup-only", "temporary-only"}:
        save.with_suffix(".json." + ("bak" if case == "backup-only" else "tmp")).write_bytes(b"sentinel")
    elif case == "target-directory":
        save.mkdir()
    elif case == "capture-file":
        capture.rmdir()
        capture.write_bytes(b"sentinel")
    elif case == "used-capture":
        (capture / ".hidden-sentinel").write_bytes(b"sentinel")
    elif case == "missing-save-parent":
        save.parent.rmdir()
    elif case == "unpaired-reader":
        keys["COTTON_REVIEW_MODE"] = "read"
        runner.dump(save, {"version": 1})
    def snapshot():
        return {p.relative_to(base).as_posix(): runner.sha(p) if p.is_file() else "directory"
                for p in base.rglob("*")}
    before = snapshot()
    with patch.object(runner, "run_validated_godot") as launch:
        try:
            runner.launch(base, stage, {}, "suite", [runner.ENGINE], keys)
        except ValueError as error:
            reason = str(error)
        else:
            raise AssertionError(case + " accepted a reused or invalid path")
        launch.assert_not_called()
    after = snapshot()
    assert before == after and reason.startswith("Cotton preflight:")
    result = {"case": case, "reason": reason, "godot_calls": 0, "before": before, "after": after}
    runner.dump(base / "refusal.json", result)
    print(case, reason, flush=True)
    return runner.describe(base / "refusal.json")


if __name__ == "__main__":
    cases = ["migration", "backup-only", "temporary-only", "target-directory", "capture-file",
             "used-capture", "missing-save-parent", "missing-stage", "unpaired-reader"]
    runner.dump(runner.HERE / "preflight-results.json", [exercise(case) for case in cases])
