"""Verify fixed-run originals, source graphs and the explicit supplemental archive input."""
from pathlib import Path
import re

import native_run as r

fixed = r.QA
entries = []
summary = {}


def record(member, path):
    entries.append({"archive_path": member, **r.describe(path)})


def verify(info):
    assert r.describe(info["path"]) == info


def finished(label):
    values = []
    for run in fixed.glob(label + "-*"):
        if (run / "receipt.json").is_file() and r.read(run / "receipt.json")["passed"]:
            values.append(run)
    assert len(values) == 1, values
    return values[0]


labels = ["view-red", "view", "refuse-profile", "refuse-capture", "small-suite", "small-read",
          "donor", "embed-export", "embed-exe-suite", "embed-exe-read"]
runs = {label: finished(label) for label in labels if label != "view"}
runs["view"] = fixed / "view-1119-043228-178335"
for label, run in runs.items():
    rc = r.read(run / "receipt.json")
    assert rc["passed"]
    for info in rc["logs"] + rc["capture_outputs"] + [rc["audit"], rc["source_graph"], rc["runtime_graph"]]:
        verify(info)
    if rc["asset_import_reuse"]:
        verify(rc["asset_import_reuse"])
    assert not r.read(run / "prelaunch-audit.json")["child_launch_candidates"]
    log = (run / "engine.log").read_text(encoding="utf-8-sig")
    mark = re.findall(r"COTTON_NATIVE_CHECKS [^\n]+|Cotton wind view: [^\n]+", log)
    if label in ["donor", "embed-export"]:
        const = "[ DONE ] " + ("loading_editor_layout" if label == "donor" else "savepack")
        assert log.splitlines().count(const) == 1
    summary[label] = {"run": run.as_posix(), "receipt": r.describe(run / "receipt.json"),
                      "exit": rc["exit_code"], "counts": mark, "errors": rc["errors"], "warnings": rc["warnings"]}
    for name in ("receipt.json", "prelaunch-audit.json", "source-graph.json", "runtime-graph.json", "asset-import-reuse.json",
                 "engine.log", "stdout.log", "stderr.log", "pair.json", "build.json", "embedded-acceptance.json",
                 "asset-import-files.json", "sentinels.json"):
        if (run / name).is_file():
            record("runs/" + label + "/" + name, run / name)
    for info in rc["capture_outputs"]:
        record("runs/" + label + "/captures/" + Path(info["path"]).name, info["path"])

for prefix in ["small", "embed-exe"]:
    writer, reader = [runs[prefix + "-" + suffix] for suffix in ["suite", "read"]]
    w, rd = [r.read(p / "captures/cotton-evidence.json") for p in [writer, reader]]
    assert not w["failures"] and not rd["failures"] and w["profile"] == rd["profile"]
    provenance = r.read(writer / "save/native-originals.json")
    save = writer / "save/progress.json"
    assert provenance["profile"] == w["profile"] and r.sha(save) == provenance["save_sha256"]
    photos = {Path(k): v for frame in w["profile"]["hashes"].values() for k, v in frame.items()}
    assert len(photos) == 6 and all(path.parent == writer / "save/photos" and r.sha(path) == v for path, v in photos.items())
    for path in [save, writer / "save/native-originals.json", *photos]:
        record("runs/" + prefix + "-suite/" + path.relative_to(writer).as_posix(), path)
    summary[prefix + "-continuity"] = {"profile": r.describe(save), "method": "gameplay", "stored_pixels": len(photos),
                                      "coins": w["profile"]["coins"], "reward_receipts": w["profile"]["reward_receipts"]}

build = r.read(runs["embed-export"] / "build.json")
verify(build["binary"])
for entry in build["templates"].values():
    verify(entry)
for label in ["embed-exe-suite", "embed-exe-read"]:
    rc = r.read(runs[label] / "receipt.json")
    assert rc["command"] == [str(Path(build["binary"]["path"])), "--log-file", (runs[label] / "engine.log").as_posix()]
    assert build["runtime_sha256"] == r.read(runs[label] / "runtime-graph.json")
summary["exe"] = build["binary"]
for file, run in [("game/tests/native_cotton_wind_main.gd", runs["small-suite"]),
                  ("game/minigames/cotton_wind_view.gd", runs["small-suite"]), ("game/tests/test_cotton_wind_view.gd", runs["view"]),
                  ("assets/ui/tutorials/game-030-step-01.png", runs["small-suite"])]:
    path = run / "project" / file
    assert r.sha(path) == r.sha(r.ROOT / file)
    record("fixed-source/" + file, path)

for item in r.read(r.HERE / "preflight-results.json"):
    verify(item)
    data = r.read(item["path"])
    assert data["before"] == data["after"] and data["godot_calls"] == 0
    record("preflight/" + data["case"] + ".json", item["path"])
for name in ("native_run.py", "test_preflight.py", "preflight-results.json", "check_ordinary_guard.py",
             "ordinary-guard-before.txt", "ordinary-guard-after.txt", "seal.py"):
    record("verification/" + name, r.HERE / name)
parse = fixed / "refuse-profile-1119-043454-5670a8"
assert not r.read(parse / "receipt.json")["passed"]
for name in ("receipt.json", "engine.log", "stdout.log", "stderr.log", "runtime-graph.json", "prelaunch-audit.json"):
    record("discarded-parse/" + name, parse / name)
assert len({e["archive_path"] for e in entries}) == len(entries)
r.dump(r.HERE / "run-summary.json", summary)
record("verification/run-summary.json", r.HERE / "run-summary.json")
r.dump(r.HERE / "promoted-allowlist.json", {"base": "1ca72ff838b5141ae6beead03b869b641c58bea9", "files": entries})
print(f"Sealed {len(entries)} files, {sum(e['bytes'] for e in entries)} bytes.")
