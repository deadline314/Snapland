# SG42 Task3 integration report

Status: FINAL SOURCE FREEZE. All owned integration and asset-dependent checks passed after final real026 PNG import. No engine active; no further mutation planned. Root can review/package this source.

Owned files and their final SHA256 are recorded in source-hashes.json (19 files). Final root-owned three tutorial PNG SHA256 are recorded read-only in tutorial-png-hashes.json. No model/driver/view, root runner/validator/designJSON, PM/Git, PNG, nativeRoot or package files changed. No dependencies or source/stage copies added.

## Change

Catalog delivers exactly26 games, candy local2 cookie_mold with fixed normal/devil2/ACH026. Session adds one driver registration after controls confirmed all files parse. World preserves old6 interactions and adds reachable cookie point(-5,0.2,2); signs and dynamic map/info reflect2/12. Candy guide offers existing Paper2-column selector and both lessons; other guides stay park. Tutorial26 has3 semantic steps pointing only to root-owned real026 PNG paths. Retake PROPS now26 rows, all3 existing props per row. Candy album/rules state actual participation policy. Existing scope/count/refusal tests moved precisely; sugar scores400/500, old IDs, quota18/12/final180 remain.

New Session tests use real key and projected pointer events through Session: highest-adhered edge selection with Tab,0.16s Space light charge/release, slow mold pointer ramp or last-slot2.8rad target, AI holds outlet only while mold owned, then real tray drag to flyingcookie x using the visible handle grab offset. Snapshot clones only generate pointer coordinates, never change model. Actual6 catches normal700/practice+assisted real inertia800, idle0, genuine timeout participation, pause/blur/cancel/no extra action, retry configuration, unknown027 and HUD are covered.

New Main test uses the Session input route for timeout/practice/ordinary/assisted challenge/cancel, fixed local2/rewards +40/dedup, first026 tutorial/map, selected retake, original/thumb decode, provenance upgrade and reload. It explicitly requires actual valid3props, Next twice and enabled shutter before creating a synthetic persistence image; this is not claimed as native shutter evidence. Exact final marker is PASS: cookie Main factory entry, six real catches, fixed rewards, selected retake originals and reload.

## Commands and evidence

All engine runs use tools.godot_entrypoints.run_validated_godot, executable C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe, --headless --path C:/Users/stanl/Github/Snapland, and an absolute distinct SNAPLAND_SAVE_PATH under this integration directory. Each log records exact command, exit, stdout and stderr.

| Log | Result |
| --- | --- |
| red-session.log | Expected RED: Catalog026 missing,1check/1failure, exit1. |
| red-session-driver.log | Expected RED after catalog: driver registration missing,2checks/1failure, exit1; full test parses. |
| catalog.log | GREEN exact catalog/copies/fixed identities/malformed data, exit0. |
| candy-world.log | GREEN4278checks, all7 actual points connected and selected across3 world entries, exit0. |
| session.log / session-offset.log | GREEN Cookie mold Session:21checks,0failures; actual6 catches and exact700/800; latest rerun uses actual grabbed-tray offset after Driver fix. |
| sugar-session.log | GREEN Sugar bridge Session:21checks,0failures; exact400/500 preserved. |
| participation.log | GREEN all26 participation/practice/cancel/driver policy with actual cookie tray input. |
| sugar-main.log | GREEN existing Sugar Main rewards/retake/provenance/reload with expanded catalog2. Existing unsupported-material OcclusionController warnings only; no ERROR/SCRIPT ERROR. |
| main-pre-assets.log / main-offset-pre-assets.log | Expected exit1 before root PNGs: actual Main gameplay/reward/reload checks ran, real retake-set assertion correctly fails closed on missing026step1; no parse errors, synthetic persistence not entered. |

No editor/GPU engine launched by Task3. Root owns native input/screenshots/real shutter/cold-process package proof and final review. No human playtest claim.

## Final dependent verification

Root froze and imported three real Main1280 PNGs. First pagedViewport run caught a real 800x450/125% overflow: cookie ordinary field group252px exceeded clip242px. Changed only new cookie ordinary copy57->47characters, retaining actual participation/natural settlement, idle/AI/practice/cancel exclusion and free-retake provenance. No shared UI geometry, font floor, test assertion or marker was relaxed. Root confirmed game-view PNGs remain valid for this lesson-copy change.

Final wording: 參與操作後結算不限勝負得普通卡；等待、切換AI、練習或取消不發卡。練習後可免費補拍，不記技巧。

| Final log | Result |
| --- | --- |
| final-cookie-main-short.log | exit0,11.15s; exact PASS: cookie Main factory entry, six real catches, fixed rewards, selected retake originals and reload. Actual real-set readiness and synthetic persistence/provenance block both completed. |
| final-retake-panel.log | exit0,31.27s; all26 canonical sets with exact26PROPS,3props each, enabled shutter afterNext2, malformed027 fails closed; exact canonical/reversible/keyboard/capture marker. |
| final-tutorial-panel-short.log | exit0,16.67s; exact PASS: tutorial panel/catalog checks. One intentional existing game001 missing-fixture warning from test_tutorial_panel.gd:100 validates fallback/zoom guards; no actual026 image warning. |
| final-tutorial-paged-short.log | exit0,37.96s; every27lessons/5semantic fields/3sizes+125%, actual clip/line-height/wheel checks pass. |
| final-region-travel.log | exit0,49.69s; exact PASS: region travel admission, lifecycle, scoped UI, restart, and unchanged rewards. Includes Candy2game guide both callbacks/2columns, album2/stamps2/info2/12 and preserved18/12targets. |
| final-retake-native-fixture.log | exit0,2.68s; exact PASS: retake native fixture adjacent helper, isolated packaging and real resources. All actual tutorial PNG resources load. |

All final commands use the exact same validated headless executable/entrypoint conventions and distinct absolute save paths described above. No final026PNG missing/unreadable warnings, ERROR or SCRIPT ERROR. Existing OcclusionController unsupported-material warnings remain in Main/region logs; intentional fallback warning remains only in its negative tutorial test.

Task3 has no open scoped implementation defects. Root retains native actual GUI/shutter/new-process/package proof, ticket/Git/CI and overall review responsibility. These headless checks do not claim human playtesting. Root's final Driver grab-offset correction was included in the actual Session/Main solver via visible handle-target geometry, and Session21 remained GREEN.
