# SG42 Task 3 fresh source review

Verdict: **no actionable P1/P2 findings in the reviewed Task 3 source**. This is scoped source acceptance, not final asset, native shutter, export or human-playtest acceptance.

Reviewed against AGENTS.md, pm-ticket, `design/runtime/cookie-mold-gameplay.md`, Task 3 of `docs/superpowers/plans/2026-11-18-cookie-mold.md`, `seams.md` and `integration/report.md`. Base HEAD: `ccddd9ab96cabd377b56d8aaa9627ca621eb0242`; reviewed the current uncommitted integration. All 19 current integration files match `integration/source-hashes.json` at review time.

## Scope and conclusions

- Catalog/runtime JSON/Session registration: exactly 26 ordered delivered games; existing 25 data rows unchanged. Candy starts at global 25 and adds local 2 `cookie_mold`; canonical identities produce `photo-candy-game-2`, `photo-candy-devil-2`, `ACH_GAME_026`. Unknown 027 remains refused by the unchanged canonical lookup and explicit negative tests. Existing fixed itemdefs 10202/20202 stay nontradeable/nonmarketable; no economy or save migration added.
- Main/CandyWorld/map/collection/tutorial selector: the old six world interactions remain; seventh cookie entrance is added independently. Catalog-derived map, stamps and album expose two delivered candy games. Factory guide is two columns with both canonical lessons and the existing back/close behavior; other regions retain their park guide. Ordinary-card copy consistently requires actual participation for both candy modes. Planned 18 ordinary / 12 devil and final 180 targets are unchanged.
- Tutorial/retake: one three-step 026 lesson points to its own three PNG paths, with participation, full-body catching, actual double-layer inertia and honest practice/cancel wording. PROPS appends a real 26th three-prop row using existing valid atlas keys. Existing canonical lesson/source-image/texture/prop checks still fail closed. The new Main test requires the actual valid set, three loaded props, two Next actions and enabled shutter before invoking its clearly labelled synthetic persistence fixture.
- Session/Main tests: the reusable route changes gameplay only through Session keyboard/pointer input and time advancement. Snapshot clones choose pointer coordinates; they do not set model results. Tests cover real six catches, normal 700 / assisted challenge 800, practice exclusion, idle exclusion, participated timeout, cancellation, pause/blur/charge clear, retry configuration, HUD and 027 refusal. Main checks local-2 awards, one +40 receipt, challenge provenance upgrade, unrelated-card isolation, selected retake, thumbnail decode and saved restart.
- Existing regression updates preserve the original identity assertions and sugar 400/500 score assertions. Global participation adds actual cookie tray input before timeout. Shared Progress keeps transactional award/dedup and excludes retake records from gameplay-thumbnail replacement, preserving retake PNG originals and original acquisition provenance when actual challenge proof is later earned.

## Verification and limits

Performed source/diff inspection, checked the 19 source hashes, ran `git diff --check` for the scoped production diff, and ran a small read-only Python assertion over JSON: original 25 rows unchanged, ordered IDs 001..026, candy local 2/mode identity, three dedicated lesson paths and fixed nontradeable itemdefs. Static checks passed.

Read the author's existing Session/Main regression reports as context; did not rerun or independently claim those engine results. No engine, GPU, editor, source-image inspection, actual shutter, export or package test was run in this review. Root was replacing final tutorial PNG candidates during review; final PNG provenance/readability/import and actual native retake/cold restart remain pending root evidence. Root-owned runner/validator/design JSON and Task 1/2 internals are outside this review.

No production, PM or Git mutation; only this review artifact was written. No open P1/P2 fix request for the Task 3 author.
