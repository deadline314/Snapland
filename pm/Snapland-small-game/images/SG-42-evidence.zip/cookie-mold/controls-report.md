# Cookie mold Task 2 delivery

Source frozen after final exact-engine runs. Only the six assigned Task 2 files were authored; no model, Session, Main, Git, PM, runner, validator or dependency edits.

## Verification

- Exact engine: `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe`, reported `4.7.2.stable.official.ed1daf0bf`.
- Every process used `tools.godot_entrypoints.run_validated_godot`, project root as cwd, and an absolute isolated `.review/cookie-mold-20261118/controls-*-save.json` in `SNAPLAND_SAVE_PATH`. No editor process or player save.
- `--headless --path <root> --script res://game/tests/test_cookie_mold_driver.gd --quit-after 120`: **Cookie mold driver: 34 checks, 0 failures**; log `test_cookie_mold_driver.gd.log`.
- `--headless --path <root> --script res://game/tests/test_cookie_mold_view.gd --quit-after 120`: **Cookie mold view: 169 checks, 0 failures**; log `test_cookie_mold_view.gd.log`.
- GPU scene `res://game/tests/native_cookie_mold_workbench_review.tscn --quit-after 800`, `SNAPLAND_COOKIE_WORKBENCH_SIZE=800x600`, `1280x720`, `1920x1080`; corresponding absolute `SNAPLAND_COOKIE_WORKBENCH_OUTPUT=.../controls-<size>`: **98 checks, 0 failures each**. Logs `controls-<size>.log`.
- 800x600 uses 125% text and reduced motion. All nine actual on-screen press/hold/release routes work. Both articulated hands' eight-corner mesh bounds fit the workspace through forty continuously controlled mold poses. Physical PNG dimensions and control bounds verified.
- Keyboard-only full route: 6 caught, 800 score, elapsed 23.185. Mouse gentle full route: 6 caught, 700 score, elapsed 31.382. Owned touch 4 final-cookie inertia route: 6 caught, 800 score, elapsed 31.090. These are scripted public InputEvent routes, not human playtests.
- All 108 edge midpoints across six polygons, including 32 gear edges, project to the actual inclined camera image and nearest-edge hit. No snapshot result or physics mutation is used by control routes.
- Retained view: 32 mold walls, gaps, crack segments and markers each; three cookie/filling meshes; six bounded completion outlines; two hands with palms, cuffs, four segmented fingers and wrapping thumbs. Nodes, materials and geometry remain unchanged across per-frame presentation; actual shape/config change alone rebuilds bounded extrusions. Six shape transitions and repeated teardown retain the measured baseline.

## Red and fixes

No preimplementation control RED run was captured; initial test execution found typed-bool parser errors in `visible_edge` and `held`, corrected before successful routes. The first unbounded-to-quit parser process reached its 60-second launcher timeout; subsequent commands use an explicit frame guard plus launcher timeout.

The stronger native hand-bounds test produced seven failures per size from a two-design-pixel left-cuff clip near a quarter turn. Its raw log is preserved as `controls-hand-bounds-red.log`. Camera projected center was moved with the same helper constants; all 98 checks now pass at all three sizes. PNG review also found and fixed completion-number/instruction overlap at 800x600. Driver review found initial tray-handle press incorrectly shifted its target by the handle offset; drag now preserves the actual press offset and has two explicit assertions. Integration worker was notified and changed pointer target construction accordingly.

## Reusable helpers

All are static on `CookieMoldView`:

- `design_point(point: Vector2, depth: float = 0.0) -> Vector2`: work x/y and explicit model depth to the 1280x720 design plane.
- `work_point(point: Vector2, depth: float = 0.0) -> Vector2`: inverse at the stated depth.
- `mold_handle_point(state: Dictionary) -> Vector2`: actual handle projection. For target geometry only, duplicate a snapshot and set its `mold_angle` to the desired angle, press the real current handle then move to this helper's target point.
- `mold_angle_at(point: Vector2, state: Dictionary) -> float`: inverse mold handle angle.
- `edge_world(state: Dictionary, index: int) -> Vector3` / `edge_point(state: Dictionary, index: int) -> Vector2`: shared real polygon-midpoint position including thickness, adhesion gap and polygon depth. `edge_at(point, state)` uses those same projections.
- `tray_point(state: Dictionary) -> Vector2`: actual right handle at `tray_x + 1.4`. Press current helper point; for target geometry duplicate snapshot, set `tray_x=desired_x`, then move to `tray_point(target)`. Grab offset is preserved, including non-center initial presses.
- `button_rect(command: String) -> Rect2`: one of `turn_left,turn_right,previous,next,tap,tray_left,tray_right,helper,retry`.

Keyboard owns all simultaneously held keyboard actions as one conceptual owner. Pointer owners are `mouse` or `touch:<index>`; another device/finger cannot steal or cancel an owned action. Touch-emulated mouse is rejected. Cancel/focus/pause/removal/reset clears charge without a hit. Shift+Tab release retains the originally pressed direction even after Shift is released first. Actual Session/native Main code must present after input before capture so retained geometry follows the latest snapshot.

## Images and remaining boundary

`controls-800x600/`, `controls-1280x720/`, `controls-1920x1080/` each contain `01-initial.png`, `02-gap-crack.png`, `03-rotated.png`. These are standalone native workbench evidence, not Main tutorial captures or reward/persistence evidence. Root owns final Main captures, integration review, strict marker registration, packaging, PM and Git delivery. No Main/award/persistence success is claimed here.

## SHA-256

| File | SHA-256 |
|---|---|
| `game/minigames/cookie_mold_driver.gd` | `a11ded224ec12a0fa9fbd80e73de2bba6a5ffdab75060186d0fe2ac331be4fab` |
| `game/minigames/cookie_mold_view.gd` | `8b09a3cb506bf7606f4532256fd68862ba02dbb4573e658a4715e1a8ec8f6647` |
| `game/tests/test_cookie_mold_driver.gd` | `6ef6a0eb5ed24d24643ee24fbf1507fc12602152cd7be01153f8e45799f502f9` |
| `game/tests/test_cookie_mold_view.gd` | `763643da094841ea0ad9cb20d8c726c9bccd1ce274c567794e47b9e4f08acc8b` |
| `game/tests/native_cookie_mold_workbench_review.gd` | `b322030fc947480e5ba441122ffc2b19bd12d94929b06debd7d728de1e45f9d8` |
| `game/tests/native_cookie_mold_workbench_review.tscn` | `d36d33d093921c9aae233828af1fb9d95ead5b9e2bbdc6af2f570194fd84d85c` |

## Fix round 1: idle right hand obscured cookie/cue

Fresh review confirmed P2: the idle right hand hovered across the upper cookie and selected cue although no charge was active. The minimal repair adds `snapshot.charging` to the existing over-edge pose condition. All other frames use the existing tray-handle resting pose; left grip, driver/model APIs, physical inputs and geometry remain unchanged.

Added projected mesh-bounds assertions require the visible idle right hand to clear both the cookie silhouette with a four-pixel margin and the selected cue. Checks cover the initial state and every one of the six actual shape transitions. Before the production edit, the exact headless command produced **Cookie mold view: 176 checks, 7 failures**, exit 1. Raw output: `controls-round1-red.log`. After the one-condition edit it produced **Cookie mold view: 176 checks, 0 failures**, exit 0, no engine errors; raw output: `controls-round1-green.log`.

Commands used the same validated launcher and exact `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe`:

- Headless arguments: `--headless --path <root> --script res://game/tests/test_cookie_mold_view.gd --quit-after 120`, timeout 30 seconds; isolated absolute `SNAPLAND_SAVE_PATH=<root>/.review/cookie-mold-20261118/controls-round1-{red,green}-save.json`.
- Native arguments: `--path <root> res://game/tests/native_cookie_mold_workbench_review.tscn --quit-after 800`, timeout 45 seconds; isolated absolute save `controls-round1-<size>-save.json`, `SNAPLAND_COOKIE_WORKBENCH_SIZE=<size>`, absolute `SNAPLAND_COOKIE_WORKBENCH_OUTPUT=<root>/.review/cookie-mold-20261118/controls-round1-<size>`.
- Native output: **Cookie native workbench: 98 checks, 0 failures** for each of `800x600`, `1280x720`, `1920x1080`, exit 0, no engine errors. Logs: `controls-round1-<size>.log`. Existing actual rotation/all-mesh hand bounds and nine action checks pass unchanged. 800x600 retains 125% text and reduced motion.

Actual idle PNGs are `controls-round1-<size>/01-initial.png` and `controls-round1-<size>/02-gap-crack.png` for all three sizes. The 1280 gap/crack PNG was visually inspected: upper cookie, adhesion points and selected ring are uncovered; left hand still grips the mold and the right hand remains visible at the tray handle. `03-rotated.png` preserves the real continuous rotation pose evidence.

Driver source/tests were unchanged, so its previous **34 checks, 0 failures** result was retained rather than rerun. Native fixture source was unchanged, still SHA-256 `b322030fc947480e5ba441122ffc2b19bd12d94929b06debd7d728de1e45f9d8`. This round verifies the local view only; Main/tutorial evidence and fresh scoped re-review remain root-owned.

Updated SHA-256:

| File | SHA-256 |
|---|---|
| `game/minigames/cookie_mold_view.gd` | `d876712e4e1252e948b5477650cd22574033bb1b47c3d567534be57021972fee` |
| `game/tests/test_cookie_mold_view.gd` | `62f7ff430381a3572854be338197399d85a00f0ae1d2a95a61d046dc2828d339` |
