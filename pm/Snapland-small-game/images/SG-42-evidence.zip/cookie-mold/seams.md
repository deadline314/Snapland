# SG-42 integration preflight

Read AGENTS.md, pm-ticket and SG42. Read-only production inspection; only this report is owned/changed. No Git, PM, engine runs or agents. Model/driver/view contract is pending; `cookie_mold` below must match the frozen contract.

## Identity and baselines

Add game-026 as candy local2, photo-candy-game-2, photo-candy-devil-2, ACH_GAME_026. Preserve all25 existing definitions, ordered IDs, score goldens, 40-coin first-card receipt and photo provenance. Keep global candy start25, welcome/harbor12 each, candy planned12, zone18 ordinary/12 devil and final gate180. Existing itemdefs already contain both fixed026 entries; no new item definition needed.

## Production ownership proposal

| File | Required integration |
| --- | --- |
| game/data/candy_games.json | Append full026 row with fixed zone/local2 and frozen action/ordinary/devil wording; Catalog requires every TEXT_FIELDS string. |
| game/core/game_catalog.gd:5 | ZONE_COUNTS.candy1->2; ZONE_STARTS.candy25 stays. Identity/validation already generic. |
| game/minigames/session.gd:31 | One DRIVERS entry for final cookie driver; existing shared lifecycle/HUD/result paths should suffice. |
| game/world/candy_world.gd:82-89 | Preserve all6 interactions, add seventh reachable cookie point near workbench and truthful sign. Existing sugar sign says1/12; present2 delivered games. Do not replace material observer. |
| game/main.gd:2374,2388 | Root-selected guide: candy ticket item becomes 工廠圖解教學; _show_region_tutorial opens existing _open body and two-column Paper buttons from Catalog.definitions(candy), each binds _open_tutorial(id,'ticket'), with _back. Other regions retain park lesson. |
| game/main.gd:1450 | Rules currently promise all natural ends ordinary. If cookie uses participation policy, give truthful sugar/cookie copy; preserve other games' policy. _candy_info_text, regional games page and map already derive counts/catalog. |
| game/ui/tutorial_catalog.gd:7 | Append game-026 EXPECTED_LESSONS. |
| game/data/tutorials.json | Append3-step cookie lesson with title/alt/goal/input/success/image, truthful participation and actual inertia qualification. |
| assets/ui/tutorials/game-026-step-01.png ..03.png | Real native1280x720 captures; tutorial and retake require imported PNGs. |
| game/ui/retake_panel.gd:12-20 | PROPS currently exactly25 rows indexed global ID-1. Append26th row with3 existing atlas keys, or _load_set fails closed and actual shutter cannot open. Reuse existing labels/assets. |
| game/ui/collection_book_panel.gd:411 | Participation copy is sugar-only. Include cookie if policy matches. Regional card generation already generic. |
| tools/verify_design.py:12 | CANDY_DELIVERED1->2; retain exact count/sequence checks. |
| design/02-minigames/catalog.json |026 implementation=single_player_runtime_needs_full_acceptance plus runtime_mode; name/action/goal/demon exactly match live name/instructions/ordinary/devil.027 onward stays design-only. |
| design/02-minigames/catalog.md | Align026 frozen control/ordinary/devil/assist wording. |
| design/runtime/full-game-delivery.md | Add SG42/026; total26/remain102, candy2 open/10 planned; retain partial-delivery caveat. |
| tools/run_game_tests.py | Register cookie model/driver/view/Session/Main and native fixture preflight, once each, with exact clean success markers. |
| tests/test_runtime_result_contract.py | Add cookie strict completion/entrypoint tests using SugarRunnerTests; retain existing sugar exact markers and diagnostic rejection. |

No production edits expected in Progress, achievement_stamp_book or harbor_map_panel: rewards/save/tutorial IDs/attempts derive Catalog; stamps derive actual region games; map uses world snapshots. Verify via integration rather than duplicate logic.

## Session driver contract already present

Sugar driver interface: reset(assisted,time_phase), create_view(), handle_input(event,design_point), clear_input(), step(delta), snapshot(), present(time_phase,reduced_motion), score_summary(practice). Snapshot requires elapsed/score/mistakes, ended/success/devil/ordinary_eligible; HUD time_text/progress_text/feedback_text. _finish suppresses ordinary in practice. Session already owns pause, blur, resume-delta discard, retry, cancellation, one completion. Driver owns source ownership. Headless view returns null. Retry reuses driver/view; new start frees old view. New tests should prove these paths.

## Exact stale tests: update without weakening

- test_game_catalog.gd:19 candy1/all25->2/26; retain welcome/harbor12 and all025-and-earlier golden identities. Add full026 ID+mode identity/name. Dynamic next-undelivered already becomes027. Add candy missing-second/duplicate/wrong-local/extra-third parser cases.
- test_sugar_bridge_main.gd:30 all25->26; :131 album1->2. :91 absence photo-candy-game-2 remains valuable isolation; only message changes from upcoming to other game. Sugar400/500, collected1, +40 and provenance assertions remain.
- test_sugar_bridge_session.gd:140 rejected026->027. Keep exact21 checks and all sugar routes.
- test_candy_world.gd:55 points6->7; :58 whitelist add026; :65 gamepoints1->2 and assert both names. Existing route/collision/actual-selection loop validates new point.
- test_region_travel.gd:223 candy album1->2+both names; :227 [18,12,1]->[18,12,2]; :235 stamp1->2+names; :238 info1/12->2/12. :242 direct sugar lesson becomes two-game selector and both target/lifecycle assertions.
- test_retake_panel.gd:37 invalid026->027. Existing all_definitions loop automatically checks026 real3 props and enabled shutter; do not fake _valid.
- test_participation_results.gd:21 all-delivered loop injects real input only for sugar. Add a real cookie input per frozen policy before natural timeout; do not set ordinary_eligible=true in natural path. Cookie suite must separately prove idle-negative.
- tests/test_design_validation.py:87 first-unbuilt index25->26 (game027). Preserve scope rejection.
- tests/test_design_validation.py:120 add exact second scope/mode alongside first; reverting either delivered row to design-only must fail.
- tests/test_design_validation.py:128 use full2-row clones for wrong second ID/zone/local, reorder, duplicate, missing second, extra027. Singleton malformed cases still reject length but no longer demonstrate second-row field validation.
- tests/test_design_validation.py:140 runtime drift must cover both delivered candy rows, regex respective game025/026 for name/action/goal/demon/runtime_mode.
- test_tutorial_panel/test_tutorial_paged_viewport dynamically cover EXPECTED_LESSONS and layout; new PNGs must genuinely load.
- test_retake_native_fixture dynamically checks actual lesson PNG dimensions; new assets must load. native_tutorial_depth_review dynamically enumerates lessons (its printed imported_screenshots=42 is old cosmetic text, not cookie evidence).
- native_pixel_tutorial_assets.gd:37 has old literal13 lessons; old generator is absent from current runner. Do not repurpose for026; native_sugar_bridge_main captures actual current game.
- Runner sail-view25/cargo-view26 are unrelated fixed check-count goldens. Preserve them. test_runtime_result_contract demands sugar63/51/55/21 markers; changing global counts does not justify relaxing these.

## Best TDD and native fixtures

- test_sugar_bridge_session.gd: new cookie Session scaffold for routing, headless/GPU ownership, elapsed, pause/no accidental action, frozen timer, suspended-delta discard, blur, retry, idle/participated timeout, real practice/assist/devil/ordinary, cancel, unknown027 and HUD. Replace solver with real frozen commands, never model mutations.
- test_sugar_bridge_main.gd/.tscn: candy integration scaffold for admission, real point/map, first lesson, idle/participated failure, ordinary/devil/practice/cancel, dedupe/+40, selected retake originals/thumbnails, reload. Assert local2 and existing025/harbor unchanged. Its _retake_capture(Image fixture) proves persistence only.
- native_sugar_bridge_main.gd/.tscn: GPU/isolated paths/3 supported sizes, admission-only synthetic seeds, real input, step/screenshot outputs, actual free-retake shutter, fresh-process read mode. Must obtain actual PNG from actual shutter.
- native_tide_lock_main preflight and test_retake_native_fixture show adjacent-helper/external packaging checks if separate cookie route helper is introduced; no absolute source fallback.

Integration worker should own only data/catalog/Session registration, Main/CandyWorld/retake/tutorial/collection, tests listed above, validator/runner contracts and delivery docs. Gameplay worker owns model/driver/view and corresponding pure tests. Native-evidence owner owns cookie native fixture and actual tutorial captures unless root combines ownership. PM/images/Git stay root-owned. Retain all others' edits.

No tests/engine or human playtest performed. Risks: missing26th PROPS row/real tutorial PNG blocks actual shutter; ordinary policy leaks through legacy fixtures/copy; broad25 replacement breaks stable IDs/goldens; new point overlap defeats real interaction.
