from pathlib import Path
import subprocess,sys
root=Path.cwd();runner=root/'.review/cookie-mold-20261118/run_native.py'
for size,mode,tag,profile in [
 ('800x600','assisted','final',None),
 ('1280x720','ordinary','final',None),
 ('1920x1080','devil','final',None),
 ('1280x720','timeout','final',None),
 ('1280x720','retake','final',None),
 ('1280x720','read','ordinary',root/'.review/cookie-mold-20261118/1280x720-ordinary-final/profile/progress.json'),
 ('1280x720','read','retake',root/'.review/cookie-mold-20261118/1280x720-retake-final/profile/progress.json')]:
 args=[sys.executable,'-X','utf8',str(runner),size,mode,tag]
 if profile:args.append(str(profile))
 subprocess.run(args,check=True)
