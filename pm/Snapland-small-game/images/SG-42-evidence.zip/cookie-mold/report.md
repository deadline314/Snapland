# SG-42 delivery evidence

Automated real Main input/GPU and fixed-step physical motion; not human play/listening or hardware performance certification. Only six Welcome admission cards are synthetic; no target score, phase, adhesion, catch or challenge proof is injected. All code-driven input uses the same public model/driver/Session paths as play.

## Source and checks

Model1209, driver34, view176, Session21 checks passed; real model gentle/inertial routes in two configs plusassist, and full keyboard/mouse/owned-touch routes catch six actual cookies.15 distinct affected Godot suites passed across builders/root, including previousSugar400/500 and all26participation.44Python design tests and50completion/entry/shard contracts passed. Strict marker suffix/error/early-exit rejection retained. New026design/runtime rows align and027 stays unbuilt.

All26 real themed retake sets become valid and can reach enabled shutter; Main synthetic persistence fixture first asserts that readiness.27lessons/5semanticfields/3sizes125% pass after shortening only026ordinary text (252px vs242 clip was caught, not relaxed). Existing deliberate missing-image negative fixture warning is not a production026warning.

## Visibility correction and honest history

First real Main1280 asset-first naturally produced800, but root/reviewer confirmed idle hand obscured cookie/cue. Originalimplementer round1one-condition repair restricts over-edgepose to charging; actualprojection assertions RED176/7 ->GREEN176/0, native98/0 eachsize andfreshscopedrereview accepted. Later asset-visible recaptures are final: exposedloosenedmold, actualdoublelayerflight separated by0.18physicalseconds, natural800result. Three actual1280PNG sources copied unchanged and imported. Earlier candidates remain historical, not finalvisualacceptance. Preimplementation controlRED was not captured; parser/nativehandbounds/visibilityREDlimitations are stated in controlsreport.

## Native final cases

See native-final-verdict.json.800x600125%text/reduced assisted800;1280gentle700;1920inertial800; participatedtraymovementtimeout0; actualselecteddevilretakewith arranged-set original pixel equality; ordinary andretake coldreads all passed. Root manually inspected finalMainmold/flight/result plus800/1920 controlimages. Single activecookie/tray and boundedshape/handgeometry remain; clear/cancel doesn't knock.

## Private standalone

New task-owned D:/Snapland-QA/20261118-cookie-mold-2a75381f avoids copying another large stage onto space-limited C. It contains runtime-only source and exactly3allowlistednativefiles (cookieentryscene/script plus sharedsugarbase). EmbeddedWindowsQA boots from clean release directory without loose project/scene/path override.1188runtime/fixture resources match currentfrozen source hashes, binarySHAverified. Actual800writer/coldreader plus actualshutter/coldreader all exit0/noERROR/no missing026PNG. This privateQAentry is not a published player installer; manifests/captures accompany evidence.

## Reviews and CI boundary

Fresh model, controls, integration and most-capable wholebranch source reviews pass with0openP1/P2. Exactmovingtray/thicknessrim and sixthcatch-at-deadline combinations remain numerical coverage limits, not found defects. No engine reruns by reviewers are claimed.

Previously discovered main CI fixture errors were separately delivered as MAIN29(5594015) andMAIN30(d233d1f), each withcausalRED/GREEN andownpush. Latestmainrun44127544526 has another intermittent existingNPCdialogue exit-resource failure under MAIN31; itsdiagnosis is independent andmustnotbehidden byrelaxing checks. FullSG42remoteCI followsdelivery; localaffectedchecks/privateQA are what this evidence establishes.

## Retained artifacts

Automatic policy rejected recursive removal of oldcompletedC QAprojectdirectories. They remain untouched; no alternate-shell deletion retry. Distinct superseded oldMAIN26binary was removed only after recordedSHA verification and newer acceptedSG41binary preservation. Own sparseMAIN29/30worktrees were removed viaGit afterremote-main ancestry verification. No player's save is used.
