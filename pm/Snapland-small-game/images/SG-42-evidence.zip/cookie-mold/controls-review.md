# Cookie mold Task 2 fresh controls review

Verdict: PASS after scoped round 1 re-review. The idle-hand P2 is ADDRESSED; no new P1/P2 breakage found in the one-condition fix or added visibility assertions. This is source review and inspection of existing engine evidence/PNGs, not a new engine run or human playtest.

## Scope and method

Read root AGENTS.md, pm-ticket, the frozen `design/runtime/cookie-mold-gameplay.md`, Task 2 and global/review constraints in `docs/superpowers/plans/2026-11-18-cookie-mold.md`, all six Task 2 files, and `controls-report.md`. Inspected the five final driver/view/native logs, the actual 800x600 gap/crack and 1920x1080 rotated PNGs, and root-supplied actual Main `1280x720-asset-first/loosened-mold.png`. Read the existing Session input/pause/layout/exit hooks only to check lifecycle and shared-HUD assumptions. No production, PM, Git, runner, engine, editor, GPU, save, or other workers' files were changed or launched.

## Initial finding (addressed in round 1)

### [P2] Move the neutral right hand clear of the cookie and selected edge

`game/minigames/cookie_mold_view.gd:384`–387: the over-selected-edge hand pose is selected whenever phase is molded and the tray is at target. It does not require charging, so releasing a tap leaves the opaque articulated hand across the cookie and selected cue indefinitely. Root supplied actual Main evidence `1280x720-asset-first/loosened-mold.png`: with an empty charge bar, angle 0 and selected edge 5, the hand covers the upper shape/edge area that the player needs to identify the six physical shapes and choose/observe loosened corners. The standalone 800 capture shows the same overlap at smaller scale. This is a causal visibility defect in a precision edge-selection game, beyond an aesthetic preference.

Keep the left gripping hand and articulated meshes. Place the neutral right hand clear of the projected polygon/selection area, and reserve the over-edge pose for the active charge/strike gesture. Add a bounded idle-pose projection or equivalent visible assertion, then rerun the affected view/native checks and Main PNG at 800/125%, 1280 and 1920. Current tests establish mesh bounds and matching edge projections, but they do not detect foreground hand occlusion of those edges.

## Other checks

- Keyboard: driver `handle_input`/`_command` share the model operations with pointer buttons; A/D and arrows use bounded delta targets; Space releases once; echo is ignored; Tab release resolves the originally held next/previous action even when Shift is released first. Holding turn/slide/tap together uses the one keyboard owner rather than conflicting device owners.
- Ownership: mouse and indexed touch cannot replace an existing driver owner. Pointer release clears owner/gesture/held state before applying one final release; cancel, nonfinite release, clear, reset, tree exit and focus loss cancel charge without a tap. Emulated mouse is explicitly filtered. The view's local pointer state is cleared by driver lifecycle clear, including synchronous retry clear. Session pause/leave/exit calls clear, guards unhandled input, disables pointer access, and moves focus into the pause controls; resume restores play focus.
- Pointer geometry: the shared helpers and actual camera use the same orthographic basis, depth and mold coordinates. Edge markers and hit points derive from the same polygon midpoint, thickness and adhesion gap. Tray drag now stores the real initial grab offset and does not set a target on press; the two new assertions exercise stationary press and subsequent delta movement. Mold handle projection agrees with the mesh's local handle offset and rotating outlet.
- Public input routes: the existing final driver log shows six catches through keyboard, mouse and owned touch (scores 800/700/800; elapsed 23.185/31.382/31.090). Tests choose targets from detached snapshots and issue ordinary InputEvents; they do not inject adhesion, phase, caught count, score or qualifications. Low versus high inertia pointer routes assert distinct devil outcomes.
- Results: score summary takes model score/count/success/devil/mistakes directly, states the floor at zero and actual ordinary/devil rules, and explicitly excludes practice rewards. Helper-only idle timeout is tested without participation or rewards. X retries the actual failed cookie while preserving time, mistakes and configuration.
- Retained view: 32 rim/gap/crack/marker slots, three cookie/filling meshes and a fixed six-entry outline array are allocated once. Presentation only rebuilds finite extrusion meshes on shape/configuration changes, and otherwise updates transforms/visibility. Existing tests cover node/mesh/material stability and teardown. Hand meshes include fixed palms/cuffs, four segmented fingers and wrapping thumbs; motion is derived from model state. There is no decorative camera shake or afterimage motion to leave enabled under reduced motion.
- Fonts and layout: Paper/FontProfiles and physical-scale compensation are used. Nine controls and status guidance remain visible in the inspected 800x600/125% PNG, without the previously reported outline/instruction overlap. The 1920 rotated capture keeps hands, mold and tray within the workspace. View content starts at design y=140, matching Session's measured HUD layout boundary. These standalone PNGs do not establish final Main/header/reward/retake evidence.

## Existing evidence inspected

| Evidence | Exact final output |
|---|---|
| `test_cookie_mold_driver.gd.log` | Godot 4.7.2; 34 checks, 0 failures; exit 0 |
| `test_cookie_mold_view.gd.log` | Godot 4.7.2; 169 checks, 0 failures; exit 0 |
| `controls-800x600.log` | Native workbench 98 checks, 0 failures; exit 0 |
| `controls-1280x720.log` | Native workbench 98 checks, 0 failures; exit 0 |
| `controls-1920x1080.log` | Native workbench 98 checks, 0 failures; exit 0 |

The native script feeds actual on-screen mouse events for all nine actions and rotation, checks physical image dimensions, and projects all eight mesh-bounds corners of both hands over forty poses. The separate view test checks all six shapes' edge projections/hits and retained resources. Preimplementation RED was not captured; the delivery report says so honestly. The later genuine hand-bounds RED is recorded separately. No historical RED is inferred or demanded.

## Reviewed SHA-256

These were independently read with Get-FileHash and match `controls-report.md`.

| File | SHA-256 |
|---|---|
| `game/minigames/cookie_mold_driver.gd` | `a11ded224ec12a0fa9fbd80e73de2bba6a5ffdab75060186d0fe2ac331be4fab` |
| `game/minigames/cookie_mold_view.gd` | `8b09a3cb506bf7606f4532256fd68862ba02dbb4573e658a4715e1a8ec8f6647` |
| `game/tests/test_cookie_mold_driver.gd` | `6ef6a0eb5ed24d24643ee24fbf1507fc12602152cd7be01153f8e45799f502f9` |
| `game/tests/test_cookie_mold_view.gd` | `763643da094841ea0ad9cb20d8c726c9bccd1ce274c567794e47b9e4f08acc8b` |
| `game/tests/native_cookie_mold_workbench_review.gd` | `b322030fc947480e5ba441122ffc2b19bd12d94929b06debd7d728de1e45f9d8` |
| `game/tests/native_cookie_mold_workbench_review.tscn` | `d36d33d093921c9aae233828af1fb9d95ead5b9e2bbdc6af2f570194fd84d85c` |

Skipped: new engine/GPU execution and end-to-end Main, award, persistence and packaged-game verification, all outside this scoped readonly review. Remaining risk: scripted source/evidence review cannot establish human usability or replace root's final Main/integration captures. Original hashes above document the initial reviewed state; round 1 current hashes and verdict below supersede it.



## Scoped round 1 re-review

Status: **ADDRESSED**. The production change is the requested single added `and _snapshot.charging` condition at view line 384. Without charge the existing visible tray-handle resting pose is used; the same over-edge charge pose, left gripping hand, input routes and bounded geometry remain. No driver/model/API/scoring change is required or present in this fix.

Inspected the new `projected_bounds` and `idle_hand_clear` checks: they project all eight corners of visible hand/cookie meshes through the actual camera, assert separation from the cookie silhouette plus four design pixels and the selected cue, and require the hand itself to remain visible. Seven assertions cover initial presentation plus the six real shape transitions driven by the existing public model route. This directly detects the reviewed occlusion rather than merely testing the new condition.

Inspected raw exact-Godot 4.7.2 logs: `controls-round1-red.log` reports 176 checks, 7 failures, exit 1; `controls-round1-green.log` reports 176 checks, 0 failures, exit 0. Each `controls-round1-{800x600,1280x720,1920x1080}.log` reports 98 native checks, 0 failures, exit 0. Thus the existing nine action routes and all-mesh hand bounds during actual continuous rotation still pass. The unchanged driver retains the reviewed 34-check result; no rerun is claimed.

Personally inspected `controls-round1-800x600/02-gap-crack.png`, `controls-round1-1280x720/01-initial.png`, and `controls-round1-1920x1080/02-gap-crack.png`. The resting right hand now sits visibly at the tray; the star cookie, adhesion points, crack/gap cue and selected ring are uncovered. Left grip and all visible controls remain. These are standalone native captures, and final Main recapture remains root-owned.

Independently verified current SHA-256:

| File | Current SHA-256 |
|---|---|
| `game/minigames/cookie_mold_view.gd` | `d876712e4e1252e948b5477650cd22574033bb1b47c3d567534be57021972fee` |
| `game/tests/test_cookie_mold_view.gd` | `62f7ff430381a3572854be338197399d85a00f0ae1d2a95a61d046dc2828d339` |

Only this review report was changed during re-review. No engine/GPU, Git, PM or production edits were performed. No additional P1/P2 finding was established within the fix scope.
