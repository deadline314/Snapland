# SG42 Task 1 fresh model review — 2026-11-18

## Verdict

No actionable P1/P2 implementation defect found in the reviewed model and public-operation tests. Task 1 is acceptable on the inspected evidence. This is independent source/spec review; I did not run an engine or perform graphical/human playtesting.

Scope: root AGENTS.md and pm-ticket; frozen design/runtime/cookie-mold-gameplay.md; Task 1 and global constraints of docs/superpowers/plans/2026-11-18-cookie-mold.md; game/minigames/cookie_mold_model.gd; game/tests/test_cookie_mold.gd; model/report.md and model/green.log. Integration, MAIN-29, PM, Git and other workers' implementations were excluded.

## Evidence and reasoning

- Geometry (model lines 30–76): six genuinely distinct bounded polygons, concavity-aware local edge samples, variant B's concave-vertex contraction, and whole double-layer thickness including filling. Tests independently triangulate every visited polygon, check radius/capacity, and visit all six slots in all eight real routes. Both polygon winding directions are handled by the signed-area concavity test.
- Material response (128–141, 195–213): taps reduce local adhesion and accumulate bounded stress; thickness participates in both adhesion resistance and stress. Crack detection runs before release, and taps do not directly set flying/caught. No pressure/stress healing or result bypass exists. All initial calibration coefficients match the frozen spec.
- Rotation/release (96–102, 175–214): shortest-angle control, wrapped mold angle, bounded angular velocity, inertial coasting, true release velocity and release-time evidence. The candidate requires both angular and inertia/gravity thresholds, and is locked only at physical catch. Failure and cookie reload clear the candidate. The missed-challenge-then-gentle-retry test verifies that failed evidence cannot be inherited.
- Collision (233–276): bounds use every local tangent coordinate and both whole-thickness endpoints; depth is checked separately because rotation remains in x/y. Catch requires a descending bottom-plane crossing, with interpolated position, angle and moving tray center before full-width containment. A missed crossing cannot be caught merely by later horizontal overlap. Caught count and proof change only inside this collision path.
- Lifecycle/qualification (155–173, 217–223, 278–300): free retry retains elapsed time, mistakes and existing six-slot completion; countdown is clipped to the exact remaining duration, and success is resolved before timeout. Helper only follows the mold outlet and never counts as participation. Assistance affects crack limit and lateral tolerance without bypassing release/catch or disqualifying actual challenge proof. clear_input drops hold/charge without a knock. Cancel/practice award exclusion belongs to Session, outside this model API.
- Boundaries/storage: public float/Vector2 inputs reject nonfinite values before state changes; step caps work at 30 substeps; arrays have fixed geometry/slot bounds and no event history; snapshot duplicates nested containers. Detached-snapshot edits in tests intentionally verify isolation and do not inject live model state.
- Tests use only public actions, step and detached snapshots to generate gameplay. No live phase, adhesion, caught, score or qualification mutation was found. The recorded exact Godot 4.7.2 log reports 1209 checks / 0 failures and eight six-cookie routes: both variants × both assistance settings × ordinary/challenge, with 700/800 scores. I inspected that log rather than rerunning it.

## Material coverage limits (not demonstrated defects)

1. The collision tests distinguish center-only catching and late overlap, but do not isolate the moving-tray interpolation decision within one crossing substep or distinguish whole double-layer thickness from a single-layer collision envelope at a tray rim. A boundary-focused public-input fixture would protect these explicit contracts; ordinary centered successful double-layer routes would also pass if thickness were accidentally omitted from collision bounds. Current model lines 240 and 254–261 implement the contracts correctly on inspection.
2. The tests cover ordinary success well before the deadline and participated timeout, but not the sixth catch during the final clipped substep. An input-only replay delayed before its final release should pin the specified catch-before-timeout tie behavior. Current model lines 176–178 and 215–223 implement the required ordering correctly on inspection.

Neither gap is evidence of a present P1/P2 bug. No speculative implementation changes requested.

## Reviewed source identity

- Model SHA256: 0e843735a4b11860a9fdfd7b5bfbbd24f8748e39a546e5d08b2672f8db802ccd
- Tests SHA256: edc167fa36b267f9a669e5160a62999cb0c23fd14361cdb5a13d456c87555bbe

Skipped engine reruns, native/view/integration verification and full-suite testing per assigned review scope. Residual risk is the two unpinned numerical boundary cases above; this report does not establish native gameplay or end-to-end award acceptance.
