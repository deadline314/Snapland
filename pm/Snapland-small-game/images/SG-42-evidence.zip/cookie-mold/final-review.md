# SG42 final whole-branch source review

Verdict: **PASS for source review; no actionable P1/P2 findings.** Reviewed the current SG42 working tree over branch `codex/cookie-mold-20261118`, base HEAD `ccddd9a`, on 2026-11-18. Final runtime/package acceptance remains root-owned and pending; this report is not a human-playtest, listening, export, or fresh engine result.

## Scope

Read AGENTS.md and pm-ticket; authoritative `design/runtime/cookie-mold-gameplay.md`; implementation plan and SDD progress ledger; the model, controls and integration review reports; all three production cookie modules and their public-operation tests; Session dispatch/input/pause/results; changed Main, CandyWorld, GameCatalog, JSON, tutorial, collection and retake paths; affected regression fixtures; native Cookie/Sugar capture inheritance; runner/validator registration and export presets. MAIN-29/30 duplicate branch patches were treated as already-delivered baseline repairs, as instructed, not feature scope findings.

## Conclusions

- **Physical rules and qualification:** Six bounded, distinct polygons and concavity-based edge adhesion feed both model and visible geometry. Whole double-layer thickness participates in resistance, stress and bounds. All scoring and inertial qualification follow actual release and whole-body catch; neither taps nor helper toggles set a result. Crack checks precede release, missed challenge candidates are cleared, completed slots survive current-cookie retry, and time does not refill. Final success is resolved before timeout after clipping the last substep. Input guards reject nonfinite values before mutation, and snapshots detach nested arrays/dictionaries.
- **Collision and bounded work:** The model caps a step at 30 substeps, stores six completion slots and at most 32 edges, and has one flying body. Catch interpolates old/new cookie position, angle and moving tray center at downward bottom-plane crossing, then recomputes full width and checks depth. Late horizontal overlap cannot itself award a catch. No unbounded event/trajectory storage or new dependency was introduced.
- **Input/lifecycle seams:** Keyboard, mouse, touch and drawn controls converge on the same driver/model methods. One owner prevents another device from replacing an active gesture; release clears ownership before the final release action, while cancel clears without tapping. Touch-emulated mouse is filtered. Session pause, blur, retry, exit and ended handling preserve the existing lifecycle. The retained view's hand-occlusion fix is present, with the right hand above the edge only while charging. Shape meshes rebuild only on a bounded shape/configuration change; frame presentation updates retained transforms and visibility.
- **Catalog and rewards:** Ordered delivered coverage is 26, with Candy local 2 mapped to `photo-candy-game-2`, `photo-candy-devil-2` and `ACH_GAME_026`. The original Sugar row is unchanged, 027 remains refused, and planned 18/12 and global 180 targets remain. Existing Progress award/dedup/provenance handling is reused without changing the save format or economy. Main and collection copy now accurately describe Candy participation eligibility. Practice/cancel exclusion remains in Session/Main rather than being bypassed by model success.
- **Entrances, tutorials and retakes:** Candy preserves the old interactions and adds the separate 026 entrance; catalog-driven map/stamps/album and the two-choice factory guide cover both games. The new lesson uses three dedicated image paths and the shortened ordinary eligibility copy. Retake has a real 26th three-prop set. Main tests explicitly require valid set readiness before their labelled synthetic persistence fixture; they do not present that fixture as a real shutter. The native Cookie route separately uses actual parsed input, 1/120 advancement, physical release/catch and the real shutter path.
- **Fixtures, runner and export reach:** All-delivered-game participation explicitly performs Cookie tray input. Catalog, retake and unsupported-game assertions were updated to exact 26/027 expectations while preserving Sugar score/identity checks. Tutorial/native-retake fixture loops derive coverage from the catalog. SaveGuard fixture copies every declared Catalog data source, so adding the second Candy row does not revive the repaired missing-Candy fixture failure. Five Cookie suites have exact completion markers and correct script/scene entrypoints, alongside unchanged Sugar markers. Existing export presets include all resources and runtime JSON; Cookie production preloads/assets have no dependency on excluded test files. Native QA fixture packaging itself remains a root acceptance step.

## Checks performed in this review

- Read-only diff/source inspection and `git diff --check`: no whitespace errors (existing CRLF conversion warning only).
- Read-only Python assertions: original Candy row unchanged; exactly two rows; appended 026/local-2/cookie mode identity correct. One initial subprocess read hit the Windows default-decoding mismatch; rerun with explicit UTF-8 passed.
- All three final tutorial PNGs are 1280x720 and match `tutorial-assets-final.json` SHA-256 values. Personally inspected the current second image: actual Main HUD at 5/6, double-layer flight, controls and six shape indicators are visible. This is image inspection, not new graphical execution.
- Inspected existing logs showing 50 runner/entry/shard Python checks and 44 design-validator checks passed. Prior model/control/integration reports supply their own engine evidence; no engine results are claimed as newly run here.

The earlier suggested boundary fixtures—isolated moving-tray/thickness-rim catch and sixth catch at the exact deadline—remain useful regression coverage, but source inspection established no current defect in either path. They are not escalated into speculative P2 requests.

## Reviewed identity

| File | SHA-256 |
|---|---|
| `game/minigames/cookie_mold_model.gd` | `0e843735a4b11860a9fdfd7b5bfbbd24f8748e39a546e5d08b2672f8db802ccd` |
| `game/minigames/cookie_mold_driver.gd` | `a11ded224ec12a0fa9fbd80e73de2bba6a5ffdab75060186d0fe2ac331be4fab` |
| `game/minigames/cookie_mold_view.gd` | `d876712e4e1252e948b5477650cd22574033bb1b47c3d567534be57021972fee` |
| `game/data/tutorials.json` | `eda321f8ee994a48b96a7003fddb9e6303bc913df39e9f4b7b90092517af4e6b` |
| `game/tests/native_cookie_mold_main.gd` | `a3a6da3a269b39ca733a51adb33dec88fe7713c9464ec91f5d7cf28019972976` |
| `tools/run_game_tests.py` | `89bb8f07a44efb1a99be88a39faa889e0fee7c76c92707eebca1623e73cfdfe8` |

Only this review report was written. No production, PM, Git, engine, editor, GPU, save, package or agent mutation was performed.

Skipped fresh engine/full-suite, complete visual/real-shutter/cold-restart and packaged-runtime checks. Residual risk is final artifact/runtime acceptance plus the two unpinned numerical boundaries; root must finish its current evidence before delivery claims.
