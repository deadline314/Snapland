from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from tools.build_desktop_release import prepare_runtime_stage
from tools.godot_entrypoints import run_validated_godot
base=Path('D:\\Snapland-QA\\20261118-cookie-mold-2a75381f')
assert not base.exists();base.mkdir(parents=True);stage=base/'project';stage.mkdir();release=base/'release';release.mkdir()
tracked=subprocess.check_output(['git','ls-files','-z'],text=True,encoding='utf-8').split('\0')
new=['game/data/candy_games.json']+[f'game/minigames/cookie_mold_{kind}.gd{suffix}' for kind in ['model','driver','view'] for suffix in ['', '.uid']]+[f'assets/ui/tutorials/game-026-step-{i:02d}.png' for i in range(1,4)]
hashes=prepare_runtime_stage(ROOT,stage,sorted(set(tracked+new)))
for name in ['native_cookie_mold_main.gd','native_cookie_mold_main.tscn','native_sugar_bridge_main.gd']:
 relative='game/tests/'+name;target=stage/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/relative,target);hashes[relative]=hashlib.sha256((ROOT/relative).read_bytes()).hexdigest()
p=stage/'project.godot';p.write_text(p.read_text(encoding='utf-8').replace('res://game/main.tscn','res://game/tests/native_cookie_mold_main.tscn'),encoding='utf-8')
p=stage/'export_presets.cfg';p.write_text(p.read_text(encoding='utf-8').replace('game/tests/*,',''),encoding='utf-8')
engine=r'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe';exe=release/'CookieMoldQA.exe'
env=dict(os.environ,SNAPLAND_SAVE_PATH=str(base/'build-profile/progress.json'))
steps=[]
for label,args in [('import',['--editor','--import','--quit']),('export',['--editor','--export-release','Windows Desktop',str(exe),'--quit'])]:
 r=run_validated_godot(stage,[engine,'--headless','--path',str(stage),*args],env=env,timeout=300);log=r.stdout+r.stderr;(base/(label+'.log')).write_text(log,encoding='utf-8');assert r.returncode==0 and 'ERROR:' not in log,(label,log[-5000:]);steps.append({'step':label,'exit':r.returncode});print('PASS private',label,flush=True)
assert exe.stat().st_size>100000000
(base/'build.json').write_text(json.dumps({'source_commit_base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_snapshot_uncommitted':True,'source_sha256':hashes,'steps':steps,'binary':{'file':exe.name,'bytes':exe.stat().st_size,'sha256':hashlib.sha256(exe.read_bytes()).hexdigest()},'scope':'Private embedded Windows QA with exactly three allowlisted native fixture files and actual source snapshot; source main overridden only in QA stage'},indent=2),encoding='utf-8')
for mode,tag,profile in [('devil','writer','qa-profile'),('read','restart','qa-profile'),('retake','retake-writer','retake-profile'),('read','retake-restart','retake-profile')]:
 out=base/tag;out.mkdir();env.update(SNAPLAND_SAVE_PATH=str(base/profile/'progress.json'),COOKIE_CAPTURE_DIR=str(out),COOKIE_REVIEW_MODE=mode,COOKIE_REVIEW_SIZE='1280x720')
 r=run_validated_godot(stage,[str(exe),'--log-file',str(out/'engine.log'),'--rendering-method','gl_compatibility','--audio-driver','Dummy','--fixed-fps','60','--quit-after','10800'],env=env,timeout=185,release_directory=release)
 log=r.stdout+r.stderr+'\n'+(out/'engine.log').read_text(encoding='utf-8');(out/'native.log').write_text(log,encoding='utf-8');(out/'result.json').write_text(json.dumps({'exit':r.returncode}),encoding='utf-8')
 report=json.loads((out/'report.json').read_text(encoding='utf-8'));assert r.returncode==0 and 'ERROR:' not in log and 'screenshot missing' not in log and 'PASS: native cookie Main' in log and not report['failures'],(tag,log[-6000:]);print('PASS standalone',tag,len(report['captures']),flush=True)
