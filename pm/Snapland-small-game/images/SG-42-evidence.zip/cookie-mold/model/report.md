# SG42 Task1 physical model handoff — 2026-11-18

Owned production/test changes only: `game/minigames/cookie_mold_model.gd`, `game/tests/test_cookie_mold.gd`. Root owns PM/Git/shared validation. No dependency, repository copy, stage, save writer, or engine process retained.

## RED and GREEN

Read root AGENTS, pm-ticket, frozen design, plan Task1, progress ledger, TDD and ponytail skills, existing SugarBridge model/test pattern and validated launcher.

Initial missing-model RED executed before production existed: exact engine printed `Cookie mold tests: 1 checks, 1 failures`, expected `physical cookie model must exist for public-operation routes`, EXIT1. Then wrote public operation route tests before model implementation. First implementation parsed and physically completed all eight six-catch routes; one test-only approximate-float comparison needed correction (`0.2` accumulated in substeps).

Additional radius RED: 1199 checks, 32 failures, all frozen maximum-radius checks; fish tail and leaf tip coordinates were slightly beyond0.62. Corrected fish tail vertices from(-0.56,+/-0.32) to(-0.53,+/-0.30), leaf end vertices from(+/-0.56,+/-0.27) to(+/-0.55,+/-0.27). Distinct shape identity and API unchanged. All six polygons triangulate and each vertex is now <=0.62.

Additional stress RED: 1209 checks, 1 failure, expected per-edge material crack-limit bound. Clamped tap/natural stress at the same crack limit; reaching that limit still cracks immediately. Recorded `stress-red.log`.

Final GREEN: exact Godot4.7.2, `Cookie mold tests: 1209 checks, 0 failures`, EXIT0, empty stderr. Full output `green.log`. This is automated public-input model verification, not human gameplay or graphical/native integration acceptance.

Exact final launcher command (PowerShell environment and Python stdin):

```powershell
$env:SNAPLAND_SAVE_PATH='C:/Users/stanl/Github/Snapland/.review/cookie-mold-20261118/model/final2-save.json'
@'
from tools.godot_entrypoints import run_validated_godot
from pathlib import Path
import os
r=run_validated_godot(Path.cwd(), ['C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe','--headless','--path',str(Path.cwd()),'--script','res://game/tests/test_cookie_mold.gd'],env=os.environ,timeout=60)
print(r.stdout);print(r.stderr);print('EXIT',r.returncode)
'@ | python -
```

## Frozen API and geometry

All methods/snapshot fields from design/runtime/cookie-mold-gameplay.md exist. `cookie_angle` uses mold clockwise convention n=(sinθ,cosθ), t=(cosθ,-sinθ); view rotation.z=-angle. polygon is local(u,v): u spans work-plane tangent, v spans z-depth; whole thickness spans normal. Snapshot deep-copies nested arrays/dictionaries. Fixed polygons: star10, heart14, fish12, leaf10, flower30, eight-tooth gear32 vertices. VariantB contracts concave vertices by0.78, uses thicker layers; same polygon drives adhesion and extrusion.

## Replayable actual operation route

Test script exposes **static** `advance(model, seconds)`, `loosen(model)`, `release_cookie(model, inertial=false)`, `catch_cookie(model)`, `solve(model, inertial=false, count=6)` for integration fixtures. Call script static methods directly; do not instantiate another SceneTree. Helpers use only public model actions, step and snapshots; no internal state writes. `solve` count can stop after five real catches for the double-layer fixture.

1. For current molded cookie, choose edge with maximum public adhesion. Select its midpoint through `select_edge_at`, begin tap, advance0.16s in <=1/120s chunks, release tap. Repeat until max adhesion<=0.15, capped180 operations.
2. Ordinary route: every1/120s set mold target to min(PI,0.9*(frame+1)/120), advance1/120s. Stop at actual flying phase. Double-layer gentle release omega~0.9, not devil.
3. Challenge route: first five cookies use ordinary route; after loosening sixth, set target2.8 immediately, advance1/120s until real flight. Actual sixth release omega4.92060rad/s, inertia10.89556 vsgravity1.28425; no proof is set before its catch.
4. While waiting molded after turn, set tray target to snapshot.outlet.x; while flying, set target to actual snapshot.cookie_position.x each1/120s. Physical tray still has4unit/s speed cap; no position/velocity edits or future trajectory targeting. Whole-body swept crossing makes the catch.
5. Caught phase waits0.46s for next real shape. Sixth catch naturally ends.

## Final coefficients

No physics calibration coefficient changed from the frozen starting design. angularcontrol28/7, accelerationlimit22, release damping1.2, maxomega5; gravity7.5, lever0.45; trayspeed4, y=-0.8, halfwidth1.15, depth0.85, assisted tolerance0.22; layerA0.16/B0.21, filling0.035; adhesionbase0.70+0.20notch; charge0.9 and force0.15+0.85fraction; taprange0.95, adhesionloss0.78, stressgain0.40 with notch0.6/upward0.65; resistance12*(1+0.35notch)*wholethicknessratio; pull adhesionloss0.20, stress0.012; release alladhesion<=0.03 andnormal.y<-0.15; exitpush0.08*pull clamped0.25..1.1; cracklimit1.0/assisted1.45 with65% warning; devilactualrelease absomega>=2 andinertia>=0.35gravity followedbywholecatch; timeout150, framecap0.25, <=30substeps of<=1/120; caughttransition0.45.

## Actual eight final outputs

|Variant|Assisted|Route|Caught|Success|Devil|Seconds|Score|Double release omega|Inertia|Gravity|
|---|---|---|---|---|---|---|---|---|---|---|
|A|false|ordinary|6|true|false|31.382|700|0.89999|0.36449|6.16198|
|A|false|inertial|6|true|true|28.607|800|4.92060|10.89556|1.28425|
|A|true|ordinary|6|true|false|31.382|700|0.89999|0.36449|6.16198|
|A|true|inertial|6|true|true|28.607|800|4.92060|10.89556|1.28425|
|B|false|ordinary|6|true|false|34.165|700|0.89999|0.36450|7.16703|
|B|false|inertial|6|true|true|31.090|800|4.92060|10.89556|1.28425|
|B|true|ordinary|6|true|false|34.165|700|0.89999|0.36450|7.16703|
|B|true|inertial|6|true|true|31.090|800|4.92060|10.89556|1.28425|

Additional checks: idle/helper-only timeout no qualification, heavy repeats crack, canceled charging never knocks, repeat begin does not reset charge, cannot change charged corner, coast after release, wrapped short angle, unloosened static inversion stays molded, wrong tray/whole-edge protrusion miss, late tray never retro-catches, helper follows outlet not flight, real failed challenge never grants proof and gentle retry cannot inherit it, retry preserves elapsed/completed/mistakes/variant, tray clamp/speed limit, participated timeout ordinary, ended input freeze, finite guards, frame cap, detached snapshots and60 resets preserving fixed pools.

## Source hashes

- Model SHA256 `0e843735a4b11860a9fdfd7b5bfbbd24f8748e39a546e5d08b2672f8db802ccd`
- Tests SHA256 `edc167fa36b267f9a669e5160a62999cb0c23fd14361cdb5a13d456c87555bbe`

Fresh root review required before dependent acceptance. Full suite, native controls, screenshots, Session/Main persistence/retake and exports remain root/other workers' scopes; this task does not claim those passed.
