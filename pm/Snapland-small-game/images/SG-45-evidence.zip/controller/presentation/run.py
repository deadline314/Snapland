import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from tools.build_desktop_release import prepare_runtime_stage
from tools.godot_entrypoints import run_validated_godot

ENGINE = "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe"
FROZEN_RUNTIME = {
    "game/minigames/chocolate_etching_geometry.gd": "803bc755a1f33c7c0ede31729e8436af8f458cea16eb2fcbe1a8b2f5ebce2fe2",
    "game/minigames/chocolate_etching_model.gd": "abb2c78ddda00dd9a424e89d7a2d2fb9e600c9277f5bcecf2839566748c76bab",
}
PRODUCT = ["game/minigames/chocolate_etching_driver.gd", "game/minigames/chocolate_etching_view.gd"]
DRIVER = "game/tests/test_chocolate_etching_driver.gd"
VIEW = "game/tests/test_chocolate_etching_view.gd"
NATIVE = "game/tests/native_chocolate_etching_workbench_review"
TUTORIALS = [f"assets/ui/tutorials/game-029-step-{i:02}.png" for i in range(1, 4)]
UNITS = {"driver": [DRIVER], "view": [VIEW]}
CHILD_API = re.compile(r"\b(?:execute|execute_with_pipe|create_process|shell_open|shell_show_in_file_manager)\b")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("label")
    parser.add_argument("mode", choices=["import", "driver", "view", "native"])
    parser.add_argument("--import-from", type=Path)
    parser.add_argument("--size", default="1280x720", choices=["1280x720", "1152x648", "800x600"])
    args = parser.parse_args()
    out = Path("D:/Snapland-chocolate-task2") / (datetime.now().strftime("%Y%m%d-%H%M%S-%f") + "-" + args.label)
    stage = out / "stage"
    stage.mkdir(parents=True)
    tracked = subprocess.check_output(["git", "ls-files"], cwd=ROOT, text=True).splitlines()
    tracked = [p for p in tracked if not p.endswith((".uid", ".import"))]
    manifest = prepare_runtime_stage(ROOT, stage, tracked)
    assert all(manifest[name] == sha for name, sha in FROZEN_RUNTIME.items()), "Unexpected frozen Model/geometry bytes"
    fixtures = UNITS.get(args.mode, [DRIVER, VIEW, NATIVE + ".gd", NATIVE + ".tscn"] if args.mode == "native" else [])
    for relative in PRODUCT + TUTORIALS + fixtures:
        source = ROOT / relative
        if source.is_file():
            dest = stage / relative
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, dest)
            manifest[relative] = digest(source)
    assert sorted(p.relative_to(stage).as_posix() for p in (stage / "game/tests").glob("*")) == sorted(fixtures)
    cache_files = {}
    cache_source = None
    if args.import_from:
        cache_source = args.import_from.resolve()
        assert cache_source.drive.upper() == "D:"
        imported = json.loads((cache_source / "receipt.json").read_text(encoding="utf-8"))
        assert imported["mode"] == "import" and imported["exit_code"] == 0 and imported["engine_sha256"] == digest(Path(ENGINE))
        for name, sha in manifest.items():
            if name.startswith("assets/") and name not in TUTORIALS:
                assert imported["source_manifest"].get(name) == sha, name
        old_stage = cache_source / "stage"
        files = [*(old_stage / ".godot/imported").glob("*"), *(old_stage / "assets").rglob("*.import")]
        for source in files:
            name = source.relative_to(old_stage)
            destination = stage / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
            cache_files[name.as_posix()] = digest(destination)
        assert cache_files
    audit = {"files": {}, "candidate_lines": {}}
    for path in sorted(stage.rglob("*")):
        if path.suffix not in {".gd", ".tscn", ".gdextension", ".cs", ".py", ".bat", ".ps1"} or not path.is_file():
            continue
        relative = path.relative_to(stage).as_posix()
        audit["files"][relative] = digest(path)
        if path.suffix == ".gd":
            lines = path.read_text(encoding="utf-8-sig").splitlines()
            hits = [f"{i}: {line}" for i, line in enumerate(lines, 1) if CHILD_API.search(line) and not line.lstrip().startswith("#")]
            if hits:
                audit["candidate_lines"][relative] = hits
    write_json(out / "child-launch-audit.json", audit)
    assert not audit["candidate_lines"], audit["candidate_lines"]
    env = dict(os.environ)
    keys = ["APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "SNAPLAND_SAVE_PATH", "GODOT_BIN", "CHOCOLATE_CAPTURE_DIR", "CHOCOLATE_REVIEW_SIZE"]
    for key in keys[:4]:
        profile = out / key.lower()
        profile.mkdir()
        env[key] = str(profile)
    for name in ("save", "captures"):
        (out / name).mkdir()
    env.update(SNAPLAND_SAVE_PATH=str(out / "save" / "progress.json"), GODOT_BIN=ENGINE,
               CHOCOLATE_CAPTURE_DIR=str(out / "captures"), CHOCOLATE_REVIEW_SIZE=args.size)
    command = [ENGINE, "--path", str(stage), "--log-file", str(out / "godot.log")]
    if args.mode in UNITS:
        command += ["--headless", "--script", "res://" + fixtures[0]]
    elif args.mode == "import":
        command += ["--headless", "--editor", "--import"]
    else:
        command += ["--resolution", args.size, "--position", "10,40", "--max-fps", "60", "res://" + NATIVE + ".tscn"]
    receipt = {"label": args.label, "mode": args.mode, "utc": datetime.now(timezone.utc).isoformat(),
               "command": command, "env": {key: env[key] for key in keys}, "source_manifest": manifest,
               "audit_sha256": digest(out / "child-launch-audit.json"), "fixtures": fixtures,
               "private_import_source": str(cache_source) if cache_source else None, "private_import_files": cache_files,
               "engine_sha256": digest(Path(ENGINE))}
    print(out, flush=True)
    write_json(out / "receipt.json", receipt)
    try:
        result = run_validated_godot(stage, command, env, timeout=240)
        returncode, stdout, stderr = result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired as exc:
        returncode, stdout, stderr = 124, exc.stdout or "", exc.stderr or ""
    (out / "stdout.log").write_text(stdout, encoding="utf-8")
    (out / "stderr.log").write_text(stderr, encoding="utf-8")
    receipt["exit_code"] = returncode
    receipt["written_file_sha256"] = {path.relative_to(out).as_posix(): digest(path) for path in [
        out / "godot.log", out / "stdout.log", out / "stderr.log", *(out / "captures").glob("*")] if path.is_file()}
    write_json(out / "receipt.json", receipt)
    print(stdout[-10000:])
    print(stderr[-10000:])
    return returncode


if __name__ == "__main__":
    sys.exit(main())
