# Rulings I made

Chronological controller rulings, including costs and limitations.

Ruling: use actual cut polygons plus bounded kinematic external gears, not fullCAD/rigid-body engine — meets drawing/material/assembly choices through existingGodot primitives — costs no industrial involute/contact-precision claim or multibody dynamics.

Ruling: retain sourceboard/heatstrips/actual extracted profile and measuredradii, never hand out templates as finishedgears — protects true kerf/thickness/leftover tradeoff — costs stronger finitegeometry validation and calibration.

Ruling: unrestricted retry/undo uses with onlylast8committed operations, no timerefund — preserves trial freedom and boundedmemory — costs inability to rewind older history; teach explicitly and clarify current029catalog assistcopy atintegration.

Ruling: native representative three routes per size plus full24source/variant/assist/outcome unitmatrix — actualfreehand keyboard routes are more costly than sevencommand configurators — costs no all24nativecombinations per size, disclosed; allmodalities represented eachsize.

Ruling: onlylabelledsixwelcome/openingseen/controlledentrance+actualE native setup, and separatelylabelledheadlesssyntheticPNG — validates new029withoutfakeearnedwalking/GPUevidence — costs no fullislandwalking/admission claim.

Ruling: excludeallfourlegacyOSchildparents beforeanynewlocal execution, retainregisteredCI — preventsrepeat of earlierprocessboundaryincident without unrelatedlauncherrewrite — costs localfault-childcoverage, complemented by cleannative/Mainpersistence andfullCI.

Ruling: treat numerical center calculations as preflightonly and initialcut/meshvalues as calibration untilTask1 eightactualpublicroutes — prevents design arithmetic being sold as playthrough — costs possible documentedparameterrework, never success/AI/input weakening.

Ruling: explicit actual-teeth/no-circle requirement overrides overlapping assisted scalar radius bands — add minimum4-unit prominence of allthree measured tip probes above the larger adjacentroot for everytooth, bothmodes, preserving prior radius/depth/contact calibration — costs rejecting formerly accepted low-relief or toothless shapes; actualeightgoodroutes mustremainproven. Authorityupdatedbeforeround1dispatch.

Ruling: require actual maximum-radius fullrotation envelope inside720x440 on every placement — fixes phase/continuousrotation bounds with a bounded one-time check instead of perframe clipping/physics — costs conservatively rejecting static edge placements that could not turn a fullcircle; intendedallgearfullturn promise takesprecedence. Authorityupdatedbeforeround1dispatch.

Ruling: permit only freshly produced same-source exact-engine D assetimportartifacts/metadata copied into separateverifiedDlaunchstages with explicitcopiedfilehashes — avoids repeatedassetimportwhilepreservingisolatedprofiles/sourceaudit — costs staleasset risk ifidentitychecksarewrong; forbid C/oldacceptedcache,script/globalclass/UID/editorcache/whole.godottree andextra cacheframework.

Ruling: reopen only the domaincoreprecision boundary with originalcoreowner whilepresentationremainsfrozen — validactualkeyboard cutsarefalselyrejected, sourcegeometrymathmustbecorrect — costs a focusedcorefollowup/review andfreshfinalUIevidence, notrelaxingEPS/selfintersection/offsetfragment/material/tooth/depth/contactrules. Fixsharedintersectionpredicateforboth segment_distance andmaterial_length, no engine-globalpatch/genericmathframework/pointsmoothing/boundsweakening. ExactinputJSONfixtureauthorizedifneeded formaintainablecapturedtrace replay.

Ruling: onlyforGeometry2D-generatedoffsetresults, removeEXACTconsecutive/closingduplicatepoints withoutmoving/deletingANYnonzeroshortedgepoint, anduseexactboundedintersectiontopology ratherthan drawn-inputEPSminspacing — actualvalidsingletonoffsetswithone-ULPedgesmustnotbediscardedasfragments — costsaseparatedvalidationpolicyforgeneratedrepresentation; truecross/nonadjacenttouch/collinearoverlap,singlecomponent,board,center,area,512cap,allkerf/profile/materialchecks remainrequired. Originalplayerstrokes/EPS/caps/coefficientspreserved. AuthorityupdatedBEFOREcontinuation; no arbitraryfragmentselection orgeometryrepair allowed.

Ruling: Task4 may stage the unchanged existing test_chocolate_etching_driver.gd Route and test_chocolate_etching_view.gd layout checker as explicit additional fixture helpers when needed, rather than duplicate their event/contour sampling/bounds logic into the new native Main fixture — preserves one source of tested geometry/input recipes and no frozen-file edits — costs a larger explicit QA-only fixture closure than the preferred four files; complete closure still audited before every engine/export/exe and excluded from normal player export. For keyboard reuse Route calls driver.step directly, so a minimal fixture-local adapter must route every such step through normal Session._process and expose read-only Driver snapshot/summary, never advance Driver behind Session clock. Native dispatch remains actual parsed events with no _unhandled_input fallback.

Ruling: before Task4 board captures permit existing Session._refresh_hud(true) after normalzero tick — readonly currentactualprogresspresentation resolves throttledsharedHUD13% versusrealboard21% in draft2 — costs explicitlyfixture-forcedfreshHUDratherthannormal10Hzdisplaycadence; no elapsed/geometry/results/rewards/prodcode changes. RootnamedconcreteriskandcheckedSession1009–1025/capture_board, not broadcodefix; sameproducerhandlesfixture.

Ruling: Task4finalnative dispatch adds one normal Session._process(1/120) after every parsed workbench pointer/touch event while Session is valid/live; ordinary paused/ended guards remain — gives explicit simulation time to each discrete movement/cut/drop rather than one-frame batches, satisfying handoff timing without changing gameplay — costs a new fixture sourcegraph/donor and final16processgraph after current800probe, not replaying acceptedTasks2/3whoseimmediatebatchesremainaccuratelydisclosed. No directDriver.step/elapsed/refund/geometry/reward changes, no doubleallpairs; sameproducerapprovedbeforeaction. Current800candidateisprobeonlyuntilsourcefreeze; HUDforce-refreshalreadyapplied.

Ruling: include allthree finalMinor in the same already-neededfinalfixwave (sharedcompletionpercent/nativeexpectedlessonorder/directcollinearprojection) — closesactualsmallprecision/coverageissueswhilefilesarealreadytouchedandavoidsseparatewaves — costs morefocusedassertions/sourcefilesandrenewednewgame/nativedeliveryproof; oldacceptedsourcehistoriesretained, no unrelatedoldgamebroadreplay.

Ruling: authorize monotonic stock-materialrevision plus minimalread-onlyboundedcommittedlinegetter/pullfromModelthroughDriverintoisolatedViewrenderdataonlyonrealmaterialchange — selected-onlysnapshotscannotreconstructotherownersdamagingremainingstockafterfree/undo, and perframefullhistorycopieswouldwastework — costs a narrowadditionalreadcontract/cacheinvalidationresponsibility; invalidatecut/fold/undo/resetwithoutrestoringoldrevision, neverbindliveModel/mutatingcallbacktoView orbuildgenericframework. Maximum4×8×512points; holesclear/readercopiescannotmutateModel; existingcommands/signaturespreserved.

Ruling: park the nonblocking standalone graphical Driver PNG output-path guard for a separate maintenance ticket immediately after SG45delivery — registeredCIisheadless, actualGUIevidenceallusesisolatedabsoluteDpaths, andplayerneverexecutesfixture; finalsingle-wavecapreached — costs unsafefuturemanualGUIfixturecallswithmissing/relativecaptureenv untilfollowup; do not describe thatunsupportedinvocationassafeorcloseitsfutureticketwithoutfix. Noactualacceptedrunorplayersavewastouched.
