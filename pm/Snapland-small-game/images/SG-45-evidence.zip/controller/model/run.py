import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from tools.build_desktop_release import prepare_runtime_stage
from tools.godot_entrypoints import run_validated_godot

label = sys.argv[1]
out = Path('D:/Snapland-chocolate-task1') / (datetime.now().strftime('%Y%m%d-%H%M%S-%f') + '-' + label)
stage = out / 'stage'
stage.mkdir(parents=True)
tracked = subprocess.check_output(['git', 'ls-files'], cwd=ROOT, text=True).splitlines()
tracked = [p for p in tracked if not p.endswith(('.uid', '.import'))]
manifest = prepare_runtime_stage(ROOT, stage, tracked)
owned = ['game/tests/test_chocolate_etching.gd', 'game/minigames/chocolate_etching_model.gd', 'game/minigames/chocolate_etching_geometry.gd', 'game/tests/chocolate_assisted_keyboard_replay.json']
for name in owned:
    source = ROOT / name
    if source.exists():
        dest = stage / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, dest)
        manifest[name] = hashlib.sha256(source.read_bytes()).hexdigest()
audit = {}
for path in stage.rglob('*.gd'):
    content = path.read_text(encoding='utf-8')
    hits = [line for line in content.splitlines() if re.search(r'OS\.(execute|create_process|execute_with_pipe|shell_open)|\.call\s*\(\s*["\'](execute|create_process)', line)]
    if hits:
        audit[str(path.relative_to(stage))] = hits
assert not audit, audit
assert set((stage/'game/tests').glob('*')) == {stage/owned[0], stage/owned[3]}
env = dict(os.environ)
for key in ['APPDATA', 'LOCALAPPDATA', 'TEMP', 'TMP']:
    profile = out / key.lower()
    profile.mkdir()
    env[key] = str(profile)
env['SNAPLAND_SAVE_PATH'] = str(out/'save'/'progress.json')
env['GODOT_BIN'] = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
command = [env['GODOT_BIN'], '--headless', '--path', str(stage), '--script', 'res://game/tests/test_chocolate_etching.gd']
receipt = {'label': label, 'utc': datetime.now(timezone.utc).isoformat(), 'command': command, 'env': {k:env[k] for k in ['APPDATA','LOCALAPPDATA','TEMP','TMP','SNAPLAND_SAVE_PATH','GODOT_BIN']}, 'source_manifest': manifest, 'child_api_audit': audit}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
result = run_validated_godot(stage, command, env, timeout=120)
(out/'stdout.log').write_text(result.stdout,encoding='utf-8')
(out/'stderr.log').write_text(result.stderr,encoding='utf-8')
receipt['exit_code'] = result.returncode
(out/'receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(str(out))
print(result.stdout)
print(result.stderr)
sys.exit(result.returncode)
