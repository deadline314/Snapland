"""Record the focused fix and verify the immutable Task 3 evidence."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
REPORT = ROOT / '.superpowers/sdd/2026-11-18-chocolate-etching/task-3-report.md'
BASE = '451c39318a4f0c76f6fafc188a1936bf14ece1a9'
PATHS = ['design/02-minigames/catalog.json', 'design/02-minigames/catalog.md', 'game/tests/test_chocolate_etching_main.gd', 'tests/test_runtime_result_contract.py']
PYTHON_LOGS = ['fix1-design-games.log', 'fix1-design-links.log', 'fix1-runtime-contract.log']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_index(path):
    return json.loads(path.read_text(encoding='utf-8'))


old = HERE / 'evidence-index.json'
assert sha(old) == '2bf71265c3f9b547f67fbdc13d9472c5aa06b75e2979502fa2068ee11f52062a'
count = 0
for history in load_index(old)['runs'].values():
    for item in history:
        receipt = Path(item['receipt'])
        assert sha(receipt) == item['sha256']
        for filename, digest in item['raw_artifacts'].items():
            assert sha(receipt.parent / filename) == digest
        count += 1
assert count == 49

before = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert before == BASE
changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=ROOT, text=True).splitlines()
assert sorted(changed) == sorted(PATHS)
sources = {name: sha(ROOT / name) for name in PATHS}
catalog_json = load_index(ROOT / PATHS[0])
policy = catalog_json['games'][28]['demon_assist_policy']
assert 'game-029' == catalog_json['games'][28]['id'] and f'| 輔助與惡魔 | {policy} |' in (ROOT / PATHS[1]).read_text(encoding='utf-8')

index = HERE / 'fix1-main-index.json'
launches = load_index(index)
assert [r['job'] for r in launches] == ['version', 'import', 'test_chocolate_etching_main']
for item in launches:
    receipt_path = Path(item['receipt'])
    assert sha(receipt_path) == item['sha256']
    receipt = load_index(receipt_path)
    assert not receipt['result'] and not receipt['errors'] and not receipt['leaks'] and receipt['contract_error'] is None
    assert receipt['source_manifest'][PATHS[2]] == sources[PATHS[2]]
    item['fixture_allowlist'] = receipt['fixture_allowlist']
    item['raw_artifacts'] = receipt['receipt_artifacts']
    for filename, digest in item['raw_artifacts'].items():
        assert sha(receipt_path.parent / filename) == digest
    audit = load_index(receipt_path.parent / 'prelaunch-audit.json')
    assert not any(row['process_calls'] or row['unstaged_fixture_references'] for row in audit)
    item['audit_rows'] = len(audit)
    log = receipt_path.parent / 'godot.log'
    lines = log.read_text(encoding='utf-8').splitlines() if log.exists() else []
    diagnostics = Counter()
    for line in lines:
        if not line.startswith('WARNING:'):
            continue
        if line.startswith('WARNING: OcclusionController: unsupported'):
            diagnostics[line.split(' building material on ', 1)[0]] += 1
        else:
            diagnostics[line] += 1
    assert sum(diagnostics.values()) == item['warnings']
    item['warnings_by_diagnostic'] = dict(diagnostics)

main = launches[-1]
assert main['warnings'] == 45
assert sum(line.startswith('CHOCOLATE SYNTHETIC PNG I/O') for line in main['markers']) == 2
assert sum(line.startswith('CHOCOLATE rules ') and 'overflow=[]' in line for line in main['markers']) == 5
assert main['markers'][-1] == 'PASS: chocolate Main factory entrance, three-wheel and leftover idler results, fixed rewards, selected PNG I/O and reload'
logs = {name: sha(HERE / name) for name in PYTHON_LOGS}
out = HERE / 'fix1-evidence-index.json'
out.write_text(json.dumps({'fix_base': BASE, 'owned_file_sha256': sources, 'launch_index_sha256': sha(index), 'launches': launches,
                           'focused_logs_sha256': logs, 'unchanged_task3_index_sha256': sha(old), 'unchanged_receipts': count},
                          ensure_ascii=False, indent=2), encoding='utf-8')

table = ['| Owned file | Raw SHA-256 |', '|---|---|', *(f'| `{name}` | `{value}` |' for name, value in sources.items())]
table += ['', '| Evidence file | Raw SHA-256 |', '|---|---|', f'| `{index.name}` | `{sha(index)}` |', f'| `{out.name}` | `{sha(out)}` |',
          *(f'| `{name}` | `{value}` |' for name, value in logs.items())]
table += ['', '| Validated launch | Exit / errors / warnings | Raw receipt SHA-256 |', '|---|---:|---|']
table += [f'| `{item["job"]}` | {item["exit"]} / {item["errors"]} / {item["warnings"]} | `{item["sha256"]}` |' for item in launches]
for warning, count in main['warnings_by_diagnostic'].items():
    table.append(f'\n{count} occurrences of `{warning}`. The unchanged scenery materials remain without cutaway.')
with REPORT.open('a', encoding='utf-8') as file:
    file.write('\n' + '\n'.join(table) + '\n')
