"""Apply the Task 3 catalog and house fixture changes after the baseline."""
import json
from pathlib import Path


def change(name, *replacements):
    path = Path(name)
    contents = path.read_bytes().decode()
    newline = '\r\n' if '\r\n' in contents else '\n'
    source = contents.replace('\r\n', '\n')
    for old, new in replacements:
        assert source.count(old) == 1, (name, old, source.count(old))
        source = source.replace(old, new)
    path.write_bytes(source.replace('\n', newline).encode())


candy = {
    'id': 'game-029', 'mode': 'chocolate_etching', 'zone': 'candy', 'local_index': 5,
    'name': '巧克力蝕刻', 'goal': '描線折出三片齒輪並裝上試裝板，讓出口實際轉滿一圈',
    'instructions': '描熱線、折料與放置齒輪',
    'devil_hint': '首次轉滿一圈前，從真實剩料折出第4輪，讓它與三個主輪都位於輸入到出口的傳動路徑。輔助與AI夾持仍須親手完成。',
    'devil': '從剩料切出惰輪並串入輸出路徑',
    'ordinary': '三個主輪帶動出口轉滿一圈',
    'attraction_tag': '熱線工藝板',
    'island_invitation': '方向鍵移游標，Tab換片、Q/E選深度、Space按住描線或轉動，F折料或放置、M換工藝與試裝、X撤銷、R切換輔助夾持。'
}

lesson = {
    'id': 'game-029', 'title': candy['name'],
    'goal': '240秒內親手描線、折出三個主輪，讓它們帶動出口轉滿一圈。',
    'ordinary': '真正提交至少8單位的熱線後正常結算可收藏普通卡。空等、只配置、練習或取消不發卡。',
    'bonus': '首次完成前從剩料折出第4輪，與三主輪串在輸入到出口的路徑才算小惡魔。',
    'steps': [
        {
            'id': 'trace', 'title': '按住描線，選深度再折料',
            'image': 'res://assets/ui/tutorials/game-029-step-01.png',
            'alt': '工藝板顯示一筆已提交的淺熱線，折料回報齒形仍有連接。',
            'goal': '深切較快但耗料較寬，淺切可沿同一路徑重描。閉合且整圈切透才可折料。',
            'input': '方向鍵或WASD移動，Tab換片、Q/E調深度，Space按住描線，或按住板面拖曳。內側放開提交，F折料。',
            'success': '有連接就補切。R切換AI只增加第二夾持，輔助吸附引導並放寬容差，仍須親手描線與折料。'
        },
        {
            'id': 'mesh', 'title': '量中心距，組裝三輪再試轉',
            'image': 'res://assets/ui/tutorials/game-029-step-02.png',
            'alt': '三片實際切出的齒輪已接入輸入和出口，試裝板顯示接觸與轉動。',
            'goal': '第1與第3輪對準兩端軸，依節圓大小安排中輪。實際中心距與齒距吻合才會傳動。',
            'input': 'M換試裝，Tab換輪。移游標後按F放置，原位按F取下，也可拖動放置。按住Space試轉。',
            'success': '三個主輪都要經過傳動，出口轉滿一圈才通關。換輪位或改結構會清零出口進度。'
        },
        {
            'id': 'idler', 'title': '從剩料取惰輪，改走四輪路徑',
            'image': 'res://assets/ui/tutorials/game-029-step-03.png',
            'alt': '剩料折出的第4輪位於三個主輪之間，四輪路徑正實際帶動出口。',
            'goal': '三主輪取出後，用留下的板材切第4輪。首次轉滿一圈前讓路徑依序穿過1、2、4、3輪。',
            'input': 'X可撤銷最近8次熱線、折料或放置，不回時間。一般撤銷扣20，輔助撤銷不扣分。',
            'success': '惰輪掛在旁邊不算。放開或暫停會停轉並保留進度，失焦會清掉未提交的描線或拖曳。'
        }
    ]
}

change('game/data/candy_games.json', ('  }\n]\n', '  },\n' + '\n'.join('  ' + line for line in json.dumps(candy, ensure_ascii=False, indent=2).splitlines()) + '\n]\n'))
change('game/data/tutorials.json', ('    }\n  ]\n}\n', '    },\n' + '\n'.join('    ' + line for line in json.dumps(lesson, ensure_ascii=False, indent=2).splitlines()) + '\n  ]\n}\n'))
change('game/core/game_catalog.gd', ('"candy": 4}', '"candy": 5}'))
change('game/minigames/session.gd', ('const DRIVERS := {"jelly_trampoline"', 'const DRIVERS := {"chocolate_etching": preload("res://game/minigames/chocolate_etching_driver.gd"), "jelly_trampoline"'))
change('game/ui/tutorial_catalog.gd', ('"game-028"]', '"game-028", "game-029"]'))
change('game/world/candy_world.gd', ('\t_point("game-028", "果凍彈床 · 蓄彈斜壓送高台", Vector3(7, GROUND_Y, -1))', '\t_point("game-028", "果凍彈床 · 蓄彈斜壓送高台", Vector3(7, GROUND_Y, -1))\n\t_point("game-029", "巧克力蝕刻 · 描線折料試轉", Vector3(10.5, GROUND_Y, -0.8))'))
for name in ('game/main.gd', 'game/ui/collection_book_panel.gd'):
    change(name, ('"syrup_flood","jelly_trampoline"]', '"syrup_flood","jelly_trampoline","chocolate_etching"]'))
change('game/ui/retake_panel.gd', ('["bench","lantern","camera"]]', '["bench","lantern","camera"], ["sign","camera","lantern"]]'))
change('tools/verify_design.py', ('CANDY_DELIVERED = 4', 'CANDY_DELIVERED = 5'))

design_path = 'design/02-minigames/catalog.json'
old_config = json.loads(Path(design_path).read_text(encoding='utf-8'))['games'][28]
row = old_config | {
    'action': candy['instructions'], 'goal': candy['ordinary'],
    'choice': '深切較快但耗料寬，淺切重描可保留剩料',
    'feedback': '切深、剩料輪廓、接觸線和出口轉動', 'variation': '重試交替兩種齒數及軸距',
    'ai': '簡單AI只在合格板角提供第二夾持',
    'demon': candy['devil'], 'assist': '引導吸附、放寬容差，最近8步撤銷不扣分',
    'test': 'A/B以實際熱線折料及量測的輪廓傳動，驗證普通與第四惰輪路徑',
    'solo': '玩家獨立完成描線、折料、放置及試轉。可暫停、重試及隨時離場。',
    'revision_reason': '以實際切深、剩料與量測輪廓決定傳動，深切速度與保留剩料形成取捨。現行單人程式仍需完整驗收。',
    'implementation': 'single_player_runtime_needs_full_acceptance',
    'demon_assist_policy': '普通與惡魔收藏均可使用輔助與AI夾持，仍須手動切割、折料、放置及轉滿一圈。',
    'runtime_mode': candy['mode']
}
source = Path(design_path).read_text(encoding='utf-8')
old_block = source[source.index('    {\n      "name": "巧克力蝕刻"'):source.index(',\n    {\n      "name": "棉糖捲風"')]
change(design_path, (old_block, '\n'.join('    ' + line for line in json.dumps(row, ensure_ascii=False, indent=2).splitlines())))

design_notes = 'design/02-minigames/catalog.md'
source = Path(design_notes).read_text(encoding='utf-8')
old_section = source[source.index('### game-029'):source.index('### game-030')]
fields = [('操作','action'), ('普通目標','goal'), ('取捨','choice'), ('可見回饋','feedback'), ('重玩變化','variation'), ('單人','solo'), ('多人','multi'), ('簡單 AI','ai'), ('小惡魔','demon'), ('輔助與惡魔','demon_assist_policy'), ('異空間','variant'), ('輔助','assist'), ('原型檢查','test'), ('修訂理由','revision_reason')]
section = '### game-029 巧克力蝕刻\n\n**創意** · 2D俯視工藝板 · 重設 · 現行單人程式，仍需完整驗收\n\n| 項目 | 規格 |\n|---|---|\n'
section += ''.join(f'| {label} | {row[key]} |\n' for label, key in fields)
change(design_notes, (old_section, section + '\n'), ('001–028 有現行單人程式，其他 100 款只在設計。', '001–029 有現行單人程式，其他 99 款只在設計。'))
change('design/runtime/full-game-delivery.md',
       ('，工廠目前四款遊戲、四格普通／小惡魔卡。可玩總數為 28，仍需完整驗收。其餘100款', '。SG-45 加入第二十九款「巧克力蝕刻」，以實際熱線、剩料及齒輪傳動提供獨立工藝玩法，工廠目前五款遊戲、五格普通／小惡魔卡。可玩總數為 29，仍需完整驗收。其餘 99 款'),
       ('，工廠目前四款已開放、其餘八款準備中。依設計目錄逐款實作其餘 100 款', '，SG-45 接入第 29 款「巧克力蝕刻」，工廠目前五款已開放、其餘七款準備中。下一款為 game-030，依設計目錄逐款實作其餘 99 款'))

for game in ('sugar_bridge', 'cookie_mold', 'syrup_flood', 'jelly_trampoline'):
    change(f'game/tests/test_{game}_main.gd',
           ('Catalog.all_definitions().size() == 28', 'Catalog.all_definitions().size() == 29'), ('delivered island has28', 'delivered island has29'),
           ('book._entries().size() == 4, "candy album exposes four', 'book._entries().size() == 5, "candy album exposes five'))
change('game/tests/test_jelly_trampoline_main.gd',
       ('stamps.get_child_count() == 4', 'stamps.get_child_count() == 5'), ('all four real local stamps', 'all five real local stamps'),
       ('"4 / 12"', '"5 / 12"'), ('其餘 8 款準備中', '其餘 7 款準備中'), ('factory4/12', 'factory5/12'),
       ('lessons.get_child_count() == 4', 'lessons.get_child_count() == 5'), ('all four delivered lessons', 'all five delivered lessons'))
for game in ('sugar_bridge', 'cookie_mold'):
    change(f'game/tests/test_{game}_session.gd', ('s.start("game-029")', 's.start("game-030")'))
change('game/tests/test_candy_world.gd',
       ('4／12", "constructed visible factory game sign advertises the four', '5／12", "constructed visible factory game sign advertises the five'),
       ('snapshot.points.size() == 9', 'snapshot.points.size() == 10'), ('"game-027","game-028"], "only four', '"game-027","game-028","game-029"], "only five'),
       ('begins_with("game-")).size() == 4', 'begins_with("game-")).size() == 5'), ('exactly four delivered candy', 'exactly five delivered candy'),
       ('"fourth game uses the next safe upper-right floor with margin")', '"fourth game uses the next safe upper-right floor with margin")\n\t\t_check(world._point_by_id("game-029").position == Vector3(10.5, script.GROUND_Y, -0.8), "fifth game uses the calibrated entrance")'))
change('game/tests/test_game_catalog.gd',
       ('candy.size() == 4 and all_games.size() == 28, "only the twenty-eight', 'candy.size() == 5 and all_games.size() == 29, "only the twenty-nine'),
       ('\t_check(catalog.identity("game-012").photo_id', '\tvar chocolate := {"id":"game-029", "mode":"chocolate_etching", "zone":"candy", "local_index":5, "photo_id":"photo-candy-game-5", "devil_photo_id":"photo-candy-devil-5", "achievement_id":"ACH_GAME_029"}\n\t_check(catalog.identity("game-029") == chocolate and catalog.identity("chocolate_etching") == chocolate and candy[4].name == "巧克力蝕刻", "fifth candy game keeps local5/global029")\n\t_check(catalog.identity("game-012").photo_id'))
change('game/tests/test_region_travel.gd',
       ('book._entries().size()==4', 'book._entries().size()==5'), ('stamps.get_child_count()==4', 'stamps.get_child_count()==5'),
       ('[18,12,4][index]', '[18,12,5][index]'),
       ('"candy album shows all four delivered local games"', '"candy album shows all five delivered local games"'),
       ('"candy achievement summary has all four real local game stamps"', '"candy achievement summary has all five real local game stamps"'),
       ('_labels(book).contains("果凍彈床")', '_labels(book).contains("果凍彈床") and _labels(book).contains("巧克力蝕刻")'),
       ('_labels(main.overlay).contains("果凍彈床")', '_labels(main.overlay).contains("果凍彈床") and _labels(main.overlay).contains("巧克力蝕刻")'),
       ('"4 / 12"', '"5 / 12"'), ('其餘 8 款準備中', '其餘 7 款準備中'),
       ('choices.get_child_count()==4, "candy guide offers exactly four', 'choices.get_child_count()==5, "candy guide offers exactly five'),
       ('["game-025","game-026","game-027","game-028"]', '["game-025","game-026","game-027","game-028","game-029"]'))
change('game/tests/test_retake_panel.gd',
       ('PROPS.size() == 28 and Catalog.all_definitions().size() == 28, "every one of28', 'PROPS.size() == 29 and Catalog.all_definitions().size() == 29, "every one of29'),
       ('["game-029", "game-120"', '["game-030", "game-120"'))
change('game/tests/native_jelly_trampoline_main.gd',
       ('工廠遊戲 4／12', '工廠遊戲 5／12'), ('== 4,"real map lists exactly4', '== 5,"real map lists exactly5'),
       ('== 4,"actual four-entry factory', '== 5,"actual five-entry factory'))

change('tests/test_design_validation.py',
       ("self.data['games'][28]['implementation'] = 'single_player_runtime_needs_full_acceptance'\n        with self.assertRaisesRegex(ValueError, 'game-029.*scope')", "self.data['games'][29]['implementation'] = 'single_player_runtime_needs_full_acceptance'\n        with self.assertRaisesRegex(ValueError, 'game-030.*scope')"),
       ("first, second, third, fourth = self.candy\n        for candy in ([], [first, second, third], [second, first, third, fourth],\n                      [first, second, third, dict(fourth, id='game-029')],\n                      [first, second, third, dict(fourth, zone='harbor')],\n                      [first, second, third, dict(fourth, local_index=3)],\n                      [first, second, third, dict(fourth, id='game-027')],\n                      self.candy + [dict(fourth, id='game-029', local_index=5)]):", "first, second, third, fourth, fifth = self.candy\n        prefix = [first, second, third, fourth]\n        for candy in ([], prefix, [second, first, third, fourth, fifth],\n                      prefix + [dict(fifth, id='game-030')],\n                      prefix + [dict(fifth, zone='harbor')],\n                      prefix + [dict(fifth, local_index=4)],\n                      prefix + [dict(fifth, id='game-028')],\n                      self.candy + [dict(fifth, id='game-030', local_index=6)]):"),
       ('    def test_candy_runtime_rules_cannot_drift', "    def test_fifth_candy_game_has_delivered_runtime_scope(self):\n        row = self.data['games'][28]\n        self.assertEqual(row['implementation'], 'single_player_runtime_needs_full_acceptance')\n        self.assertEqual(row['runtime_mode'], 'chocolate_etching')\n        row['implementation'] = 'design_only_not_playtested'\n        with self.assertRaisesRegex(ValueError, 'game-029.*scope'):\n            v.validate_games(self.data, self.refs)\n\n    def test_candy_runtime_rules_cannot_drift"),
       ('for index in (24, 25, 26, 27):', 'for index in range(24, 29):'))

suites = {
    'chocolate model tests': ('test_chocolate_etching.gd', 'Chocolate etching tests: 211 checks, 0 failures'),
    'chocolate driver tests': ('test_chocolate_etching_driver.gd', 'Chocolate etching driver: 73 checks, 0 failures'),
    'chocolate view tests': ('test_chocolate_etching_view.gd', 'Chocolate etching view: 30 checks, 0 failures'),
    'chocolate Session tests': ('test_chocolate_etching_session.gd', 'Chocolate etching Session: 55 checks, 0 failures'),
    'chocolate Main tests': ('test_chocolate_etching_main.tscn', 'PASS: chocolate Main factory entrance, three-wheel and leftover idler results, fixed rewards, selected PNG I/O and reload'),
}
markers = ''.join(f'    "{label}": "{marker}",\n' for label, (_, marker) in suites.items())
checks = ''.join(f'        ("{label}", common + [{"\"--script\", " if entry.endswith(".gd") else ""}"res://game/tests/{entry}"]),\n' for label, (entry, _) in suites.items())
change('tools/run_game_tests.py',
       ('PASS_MARKERS = {\n', 'PASS_MARKERS = {\n' + markers),
       ('"syrup ", "jelly ")) or', '"syrup ", "jelly ", "chocolate ")) or'),
       ('        ("jelly model tests",', checks + '        ("jelly model tests",'))
contracts = ''.join(f'    "{label}": ("{entry}", "{marker}"),\n' for label, (entry, marker) in suites.items())
change('tests/test_runtime_result_contract.py',
       ('    "jelly model tests":', contracts + '    "jelly model tests":'),
       ('"syrup ", "jelly "))]', '"syrup ", "jelly ", "chocolate "))]'),
       ('self.assertEqual(len(drivers), 20)', 'self.assertEqual(len(drivers), 25)'))

change('game/tests/test_participation_results.gd',
       ('const Catalog = preload("res://game/core/game_catalog.gd")', 'const Catalog = preload("res://game/core/game_catalog.gd")\nconst Chocolate = preload("res://game/tests/test_chocolate_etching_session.gd")'),
       ('\t\tif definition.mode == "sugar_bridge":', '\t\tif definition.mode == "chocolate_etching": Chocolate.cut_line(session)\n\t\tif definition.mode == "sugar_bridge":'),
       ('\t\telif definition.mode == "syrup_flood":', '\t\telif definition.mode == "chocolate_etching":\n\t\t\tChocolate.cut_line(session)\n\t\t\tChocolate.advance(session, 241.0)\n\t\telif definition.mode == "syrup_flood":'))

change('game/tests/test_tutorial_paged_viewport.gd',
       ('\t\tfor lesson_id in panel.catalog.lesson_ids():', '\t\tvar lesson_ids := panel.catalog.lesson_ids()\n\t\tvar page_count := 0\n\t\t_check(lesson_ids.size() == 30, "one park lesson and 29 game lessons")\n\t\tfor lesson_id in lesson_ids:'),
       ('\t\t\t\tfor page in range(panel._copy_pages.size()):', '\t\t\t\tpage_count += panel._copy_pages.size()\n\t\t\t\tif lesson_id == "game-029":\n\t\t\t\t\tprint("CHOCOLATE tutorial viewport=%s scale=1.25 step=%d pages=%d" % [dimensions, step + 1, panel._copy_pages.size()])\n\t\t\t\tfor page in range(panel._copy_pages.size()):'),
       ('\tpanel.queue_free()', '\t\tprint("CHOCOLATE tutorial viewport=%s scale=1.25 lessons=%d semantic_groups=%d" % [dimensions, lesson_ids.size(), page_count])\n\tpanel.queue_free()'))

private = Path(__file__).resolve().parent
for source, target in [('session.gd.txt', 'test_chocolate_etching_session.gd'), ('main.gd.txt', 'test_chocolate_etching_main.gd'), ('main.tscn.txt', 'test_chocolate_etching_main.tscn')]:
    text = (private / source).read_text(encoding='utf-8').replace('fixed local4 and global029 identities', 'fixed local5 and global029 identities')
    (Path('game/tests') / target).write_text(text, encoding='utf-8')
