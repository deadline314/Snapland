"""Prepare the corresponding chocolate fixture from the previous factory flow."""
from pathlib import Path

root = Path('game/tests')
private = Path(__file__).resolve().parent
main = (root / 'test_jelly_trampoline_main.gd').read_text(encoding='utf-8')
# The existing Jelly fixture is the final authority only for the common factory flow.
for old, new in {
    'test_jelly_trampoline_session.gd': 'test_chocolate_etching_session.gd',
    'jelly_trampoline': 'chocolate_etching', 'Jelly Main': 'Chocolate Main',
    'Jelly Trampoline': 'Chocolate Etching', 'game-028': 'game-029', '028': '029',
    '"local_index":4': '"local_index":5', 'photo-candy-game-4': 'photo-candy-game-5',
    'photo-candy-devil-4': 'photo-candy-devil-5', 'fourth': 'fifth', '果凍彈床': '巧克力蝕刻',
    '== 28': '== 29', 'has28': 'has29', 'size() == 4': 'size() == 5',
    'get_child_count() == 4': 'get_child_count() == 5', 'all four real local stamps': 'all five real local stamps',
    'all four delivered lessons': 'all five delivered lessons', 'four real local entries': 'five real local entries',
    '"4 / 12"': '"5 / 12"', '其餘 8 款準備中': '其餘 7 款準備中', 'factory4/12': 'factory5/12',
    'Vector3(7, main.world.GROUND_Y, -1)': 'Vector3(10.5, main.world.GROUND_Y, -0.8)',
    'Route.advance(main.session, 61.0)': 'Route.advance(main.session, 241.0)',
    'Route.launch(main.session, 0.15)': 'Route.cut_line(main.session)',
    'real three-fruit practice route': 'real four-wheel practice route',
    'real three-fruit ordinary route': 'real three-wheel ordinary route',
    'Route.solve(main.session, true, true)': 'Route.solve(main.session, true, "touch")',
    'real assisted same-fruit bell route': 'real assisted leftover-idler route',
    'PASS: jelly Main factory entry, three real deliveries and same-fruit bell, fixed rewards, selected retake originals and reload': 'PASS: chocolate Main factory entrance, three-wheel and leftover idler results, fixed rewards, selected PNG I/O and reload',
    'FAIL: jelly Main': 'FAIL: chocolate Main',
}.items():
    main = main.replace(old, new)
main = main.replace('const RulesLayout =', 'const Keys = preload("res://game/tests/retake_native_route.gd")\nconst RulesLayout =')
main = main.replace('and main.world._point_by_id("game-027")', 'and main.world._point_by_id("game-028").get("id", "") == "game-028" and main.world._point_by_id("game-027")')
main = main.replace('factory preserves all four actual entrances', 'factory preserves all four previous physical entrances and adds the fifth')
main = main.replace('main.world.interact()', 'await Keys.key(get_viewport(), KEY_E)')
main = main.replace('factory interaction opens real game invitation', 'actual E opens the physical Chocolate Etching invitation')
main = main.replace('action.pressed.emit()', 'await Keys.activate(action)')
main = main.replace('menu routes', 'menu routes')
main = main.replace('rules expose the participation page', 'rules expose paging to the actual-participation rule')
main = main.replace('Progress.settings["ui_scale"] = 1.25', 'Progress.settings["ui_scale"] = 1.25\n\tProgress.settings["reduced_motion"] = true')
main = main.replace('check(RulesLayout.inspect_layout(main).is_empty(), "complete rules text and actions fit actual800 large page%d" % page)', 'var overflow := RulesLayout.inspect_layout(main)\n\t\t\tprint("CHOCOLATE rules viewport=800x600 scale=1.25 page=%d overflow=%s" % [page + 1, overflow])\n\t\t\tcheck(overflow.is_empty(), "complete rules text and actions fit actual800 large page%d: %s" % [page + 1, overflow])')
main = main.replace('Progress.coins == initial_coins + 40,', 'Progress.coins == initial_coins + 40 and Progress.wardrobe_rewarded_games.count("game-029") == 1,')
main = main.replace('and Progress.photos["photo-candy-devil-5"].challenge_earned,', 'and Progress.photos["photo-candy-devil-5"].challenge_earned and Progress.wardrobe_rewarded_games.count("game-029") == 1,')
main = main.replace('check(main.session == null and Progress.coins == coins and Progress.normal_count_for_zone("candy") == 1,', 'check(main.session == null and Progress.coins == coins and Progress.normal_count_for_zone("candy") == 1 and Progress.devil_count("candy") == 1,')
main = main.replace('SYNTHETIC PHOTO: PNG I/O fixture after actual selected retake reaches shutter', 'CHOCOLATE SYNTHETIC PNG I/O after actual selected retake reaches shutter')
main = main.replace('var original_path := str(record.get("original_frames", [""])[0])', 'if record.get("original_frames", []).is_empty(): return\n\tvar original_path := str(record.original_frames[0])')
main = main.replace('and Progress.has_attempted_game("game-029") and FileAccess.get_sha256(original_path)', 'and Progress.has_attempted_game("game-029") and Progress.wardrobe_rewarded_games.count("game-029") == 1 and FileAccess.get_sha256(original_path)')
assert 'jelly' not in main.lower() and 'game-029' in main
(private / 'main.gd.txt').write_text(main, encoding='utf-8')
(private / 'main.tscn.txt').write_text((root / 'test_jelly_trampoline_main.tscn').read_text(encoding='utf-8')
    .replace('jelly_trampoline', 'chocolate_etching').replace('JellyTrampoline', 'ChocolateEtching'), encoding='utf-8')
