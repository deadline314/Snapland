"""Run selected fixtures in fresh stages, with explicit dependency and process audits."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from threading import Lock
from uuid import uuid4

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from tools.build_desktop_release import prepare_runtime_stage
from tools.godot_entrypoints import run_validated_godot
from tools.run_game_tests import build_checks, result_error

HERE = Path(__file__).resolve().parent
ENGINE = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
ENGINE_SHA256 = 'c8f0a6bc45a19b33541501e57f6f7cd972ab18453743266339d495cbbe846643'
EXCLUDED = {'test_photo_retake_main', 'test_photo_retake_progress', 'test_region_travel', 'test_region_progress'}
REFERENCES = re.compile(r'res://([^"\s]+\.(?:gd|gdshader|tscn|tres))')
LAUNCH_CALL = re.compile(r'OS\s*\.\s*(?:execute|create_process|execute_with_pipe|create_instance)\s*\(')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save_json(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')


def stage_for(job, entries, donor=None):
    profile = BASE / job
    stage = profile / 'project'
    stage.mkdir(parents=True)
    source_root = donor[0] if donor else ROOT
    manifest = prepare_runtime_stage(source_root, stage, TRACKED)
    pending = ['game/tests/' + e for e in entries]
    fixtures = set()
    while pending:
        name = pending.pop()
        if name in fixtures:
            continue
        assert Path(name).stem not in EXCLUDED, f'CI-only fixture {name}'
        source = source_root / name
        assert source.is_file(), name
        destination = stage / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        manifest[name] = sha(destination)
        fixtures.add(name)
        pending.extend(ref for ref in REFERENCES.findall(source.read_text(encoding='utf-8')) if ref.startswith('game/tests/'))
    imported = {}
    if donor:
        source_stage, source_receipt = donor
        assert source_receipt['engine_sha256'] == ENGINE_SHA256
        assert all(source_receipt['source_manifest'].get(path) == digest for path, digest in manifest.items())
        for source in sorted(source_stage.glob('assets/**/*.import')):
            path = source.relative_to(source_stage).as_posix()
            asset = path.removesuffix('.import')
            assert manifest.get(asset) == source_receipt['source_manifest'].get(asset) and manifest.get(asset), asset
            artifact_refs = re.findall(r'res://(\.godot/imported/[^"\s]+)', source.read_text(encoding='utf-8'))
            for name in {path, *artifact_refs}:
                destination = stage / name
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source_stage / name, destination)
                imported[name] = sha(destination)
    return profile, stage, manifest, sorted(fixtures), imported


def launch(job, args, entries, donor=None):
    profile, stage, manifest, fixtures, imports = stage_for(job, entries, donor)
    audit = []
    for path in sorted(stage.rglob('*')):
        if path.suffix not in {'.gd', '.tscn', '.tres', '.gdshader', '.godot'} or not path.is_file():
            continue
        name = path.relative_to(stage).as_posix()
        source = path.read_text(encoding='utf-8')
        calls = [line for line, code in enumerate(source.splitlines(), 1) if LAUNCH_CALL.search(code)]
        assert Path(name).stem not in EXCLUDED, name
        assert sha(path) == manifest[name], name
        unresolved = [ref for ref in REFERENCES.findall(source) if ref.startswith('game/tests/') and ref not in fixtures]
        audit.append({'path': name, 'source_sha256': manifest[name], 'process_calls': calls, 'unstaged_fixture_references': unresolved})
    audit_path = profile / 'prelaunch-audit.json'
    save_json(audit_path, audit)
    assert all(not row['process_calls'] and not row['unstaged_fixture_references'] for row in audit), audit_path
    updates = {'SNAPLAND_SAVE_PATH': str(profile / 'save' / 'progress.json'), 'GODOT_BIN': ENGINE, 'CHOCOLATE_CAPTURE_DIR': str(profile / 'captures')}
    for key in ('APPDATA', 'LOCALAPPDATA', 'TEMP', 'TMP'):
        updates[key] = str(profile / key.lower())
        Path(updates[key]).mkdir()
    (profile / 'save').mkdir()
    (profile / 'captures').mkdir()
    log = profile / 'godot.log'
    command = [ENGINE, '--path', str(stage), '--log-file', str(log), '--headless', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility', *args]
    started = datetime.now(timezone.utc).isoformat()
    timeout = 240 if job in {'import', 'test_tutorial_paged_viewport'} else 120
    try:
        result = run_validated_godot(stage, command, os.environ | updates, timeout)
    except subprocess.TimeoutExpired as exc:
        result = subprocess.CompletedProcess(command, -999, exc.stdout or '', exc.stderr or '')
    (profile / 'stdout.log').write_bytes(result.stdout.encode('utf-8'))
    (profile / 'stderr.log').write_bytes(result.stderr.encode('utf-8'))
    output = log.read_text(encoding='utf-8', errors='replace') if log.exists() else result.stdout + result.stderr
    contract = ITEMS.get(job)
    error = result_error(contract, result) if contract is not None else None
    receipt = dict(started_utc=started, engine_sha256=sha(Path(ENGINE)), command=command, environment=updates, timeout=timeout,
                   result=result.returncode, errors=output.count('ERROR:'), warnings=output.count('WARNING:'),
                   leaks=re.findall(r'(?im)^.*(?:warning|error):.*(?:leaked|still in use at exit).*$',output), contract_error=error,
                   markers=[line for line in output.splitlines() if re.search(r'checks,|PASS:|CHOCOLATE |^4\.7\.',line)],
                   fixture_allowlist=fixtures, source_manifest=manifest, copied_asset_artifacts=imports,
                   donor_stage=str(donor[0]) if donor else None, excluded_ci_parents=sorted(EXCLUDED),
                   receipt_artifacts={p.name: sha(p) for p in (audit_path, log, profile / 'stdout.log', profile / 'stderr.log') if p.is_file()})
    receipt_path = profile / 'receipt.json'
    save_json(receipt_path, receipt)
    with INDEX_LOCK:
        INDEX.append({'job': job, 'receipt': str(receipt_path), 'sha256': sha(receipt_path), 'exit': result.returncode,
                      'errors': receipt['errors'], 'warnings': receipt['warnings'], 'markers': receipt['markers']})
        save_json(HERE / (LABEL + '-index.json'), INDEX)
    print(job, result.returncode, f"errors={receipt['errors']} warnings={receipt['warnings']}", receipt_path, flush=True)
    if not (LABEL.startswith('red') and job == 'test_chocolate_etching_session'):
        assert not result.returncode and not receipt['errors'] and not receipt['leaks'] and error is None, receipt_path
    return stage, receipt, result


LABEL, *ENTRIES = sys.argv[1:]
assert ENTRIES and not ({Path(e).stem for e in ENTRIES} & EXCLUDED)
assert not (HERE / (LABEL + '-index.json')).exists()
BASE = Path('D:/Snapland-QA') / ('chocolate-integration-' + LABEL + '-' + uuid4().hex[:8])
TRACKED = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT, text=True, encoding='utf-8').split('\0')
TRACKED = [p for p in TRACKED if not p.endswith(('.uid', '.import'))]
ITEMS = {Path(cmd[-1]).stem: label for label, cmd in build_checks(ENGINE) if cmd[-1].endswith(('.gd', '.tscn'))}
ITEMS['import'] = 'clean project import'
INDEX = []
INDEX_LOCK = Lock()
assert sha(Path(ENGINE)) == ENGINE_SHA256
_, _, version = launch('version', ['--version'], ENTRIES)
assert version.stdout.startswith('4.7.2.stable.'), version.stdout
import_stage, import_receipt, _ = launch('import', ['--editor', '--import', '--quit'], ENTRIES)

def run_entry(entry):
    args = ['--script'] if entry.endswith('.gd') else []
    launch(Path(entry).stem, args + ['res://game/tests/' + entry], [entry], (import_stage, import_receipt))

with ThreadPoolExecutor(max_workers=3) as group:
    list(group.map(run_entry, ENTRIES))
