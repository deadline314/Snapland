"""Verify retained evidence and append the exact-source Task 3 results."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
REPORT = ROOT / '.superpowers/sdd/2026-11-18-chocolate-etching/task-3-report.md'
RUNS = ['red-baseline', 'baseline-travel', 'green-integration', 'final-wired', 'final-tutorial', 'final-regressions']
EXCLUDED = {'test_photo_retake_main', 'test_photo_retake_progress', 'test_region_travel', 'test_region_progress'}
NEW_FIXTURES = ['game/tests/test_chocolate_etching_session.gd', 'game/tests/test_chocolate_etching_main.gd', 'game/tests/test_chocolate_etching_main.tscn']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


summary = {}
promoted = {}
observed_source = {}
markdown = []
for run in RUNS:
    index = HERE / f'{run}-index.json'
    rows = json.loads(index.read_text(encoding='utf-8'))
    markdown.append(f'| `{index.name}` | {len(rows)} | `{sha(index)}` |')
    results = []
    for row in rows:
        receipt_path = Path(row['receipt'])
        assert sha(receipt_path) == row['sha256']
        receipt = json.loads(receipt_path.read_text(encoding='utf-8'))
        assert not ({Path(name).stem for name in receipt['fixture_allowlist']} & EXCLUDED)
        for key, digest in receipt['receipt_artifacts'].items():
            assert sha(receipt_path.parent / key) == digest
        audit = json.loads((receipt_path.parent / 'prelaunch-audit.json').read_text(encoding='utf-8'))
        assert not any(a['process_calls'] or a['unstaged_fixture_references'] for a in audit)
        log_path = receipt_path.parent / 'godot.log'
        log = log_path.read_text(encoding='utf-8') if log_path.exists() else ''
        warnings = Counter()
        for line in log.splitlines():
            if line.startswith('WARNING: OcclusionController:'):
                warnings['OcclusionController: material preserved without cutaway'] += 1
            elif line.startswith('WARNING:'):
                warnings[line] += 1
        assert sum(warnings.values()) == row['warnings'], (run, row['job'], warnings)
        result = {**row, 'audit_rows': len(audit), 'warnings_by_diagnostic': dict(warnings), 'raw_artifacts': dict(receipt['receipt_artifacts']),
                  'fixture_allowlist': receipt['fixture_allowlist'], 'started_utc': receipt['started_utc']}
        results.append(result)
        job = row['job']
        if not run.startswith('final-') or job in {'version', 'import'} or row['exit'] != 0:
            continue
        assert not receipt['contract_error'] and not receipt['leaks'] and not row['errors']
        assert job not in promoted
        for source, digest in receipt['source_manifest'].items():
            if source not in observed_source:
                observed_source[source] = sha(ROOT / source)
            assert observed_source[source] == digest, (job, source)
        promoted[job] = result
    summary[run] = results

assert len(promoted) == 17
assert len([row for row in summary['red-baseline'] if row['exit'] == 0]) == 16
assert len(summary['baseline-travel']) == 3
(HERE / 'evidence-index.json').write_text(json.dumps({'runs': summary, 'promoted': promoted}, ensure_ascii=False, indent=2), encoding='utf-8')

stats = ['## Local results', '', '| Suite | Result | Warnings | Exact receipt SHA-256 |', '|---|---|---:|---|']
for job, row in promoted.items():
    marker = next(line for line in reversed(row['markers']) if not line.startswith('CHOCOLATE '))
    stats.append(f'| `{job}` | {marker} | {row["warnings"]} | `{row["sha256"]}` |')

stats += ['', '| History index | Actual launches | SHA-256 |', '|---|---:|---|', *markdown, '']
stats += ['Evidence-index SHA-256 `' + sha(HERE / 'evidence-index.json') + '`.']
tutorial = promoted['test_tutorial_paged_viewport']['markers']
stats += ['', '### Tutorial bounds', '', '| Viewport | All lessons | Visible semantic groups | Chocolate steps |', '|---|---:|---:|---|']
for line in tutorial:
    match = re.fullmatch(r'CHOCOLATE tutorial viewport=(.*) scale=1.25 lessons=(\d+) semantic_groups=(\d+)', line)
    if match:
        size, lessons, groups = match.groups()
        steps = [step.rsplit('=', 1)[-1] for step in tutorial if f'viewport={size} scale=1.25 step=' in step]
        assert len(steps) == 3
        stats.append(f'| `{size}` at 1.25 | {lessons} | {groups} | {", ".join(steps)} |')
stats += ['', '### Local verification logs', '', '| Command output | Result | SHA-256 |', '|---|---|---|']
for log, result in [('design-python.log', '47 checks'), ('runtime-python.log', '36 checks'), ('entrypoints-python.log', '15 checks'), ('design-games.log', 'PASS games and runtime alignment'), ('design-links.log', 'PASS links')]:
    log = 'final-' + log
    stats.append(f'| `{log}` | {result} | `{sha(HERE / log)}` |')

modified = subprocess.check_output(['git', 'diff', '--name-only', '--'], cwd=ROOT, text=True, encoding='utf-8').splitlines()
paths = sorted({*modified, *NEW_FIXTURES})
stats += ['', '## Frozen owned-file SHA-256', '', '| Path | Raw SHA-256 |', '|---|---|']
for name in paths:
    stats.append(f'| `{name}` | `{sha(ROOT / name)}` |')
stats += ['', 'This report and the private integration receipts are controller handoff artifacts.']
prefix = REPORT.read_text(encoding='utf-8').split('\n## Local results\n', 1)[0]
REPORT.write_text(prefix.rstrip() + '\n\n' + '\n'.join(stats) + '\n', encoding='utf-8')
