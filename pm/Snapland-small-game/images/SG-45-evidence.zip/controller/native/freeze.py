"""Verify and freeze an explicit final Task 4 evidence set from fresh D outputs."""

import argparse
from pathlib import Path
import re

from run import BASE, FIXTURES, HERE, ROOT, describe, dump, read, sha


PAIRS = {("suite", "1280x720", False), ("suite", "1152x648", False), ("suite", "800x600", False),
         ("retake-ordinary", "1280x720", False), ("retake-ordinary", "800x600", False),
         ("retake-devil", "1280x720", False), ("retake-devil", "1152x648", False), ("suite", "1280x720", True)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--version", type=Path, required=True)
    parser.add_argument("--donor", type=Path, required=True)
    parser.add_argument("--build", type=Path, required=True)
    parser.add_argument("pairs", type=Path, nargs=8)
    args = parser.parse_args()
    promoted = {}

    def add(path, kind):
        entry = describe(path)
        promoted.setdefault(entry["path"], {**entry, "category": kind})
        return entry

    version_ref = add(args.version / "receipt.json", "exact-engine-receipt")
    donor_ref = add(args.donor / "receipt.json", "fresh-import-receipt")
    import_files = add(args.donor / "asset-import-files.json", "fresh-asset-import-identity")
    build_ref = add(args.build / "build.json", "embedded-build-identity")
    add(args.build / "embedded-acceptance.json", "embedded-acceptance-pair")
    build = read(build_ref["path"])
    assert describe(build["binary"]["path"]) == build["binary"]
    assert all(describe(tpl["path"]) == tpl for tpl in build["templates"].values())
    source = read(args.donor / "source-graph.json")
    assert source["commit_base"] == BASE and source["fixtures"] == FIXTURES
    assert all(sha(ROOT / name) == digest for name, digest in source["source_raw_sha256"].items())

    def process(reference, kind):
        assert add(reference["path"], kind) == reference
        receipt = read(reference["path"])
        assert receipt["passed"] and receipt["exit_code"] == 0 and not receipt["errors"] and not receipt["leak_diagnostics"]
        assert read(receipt["source_graph"]["path"]) == source
        audit = read(receipt["audit"]["path"])
        assert audit["fixture_closure"] == FIXTURES and not audit["child_launch_candidates"]
        for key, category in (("source_graph", "process-source-graph"), ("runtime_graph", "process-runtime-graph"),
                              ("audit", "process-prelaunch-audit"), ("asset_import_reuse", "asset-import-reuse")):
            if receipt[key] is not None:
                assert add(receipt[key]["path"], category) == receipt[key]
        for log in receipt["logs"]:
            assert add(log["path"], "engine-raw-log" if log["path"].endswith("/engine.log") else "unsuppressed-launcher-stdio") == log
        for item in receipt["capture_outputs"]:
            assert add(item["path"], "raw-native-png" if item["path"].endswith(".png") else "native-fixture-evidence") == item
        return receipt

    version_run = process(version_ref, "exact-engine-receipt")
    donor_run = process(donor_ref, "fresh-import-receipt")
    export_run = process(build["export"], "embedded-export-receipt")
    export_log = next(item["path"] for item in export_run["logs"] if item["path"].endswith("/engine.log"))
    exported_resources = Path(export_log).read_text(encoding="utf-8-sig")
    exported_tests = set(re.findall(r"(?m)^.*savepack[^\n]*res://(game/tests/[^\s]+)$", exported_resources))
    assert exported_tests == {name + ".remap" for name in FIXTURES} | {name + "c" for name in FIXTURES if name.endswith(".gd")}
    scene = next(name for name in FIXTURES if name.endswith(".tscn"))
    assert re.search(r"savepack[^\n]*res://\.godot/exported/[^\n]*" + re.escape(Path(scene).stem) + r"\.scn", exported_resources)
    assert all(sha(Path(export_run["stage"]) / name) == digest for name, digest in build["runtime_sha256"].items())
    for filename in ["run.py", "freeze.py"]:
        add(HERE / filename, "private-evidence-tool")
    shown = set()
    unique_paths = set()
    unique_saves = set()
    runs = []
    for pair_path in args.pairs:
        pair_ref = add(pair_path, "writer-reader-pair")
        pair = read(pair_path)
        writer, reader = [process(reference, "native-process-receipt") for reference in pair["runs"]]
        assert writer["kind"] == pair["writer_mode"] and reader["kind"] == "read"
        assert bool(writer["release_directory"]) == bool(reader["release_directory"])
        key = (writer["kind"], pair["size"], bool(writer["release_directory"]))
        assert key in PAIRS and key not in shown
        shown.add(key)
        save = Path(writer["environment"]["SNAPLAND_SAVE_PATH"])
        assert save == Path(reader["environment"]["SNAPLAND_SAVE_PATH"]) and save not in unique_saves
        unique_saves.add(save)
        for receipt in [writer, reader]:
            locations = [receipt["stage"], *(receipt["environment"][name] for name in ("APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "CHOCOLATE_CAPTURE_DIR"))]
            assert all(Path(value).drive.upper() == "D:" for value in locations)
            assert len(set(locations)) == len(locations) and not unique_paths.intersection(locations)
            unique_paths.update(locations)
            assert receipt["marker_counts_engine_stdout_stderr"][0] == 1
            assert max(receipt["marker_counts_engine_stdout_stderr"]) == 1
        writer_ev = read(Path(writer["environment"]["CHOCOLATE_CAPTURE_DIR"]) / "chocolate-evidence.json")
        reader_ev = read(Path(reader["environment"]["CHOCOLATE_CAPTURE_DIR"]) / "chocolate-evidence.json")
        assert not writer_ev["failures"] and not reader_ev["failures"]
        profile_ref = add(save.parent / "native-originals.json", "writer-save-provenance")
        assert writer_ev["profile"] == reader_ev["profile"] == read(profile_ref["path"])
        for hashes in writer_ev["profile"]["hashes"].values():
            for path, digest in hashes.items():
                assert add(path, "persisted-original-or-thumbnail")["sha256"] == digest
        if writer["kind"] == "suite":
            assert sorted(item["label"] for item in writer_ev["routes"]) == ["assisted-ai", "devil", "material", "ordinary", "practice", "timeout"]
            assert len({entry["image"] for entry in writer_ev["lessons"]}) == 3
            assert all(len(layout["custom_controls"]) == 12 and not layout["errors"] for layout in writer_ev["layouts"] if "custom_controls" in layout)
        else:
            proof = writer_ev["retake"]
            assert proof["equal_original_pixels"] and proof["initial"]["acquisition_method"] == proof["after_challenge"]["acquisition_method"] == "retake"
            assert not proof["initial"]["challenge_earned"] and proof["after_challenge"]["challenge_earned"] == (writer["kind"] == "retake-devil")
            assert all(add(path, "persisted-original-or-thumbnail")["sha256"] == digest for path, digest in proof["files"].items())
        runs.append((key, pair_ref, writer, reader, writer_ev, reader_ev))
    assert shown == PAIRS

    def cite_receipt(record):
        return f'`{record["path"]}`  \nSHA-256 `{record["sha256"]}`, {record["bytes"]} bytes.'

    binary = build["binary"]
    engine = version_run["engine"]
    editor = version_run["editor_sibling"]
    lines = ["# SG-45 Task 4 · Native Main and independent Windows executable", "",
             "**Frozen scope** · Accepted native GPU evidence for 3 Main size suites, 4 selected retake pairs and 1 standalone Windows executable pair. Each pair has a fresh writer and an independent new-process reader. All 16 runtime processes exited 0, recorded the expected exact marker once per available engine output stream, and emitted zero `ERROR:` and genuine leak or still-in-use diagnostics.", "",
             f"Runtime source base `{BASE}` plus the two new Native Main fixture files. The complete raw source manifest records the fixtures and tracked runtime. It excludes repository `.uid` and `.import` sidecars. The fixture stages use verified asset-only reuse from one new exact-source D import. Task 1–3 suites remain prior evidence.", "",
             "## Actual Main, controls and layout", "",
             "The only synthetic progression is six welcome admission cards and opening seen. Setting the isolated viewport/accessibility profile and placing the actor at the sign `(0, GROUND_Y, -10.8)` or physical kiosk `(10.5, GROUND_Y, -0.8)` are labelled setup. Physical nearest selection and parsed E open the actual kiosk. Parsed M opens the actual ticket, then focused Enter drives the regional map’s five-entry list and chocolate invitation. Both the factory sign and achievement book show the catalog’s five delivered entries. Identity is `game-029` / `chocolate_etching` / candy local 5 / `photo-candy-game-5` / `photo-candy-devil-5` / `ACH_GAME_029`.", "",
             "All five actual rule pages and every semantic tutorial section are visited at each suite size. The three 1280×720 tutorial textures decode on the real Main and inside the standalone executable. Evidence JSON records active text/Button rectangles, clipping-ancestor intersections and fit. The actual pager selects the active semantic group while the inactive groups remain outside the scroll window. At 800×600 the shared tutorial uses its existing one-line ellipsis for the small screenshot alt caption. The existing tooltip and zoom UI use the full caption. The fixture verifies all semantic copy pages and their visible bodies, and leaves zoom unexercised. The house View checker plus measured transformed rectangles verify all 12 controls and bound text beneath the real Session HUD. The 800×600 pair saves and reloads text scale 1.25 and reduced motion.", "",
             "The fixture parses Godot keyboard, mouse and synthetic screen-touch events and flushes buffered events through the focused GUI and normal Session. Its local clock adapter calls Session `_process(delta)` for keyboard motion and held rotation and advances 1/120 second after each parsed workbench pointer or touch event while the Session is live. It reads snapshots and never advances the Driver or Model directly. Before a board capture it force-refreshes the HUD from the current actual Session snapshot. This presentation call advances no time. The existing HUD floors the outlet percentage and the board rounds the same numeric value to the nearest integer. The ordinary mid-turn capture therefore shows 20% and 21% for 1.3125 radians. Graphical setup may spend a few real frames before binding. Adapter seconds and total game seconds are both retained. Neither is human completion timing.", "",
             "A deep contour is submitted and undone. A single 0.5 contour remains attached. A matching second 0.5 contour cuts through, produces an actual measured outline and material hole, then undo restores the material without refunding time. A real HUD retry begins a clean round. Keyboard, mouse, and synthetic touch complete three-wheel, leftover four-wheel and assisted four-wheel-while-clamped routes respectively. Connected topology is measured from extracted radii and mounted positions. A held input drives actual outlet rotation to TAU, with positive rotation for the ordinary transmission and negative rotation through the intervening idler. The AI clamp starts with zero traces and participation. A genuinely submitted open stroke leads to qualified failure at the actual 240-second deadline. Real GUI practice can complete the four-wheel route without changes to rewards or photos. Esc drops the live preview, pause freezes material and elapsed time, and actual HUD leave confirmation cancels without awards.", "",
             "## Actual GPU shutter and persistence", "",
             "Each retake pair enters selected practice through the actual kiosk rules button, submits an actual cut, and leaves through the pause HUD to return to that selection. Parsed GUI arrangement changes prop, framing and distance. The real SubViewport shutter stores a 1280×720 original whose decoded pixels equal the arranged GPU frame and one decoded 320×180 thumbnail. A shutter gives only the selected card, `retake` acquisition and no challenge proof, one 40-coin receipt (120 → 160) and the fixed game achievement. Later actual matching completion preserves both stored paths, their SHA-256 and retake method. Only a matching devil completion adds devil proof and can acquire the other ordinary card.", "",
             "An independent reader verifies all acquired IDs, each complete provenance record and decoded file SHA, the exact 160 coins, the one game receipt, the region, the actual attempt/tutorial and the achievement. For ordinary gameplay, subsequent completion refreshes the shared latest gameplay photos. This behavior is distinct from the retake original preservation asserted before completion, afterward, and in the reader. No older factory card is granted.", "",
             "## Launch isolation and embedded output", "",
             f'Exact Godot console `{engine["path"]}` reports `{version_run["version"]}` and has SHA-256 `{engine["sha256"]}`. Its graphical sibling `{editor["path"]}` has SHA-256 `{editor["sha256"]}`. The actual native renderer logged Vulkan Forward+ on AMD Radeon RX 9070 XT. The independent Windows QA executable is `{binary["path"]}` ({binary["bytes"]:,} bytes, SHA-256 `{binary["sha256"]}`).', "",
             "The local validated-launcher timeout is 300 seconds. The inherited fixture wall-clock watchdog is 180 seconds. Before every launch the harness audits the staged script, scene, resource and configuration graph, including inherited base, autoloads and dynamic-loaded runtime paths. The four known fault-child parents are absent from staging and remain registered in CI. The exact six-file closure includes the two newly added fixture files, the existing Sugar base and AudioRelease helper, plus the unchanged Driver Route and View layout helpers authorized in the Task 4 handoff.", "",
             "Each version/import/export/runtime call has fresh absolute D stage, APPDATA, LOCALAPPDATA, TEMP, TMP and capture paths. The paired reader alone shares the writer save. Asset reuse contains only hashed import sidecars and addressed asset artifacts from the fresh exact-source import. Whole `.godot` caches, class/UID/script/editor caches and old builds are excluded. Engine log bytes are retained verbatim. The validated launcher's separately captured stdout and stderr are unsuppressed UTF-8 text re-encoded as UTF-8 by the harness. No diagnostics are filtered before writing logs. The audio-release helper checks destruction of captured playback references.", "",
             "The standalone PCK is embedded in a new Windows PE. Its private staged project points to the fixture and permits the exact staged Windows QA closure. The exporter’s own savepack log confirms every allowlisted test remap, the five compiled fixture scripts and the compiled scene, with no other test path. The export stage’s final source bytes match its audited graph. The production project main and normal Windows/Linux test exclusions remain intact. Both actual `.exe` launches use their clean release directory and only an absolute `--log-file` argument after the executable. They have no path/scene/project override or loose project/PCK.", ""]
    for kind, tpl in build["templates"].items():
        lines.append(f'- Pinned 4.7.2 Windows {kind} template `{tpl["path"]}` ({tpl["bytes"]:,} bytes), SHA-256 `{tpl["sha256"]}`.')
    lines.extend(["", "Selected executed source raw SHA-256 values", ""])
    source_names = [*FIXTURES, "game/main.gd", "game/minigames/session.gd", "game/minigames/chocolate_etching_driver.gd",
                    "game/minigames/chocolate_etching_view.gd", "game/minigames/chocolate_etching_model.gd", "game/minigames/chocolate_etching_geometry.gd"]
    for name in source_names:
        lines.append(f'- `{name}` · `{source["source_raw_sha256"][name]}`')
    lines.extend(["", "The full runtime graphs also retain the two QA-only staged configuration SHA values for the Windows executable. These are raw executed bytes. Git text normalization can produce different committed blob hashes.", "",
                  "Version receipt", "", cite_receipt(version_ref), "", "Fresh import receipt", "", cite_receipt(donor_ref), "",
                  "Fresh import addressed file list", "", cite_receipt(import_files), "", "Windows build identity", "", cite_receipt(build_ref), "",
                  "Windows exporter receipt", "", cite_receipt(build["export"]), "", "## Accepted runtime pairs", "",
                  "The pair receipts chain exact commands, isolated environment, complete source/runtime graphs, prelaunch audits, raw log hashes and all output hashes. Separate route clocks below reflect the actual Session stepping, with timing rounded here and full precision in the original evidence.", "",
                  "| Mode / dimensions | Writer and reader wall seconds | Writer and reader parsed events | Rule / lesson page / 12-control checkpoint counts | Pair receipt SHA-256 |", "|---|---:|---:|---:|---|"])
    for (mode, size, exe), pair_ref, writer, reader, writer_ev, reader_ev in runs:
        label = ("embedded " if exe else "") + mode + " " + size
        events = [sum(evidence["parsed_events"].values()) for evidence in [writer_ev, reader_ev]]
        counts = [sum(1 for layout in writer_ev["layouts"] if layout["capture"].startswith("rules-")),
                  len(writer_ev["lessons"]), sum(1 for layout in writer_ev["layouts"] if "custom_controls" in layout)]
        lines.append(f'| {label} | {writer["wall_seconds"]:.2f} / {reader["wall_seconds"]:.2f} | {events[0]} / {events[1]} | {counts[0]} / {counts[1]} / {counts[2]} | `{pair_ref["sha256"]}` |')
    lines.extend(["", "| Mode / dimensions | Route | Score | Elapsed / adapter seconds | Mid-turn output rad/s |", "|---|---|---:|---:|---:|"])
    for (mode, size, exe), _, _, _, writer_ev, _ in runs:
        label = ("embedded " if exe else "") + mode + " " + size
        for route in writer_ev["routes"]:
            if "elapsed" not in route:
                continue
            angle = f'{route["output_omega"]:+.2f}' if "output_omega" in route else "—"
            lines.append(f'| {label} | {route["label"]} | {route["score"]} | {route["elapsed"]:.3f} / {route["simulated_seconds"]:.3f} | {angle} |')
    lines.extend(["", "### Accepted receipt paths and raw SHA-256", ""])
    for key, pair_ref, writer, reader, _, _ in runs:
        lines.append(f'**{"embedded " if key[2] else ""}{key[0]} {key[1]}**')
        lines.append("")
        for record in [pair_ref, *read(pair_ref["path"])["runs"]]:
            lines.extend([cite_receipt(record), ""])
    all_receipts = [version_run, donor_run, export_run, *(receipt for item in runs for receipt in item[2:4])]
    lines.extend(["## Diagnostics, artifact promotion and limits", ""])
    messages = sorted({line for receipt in all_receipts for line in receipt["warnings"]})
    lines.append("Warnings recorded in the accepted receipt set." if messages else "Accepted version/import/export/runtime receipts contain no warning lines.")
    if messages:
        lines.append("")
        lines.extend("- `" + message.rstrip("\r") + "`" for message in messages)
    lines.extend(["", f'Archive inputs are explicitly enumerated by existing absolute path, raw SHA-256, byte count and category in `{HERE.as_posix()}/promoted-archive-allowlist.json`. That file includes final raw PNGs, still-referenced photos, all final receipts/audits/logs/source graphs and the private launch/freeze source. The hashed executable and templates remain on D.', "",
                  "Rejected probes stay distinct under the private D root. `draft1-1280` caught a fixture parser failure. `draft2-1280` passed writer gameplay but the reader rejected GDScript integer versus parsed JSON float types. The persisted JSON records matched. The 800 `current800` writer confirmed core gameplay and layout and exposed a fixture error that required visiting the actual stamp's page before expecting visible text. Unused candidate donor stages are retained with original hashes. These probes remain outside the promoted archive.", "",
                  "Production source, frozen tests/helpers, acceptance history, player saves and normal exports remained intact. This evidence is scripted GPU/input/persistence coverage on one machine. Human play timing, physical touch, hearing, cross-hardware behavior and walked admission were outside this verification.", ""])
    report = ROOT / ".superpowers/sdd/2026-11-18-chocolate-etching/task-4-report.md"
    with report.open("x", encoding="utf-8", newline="\n") as output:
        output.write("\n".join(lines))
    add(report, "task-4-frozen-report")
    archive = HERE / "promoted-archive-allowlist.json"
    dump(archive, {"task": "SG-45 Task 4", "source_base": BASE, "source_graph": donor_run["source_graph"],
                   "executable_retained_on_d": binary, "templates_retained_on_d": build["templates"],
                   "pair_receipts": [item[1] for item in runs], "files": sorted(promoted.values(), key=lambda entry: entry["path"])})
    print(report, archive, f"{len(promoted)} files", sep="\n")


if __name__ == "__main__":
    main()
