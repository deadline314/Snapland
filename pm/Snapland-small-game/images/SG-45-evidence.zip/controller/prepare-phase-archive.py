"""Select immutable SG45 evidence; never traverse runtime stages or caches."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent.parent
WORK = REPO / '.superpowers/sdd/2026-11-18-chocolate-etching'
rows = {}


def read(path):
    return json.loads(Path(path).read_bytes())


def add(path, category, expected=None, size=None):
    path = Path(path).resolve()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    assert expected is None or digest == expected, path
    assert size is None or path.stat().st_size == size, path
    if path in rows:
        assert rows[path]['sha256'] == digest, path
        return
    if path.is_relative_to(HERE):
        target = 'controller/' + path.relative_to(HERE).as_posix()
    elif path.is_relative_to(WORK):
        target = 'reviews/' + path.relative_to(WORK).as_posix()
    elif path.is_relative_to(REPO):
        target = 'source/' + path.relative_to(REPO).as_posix()
    else:
        target = None
        for folder, prefix in [('Snapland-chocolate-task1', 'model'), ('Snapland-chocolate-task2', 'presentation'), ('Snapland-chocolate-task4', 'native')]:
            parent = Path('D:/') / folder
            if path.is_relative_to(parent):
                target = prefix + '/runs/' + path.relative_to(parent).as_posix()
                break
        if target is None:
            parent = Path('D:/Snapland-QA')
            assert path.is_relative_to(parent) and path.relative_to(parent).parts[0].startswith('chocolate-integration-'), path
            target = 'integration/runs/' + path.relative_to(parent).as_posix()
    assert not target.startswith('/') and '..' not in Path(target).parts
    rows[path] = dict(path=path.as_posix(), archive=target, category=category,
                      sha256=digest, bytes=path.stat().st_size)


model = read(HERE / 'model/evidence-index.json')
for run in model['runs']:
    for name, info in run['files'].items():
        add(Path(run['directory']) / name, 'model-' + run['status'], info['sha256_raw_file_bytes'], info['bytes'])
for freeze in model['prior_freezes']:
    add(freeze['index_file'], 'historical-model-index', freeze['index_raw_sha256'])

for filename in ('evidence-index.json', 'evidence-index-fix1.json'):
    index = read(HERE / 'presentation' / filename)
    for run in index['runs'].values():
        folder = Path(run['folder'])
        add(folder / 'receipt.json', 'presentation-receipt', run['receipt_raw_sha256'])
        for name, digest in run['written_file_raw_sha256'].items():
            path = Path(name) if Path(name).is_absolute() else folder / name
            add(path, 'presentation-indexed-evidence', digest)

integration = read(HERE / 'integration/evidence-index.json')
for runs in list(integration['runs'].values()) + [read(HERE / 'integration/fix1-evidence-index.json')['launches']]:
    for run in runs:
        path = Path(run['receipt'])
        add(path, 'integration-receipt', run['sha256'])
        for name, digest in read(path)['receipt_artifacts'].items():
            add(path.parent / name, 'integration-raw-artifact', digest)

for phase in ('model', 'presentation', 'integration'):
    for path in sorted((HERE / phase).iterdir()):
        if path.is_file() and path.suffix in {'.json', '.log', '.py', '.txt'}:
            add(path, 'phase-index-history-or-harness')

native = read(HERE / 'native/promoted-archive-allowlist.json')
for row in native['files']:
    add(row['path'], row['category'], row['sha256'], row['bytes'])
for path in sorted(Path('D:/Snapland-chocolate-task4').iterdir()):
    if not path.is_dir():
        continue
    # Only named top-level receipts; no project/import/save or old PNG traversal.
    for name in ('receipt.json', 'engine.log', 'stdout.log', 'stderr.log', 'source-graph.json', 'runtime-graph.json', 'prelaunch-audit.json'):
        file = path / name
        if file.is_file() and file not in rows:
            add(file, 'historical-native-not-promoted')

archive_names = [row['archive'] for row in rows.values()]
assert len(archive_names) == len(set(archive_names))
output = HERE / 'phase-archive-inputs.json'
output.write_text(json.dumps({'scope': 'SG45 exact indexed evidence, explicitly labelled histories; excludes stage trees, caches and retained EXE/template binaries', 'files': list(rows.values())}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'files': len(rows), 'bytes': sum(r['bytes'] for r in rows.values()), 'output': str(output)}))
