extends "res://game/tests/test_chocolate_etching_driver.gd"

func _run() -> void:
	check(Geometry._segment_fraction(Vector2(100,100), Vector2(103,100), Vector2(107,100), Vector2(103,100)) == 1.0,
		"Reversed collinear segment includes the exact shared endpoint")
	_check_fine_placement()
	await _check_leftover_margin()
	print("FOCUSED %d checks, %d failures" % [checks, failures])
	quit(int(failures != 0))
