"""Only the focused GPU regression or the five game-029 suites."""
import re
import sys
from pathlib import Path
import run

label, phase = sys.argv[1:3]
focus = "game/tests/chocolate_final_focus.gd"
all_entries = ["game/tests/test_chocolate_etching" + suffix for suffix in (".gd", "_driver.gd", "_view.gd", "_session.gd", "_main.tscn")]
entries = [focus] if phase == "focus" else all_entries

def closure(entries):
    files = set()
    pending = list(entries)
    while pending:
        name = pending.pop()
        if name in files:
            continue
        files.add(name)
        assert Path(name).stem not in run.EXCLUDED
        pending.extend(re.findall(r'res://(game/tests/[^"\s]+\.(?:gd|tscn|json))', run.fixture_source(name).read_text(encoding="utf-8")))
    return sorted(files)

run.FIXTURES = closure(entries)
donor = Path(sys.argv[3]) if len(sys.argv) == 4 else run.bootstrap(label)
for entry in entries:
    run.FIXTURES = closure([entry])
    base, stage, manifest = run.prepare(label + "-" + Path(entry).stem, donor)
    args = [run.ENGINE, "--path", stage]
    args += ["--resolution", "1280x720", "--position", "10,40"] if phase == "focus" else ["--headless", "--audio-driver", "Dummy", "--rendering-method", "gl_compatibility"]
    if entry.endswith(".gd"):
        args += ["--script"]
    args += ["res://" + entry]
    run.launch(base, stage, manifest, "focused-gpu" if phase == "focus" else "local-suite", args, run.environment(base))
    log = (base / "engine.log").read_text(encoding="utf-8-sig")
    assert re.search(r"(?:0 failures|PASS:)", log), base
