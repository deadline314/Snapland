"""Verify and freeze an post-fix game-029 evidence set from fresh D outputs."""

import argparse
from datetime import datetime, timedelta
from pathlib import Path
import re
import subprocess

from run import BASE, FIXTURES, HERE, ROOT, describe, dump, read, sha
from tools.run_game_tests import result_error


PAIRS = {("suite", "1280x720", False), ("suite", "1152x648", False), ("suite", "800x600", False),
         ("retake-ordinary", "1280x720", False), ("retake-ordinary", "800x600", False),
         ("retake-devil", "1280x720", False), ("retake-devil", "1152x648", False), ("suite", "1280x720", True)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--version", type=Path, required=True)
    parser.add_argument("--donor", type=Path, required=True)
    parser.add_argument("--build", type=Path, required=True)
    parser.add_argument("pairs", type=Path, nargs=8)
    args = parser.parse_args()
    promoted = {}

    def add(path, kind):
        entry = describe(path)
        promoted.setdefault(entry["path"], {**entry, "category": kind})
        return entry

    version_ref = add(args.version / "receipt.json", "exact-engine-receipt")
    donor_ref = add(args.donor / "receipt.json", "fresh-import-receipt")
    import_files = add(args.donor / "asset-import-files.json", "fresh-asset-import-identity")
    build_ref = add(args.build / "build.json", "embedded-build-identity")
    add(args.build / "embedded-acceptance.json", "embedded-acceptance-pair")
    build = read(build_ref["path"])
    assert describe(build["binary"]["path"]) == build["binary"]
    assert all(describe(tpl["path"]) == tpl for tpl in build["templates"].values())
    source = read(args.donor / "source-graph.json")
    assert source["commit_base"] == BASE and source["fixtures"] == FIXTURES
    assert all(sha(ROOT / name) == digest for name, digest in source["source_raw_sha256"].items())

    def process(reference, kind):
        assert add(reference["path"], kind) == reference
        receipt = read(reference["path"])
        assert receipt["passed"] and receipt["exit_code"] == 0 and not receipt["errors"] and not receipt["leak_diagnostics"]
        assert read(receipt["source_graph"]["path"]) == source
        audit = read(receipt["audit"]["path"])
        assert audit["fixture_closure"] == FIXTURES and not audit["child_launch_candidates"]
        for key, category in (("source_graph", "process-source-graph"), ("runtime_graph", "process-runtime-graph"),
                              ("audit", "process-prelaunch-audit"), ("asset_import_reuse", "asset-import-reuse")):
            if receipt[key] is not None:
                assert add(receipt[key]["path"], category) == receipt[key]
        for log in receipt["logs"]:
            assert add(log["path"], "engine-raw-log" if log["path"].endswith("/engine.log") else "unsuppressed-launcher-stdio") == log
        for item in receipt["capture_outputs"]:
            assert add(item["path"], "raw-native-png" if item["path"].endswith(".png") else "native-fixture-evidence") == item
        return receipt

    version_run = process(version_ref, "exact-engine-receipt")
    donor_run = process(donor_ref, "fresh-import-receipt")
    export_run = process(build["export"], "embedded-export-receipt")
    export_log = next(item["path"] for item in export_run["logs"] if item["path"].endswith("/engine.log"))
    exported_resources = Path(export_log).read_text(encoding="utf-8-sig")
    exported_tests = set(re.findall(r"(?m)^.*savepack[^\n]*res://(game/tests/[^\s]+)$", exported_resources))
    assert exported_tests == {name + ".remap" for name in FIXTURES} | {name + "c" for name in FIXTURES if name.endswith(".gd")}
    scene = next(name for name in FIXTURES if name.endswith(".tscn"))
    assert re.search(r"savepack[^\n]*res://\.godot/exported/[^\n]*" + re.escape(Path(scene).stem) + r"\.scn", exported_resources)
    assert all(sha(Path(export_run["stage"]) / name) == digest for name, digest in build["runtime_sha256"].items())
    for filename in ["run.py", "freeze.py", "graph.py"]:
        add(HERE / filename, "private-evidence-tool")
    shown = set()
    unique_paths = set()
    unique_saves = set()
    runs = []
    for pair_path in args.pairs:
        pair_ref = add(pair_path, "writer-reader-pair")
        pair = read(pair_path)
        writer, reader = [process(reference, "native-process-receipt") for reference in pair["runs"]]
        assert writer["kind"] == pair["writer_mode"] and reader["kind"] == "read"
        assert bool(writer["release_directory"]) == bool(reader["release_directory"])
        key = (writer["kind"], pair["size"], bool(writer["release_directory"]))
        assert key in PAIRS and key not in shown
        shown.add(key)
        save = Path(writer["environment"]["SNAPLAND_SAVE_PATH"])
        assert save == Path(reader["environment"]["SNAPLAND_SAVE_PATH"]) and save not in unique_saves
        unique_saves.add(save)
        for receipt in [writer, reader]:
            locations = [receipt["stage"], *(receipt["environment"][name] for name in ("APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "CHOCOLATE_CAPTURE_DIR"))]
            assert all(Path(value).drive.upper() == "D:" for value in locations)
            assert len(set(locations)) == len(locations) and not unique_paths.intersection(locations)
            unique_paths.update(locations)
            assert receipt["marker_counts_engine_stdout_stderr"][0] == 1
            assert max(receipt["marker_counts_engine_stdout_stderr"]) == 1
        writer_ev = read(Path(writer["environment"]["CHOCOLATE_CAPTURE_DIR"]) / "chocolate-evidence.json")
        reader_ev = read(Path(reader["environment"]["CHOCOLATE_CAPTURE_DIR"]) / "chocolate-evidence.json")
        assert not writer_ev["failures"] and not reader_ev["failures"]
        profile_ref = add(save.parent / "native-originals.json", "writer-save-provenance")
        assert writer_ev["profile"] == reader_ev["profile"] == read(profile_ref["path"])
        for hashes in writer_ev["profile"]["hashes"].values():
            for path, digest in hashes.items():
                assert add(path, "persisted-original-or-thumbnail")["sha256"] == digest
        if writer["kind"] == "suite":
            assert sorted(item["label"] for item in writer_ev["routes"]) == ["assisted-ai", "devil", "material", "ordinary", "practice", "timeout"]
            for slide in range(1, 4):
                rows = [entry for entry in writer_ev["lessons"] if entry["capture"].startswith(f"tutorial-{slide}-copy-")]
                assert rows and all(entry["image"] == f"res://assets/ui/tutorials/game-029-step-{slide:02}.png" for entry in rows)
                assert [i for row in rows for i in row["semantic_indices"]] == list(range(5))
            assert {f"old-stock-cut-{name}.png" for name in ("idler", "owner", "undone")} <= {Path(item["path"]).name for item in writer["capture_outputs"]}
            percentages = [re.search(r"(\d+)%", leaf["text"])[1] for layout in writer_ev["layouts"] if layout["capture"] == "ordinary-output-rotation.png"
                           for leaf in layout.get("leaves", []) if "%" in leaf["text"]]
            assert percentages == ["20", "20"], percentages
            assert all(len(layout["custom_controls"]) == 12 and not layout["errors"] for layout in writer_ev["layouts"] if "custom_controls" in layout)
        else:
            proof = writer_ev["retake"]
            assert proof["equal_original_pixels"] and proof["initial"]["acquisition_method"] == proof["after_challenge"]["acquisition_method"] == "retake"
            assert not proof["initial"]["challenge_earned"] and proof["after_challenge"]["challenge_earned"] == (writer["kind"] == "retake-devil")
            assert all(add(path, "persisted-original-or-thumbnail")["sha256"] == digest for path, digest in proof["files"].items())
        runs.append((key, pair_ref, writer, reader, writer_ev, reader_ev))
    assert shown == PAIRS

    native_index = HERE / "promoted-archive-allowlist.json"
    native_files = {"scope": "post-fix native final source only", "base": BASE, "source_graph": donor_run["source_graph"],
                    "executable_retained_on_d": build["binary"], "templates_retained_on_d": build["templates"],
                    "pair_receipts": [item[1] for item in runs], "files": sorted(promoted.values(), key=lambda item: item["path"])}
    refs = {}
    local_files = {}
    def retain_local(path, kind):
        entry = describe(path)
        local_files[entry["path"]] = {**entry, "category": kind}
        return entry
    d_root = args.donor.parent
    for receipt_path in sorted(d_root.glob("*/receipt.json")):
        receipt = read(receipt_path)
        if str(receipt_path.parent).startswith(str(d_root / "final-")) and not receipt_path.parent.name.startswith("final-suites-"):
            continue
        ref = retain_local(receipt_path, "local-process-receipt")
        raw_log = receipt_path.parent / "engine.log"
        summaries = []
        if raw_log.exists():
            lines = raw_log.read_text(encoding="utf-8-sig").splitlines()
            summaries = [line for line in lines if line.startswith(("Chocolate etching", "CHOCOLATE ", "FOCUSED ", "STOCK_FRAME ", "PASS:"))]
        refs[receipt_path.parent.name] = {"receipt": ref, "strict_pass": receipt["passed"], "errors": receipt["errors"],
                                          "warnings": receipt["warnings"], "summaries": summaries}
        if receipt["kind"] == "local-suite":
            labels = {"test_chocolate_etching": "model", "test_chocolate_etching_driver": "driver", "test_chocolate_etching_view": "view",
                      "test_chocolate_etching_session": "Session", "test_chocolate_etching_main": "Main"}
            entry = next(value for value in receipt["command"] if value.startswith("res://game/tests/"))
            check = "chocolate " + labels[Path(entry).stem] + " tests"
            result = subprocess.CompletedProcess(receipt["command"], receipt["exit_code"],
                       (receipt_path.parent / "stdout.log").read_text(encoding="utf-8"), (receipt_path.parent / "stderr.log").read_text(encoding="utf-8"))
            assert receipt["passed"] and result_error(check, result, receipt["environment"]["SNAPLAND_SAVE_PATH"]) is None, check
            refs[receipt_path.parent.name]["ci_marker_verified"] = check
        for reference in [receipt["source_graph"], receipt["runtime_graph"], receipt["audit"], *receipt["logs"], *receipt["capture_outputs"]]:
            assert retain_local(reference["path"], "local-launch-evidence") == reference
        if receipt["asset_import_reuse"]:
            assert retain_local(receipt["asset_import_reuse"]["path"], "local-import-reuse") == receipt["asset_import_reuse"]
        if receipt["kind"] == "import":
            retain_local(receipt_path.parent / "asset-import-files.json", "local-import-identity")
    local_index = HERE / "local-evidence.json"
    assert sum("ci_marker_verified" in entry for entry in refs.values()) == 5
    old_focus = read(next(d_root.glob("calibrated-red-chocolate_final_focus-*/receipt.json")))
    first_green = read(next(d_root.glob("calibrated-green-chocolate_final_focus-*/receipt.json")))
    last_green = read(next(d_root.glob("sequential-green-chocolate_final_focus-*/receipt.json")))
    old_graph = read(old_focus["source_graph"]["path"])["source_raw_sha256"]
    green_graph = read(last_green["source_graph"]["path"])["source_raw_sha256"]
    assert read(first_green["source_graph"]["path"])["source_raw_sha256"] == green_graph
    differences = {name for name, digest in old_graph.items() if green_graph[name] != digest}
    assert differences == {"game/minigames/chocolate_etching_" + suffix + ".gd" for suffix in ("model", "geometry", "driver", "view")}
    for name in differences:
        assert sha(HERE / "baseline" / Path(name).name) == old_graph[name]
    assert last_green["passed"] and datetime.fromisoformat(last_green["started_utc"]) > datetime.fromisoformat(old_focus["started_utc"]) + timedelta(seconds=old_focus["wall_seconds"])
    inputs = ["focused.gd", "local.py", "games.log", "links.log", "design-python.log", "runtime-python.log", "runtime-markers-python.log"]
    dump(native_index, native_files)
    for path in [*(HERE / name for name in inputs), *(HERE / "baseline").glob("*.gd")]:
        retain_local(path, "local-probe-input")
    dump(local_index, {"processes": refs, "files": sorted(local_files.values(), key=lambda entry: entry["path"])})

    def ref(entry):
        return f'`{entry["path"]}` ({entry["bytes"]:,} bytes, SHA-256 `{entry["sha256"]}`)'

    changed = ["design/runtime/chocolate-etching-gameplay.md", *["game/minigames/chocolate_etching_" + name + ".gd" for name in ("model","geometry","driver","view")],
               *["game/tests/test_chocolate_etching" + suffix + ".gd" for suffix in ("","_driver","_view")], FIXTURES[1],
               "tools/run_game_tests.py", "tests/test_runtime_result_contract.py"]
    report = ["# SG-45 final review fix", "",
              f"Input commit `{BASE}`. The reviewed production and fixture bytes are listed below. The post-fix native graph uses one immutable raw source graph with {len(source['source_raw_sha256'])} entries. All 8 independent writer/reader pairs passed, including the new embedded Windows executable. All five game-029 suites passed.", "",
              "## Player behavior and bounded rendering", "",
              "An in-board drop calls the existing place-only model operation. A two-unit correction from four units off the input shaft leaves the wheel mounted and brings it into tolerance. An identical coordinate after the design/board round-trip is a no-op using Godot’s Vector2 approximate equality. Explicit F and the on-screen 放／取 retain their three-unit removal radius. The tests check real outlet travel, cancel, undo and structural progress reset.", "",
              "The model increments stock_revision after a genuine cut, fold, undo or reset. Selection and time preserve the revision. Its read-only stock_strokes() returns a deep copy of at most 4×8 committed lines of up to 512 points. Ordinary per-frame snapshots still contain only selected strokes. The Driver supplies the copy to its View on a revision change. One retained StockSurface draws the heat underneath the extracted holes and below interactive overlays. Each stock/phase refresh rebuilds its draw commands. Existing dynamic cursor and gear presentation continue separately. A regression mutates the returned copy and checks the model’s points and depth.", "",
              "The workbench and HUD read the same floored output_percent. A real 99.5% turn displays 99% in both, and both reach 100% on success. The separate 10 Hz HUD cadence can briefly retain an earlier state. Three exact ordered lesson texture paths and five semantic indices are asserted. The collinear predicate projects the second endpoint from A directly and returns fraction 1 for A=(100,100), B=(103,100), C=(107,100), D=B.", "",
              "## Actual chronology", "",
              "The original focused GPU probe ran on the unedited base runtime first. Both two-unit placements lost the wheel, both selected-board frames had zero heat at the known damaging line, and the shared endpoint was lost. Its nine behavioral failures were recorded before product edits. The first changed-source candidate fixed the visible marks, placement and endpoint but failed two driving expectations. Measured pitch circles showed the test’s straight middle placement was too close to the corrected wheel. The final fixture places the middle wheel at the intersection of both measured pitch distances, then exercises the unaltered two-unit move. The identical calibrated fixture ran against the base-hashed runtime again and against final production. All candidate and final local receipt paths, errors, exact commands, environments, raw outputs and graphs are indexed below.", "",
              f"Calibrated RED started {old_focus['started_utc']} ({old_focus['wall_seconds']:.3f} s), and the first calibrated GREEN started {first_green['started_utc']} ({first_green['wall_seconds']:.3f} s). These calls overlapped. The additional identical focused GREEN started {last_green['started_utc']} ({last_green['wall_seconds']:.3f} s), strictly after the completed RED, in a fresh stage/profile with the calibrated GREEN asset donor. Raw source comparison proves the calibrated old and final graphs differ in only the four production scripts. The focused fixture and all other manifest bytes match.", "",
              ref(describe(local_index)), ""]
    for key, item in refs.items():
        if "chocolate_final_focus" in key or key.startswith("final-suites-test"):
            report += [f"- {key} · {ref(item['receipt'])}", "  " + " / ".join(item["summaries"])]
    report += ["", "The focused and native frame probes sample a 5×5 pixel region around the midpoint of the actual stored half-depth cut from (344.353881835938,288.465301513672) to (350.608642578125,283.477508544922). The old line intersects only the idler removal margin, clears the retained idler and the three main footprints, then specifically prevents the fourth extraction. Both idler and freed-owner captures precede drawing the idler contours. The sampled heat from the old owner cut disappears after undoing it. A sampled former contour in an extracted hole stays clear. Captures are raw GPU PNGs. The 8 Model and 24 Driver completion routes remain covered.", "",
               "## Commands and isolation", "", "Private launch commands relative to the final-fix evidence directory", "",
               "`python local.py red focus`, `python local.py green focus`, `CHOCOLATE_BASELINE_SOURCE=1 python local.py calibrated-red focus`, `python local.py calibrated-green focus`, `python local.py final-suites suites`, `python graph.py`, then `python local.py sequential-green focus D:/Snapland-chocolate-final-fix/calibrated-green-donor-1118-134355-35dbfd`. The alternate baseline contains the exact Git-base geometry, model, driver and view, verified against the pre-edit raw engine graph. The first changed candidate and focused calibrated runs are diagnostics outside the final native graph.", "",
               "Project-root checks were `python tools/verify_design.py --scope games`, `python tools/verify_design.py --scope links`, `python -m unittest discover -s tests -p test_design_validation.py -v`, and `python -m unittest discover -s tests -p test_runtime_result_contract.py -v`. Both design scopes, 47 design and 23 runtime Python tests passed.", "",
               "Six exact CI-marker counts were updated after the five actual suite results: 217 Model, 92 Driver, 33 View in both the runner and its contract fixture. The 23 Python result-contract tests were rerun afterward and each actual saved process stdout/stderr was checked against result_error during this freeze. These two Python files are outside the embedded/runtime source graph. This metadata change does not alter its frozen bytes.", "",
               f"Exact version `{version_run['version']}`. Console {ref(version_run['engine'])}. Graphical sibling {ref(version_run['editor_sibling'])}.",
               "Every launch used run_validated_godot after an audit of the entire staged script/scene/config/resource closure. Local exclusions are test_photo_retake_main, test_region_travel, test_photo_retake_progress and test_region_progress. Six QA-only native closure files include the Sugar native base, audio helper, Driver route, View layout helper and chocolate fixture scene/script. Each process has a fresh absolute D stage and APPDATA, LOCALAPPDATA, TEMP, TMP and capture directory. Only a paired reader shares its writer save. Approved reuse is confined to addressed, hashed fresh D asset imports; script UID/class caches and C project caches were excluded. SceneTree cases used --script and Node cases their real scene. Exact engine/EXE commands and absolute environment are in every process receipt. Engine logs are raw, stdio is unsuppressed re-encoded UTF-8.", "",
               "## Final source identities", ""]
    for name in changed:
        report.append(f"- {ref(describe(ROOT / name))}")
    report += ["", "## Final native evidence", "", "Raw native existing-path/byte/SHA-256 allowlist " + ref(describe(native_index)), "",
               "Native donor source graph " + ref(donor_run["source_graph"]), "Standalone build " + ref(build_ref),
               "Embedded Windows executable " + ref(build["binary"]), ""]
    report += [f"- Windows {kind} template {ref(entry)}" for kind, entry in build["templates"].items()]
    for key, pair_ref, writer, reader, writer_ev, _ in runs:
        report += ["", f"**{key[0]} {key[1]}{' embedded executable' if key[2] else ' editor runtime'}**", "",
                   ref(pair_ref), "", *[ref(entry) for entry in read(pair_ref["path"])["runs"]]]
        if key[0] == "suite":
            log = Path(writer["stage"]).parent / "engine.log"
            report += ["", *[line for line in log.read_text(encoding="utf-8-sig").splitlines() if line.startswith("STOCK_FRAME ")]]
    accepted = [version_run, donor_run, export_run, *(r for item in runs for r in item[2:4])]
    native_warnings = sorted({line for r in accepted for line in r["warnings"]})
    report += ["", "## Diagnostics and limits", "",
               "All accepted launches exited zero with no engine errors or genuine leaks. The native GPU writer/reader graph verifies actual ordinary/devil, material/undo/retake/provenance, practice and independent reader state. The inherited fixture advances the ordinary Session clock; each live pointer event ticks 1/120 s and a capture force-refreshes the HUD. The standalone PE was exported from the final graph against pinned templates and both processes executed it with only a log-file argument. Normal player export settings were not modified.", "",
               "Both actual HUD and workbench label texts in the ordinary mid-turn capture showed 20% in each suite writer. The 5×5 heat and hole probes establish visibility at the reviewed margin and owner contour probe locations under the recorded overlay positions. Existing center markers, clamps, guides and cursor can obscure portions of a trace. The headless Main suite emitted 45 distinct existing occlusion warnings preserving unsupported ShaderMaterial/StandardMaterial3D building materials; its receipt keeps the full lines. Native/import/export warnings, if present, follow.", "",
               f"The 19 final native version/import/export and writer/reader receipts recorded {len(native_warnings)} distinct warnings.",
               *[f"- `{line.strip()}`" for line in native_warnings], "",
               "All 1,183 prior root archive inputs and the 466 Task 4 items remain pre-fix provenance only. No previous report, native package, executable or capture was amended. Scripted single-machine results do not establish human timing, listening, physical-touch ergonomics, cross-device performance, walked admission, independent earning of the six welcome cards, or manual art acceptance. Earlier unaffected games, excluded fault-child parents and the full native zoom route were not locally replayed. Root owns the exact commit, scoped re-review, archive, PM, merge and CI.", ""]
    destination = ROOT / ".superpowers/sdd/2026-11-18-chocolate-etching/final-fix-report.md"
    with destination.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write("\n".join(report))
    print(ref(describe(destination)), ref(describe(native_index)), len(promoted))

if __name__ == "__main__":
    main()

