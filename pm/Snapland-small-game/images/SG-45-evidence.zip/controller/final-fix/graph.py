import sys
import run

donor = run.bootstrap("final-native")
for mode, size in [("suite", "1280x720"), ("suite", "1152x648"), ("suite", "800x600"),
                   ("retake-ordinary", "1280x720"), ("retake-devil", "1280x720"), ("retake-ordinary", "800x600"), ("retake-devil", "1152x648")]:
    run.pair(f"final-{size}", size, mode, donor)
run.embedded("final-embedded", donor)
