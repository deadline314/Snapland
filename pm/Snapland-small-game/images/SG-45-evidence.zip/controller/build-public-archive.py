"""Build SG45 evidence after final review, preserving earlier source attribution."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent.parent
WORK = REPO / '.superpowers/sdd/2026-11-18-chocolate-etching'
OUTPUT = REPO / 'pm/Snapland-small-game/images/SG-45-evidence.zip'
rows = {}
names = set()


def read(path):
    return json.loads(Path(path).read_bytes())


def add(path, category, expected=None, size=None, archive=None):
    path = Path(path).resolve()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    assert expected is None or digest == expected, path
    assert size is None or path.stat().st_size == size, path
    if path in rows:
        assert rows[path]['sha256'] == digest, path
        return
    if archive is None:
        if path.is_relative_to(HERE):
            archive = 'controller/' + path.relative_to(HERE).as_posix()
        elif path.is_relative_to(WORK):
            archive = 'reviews/' + path.relative_to(WORK).as_posix()
        elif path.is_relative_to(REPO):
            archive = 'source/' + path.relative_to(REPO).as_posix()
        else:
            parent = Path('D:/Snapland-chocolate-final-fix')
            assert path.is_relative_to(parent), path
            archive = 'final-fix/runs/' + path.relative_to(parent).as_posix()
    assert archive not in names and not archive.startswith('/') and '..' not in Path(archive).parts, archive
    names.add(archive)
    rows[path] = dict(path=path.as_posix(), archive=archive, category=category,
                      sha256=digest, bytes=path.stat().st_size)


assert not OUTPUT.exists(), 'Never overwrite delivered evidence.'
assert (WORK / 'final-rereview-1.md').is_file()
for row in read(HERE / 'phase-archive-inputs.json')['files']:
    add(row['path'], 'pre-final-fix/' + row['category'], row['sha256'], row['bytes'], row['archive'])
for name in ('promoted-archive-allowlist.json', 'local-evidence.json'):
    path = HERE / 'final-fix' / name
    add(path, 'post-final-fix-index')
    for row in read(path)['files']:
        add(row['path'], 'post-final-fix/' + row['category'], row['sha256'], row['bytes'])
for path in sorted(WORK.iterdir()):
    if path.is_file() and path.suffix in {'.md', '.diff'}:
        add(path, 'requirements-reviews-and-decisions')
for name in subprocess.check_output(['git', 'diff', '--name-only', '-z', 'd2ee8453e70bbb21d9b5d2de80a1953452a05759..HEAD'], cwd=REPO).split(b'\0'):
    if name:
        name = name.decode('utf-8')
        if not name.startswith('pm/'):
            add(REPO / name, 'post-final-fix-reviewed-source')
for name in ('native/promoted-archive-allowlist.json', 'root-native-freeze-verification.json',
             'root-native-visual-review.json', 'root-final-fix-freeze-verification.json',
             'root-final-fix-visual-review.json', 'merged-checks/source-commits.json',
             'merged-checks/final-fix-source-commits.json', 'merged-checks/feature-ci-451-final.json',
             'phase-archive-inputs.json', 'pm-image-provenance.json', 'rulings.md',
             'final-dispositions.md', 'archive-input-plan.md', 'prepare-phase-archive.py',
             'build-public-archive.py'):
    add(HERE / name, 'controller-evidence-and-packaging')
for name in ('feature-ci-c2dc-initial.json', 'feature-ci-c2dc-final.json'):
    path = HERE / 'merged-checks' / name
    if path.is_file():
        add(path, 'source-ci-status-with-exact-head')

manifest = dict(scope='SG45 post-final-fix evidence with explicitly attributed earlier histories. Scripted inputs/GPU and one machine, no human enjoyment, listening, physical touch, cross-device or walked admission claim. EXE/templates retained on D with identities in reports, not embedded in this ZIP.', files=list(rows.values()))
OUTPUT.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(OUTPUT, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for row in rows.values():
        archive.write(row['path'], row['archive'])
    archive.writestr('MANIFEST.json', json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
with zipfile.ZipFile(OUTPUT) as archive:
    assert archive.testzip() is None
    for row in rows.values():
        assert hashlib.sha256(archive.read(row['archive'])).hexdigest() == row['sha256'], row['archive']
with OUTPUT.open('rb') as stream:
    digest = hashlib.file_digest(stream, 'sha256').hexdigest()
result = dict(path=str(OUTPUT), entries=len(rows) + 1, bytes=OUTPUT.stat().st_size, sha256=digest)
(HERE / 'archive-result.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result))
