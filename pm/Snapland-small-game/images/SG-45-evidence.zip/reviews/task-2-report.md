# Task 2 — Drawing input and workshop presentation

DONE for exact commit and fresh review. Effective BASE `4f8cef88de82db0e3be48fb01ecce753adde362a` includes the separately approved core precision follow-up. The presentation consumed the approved geometry and unchanged Model. See `task-1-core-rereview-3.md`.

## Frozen scope

| Owned file | Raw SHA-256 |
|---|---|
| `game/minigames/chocolate_etching_driver.gd` | `4785919dcf4604ea0813d6ed1a0ffd775d20620a9a57b8d6c66c9ad7214cf363` |
| `game/minigames/chocolate_etching_view.gd` | `343e6441c59d1cfd62d571b2d55dddaae430840bc9a0ad000500d8ddfa5b30b8` |
| `game/tests/test_chocolate_etching_driver.gd` | `66491231c3cfafd3978166a2f55b7b509907104400bb3829536451e1f93c5629` |
| `game/tests/test_chocolate_etching_view.gd` | `7aaa70f8edc4181c96e80578735669900ca770c816a3fe6374c34ba1b31bb726` |
| `game/tests/native_chocolate_etching_workbench_review.gd` | `4fce57adb59cab0bbd985404aeb264ad7f4893496c5aa56804667435e8fd83cf` |
| `game/tests/native_chocolate_etching_workbench_review.tscn` | `543c57dab4b206c677862169afe42b1307fca6a9c3c8c6bd27457e34dfaf9805` |
| `assets/ui/tutorials/game-029-step-01.png` | `0b18be7ab7038b01a098ff3ae203cac46039623d86d8b4d992ef663b95189f83` |
| `assets/ui/tutorials/game-029-step-02.png` | `5628205de661775642f7eb167dabae567d4c77220974379a19b40409362f937d` |
| `assets/ui/tutorials/game-029-step-03.png` | `d0c275e1e59cf9e5be0d7868e7f09b5677f27df0b96c701ed2bee6cbc4ef90a6` |

All six source files passed trailing-whitespace and EOF checks. The five final receipts match all current source files applicable to their exact launch closures. The PNGs were copied after capture and the workbench fixture does not load them. The index records the exact omissions from each stage and the four verified raw core hashes.

## Final verification

All five processes exited 0 with empty stderr and no Godot script errors, errors, warnings or leak markers in their engine logs.

| Result | Fresh D directory below `D:/Snapland-chocolate-task2/` | Raw UTF-8 Godot log SHA-256 |
|---|---|---|
| Driver 62 checks, 0 failures. 24 complete routes. | `20261118-123751-305854-driver-freeze` | `9dbc99d15eb68fd07a4e952fe47b0d77b171990449205c2712afe6b020c98798` |
| View 30 checks, 0 failures. | `20261118-123751-308446-view-freeze` | `23db1e7fc29a540477ac0d3602f380005dbcbc76dd6deb33cd92984613a4684d` |
| Native 1280×720. 180 checks, 0 failures. 3 complete routes, 11 captures. | `20261118-123801-331982-native-1280x720-freeze` | `12df02eccbab5f87011e28d05ff69076de7c693f6b6dfcbbba1f66ac6c077c5e` |
| Native 1152×648. 180 checks, 0 failures. 3 complete routes, 11 captures. | `20261118-123811-111874-native-1152x648-freeze` | `dbd45c8579952786141d290ac235aa272aff890dd66afea96b9de5a3c2d7b53b` |
| Native 800×600. 180 checks, 0 failures. 3 complete routes, 11 captures. | `20261118-123751-306112-native-800x600-freeze` | `76eb2dfffcc224af2036240b40da5821beca19c3380a12a70afa72b155797cfa` |

Driver boundaries cover W plus Up, held opposite directions and recovery, Space during motion, echoed Tab, both depth clamps, depth/selection/phase cancellation, emulated mouse, second touch, wrong-source release, matched touch cancel, nonfinite pointer input, outside release, pause clear, retry clear, eight undo entries, eight strokes and 512 points. Pointer and touch events use the same board transform and command centers as the View. A stationary click gives no participation. Undo keeps elapsed time and participation. Assisted undo adds no mistake.

Both previously deferred cases pass through actual Driver events. Rigid 0.18 rad rotations about each opposite shaft preserve contacts [(0,1),(1,2)] while the displaced shaft independently blocks travel. The fourth-wheel case commits a gear-0 stroke from (344.353881835938,288.465301513672) to (350.608642578125,283.477508544922) with half-width 1.75. Its kerf clears all three main footprints and the idler retained outline. All three main wheels still fold, and the idler fold is refused specifically because that old stroke hits its removal-only margin.

## Driver routes

Keyboard routes use held directional inputs and elapsed Driver.step calls at the model speed. The fixture follows a bounded octile approximation for unassisted play. Assisted steering chooses held-key timings along projected guide segments to keep the actual recorded samples within the original point cap. All cursor movement, cutting and placement still go through input events. Keyboard uses .25 depth. Pointer and touch use .50. The fixture derives all placement centers from extracted wheel radii. Every route reaches one complete turn of actual output and places all three main wheels on its path. The evidence index retains all cut and stroke counts, radii, placement centers, drive angles and contact pairs.

| Source | Board | Assist | Ordinary score / elapsed seconds | Idler score / elapsed seconds |
|---|---|---|---:|---:|
| Keyboard | A | Off | 400 / 83.860756 | 500 / 99.468431 |
| Keyboard | A | On | 400 / 65.790077 | 500 / 77.945981 |
| Keyboard | B | Off | 400 / 83.439062 | 500 / 102.165392 |
| Keyboard | B | On | 400 / 66.111479 | 500 / 80.982872 |
| Pointer | A | Off | 400 / 3.141593 | 500 / 3.141593 |
| Pointer | A | On | 400 / 3.141593 | 500 / 3.141593 |
| Pointer | B | Off | 400 / 3.590392 | 500 / 3.590392 |
| Pointer | B | On | 400 / 3.590392 | 500 / 3.590392 |
| Touch | A | Off | 400 / 3.141593 | 500 / 3.141593 |
| Touch | A | On | 400 / 3.141593 | 500 / 3.141593 |
| Touch | B | Off | 400 / 3.590392 | 500 / 3.590392 |
| Touch | B | On | 400 / 3.590392 | 500 / 3.590392 |

The pointer and touch fixture dispatches tracing points immediately. Their elapsed values measure output rotation.

## Native workbench and tutorials

The fixture uses `Input.parse_input_event` into the focused Control. Parsed Tab changes the selected gear while the alternate focus target stays unfocused. Real Control focus loss stops movement. Tree exit clears a live cutting preview. The 1280 and 1152 launches use text scale 1.0. The 800 launch uses 1.25 and reduced motion with the same cut geometry, contact lines, angle changes and output progress.

| Representative per size | Parsed events | Output at capture | Natural score |
|---|---:|---|---:|
| Keyboard ordinary A | 5,332 | +2 rad/s and 1.5 rad accumulated | 400 |
| Pointer leftover idler B | 358 | −1.75 rad/s and 1.3125 rad accumulated | 500 |
| Assisted touch leftover idler A | 346 | −2 rad/s and 1.5 rad accumulated | 500 |

Each native process parses 6,259 events including lifecycle and missteps. Its 11 checkpoints scan all 12 transformed command rectangles and every active text element against viewport and clipping ancestors. The raw states include shallow connection, successful retrace, interior kerf refusal, active cutting, undo with outside cancellation, invalid placement, solid mount and dashed preview, three-gear output, leftover hole, four-gear output and assisted output. The View test retains 30 node identities, one font and two shared style resources through 120 presentations and ten resets. Each native process retains those local identities and global 37 nodes and 30 resources across 120 presentations and ten retries. Active snapshot copies and temporary drawing geometry remain bounded.

| Shipped asset | Raw final 1280 capture | Frame state |
|---|---|---|
| `game-029-step-01.png` | `tutorial-01-heat.png` | Board A has one committed depth-.50 heat line. The attempted fold reports an uncut connection and leaves the material in place. |
| `game-029-step-02.png` | `tutorial-02-three-gear.png` | Three actual keyboard-cut wheels transmit to the output clockwise. |
| `game-029-step-03.png` | `tutorial-03-leftover-output.png` | An actual leftover idler from Board B forms the four-wheel path and reverses the output. |

The three assets are byte-identical 1280×720 copies from `D:/Snapland-chocolate-task2/20261118-123801-331982-native-1280x720-freeze/captures/`. The index records the raw source and SHA-256 for each shipped asset and all 33 final raw native screenshots. No cropping or image editing took place.

## Launch and retained chronology

The native logs identify Godot 4.7.2.stable.official.ed1daf0bf and Vulkan 1.4.359 Forward+ on AMD Radeon RX 9070 XT. The exact engine `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe` has SHA-256 `c8f0a6bc45a19b33541501e57f6f7cd972ab18453743266339d495cbbe846643`. The private runner uses `prepare_runtime_stage` with tracked runtime and each exact fixture closure, then `run_validated_godot`. SceneTree entries use `--script` and the native Node uses its real .tscn. Each process has fresh absolute D stage, save, capture, APPDATA, LOCALAPPDATA, TEMP and TMP. Every launch hashes and audits its staged script and scene graph. The four known legacy fault-child parent tests are absent.

The Paper asset donor is the fresh isolated D import `20261118-120046-246914-paper-import`. Only asset imports and their asset-side metadata are reused, with source asset and engine hash checks. Each final receipt contains the individual imported artifact hashes. No C cache, global-script/class cache, UID cache, existing package or player profile was used. The separate Godot UTF-8 file logs retain the diagnostic Chinese text. The launcher-decoded stdio files can contain replacement characters. All listed hashes describe the actual written files.

The literal missing-Driver and missing-View REDs executed before either production script existed. Each returned 1 with empty stderr and the expected missing-component marker at the exact `res://game/minigames/…` path. Earlier actual key probes supplied the two exact disjoint-segment cases and six input contours for the separately approved precision correction. Later held-key probes tested valid timing within the frozen caps. Those diagnostic files and receipts remain intact.

The rejected fixture parser and native early-exit runs have no acceptance credit. The earlier 800×600 candidate `20261118-123706-213174-native-800x600-verified` completed all routes but failed 11 hit-rectangle checks because the AI label exceeded the fixed control width at text scale 1.25. The final graph shortens the displayed button label and retains the AI-only clamp rule in the footer and hover. All earlier-source passes are superseded by the five final processes.

Exact commands, env paths, source differences, log hashes, raw image hashes and full result arrays are stored in `.review/chocolate-etching-20261118/presentation/evidence-index.json`, raw SHA-256 `d64e7ebef8609ea49909a5d0dc1304ce1061416113357ac2e8b87b79014e3047`. The index preserves all 32 process dispositions and receipt paths.

The standalone workbench leaves the first 140 design units for the Main HUD. Main/Session wiring, Main rule and lesson pages, reward granting, export and retake have separate acceptance. The fixture covers scripted input and native rendering. Human play, hearing, physical touch and cross-device behavior remain unverified.

## Fix round 1 — Canceled mouse gestures

DONE for the controller's exact fix commit and scoped rereview. FIX_BASE `322486c161825acb1b16a304bb08a8f479473b33`. The regression fixture was written first and executed against the original Driver from that base.

The old source committed a stroke after a canceled left release. The live preview had traveled 29.9999923706055 board units. Cancellation created one stroke and one undo entry and marked participation. A second real gesture dragged an already mounted gear from (200.000015258789, 220) toward (248.000015258789, 256). Canceling moved the mounted gear to (248.000030517578, 256) and increased undo entries from four to five. The new comparison on the held-Space keyboard A ordinary route also detected stale held commands in the terminal step return.

The Driver now checks the recognized pointer event's common cancellation flag before reaching ordinary release. The existing source check protects the active owner. Clearing the matching gesture discards pending drawing and drop state. The terminal step also clears held commands from its returned snapshot once ownership is released. [Godot InputEvent cancellation API](https://docs.godotengine.org/en/stable/classes/class_inputevent.html#class-inputevent-method-is-canceled)

The final cut test sees zero committed strokes, zero undo entries and no participation. The final drop test keeps the gear mounted at (200.000015258789, 220) and keeps four undo entries, the original committed strokes and participation. A delayed ordinary mouse release changes neither canceled gesture. Wrong-owner mouse and touch cancellations leave the other source's gesture live. The keyboard terminal step matches the settled snapshot.

| Run | Result | Fresh D suffix | Receipt raw SHA-256 | Godot UTF-8 log raw SHA-256 |
|---|---|---|---|---|
| `fix1-old-source-red` | 73 checks, 3 intended failures, all 24 full routes pass, exit 1 | `20261118-124623-602994-fix1-old-source-red` | `802f250ce301546a11d2135bc4d1f435f8a834cc557648621149b5ae3af5ae91` | `36b560d967827ddee2b5c8ec5af92365c8baf25512e52edee45b5f8b559d77e9` |
| `fix1-final-green` | 73 checks, 0 failures, all 24 full routes pass, exit 0 | `20261118-124700-620400-fix1-final-green` | `656ec942f3650a0239077bba803dfc8fcd960c6f2e8f1291458686a5ad302305` | `2925ac604637966e409aa15514416454ea76452d189d825bcd3b225da9c10398` |

```text
python .review/chocolate-etching-20261118/presentation/run.py fix1-old-source-red driver --import-from D:/Snapland-chocolate-task2/20261118-120046-246914-paper-import
python .review/chocolate-etching-20261118/presentation/run.py fix1-final-green driver --import-from D:/Snapland-chocolate-task2/20261118-120046-246914-paper-import
```

Both used the same regression fixture, exact validated Godot 4.7.2 and one isolated headless SceneTree launch each. Each prelaunch audit has 146 staged scripts and scenes and zero child-API candidates. The final stderr is empty. The final Godot log has no errors, warnings or leak markers. The 24 ordinary and idler result arrays match the original Driver proof exactly, including measured outlines, contact paths, positions, progress and scores.

| Changed file | Final raw SHA-256 |
|---|---|
| `game/minigames/chocolate_etching_driver.gd` | `410ed7532c42db2fde8f5617b459a772b03392efc43b93b9a944c27917292c9b` |
| `game/tests/test_chocolate_etching_driver.gd` | `692556827fc5792ec54e809fe9805a25b8bddec6723942ad50ebdf0979c108ab` |

No trailing whitespace or excess EOF blank lines. Raw and canonical LF hashes agree for the two changed files. The two final source hashes match their stage files and receipt. The other seven Task 2 files and the four frozen core files match their previous raw hashes. The View and three native sizes above are evidence from the earlier Driver source. The rendering and tutorial PNG sources retain their original provenance.

The original index remains byte-exact at `d64e7ebef8609ea49909a5d0dc1304ce1061416113357ac2e8b87b79014e3047`. The separate `.review/chocolate-etching-20261118/presentation/evidence-index-fix1.json` has raw SHA-256 `392753de68b2412bc33bf3198ae2cac8c8cb5f57ff940564c0609a2698931ab3` and records both full commands and environments, receipts, raw logs, stage hashes and result arrays.
