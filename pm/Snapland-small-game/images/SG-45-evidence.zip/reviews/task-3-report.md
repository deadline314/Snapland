# Task 3 — Factory entry, Session and fixed progress

Base `23e21b0ed211617571f70054faa6cd57ce98b802`. `game-029` now opens `chocolate_etching` as the fifth candy game. The catalog resolves `photo-candy-game-5`, `photo-candy-devil-5` and `ACH_GAME_029`. The factory has 5 of 12 game stations and the island has 29 delivered games across 128 design candidates. `game-030` is the first undelivered candidate. Production only adds the new station, registers the existing Driver and supplies the data, participation wording, lesson and retake prop row. Existing Progress, Steam inventory/economy, audio routing, player entry and export exclusions retain their existing implementations.

The new 3-step lesson uses the accepted raw Task 2 images. Its copy covers material loss and shallow retrace, actual mesh spacing, the inclusive fourth-wheel path, AI clamp and assisted tolerance, eight undo actions, and participation. The four earlier factory rows and all previous lesson rows precede the appended data verbatim. The 29th retake props use the existing sign, camera and lantern assets.

## Behavioral RED and regression chronology

1. The `red-baseline` batch ran before wiring with the shipping Task 1/2 sources. Its import completed cleanly. The original one-check test executed `Session.start("game-029")`, observed empty game ID and mode, absent Driver, `ended=true`, and one cancellation. It printed `Chocolate etching Session: 1 checks, 1 failures` and exited 1 with one intended `push_error`. The preserved `red-session.gd.txt` copy has SHA-256 `3effa9b766b7e4517ce124bc3984d584c7e51e596c54abdbde877769c1a05822`. Original fixture and raw receipt remain in the isolated run directory.
2. All 14 old affected fixtures in that batch passed. The separate `baseline-travel` process added the old travel map and collection UI check, for 15 passing baseline fixtures. Python design and runtime-result tests and the games/links scopes also passed before wiring.
3. `green-integration` was the first wired candidate. Session printed `55 checks, 0 failures` and completed eight natural routes. Main passed real entry, rules bounds, gameplay, rewards, and labelled synthetic PNG I/O. The extra tutorial diagnostic used `:=` against a dynamically typed catalog field, so the new paged test rejected the script on type inference. This test-fixture parser failure is recorded separately from the pre-wiring behavioral RED. No shared UI source change was made.
4. In `final-wired`, the invitation distinguishes AI clamping from assisted mode and the Session log records real angle, angular speed and travel at 0.75 seconds. Main records the actual rules rectangles. The import staged the earlier paged fixture while its error was being inspected, so the same parser error recurs in this batch's paged entry only. Its wrapper canceled queued jobs after reporting the error. Six fixture jobs completed cleanly and are promoted. `final-tutorial` stages the explicit `Array[String]` annotation in a new clean project and supplies the promoted paged result. `final-regressions` runs the ten queued fixtures that had yet to start.

## Route, entry and progress evidence

The Session fixture passes Godot event objects through `Session._unhandled_input` and advances through `Session._process`. It uses the existing public-event Driver fixture to choose guide and measured gear centers. Pointer A and touch-event B each cover ordinary and leftover-idler completion in both assisted and standard modes. Those cut inputs are dispatched immediately, so route duration is output rotation time. Session reports 400 for the three-wheel route and 500 for the four-wheel route, with `TAU` radians of measured outlet travel in each. Pause/blur tests observe real held key and pointer cut previews, moved mount previews, and already-turning wheels before interrupting. Late releases preserve the actual mounted position, undo count and completed travel. A clean retry uses the same Driver with variant B and no old material or travel. A real 30-unit open hot stroke qualifies on natural timeout. The idle, canceled preview, configurations, practice, and leave cases retain their distinct eligibility/results.

Main grants six synthetic welcome admission cards and marks the opening seen, then enters the normal factory travel flow. Controlled player placement is at `(10.5, GROUND_Y, -0.8)` followed by physics frames. The nearest interaction is really `game-029` and a real E event opens its invitation. The keyboard-focused map entry opens the same invitation with Enter. The factory terrain regression independently checks floor collision, point reachability, safe footing, nearest interaction, old entrances, and the visible 5／12 sign. Main visits the first lesson, marks it seen through the tutorial callback, and runs natural idle, real-cut timeout, three-wheel, assisted idler, practice and cancellation flows. The first ordinary receipt adds 40 coins once, later genuine devil adds its local-5 card and challenge proof, and `ACH_GAME_029`, attempt, tutorial and record survive memory reset and disk reload. Regional guide, book, ticket, and stamp tests detect the actual fifth entry.

The headless Main uses separately labelled synthetic PNG I/O for both actual selected retake routes after each set reaches its enabled shutter. The selected card alone is awarded with retake provenance, an original and thumbnail. A natural matching challenge, then disk reload, preserves original bytes, frame arrays and acquisition provenance. The proof flag is present only for the genuine devil challenge. Task 4 owns GPU capture, a second-process reader, package entry, current latest gameplay-photo refresh, and actual retake provenance acceptance. This stage records event replay and numeric checks without claims about human play, sound, physical touch hardware or walking to the station.

## Launch boundaries

The validated executable is `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe`, version `4.7.2.stable.official.ed1daf0bf`, SHA-256 `c8f0a6bc45a19b33541501e57f6f7cd972ab18453743266339d495cbbe846643`. Each version/import/test call through `tools.godot_entrypoints.run_validated_godot` uses its own fresh absolute D stage, save, capture, APPDATA, LOCALAPPDATA, TEMP and TMP. The launcher uses `--script` only for SceneTree entries and launches Main/Travel Book with their real `.tscn` files. Every launch audits all staged scripts/scenes plus the exact allowlisted test/helper closure for process launch APIs and excluded fixture references before execution. Every fixture listed in a receipt is transitive from the requested fixture entries. Runtime files come from `prepare_runtime_stage` with a tracked manifest filtered for UID/import sidecars. Each fresh exact-engine D import supplies only matching asset `.import` sidecars and addressed artifact bytes to its fresh test stages. The import donors have exact source hashes. No C caches, source import metadata, script/class/UID cache, player profile or legacy package participates.

`test_photo_retake_main`, `test_region_travel`, `test_photo_retake_progress`, and `test_region_progress` are excluded from every local launch and retained in the CI runner. Their fault-child behavior is checked by CI. Other legacy parents with process-spawning helpers were outside the selected integration fixtures. This report uses the separate child-free `test_travel_book_ui` and the new Chocolate Main for local persistence and regional UI assertions. It adjusts stale count assertions in the unchanged Jelly native flow and CI-only regional travel suite without locally executing those suites. Task 1 and Task 2 frozen executable test suites are registered with their accepted exact markers. Their accepted runs are reused as evidence without replaying them during this task.

## Commands and receipts

The following wrappers were run from the repository root. Files `*-index.json` sit in `.review/chocolate-etching-20261118/integration/`. Each indexed full receipt contains its actual launch timestamp, command, environment, return code, exact source/import hashes and SHA-256 of the written raw engine/stdio logs and prelaunch closure audit. The launcher decodes stdio to UTF-8 and the separately written Godot log keeps the engine's exact message text.

```text
python .review/chocolate-etching-20261118/integration/run.py red-baseline test_chocolate_etching_session.gd test_game_catalog.gd test_candy_world.gd test_participation_results.gd test_retake_panel.gd test_tutorial_panel.gd test_tutorial_paged_viewport.gd test_sugar_bridge_session.gd test_cookie_mold_session.gd test_syrup_flood_session.gd test_jelly_trampoline_session.gd test_sugar_bridge_main.tscn test_cookie_mold_main.tscn test_syrup_flood_main.tscn test_jelly_trampoline_main.tscn
python .review/chocolate-etching-20261118/integration/run.py baseline-travel test_travel_book_ui.tscn
python .review/chocolate-etching-20261118/integration/run.py green-integration test_chocolate_etching_session.gd test_chocolate_etching_main.tscn test_tutorial_paged_viewport.gd
python .review/chocolate-etching-20261118/integration/run.py final-wired test_chocolate_etching_session.gd test_chocolate_etching_main.tscn test_tutorial_paged_viewport.gd test_game_catalog.gd test_candy_world.gd test_participation_results.gd test_retake_panel.gd test_tutorial_panel.gd test_travel_book_ui.tscn test_sugar_bridge_session.gd test_cookie_mold_session.gd test_syrup_flood_session.gd test_jelly_trampoline_session.gd test_sugar_bridge_main.tscn test_cookie_mold_main.tscn test_syrup_flood_main.tscn test_jelly_trampoline_main.tscn
python .review/chocolate-etching-20261118/integration/run.py final-tutorial test_tutorial_paged_viewport.gd
python .review/chocolate-etching-20261118/integration/run.py final-regressions test_tutorial_panel.gd test_travel_book_ui.tscn test_sugar_bridge_session.gd test_cookie_mold_session.gd test_syrup_flood_session.gd test_jelly_trampoline_session.gd test_sugar_bridge_main.tscn test_cookie_mold_main.tscn test_syrup_flood_main.tscn test_jelly_trampoline_main.tscn
python -m unittest discover -s tests -p 'test_design_validation.py' -v
python -m unittest discover -s tests -p 'test_runtime*.py' -v
python -m unittest discover -s tests -p 'test_godot_entrypoints.py' -v
python tools/verify_design.py --scope games
python tools/verify_design.py --scope links
git diff --check
```

The runtime contract tests require the five Chocolate markers on exact full stdout lines, validate SceneTree vs scene launch arguments, and reject missing, quoted, suffixed, stderr-only or dirty completion. Shard behavior and the 240-second Pixel Shell/avatar timeouts are preserved. The design scope validates the current runtime rows against all 128 candidates and rejects a false implementation claim on 030.

The baseline and promoted Main runs retain the existing `OcclusionController` warning from `game/world/occlusion_controller.gd:178` when the scenery preserves an unsupported StandardMaterial3D or ShaderMaterial without cutaway. The tutorial panel catalog suite deliberately exercises the missing-image fallback, which logs one warning for `fixture-deliberately-missing.png`. Both warnings are retained in the raw diagnostics. The actual 800×600 rules panel fits `(18,40)` to `(782,560)`, with text, actions and containment checked on all five pages at 1.25 with reduced motion. `test_candy_world` reports 4,326 checks on three visits, covering the collision and nearby-point behavior at the new location. There was no reproducible shared layout defect in the selected pages.

## Local results

| Suite | Result | Warnings | Exact receipt SHA-256 |
|---|---|---:|---|
| `test_chocolate_etching_session` | Chocolate etching Session: 55 checks, 0 failures | 0 | `4666e57637c77eca921cb50ba67f6a7ea3a1338b7865f693aab4c906bfd4a2f6` |
| `test_game_catalog` | PASS: delivered game catalog, copies, regional identity and malformed data | 0 | `0fc6dacb2982735f29b31ee517474b69701e209ee4d46957c7b1e9dc30331d57` |
| `test_chocolate_etching_main` | PASS: chocolate Main factory entrance, three-wheel and leftover idler results, fixed rewards, selected PNG I/O and reload | 45 | `6f35865cbc94800a1545c9a402fa2c68405ea0c34db3c6517a6586ef424d299b` |
| `test_candy_world` | PASS: candy world connected terrain, temperature, safe reset, map and bounded reentry | 0 | `252c55b7eb6b5e8448bec2ac9e9e5be4cb5052627e9a378e9c7cedb1aeeb2f8a` |
| `test_participation_results` | PASS: every delivered participation result, practice, cancellation and driver eligibility | 0 | `985d92840e98e321c9fd9062d9c428eecc71d9d401a220405b795bdb460d526b` |
| `test_retake_panel` | PASS: retake panel canonical targets, reversible state, keyboard and capture guards | 0 | `13d897e322dd005146c29803e029fced47eb5e2d773d814da425bd764f1bd58e` |
| `test_tutorial_paged_viewport` | PASS: native-matching tutorial steps for every lesson, all five semantic fields in capacity-driven page groups, three sizes/1.25, visible copy clip/line height and blocked wheel | 0 | `44aa0d8471b5bf2ce3881f398adeff52aebb00994f27d49fd9f70d6c8c7bea85` |
| `test_sugar_bridge_session` | Sugar bridge Session: 21 checks, 0 failures | 0 | `3ab2f8449b3caf83928955c0553026941b0112f8f98a01fd1861535baa044bb6` |
| `test_travel_book_ui` | PASS: travel map, paged collection book, achievement stamps, and reduce-motion hook | 19 | `5319f0a4c82bb20a7ca07968c98dfb7e4f368dce15e5e12c13706d1957e2431a` |
| `test_cookie_mold_session` | Cookie mold Session: 21 checks, 0 failures | 0 | `f94c5918c1923feb5d1cf4dc664ee0b6188e4db626c281cd6206fa32a0cde20f` |
| `test_tutorial_panel` | PASS: tutorial panel/catalog checks | 1 | `eccabf2b6cb04affa40acbc8fc32615d3c343eab21edeb1846ac7957279c85d8` |
| `test_syrup_flood_session` | Syrup flood Session: 46 checks, 0 failures | 0 | `b0a01c76bc3c9842dd4cb50aee1b76226731c4624a266ae784b2968e2c3c760a` |
| `test_jelly_trampoline_session` | Jelly trampoline Session: 52 checks, 0 failures | 0 | `6e1144b2bc0141397e69e437eb042016ea999c8b42726898a7ae20437bf01de8` |
| `test_sugar_bridge_main` | PASS: sugar Main candy entry, tutorial, real results, fixed rewards, selected retake originals and reload | 30 | `47b86f5dfacd166712d1e3b71c8bc089a36894c83e155a3c8398e5c5c20f5ad6` |
| `test_cookie_mold_main` | PASS: cookie Main factory entry, six real catches, fixed rewards, selected retake originals and reload | 30 | `411835845aae2f9fc5a4b6d066bb9ac3ee9a66c28387ef1277314d1b444b8cad` |
| `test_syrup_flood_main` | PASS: syrup Main factory entry, three real filled closed tanks, fixed rewards, selected retake originals and reload | 45 | `4619dc90926109b3fabfe9b3f352da701d0c7bc07933c7baa15a38e3cd17b6ef` |
| `test_jelly_trampoline_main` | PASS: jelly Main factory entry, three real deliveries and same-fruit bell, fixed rewards, selected retake originals and reload | 45 | `ae654408718c46116e00139cd6875c066caf908acc99491e6028706cafd21e82` |

| History index | Actual launches | SHA-256 |
|---|---:|---|
| `red-baseline-index.json` | 17 | `0d7c67236025236ba7ef16f36722071a44028ba5a7ac8985ffdd191a1b7b97ba` |
| `baseline-travel-index.json` | 3 | `beb010f0d9fe0b293ca3464b0064864902d90354e91498a81d94545edbb084d3` |
| `green-integration-index.json` | 5 | `44a08de32a4682ddd1d1e36f4325ccfe52236252d03bae812facd23fb1b11535` |
| `final-wired-index.json` | 9 | `285bfa7f90be1a3116ea02be524b389f1c3858d09dce93245656cdc11fb34de0` |
| `final-tutorial-index.json` | 3 | `cf72ea75b71680fd3000842ec765b60451b067b7c4ff2814a9ccb5a9e40bd74f` |
| `final-regressions-index.json` | 12 | `682377257a418669450cceccf0bb33385503534dc99023dfc9ac18cd5474eedb` |

Evidence-index SHA-256 `2bf71265c3f9b547f67fbdc13d9472c5aa06b75e2979502fa2068ee11f52062a`.

### Tutorial bounds

| Viewport | All lessons | Visible semantic groups | Chocolate steps |
|---|---:|---:|---|
| `(800, 600)` at 1.25 | 30 | 449 | 5, 5, 5 |
| `(800, 450)` at 1.25 | 30 | 449 | 5, 5, 5 |
| `(1280, 720)` at 1.25 | 30 | 215 | 3, 2, 2 |
| `(1920, 1080)` at 1.25 | 30 | 102 | 2, 2, 2 |

### Local verification logs

| Command output | Result | SHA-256 |
|---|---|---|
| `final-design-python.log` | 47 checks | `794c95ad4f83fdccb8088d2ee636760a13d8547e3033d2f21419494d29fafd80` |
| `final-runtime-python.log` | 36 checks | `820b4c9c9e16d1775c750a54ccd79fd1ba8303e8f4fb4ace2455c3db7bbbc6a4` |
| `final-entrypoints-python.log` | 15 checks | `c59170bf1623c61d9629748e4b36f22550fa07a28918b3f0a0f9ef9b4894b747` |
| `final-design-games.log` | PASS games and runtime alignment | `98d80686bda08dd7591d93035b698a67c20158738e0b081dfd6c23839f32134d` |
| `final-design-links.log` | PASS links | `33ba8157d5b3f66735486df997ef07707cba2e689b506b25336880b6603b2b67` |

## Frozen owned-file SHA-256

| Path | Raw SHA-256 |
|---|---|
| `design/02-minigames/catalog.json` | `0d8330178fe58d113c3e5e02fae2c720622404fbb696af8e6a5cb6a576cb11cf` |
| `design/02-minigames/catalog.md` | `dfc1981d1be9a473e5a0b7b940c4e681f32bfb4f1148cee866ad2332893414a7` |
| `design/runtime/full-game-delivery.md` | `7678342fa53c43acd9b193c101e5759e8686603e97d3e2a826b7a6a56fcb6a33` |
| `game/core/game_catalog.gd` | `e91cc70be963e18c27c0805f118888c51b013a8b725c3bae1f5daa22d75a70f3` |
| `game/data/candy_games.json` | `2da740f5ee7d604bfa9e0e3e60edf2b582f192d42f36e16a109f445239987a15` |
| `game/data/tutorials.json` | `00f1a6d61c9443d59f8ddee915911d9ac7b567bc5fd96d42fff3962743e2e1b6` |
| `game/main.gd` | `73d8ad474871d9130ec7334e83ce676e53aef87deca035028e7ff0333268b40e` |
| `game/minigames/session.gd` | `a16a9aabbd62de132adb2a1205ce25c112302676f3bebd0dfb4722c50891f4a3` |
| `game/tests/native_jelly_trampoline_main.gd` | `c789cc75ce56b8f3b411a5162c275754bc9b4996505ba1121f7893d3f30f193f` |
| `game/tests/test_candy_world.gd` | `1ad8109a02d3f2d0ee8ef14e42f511caf6f035e7b41475854459567b3cfb3099` |
| `game/tests/test_chocolate_etching_main.gd` | `81e9fc74d04f4e961a8bde78fd64091def2532e5073c811bfe226e5a55d4b2da` |
| `game/tests/test_chocolate_etching_main.tscn` | `b336c2256de8f64deb995d4c8a53230d9600dcd82e8370c8a6f605115f05abc3` |
| `game/tests/test_chocolate_etching_session.gd` | `74302a494983015e933f37512e0a9b31ac79697e357e37ea9ca8556ef4ee3ef9` |
| `game/tests/test_cookie_mold_main.gd` | `e1a4787d4e21c924239fffed532bac88cd40903cb68e5f5a1eca40c43c9cae77` |
| `game/tests/test_cookie_mold_session.gd` | `e33d944fa522e3309bdf5663a3611f3da30a6c6e94b73c9bcd5dded174eac748` |
| `game/tests/test_game_catalog.gd` | `0cb2336f569f54310415ab94ea2a993ad9d9d07f084664c9ad0246bb33d54552` |
| `game/tests/test_jelly_trampoline_main.gd` | `71fde2b1c301ca1f8e26faec64b8434da89b2831719d162619612e8e8862ebeb` |
| `game/tests/test_participation_results.gd` | `a1de6fffa50c018a1149ef8eb3a00c61d1d4657d5e0a9e11f928b22ec5cbdcfc` |
| `game/tests/test_region_travel.gd` | `96bfd30976a2c5c3544d4d073d39479316480b53a9dc45215c0dbc13ee98cd4f` |
| `game/tests/test_retake_panel.gd` | `3467deb03c635a09d4b1abc73bf2f15b6daac56bb23bff67b4ed887c39bc7c83` |
| `game/tests/test_sugar_bridge_main.gd` | `4c72a1b5c7ca8c2a5742132330b12c7d9c41e1f436048c7f3507684fefaf241a` |
| `game/tests/test_sugar_bridge_session.gd` | `7e961af213fc07e31563572c02286fa28a05985c2e444f4bf9f914d518115996` |
| `game/tests/test_syrup_flood_main.gd` | `cc43b85e64b19fb628b0074c9c937f86df99a4fc21f0fe9ed3444308cafb2d48` |
| `game/tests/test_tutorial_paged_viewport.gd` | `b87ba64d2d14b2c4f6d759c4cdc33b8067e01aae3d4ce877b8320adf683179dc` |
| `game/ui/collection_book_panel.gd` | `58141f859cec75065c113d9fc8e62fb83c34eeefda1cfb4efea29bda6dabbac5` |
| `game/ui/retake_panel.gd` | `dce6cc21e68c0d6861ca3ecb348a1fc6a0065fbd530c05e2d412043fb0535fa9` |
| `game/ui/tutorial_catalog.gd` | `6100308d0e2fc0186b902fad4c912696ab687072de07fd59b16625e680cb7543` |
| `game/world/candy_world.gd` | `de07c3044930ad14487675c4a62e89d897108d0d31a7e65440ad2d152a8dd964` |
| `tests/test_design_validation.py` | `affe74d0b35c499c3397a42a1e8abaaabd3bb6e66e7487a6b2c11ffbd4a74884` |
| `tests/test_runtime_result_contract.py` | `82357a25d0da117d58abecac40ea4a47fdd271d41dea0e7f24d22f62e3f74508` |
| `tools/run_game_tests.py` | `1f59593ab63048317e60aab7ef635e38642a1cea4d60eedc422d737c167c63cc` |
| `tools/verify_design.py` | `e48672c76088360524f58d599920af7009d8f80fbc144b95ebb194686095a008` |

This report and the private integration receipts are controller handoff artifacts.

## Fix 1 — Collectible wording and Main fixture assertions

Fix base `451c39318a4f0c76f6fafc188a1936bf14ece1a9`. Both design catalogs had required a complete revolution for ordinary collection. They now match the existing runtime and tutorial. In formal play, an actual hot cut at least eight units long into remaining material qualifies on natural settlement, including timeout. The devil challenge requires a fourth wheel cut from leftover material to lie with all three main wheels in the input-to-output path and drive the output a full revolution.

The previous Main fixture accepted only `modal_kind == "game_info"` after E and after the focused map action, then supplied `game-029` directly to navigate onward. It now requires the exact visible `InviteTitle` to be `巧克力蝕刻` after each action. E continues through the invitation's visible rules button and the focused map action continues through its visible start button to the `game-029` tutorial. A different title, hidden title, or missing title makes the assertion false even when the modal kind matches. Each retake case records a failed check if the capture panel is absent, then guards the remaining access to that panel. The failure list prevents the suite from printing the completion marker in either case. These are fixture evaluation changes and static failing-branch checks. The focused engine run exercises the real successful paths.

The Python regression groups the five Chocolate suites in their own mapping and retains all cases in the existing driver suite union. The focused result-contract file passed 23 tests. Games, runtime catalog alignment, links and whitespace checks passed. The Main success marker includes the five rule pages, natural results, fixed rewards and both selected synthetic PNG I/O routes. GPU capture and package acceptance remain Task 4. The previous 17 fixture results, the broader Python results and Task 1/2 acceptance sources were reused. All 49 original receipts and their raw artifacts were hash-checked against the unchanged Task 3 index.

```text
python .review/chocolate-etching-20261118/integration/run.py fix1-main test_chocolate_etching_main.tscn
python tools/verify_design.py --scope games
python tools/verify_design.py --scope links
python -m unittest discover -s tests -p 'test_runtime_result_contract.py' -v
git diff --check
```

The new launch index and its full receipts retain the exact command and environment, fixture closure, imported asset identity and raw log SHA-256 for each isolated version, import and real Main scene run. The original index and all earlier launch records are preserved with their original source identity.

| Owned file | Raw SHA-256 |
|---|---|
| `design/02-minigames/catalog.json` | `c17984876277328cfd43864fd93b97c1b04914e4ac8c7d7578048ce20a9e5c01` |
| `design/02-minigames/catalog.md` | `5e86f7b6b5157b2f04a55e73d13f3733d61bfa753360cfb5942a46e6d6fdf388` |
| `game/tests/test_chocolate_etching_main.gd` | `4237b17f6c90bde4b4dc3b735a49812a33fe6b7ddc859ffdd73b6ffed1764f41` |
| `tests/test_runtime_result_contract.py` | `300a1cb05a45fc24ba2023493dfeab8270353960b784eb49e78b705dd172a1a8` |

| Evidence file | Raw SHA-256 |
|---|---|
| `fix1-main-index.json` | `fef4bcf656ec36aa03ff0c9c1bc52ab6a4efd911da2b4869517fd01f18a0fd9f` |
| `fix1-evidence-index.json` | `d82280cf56a98a6e713312c87c65062713782cb1d72fc46c30c1b83095fd4c09` |
| `fix1-design-games.log` | `98d80686bda08dd7591d93035b698a67c20158738e0b081dfd6c23839f32134d` |
| `fix1-design-links.log` | `33ba8157d5b3f66735486df997ef07707cba2e689b506b25336880b6603b2b67` |
| `fix1-runtime-contract.log` | `bebbe1403cdec7003bd0c98a0458b0095894bbfdbdd7ada1fac22fc6f3a933ed` |

| Validated launch | Exit / errors / warnings | Raw receipt SHA-256 |
|---|---:|---|
| `version` | 0 / 0 / 0 | `e05918d7c3380f76180d6236fe23075eb3a75f46445905a13ced1a345d51f9ed` |
| `import` | 0 / 0 / 0 | `69200dd449eb6b7585515ec3eebc5fc074e2cb5a4081b0fe55fd18b6f529ee48` |
| `test_chocolate_etching_main` | 0 / 0 / 45 | `9e375158bfaa1f784487d388c0bbddec250c617fd49aa96f957a0a0bf5c7bd63` |

The existing `OcclusionController` warnings preserve scenery materials without cutaway in 12 StandardMaterial3D cases and 33 ShaderMaterial cases.
