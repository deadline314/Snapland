# Task 1 — bounded chocolate material and transmission model

Producer status: DONE, frozen for controller commit and independent review. No Git mutation, PM edit, Driver/View/integration edit, player-profile access, or coefficient change was performed by this producer. Review BASE is `bf90ce6a94d2437f10b2fc39968fc3f343e9e7bd`.

## Frozen sources

| Source | Lines | SHA256 of actual source bytes |
|---|---:|---|
| `game/minigames/chocolate_etching_geometry.gd` | 150 | `5d1ca20fe4a8505c8d8ab8dc8011069d706661426d7aae05e0d0e8cbb03d07f5` |
| `game/minigames/chocolate_etching_model.gd` | 440 | `5b906d3df8d974c254a64059a397ba3b4152e567e845b696d3a4a3e589684e03` |
| `game/tests/test_chocolate_etching.gd` | 501 | `215f92b0e8f3ab182e01a1ed545b71a97e31d6599623314be6533135cff71ba5` |

Source files use LF; canonical-LF SHA256 equals raw SHA256. Git blob IDs are separately recorded in `.review/chocolate-etching-20261118/model/evidence-index.json`. Source hygiene checked: no trailing whitespace, no extra blank line at EOF, no OS child-process API references. The final stage's owned-source manifest matches all three current raw hashes exactly. No source edits followed the final successful engine run.

## Actual verification and boundaries

Final engine run: `D:/Snapland-chocolate-task1/20261118-112937-660545-sampling-self-review`.

Exact marker: **Chocolate etching tests: 97 checks, 0 failures**. Validated engine exit 0; stderr file empty. This is deterministic headless Model verification, not native play, rendering, touch hardware, sound, or full game integration acceptance.

The tests cover:

- Eight public-input routes, A/B × normal/assisted × ordinary/actual leftover idler, with exact clean 400/500 scores. An additional reversed-contour four-wheel route also earns 500.
- Single shallow pass fails, real retrace succeeds; partial deep retrace cannot hide uncut perimeter points; normal/assisted undo restores actual material without rewinding time/participation; bounded retry history is not a retry-count limit.
- Both variants' one-pass depth-1 main wheels succeed but spend enough real material to prevent the fourth wheel. Fourth extraction before the first three fails. Removed board material cannot become a replacement blank.
- Actual crossing cut, self-intersection, open contour, one flattened tooth, round blank, thin shaft web, vanished offset and multiple inner-offset fragments are rejected. Third-party strokes are checked against the fourth wheel's complete material footprint, not just its final outline.
- Helper only creates a legitimate uncut-corner clamp. Cut corners invalidate it; all four unavailable corners produce no benefit. Depth .75 proves the normal/assisted/helper fold thresholds are enforced using actual clamp availability.
- Detached and dangling fourth wheels do not earn devil; a genuinely inserted fourth wheel reverses output direction. Variant B actual output speed is -1.75 rad/s and .25 seconds integrates .4375 radians. The same angular state satisfies the contact tooth-phase equations.
- Closed odd cycle, overlapping centers, separation, incompatible actual measured module, invalid shaft position and invalid placement cannot transmit. Jamming costs once per held attempt, then once again only after release/retry.
- Release/clear_input retains output travel; material/placement/unmount/undo structural changes reset it. Natural timeout with a real incomplete cut is eligible; empty driving is not. Practice/cancel reward exclusion belongs to Session and is not implemented as a duplicate Model reward policy.
- Contact distance brackets at tolerance ±.02: inside yields .5 radians in .25 seconds; outside yields zero for both tolerance 3 and assisted tolerance 6. Deadline bracket: start .02 seconds early wins at elapsed239.98 with TAU travel; .02 late ends at240 with6.243185307 radians and no success.
- Nonfinite input, invalid/huge deltas, huge finite direction, outside stroke, cancelled preview, zero-motion hold, 512-point overflow, 8-stroke limit, snapshot mutation isolation, last-eight undo horizon and100 draw/undo retries are exercised. Short straight keyboard samples are coalesced while preserving the actual corner and final endpoint.

## Public recipes and measured placements

All successful recipes use only the frozen public operations. No part, result, geometry, angle, position, score or source state is injected.

Common cut recipe: `reset(assisted, variant)`, keep default depth .5 and helper off, select piece0 with `cycle_piece` as needed. Read `selected_guides[0]`; `move_cursor_to(first)`, `begin_tool`, move through every actual guide vertex, return to first, `release_tool`. Repeat the same physical trace once, then `fold_or_mount`. Repeat for pieces1 and2, and for piece3 only for the idler challenge. Guideline coordinates are actual offset contours, not an integer completion tag. Each copied point goes through the public cursor, sampling, stroke, coverage, kerf, source and profile rules. The reversed route reverses each guide's point sequence before tracing.

Then `toggle_phase`; select and `place_selected` each intended center. Input and output stay on their actual shaft coordinates. Ordinary middle x is `(input.x + output.x + r0 - r2)/2`, y220. For the idler, middle is `input + Vector2.from_angle(-PI/6)*(r0+r1)`. The idler is the upper intersection of the circle around the middle of radius `r1+r3` and the circle around the output of radius `r2+r3`. These formulas consume measurements from the extracted parts, not nominal reference centers. Finally `begin_tool` and bounded `.25` steps until ended; `solve` is capped to30 iterations.

| Variant | Assisted | Route | Wheel1 center | Wheel3 center (idler) | Output | Score | Actual drive time |
|---|---|---|---|---|---|---:|---:|
| A | false | ordinary | (320.0,220.0) | not cut/mounted | (440,220) | 400 | 3.141592654 |
| A | true | ordinary | (320.0,220.0) | not cut/mounted | (440,220) | 400 | 3.141592654 |
| A | false | idler | (305.6311,159.0139) | (410.3098,143.9963) | (440,220) | 500 | 3.141592654 |
| A | true | idler | (305.6311,159.0139) | (410.3098,143.9963) | (440,220) | 500 | 3.141592654 |
| B | false | ordinary | (303.9753,220.0) | not cut/mounted | (416,220) | 400 | 3.590391604 |
| B | true | ordinary | (303.9753,220.0) | not cut/mounted | (416,220) | 400 | 3.590391604 |
| B | false | idler | (291.6982,167.0580) | (370.6255,124.3756) | (416,220) | 500 | 3.590391604 |
| B | true | idler | (291.6982,167.0580) | (370.6255,124.3756) | (416,220) | 500 | 3.590391604 |

Wheel0 center is always(200,220). Table centers are displayed rounded; the executable public recipe recomputes them from actual radius values. Actual final measured radii:

- A: `[48.909425268084,73.0628498391709,48.9094229729235,32.6876149916182]`.
- B: `[56.9745294776711,48.9094245637943,65.0239805499431,40.81967641085]`.

Each modulus is `2*radius/teeth`; no nominal radius is substituted. Outline measurements include the real offset geometry and ray intersections, so these radii differ from nominal `4*z`. No coefficient adjustment was necessary. The instantaneous public trace recipe consumes no simulated time between cursor calls; the recorded elapsed figures describe the actual simulated drive interval, not human crafting time.

## Frozen behavior for subsequent consumers

`phase` is `craft` or `assembly`; `helper_clamp` is a Vector2 or null; `pins` contains input and output centers. Connections are deterministic ascending Vector2i index pairs. Outline/removed_outline/guide/stroke vertices are absolute source-board coordinates. To present a mounted outline, rotate `(vertex-source_center)` by the part's angle, then add position. Angle is radians and wraps to[-PI,PI). Unfreed outlines stay empty. Stroke dictionaries expose `points`, `depth`, `width`; only the selected piece's strokes enter each snapshot.

The geometry helper is domain-local: simple-polygon validation, actual miter offsets, bounded ray/profile measurement,128-point minimum local depth, segment/kerf intrusion, polygon overlap and bounds. Empty or non-single offset results are rejected. All final contours must be simple, within the original board, contain the source center, and satisfy each actual tooth/root/shaft-web measurement. This remains simplified external-gear kinematics, not industrial gear CAD or a rigid-body simulator.

State bounds: four parts, up to512 points per stroke, eight strokes per piece, eight structural undo snapshots, two guides,128 coverage samples, at most four graph nodes/six edges and at most30 substeps per public step. Mistakes saturate at1,000,000,000 and score floors at zero; time caps at240. Retrying after undo is unrestricted, while state/history/time remain bounded. Snapshot excludes undo history and unselected stroke arrays and duplicates exposed mutable containers. No new dependency or framework was introduced.

## Genuine RED chronology and rejected history

1. Read task brief, authority, applicable AGENTS/pm-ticket, house Jelly model/tests and validated launch/stage helpers. Root owns ticket/Git actions.
2. Wrote the exact SceneTree test filename with meaningful missing-model/missing-geometry assertions. Both product files were absent.
3. Executed `pristine-red` in fresh D staging before writing either product file. Godot4.7.2 executed the fixture and printed `Chocolate etching tests: 2 checks, 2 failures`, exit1. Both errors were the intended missing real Model/geometry assertions; no parser/import/path failure. Preserved directory `D:/Snapland-chocolate-task1/20261118-074457-442713-pristine-red`.
4. Implemented owned geometry/Model and public recipes. The next two runs had local GDScript type-inference parse errors (`needed`, then geometry `angle`) and are retained as rejected parser failures, never called RED or acceptance.
5. `20261118-074742-757427-measured-routes-2` passed18 checks/eight routes. It is superseded, not final evidence for the later expanded fixture.
6. The first `edge-contracts` attempt was interrupted during stage copy by the environment/tool update, exit1073807364. It has only a partial stage and no receipt/profile/engine logs; no engine launch or result is claimed.
7. Resumed same task, not a second producer. Expanded fixture first needed explicit bool type for `main_freed`. Next run produced80 checks/4 failures: exact float equality in two undo assertions, a test line that did not actually touch the helper clamp, and an invalid test contour rather than the intended valid incompatible module. Fixed these fixtures: approximate elapsed comparison, an actual line starting at the clamp, and a valid free-drawn root42/top60 profile. No Model thresholds or authority coefficients were weakened. The next run passed80/80.
8. Added contact/clamp/undo-horizon/phase edge checks; one fixture-only `half_span` inference parse error was fixed. Next run passed95/95.
9. Self-review found that sampling every one-unit keyboard substep could needlessly consume the point budget. Added exact straight-short-sample coalescing with turn/endpoint regression. Final run passed97/97 and all route/edge checks. No further product or fixture changes followed.

Full11-run classification, original per-run manifests, commands, environments, exit codes and raw-file hashes are in the evidence index. Rejected logs/stages were preserved and not rewritten to match final sources.

## Commands, isolation and evidence

Runner: `.review/chocolate-etching-20261118/model/run.py`; final invocation:

```text
python .review/chocolate-etching-20261118/model/run.py sampling-self-review
```

The runner calls `tools.build_desktop_release.prepare_runtime_stage` with tracked runtime files, excludes UID/import metadata, and copies only the three owned files as explicit fixtures/helpers. All other game/tests are excluded. No old package, C cache, broad test tree or untracked UID/import closure was copied.

Before each launch, every staged GDScript was scanned for OS execution/create-process/shell APIs; no hits. The test fixture and direct geometry/Model closure contain no OS references. Known four fault-child parents are absent from every test-stage closure. There was no editor import or child Godot launch in this task.

Every actual engine command is structurally validated through `tools.godot_entrypoints.run_validated_godot`:

```text
C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe --headless --path D:/Snapland-chocolate-task1/<fresh-run>/stage --script res://game/tests/test_chocolate_etching.gd
```

The engine's actual banner is4.7.2.stable.official.ed1daf0bf. Each process has a unique absolute D root, stage, save path, APPDATA, LOCALAPPDATA, TEMP and TMP. Final environment paths all start `D:/Snapland-chocolate-task1/20261118-112937-660545-sampling-self-review/`; save is `save/progress.json`. Complete literal command/env/manifest live in `receipt.json`; raw-byte receipt SHA256 is `e30c5f26ed9dc24c9534a3ebb904cf6d7cfb45381084ab2813c2895ec075b461`.

The index hashes preserved log/receipt file bytes after writing, including Windows newline conversion. These are the validated launcher's decoded stdout/stderr text, not a claim of original pipe-byte capture. Chinese feedback prints may contain console decoding replacement characters; ASCII test markers and numerical route measurements are intact. Source, log and Git blob hashes are distinguished explicitly. No unrelated PID was killed and no destructive cleanup was run.

Skipped/outside scope: Driver/View/Session/Main/native/GPU/export QA and full-suite CI; controller owns the subsequent tasks, commit and fresh review. Risk/limit: these deterministic tests establish bounded geometry and kinematics, not human ease of tracing, physical tooth collision, rendering quality or hardware performance.

## Formal fix round 1 — seven Important findings

FIX_BASE `a1c9365`; producer status DONE, frozen for controller commit and the same reviewer's scoped review. The initial report above is retained as historical evidence, not a claim that the rejected initial implementation satisfied these seven contracts. The original97-check manifest/logs/stage remain unchanged. The pre-fix evidence index is preserved byte-for-byte as `.review/chocolate-etching-20261118/model/evidence-index-before-fix1.json`; the current index identifies the new final candidate and every superseded run.

Read the exact seven findings in `task-1-fix-1-findings.md`, the full `task-1-review.md`, and the controller's authority rulings before source edits. Inspected the Model's callers of motion, cancellation, begin/release, phase changes and undo. No coefficient changes, Git mutation, PM edit, other product code, subagent or Task2 work was performed.

### Regression-first chronology

Added focused regressions to the existing covering fixture while both product source hashes still matched the rejected initial freeze. First launch had one fixture-only type-inference parse failure (`normal`) and is explicitly rejected as non-behavioral evidence. After correcting that fixture declaration, executed:

```text
python .review/chocolate-etching-20261118/model/run.py fix1-old-source-behavioral-red
```

Preserved genuine old-source RED: `D:/Snapland-chocolate-task1/20261118-114141-353903-fix1-old-source-behavioral-red`, exit1, **Chocolate etching tests: 126 checks, 22 failures**. Every Important defect was reproduced: assisted public twelve-gon, one inadequate tooth, both snap-escape directions, cancelled held motion, short kerf state/extraction/undo/travel, near-threshold area in both windings, typed empty/nonempty contacts and actually extracted asymmetric rotation envelope. The original97 checks and eight public winning routes continued to pass in that RED. No missing-model RED was replayed and no source was rewound.

Applied the minimum shared fixes once. The same126-check fixture then passed with exit0 and empty stderr in `20261118-114232-684533-fix1-green-candidate`. Self-review tightened the scratch rule to preserve every represented nonzero segment and included the actual added closing segment in participation length; seven additional assertions exercise these boundaries and motion-anchor lifecycle. The final run:

```text
python .review/chocolate-etching-20261118/model/run.py fix1-final-self-review
```

Final preserved directory: `D:/Snapland-chocolate-task1/20261118-114305-911550-fix1-final-self-review`. Exact marker: **Chocolate etching tests: 133 checks, 0 failures**; validated Godot exit0; empty stderr. All eight ordinary/idler A/B normal/assisted recipes, measured radii, placements, drive times and clean400/500 scores in the earlier table remain unchanged. The reversed idler route also remains passing. No product or fixture changes followed this final run.

### Changes and coverage by finding

1. Retained all root/tip radius bands and added the controller's actual-tooth prominence rule: each of the three tip rays must exceed the larger neighboring root radius by at least4. The constructed assisted twelve-gon traces actual guide-flank points through public inputs, is genuinely extracted by the old code, and is now rejected; a single low-prominence tooth also fails.
2. Relative movement now integrates an unsnapped, bounded cursor anchor before deriving the assisted projection. Absolute cursor moves rebase it. Both normal directions escape a guide after sustained public movement. Selection/phase/undo cancellation synchronizes the anchor, and no hidden displacement survives those transitions.
3. Public `cancel_tool` clears held movement and rebases the anchor; `clear_input` shares it. Valid held-motion `begin_tool` and `release_tool` do not call cancellation, so drawing/release retains legitimate movement. A public test first creates snap offset, then makes an absolute move and draws/releases while moving.
4. Every represented nonzero scratch on remaining material is committed, undoable and resets structural travel. Only a committed length of at least8 on actual remaining material grants participation. The domain helper splits each segment at removed-outline intersections, sums only intervals whose midpoint remains in board material, and uses the same fixed stroke/part/outline bounds. Tests cover a five-unit interior scratch preventing extraction, undo restoring it, short-only timeout ineligibility, tiny represented scratch retention, added closure length and length crossing a removed region.
5. Area uses an origin at the polygon's first vertex and scalar double products. Board-coordinate squares of sides .008/.012/.02 exercise represented areas below/above1e-4 and both windings. This fixes the shared area operation used by source overlap; no overlap epsilon was relaxed.
6. Both reset and graph rebuild allocate `Array[Vector2i]`. Snapshot duplication preserves that element type; regressions assert empty and mounted metadata plus deterministic pair ordering.
7. Placement checks the actual maximum source-relative outline radius against all four canvas sides. This is the controller-authorized conservative full-rotation envelope even for a disconnected gear. The regression actually cuts an asymmetric gear with a90-unit unsampled protrusion: its angle-zero contour fits near the top, but its full-turn envelope is rejected there and accepted at a safe center.

### Updated freeze and evidence

| Source | Lines | SHA256 of raw current source bytes |
|---|---:|---|
| `game/minigames/chocolate_etching_geometry.gd` | 179 | `ede58b4deda77b1a54eb0966fa8c7f42345bc9e2a37c02a3f0224bc7ae8578fa` |
| `game/minigames/chocolate_etching_model.gd` | 450 | `0395eb3f16fbe6906660baa36ced7c0d0acb2fe42e1f9b43505c4a03e2de28bf` |
| `game/tests/test_chocolate_etching.gd` | 622 | `b31671b9d0df047163eb9c6b165b65a375146e7be0355e646f6d8c6cf8f881c6` |

All three raw hashes match the final launch manifest. LF-canonical hashes remain equal to raw-source hashes; Git blob SHA1 is separately recorded. Self-review hygiene passed before freeze: no trailing whitespace or excess EOF blank line. Final receipt raw-byte SHA256: `b64a0e02c6be1b71644e90bf5c35782a8153d8e03a011e5725eaf8357e8baddf`.

All four fix-round launches used the unchanged audited runner and exact validated Godot4.7.2 SceneTree entrypoint, each with fresh absolute D stage/save/APPDATA/LOCALAPPDATA/TEMP/TMP and no known fault-child parents or OS execution API in the staged closure. Full commands, environments, manifests, exit codes and hashes are appended to the evidence index. Hashes are over written file bytes, not an in-memory stdout string. The previously documented decoded-console Unicode caveat remains; numeric/ASCII markers and measurements are intact.

The two review Minor coverage gaps remain honestly ledger-deferred: independent isolated shaft validation and an independently constructed other-piece kerf touching only the fourth footprint margin. No separate runs or source scope were added for them. Full native/Driver/View/Session/GPU/export/hardware work is still outside this Model fix round. Conservative rotation-envelope placement intentionally reserves all-turn space; it is not a per-frame rigid-body boundary solver.

## Formal fix round 2 — exact retained closure endpoint

FIX_BASE `301bcf9`; producer DONE, frozen for the controller's exact commit and same-reviewer scoped R4 check. Read `task-1-fix-2-findings.md` and `task-1-rereview-1.md` verbatim. The six addressed findings were not reopened; this round corrects only R4's represented near-start endpoint. No calibration, authority, geometry helper, Git, PM, Driver or Task2 change.

Added the public A=(100,100), B=(103.99999,100), C=(100,100.00005) regression before modifying the current Model. It checks the stored A→B→C→A sequence, represented physical length8.000038146972656, participation and natural-timeout ordinary eligibility. Two capacity fixtures retain511 and512 actual reversing samples before release; the former must append its closing point into slot512, while the latter must refuse explicitly without replacing C or increasing the cap.

Executed exactly two engine runs, using the unchanged validated/audited launcher and fresh absolute D stages/profiles:

```text
python .review/chocolate-etching-20261118/model/run.py fix2-old-source-red
python .review/chocolate-etching-20261118/model/run.py fix2-final-green
```

Genuine current-old-source RED: `D:/Snapland-chocolate-task1/20261118-114942-579935-fix2-old-source-red`, exit1, **Chocolate etching tests: 141 checks, 6 failures**. Failures are exactly endpoint sequence, resulting material length, participation, timeout eligibility and the two closure-capacity expectations. The original133 assertions and eight successful routes remained passing. No missing-model replay, parse failure, source rewind or unrelated suite occurred in this round.

The Model now preserves the final sample exactly. When endpoint and start differ and qualify for closure, it appends the actual start only when a slot remains; otherwise the existing explicit capacity feedback rejects the uncommitted preview. Exact endpoint equality needs no extra point. Material length is calculated once on this final retained physical polyline, naturally removing the newly noted duplicate-work Minor without introducing another gate or run.

Final GREEN: `D:/Snapland-chocolate-task1/20261118-114955-031194-fix2-final-green`, exact **Chocolate etching tests: 141 checks, 0 failures**, validated Godot exit0, empty stderr. All133 previous assertions, the eight original measured public recipes with clean400/500 scores, reversed idler route, contact/deadline brackets and new exact-capacity checks pass. Recipe coordinates, actual radii, speed integrals and public interfaces are unchanged.

| Source | Lines | Final raw source SHA256 |
|---|---:|---|
| `game/minigames/chocolate_etching_geometry.gd` (unchanged) | 179 | `ede58b4deda77b1a54eb0966fa8c7f42345bc9e2a37c02a3f0224bc7ae8578fa` |
| `game/minigames/chocolate_etching_model.gd` | 447 | `abb2c78ddda00dd9a424e89d7a2d2fb9e600c9277f5bcecf2839566748c76bab` |
| `game/tests/test_chocolate_etching.gd` | 653 | `1d549db02e8306d8a05104bd98b0e8b367a51ec97b4aa9762f4c7d1599053fc6` |

Hygiene before freeze: no trailing whitespace or excess EOF blank line; all three current raw hashes equal the final stage manifest. No source/fixture edits or engine launches followed final GREEN. Final receipt raw-file SHA256 is `a67b71b9b4085f95fc8436a35cf5d96a5e7abe642be4c59dd4cb7eaee7e91202`.

The prior133 evidence index is preserved byte-exact as `.review/chocolate-etching-20261118/model/evidence-index-before-fix2.json`; prior manifests, logs and stages remain untouched. Current `evidence-index.json` appends both runs and their exact commands, environment, stage manifests, exit codes and written-file hashes. Source LF and raw hashes match; Git blob IDs remain separately labeled. The decoded-pipe Unicode caveat remains unchanged; no original pipe-byte capture is claimed.

The original two Minor coverage gaps remain ledger-deferred. No native, Driver/View, Session, GPU, export, full-suite or human-play claim follows from this bounded Model correction.

## Core follow-up round 3 — captured assisted geometry precision

Core follow-up BASE `74b942128ae88818a11cb707b51106afc59523eb`. Producer DONE/frozen for the controller's exact commit and the same core reviewer's scoped review. The earlier seven findings remain closed. This follow-up changes the geometry helper, covering fixture and the explicitly authorized replay JSON only; the Model and all six frozen presentation files are byte-identical to their handoff versions. No Git, PM, presentation, UI, engine-global or coefficient edit was made.

Read the consumer's exact minimal pairs, public replay and B raw-offset report in `.review/chocolate-etching-20261118/presentation/core-handoff.json`; verified raw SHA256 `53a26859cf94b846f3c90910015e82355c7ea54d9283894479581689f9b98085`. The six actual captured point arrays come from `D:/Snapland-chocolate-task2/20261118-121357-690304-assisted-geometry-decisive/captures/keyboard-{A,B}-assist-stroke-{1,2,3}.json`. Each array is preserved exactly, in original order and with all original values, in `game/tests/chocolate_assisted_keyboard_replay.json`; source capture hashes accompany the arrays. The original held-key schedules remain at the named consumer capture directory and are not rewritten. Root authorized this input-data fixture before dispatch (`f517e4c`); the test reads its literal `res://game/tests/chocolate_assisted_keyboard_replay.json` path.

### Regression-first evidence and residual ruling

Five fresh-D engine runs occurred in this core follow-up:

| Label | Directory suffix | Result and disposition |
|---|---|---|
| `core3-old-source-red` | `20261118-122008-492750-core3-old-source-red` | Genuine current-old-source RED:204 checks/35 failures, exit1. Original141 and all eight routes pass. |
| `core3-shared-intersection-green` | `20261118-122029-968347-core3-shared-intersection-green` | Despite its requested label, this is a **rejected candidate**,204 checks/24 failures, exit1. Segment/candidate failures fixed; generated offset representation still fails. |
| `core3-offset-residual-diagnostic` | `20261118-122048-162283-core3-offset-residual-diagnostic` |204 checks/24 failures, exit1. Concrete exact-duplicate and one-ULP generated-edge diagnostics; preserved, not acceptance evidence. |
| `core3-generated-contour-green` | `20261118-122339-854251-core3-generated-contour-green` |209 checks/0 failures, exit0 after controller ruling. Superseded by additional focused public input replay. |
| `core3-public-replay-final` | `20261118-122415-906430-core3-public-replay-final` |**Chocolate etching tests: 211 checks, 0 failures**, exit0, empty stderr; final candidate. |

Each command was `python .review/chocolate-etching-20261118/model/run.py <label>` and every directory is under `D:/Snapland-chocolate-task1/`. No missing-model replay, source rewind or parser failure occurred. The existing fixture first reproduced both exact disjoint-segment cases in both argument/endpoint orders, A's falsely non-simple captured contours, and all12 rejected singleton raw offsets before production edits.

The shared double-precision intersection fix made all six captured input contours valid, but did not fix generated output spacing. Before extending the implementation, reported the exact remaining cases to the controller: A inward edges0/2 are separated by one generated edge of length0.000015258789; B inward edges1/3 meet because generated edge2 repeats `(166.388198852539,128.992965698242)` exactly; B outward also has a one-ULP edge. These were not newly discovered input crossings. Controller ruling `9360b56` explicitly authorized generated-output-only exact duplicate removal and true-topology validation while preserving all positive short edges and the original drawn-input EPS rules. The24-failure candidate and diagnostic remain intact.

### Shared correction and bounded generated-output handling

Both `segment_distance` and `material_length` now use one domain-local intersection-fraction function. It checks actual segment bounds and uses scalar double relative-coordinate products and bounded parameters. Parallel, collinear overlap, exact contact, degenerate segment and disjoint cases remain distinct. There is no call left to the numerically problematic `Geometry2D.segment_intersects_segment` in the helper. Segment distances still use the original closest-segment calculation when no real intersection exists. No EPS, kerf margin, score, tooth, radius, depth, contact or time coefficient changed.

Only the result of `Geometry2D.offset_polygon` goes through `_offset_contour`: the raw result must still contain exactly one component and at most512 vertices. Exact consecutive duplicates and a repeated closing coordinate are removed; every nonzero edge endpoint remains verbatim. Area>1, source-board bounds, source-center inclusion and true topology remain required. Shared exact intersection checks reject actual nonadjacent crossings/touches and adjacent backtracking overlap. The original `simple()` EPS edge-spacing guard remains unchanged for input candidates. A dedicated one-ULP fixture proves the generated contour is preserved while the same sequence is still rejected by the unchanged input-spacing guard. Real crossed/touching/backtracking output fixtures remain rejected. No fragments are selected, holes ignored, nonzero points smoothed or captured inputs altered.

### Actual captured results

All six exact input contours now pass `simple()`. All12 offsets are still raw singletons, with unchanged areas; duplicate-only canonicalization retains the following vertices:

| Captured trace | Inward raw→retained | Outward raw→retained |
|---|---:|---:|
| A1 |421→406 |410→397 |
| A2/A3 |420→405 |409→396 |
| B1 |441→422 |419→401 |
| B2/B3 |447→432 |427→411 |

B2/B3 inward area remains10667.620428630 and outward area12289.949235902. The fixture asserts retained points equal the raw sequence with only exact consecutive/closing duplicates removed, and asserts the scalar areas are exactly equal. Both original disjoint pairs now have the proper positive closest-endpoint distance for every tested ordering. Genuine crossing/overlap/touch cases still return zero; parallel gaps and material-length removed/disjoint intervals remain correct.

In addition to exact-array geometry tests, the final fixture resets an assisted Model for A/B, sets depth .25, feeds each of the three captured arrays through public `move_cursor_to`/`begin_tool`/`release_tool`, then invokes public fold. Both folds succeed with zero mistakes and three real strokes: A produces395 outline vertices and measured radius48.567805767; B produces417 vertices and radius56.619881808. Public replay intentionally goes through the normal assisted projection/sampling again, so these resulting vertex counts differ from the raw-array unit tests. This is a public captured-point Model replay, **not a claim that the original held-key Driver schedule has been rerun after the fix**; that consumer verification remains with the presentation owner after this core gate.

All141 retained assertions, eight original public winning routes with clean400/500 scores and unchanged measured placement recipes, reversed idler route, cutoffs, sampling/closure caps and earlier fixed regressions pass. No private geometry, state or result injection was used in a winning route or public captured fold.

### Final frozen sources and launch closure

| Source | Lines | SHA256 of actual current bytes |
|---|---:|---|
| `game/minigames/chocolate_etching_geometry.gd` |228 |`803bc755a1f33c7c0ede31729e8436af8f458cea16eb2fcbe1a8b2f5ebce2fe2` |
| `game/minigames/chocolate_etching_model.gd` (unchanged) |447 |`abb2c78ddda00dd9a424e89d7a2d2fb9e600c9277f5bcecf2839566748c76bab` |
| `game/tests/test_chocolate_etching.gd` |722 |`3228a4bd9982d3757b9c96c9aca36051110a04c6ccf55e86a1dcccc7b19378d3` |
| `game/tests/chocolate_assisted_keyboard_replay.json` |1 |`555443a68e545b75b99cbc56f9216a7c3ca1a3d2516289cc03a56af898f41c89` |

The three GDScript files use LF and their canonical-LF hashes equal raw hashes. Replay JSON was written with a final Windows CRLF; its separately labeled canonical-LF SHA256 is `6a83262490e4f8d5165e4ce14ef16c69c7f1b413cc837d0e4ef52f187508fa7c`. Git blob IDs are separate in the index. Do not rewrite the preserved raw fixture/logs to make these representations appear identical.

All four current raw hashes equal the final staged-source manifest. Hygiene passed before freeze: no trailing whitespace/excess EOF blank line. Source fixture arrays were independently compared to all six originals and source hashes. Presentation handoff hashes were rechecked unchanged and those six files were confirmed absent from the final stage manifest. No engine or source/fixture rewrite followed final acceptance candidate verification.

Private runner change is only the explicit JSON fixture allowlist and its exact two-file `game/tests` closure assertion. Staging remains tracked runtime plus exact owned fixture/helper files, no untracked presentation/cache/import files, no broad test tree and no known four fault-child parents. Every staged GDScript is audited before exact validated Godot4.7.2 SceneTree launch; no OS child API hits. Each process has fresh absolute D stage/save/APPDATA/LOCALAPPDATA/TEMP/TMP, with no GUI/Paper import or unrelated PID action.

Final receipt raw-file SHA256: `1437a4e8b5f7e8c42e1d4d6a1181f3c5ae5ace986ed23c99d99a67759c02e571`. The current evidence index appends all five runs, complete literal commands/environments, source manifests, exit codes, log/receipt written-byte hashes, handoff/data provenance and current source graph. The pre-core3 index is preserved byte-exact as `evidence-index-before-core3.json`; all earlier accepted141 logs/manifests/stages remain unchanged. Hashes describe written files; the launcher-decoded Unicode caveat remains and no original pipe-byte capture is claimed.

No remaining core defect was observed in the scoped captured-contour/public-fold checks. The two earlier Minor coverage gaps remain deferred. Fresh held-key Driver routes, presentation at three sizes, native/GPU/export and human operation remain the presentation/controller workflow, not this core follow-up.
