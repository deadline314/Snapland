### Spec compliance

**Issues found.** The fifth factory game is integrated and its natural results follow the approved participation rule. Two catalog descriptions contradict that rule. The Main regression also leaves the destination of two entry actions and the presence of the selected retake panel unchecked. See I1–I3 below.

**Reviewed revision** `23e21b0ed211617571f70054faa6cd57ce98b802..451c39318a4f0c76f6fafc188a1936bf14ece1a9`, 32 files, Task 3 only. The package covers the named production, design, runner and regression files, including the new Main scene at `game/tests/test_chocolate_etching_main.tscn:3`.

### Strengths

- The new catalog row uses the fixed ID and local index. The identity test checks both lookup keys, both photo IDs and the achievement. The world appends a station at the specified coordinates and tests real physics selection alongside the existing entrances and visible 5／12 sign. See `game/data/candy_games.json:59`, `game/tests/test_game_catalog.gd:47`, `game/world/candy_world.gd:94` and `game/tests/test_candy_world.gd:39`, `:66`, `:71`.
- The Session fixture dispatches input events, measures actual output travel and checks speed direction, contact pairs and natural result scores for the eight routes. Separate assertions exercise held strokes, drag, rotation, pause, blur, retry, timeout, practice and cancellation. See `game/tests/test_chocolate_etching_session.gd:18`, `:51`, `:83`, `:108`, `:129`, `:155`, `:172`.
- The Main comparisons cover zero cards on idle timeout, one local ordinary card and one 40-coin receipt on a qualifying cut, subsequent genuine devil proof and reload. Where the retake panel is present, the fixture explicitly labels synthetic PNG I/O, checks the full-resolution pixels, records the original file hash and checks it after a genuine matching challenge and reload. See `game/tests/test_chocolate_etching_main.gd:109`, `:117`, `:128`, `:177`, `:191`, `:208`, `:211`.
- All five new CI entries require exact completion markers and use the appropriate scene or script. The lesson supplies three existing image paths, the eight-action undo limit and the reward distinction. The small-screen test iterates every lesson, step and semantic page. See `tools/run_game_tests.py:24`, `:267`, `:369`, `game/data/tutorials.json:1052`, `:1058`, `:1067`, `:1076`, `:1079`, and `game/tests/test_tutorial_paged_viewport.gd:19`, `:41`.

### Issues

**Critical — 0.**

**Important — 3.**

1. **I1. Incorrect ordinary collectible requirement in both design catalogs.** `design/02-minigames/catalog.json:737` and `design/02-minigames/catalog.md:618` say both collectibles require hand cutting, folding, placement and a full revolution. A formal session qualifies for the ordinary collectible after any qualifying hot cut and natural settlement, even on timeout. A full turn with an in-path leftover idler is the devil challenge. Correct both copies. The tutorial, runtime and Main timeout evidence already agree with the authority at `design/runtime/chocolate-etching-gameplay.md:25`, `:39` and `game/tests/test_chocolate_etching_main.gd:114`.
2. **I2. The entry assertions can pass after opening a different game's invitation.** `game/tests/test_chocolate_etching_main.gd:54` and `:98` check only the common modal kind. The following calls at `:61` and `:99` explicitly supply the expected ID, so they bypass the destination chosen by E and by the focused map button. Check the target-specific visible invitation after each event. Following its actual start button through to the expected tutorial would also verify the selected target.
3. **I3. An absent retake panel silently skips the mandatory capture and reload assertions.** `game/tests/test_chocolate_etching_main.gd:169` returns after a check of only the modal kind and selected target. If those fields are correct but the panel failed to mount, the helper skips the shutter, selected award, PNG and post-challenge reload checks. Both selections could take this path while `:237` still reports PASS. Record a failed check for an absent panel before the guard returns.

**Minor — 1.**

1. `tests/test_runtime_result_contract.py:267` places all five Chocolate cases inside `JELLY_SUITES`. The union currently exercises all cases, but a caller selecting Jelly by name gets both families. Give Chocolate its own mapping and include it in the existing union.

### Evidence and limits

- The accepted index identifies the pre-wiring Session failure, two intermediate paged-fixture parser failures, and 17 promoted fixtures. The controller's freeze record ties 32 files, 49 historical receipts and 190 raw artifacts to the accepted evidence and confirms current promoted source graphs and frozen core/Task 2. The producer records 98 Python checks plus passing games/links scopes. The fixture parser failures are historical runs, distinct from the behavioral RED. See `.review/chocolate-etching-20261118/integration/root-freeze-verification.json:2` and `.superpowers/sdd/2026-11-18-chocolate-etching/task-3-report.md:9`, `:12`, `:39`.
- Diagnostic noise in the producer's record consists of existing scenery material warnings and the deliberately missing tutorial image. Both have identified causes. The review found no new Task 3 warning in that evidence. See `.superpowers/sdd/2026-11-18-chocolate-etching/task-3-report.md:49`.
- One hunk cuts off the natural-settlement branch of the shared participation fixture. A focused read of the omitted `game/tests/test_participation_results.gd:46`–`:52` confirmed that drivers advance through Session ticks before asserting the natural timeout result. No other changed implementation file was reopened, and no Git, engine or test commands were executed.
- **Cannot verify from this task diff.** GPU-produced photo pixels, current latest-gameplay-photo refresh, the new-process retake reader, packaged EXE, and native three-size UI acceptance belong to Task 4. The four fault-child parents remain CI-only. The selected headless runs support the stated numerical, event and synthetic-I/O checks. Controlled positioning and simulated input provide no evidence of human walking, physical touch, listening or cross-device performance. See `game/tests/test_chocolate_etching_main.gd:49`, `:177` and `.superpowers/sdd/2026-11-18-chocolate-etching/task-3-report.md:20`, `:26`.

### Assessment

**Task quality — Needs fixes.** Correct the two catalog entries and make the Main fixture detect both wrong destinations and a missing retake panel. The current receipts record successful paths, but the PASS marker also admits the regressions described above.
