# SG-45 Task 2 fix round 1

## Finding verdicts

- **Important 1, canceled mouse release commits a gesture — ADDRESSED.** At `game/minigames/chocolate_etching_driver.gd:40`, every recognized pointer event now takes the cancellation path before motion or release processing. The existing owner check prevents an unrelated source from clearing the gesture. At `game/tests/test_chocolate_etching_driver.gd:103`, the mouse fixture supplies Godot's actual cancellation flag. The cut regression at `:524` records 30 board units of preview travel and verifies zero committed strokes, zero undo entries and no participation after cancellation. The drop regression at `:561` preserves the original mounted position and four undo entries after a drag to another valid interior location. Later ordinary releases leave the full snapshots unchanged at `:540` and `:567`. Both directions of wrong-source cancellation are exercised at `:467` and `:534`.
- **Minor 1, stale held commands in the terminal step — ADDRESSED.** At `game/minigames/chocolate_etching_driver.gd:159`, the terminal return clears the outward held-command array after releasing ownership. The route retains the actual return dictionary from the final step at `game/tests/test_chocolate_etching_driver.gd:387`. The held-Space keyboard route checks an empty held-command list and equality with the settled snapshot at `:30`.

## Fix evidence

The diff covers two files between `322486c161825acb1b16a304bb08a8f479473b33` and `23e21b0ed211617571f70054faa6cd57ce98b802`. The old-source run reports exactly the three expected failures for the cut, the mounted drop and the terminal step. The final Driver passes 73 checks with exit 0, empty stderr and zero engine issue lines. All 24 structured route results match both the old-source run and the earlier accepted Driver record exactly. See `.review/chocolate-etching-20261118/presentation/evidence-index-fix1.json:74`, `:84`, `:2086`, `:2141` and `.review/chocolate-etching-20261118/presentation/evidence-index.json:2277`.

## New breakage in the fix diff

None. Critical 0, Important 0, Minor 0.

## Out-of-scope observations

None.

## Verdict

**Spec compliance — Approved for Task 2. Task quality — Approved.** Both prior findings are addressed. There are no open Task 2 findings.

**Cannot verify from this fix.** The final-Driver regression uses Godot input events at the Driver boundary. The three native workbench runs, View run and raw tutorial PNG captures retain their original provenance on the earlier Driver revision. Native delivery in the integrated Main and physical device behavior have separate acceptance. See `.review/chocolate-etching-20261118/presentation/evidence-index-fix1.json:23`.
