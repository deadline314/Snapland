# SG-45 Task 4 · Native Main and independent Windows executable

**Frozen scope** · Accepted native GPU evidence for 3 Main size suites, 4 selected retake pairs and 1 standalone Windows executable pair. Each pair has a fresh writer and an independent new-process reader. All 16 runtime processes exited 0, recorded the expected exact marker once per available engine output stream, and emitted zero `ERROR:` and genuine leak or still-in-use diagnostics.

Runtime source base `687944d683493c466879810b5c9e8d309ffc8c7a` plus the two new Native Main fixture files. The complete raw source manifest records the fixtures and tracked runtime. It excludes repository `.uid` and `.import` sidecars. The fixture stages use verified asset-only reuse from one new exact-source D import. Task 1–3 suites remain prior evidence.

## Actual Main, controls and layout

The only synthetic progression is six welcome admission cards and opening seen. Setting the isolated viewport/accessibility profile and placing the actor at the sign `(0, GROUND_Y, -10.8)` or physical kiosk `(10.5, GROUND_Y, -0.8)` are labelled setup. Physical nearest selection and parsed E open the actual kiosk. Parsed M opens the actual ticket, then focused Enter drives the regional map’s five-entry list and chocolate invitation. Both the factory sign and achievement book show the catalog’s five delivered entries. Identity is `game-029` / `chocolate_etching` / candy local 5 / `photo-candy-game-5` / `photo-candy-devil-5` / `ACH_GAME_029`.

All five actual rule pages and every semantic tutorial section are visited at each suite size. The three 1280×720 tutorial textures decode on the real Main and inside the standalone executable. Evidence JSON records active text/Button rectangles, clipping-ancestor intersections and fit. The actual pager selects the active semantic group while the inactive groups remain outside the scroll window. At 800×600 the shared tutorial uses its existing one-line ellipsis for the small screenshot alt caption. The existing tooltip and zoom UI use the full caption. The fixture verifies all semantic copy pages and their visible bodies, and leaves zoom unexercised. The house View checker plus measured transformed rectangles verify all 12 controls and bound text beneath the real Session HUD. The 800×600 pair saves and reloads text scale 1.25 and reduced motion.

The fixture parses Godot keyboard, mouse and synthetic screen-touch events and flushes buffered events through the focused GUI and normal Session. Its local clock adapter calls Session `_process(delta)` for keyboard motion and held rotation and advances 1/120 second after each parsed workbench pointer or touch event while the Session is live. It reads snapshots and never advances the Driver or Model directly. Before a board capture it force-refreshes the HUD from the current actual Session snapshot. This presentation call advances no time. The existing HUD floors the outlet percentage and the board rounds the same numeric value to the nearest integer. The ordinary mid-turn capture therefore shows 20% and 21% for 1.3125 radians. Graphical setup may spend a few real frames before binding. Adapter seconds and total game seconds are both retained. Neither is human completion timing.

A deep contour is submitted and undone. A single 0.5 contour remains attached. A matching second 0.5 contour cuts through, produces an actual measured outline and material hole, then undo restores the material without refunding time. A real HUD retry begins a clean round. Keyboard, mouse, and synthetic touch complete three-wheel, leftover four-wheel and assisted four-wheel-while-clamped routes respectively. Connected topology is measured from extracted radii and mounted positions. A held input drives actual outlet rotation to TAU, with positive rotation for the ordinary transmission and negative rotation through the intervening idler. The AI clamp starts with zero traces and participation. A genuinely submitted open stroke leads to qualified failure at the actual 240-second deadline. Real GUI practice can complete the four-wheel route without changes to rewards or photos. Esc drops the live preview, pause freezes material and elapsed time, and actual HUD leave confirmation cancels without awards.

## Actual GPU shutter and persistence

Each retake pair enters selected practice through the actual kiosk rules button, submits an actual cut, and leaves through the pause HUD to return to that selection. Parsed GUI arrangement changes prop, framing and distance. The real SubViewport shutter stores a 1280×720 original whose decoded pixels equal the arranged GPU frame and one decoded 320×180 thumbnail. A shutter gives only the selected card, `retake` acquisition and no challenge proof, one 40-coin receipt (120 → 160) and the fixed game achievement. Later actual matching completion preserves both stored paths, their SHA-256 and retake method. Only a matching devil completion adds devil proof and can acquire the other ordinary card.

An independent reader verifies all acquired IDs, each complete provenance record and decoded file SHA, the exact 160 coins, the one game receipt, the region, the actual attempt/tutorial and the achievement. For ordinary gameplay, subsequent completion refreshes the shared latest gameplay photos. This behavior is distinct from the retake original preservation asserted before completion, afterward, and in the reader. No older factory card is granted.

## Launch isolation and embedded output

Exact Godot console `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe` reports `4.7.2.stable.official.ed1daf0bf` and has SHA-256 `c8f0a6bc45a19b33541501e57f6f7cd972ab18453743266339d495cbbe846643`. Its graphical sibling `C:/Tools/Godot/Godot_v4.7.2-stable_win64.exe` has SHA-256 `ab1824f85bfd8e0e4128182c000c4003a3e042245b2967848d089b2a04b22424`. The actual native renderer logged Vulkan Forward+ on AMD Radeon RX 9070 XT. The independent Windows QA executable is `D:/Snapland-chocolate-task4/final-embedded-export-1118-132631-8a7d71/release/ChocolateEtchingQA.exe` (285,894,864 bytes, SHA-256 `6ecf816ac41bd9fd0eac4eb88b60dbcad9b05d7aee6bbfd058aa0fb9651e5338`).

The local validated-launcher timeout is 300 seconds. The inherited fixture wall-clock watchdog is 180 seconds. Before every launch the harness audits the staged script, scene, resource and configuration graph, including inherited base, autoloads and dynamic-loaded runtime paths. The four known fault-child parents are absent from staging and remain registered in CI. The exact six-file closure includes the two newly added fixture files, the existing Sugar base and AudioRelease helper, plus the unchanged Driver Route and View layout helpers authorized in the Task 4 handoff.

Each version/import/export/runtime call has fresh absolute D stage, APPDATA, LOCALAPPDATA, TEMP, TMP and capture paths. The paired reader alone shares the writer save. Asset reuse contains only hashed import sidecars and addressed asset artifacts from the fresh exact-source import. Whole `.godot` caches, class/UID/script/editor caches and old builds are excluded. Engine log bytes are retained verbatim. The validated launcher's separately captured stdout and stderr are unsuppressed UTF-8 text re-encoded as UTF-8 by the harness. No diagnostics are filtered before writing logs. The audio-release helper checks destruction of captured playback references.

The standalone PCK is embedded in a new Windows PE. Its private staged project points to the fixture and permits the exact staged Windows QA closure. The exporter’s own savepack log confirms every allowlisted test remap, the five compiled fixture scripts and the compiled scene, with no other test path. The export stage’s final source bytes match its audited graph. The production project main and normal Windows/Linux test exclusions remain intact. Both actual `.exe` launches use their clean release directory and only an absolute `--log-file` argument after the executable. They have no path/scene/project override or loose project/PCK.

- Pinned 4.7.2 Windows debug template `D:/Snapland-chocolate-task4/final-embedded-export-1118-132631-8a7d71/templates/windows_debug_x86_64.exe` (103,176,704 bytes), SHA-256 `51498b72b3a237f882ebd7d1787f06a4bc1eaf0572daab93837adcfd3cfdc107`.
- Pinned 4.7.2 Windows release template `D:/Snapland-chocolate-task4/final-embedded-export-1118-132631-8a7d71/templates/windows_release_x86_64.exe` (109,268,480 bytes), SHA-256 `d34d36f3be1a6c49c56525ae86469b92e4f417ddf0b43cf00dd80c385c4b0562`.

Selected executed source raw SHA-256 values

- `game/tests/native_chocolate_etching_main.tscn` · `123e99acdc3279f51f6d16a86eddb704d517a3940adabb01f6a37cdf837a0f3a`
- `game/tests/native_chocolate_etching_main.gd` · `c42a38355a91226409d7307472e1749c474c37755c7a9e51baa18fecb43f6dce`
- `game/tests/native_sugar_bridge_main.gd` · `f802c6de3c6ae892ae2895a13cff7917a13d14b857082267ce1910a7024524d7`
- `game/tests/audio_playback_release.gd` · `1b61bba4e5c54e38050e8ba0b7170b18848198928937ca2c4dfdebc31cc37184`
- `game/tests/test_chocolate_etching_driver.gd` · `692556827fc5792ec54e809fe9805a25b8bddec6723942ad50ebdf0979c108ab`
- `game/tests/test_chocolate_etching_view.gd` · `7aaa70f8edc4181c96e80578735669900ca770c816a3fe6374c34ba1b31bb726`
- `game/main.gd` · `73d8ad474871d9130ec7334e83ce676e53aef87deca035028e7ff0333268b40e`
- `game/minigames/session.gd` · `a16a9aabbd62de132adb2a1205ce25c112302676f3bebd0dfb4722c50891f4a3`
- `game/minigames/chocolate_etching_driver.gd` · `410ed7532c42db2fde8f5617b459a772b03392efc43b93b9a944c27917292c9b`
- `game/minigames/chocolate_etching_view.gd` · `343e6441c59d1cfd62d571b2d55dddaae430840bc9a0ad000500d8ddfa5b30b8`
- `game/minigames/chocolate_etching_model.gd` · `abb2c78ddda00dd9a424e89d7a2d2fb9e600c9277f5bcecf2839566748c76bab`
- `game/minigames/chocolate_etching_geometry.gd` · `803bc755a1f33c7c0ede31729e8436af8f458cea16eb2fcbe1a8b2f5ebce2fe2`

The full runtime graphs also retain the two QA-only staged configuration SHA values for the Windows executable. These are raw executed bytes. Git text normalization can produce different committed blob hashes.

Version receipt

`D:/Snapland-chocolate-task4/final-version-1118-132151-8c72be/receipt.json`  
SHA-256 `3d652a869e5bcf83ca8cd34d23397dbd43ff9350b1a32e289d2dcdbcd7414df6`, 2779 bytes.

Fresh import receipt

`D:/Snapland-chocolate-task4/final-donor-1118-132157-351b57/receipt.json`  
SHA-256 `88f357168a8746fc43a329c5192b1db6031ee890b48b4f4445ae7078e98cc532`, 3195 bytes.

Fresh import addressed file list

`D:/Snapland-chocolate-task4/final-donor-1118-132157-351b57/asset-import-files.json`  
SHA-256 `5ba6ec1f513c3fc287dfe021f32238198be59270e01b31fd0cab40e2bc0b32cf`, 159831 bytes.

Windows build identity

`D:/Snapland-chocolate-task4/final-embedded-export-1118-132631-8a7d71/build.json`  
SHA-256 `ed4933ee365c6fcec27968df45ffc22ce20a9284abc6192c6956a0adb1e73c18`, 128071 bytes.

Windows exporter receipt

`D:/Snapland-chocolate-task4/final-embedded-export-1118-132631-8a7d71/receipt.json`  
SHA-256 `fec05904cb2ac823aadb10cedcd4a105edc8caa0b300c8906e7b1e4649e1d609`, 3699 bytes.

## Accepted runtime pairs

The pair receipts chain exact commands, isolated environment, complete source/runtime graphs, prelaunch audits, raw log hashes and all output hashes. Separate route clocks below reflect the actual Session stepping, with timing rounded here and full precision in the original evidence.

| Mode / dimensions | Writer and reader wall seconds | Writer and reader parsed events | Rule / lesson page / 12-control checkpoint counts | Pair receipt SHA-256 |
|---|---:|---:|---:|---|
| suite 800x600 | 10.41 / 4.79 | 6993 / 6 | 5 / 15 / 12 | `8478be99cc51a37cbb46eb6d319726268cbc960508e5327ab385592c87cae0c0` |
| retake-ordinary 800x600 | 7.41 / 4.64 | 340 / 4 | 0 / 0 / 1 | `604152407b31bb5993a671c211f887508956e9d05eaaeb86bc9f68abc9a4a43c` |
| suite 1280x720 | 10.72 / 4.82 | 6971 / 6 | 5 / 6 / 12 | `21fb40930363a96bd553ed114680227989cb65cc2fa7accb8a1253741f908af3` |
| suite 1152x648 | 10.43 / 4.98 | 6975 / 6 | 5 / 6 / 12 | `e57b2645328e977da0d78f714bdabdbe459cead333d04bb3647315572336ac89` |
| retake-ordinary 1280x720 | 7.96 / 4.67 | 336 / 4 | 0 / 0 / 1 | `2f07996ceee74e1c643827b19c539aa16c7fa09275432a9c5a62761a523ef1ea` |
| retake-devil 1280x720 | 8.22 / 4.92 | 395 / 6 | 0 / 0 / 2 | `8c8e8a796d88f86925f5f82b2dc4d4e292f2f22c4441129d90b45a9210b09c69` |
| retake-devil 1152x648 | 8.28 / 4.80 | 399 / 6 | 0 / 0 / 2 | `7399250e7fca3dfad5056e2aef967c60c8264026e6c99ab6a67032a8fc989baa` |
| embedded suite 1280x720 | 13.77 / 4.46 | 6971 / 6 | 5 / 6 / 12 | `7a010f321dfd939a0418bd9493cd53dbed877b0dff9d6a3952885cf6f99a15a6` |

| Mode / dimensions | Route | Score | Elapsed / adapter seconds | Mid-turn output rad/s |
|---|---|---:|---:|---:|
| suite 800x600 | ordinary | 400 | 83.439 / 83.439 | +1.75 |
| suite 800x600 | devil | 500 | 6.081 / 6.008 | -2.00 |
| suite 800x600 | assisted-ai | 500 | 6.109 / 6.025 | -2.00 |
| suite 800x600 | timeout | 0 | 240.000 / 239.920 | — |
| suite 800x600 | practice | 500 | 6.635 / 6.557 | -1.75 |
| retake-ordinary 800x600 | matching-challenge | 400 | 5.559 / 5.533 | +2.00 |
| suite 1280x720 | ordinary | 400 | 83.439 / 83.439 | +1.75 |
| suite 1280x720 | devil | 500 | 6.104 / 6.008 | -2.00 |
| suite 1280x720 | assisted-ai | 500 | 6.147 / 6.025 | -2.00 |
| suite 1280x720 | timeout | 0 | 240.000 / 239.883 | — |
| suite 1280x720 | practice | 500 | 6.666 / 6.557 | -1.75 |
| suite 1152x648 | ordinary | 400 | 83.439 / 83.439 | +1.75 |
| suite 1152x648 | devil | 500 | 6.098 / 6.008 | -2.00 |
| suite 1152x648 | assisted-ai | 500 | 6.136 / 6.025 | -2.00 |
| suite 1152x648 | timeout | 0 | 240.000 / 239.887 | — |
| suite 1152x648 | practice | 500 | 6.657 / 6.557 | -1.75 |
| retake-ordinary 1280x720 | matching-challenge | 400 | 5.561 / 5.533 | +2.00 |
| retake-devil 1280x720 | matching-challenge | 500 | 6.035 / 6.008 | -2.00 |
| retake-devil 1152x648 | matching-challenge | 500 | 6.036 / 6.008 | -2.00 |
| embedded suite 1280x720 | ordinary | 400 | 83.439 / 83.439 | +1.75 |
| embedded suite 1280x720 | devil | 500 | 6.097 / 6.008 | -2.00 |
| embedded suite 1280x720 | assisted-ai | 500 | 6.147 / 6.025 | -2.00 |
| embedded suite 1280x720 | timeout | 0 | 240.000 / 239.897 | — |
| embedded suite 1280x720 | practice | 500 | 6.668 / 6.557 | -1.75 |

### Accepted receipt paths and raw SHA-256

**suite 800x600**

`D:/Snapland-chocolate-task4/final800-read-1118-132244-abf473/pair.json`  
SHA-256 `8478be99cc51a37cbb46eb6d319726268cbc960508e5327ab385592c87cae0c0`, 507 bytes.

`D:/Snapland-chocolate-task4/final800-suite-1118-132224-f7d81d/receipt.json`  
SHA-256 `acf4a80095eadfd66edb0107daf5c5bbcc7f6fc15a92d9c31c0feec614a63506`, 14523 bytes.

`D:/Snapland-chocolate-task4/final800-read-1118-132244-abf473/receipt.json`  
SHA-256 `0354cadc52b327449ea7f120577257f6d1cd934b0845b6603a1e9ea7a38e9077`, 4484 bytes.

**retake-ordinary 800x600**

`D:/Snapland-chocolate-task4/final800-read-1118-132317-733468/pair.json`  
SHA-256 `604152407b31bb5993a671c211f887508956e9d05eaaeb86bc9f68abc9a4a43c`, 526 bytes.

`D:/Snapland-chocolate-task4/final800-retake-ordinary-1118-132259-580fd0/receipt.json`  
SHA-256 `2e9a23938f2a80c761666f21dca3e50eb113dbdf073f36c9d8746ac17455cf34`, 6886 bytes.

`D:/Snapland-chocolate-task4/final800-read-1118-132317-733468/receipt.json`  
SHA-256 `2c96b80c7fbab4ed889394c7b7013344574fd0d7b42bd2586a1629e5b7682eff`, 4265 bytes.

**suite 1280x720**

`D:/Snapland-chocolate-task4/final1280-read-1118-132401-77a720/pair.json`  
SHA-256 `21fb40930363a96bd553ed114680227989cb65cc2fa7accb8a1253741f908af3`, 511 bytes.

`D:/Snapland-chocolate-task4/final1280-suite-1118-132340-22edfd/receipt.json`  
SHA-256 `d0a5a44fb59609351acf1cbebae7bfce014bddfcf8996f32a99c5b32e393b70a`, 12532 bytes.

`D:/Snapland-chocolate-task4/final1280-read-1118-132401-77a720/receipt.json`  
SHA-256 `6ff283b11dd839e2582625a099ea5ca84e50413262bbb48b92219188d4ce1585`, 4506 bytes.

**suite 1152x648**

`D:/Snapland-chocolate-task4/final1152-read-1118-132436-c62cef/pair.json`  
SHA-256 `e57b2645328e977da0d78f714bdabdbe459cead333d04bb3647315572336ac89`, 511 bytes.

`D:/Snapland-chocolate-task4/final1152-suite-1118-132416-f3ef20/receipt.json`  
SHA-256 `04205a66b6932097c0c6535f2ea5de2eda1d216c544ba8d47ad4839aa2d539bc`, 12528 bytes.

`D:/Snapland-chocolate-task4/final1152-read-1118-132436-c62cef/receipt.json`  
SHA-256 `e59de684dd495b27635cbb87431c63567ca92d31e966d2a267d306c9531fbec1`, 4506 bytes.

**retake-ordinary 1280x720**

`D:/Snapland-chocolate-task4/final1280-read-1118-132510-c63183/pair.json`  
SHA-256 `2f07996ceee74e1c643827b19c539aa16c7fa09275432a9c5a62761a523ef1ea`, 530 bytes.

`D:/Snapland-chocolate-task4/final1280-retake-ordinary-1118-132451-e3e80f/receipt.json`  
SHA-256 `a1c098a8d4813a6e3f2cc6afffc8081b3fcae061b7e7e7c10a9b498da1ac1fcf`, 6918 bytes.

`D:/Snapland-chocolate-task4/final1280-read-1118-132510-c63183/receipt.json`  
SHA-256 `248aa6e76b1d34e8c6e7cbbc59c19c1ceccbdaccbc656b29a32ee8aee351d020`, 4286 bytes.

**retake-devil 1280x720**

`D:/Snapland-chocolate-task4/final1280-read-1118-132542-36f392/pair.json`  
SHA-256 `8c8e8a796d88f86925f5f82b2dc4d4e292f2f22c4441129d90b45a9210b09c69`, 524 bytes.

`D:/Snapland-chocolate-task4/final1280-retake-devil-1118-132524-a99cef/receipt.json`  
SHA-256 `0416cd0839076a2ce3854376d1e0359d60c11e02eea63da4b0bc292eb5d1054b`, 7312 bytes.

`D:/Snapland-chocolate-task4/final1280-read-1118-132542-36f392/receipt.json`  
SHA-256 `ef3fef8e36db85eadbf4c645a484e71020a1e5750a4e93e12af49a24a0319784`, 4513 bytes.

**retake-devil 1152x648**

`D:/Snapland-chocolate-task4/final1152-read-1118-132616-a97880/pair.json`  
SHA-256 `7399250e7fca3dfad5056e2aef967c60c8264026e6c99ab6a67032a8fc989baa`, 524 bytes.

`D:/Snapland-chocolate-task4/final1152-retake-devil-1118-132558-8f4c67/receipt.json`  
SHA-256 `23b95d9f6fb706078d2457e5c09cf8ccd806091d0c6c8c487a4582c8f48cd899`, 7312 bytes.

`D:/Snapland-chocolate-task4/final1152-read-1118-132616-a97880/receipt.json`  
SHA-256 `e4d373ba04f31a4534543fa093ff2eb93d4b9987f01263873bbd0a83a1603e91`, 4513 bytes.

**embedded suite 1280x720**

`D:/Snapland-chocolate-task4/final-embedded-exe-read-1118-132730-a9f293/pair.json`  
SHA-256 `7a010f321dfd939a0418bd9493cd53dbed877b0dff9d6a3952885cf6f99a15a6`, 538 bytes.

`D:/Snapland-chocolate-task4/final-embedded-exe-suite-1118-132705-7aad6c/receipt.json`  
SHA-256 `d0b6fd1554c19708e7ef8caf844a9b850600fffa905008b50a86136aba32c695`, 12919 bytes.

`D:/Snapland-chocolate-task4/final-embedded-exe-read-1118-132730-a9f293/receipt.json`  
SHA-256 `a2922988745f61eec49da29f654db22f61f6dc6a8a65d05ba08575bad2d9eacd`, 4579 bytes.

## Diagnostics, artifact promotion and limits

Accepted version/import/export/runtime receipts contain no warning lines.

Archive inputs are explicitly enumerated by existing absolute path, raw SHA-256, byte count and category in `C:/Users/stanl/Github/Snapland/.review/chocolate-etching-20261118/native/promoted-archive-allowlist.json`. That file includes final raw PNGs, still-referenced photos, all final receipts/audits/logs/source graphs and the private launch/freeze source. The hashed executable and templates remain on D.

Rejected probes stay distinct under the private D root. `draft1-1280` caught a fixture parser failure. `draft2-1280` passed writer gameplay but the reader rejected GDScript integer versus parsed JSON float types. The persisted JSON records matched. The 800 `current800` writer confirmed core gameplay and layout and exposed a fixture error that required visiting the actual stamp's page before expecting visible text. Unused candidate donor stages are retained with original hashes. These probes remain outside the promoted archive.

Production source, frozen tests/helpers, acceptance history, player saves and normal exports remained intact. This evidence is scripted GPU/input/persistence coverage on one machine. Human play timing, physical touch, hearing, cross-hardware behavior and walked admission were outside this verification.
