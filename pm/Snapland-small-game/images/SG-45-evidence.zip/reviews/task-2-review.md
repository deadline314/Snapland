# SG-45 Task 2 review at 322486c

## Spec compliance

❌ Issues found. One path commits a mouse gesture that Godot explicitly canceled. The design requires canceling a stroke to discard it and canceling a drop to preserve the mounted gear. See `design/runtime/chocolate-etching-gameplay.md:15`, `design/runtime/chocolate-etching-gameplay.md:31` and Important 1 below.

The reviewed delta from `4f8cef88de82db0e3be48fb01ecce753adde362a` to `322486c161825acb1b16a304bb08a8f479473b33` contains all nine owned files. The pre-implementation missing-script REDs are recorded separately at `.review/chocolate-etching-20261118/presentation/evidence-index.json:61` and `:117`.

⚠️ The standalone fixture verifies Control focus, parsed input and tree exit at `game/tests/native_chocolate_etching_workbench_review.gd:63` and `:80`. Main pause/map routing, Session reward handling, rule and lesson pages, export and retake belong to later acceptance. Human playability, physical keyboard/touch timing, hearing and cross-device rendering require separate observation. The raw tutorial images capture intermediate frame states. Their source and byte identity are recorded at `.review/chocolate-etching-20261118/presentation/evidence-index.json:31` and the controller's image inspection at `.review/chocolate-etching-20261118/presentation/root-freeze-verification.json:7`.

## Strengths

- Real source ownership and continuous movement are exercised through actual event objects. The aliases survive releasing one physical key, opposite directions cancel and recover, and focused Tab delivery survives GUI traversal. See `game/minigames/chocolate_etching_driver.gd:75`, `:141`, `game/tests/test_chocolate_etching_driver.gd:402` and `game/tests/native_chocolate_etching_workbench_review.gd:63`.
- The View and Driver share command rectangles and board transforms. The retained canvas draws measured contours, kerf widths, actual clamps, contact pairs, rotated shapes, a dashed placement preview and the signed output arrow. The scoring footer explains undo, assistance and clean 400/500 scores. See `game/minigames/chocolate_etching_view.gd:58`, `:85`, `:188`, `:268` and `:305`. The layout fixture checks transformed rectangles, clipping ancestors and font metrics at `game/tests/test_chocolate_etching_view.gd:88`.
- The 24 routes trace and extract parts before computing placements from their measured radii. The shaft tests preserve the contact graph while displacing each shaft independently. The idler case checks the actual committed kerf and the actual three removed outlines before checking the specific fourth-fold refusal. See `game/tests/test_chocolate_etching_driver.gd:17`, `:207`, `:336`, `:518` and `:549`.
- The native fixture reuses the route event generator and parses events into the focused Control. It captures a blocked shallow cut, retrace, interior-kerf refusal, undo, outside cancellation, rejected placement and actual moving three/four-wheel networks. See `game/tests/native_chocolate_etching_workbench_review.gd:94`, `:111`, `:156` and `:190`. Accepted records show Driver 62/0 across 24 routes, View 30/0, and 180/0 per native size with three routes and eleven raw captures each. The 800×600 run uses 1.25 text scale and reduced motion. All five accepted runs record empty stderr and no engine issues. The native identity/count check covers 120 presentations and ten retries. See `.review/chocolate-etching-20261118/presentation/evidence-index.json:2277`, `:4368`, `:4917`, `:5025`, `:5574`, and `game/tests/native_chocolate_etching_workbench_review.gd:207`.

## Issues

### Critical

None.

### Important

1. **A canceled left mouse release commits the gesture.** `game/minigames/chocolate_etching_driver.gd:40` checks the cancellation flag only for screen touches. A matching left mouse release with `canceled = true` and an interior point reaches `:54` and `:100` or `:103`. The craft path records a stroke and can mark participation. The assembly path can move or remove an already mounted gear. The event helper at `game/tests/test_chocolate_etching_driver.gd:89` accepts a cancellation argument but applies it only on its touch branch, so the suite misses this case. Handle canceled button/touch events before ordinary release while retaining the owner check. Exercise a canceled mouse cut after actual travel and a canceled interior drop after dragging an already mounted wheel. Check strokes, participation, undo and mounted position as applicable, and verify that a later genuine release cannot commit the discarded gesture. Focused unchanged-code check confirmed that the commit paths actually mutate material/history or placement at `game/minigames/chocolate_etching_model.gd:129` and `:226`. Comparable house drivers also check canceled touch specifically, e.g. `game/minigames/cookie_mold_driver.gd:52`. Godot exposes this flag for mouse buttons as well. [Godot InputEventMouseButton documentation](https://docs.godotengine.org/en/stable/classes/class_inputeventmousebutton.html#class-inputeventmousebutton-property-canceled)

### Minor

1. **The terminal step returns stale held commands.** `game/minigames/chocolate_etching_driver.gd:156` builds the outward snapshot before clearing the Driver's owner state. A final step reached while holding Space reports `held_commands = ["tool"]`, although an immediate `snapshot()` reports it empty. The frozen Model already clears its tool/motion flags on termination at `game/minigames/chocolate_etching_model.gd:299`. The house Session consumes the returned dictionary directly at `game/minigames/session.gd:1021`. Make the terminal return agree with the post-step snapshot and compare the two on one existing route.

## Assessment

**Task quality — Needs fixes.** The three delivered tutorial images, bounded rendering and real-event route coverage have traceable evidence. A mouse cancellation can still alter material or placement and must be corrected before accepting the Driver.

Reviewed the supplied diff in one read and the exact evidence records. No changed-file reread, engine launch or Git mutation. The two focused API checks above cover the effects of cancel/commit and the consumer of terminal step state.
