"""Exercise SG46 file boundaries through the actual graphical Driver test."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import uuid

HERE = Path(__file__).resolve().parent
REPO = HERE.parent.parent
source = REPO / '.review/chocolate-etching-20261118/native/run.py'
spec = importlib.util.spec_from_file_location('capture_stage', source)
stage_tools = importlib.util.module_from_spec(spec)
spec.loader.exec_module(stage_tools)
stage_tools.BASE = '8d96453540789f9d36122c7a516b7a86e71a9593'
stage_tools.FIXTURES = ['game/tests/test_chocolate_etching_driver.gd']


def fresh(label):
    path = Path('D:/Snapland-capture-guard-20261118') / (label + '-' + uuid.uuid4().hex[:8])
    path.mkdir(parents=True)
    return path


stage_tools.make_base = fresh
phase = sys.argv[1]
donor = stage_tools.bootstrap(phase)
cases = ['unset'] if phase == 'red' else ['unset', 'relative', 'resource', 'userdata', 'absolute', 'headless']
results = []
sample = (REPO / 'assets/ui/tutorials/game-029-step-01.png').read_bytes()
for case in cases:
    base, stage, manifest = stage_tools.prepare(phase + '-' + case, donor)
    keys = stage_tools.environment(base)
    capture = {'unset': '', 'relative': 'relative-captures', 'resource': 'res://', 'userdata': 'user://'}
    if case in capture:
        keys['CHOCOLATE_CAPTURE_DIR'] = capture[case]
    relative = stage / 'relative-captures'
    relative.mkdir()
    sentinels = []
    for folder in (stage, relative):
        for label in ('idler', 'owner', 'undone'):
            path = folder / (label + '.png')
            path.write_bytes(sample)
            sentinels.append(path)
    before_png = {p.resolve() for p in base.rglob('*.png')}
    args = [stage_tools.ENGINE, '--path', stage]
    args += ['--headless', '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility'] if case == 'headless' else ['--resolution', '1280x720', '--position', '10,40']
    args += ['--script', 'res://game/tests/test_chocolate_etching_driver.gd']
    receipt = stage_tools.launch(base, stage, manifest, 'capture-boundary', args, keys)
    log = (base / 'engine.log').read_text(encoding='utf-8-sig')
    markers = re.findall(r'^Chocolate etching driver: (\d+) checks, 0 failures$', log, re.M)
    assert len(markers) == 1 and int(markers[0]) >= 92
    if case == 'headless':
        assert markers == ['92']
    else:
        frames = re.findall(r'^STOCK_FRAME (idler|owner|undone) heat=(\d+) hole_heat=(\d+)$', log, re.M)
        assert [v[0] for v in frames] == ['idler', 'owner', 'undone']
        assert all(int(v[2]) == 0 and ((int(v[1]) > 0) == (v[0] != 'undone')) for v in frames)
    intact = all(p.read_bytes() == sample for p in sentinels)
    created = {p.resolve() for p in base.rglob('*.png')} - before_png
    expected = {base / 'captures' / (v + '.png') for v in ('idler', 'owner', 'undone')} if case == 'absolute' else set()
    passed = intact and created == {p.resolve() for p in expected}
    row = {'case': case, 'passed': passed, 'sentinels_intact': intact, 'new_png': sorted(str(p) for p in created),
           'expected_png': sorted(str(p) for p in expected), 'checks': int(markers[0]), 'receipt': stage_tools.describe(base / 'receipt.json')}
    stage_tools.dump(base / 'boundary.json', row)
    results.append(row)
    print(json.dumps(row), flush=True)
path = HERE / (phase + '-results.json')
assert not path.exists()
path.write_text(json.dumps({'source_tool': stage_tools.describe(source), 'donor': str(donor), 'results': results}, indent=2) + '\n', encoding='utf-8')
assert all(r['passed'] for r in results), 'Actual graphical test overwrote a sentinel or exported to an unapproved directory'
