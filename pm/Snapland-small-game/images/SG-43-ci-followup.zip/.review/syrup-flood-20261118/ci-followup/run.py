"""Focused tracked-only syrup rules CI reproduction with fresh D isolation."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import uuid

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from tools.build_desktop_release import prepare_runtime_stage
from tools.godot_entrypoints import run_validated_godot
from tools.run_game_tests import PASS_MARKERS, result_error

HERE = Path(__file__).parent
ENGINE = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
label = sys.argv[1]
assert label in ['red', 'green']
tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT, encoding='utf-8').split('\0')
base = Path('D:/Snapland-QA') / ('syrup-rules-ci-' + label + '-' + uuid.uuid4().hex[:8])
stage = base / 'project'
stage.mkdir(parents=True)
manifest = prepare_runtime_stage(ROOT, stage, tracked)
fixtures = [
    'game/tests/test_syrup_flood_main.tscn',
    'game/tests/test_syrup_flood_main.gd',
    'game/tests/test_syrup_flood_session.gd',
    'game/tests/test_cookie_mold_session.gd',
    'game/tests/audio_playback_release.gd',
]
if label == 'green':
    fixtures += ['game/tests/test_cookie_mold_main.tscn', 'game/tests/test_cookie_mold_main.gd']
for name in fixtures:
    assert name in tracked, name
    source = ROOT / name
    target = stage / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    manifest[name] = hashlib.sha256(source.read_bytes()).hexdigest()
assert not any('jelly_trampoline' in name for name in manifest)
common = [ENGINE, '--headless', '--path', str(stage), '--audio-driver', 'Dummy', '--rendering-method', 'gl_compatibility']
checks = [('clean project import', [ENGINE, '--headless', '--editor', '--path', str(stage), '--rendering-method', 'gl_compatibility', '--import', '--quit']),
          ('syrup Main tests', common + ['res://game/tests/test_syrup_flood_main.tscn'])]
if label == 'green':
    checks.append(('cookie Main tests', common + ['res://game/tests/test_cookie_mold_main.tscn']))
receipts = []
for name, command in checks:
    mode = name.replace(' ', '-')
    profile = base / (mode + '-profile')
    environment = dict(os.environ, SNAPLAND_SAVE_PATH=str(profile / 'progress.json'),
                       APPDATA=str(profile / 'appdata'), LOCALAPPDATA=str(profile / 'localappdata'),
                       TEMP=str(profile / 'temp'), TMP=str(profile / 'temp'))
    for key in ['APPDATA', 'LOCALAPPDATA', 'TEMP']:
        Path(environment[key]).mkdir(parents=True)
    result = run_validated_godot(stage, command, environment, 300)
    output = result.stdout + result.stderr
    log = label + '-' + mode + '.log'
    (HERE / log).write_text(output, encoding='utf-8')
    leaks = [line for line in output.splitlines() if any(word in line for word in [
        'ObjectDB instances leaked', 'resources still in use at exit', 'Orphan StringName', 'pages in use at exit'])]
    receipt = dict(label=name, command=command,
        environment={key: environment[key] for key in ['SNAPLAND_SAVE_PATH', 'APPDATA', 'LOCALAPPDATA', 'TEMP', 'TMP']},
        exit=result.returncode, strict_error=result_error(name, result),
        errors=[line for line in output.splitlines() if 'ERROR:' in line],
        unsupported_material_warnings=sum('WARNING: OcclusionController: unsupported ' in line for line in output.splitlines()),
        leak_diagnostics=leaks, exact_marker_count=result.stdout.splitlines().count(PASS_MARKERS[name]) if name in PASS_MARKERS else 0,
        log=log, source_sha256=manifest, tracked_fixture_allowlist=fixtures)
    receipts.append(receipt)
    (HERE / (label + '-receipt.json')).write_text(json.dumps(receipts, indent=2), encoding='utf-8')
    print(name, 'exit', result.returncode, 'errors', len(receipt['errors']), 'unsupported_warnings', receipt['unsupported_material_warnings'], 'leaks', len(leaks), 'marker_count', receipt['exact_marker_count'], flush=True)
    if name == 'clean project import' and (result.returncode or receipt['errors'] or leaks):
        break
sys.exit(1 if any(row['strict_error'] or row['leak_diagnostics'] for row in receipts) else 0)
