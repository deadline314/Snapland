from pathlib import Path
import os,json,time,hashlib
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();b=r/'work/kite-final-20261022';stage=r/'work/tutorial-current-20261020/validation-project';out=b/'restart-v3';profile=b/'controls-v3/progress.json';assert profile.is_file() and not (out/'result.json').exists()
def files():return {str(p.relative_to(profile.parent)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((profile.parent/'photos').rglob('*')) if p.is_file()}
before=profile.read_bytes();photos=files();assert photos
(out/'before-sha256.json').write_text(json.dumps(dict(progress=hashlib.sha256(before).hexdigest(),photos=photos),indent=2)+'\n')
start=time.monotonic();p=run_validated_godot(stage,[str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'),'--path',str(stage),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--resolution','1280x720','--log-file',str(out/'engine.log'),'res://'+str((out/'entry.tscn').relative_to(r))],dict(os.environ,SNAPLAND_SAVE_PATH=str(profile),SNAPLAND_RESTART_EVIDENCE=str(out)),90)
log=p.stdout+p.stderr;(out/'result.log').write_text(log);record=dict(exit=p.returncode,errors=log.count('ERROR:'),seconds=round(time.monotonic()-start,2),complete_progress_bytes_equal=before==profile.read_bytes(),all_photo_files_equal=photos==files(),photo_file_count=len(photos),scope='Second actual Godot4.7.2 process reading only this Session earned private profile, without reset. Not a desktop-release acceptance.')
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(record,log[-450:],flush=True)
assert record['exit']==0 and record['errors']==0 and record['complete_progress_bytes_equal'] and record['all_photo_files_equal'] and 'PASS: separate Kite engine process' in log
