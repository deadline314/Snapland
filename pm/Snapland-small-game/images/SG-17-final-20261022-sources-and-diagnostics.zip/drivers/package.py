from pathlib import Path
import json,hashlib,shutil,zipfile,re,subprocess
r=Path.cwd();b=r/'work/kite-final-20261022';out=r/'pm/Snapland-small-game/images';prefix='SG-17-final-20261022-'
def copy(src,name=None):
 p=b/src;q=out/(prefix+(name or src.replace('/','-')))
 if p.suffix=='.log':q.write_text('\n'.join(line.rstrip() for line in re.sub(r'\x1b\[[0-9;]*m','',p.read_text()).splitlines()).rstrip()+'\n')
 else:shutil.copyfile(p,q)
for case in ['controls-v3','outcomes-v4','restart-v3','lesson-final','lesson-import','release-smoke-final']:
 d=json.loads((b/case/'result.json').read_text());assert d['exit']==0 and d['errors']==0,(case,d)
 for name in ['result.json','result.log','source-provenance.json','video-metadata.json','before-sha256.json','restart-check.json','outcomes.json','kite-failed-result-layout.json','kite-ordinary-result-layout.json','kite-assisted-night-result-layout.json','kite-precise-result-layout.json']:
  if (b/case/name).exists():copy(case+'/'+name)
 if case in ['controls-v3','outcomes-v4']:copy(case+'/play.mp4',case+'.mp4')
 for p in (b/case/'captures').glob('*.png'):copy(str(p.relative_to(b)))
for case in ['controls-v3','outcomes-v4','lesson-final']:
 for p in sorted(b.glob(case+'-review-*.jpg')):copy(p.name)
for name in ['ci-f6-runtime.log','ci-f6-full.log','ci-f6-verification.json','reference-images.json','feather-official-animation.gif','feather-official-first-frame.png','flock-official.jpg','alba-official.png','previous-tutorial-sha256.json','updated-tutorial-sources.json','twelve-game-comparison-1.jpg','twelve-game-comparison-2.jpg','twelve-game-source-sha256.json']:
 copy(name)
for case in ['ui-before-realistic','ui-final-realistic']:
 for name in ['result.json','result.log']:copy(case+'/'+name)
copy('ui-regression.json')
assert json.loads((b/'ui-before-realistic/result.json').read_text())['exit']==1
assert json.loads((b/'ui-final-realistic/result.json').read_text())['exit']==0
checks=json.loads((b/'checks-layout/results.json').read_text());assert len(checks)==6 and all(q['exit']==0 and q['errors']==0 and q['error'] is None and q['seconds']<90 for q in checks)
for p in (b/'checks-layout').glob('*'):
 if p.is_file():copy(str(p.relative_to(b)))
for name in ['build.json','import.log','export.log']:copy('release-final/'+name)
copy('release-smoke-final/profile/art-smoke-game-002.png','actual-release-kite-initial.png')
refs=['game/main.gd','game/minigames/session.gd','game/tests/test_minigames.gd','game/tests/test_pixel_ui_shell.gd','game/tests/native_kite_main_flow_review.gd','game/tests/native_kite_outcomes_review.gd','game/tests/native_kite_outcomes_review.tscn','game/tests/native_kite_restart_review.gd','game/tests/native_kite_restart_review.tscn',*[f'assets/ui/tutorials/game-002-step-{i:02}.png' for i in [1,2,3]]]
stage=r/'work/tutorial-current-20261020/validation-project'
for rel in ['game/main.gd','game/minigames/session.gd','game/tests/test_minigames.gd','game/tests/test_pixel_ui_shell.gd',*[f'assets/ui/tutorials/game-002-step-{i:02}.png' for i in [1,2,3]]]:assert (r/rel).read_bytes()==(stage/rel).read_bytes(),rel
build=json.loads((b/'release-final/build.json').read_text())
for rel in ['game/main.gd','game/minigames/session.gd',*[f'assets/ui/tutorials/game-002-step-{i:02}.png' for i in [1,2,3]]]:assert build['source_sha256'][rel]==hashlib.sha256((r/rel).read_bytes()).hexdigest(),rel
assert not any(rel.startswith(('tools/','work/','game/tests/')) for rel in build['source_sha256'])
log=(b/'release-smoke-final/result.log').read_text();assert len(re.findall(r'ART SMOKE DRAW: game-\d{3} renderer=',log))==12
history={'scope':'Earlier native passes cover their stated routes, not final UI/source claims.', 'outcomes_v1':'Three actual misses + retry + edge/centers passed, but individual eligibility not yet visible.', 'outcomes_v2':'Eligibility and per-attempt zero rows passed. Viewed result pages exposed modal/photo-grid resizing; visually rejected as final layout.', 'outcomes_v3':'Final layout guard passes; did not include final assisted night/reduced replay.', 'outcomes_v4':'Final genuine miss/retry/edge ordinary and assisted night/reduced ordinary-only replay; no thresholds weakened.', 'controls_v1_v2':'Pass their first tutorial/precise/album/private routes; before final stable result layout. V3 is final.', 'lesson_assets':'Final3 PNGs copied from v3 actual action,gust,natural500result AFTER the controls film. Separate new lesson process/import validates refreshed images; do not describe the controls film as showing the new lesson assets.', 'reference_failures':'Initial Pilotwings Nintendo URL, old Panic Playdate URL, incorrectly guessed Tiny&Big and Humanity store URLs were inaccessible and not counted. Six successful primary teams are documented separately.', 'first_headless_counterexample':'The short-label fixture had no qualification row and did not reproduce the observed layout jump (exit0). It is inconclusive, not a failed-before proof. Realistic long row/qualification data and a sixth partial-page item retain old assertions and exercise the real minimum-content difference.', 'audio':'All native engines used Dummy. Silent video, not listening/hardware performance/human play.'}
(out/(prefix+'attempt-history.json')).write_text(json.dumps(history,indent=2)+'\n')
record={'starting_commit':'f6b48d064addd1715dde835bd51ac2c309d0a71b','scope':'SG17 game002 complete ticket acceptance; not ART20/21 all-game art, human play, hearing or Windows acceptance.','core_checks':checks,'additional_layout_regression':json.loads((b/'ui-regression.json').read_text()),'final_native':{case:json.loads((b/case/'result.json').read_text()) for case in ['controls-v3','outcomes-v4','restart-v3','lesson-final']},'native_captures_viewed':{'controls_and_restart':18,'outcomes':18,'new_lesson':6},'final_movies':{case:json.loads((b/case/'video-metadata.json').read_text()) for case in ['controls-v3','outcomes-v4']},'movie_review_scope':'Full files decoded; all42 native still captures viewed via contacts plus critical full-size result pages; no continuous watching claim. Controls fixed60 simulation for original retry contract, outcome actual engine clock, external15FPS silent wall captures. No new quarter-speed run; prior approved quarter evidence remains historical.','current_runtime_source_equality':'Post-run equality to clean validation project and export source map, not retroactive launch hashes. Diagnostic sources retain their recorded copy hashes.','source_sha256':{rel:hashlib.sha256((r/rel).read_bytes()).hexdigest() for rel in refs},'release':{'binary':build['binary'],'source_base':build['source_commit'],'provenance':'Built from tracked working-tree runtime bytes, including uncommitted SG17 changes; source_sha256 map verified. Not a clean f6 release claim.','steps':build['steps'],'smoke':json.loads((b/'release-smoke-final/result.json').read_text()),'real_main_initial_renderers':12,'excluded':'game/tests,tools,work and rejected garments','scope':'Real Linux embedded-PCK executable own Main/resource startup and initial12renderer draws; not packaged full Kite input flow.'},'baseline_ci':json.loads((b/'ci-f6-verification.json').read_text())}
(out/(prefix+'verification.json')).write_text(json.dumps(record,indent=2)+'\n')
with zipfile.ZipFile(out/(prefix+'sources-and-diagnostics.zip'),'w',zipfile.ZIP_DEFLATED) as z:
 for rel in refs:z.write(r/rel,'current-source/'+rel)
 for p in b.rglob('*.log'):
  if 'release-final/release' not in str(p):z.write(p,'raw-logs/'+str(p.relative_to(b)))
 for rel in ['work/tutorial-current-20261020/private_main.gd','work/tutorial-current-20261020/private_main.tscn']:z.write(r/rel,'diagnostic-main/'+Path(rel).name)
 for p in b.iterdir():
  if p.is_file() and p.suffix in ['.py','.json']:z.write(p,'drivers/'+p.name)
 for case in ['controls-v1','controls-v2','controls-v3','outcomes-v1','outcomes-v2','outcomes-v3','outcomes-v4','restart-v3','lesson-final','ui-before','ui-before-realistic','ui-final-realistic']:
  for p in (b/case).iterdir():
   if p.is_file() and p.suffix in ['.gd','.tscn','.json','.log']:z.write(p,'cases/'+case+'/'+p.name)
 for name in ['009-kite-ordinary-page-1.png','010-kite-ordinary-page-2.png']:z.write(b/'outcomes-v2/captures'/name,'rejected-layout/'+name)
 for n in [1,2,3]:
  rel=f'assets/ui/tutorials/game-002-step-{n:02}.png';old=subprocess.check_output(['git','show','f6b48d0:'+rel]);assert hashlib.sha256(old).hexdigest()==json.loads((b/'previous-tutorial-sha256.json').read_text())[rel];z.writestr('previous-lessons/'+Path(rel).name,old)
files=sorted(p for p in out.glob(prefix+'*') if p.name!=prefix+'manifest.json');(out/(prefix+'manifest.json')).write_text(json.dumps({'scope':'SG17 final bounded native evidence; manifest excludes itself.','files':[{'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]},indent=2)+'\n')
print('Packaged',len(files),'files',sum(p.stat().st_size for p in files),'bytes')
