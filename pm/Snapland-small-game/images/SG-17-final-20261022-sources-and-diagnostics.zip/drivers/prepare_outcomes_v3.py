from pathlib import Path
import re,hashlib,json,shutil,subprocess
r=Path.cwd();b=r/'work/kite-final-20261022';stage=r/'work/tutorial-current-20261020/validation-project'
# Current production source in reusable clean tracked-only import; no root editor scan.
for base in ['game','design','assets']:
 for relative in subprocess.check_output(['git','ls-files',base],text=True).splitlines():
  p=r/relative
  if p.suffix not in ['.gd','.tscn','.json']:continue
  q=stage/relative;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
for case,entry in [('outcomes-v3','native_kite_outcomes_review')]:
 out=b/case;out.mkdir(exist_ok=False);mapping={};proof={}
 def clone(name):
  if name in mapping:return mapping[name]
  p=r/'game/tests'/name;s=p.read_text();q=out/name;local='res://'+str(q.relative_to(r));mapping[name]=local
  for dep in sorted(set(re.findall(r'res://game/tests/([^"\']+\.gd)',s))):s=s.replace('res://game/tests/'+dep,clone(dep))
  s=s.replace('res://game/main.tscn','res://work/tutorial-current-20261020/private_main.tscn')
  q.write_text(s);proof[str(p.relative_to(r))]={'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'copy_sha256':hashlib.sha256(q.read_bytes()).hexdigest()}
  return local
 script=clone(entry+'.gd');(out/'entry.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="'+script+'" id="1"]\n[node name="PuzzleReview" type="Node"]\nscript=ExtResource("1")\n')
 (out/'source-provenance.json').write_text(json.dumps({'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'diagnostic_changes':'dependency paths and private Main screenshot observer only; returning-player tutorial fixture and station relocation; no gameplay thresholds or clocks changed','sources':proof},indent=2)+'\n')
 shutil.copytree(out,stage/out.relative_to(r))
 # New native script is also available at its normal resource location.
for p in (r/'game/tests').glob('native_kite_outcomes_review.*'):shutil.copy2(p,stage/p.relative_to(r))
