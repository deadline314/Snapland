from pathlib import Path
import json,time,os,hashlib,shutil
from tools.godot_entrypoints import run_validated_godot
from tools.run_game_tests import result_error
r=Path.cwd();b=r/'work/kite-final-20261022';stage=r/'work/tutorial-current-20261020/validation-project';target=stage/'game/main.gd';current=(r/'game/main.gd').read_bytes();s=current.decode();start=s.index('\tif pager.name=="ResultScorePages":');end=s.index('\n\tfor child in view.get_children():',start);old=s[:start]+s[end:];start=old.index('func _render_score_row');end=old.index('\nfunc ',start+1);old=old[:start]+old[start:end].replace('\tlabel.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART\n','').replace('\tlabel.size_flags_horizontal=Control.SIZE_EXPAND_FILL\n','')+old[end:];assert old!=s
shutil.copyfile(r/'game/tests/test_pixel_ui_shell.gd',stage/'game/tests/test_pixel_ui_shell.gd')
records=[]
try:
 for case,source in [('ui-before',old.encode()),('ui-final',current)]:
  out=b/case;out.mkdir();target.write_bytes(source);(out/'main-source.gd.txt').write_bytes(source);t=time.monotonic();p=run_validated_godot(stage,[str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'),'--headless','--path',str(stage),'--audio-driver','Dummy','--rendering-method','gl_compatibility','res://game/tests/test_pixel_ui_shell.tscn'],dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'progress.json')),90);log=p.stdout+p.stderr;(out/'result.log').write_text(log);data=dict(exit=p.returncode,errors=log.count('ERROR:'),seconds=round(time.monotonic()-t,2),main_sha256=hashlib.sha256(source).hexdigest(),result_error=result_error('pixel UI shell tests',p));(out/'result.json').write_text(json.dumps(data,indent=2)+'\n');records.append(dict(case=case,**data));print(records[-1],flush=True)
  if case=='ui-before':assert p.returncode==1 and 'result pagination keeps every photo position and size stable' in log
  else:assert data['result_error'] is None and data['errors']==0 and p.returncode==0
finally:target.write_bytes(current)
(b/'ui-regression.json').write_text(json.dumps(records,indent=2)+'\n')
