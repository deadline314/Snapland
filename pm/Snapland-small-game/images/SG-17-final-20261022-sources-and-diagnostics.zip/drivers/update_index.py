from pathlib import Path
import re,collections
p=Path('pm/open_tickets.md');s=p.read_text();tickets={}
for f in Path('pm').glob('Snapland-*/*.md'):
 m=re.match(r'\[((?:ART|MAIN|MIC|SG|ST)-\d+)\]',f.name)
 if not m:continue
 status=re.search(r'^> 狀態：(.+)$',f.read_text(),re.M);assert status,f
 tickets[m[1]]=(re.split('[（(]',status[1])[0].strip(),f)
opened={k:v for k,v in tickets.items() if v[0]!='完成'};done=len(tickets)-len(opened)
s=re.sub(r'2026-10-(?:20|21|22)（Asia/Taipei）。從 .*?\n\n',f'2026-10-22（Asia/Taipei）。從 {len(tickets)} 張實際票檔重新盤點：**{done} 張完成、{len(opened)} 張進行中，共 {len(opened)} 張未結案**。本輪逐票重驗與交付；實際範圍見各票。\n\n',s,count=1,flags=re.S)
lines=[]
for line in s.splitlines():
 m=re.match(r'\| \[((?:ART|MAIN|MIC|SG|ST)-\d+) ',line)
 if m and m[1] not in opened:continue
 for cat in ['ART','MAIN','MIC','SG','ST']:
  if re.match(r'\| '+cat+r' \| \d+ \|$',line):line=f'| {cat} | {sum(k.startswith(cat+"-") for k in opened)} |'
 lines.append(line)
s='\n'.join(lines)+'\n'
listed=set(re.findall(r'\| \[((?:ART|MAIN|MIC|SG|ST)-\d+) ',s))
for k,(status,f) in opened.items():
 if k in listed:continue
 summary='；'.join(re.findall(r'^- \[ \] (.+)',f.read_text(),re.M))
 if len(summary)>190:summary=summary[:190]+'…（完整條件見本票）'
 title=f.stem.split(']',1)[1]
 row=f'| [{k} {title}](<{f.relative_to("pm")}>) | {status} | {summary} |\n\n'
 cat=k.split('-')[0];order=['ART','MAIN','MIC','SG','ST'];idx=order.index(cat)
 if idx+1<len(order):s=s.replace('## '+order[idx+1]+'\n',row+'## '+order[idx+1]+'\n')
 else:s+=row
s=re.sub(r'本批程式基準 `[^`]+`，票況依本輪實際狀態更新。','本輪續作基準 `244536b`，票況依各票最新交付更新。',s)
p.write_text(s)
assert set(re.findall(r'\| \[((?:ART|MAIN|MIC|SG|ST)-\d+) ',s))==set(opened)
print('tickets',len(tickets),'done',done,'open',len(opened))
