from pathlib import Path
from PIL import Image,ImageDraw
import subprocess,json,hashlib
b=Path('work/kite-final-20261022')
for case in ['controls-v3','outcomes-v4']:
 p=b/case/'play.mp4';subprocess.run(['ffmpeg','-v','error','-threads','1','-i',str(p),'-f','null','-'],check=True,timeout=90);j=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_entries','stream=codec_name,width,height,nb_read_frames,r_frame_rate,duration','-of','json',str(p)],text=True,timeout=60));(b/case/'video-metadata.json').write_text(json.dumps(j,indent=2)+'\n');print(case,j['streams'],flush=True)
for case in ['controls-v3','outcomes-v4','lesson-final']:
 files=sorted((b/case/'captures').glob('*.png'))
 for page in range((len(files)+5)//6):
  out=Image.new('RGB',(1920,764),'#123440');d=ImageDraw.Draw(out)
  for i,p in enumerate(files[page*6:page*6+6]):
   im=Image.open(p).convert('RGB');im.thumbnail((640,350));x=i%3*640;y=i//3*382;out.paste(im,(x,y+25));d.text((x+5,y+5),p.name,fill='white')
  out.save(b/f'{case}-review-{page+1}.jpg')
records=[]
for page in range(2):
 out=Image.new('RGB',(1920,764),'#123440');d=ImageDraw.Draw(out)
 for i in range(6):
  number=page*6+i+1;p=Path('assets/ui/tutorials/game-%03d-step-01.png'%number);im=Image.open(p).convert('RGB');im.thumbnail((640,350));x=i%3*640;y=i//3*382;out.paste(im,(x,y+25));d.text((x+5,y+5),'game-%03d / current lesson gameplay source'%number,fill='white');records.append(dict(game=number,path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),scope='Current approved lesson gameplay source; historical capture except new game002. Not twelve new playthroughs.'))
 out.save(b/f'twelve-game-comparison-{page+1}.jpg')
(b/'twelve-game-source-sha256.json').write_text(json.dumps(records,indent=2)+'\n')
