from pathlib import Path
import os,time,json
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();b=r/'work/kite-final-20261022';stage=r/'work/tutorial-current-20261020/validation-project'
for case,number in [('lesson-final',2)]:
 out=b/case;assert not (out/'result.json').exists() and not (out/'progress.json').exists()
 cmd=[str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'),'--path',str(stage),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--resolution','1280x720','--log-file',str(out/'engine.log'),'res://'+str((out/'entry.tscn').relative_to(r)),'--fixed-fps','60','--','--tutorial-first='+str(number),'--tutorial-last='+str(number)]
 start=time.monotonic();p=run_validated_godot(stage,cmd,dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'progress.json')),90);s=p.stdout+p.stderr;(out/'result.log').write_text(s);d=dict(case=case,exit=p.returncode,errors=s.count('ERROR:'),seconds=round(time.monotonic()-start,2),passes=[l for l in s.splitlines() if l.startswith('PASS:')]);(out/'result.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(d,s[-600:],flush=True)
 assert p.returncode==0 and d['errors']==0 and d['passes']
