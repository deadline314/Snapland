from pathlib import Path
import subprocess,shutil,ast
r=Path.cwd();b=r/'work/kite-final-20261022';stage=r/'work/tutorial-current-20261020/validation-project'
for base in ['game','design','assets']:
 for rel in subprocess.check_output(['git','ls-files',base],text=True).splitlines():
  p=r/rel
  if p.suffix in ['.gd','.tscn','.json']:
   q=stage/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
s=(r/'work/sign-final-20261021/checks.py').read_text().replace("r/'work/sign-final-20261021/checks-final'","b/'checks-final'").replace("b=r/'work/tutorial-current-20261020';stage=b/'validation-project'","b=r/'work/kite-final-20261022';stage=r/'work/tutorial-current-20261020/validation-project'").replace('sign balance model tests','kite flight model tests').replace('sign balance view tests','kite flight view tests');(b/'checks.py').write_text(s)
