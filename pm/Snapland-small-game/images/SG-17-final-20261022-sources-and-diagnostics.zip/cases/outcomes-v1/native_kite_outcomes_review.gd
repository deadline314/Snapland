extends "res://work/kite-final-20261022/outcomes-v1/native_kite_main_flow_review.gd"
## Genuine missed-ring failure, actual retry, and a pointer-flown edge/center route.
var _outcome: Dictionary = {}
var _outcome_state: Dictionary = {}

func _run() -> void:
	if not OS.get_environment("SNAPLAND_SAVE_PATH").is_absolute_path() or DisplayServer.get_name()=="headless":_fail("Kite outcomes require GPU and an isolated absolute profile");return
	_wall_started_msec=Time.get_ticks_msec();_guard_active=true
	progress=get_tree().root.get_node("Progress");progress.reset_progress();progress.intro_seen=true
	progress.settings.assist=false;progress.settings.reduced_motion=false
	main=_instantiate_main();get_tree().root.add_child(main);await _frames(5)
	if not await _move_to_kite_station():return
	_key(KEY_E)
	if not await _wait_until(func():return main.modal_kind=="game_info","open actual kite station"):return
	if not await _activate_main_button("開始遊玩","start actual kite failure route"):return
	if not await _wait_until(func():return is_instance_valid(main.session),"kite session begins"):return
	var path:=OS.get_environment("SNAPLAND_SAVE_PATH")
	if not progress.save_progress():_fail("Save nonempty Kite baseline");return
	var baseline:=FileAccess.get_file_as_string(path)
	if baseline.is_empty():_fail("Empty full-save baseline");return
	var live:Control=main.session;live.finished.connect(_latch_outcome.bind(live),CONNECT_ONE_SHOT)
	_send_key(KEY_DOWN,true)
	if not await _wait_outcome(45000):return
	_send_key(KEY_DOWN,false)
	if bool(_outcome.success) or int(_outcome.score)!=0 or int(_outcome_state.misses)!=3 or int(_outcome_state.rescues_used)!=2 or FileAccess.get_file_as_string(path)!=baseline:
		_fail("Three actual missed rings did not fail with unchanged full save: "+str(_outcome_state));return
	if not await _review_result_pages("kite-failed"):return
	var failed:Dictionary={"result":_outcome.duplicate(true),"model":_outcome_state.duplicate(true),"complete_save_unchanged":true}
	var button:=_find(main.overlay,"再玩一次") as Button;var reset:Dictionary={}
	if button==null:_fail("Missing Kite result retry");return
	button.pressed.connect(func():
		var active:Control=main.session
		if is_instance_valid(active):reset.merge({"score":active.score,"elapsed":active.elapsed,"ring":active.kite_model.ring_index,"centers":active.kite_model.center_hits,"edges":active.kite_model.edge_hits,"misses":active.kite_model.misses,"rescues":active.kite_model.rescues_used,"events":active.score_events.size()})
	)
	if not await _native_click_button(button,"retry actual missed-ring result"):return
	if reset!={"score":0,"elapsed":0.0,"ring":0,"centers":0,"edges":0,"misses":0,"rescues":0,"events":0}:_fail("Kite retry retained state: "+str(reset));return
	_outcome.clear();_outcome_state.clear();live=main.session
	live.finished.connect(_latch_outcome.bind(live),CONNECT_ONE_SHOT)
	if not main._capture("kite-real-result-retry.png"):_fail("Capture Kite retry");return
	if not await _drive_edge_route(live):return
	if not await _wait_outcome(5000):return
	if not bool(_outcome.success) or bool(_outcome.devil) or int(_outcome.score)!=460 or int(_outcome_state.edge_hits)!=1 or int(_outcome_state.center_hits)!=4 or int(_outcome_state.rescues_used)!=0 or not progress.photos.has("photo-welcome-game-2") or progress.photos.has("photo-welcome-devil-2"):
		_fail("One edge plus four centers did not earn460 ordinary only: "+str(_outcome_state));return
	if not await _review_result_pages("kite-ordinary"):return
	FileAccess.open(path.get_base_dir().path_join("outcomes.json"),FileAccess.WRITE).store_string(JSON.stringify({"failed":failed,"retry_at_input":reset,"ordinary":{"result":_outcome,"model":_outcome_state},"result_pages_actual_pointer":true},"  "))
	if not await _activate_main_button("返回遊園","return from actual ordinary Kite result"):return
	if not await _wait_until(func():return main.session==null and main.modal_kind=="","return to park"):return
	print("PASS: native Kite three real missed rings fail safely, actual result retry resets state, pointer edge+four centers earn460 ordinary only; all result pages clicked and park return")
	_guard_active=false;await main._quit_game()

func _latch_outcome(result:Dictionary, live:Control) -> void:
	_outcome=result.duplicate(true);_outcome_state=live.kite_model.snapshot().duplicate(true)

func _wait_outcome(limit:int) -> bool:
	var deadline:=Time.get_ticks_msec()+limit
	while _outcome.is_empty() and Time.get_ticks_msec()<deadline:
		if _failure_latched:return false
		await get_tree().physics_frame
	if _outcome.is_empty():_fail("Kite route did not naturally finish before its original finite guard");return false
	await _frames(3)
	return true

func _drive_edge_route(live:Control) -> bool:
	var deadline:=Time.get_ticks_msec()+45000
	var last_ring:=-1
	while _outcome.is_empty() and Time.get_ticks_msec()<deadline:
		if not is_instance_valid(live):_fail("Kite freed before natural finish");return false
		var state:Dictionary=live.kite_model.snapshot();var ring:=int(state.nextRing)
		if ring>=5:break
		var target:float=live.kite_model.RING_HEIGHT[ring]+(27.0 if ring==0 else 0.0)
		var aim:=clampf((float(state.height)-target)*0.06-float(state.vy)*0.012,-1.0,1.0)
		var point:Vector2=get_viewport().get_final_transform()*(live.presentation.get_global_transform_with_canvas()*Vector2(640,390-aim*235))
		var motion:=InputEventMouseMotion.new();motion.position=point;motion.global_position=point;motion.window_id=get_window().get_window_id()
		Input.parse_input_event(motion);Input.flush_buffered_events()
		if ring!=last_ring:
			if not main._capture("kite-edge-route-ring-%d.png"%(ring+1)):_fail("Capture actual Kite ring");return false
			last_ring=ring
		await get_tree().physics_frame
	if _outcome.is_empty():_fail("Pointer edge route exceeded45-second guard");return false
	return true

func _review_result_pages(prefix:String) -> bool:
	var pager:=main.overlay.find_child("ResultScorePages",true,false) as VBoxContainer
	if pager==null or not pager.has_meta("page_entries"):await _fail("Missing live score pager");return false
	var entries:Array=pager.get_meta("page_entries");var seen:Dictionary={}
	var next:=main.overlay.find_child("ResultScorePagesNext",true,false) as Button
	for page in int(pager.get_meta("page_count",0)):
		await _frames(2)
		var content:=pager.find_child("PageContent",true,false)
		for node in content.get_children():
			if not node is Label or not node.visible:continue
			var label:=node as Label
			if not get_viewport().get_visible_rect().encloses(label.get_global_rect()):await _fail("Actual result row is clipped");return false
			var index:=int(str(label.name).trim_prefix("ResultScoreRow"))
			if index>=entries.size() or not label.text.contains(str(entries[index].label)):await _fail("Actual result row text differs");return false
			seen[index]=label.text
		await RenderingServer.frame_post_draw
		if not main._capture("%s-page-%d.png"%[prefix,page+1]):await _fail("Capture actual result page");return false
		if page+1<int(pager.get_meta("page_count")):
			if not await _native_click_button(next,"read next actual Kite score page"):return false
	if seen.size()!=entries.size():await _fail("Not all actual Kite score rows were shown");return false
	return true
