from pathlib import Path
from PIL import Image,ImageDraw
import json,hashlib,subprocess,sys
r=Path.cwd();b=r/'work/puzzle-batch-20261020';kind=sys.argv[1];cases=sys.argv[2:]
for case in cases:
 out=b/case
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(out/'play.avi'),'-c:v','libx264','-preset','fast','-crf','25','-pix_fmt','yuv420p','-an',str(out/'play.mp4')],check=True)
 subprocess.run(['ffmpeg','-v','error','-i',str(out/'play.mp4'),'-f','null','-'],check=True)
 meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=width,height,r_frame_rate,nb_frames:format=duration','-of','json',str(out/'play.mp4')],text=True));(out/'video-metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
paths=[p for case in cases for p in sorted((b/case/'captures').glob('*.png'))]
for off in range(0,len(paths),12):
 part=paths[off:off+12];sheet=Image.new('RGB',(1280,230*((len(part)+2)//3)),'#e9e4d9');d=ImageDraw.Draw(sheet)
 for i,p in enumerate(part):
  im=Image.open(p).convert('RGB');assert im.size==(1280,720);im.thumbnail((420,210));x=i%3*426;y=i//3*230;sheet.paste(im,(x,y+18));d.text((x+3,y+3),p.parent.parent.name+' '+p.stem[:27],fill='black')
 sheet.save(b/(kind+'-overview-'+str(off//12)+'.jpg'))
print('captures',len(paths),'sheets',(len(paths)+11)//12)
