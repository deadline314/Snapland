from pathlib import Path
import os,json,time,subprocess
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();b=r/'work/sign-final-20261021';stage=r/'work/tutorial-current-20261020/validation-project';out=b/'outcomes-v3';assert not (out/'result.json').exists()
rec=subprocess.Popen(['ffmpeg','-n','-v','error','-f','x11grab','-video_size','1280x720','-framerate','15','-i',os.environ['DISPLAY'],'-t','250','-c:v','libx264','-threads','1','-preset','ultrafast','-crf','23','-pix_fmt','yuv420p',str(out/'play.mp4')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
start=time.monotonic();p=None
try:
 p=run_validated_godot(stage,[str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'),'--path',str(stage),'--audio-driver','Dummy','--rendering-method','gl_compatibility','--resolution','1280x720','--position','0,0','--log-file',str(out/'engine.log'),'res://'+str((out/'entry.tscn').relative_to(r))],dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'progress.json')),240)
except subprocess.TimeoutExpired as e:
 (out/'timeout.log').write_text((e.stdout or '')+(e.stderr or ''));raise
finally:
 _,err=rec.communicate('q\n',timeout=15);(out/'record.log').write_text(err)
log=p.stdout+p.stderr;(out/'result.log').write_text(log);d={'exit':p.returncode,'errors':log.count('ERROR:'),'seconds':round(time.monotonic()-start,2),'passes':[x for x in log.splitlines() if x.startswith('PASS:')],'scope':'Actual realtime engine clock, uncapped rendering. External silent15FPS full-window recording; original35-second per-route and300-second fixture/global240-second process limits preserved. Not hardware FPS.'};(out/'result.json').write_text(json.dumps(d,indent=2)+'\n');print(d,log[-700:],flush=True);assert d['exit']==0 and d['errors']==0 and d['passes']
