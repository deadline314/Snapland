from pathlib import Path
import json,hashlib,shutil,zipfile,re
r=Path.cwd();b=r/'work/sign-final-20261021';dest=r/'pm/Snapland-small-game/images';prefix='SG-23-final-20261021-';files=[]
def cp(p,label):
 q=dest/(prefix+label);assert not q.exists(),q
 if p.suffix=='.log':
  s=re.sub(r'\x1b\[[0-9;]*m','',p.read_text());q.write_text('\n'.join(x.rstrip() for x in s.splitlines()).rstrip()+'\n')
 else:shutil.copyfile(p,q)
 files.append({'file':q.name,'source':str(p.relative_to(r)),'bytes':q.stat().st_size,'sha256':hashlib.sha256(q.read_bytes()).hexdigest()})
for case in ['outcomes-final','controls-final','phases-final','lesson-final']:
 d=json.loads((b/case/'result.json').read_text());assert d['exit']==0 and d['errors']==0 and d['passes']
 for p in sorted((b/case/'captures').glob('*.png')):cp(p,case+'-'+p.name)
 for name in ['result.json','result.log','source-provenance.json','natural-results.json','outcomes.json','phase-audit.json','video-metadata.json','play.mp4']:
  p=b/case/name
  if p.is_file():cp(p,case+'-'+name)
for folder in ['checks-final','hud-check','water-check','import-final']:
 for p in sorted((b/folder).glob('*')):
  if p.is_file() and p.suffix in ['.json','.log']:cp(p,folder+'-'+p.name)
checks=json.loads((b/'checks-final/results.json').read_text());assert len(checks)==6 and all(x['error'] is None for x in checks)
for case in ['outcomes','outcomes-v2']:
 for name in ['result.json','result.log','source-provenance.json']:cp(b/case/name,'rejected-'+case+'-'+name)
for folder in ['calibration','water-calibration']:
 for p in sorted((b/folder).glob('*')):
  if p.is_file() and p.suffix in ['.json','.log','.png']:cp(p,folder+'-'+p.name)
for n in ['research.md','reference-provenance.json','final-media.json','ci-b91-verification.json','ci-b91-full-suite.log','ci-b91-game-runtime.log','tutorial-refresh/source.json']:
 cp(b/n,n.replace('/','-'))
for p in sorted(b.glob('reference-*.jpg')):cp(p,p.name)
for n in ['outcomes-final-overview-0.jpg','controls-final-overview-0.jpg','phases-final-overview-0.jpg','lesson-final-overview.jpg']:cp(b/n,n)
for n in ['build.json','import.log','export.log']:cp(b/'release-water-final'/n,'release-'+n)
for n in ['result.json','result.log']:cp(b/'release-water-smoke-final'/n,'release-smoke-'+n)
release=json.loads((b/'release-water-final/build.json').read_text());assert all(x['exit']==0 and x['errors']==0 for x in release['steps']);assert json.loads((b/'release-water-smoke-final/result.json').read_text())['completion']
components=['game/minigames/session.gd','game/minigames/sign_balance_model.gd','game/minigames/sign_balance_view.gd','game/ui/minigame_hud.gd','game/tests/native_sign_balance_review.gd','game/tests/native_sign_outcomes_review.gd','game/tests/test_minigames.gd','game/tests/test_sign_balance_view.gd',*[f'assets/ui/tutorials/game-008-step-{i:02d}.png' for i in range(1,4)]]
hashes={n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in components}
for n in components:
 if n.startswith(('game/minigames/','game/ui/','assets/')):assert release['source_sha256'][n]==hashes[n],n
(b/'source-sha256-final.json').write_text(json.dumps(hashes,indent=2)+'\n');cp(b/'source-sha256-final.json','source-sha256-final.json')
archive=b/'review-sources.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for case in ['outcomes','outcomes-v2','outcomes-v3','outcomes-final','controls-final','phases-final','lesson-final']:
  for p in (b/case).glob('*'):
   if p.suffix in ['.gd','.tscn']:z.write(p,str(p.relative_to(b)))
 for p in b.glob('*.py'):z.write(p,'runner/'+p.name)
 for p in b.glob('*calibrate.gd'):z.write(p,'runner/'+p.name)
 for p in b.glob('reference-*-source.json'):z.write(p,'references/'+p.name)
 for p in (b/'tutorial-refresh').glob('*.png'):z.write(p,'previous-tutorial/'+p.name)
 for n in ['work/tutorial-current-20261020/private_main.gd','work/tutorial-current-20261020/private_main.tscn',*components]:z.write(r/n,'repository/'+n)
cp(archive,'review-sources.zip')
manifest={'ticket':'SG-23','date':'2026-10-21 Asia/Taipei','runtime':'Godot4.7.2 Compatibility llvmpipe1280x720 Dummy audio','scope':'Native actual station/input/HUD paths, full-world menus and actual3D mechanism; station relocation, returning-player and time/reduced settings are fixtures. Separate new-player tutorial lifecycle. No model/score/clock/award writes.','accepted_changes':['Right-side short feedback retains its anchor through every layout/refresh; all55 model angles protect board/title/weight/card clearance.','Actual completed unsuccessful stages retain zero-point rows; impacts named separately.','Four water material colors calibrated from actual GPU output; whole-scene tonemap/exposure candidates rejected.','Three current lesson images are byte-identical actual native final formal captures.'],'outcomes':json.loads((b/'outcomes-final/outcomes.json').read_text()),'phase_audit':json.loads((b/'phases-final/phase-audit.json').read_text()),'seven_formal_checks':checks+[json.loads((b/'hud-check/result.json').read_text())],'post_water_view_check':json.loads((b/'water-check/result.json').read_text()),'tutorial_lifecycle':json.loads((b/'lesson-final/result.json').read_text()),'final_media':json.loads((b/'final-media.json').read_text()),'release_build':{'source_commit':release['source_commit'],'steps':release['steps'],'binary':release['binary'],'selected_runtime_source_hashes_match_current':True,'scope':'Source SHA map authoritative: export base precedes this uncommitted SG23 change. Linux embedded PCK release boots its own Main; actual twelve-scene smoke separate from native fixture routes. Not Windows or hardware FPS.'},'release_smoke':json.loads((b/'release-water-smoke-final/result.json').read_text()),'prior_ci':json.loads((b/'ci-b91-verification.json').read_text()),'attempts':['Original native guard rejected upper feedback intersection with extreme tilted board AABB,18.16s. Original local test allowed board-corner overlap at extreme angles; new test is stricter across55angles.','Fixed20FPS internal recording run hit the original35-second route deadline before its result latch;44.15s exit1 with an additional resource-at-exit error. Its later naturally observed zero result is partial evidence only, not a completed route.','Final runs use actual realtime clock and separate15FPS desktop recording. Original35s per-route,300s fixture and240s external process caps retained.','Pre-water control/outcome/lesson/release successes are superseded for final appearance by explicitly named final cases; preserved privately.','Four whole-scene tonemap/energy candidates retain clipping or unwanted tint; no whole-scene lighting change adopted. Water-only four-phase candidates followed by eight actual Main phase/reduced runs accepted.'],'evidence_limits':'Three silent external15FPS movies fully decoded.27 final gameplay/phase stills and6 refreshed-lesson stills reviewed in contact sheets. Not continuous movie watching, a new quarter-speed run, human play, listening or entire ART21 acceptance. Older quarter-speed evidence remains separately cited.','files':files}
(dest/(prefix+'verification.json')).write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print('SG23',len(files),'artifacts',sum(x['bytes'] for x in files),'bytes')
