from pathlib import Path
import subprocess,json
from PIL import Image,ImageDraw
b=Path('work/sign-final-20261021');records=[]
for case in ['outcomes-final','controls-final','phases-final']:
 out=b/case;result=json.loads((out/'result.json').read_text());assert result['exit']==0 and result['errors']==0
 subprocess.run(['ffmpeg','-v','error','-i',str(out/'play.mp4'),'-f','null','-'],check=True,timeout=90)
 info=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_entries','stream=width,height,r_frame_rate,nb_read_frames:format=duration','-of','json',str(out/'play.mp4')],text=True));(out/'video-metadata.json').write_text(json.dumps(info,indent=2)+'\n')
 paths=sorted((out/'captures').glob('*.png'))
 for off in range(0,len(paths),12):
  part=paths[off:off+12];sheet=Image.new('RGB',(1280,230*((len(part)+2)//3)),'#e9e4d9');d=ImageDraw.Draw(sheet)
  for i,p in enumerate(part):
   im=Image.open(p).convert('RGB');im.thumbnail((420,210));x=i%3*426;y=i//3*230;sheet.paste(im,(x,y+18));d.text((x+3,y+3),p.stem[:36],fill='black')
  sheet.save(b/f'{case}-overview-{off//12}.jpg')
 records.append({'case':case,'movie':info,'decoded_all_frames':True,'actual_stills':len(paths),'silent_external_window_recording':True})
(b/'final-media.json').write_text(json.dumps(records,indent=2)+'\n');print([(x['case'],x['movie']['format']['duration'],x['actual_stills']) for x in records])
