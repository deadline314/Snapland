from pathlib import Path
import os,time,json
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();stage=r/'work/tutorial-current-20261020/validation-project';out=r/'work/sign-final-20261021/import-final';out.mkdir(exist_ok=False);start=time.monotonic();p=run_validated_godot(stage,[str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'),'--headless','--path',str(stage),'--editor','--import','--quit'],dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'progress.json')),90);log=p.stdout+p.stderr;(out/'result.log').write_text(log);d={'exit':p.returncode,'errors':log.count('ERROR:'),'seconds':round(time.monotonic()-start,2)};(out/'result.json').write_text(json.dumps(d,indent=2)+'\n');print(d,log[-300:]);assert d['exit']==0 and d['errors']==0
