from pathlib import Path
import urllib.request,json,hashlib
from concurrent.futures import ThreadPoolExecutor
b=Path('work/sign-final-20261021');pairs=[('poly-bridge',1850160),('little-left',1629520),('dorfromantik',1455840)]
def fetch(pair):
 name,app=pair;url=f'https://store.steampowered.com/api/appdetails?appids={app}&l=english';raw=urllib.request.urlopen(url,timeout=25).read();p=json.loads(raw)[str(app)];assert p['success'];data=p['data'];shot=data['screenshots'][0]['path_full'];im=urllib.request.urlopen(shot,timeout=25).read();(b/f'reference-{name}.jpg').write_bytes(im);(b/f'reference-{name}-source.json').write_bytes(raw)
 return {'name':data['name'],'developer':data['developers'],'page':f'https://store.steampowered.com/app/{app}/','metadata_url':url,'image_url':shot,'file':f'reference-{name}.jpg','bytes':len(im),'sha256':hashlib.sha256(im).hexdigest(),'type':'Official product static screenshot, not continuous play or Snapland game asset'}
with ThreadPoolExecutor(max_workers=3) as pool:records=list(pool.map(fetch,pairs))
(b/'reference-provenance.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n');print([(x['name'],x['bytes']) for x in records])
