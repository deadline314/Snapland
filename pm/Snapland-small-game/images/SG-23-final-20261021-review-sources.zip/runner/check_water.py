from pathlib import Path
import os,json,time
from tools.godot_entrypoints import run_validated_godot
from tools.run_game_tests import result_error
r=Path.cwd();stage=r/'work/tutorial-current-20261020/validation-project';out=r/'work/sign-final-20261021/water-check';out.mkdir(exist_ok=False);t=time.monotonic();p=run_validated_godot(stage,[str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'),'--headless','--path',str(stage),'--script','res://game/tests/test_sign_balance_view.gd'],dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'progress.json')),90);log=p.stdout+p.stderr;(out/'result.log').write_text(log);err=result_error('sign balance view tests',p);d={'exit':p.returncode,'errors':log.count('ERROR:'),'seconds':round(time.monotonic()-t,2),'error':err};(out/'result.json').write_text(json.dumps(d,indent=2)+'\n');print(d);assert err is None
