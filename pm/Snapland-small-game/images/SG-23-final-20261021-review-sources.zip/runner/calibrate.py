from pathlib import Path
import os,json,time
from tools.godot_entrypoints import run_validated_godot
r=Path.cwd();stage=r/'work/tutorial-current-20261020/validation-project';out=r/'work/sign-final-20261021/calibration';p=run_validated_godot(stage,[str(r/'work/art18/engine-4.7.2/Godot_v4.7.2-stable_linux.x86_64'),'--path',str(stage),'--script','res://work/sign-final-20261021/calibrate.gd','--audio-driver','Dummy','--rendering-method','gl_compatibility'],dict(os.environ,SNAPLAND_SAVE_PATH=str(out/'progress.json')),60);log=p.stdout+p.stderr;(out/'result.log').write_text(log);(out/'result.json').write_text(json.dumps({'exit':p.returncode,'errors':log.count('ERROR:')}));print(log[-1000:]);assert p.returncode==0 and 'ERROR:' not in log
