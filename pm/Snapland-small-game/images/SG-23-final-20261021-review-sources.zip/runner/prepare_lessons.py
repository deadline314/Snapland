from pathlib import Path
import shutil,hashlib,json
r=Path.cwd();b=r/'work/sign-final-20261021';stage=r/'work/tutorial-current-20261020/validation-project'
for case in ['lesson']:
 out=b/case;out.mkdir(exist_ok=False)
 src=r/'game/tests/native_tutorial_lifecycle_review.gd';s=src.read_text().replace('res://game/tests/native_review.gd','res://'+str((out/'native_review.gd').relative_to(r))).replace('ProjectSettings.globalize_path("res://.review/main10-lifecycle-evidence")','OS.get_environment("SNAPLAND_SAVE_PATH").get_base_dir().path_join("captures")')
 s=s.replace('var path := folder.path_join(filename)','var path := folder.path_join(filename)\n\t_check(not FileAccess.file_exists(path), "evidence output must be exclusive")')
 (out/'lesson.gd').write_text(s)
 p=r/'game/tests/native_review.gd';(out/p.name).write_text(p.read_text().replace('res://game/main.tscn','res://work/tutorial-current-20261020/private_main.tscn'))
 (out/'entry.tscn').write_text('[gd_scene load_steps=2 format=3]\n[ext_resource type="Script" path="res://'+str((out/'lesson.gd').relative_to(r))+'" id="1"]\n[node name="PuzzleTutorialReview" type="Node"]\nscript=ExtResource("1")\n')
 (out/'source-provenance.json').write_text(json.dumps({'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'diagnostic_changes':'dependency paths, isolated screenshot output and reject overwrite; original 60-second per-game and 360-second global bounds and gameplay unchanged'},indent=2)+'\n')
 shutil.copytree(out,stage/out.relative_to(r))
