from pathlib import Path
import subprocess,sys
b=Path('work/sign-final-20261021')
for name in ['outcomes-final','controls-final','phases-final']:
 subprocess.run([sys.executable,str(b/'run_realtime_final.py'),name],check=True)
