from pathlib import Path
import subprocess,sys
b=Path('work/sign-final-20261021')
for script,args in [('run.py',['controls-v2']),('lesson.py',[])]:
 subprocess.run([sys.executable,str(b/script),*args],check=True)
