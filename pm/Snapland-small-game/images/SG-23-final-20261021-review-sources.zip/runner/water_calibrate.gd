extends SceneTree
func _initialize()->void:_run.call_deferred()
func _run()->void:
	root.size=Vector2i(1280,720)
	var profile:=OS.get_environment("SNAPLAND_SAVE_PATH");var folder:=profile.get_base_dir()
	if not profile.is_absolute_path():quit(2);return
	var model=preload("res://game/minigames/sign_balance_model.gd").new();model.reset()
	var view=preload("res://game/minigames/sign_balance_view.gd").new();root.add_child(view);view.size=Vector2(1280,720)
	var records:Array=[]
	for row in [["water-noon","noon","#236c7a"],["water-dawn","dawn","#356b76"],["water-dusk","dusk","#4b5969"],["water-night","night","#142c3d"]]:
		view.update_frame(model.snapshot(),row[1],false)
		view._materials.water.albedo_color=Color(row[2])
		for i in 6:await process_frame
		await RenderingServer.frame_post_draw
		var image:=root.get_texture().get_image();image.save_png(folder.path_join(str(row[0])+".png"))
		records.append({"name":row[0],"sample":str(image.get_pixel(10,200)),"water":str(view._materials.water.albedo_color)})
	FileAccess.open(folder.path_join("audit.json"),FileAccess.WRITE).store_string(JSON.stringify(records,"  "))
	print("PASS: four real native tonemap candidates captured; not a visual acceptance result")
	view.queue_free();await process_frame;quit()
