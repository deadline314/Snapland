extends "res://work/sign-final-20261021/phases-final/native_sign_balance_review.gd"
func _run()->void:
	_wall_deadline_msec=Time.get_ticks_msec()+300000
	progress=get_tree().root.get_node("Progress");progress.reset_progress();progress.intro_seen=true
	main=_instantiate_main();get_tree().root.add_child(main);await _frames(4)
	var records:Array=[]
	for phase in ["dawn","noon","dusk","night"]:
		for reduced in [false,true]:
			progress.settings.time_phase=phase;progress.settings.reduced_motion=reduced;progress.settings.assist=false
			if not await _launch_sign_balance():return
			var live:Control=main.session
			await RenderingServer.frame_post_draw
			var viewport:SubViewport=live.presentation.find_child("HarborViewport",true,false)
			var color:=viewport.get_texture().get_image().get_pixel(20,260)
			if not main._capture("sign-%s-reduced-%s.png"%[phase,str(reduced)]):await _fail("Capture actual phase");return
			records.append({"phase":phase,"reduced":reduced,"water_sample":str(color),"camera_actual_gpu_checked":true})
			for name in ["PauseButton","LeaveButton","ConfirmAction"]:
				var button:=live.minigame_hud.find_child(name,true,false) as Button
				if button==null:await _fail("Missing phase exit control "+name);return
				if not await _native_click_button(button,"leave phase through "+name):return
			if not await _wait_until(func():return main.session==null and main.modal_kind=="","phase test returns to park"):return
	FileAccess.open(OS.get_environment("SNAPLAND_SAVE_PATH").get_base_dir().path_join("phase-audit.json"),FileAccess.WRITE).store_string(JSON.stringify({"cases":records,"scope":"Actual Main station input, eight actual GPU scenes, time/reduced settings are fixture state; real pause/leave/confirm each time. Not time-settings UI or hardware FPS."},"  "))
	print("PASS: native sign four time phases and reduced-motion on/off retain colored water, actual3D camera, apparatus clearance and real pause/leave confirmation")
	await main._quit_game()
