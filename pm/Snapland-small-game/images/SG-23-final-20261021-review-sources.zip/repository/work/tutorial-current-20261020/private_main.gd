extends "res://game/main.gd"
## Evidence-only output routing and observation; production controls/rules stay inherited.
var capture_index := 0
var result_index := 0
var observed_results: Array[Dictionary] = []
func _capture(request: String) -> bool:
	var profile := OS.get_environment("SNAPLAND_SAVE_PATH")
	if not profile.is_absolute_path(): return false
	var folder := profile.get_base_dir().path_join("captures")
	DirAccess.make_dir_recursive_absolute(folder)
	var path := folder.path_join("%03d-%s" % [capture_index,request.get_file()])
	capture_index += 1
	if FileAccess.file_exists(path): return false
	var image := get_viewport().get_texture().get_image()
	if image == null or image.is_empty() or image.get_size()!=Vector2i(1280,720): return false
	if image.save_png(path)!=OK:return false
	var report := {"request":request,"file":path,"size":[1280,720],"window":[get_window().size.x,get_window().size.y],"frame":Engine.get_process_frames()}
	var journal := FileAccess.open(profile.get_base_dir().path_join("captures.jsonl"),FileAccess.READ_WRITE if FileAccess.file_exists(profile.get_base_dir().path_join("captures.jsonl")) else FileAccess.WRITE)
	if journal==null:return false
	journal.seek_end();journal.store_line(JSON.stringify(report));journal.close()
	print("PRIVATE_NATIVE_CAPTURE ",JSON.stringify(report))
	return true
func _launch_game(id: String, assist: bool, practice: bool = false) -> void:
	super._launch_game(id,assist,practice)
	if is_instance_valid(session):
		session.finished.connect(_observe_result)
func _observe_result(result: Dictionary) -> void:
	# Observe the real Session signal after Main's normal result handler. Never emit it.
	var record := result.duplicate(true)
	record["observed_process_id"] = OS.get_process_id()
	record["observed_frame"] = Engine.get_process_frames()
	record["observer_only"] = true
	observed_results.append(record)
	var path := OS.get_environment("SNAPLAND_SAVE_PATH").get_base_dir().path_join("natural-results.json")
	var file := FileAccess.open(path,FileAccess.WRITE)
	if file!=null:file.store_string(JSON.stringify(observed_results,"  "));file.close()
	_record_result_frame.call_deferred(record)
func _record_result_frame(record: Dictionary) -> void:
	await RenderingServer.frame_post_draw
	if modal_kind!="result":
		print("NATURAL_RESULT_NOT_CAPTURED: modal already changed ",record.game_id)
		return
	var label := "natural-%02d-%s-score-%d.png"%[result_index,str(record.game_id),int(record.score)]
	result_index+=1
	if not _capture(label):push_error("Could not preserve the actual natural result "+label)
