"""Append the narrow sign fix and explicit historical hash semantics; no engine run."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
index_path=HERE/'evidence-index.json'
index=json.loads(index_path.read_text(encoding='utf-8'))
red_path=HERE/'fix1-red-receipt.json'
green_path=HERE/'fix1-final-green-receipt.json'
red=json.loads(red_path.read_text(encoding='utf-8'))
green=json.loads(green_path.read_text(encoding='utf-8'))
assert len(red)==2 and red[0]['exit']==0 and red[0]['errors']==0
assert red[1]['exit']==1 and red[1]['errors']==3 and red[1]['leaks']==0
assert len(green)==3 and all(row['exit']==0 and row['errors']==0 and row['leaks']==0 and row['marker_contract_error'] is None for row in green)
for row in red+green:
    for field,value in row['environment'].items(): assert value.startswith('D:'),(field,value)
world='game/world/candy_world.gd'
fixture='game/tests/test_candy_world.gd'
assert red[1]['source_sha256'][world]=='3f556468a3567be1caa809c190ed06ef40ea15092e01e63c8afca41d074ccbe1'
assert green[1]['source_sha256'][fixture]==sha(ROOT/fixture)
assert green[1]['source_sha256'][world]==sha(ROOT/world)
frozen=json.loads((HERE/'boundary-receipt.json').read_text(encoding='utf-8'))['frozen_sources']
for name,expected in frozen.items(): assert sha(ROOT/name)==expected,name
index['fix1']=dict(fix_base='7037511cdd6a9749725bb404f36bfe013c6a1bdf',finding='P2 physical factory game count sign',source_sha256={name:sha(ROOT/name) for name in [world,fixture]},red=dict(receipt=red_path.name,receipt_raw_sha256=sha(red_path),world_old_sha256=red[1]['source_sha256'][world],fixture_sha256=red[1]['source_sha256'][fixture],exit=1,errors=3,leaks=0),failed_first_green=dict(receipt='fix1-green-receipt.json',receipt_raw_sha256=sha(HERE/'fix1-green-receipt.json'),cause='Fixture checked distance-gated sign visibility from entry; text fix was present but three new assertions still failed. Main passed; neither failed-world result is promoted.'),green=dict(receipt=green_path.name,receipt_raw_sha256=sha(green_path),cases=['test_candy_world','test_jelly_trampoline_main'],exit=0,errors=0,leaks=0),prelaunch_audits={name:sha(HERE/name) for name in ['fix1-red-prelaunch-closure-audit.json','fix1-green-prelaunch-closure-audit.json','fix1-final-green-prelaunch-closure-audit.json']},hash_semantics='Runtime/receipt/source/audit hashes are raw bytes. Historical Python receipt log_sha256 values are UTF-8 LF canonical text; separate raw_byte_sha256 values are listed in python_log_hashes. No old log/receipt bytes changed.',scope='Only world sign expression and existing candy-world visible Label3D assertion/setup changed. Genuine pre-edit RED, first failed two-case GREEN (fixture visibility setup), and final fresh two-case GREEN retained; no producer/PNG edits.')
index_path.write_text(json.dumps(index,ensure_ascii=False,indent=2),encoding='utf-8')

report=ROOT/'.superpowers/sdd/2026-11-18-jelly-trampoline/task-3-report.md'
text=report.read_text(encoding='utf-8')
text=text.replace('## Frozen owned source SHA256','## Initial frozen owned source SHA256')
text=text.replace('The following30 files are the exact handoff; raw hashes include their actual checkout bytes.','The following30 files are the initial handoff before fix round1; the two superseding fix hashes appear below, and evidence-index.json carries all30 current hashes. Raw hashes include their actual checkout bytes.')
assert '## Fix round 1' not in text
append='''

## Fix round 1 — physical factory game-count sign

Status: DONE for scoped re-review. FIX_BASE `7037511cdd6a9749725bb404f36bfe013c6a1bdf`. Sole P2 finding: the physical factory sign still advertised3/12 despite four real entrances. The sign now formats the delivered candy count from the existing lightweight catalog accessor. Its `Vector3(0, GROUND_Y, -10.8)` position and every existing entrance remain unchanged. The existing candy-world fixture finds the constructed Label3D by its actual sign text prefix and requires exactly one visible sign reading `工廠遊戲 4／12` on all three world visits.

Genuine pre-edit chronology: added the sign assertion while the old3/12 production expression was still intact. Before any engine launch, the exact staged selected fixture/helper closure was audited for OS process-launch APIs: RED1 file and each GREEN7 files, zero launch calls, source SHAs recorded in each prelaunch audit. `fix1-red` import exit0/errors0; actual old-code candy-world exit1/errors3/leaks0, exactly the new sign assertion on three visits (`Candy world checks: 4311`, `FAIL: candy world (3/4311)`). The automatic receipt retains the old world's raw SHA and original regression fixture SHA. That first assertion also checked visibility from entry, missing the existing distance gate; it was therefore a confounded RED, not an isolated text-only regression. No code rewind or replay is claimed.

Then changed only the shared sign text expression. The first `fix1-green` still failed the three sign assertions because the label is correctly hidden19.8m from entry; current Main passed. That failed receipt/log remains unchanged and excluded. Corrected only the fixture setup to stand the player on safe floor beside the sign, let two real physics frames update distance visibility, check the visible4/12 Label3D, and return to entry before existing checks. The final fixture differs from the first RED fixture; no clean same-final-fixture old-code RED was replayed. Root was informed of this limitation.

`fix1-final-green` used another fresh D stage and fresh five-path D profiles per process: import exit0/errors0, candy-world exit0/errors0/leaks0 with4311 checks and its exact existing PASS marker, and current Jelly Main exit0/errors0/leaks0 with its exact existing PASS marker. Candy-world warnings0; Main's45 existing material warnings remain unsuppressed. Main rechecks the current fourth entrance/map callback, actual800-large rules, natural routes/rewards, selected retakes and reload. This is headless scripted integration evidence, not human playtesting or GPU proof.

Exact engine and launcher remain `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe` via `run_validated_godot`; SceneTree uses `--script`, Main uses its real `.tscn`. Full actual commands, isolated absolute D save/APPDATA/LOCALAPPDATA/TEMP/TMP paths, exits/errors/leaks/markers and source SHA manifests are in `fix1-red-receipt.json`, failed `fix1-green-receipt.json` and accepted `fix1-final-green-receipt.json`; raw logs and prelaunch audit files share those run prefixes under the private integration directory.

```text
python .review/jelly-trampoline-20261118/integration/run.py fix1-red test_candy_world.gd
python .review/jelly-trampoline-20261118/integration/run.py fix1-green test_candy_world.gd test_jelly_trampoline_main.tscn
python .review/jelly-trampoline-20261118/integration/run.py fix1-final-green test_candy_world.gd test_jelly_trampoline_main.tscn
```

The RED/first-GREEN commands record historical execution with earlier fixture setup; rerunning them after the correction will not reproduce their failures. The promoted index now replaces only candy-world and Jelly Main with current fix1-final-green evidence. Older accepted stages explicitly list the changed world sign and, where their selected closure contained it, the changed candy-world fixture among current-source differences; earlier028 copy/Main-fixture differences remain declared. The new exact promoted closure audit remains read-only. The excluded legacy child parents and all their raw history remain excluded and unchanged.

No whole15-suite/98-Python/native/export rerun, launcher refactor, stage source patch, frozen Model/Driver/View/tutorial-PNG edit, Git mutation or Task4 work occurred. The six frozen producer/PNG hashes were checked read-only and still match. Only these two source hashes supersede the initial list:

'''
append+=''.join('- `'+name+'`: `'+sha(ROOT/name)+'`\n' for name in [world,fixture])
append+='''

### Historical Python hash semantics

The existing `python-final-receipt.json` field `log_sha256` hashes in-memory UTF-8 text with LF newlines before Windows text writing produced the preserved CRLF log files. Those historical values are **canonical-text hashes**, not raw-byte hashes. Old receipts/log bytes were not rewritten and passing Python commands were not rerun. The evidence index now labels that meaning and adds a separate raw-byte hash for each preserved file:

| Log | Historical UTF-8/LF canonical SHA256 | Preserved raw-byte SHA256 |
|---|---|---|
'''
append+=''.join('| '+row['log']+' | '+row['canonical_text_sha256']+' | '+row['raw_byte_sha256']+' |\n' for row in index['python_log_hashes'])
append+='\nRuntime logs, source files, receipts and audit SHA values remain explicitly raw-byte hashes. This metadata clarification grants no new Python execution or gameplay acceptance.\n'
report.write_text(text+append,encoding='utf-8')
print('Fix1 source/report metadata frozen; old Python bytes retained; exact2 source hashes appended.')
