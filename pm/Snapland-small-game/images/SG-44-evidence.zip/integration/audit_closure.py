"""Read-only launch audit of each promoted exact staged fixture/helper closure."""
import hashlib
import json
from pathlib import Path
import re

HERE=Path(__file__).resolve().parent
index=json.loads((HERE/'evidence-index.json').read_text(encoding='utf-8'))
records=[]
all_names=set()
for mode,selected in index['promoted_runtime_results'].items():
    receipt=next(row for row in json.loads((HERE/selected['receipt']).read_text(encoding='utf-8')) if row['mode']==mode)
    command=receipt['command']
    stage=Path(command[command.index('--path')+1])
    entry=command[-1].removeprefix('res://')
    pending=[entry]
    closure={}
    launch_lines=[]
    while pending:
        name=pending.pop()
        if name in closure: continue
        raw=(stage/name).read_bytes()
        sha=hashlib.sha256(raw).hexdigest()
        assert sha==receipt['source_sha256'][name],name
        closure[name]=sha
        text=raw.decode('utf-8')
        for line_number,line in enumerate(text.splitlines(),1):
            if re.search(r'OS\s*\.\s*(?:execute|create_process|execute_with_pipe|create_instance)\s*\(',line):
                launch_lines.append(dict(file=name,line=line_number,source=line.strip()))
        pending.extend(re.findall(r'res://(game/tests/[^"\s]+\.(?:gd|tscn))',text))
    assert not launch_lines,(mode,launch_lines)
    all_names.update(closure)
    records.append(dict(case=mode,run=selected['run'],stage=str(stage),entry=entry,fixture_helper_sha256=closure,launch_lines=launch_lines))
report=dict(scope='Read-only complete explicit fixture/helper closure of the15 actually executed promoted cases; exact staged sources match automatic receipt SHAs. No engine run or mutation.',case_count=len(records),unique_fixture_helper_count=len(all_names),unique_fixture_helpers=sorted(all_names),cases=records,excluded_unvalidated_child_parents=['game/tests/test_region_progress.gd:136','game/tests/test_photo_retake_progress.gd:143'])
(HERE/'fixture-launch-audit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print('PASS:',len(records),'promoted case closures,',len(all_names),'unique exact staged fixtures/helpers, zero process launch calls')
