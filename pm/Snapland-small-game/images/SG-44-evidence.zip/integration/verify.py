"""Record focused Python contracts and unchanged producer/legacy data boundaries."""
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
BASE='cd582d2080b53cf37c804f564201ca109d764977'
def before(name):
    return subprocess.check_output(['git','show',BASE+':'+name],cwd=ROOT)
def current(name):
    return (ROOT/name).read_bytes()
def data(name, old=False):
    return json.loads(before(name) if old else current(name))
boundaries={}
for name in ['game/data/welcome_games.json','game/data/harbor_games.json','game/core/progress.gd','game/core/steam_bridge.gd']:
    assert current(name).replace(b'\r\n',b'\n')==before(name).replace(b'\r\n',b'\n'),name
    boundaries[name]='identical canonical text to base (Git LF versus checkout CRLF normalized)'
assert data('game/data/candy_games.json')[:3]==data('game/data/candy_games.json',True)
assert data('game/data/tutorials.json')['lessons'][:-1]==data('game/data/tutorials.json',True)['lessons']
catalog=data('design/02-minigames/catalog.json')['games']
old_catalog=data('design/02-minigames/catalog.json',True)['games']
assert len(catalog)==128 and catalog[:27]==old_catalog[:27] and catalog[28:]==old_catalog[28:]
boundaries['data']='old27 runtime definitions, park+27 old lessons, and127 other candidate design rows structurally identical'
def props(raw):
    return ast.literal_eval(re.search(r'const PROPS := (\[.*?\])\s*const PROP_LABELS',raw.decode('utf-8'),re.S)[1])
assert props(current('game/ui/retake_panel.gd'))[:27]==props(before('game/ui/retake_panel.gd'))
assert len(props(current('game/ui/retake_panel.gd')))==28
boundaries['retake_props']='first27 rows structurally identical; exactly one28th row appended'
frozen={
 'game/minigames/jelly_trampoline_model.gd':'86134f411bae5c41bee6732340155bb06ca6991d85b9e98ef5b5191bd90cf822',
 'game/minigames/jelly_trampoline_driver.gd':'9b03f31b464a09fb5896438ca61d5c7f6d44e59606f92d47938357b2821887b7',
 'game/minigames/jelly_trampoline_view.gd':'33c8f3e5a5038004e95e781cd8f43093c6d83184ddd83d9115a5d9def7097b11',
 'assets/ui/tutorials/game-028-step-01.png':'ef2fa79e4890b25878323f7b63a62265af52ebf5176d7a1c56b4f406a19d3fa9',
 'assets/ui/tutorials/game-028-step-02.png':'44dd41c0497d68c9ef917253eda892435844f2038aee07af3d3eef48c01c7a24',
 'assets/ui/tutorials/game-028-step-03.png':'0a400080054a61667b52259b6ba0dd74805cedb1b678948cc14bd1211db7dcbf',
}
for name,sha in frozen.items(): assert hashlib.sha256(current(name)).hexdigest()==sha,name
boundaries['frozen_sources']=frozen
(HERE/'boundary-receipt.json').write_text(json.dumps(boundaries,ensure_ascii=False,indent=2),encoding='utf-8')
commands=[
 [sys.executable,'-m','unittest','tests.test_design_validation','tests.test_runtime_result_contract','tests.test_runtime_shards','tests.test_godot_entrypoints','tests.test_desktop_release_stage','-v'],
 [sys.executable,'tools/verify_design.py','--scope','games'],
 [sys.executable,'tools/verify_design.py','--scope','links'],
 [sys.executable,'tools/check_runtime_tests.py'],
 ['git','diff','--check'],
]
receipts=[]
for i,cmd in enumerate(commands):
    result=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True,encoding='utf-8')
    raw=result.stdout+result.stderr
    (HERE/f'python-final-{i}.log').write_text(raw,encoding='utf-8')
    receipts.append(dict(command=cmd,exit=result.returncode,log=f'python-final-{i}.log',log_sha256=hashlib.sha256(raw.encode()).hexdigest()))
    print(cmd[1:],result.returncode,raw[-500:],flush=True)
(HERE/'python-final-receipt.json').write_text(json.dumps(receipts,indent=2),encoding='utf-8')
assert all(r['exit']==0 for r in receipts)
