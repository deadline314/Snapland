"""Fresh exact-runtime stage and selected fixture closure; no legacy child runners."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import uuid

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from tools.build_desktop_release import prepare_runtime_stage
from tools.godot_entrypoints import run_validated_godot
from tools.run_game_tests import build_checks, result_error

HERE = Path(__file__).resolve().parent
ENGINE = 'C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
label, *entries = sys.argv[1:]
assert entries
assert not any(any(name in e for name in ['test_photo_retake_main','test_region_travel','test_region_progress','test_photo_retake_progress']) for e in entries)
base = Path('D:/Snapland-QA') / ('jelly-integration-' + label + '-' + uuid.uuid4().hex[:8])
stage = base / 'project'
stage.mkdir(parents=True)
tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT, text=True, encoding='utf-8').split('\0')
# prepare_runtime_stage takes an explicit tracked manifest. UID/import caches are not fixture evidence.
tracked = [p for p in tracked if not p.endswith(('.uid', '.import'))]
manifest = prepare_runtime_stage(ROOT, stage, tracked)
pending = ['game/tests/' + e for e in entries]
copied = set()
while pending:
    name = pending.pop()
    if name in copied:
        continue
    copied.add(name)
    source = ROOT / name
    assert source.is_file(), name
    destination = stage / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    manifest[name] = hashlib.sha256(source.read_bytes()).hexdigest()
    for ref in re.findall(r'res://(game/tests/[^"\s]+\.(?:gd|tscn))', source.read_text(encoding='utf-8')):
        pending.append(ref)
launch_audit = []
for name in sorted(copied):
    source = stage / name
    lines = source.read_text(encoding='utf-8').splitlines()
    launches = [dict(line=i, text=line.strip()) for i, line in enumerate(lines, 1) if re.search(r'OS\s*\.\s*(?:execute|create_process|execute_with_pipe|create_instance)\s*\(', line)]
    launch_audit.append(dict(file=name, source_sha256=manifest[name], launch_calls=launches))
(HERE / (label + '-prelaunch-closure-audit.json')).write_text(json.dumps(launch_audit, indent=2), encoding='utf-8')
assert not any(row['launch_calls'] for row in launch_audit), 'selected fixture/helper closure contains process launches'
print('PRELAUNCH AUDIT:', len(launch_audit), 'exact staged fixture/helper files, zero process launch calls', flush=True)
receipts = []
jobs = [('import', ['--editor', '--import', '--quit'])]
jobs += [(Path(e).stem, ['--script', 'res://game/tests/' + e] if e.endswith('.gd') else ['res://game/tests/' + e]) for e in entries]
labels = {Path(command[-1]).stem: suite for suite, command in build_checks(ENGINE) if command[-1].endswith(('.gd', '.tscn'))}
for mode, args in jobs:
    profile = base / (mode + '-profile')
    env = dict(os.environ, SNAPLAND_SAVE_PATH=str(profile / 'progress.json'), APPDATA=str(profile / 'appdata'), LOCALAPPDATA=str(profile / 'localappdata'), TEMP=str(profile / 'temp'), TMP=str(profile / 'tmp'))
    for key in ['APPDATA', 'LOCALAPPDATA', 'TEMP', 'TMP']:
        Path(env[key]).mkdir(parents=True)
    cmd = [ENGINE, '--headless', '--path', str(stage), *args]
    try:
        result = run_validated_godot(stage, cmd, env, 180 if mode == 'import' else 120)
        output = result.stdout + result.stderr
        code = result.returncode
    except subprocess.TimeoutExpired as exc:
        output = str(exc.stdout) + str(exc.stderr)
        code = -999
    (HERE / (label + '-' + mode + '.log')).write_text(output, encoding='utf-8')
    contract = result_error('clean project import' if mode == 'import' else labels[mode], result) if code != -999 else 'timeout'
    receipt = dict(mode=mode, command=cmd, environment={k:env[k] for k in ['SNAPLAND_SAVE_PATH','APPDATA','LOCALAPPDATA','TEMP','TMP']}, exit=code, errors=output.count('ERROR:'), leaks=len(re.findall(r'(?im)^.*(?:WARNING|ERROR):.*(?:leaked|still in use at exit).*$',output)), warnings=output.count('WARNING:'), marker_contract_error=contract, markers=[l for l in output.splitlines() if re.search(r'(?:checks,|PASS:|tests:)',l)], source_sha256=manifest)
    receipts.append(receipt)
    (HERE / (label + '-receipt.json')).write_text(json.dumps(receipts, indent=2), encoding='utf-8')
    print(json.dumps({k:v for k,v in receipt.items() if k not in ['source_sha256','command','environment']}), flush=True)
    if mode == 'import' and (code or receipt['errors']):
        break
if label not in {'pre-wiring-red', 'fix1-red'}:
    assert len(receipts) == len(jobs) and all(r['exit'] == 0 and r['errors'] == 0 and r['leaks'] == 0 and r['marker_contract_error'] is None for r in receipts), 'strict selected runtime gate failed'
