"""Freeze exact Task3 sources and selected raw runtime outcomes without rerunning."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from tools.run_game_tests import build_checks, PASS_MARKERS

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
previous=json.loads((HERE/'evidence-index.json').read_text(encoding='utf-8'))
changed=list(previous['source_sha256'])
changed += ['game/tests/test_jelly_trampoline_session.gd','game/tests/test_jelly_trampoline_main.gd','game/tests/test_jelly_trampoline_main.tscn']
sources={name:sha(ROOT/name) for name in sorted(set(changed))}
labels={Path(command[-1]).stem:label for label,command in build_checks('fixture-godot') if command[-1].endswith(('.gd','.tscn'))}
promoted={}
excluded_children={'test_region_progress','test_photo_retake_progress'}
for run in ['selected-green','final-copy','final-main','fix1-final-green']:
    receipt_path=HERE/(run+'-receipt.json')
    for receipt in json.loads(receipt_path.read_text(encoding='utf-8')):
        mode=receipt['mode']
        if mode=='import': continue
        if mode in excluded_children: continue
        log=HERE/(run+'-'+mode+'.log')
        output=log.read_text(encoding='utf-8')
        errors=output.count('ERROR:')
        leaks=re.findall(r'(?im)^.*(?:WARNING|ERROR):.*(?:leaked|still in use at exit).*$',output)
        marker=PASS_MARKERS[labels[mode]]
        assert receipt['exit']==0 and errors==0 and not leaks and marker in output.splitlines(),(run,mode)
        fixture='game/tests/'+mode+('.tscn' if receipt['command'][-1].endswith('.tscn') else '.gd')
        if fixture not in receipt['source_sha256']: raise AssertionError(fixture)
        # Later current-copy jobs replace earlier equivalents; no source is rewound or replayed.
        promoted[mode]=dict(run=run,receipt=receipt_path.name,receipt_sha256=sha(receipt_path),log=log.name,log_sha256=sha(log),exit=0,errors=0,leaks=0,warnings=output.count('WARNING:'),marker=marker,entrypoint_source_sha256=receipt['source_sha256'][fixture],current_entrypoint_sha256=sha(ROOT/fixture),current_runtime_source_differences=[p for p,h in receipt['source_sha256'].items() if (ROOT/p).is_file() and sha(ROOT/p)!=h])
for mode,row in promoted.items():
    assert row['entrypoint_source_sha256']==row['current_entrypoint_sha256'],mode

baseline=[]
for receipt in json.loads((HERE/'pre-wiring-baseline-receipt.json').read_text(encoding='utf-8')):
    log=HERE/('pre-wiring-baseline-'+receipt['mode']+'.log')
    output=log.read_text(encoding='utf-8')
    leaks=re.findall(r'(?im)^.*(?:WARNING|ERROR):.*(?:leaked|still in use at exit).*$',output)
    assert receipt['exit']==0 and 'ERROR:' not in output and not leaks
    baseline.append(dict(mode=receipt['mode'],exit=0,errors=0,actual_leak_diagnostics=0,original_overbroad_leak_count=receipt['leaks'],warnings=output.count('WARNING:'),raw_log_sha256=sha(log),excluded_from_validated_acceptance=receipt['mode'] in excluded_children))

python_receipt=HERE/'python-final-receipt.json'
python_log_hashes=[]
for row in json.loads(python_receipt.read_text(encoding='utf-8')):
    path=HERE/row['log']
    canonical_sha=hashlib.sha256(path.read_text(encoding='utf-8').encode('utf-8')).hexdigest()
    assert canonical_sha==row['log_sha256'],row['log']
    python_log_hashes.append(dict(log=row['log'],historical_receipt_field='log_sha256',historical_hash_semantics='UTF-8 text with LF newlines before Windows CRLF text writing; not a raw-byte hash',canonical_text_sha256=canonical_sha,raw_byte_sha256=sha(path)))
index=dict(status='DONE',base='cd582d2080b53cf37c804f564201ca109d764977',fix_base='7037511cdd6a9749725bb404f36bfe013c6a1bdf',source_sha256=sources,promoted_runtime_results=promoted,python_receipt_raw_sha256=sha(python_receipt),python_log_hashes=python_log_hashes,pre_wiring_baseline_reclassification=baseline,excluded_runtime_parents=sorted(excluded_children),private_harness_sha256={p.name:sha(p) for p in HERE.glob('*.py')},limits=['No GPU/new-process/package acceptance; synthetic PNG I/O only.','Legacy test_photo_retake_main and test_region_travel not executed; inherited OS.execute bypasses mandated launcher/profile boundary.','Region-progress and photo-retake-progress were mistakenly executed before discovering their additional OS.execute children. Their children stayed in inherited isolated D profiles but bypassed validation/per-process profile isolation; both parent suites excluded from promoted evidence. No standalone child raw logs or validated receipts exist.','Older selected stages retain final028 invitation/tutorial/Main fixture differences and the prior physical sign/world fixture. Current fix1-green covers the updated world fixture/sign and Main; current-copy runs cover tutorial/retake copy. See each exact differences list.','Original baseline harness leaked-field regex falsely counted JSON keys and exited1 despite clean subprocesses; raw receipts remain unchanged and reclassification is explicit.'])
(HERE/'evidence-index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2),encoding='utf-8')
print('Task3 frozen:',len(sources),'owned sources;',len(promoted),'selected runtime suites; all exit0/errors0/leaks0')
for mode,row in promoted.items(): print(mode,row['run'],'warnings',row['warnings'],'source differences',row['current_runtime_source_differences'])
