import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
def replace(name, old, new):
    path = ROOT / name
    text = path.read_text(encoding='utf-8')
    assert old in text, (name, old)
    path.write_text(text.replace(old,new), encoding='utf-8')

replace('game/minigames/session.gd','const DRIVERS := {','const DRIVERS := {"jelly_trampoline": preload("res://game/minigames/jelly_trampoline_driver.gd"), ')
replace('game/core/game_catalog.gd','"candy": 3}', '"candy": 4}')
replace('game/ui/tutorial_catalog.gd','"game-026", "game-027"]','"game-026", "game-027", "game-028"]')
replace('game/world/candy_world.gd','\t_point("game-027", "糖漿分洪 · 冷熱切管與關閥", Vector3(7, GROUND_Y, -6))','\t_point("game-027", "糖漿分洪 · 冷熱切管與關閥", Vector3(7, GROUND_Y, -6))\n\t_point("game-028", "果凍彈床 · 蓄彈斜壓送高台", Vector3(7, GROUND_Y, -1))')
for name in ['game/main.gd','game/ui/collection_book_panel.gd']:
    replace(name,'["sugar_bridge","cookie_mold","syrup_flood"]','["sugar_bridge","cookie_mold","syrup_flood","jelly_trampoline"]')
replace('game/ui/retake_panel.gd','["lantern","sign","camera"]]','["lantern","sign","camera"], ["bench","lantern","camera"]]')
replace('tools/verify_design.py','CANDY_DELIVERED = 3','CANDY_DELIVERED = 4')

game = dict(id='game-028',mode='jelly_trampoline',zone='candy',local_index=4,name='果凍彈床',
    goal='移床斜壓並按住蓄彈，放開後把三顆果實真正送上高台',
    instructions='移床斜壓、按住蓄彈再放開',
    devil_hint='讓任一果實真實碰響側鈴，並把同一顆送上高台，再完成三顆；AI與回接只是可選補救，輔助仍可挑戰',
    devil='碰鈴的同顆果實送達並完成三顆',ordinary='連續送三顆果實上高台',attraction_tag='彈性工作台',
    island_invitation='A/D移床、Q/E斜壓、Space按住蓄彈再放開；R切AI接穩後等你放行，X免費重置當顆不回時間。')
path = ROOT / 'game/data/candy_games.json'
text = path.read_text(encoding='utf-8')
assert text.rstrip().endswith(']')
path.write_text(text.rstrip()[:-1].rstrip()+',\n'+json.dumps(game,ensure_ascii=False,indent=2).replace('\n','\n  ').join(['  ',''])+'\n]\n',encoding='utf-8')

lesson = dict(id='game-028',title='果凍彈床',goal='移床、斜壓與蓄彈，把三顆果實送上高台；限時60秒。',
    ordinary='真正蓄彈放開後正式結算不限勝負得普通卡；只配置、按住或等待不發卡。練習、取消不發卡。',
    bonus='任一果實真正碰響側鈴後，同顆果實送上高台，再完成三顆。AI與回接是可選補救，並非小惡魔必要條件。',steps=[
    dict(id='charge',title='移床斜壓，按住後放開',image='res://assets/ui/tutorials/game-028-step-01.png',
         alt='真實果凍支撐已下壓，果實仍在床上，斜壓21度與預測弧線顯示放開後的落點。',
         goal='深壓提高能量，斜壓改變水平速度；每顆果重與台高不同。按住不會自動發射。',
         input='A/D或左右鍵移床，Q/E斜壓；Space或按住蓄彈鈕，至少0.15秒後同來源放開才發射。',
         success='果實跟隨床面實際下壓，放開後依能量、斜角與重量飛行；飛行中不能遙控果實轉向。'),
    dict(id='deliver',title='真實落台，連送三顆',image='res://assets/ui/tutorials/game-028-step-02.png',
         alt='第三顆真實下降落台，已送三顆且其中同顆碰鈴送達，實際結算500分。',
         goal='果實下降穿越台頂且落在支撐範圍才送達；連送三顆成功。普通無失誤400分，碰鈴同顆送達可得500分。',
         input='讀果重、台高與弧線，逐顆調床位、斜壓及蓄力。成功加100，每顆100，小惡魔再100，失手每次扣20。',
         success='這張圖的500分來自真實碰鈴果實送達；普通成功不必碰鈴。未操作、練習或取消不發卡。'),
    dict(id='recover',title='碰鈴回接後，親自蓄彈放行',image='res://assets/ui/tutorials/game-028-step-03.png',
         alt='已送2/3，同一顆果實真實碰鈴、撞牆回落後被接穩，玩家重新按住蓄彈，尚未完成送達。',
         goal='R切AI只在實際回落碰床時接穩，等你再蓄彈放開；同顆碰鈴紀錄保留到真正送達。回接並非必要技巧。',
         input='飛行時移床準備接球，或按住Space等真正接觸。X重置當顆不回時間；失落時輔助保留已送進度。',
         success='圖中仍是2/3，重新手動放開並落台才計同顆碰鈴送達。暫停、失焦或外側放開取消蓄彈，不幽靈發射。')])
path = ROOT / 'game/data/tutorials.json'
text = path.read_text(encoding='utf-8')
suffix='    }\n  ]\n}\n'
assert text.endswith(suffix)
text=text[:-len(suffix)]+'    },\n'+'\n'.join('    '+line for line in json.dumps(lesson,ensure_ascii=False,indent=2).splitlines())+'\n  ]\n}\n'
path.write_text(text,encoding='utf-8')

path=ROOT/'design/02-minigames/catalog.json'
text=path.read_text(encoding='utf-8')
data=json.loads(text)
row=data['games'][27]
old='\n'.join('    '+line for line in json.dumps(row,ensure_ascii=False,indent=2).splitlines())
assert old in text
row.update(action=game['instructions'],goal=game['ordinary'],demon=game['devil'],runtime_mode=game['mode'],implementation='single_player_runtime_needs_full_acceptance')
new='\n'.join('    '+line for line in json.dumps(row,ensure_ascii=False,indent=2).splitlines())
path.write_text(text.replace(old,new),encoding='utf-8')
replace('design/02-minigames/catalog.md','001–027 有現行單人程式，其他 101 款只在設計','001–028 有現行單人程式，其他 100 款只在設計')
path=ROOT/'design/02-minigames/catalog.md'
text=path.read_text(encoding='utf-8')
start=text.index('### game-028 ')
end=text.index('### game-029 ',start)
block=text[start:end].replace('設計候選','單人程式已接入，待完整驗收').replace('移動落點並按住蓄彈',game['instructions']).replace('用斜壓反彈碰響側鈴',game['devil'])
path.write_text(text[:start]+block+text[end:],encoding='utf-8')
replace('design/runtime/full-game-delivery.md','工廠目前三款遊戲、三格普通／小惡魔卡。可玩總數為 27','SG-44 加入第二十八款「果凍彈床」，以真實蓄彈、斜壓、側鈴同顆送達提供獨立空間玩法，工廠目前四款遊戲、四格普通／小惡魔卡。可玩總數為 28')
replace('design/runtime/full-game-delivery.md','其餘101款','其餘100款')
replace('design/runtime/full-game-delivery.md','工廠目前三款已開放、其餘九款準備中','SG-44 接入第 28 款「果凍彈床」，工廠目前四款已開放、其餘八款準備中')
replace('design/runtime/full-game-delivery.md','其餘 101 款','其餘 100 款')
