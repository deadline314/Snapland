from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
def edit(name, pairs):
    p=ROOT/name
    text=p.read_text(encoding='utf-8')
    for old,new in pairs:
        assert old in text,(name,old)
        text=text.replace(old,new)
    p.write_text(text,encoding='utf-8')

for game in ['sugar_bridge','cookie_mold','syrup_flood']:
    edit('game/tests/test_'+game+'_main.gd', [('all_definitions().size() == 27','all_definitions().size() == 28'),('has27','has28'),('book._entries().size() == 3','book._entries().size() == 4'),('candy album exposes three real local entries','candy album exposes four real local entries')])
for game in ['sugar_bridge','cookie_mold']:
    edit('game/tests/test_'+game+'_session.gd',[('s.start("game-028")','s.start("game-029")'),('upcoming game028','upcoming game029')])
edit('game/tests/test_game_catalog.gd', [('candy.size() == 3 and all_games.size() == 27','candy.size() == 4 and all_games.size() == 28'),('twenty-seven','twenty-eight')])
edit('game/tests/test_candy_world.gd', [('snapshot.points.size() == 8','snapshot.points.size() == 9'),('["game-025","game-026","game-027"]','["game-025","game-026","game-027","game-028"]'),('only three delivered games','only four delivered games'),('begins_with("game-")).size() == 3','begins_with("game-")).size() == 4'),('exactly three delivered candy games','exactly four delivered candy games')])
edit('game/tests/test_retake_panel.gd',[('PROPS.size() == 27 and Catalog.all_definitions().size() == 27','PROPS.size() == 28 and Catalog.all_definitions().size() == 28'),('one of27','one of28'),('for invalid in ["game-028"','for invalid in ["game-029"')])
edit('game/tests/test_region_travel.gd', [('book._entries().size()==3','book._entries().size()==4'),('all three delivered local games','all four delivered local games'),('[18,12,3][index]','[18,12,4][index]'),('stamps.get_child_count()==3','stamps.get_child_count()==4'),('all three real local game stamps','all four real local game stamps'),('"3 / 12"','"4 / 12"'),('"其餘 9 款準備中"','"其餘 8 款準備中"'),('choices.get_child_count()==3','choices.get_child_count()==4'),('exactly three delivered lessons','exactly four delivered lessons'),('["game-025","game-026","game-027"]','["game-025","game-026","game-027","game-028"]')])
edit('game/tests/test_tutorial_paged_viewport.gd',[('[Vector2i(800,450),Vector2i(1280,720),Vector2i(1920,1080)]','[Vector2i(800,600),Vector2i(800,450),Vector2i(1280,720),Vector2i(1920,1080)]')])
edit('tests/test_design_validation.py',[("self.data['games'][27]['implementation']", "self.data['games'][28]['implementation']"),("'game-028.*scope'","'game-029.*scope'"),('first, second, third = self.candy','first, second, third, fourth = self.candy'),("[first, second, dict(third, id='game-028')]","[first, second, third, dict(fourth, id='game-029')]"),("self.candy + [dict(third, id='game-028', local_index=4)]","self.candy + [dict(fourth, id='game-029', local_index=5)]"),('for index in (24, 25, 26):','for index in (24, 25, 26, 27):')])

# New Main uses the existing full factory/selected-retake fixture pattern.
source=(ROOT/'game/tests/test_syrup_flood_main.gd').read_text(encoding='utf-8')
source=source.replace('syrup_flood','jelly_trampoline').replace('game-027','game-028').replace('ACH_GAME_027','ACH_GAME_028').replace('photo-candy-game-3','photo-candy-game-4').replace('photo-candy-devil-3','photo-candy-devil-4').replace('糖漿分洪','果凍彈床').replace('Syrup','Jelly').replace('syrup','jelly').replace('027','028').replace('third candy','fourth candy').replace('third entrance','fourth entrance').replace('local3','local4').replace('"local_index":3','"local_index":4').replace('three real filled closed tanks','three real deliveries and same-fruit bell').replace('three-tank','three-fruit').replace('cold plug','same-fruit bell').replace('Vector3(7, main.world.GROUND_Y, -6)','Vector3(7, main.world.GROUND_Y, -1)').replace('Route.advance(main.session, 76.0)','Route.advance(main.session, 61.0)')
source=source.replace('Route.key(main.session, KEY_SPACE)\n\tRoute.key(main.session, KEY_SPACE, false)\n\tRoute.tap(main.session, KEY_SPACE)','Route.launch(main.session, 0.15)')
source=source.replace('check(Route.solve(main.session, true), "real assisted same-fruit bell route")','check(Route.solve(main.session, true, true), "real assisted same-fruit bell route")')
source=source.replace('"id", "") == "game-028" and main.world._point_by_id("game-026")','"id", "") == "game-028" and main.world._point_by_id("game-027").get("id", "") == "game-027" and main.world._point_by_id("game-026")').replace('all three actual entrances','all four actual entrances')
source=source.replace('const Release =','const RulesLayout = preload("res://game/tests/native_game_rules_layout_review.gd")\nconst Paper = preload("res://game/ui/paper_ui.gd")\nconst Release =')
source=source.replace('\tmain._show_game_rules("game-028")','\tget_window().size = Vector2i(800, 600)\n\tProgress.settings["ui_scale"] = 1.25\n\tPaper.set_text_scale(1.25)\n\tmain._show_game_rules("game-028")\n\tawait _frames()\n\tvar pager: Control = main.overlay.find_child("GameRulesExtraDetails", true, false)\n\tcheck(pager != null and int(pager.get_meta("page_count")) == 5, "all five actual rules pages exist")\n\tif pager != null:\n\t\tfor page in int(pager.get_meta("page_count")):\n\t\t\tawait _frames()\n\t\t\tcheck(RulesLayout.inspect_layout(main).is_empty(), "complete rules text and actions fit actual800 large page%d" % page)\n\t\t\tif page < int(pager.get_meta("page_count")) - 1:\n\t\t\t\tmain.overlay.find_child("GameRulesExtraDetailsNext", true, false).pressed.emit()\n\tmain._show_game_rules("game-028")')
source=source.replace('\tmain._show_map()','\tget_window().size = Vector2i(1280, 720)\n\tPaper.set_text_scale(1.0)\n\tProgress.settings["ui_scale"] = 1.0\n\tmain._show_map()')
source=source.replace('if action != null: action.pressed.emit()','if action != null:\n\t\taction.grab_focus()\n\t\tcheck(action.has_focus(), "regional map action is keyboard focusable")\n\t\taction.pressed.emit()')
(ROOT/'game/tests/test_jelly_trampoline_main.gd').write_text(source,encoding='utf-8')
(ROOT/'game/tests/test_jelly_trampoline_main.tscn').write_text('[gd_scene load_steps=2 format=3]\n\n[ext_resource type="Script" path="res://game/tests/test_jelly_trampoline_main.gd" id="1"]\n\n[node name="JellyTrampolineMainTest" type="Node"]\nscript = ExtResource("1")\n',encoding='utf-8')
