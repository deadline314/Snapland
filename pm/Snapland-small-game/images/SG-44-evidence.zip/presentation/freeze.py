"""Freeze owned source hashes and three unedited native lesson captures."""
from pathlib import Path
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
labels = ["final-unit", "native-final-1280x720", "native-1152x648", "native-800x600"]
runs = {}
for label in labels:
    receipts = json.loads((HERE / (label + "-receipt.json")).read_text())
    assert all(item["exit"] == 0 and item["errors"] == 0 for item in receipts)
    runs[label] = receipts
native = runs["native-final-1280x720"][-1]
capture_dir = Path(native["environment"]["SNAPLAND_JELLY_WORKBENCH_OUTPUT"])
provenance = []
for step, name in enumerate(["01-charge-slant", "04-three-real-deliveries", "03-bell-recatch-manual-release"], 1):
    source = capture_dir / (name + ".png")
    target = ROOT / f"assets/ui/tutorials/game-028-step-{step:02d}.png"
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    assert sha(source) == sha(target)
    provenance.append(dict(step=step, source=str(source), target=str(target.relative_to(ROOT)), sha256=sha(target)))
files = ["game/minigames/jelly_trampoline_driver.gd", "game/minigames/jelly_trampoline_view.gd", "game/tests/test_jelly_trampoline_driver.gd", "game/tests/test_jelly_trampoline_view.gd", "game/tests/native_jelly_trampoline_workbench_review.gd", "game/tests/native_jelly_trampoline_workbench_review.tscn", *[p["target"] for p in provenance]]
hashes = {name: sha(ROOT / name) for name in files}
for receipts in runs.values():
    manifest = receipts[-1]["source_sha256"]
    for name in files[:4]:
        assert manifest[name] == hashes[name], (name, "active Driver/View closure differs")
    if receipts[-1]["mode"] == "native":
        for name in files[4:6]:
            assert manifest[name] == hashes[name], (name, "native closure differs")
assert sha(ROOT / "game/minigames/jelly_trampoline_model.gd") == "86134f411bae5c41bee6732340155bb06ca6991d85b9e98ef5b5191bd90cf822"
assert sha(ROOT / "game/tests/test_jelly_trampoline.gd") == "4731a456790147a9bf8844affed605f88f2d6b7985af8bb1a99691cfc7e6913e"
captures = {}
for label, receipts in runs.items():
    if receipts[-1]["mode"] == "native":
        folder = Path(receipts[-1]["environment"]["SNAPLAND_JELLY_WORKBENCH_OUTPUT"])
        captures[label] = {str(path): sha(path) for path in sorted(folder.glob("*.png"))}
index = dict(status="frozen", source_sha256=hashes, tutorial_provenance=provenance, final_runs={label: str(HERE / (label + "-receipt.json")) for label in labels}, raw_captures=captures)
(HERE / "evidence-index.json").write_text(json.dumps(index, indent=2), encoding="utf-8")
lines = ["\n## Automatic frozen SHA and provenance appendix\n"]
for name, digest in hashes.items():
    lines.append(f"- `{name}`: `{digest}`")
for item in provenance:
    lines.append(f"- Tutorial step{item['step']}: `{item['source']}` -> `{item['target']}`; identical SHA `{item['sha256']}`.")
for label, receipts in runs.items():
    stage = receipts[0]["command"][receipts[0]["command"].index("--path") + 1]
    lines.append(f"- `{label}` stage: `{stage}`; exact command/env/exit/SHA receipt: `{HERE / (label + '-receipt.json')}`.")
    for receipt in receipts:
        lines.append(f"  - {receipt['mode']}: `{json.dumps(receipt['command'])}`; environment `{json.dumps(receipt['environment'])}`; exit{receipt['exit']}/errors{receipt['errors']}.")
report = ROOT / ".superpowers/sdd/2026-11-18-jelly-trampoline/task-2-report.md"
report.write_text(report.read_text(encoding="utf-8") + "\n".join(lines) + "\n", encoding="utf-8")
print("Frozen nine owned files; final source closures verified; three raw tutorials copied byte-identically.")
