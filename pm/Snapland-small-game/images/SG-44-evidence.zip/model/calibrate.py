import math
from pathlib import Path

def shot(mass, height, x, tilt, charge, assist=False):
    d=min(1,charge/1.4); y=492+40*d; v=1000*d/math.sqrt(mass); vx=v*math.sin(math.radians(tilt)); vy=-v*math.cos(math.radians(tilt)); bell=False
    for i in range(700):
        nx=x+vx/120; ny=y+vy/120+450/14400; nv=vy+7.5
        if nx>1060: nx=1060-(nx-1060)*.85; vx*= -.85
        if nx<60: nx=60+(60-nx)*.85; vx*= -.85
        if ny<60: ny=60+(60-ny)*.6; nv*= -.6
        dx=nx-x;dy=ny-y;den=dx*dx+dy*dy
        t=max(0,min(1,((930-x)*dx+(190-y)*dy)/den)) if den else 0
        bell |= (x+dx*t-930)**2+(y+dy*t-190)**2 <= (70 if assist else 60)**2
        if nv>0 and y<=height-28<=ny:
            cx=x+(nx-x)*(height-28-y)/(ny-y)
            if abs(cx-870)<=(87 if assist else 62): return 'delivered',bell,i/120,cx
        if nv>0 and y<=492<=ny: return 'return',bell,i/120,x+(nx-x)*(492-y)/(ny-y)
        x,y,vy=nx,ny,nv
    return 'timeout',bell,0,x

if __name__=='__main__':
    for assist in (False,True):
        for mass,height in [(1,240),(1.15,260),(.9,220)]:
            for wantbell in (False,True):
                found=[]
                for x in range(180,501,40):
                    for tilt in (7,14,21,28,35):
                        for c in range(90,141,2):
                            r=shot(mass,height,x,tilt,c/100,assist)
                            if r[0]=='delivered' and r[1]==wantbell:
                                found.append((abs(r[3]-(915 if wantbell else 835)),x,tilt,c/100,r))
                print(assist,mass,height,wantbell,sorted(found)[:2])
    found=[]
    for mass,height in [(1,240),(1.15,260),(.9,220)]:
        for x in range(180,501,40):
            for tilt in (7,14,21,28,35):
                for c in range(90,141):
                    r=shot(mass,height,x,tilt,c/100)
                    if r[0]=='return' and r[1] and 138<=r[3]<=542: found.append((mass,height,x,tilt,c/100,r))
    print('BELL_CATCH',found[:15], 'count',len(found))
