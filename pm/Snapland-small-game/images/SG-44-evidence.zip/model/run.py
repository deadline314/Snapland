"""Owned fresh D: stage, exact fixture allowlist, validated Godot runs."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import uuid

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from tools.build_desktop_release import prepare_runtime_stage
from tools.godot_entrypoints import run_validated_godot

HERE = Path(__file__).resolve().parent
ENGINE = "C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe"
label = sys.argv[1]
base = Path("D:/Snapland-QA") / ("jelly_trampoline-model-" + label + "-" + uuid.uuid4().hex[:8])
stage = base / "project"
stage.mkdir(parents=True)
tracked = subprocess.check_output(["git", "ls-files", "-z"], cwd=ROOT, text=True, encoding="utf-8").split("\0")
manifest = prepare_runtime_stage(ROOT, stage, tracked)
for name in ["game/minigames/jelly_trampoline_model.gd", "game/tests/test_jelly_trampoline.gd"]:
    if label == "controlled-missing-model" and name.endswith("_model.gd"):
        continue
    source = ROOT / name
    if source.exists():
        destination = stage / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        manifest[name] = hashlib.sha256(source.read_bytes()).hexdigest()
receipts = []
for mode, args in [("import", ["--editor", "--import", "--quit"]), ("test", ["--script", "res://game/tests/test_jelly_trampoline.gd"])]:
    profile = base / (mode + "-profile")
    env = dict(os.environ, SNAPLAND_SAVE_PATH=str(profile / "progress.json"), APPDATA=str(profile / "appdata"),
               LOCALAPPDATA=str(profile / "localappdata"), TEMP=str(profile / "temp"), TMP=str(profile / "temp"))
    for key in ["APPDATA", "LOCALAPPDATA", "TEMP"]:
        Path(env[key]).mkdir(parents=True)
    cmd = [ENGINE, "--headless", "--path", str(stage), *args]
    result = run_validated_godot(stage, cmd, env, 300 if mode == "import" else 90)
    output = result.stdout + result.stderr
    (HERE / (label + "-" + mode + ".log")).write_text(output, encoding="utf-8")
    receipt = dict(mode=mode, command=cmd, environment={k: env[k] for k in ["SNAPLAND_SAVE_PATH", "APPDATA", "LOCALAPPDATA", "TEMP", "TMP"]},
                   exit=result.returncode, errors=output.count("ERROR:"), source_sha256=manifest)
    receipts.append(receipt)
    print(mode, "exit", result.returncode, "errors", receipt["errors"], flush=True)
    if mode == "test":
        print(output, flush=True)
    if mode == "import" and (result.returncode or "ERROR:" in output):
        break
(HERE / (label + "-receipt.json")).write_text(json.dumps(receipts, indent=2), encoding="utf-8")

