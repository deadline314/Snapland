"""Freeze an explicit archive input list for already reviewed Tasks 1–3."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
rows = {}


def add(path, category, expected=None, archive=None):
    path = Path(path).resolve()
    data = path.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if expected is not None:
        assert digest == expected, path
    key = archive or f"{path.parent.name}/{path.name}"
    assert key not in rows, key
    rows[key] = dict(path=str(path), archive=key, category=category,
                     sha256=digest, bytes=len(data))


def run_files(phase, prefixes, category):
    folder = ROOT / phase
    for prefix in prefixes:
        matches = sorted(p for p in folder.glob(prefix + '-*')
                         if p.suffix in ('.log', '.json'))
        assert matches, (phase, prefix)
        for path in matches:
            add(path, category)


for phase in ('model', 'presentation', 'integration'):
    add(ROOT / phase / 'evidence-index.json', 'phase-index')

run_files('model', ['fix1-preview-green'], 'promoted-model')
run_files('model', ['controlled-missing-model', 'draft-green', 'routes-v1',
                    'rules-v2', 'calibrated-v3', 'thresholds-v4', 'apex-red',
                    'final-green', 'fix1-preview-red'], 'historical-model')
for name in ('first-unvalidated-draft.gd', 'initial-wrong-entrypoint.txt',
             'red-attempt-reconstructed-receipt.json', 'red-import.log', 'run.py',
             'calibrate.py'):
    add(ROOT / 'model' / name, 'model-chronology-or-harness')

run_files('presentation', ['final-unit', 'native-final-1280x720',
                          'native-1152x648', 'native-800x600'],
          'promoted-presentation')
run_files('presentation', ['preimplementation-red'], 'historical-presentation')
for name in ('run.py', 'freeze.py', 'root-visual-review.md'):
    add(ROOT / 'presentation' / name, 'presentation-harness-or-observation')
presentation = json.loads((ROOT / 'presentation/evidence-index.json').read_text(encoding='utf-8'))
for run, images in presentation['raw_captures'].items():
    for path, digest in images.items():
        add(path, 'raw-presentation-png', digest,
            f'presentation/{run}/{Path(path).name}')

integration = json.loads((ROOT / 'integration/evidence-index.json').read_text(encoding='utf-8'))
receipt_names = set()
for name, result in integration['promoted_runtime_results'].items():
    add(ROOT / 'integration' / result['log'], 'promoted-integration-log',
        result['log_sha256'])
    receipt_names.add(result['receipt'])
for name in sorted(receipt_names):
    add(ROOT / 'integration' / name, 'selected-receipt-with-explicit-exclusions')
for prefix in ('pre-wiring-baseline', 'pre-wiring-red', 'fix1-red', 'fix1-green'):
    run_files('integration', [prefix], 'historical-not-promoted')
for name in ('boundary-receipt.json', 'fixture-launch-audit.json',
             'fix1-final-green-prelaunch-closure-audit.json',
             'python-final-receipt.json', 'run.py', 'audit_closure.py',
             'fixtures.py', 'freeze.py', 'verify.py', 'wire.py', 'fix1_report.py'):
    add(ROOT / 'integration' / name, 'integration-audit-or-harness')
for result in integration['python_log_hashes']:
    add(ROOT / 'integration' / result['log'], 'promoted-python-raw-log',
        result['raw_byte_sha256'])

output = ROOT / 'phase-archive-inputs.json'
output.write_text(json.dumps({'scope': 'Tasks 1–3 selected evidence plus labelled historical limitations; no Task4 acceptance',
                             'files': list(rows.values())}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'manifest': str(output), 'files': len(rows),
                  'bytes': sum(row['bytes'] for row in rows.values())}))
