"""Package only explicitly retained SG44 evidence after the final review."""
import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent
WORKSPACE = REPO / '.superpowers/sdd/2026-11-18-jelly-trampoline'
OUTPUT = REPO / 'pm/Snapland-small-game/images/SG-44-evidence.zip'
rows = {}
paths = set()


def add(path, category, expected=None, size=None, archive=None):
    path = Path(path).resolve()
    if path in paths:
        return
    data = path.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    assert expected is None or digest == expected, path
    assert size is None or len(data) == size, path
    if archive is None:
        if path.is_relative_to(ROOT / 'native'):
            archive = 'native/' + path.relative_to(ROOT / 'native').as_posix()
        elif path.is_relative_to(WORKSPACE):
            archive = 'reviews/' + path.relative_to(WORKSPACE).as_posix()
        elif path.is_relative_to(REPO):
            archive = 'source/' + path.relative_to(REPO).as_posix()
        else:
            archive = 'native/runs/' + path.relative_to(Path('D:/Snapland-QA')).as_posix()
    assert archive not in rows and not archive.startswith('/') and '..' not in Path(archive).parts, archive
    rows[archive] = dict(path=str(path), archive=archive, category=category,
                         sha256=digest, bytes=len(data))
    paths.add(path)


assert not OUTPUT.exists(), 'Do not overwrite a delivered evidence archive.'
for row in json.loads((ROOT / 'phase-archive-inputs.json').read_text(encoding='utf-8'))['files']:
    add(row['path'], row['category'], row['sha256'], row['bytes'], row['archive'])
for row in json.loads((ROOT / 'native/public-archive-inputs.json').read_text(encoding='utf-8'))['files']:
    add(row['path'], row['category'], row['sha256'], row['bytes'])

for name in ('progress.md', 'task-1-brief.md', 'task-1-report.md', 'task-1-review.md',
             'task-1-rereview-1.md', 'task-2-brief.md', 'task-2-report.md', 'task-2-review.md',
             'task-3-brief.md', 'task-3-report.md', 'task-3-review.md', 'task-3-rereview-1.md',
             'task-4-brief.md', 'task-4-report.md', 'task-4-review.md', 'final-review.md'):
    add(WORKSPACE / name, 'requirements-review-and-rulings')
for name in ('design/runtime/jelly-trampoline-gameplay.md',
             'docs/superpowers/plans/2026-11-18-jelly-trampoline.md'):
    add(REPO / name, 'design-authority-or-plan')
for pattern in ('review-*.diff', 'task-4-rereview-*.md', 'final-rereview*.md'):
    for path in sorted(WORKSPACE.glob(pattern)):
        add(path, 'review-package-or-scoped-followup')
for name in ('native/root-visual-review.md', 'native/root-freeze-verification.json',
             'merged-checks/integrated-feature-ci.json', 'merged-checks/source-commits.json', 'phase-archive-inputs.json',
             'pm-image-provenance.json', 'rulings.md', 'final-dispositions.md', 'prepare-phase-archive.py', 'build-public-archive.py'):
    add(ROOT / name, 'controller-evidence-and-packaging', archive='controller/' + name)

manifest = dict(scope='SG44 selected passing evidence plus explicitly labelled historical limitations; no human play, hearing, art naturalness, physical touch hardware, walking or earned-admission claim.',
                files=list(rows.values()))
OUTPUT.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(OUTPUT, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for row in rows.values():
        archive.write(row['path'], row['archive'])
    archive.writestr('MANIFEST.json', json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
with zipfile.ZipFile(OUTPUT) as archive:
    assert archive.testzip() is None
    for row in rows.values():
        assert hashlib.sha256(archive.read(row['archive'])).hexdigest() == row['sha256'], row['archive']
result = dict(archive=str(OUTPUT), entries=len(rows) + 1, bytes=OUTPUT.stat().st_size,
              sha256=hashlib.sha256(OUTPUT.read_bytes()).hexdigest())
(ROOT / 'archive-result.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result))
