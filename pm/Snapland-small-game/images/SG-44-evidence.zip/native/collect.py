"""Read-only freeze of exact current passing processes, source graph, raw PNGs and archive inputs."""
from run import *
import struct
LABELS=['current1280','current1152','final800','retake1280ordinary','retake1280devil','retake800ordinary','retake1152devil','qa-final']
def file_info(path,category=None):
    path=Path(path);value=dict(path=str(path),sha256=sha(path),bytes=path.stat().st_size)
    if category: value['category']=category
    return value

def collect():
    cases=[];inputs={};stage_infos=[]
    def include(path,category):
        value=file_info(path,category);inputs[value['path']]=value
    for label in LABELS:
        stage_info=json.loads((HERE/(label+'-stage.json')).read_bytes());stage_infos.append(stage_info)
        for part in [('suite' if label in ['current1280','current1152','final800','qa-final'] else 'retake-devil' if label.endswith('devil') else 'retake-ordinary'),'read']:
            name=label+'-'+part
            receipt_path=HERE/(name+'-receipt.json');r=json.loads(receipt_path.read_bytes())
            assert r['exit']==0 and r['errors']==0 and not r['leak_diagnostics'] and r['marker_count']==1 and r['pass_all_guards'],name
            assert sha(r['log'])==r['log_sha256'] and sha(r['stdio'])==r['stdio_sha256'] and sha(r['audit'])==r['audit_sha256']
            audit_data=json.loads(Path(r['audit']).read_bytes());assert not audit_data['process_launch_calls']
            assert all(sha(Path(stage_info['stage'])/n)==digest for n,digest in audit_data['source_sha256'].items())
            folder=Path(r['environment']['JELLY_CAPTURE_DIR']);physical=json.loads((folder/'physical-report.json').read_bytes());report=json.loads((folder/'report.json').read_bytes())
            assert not physical['failures'] and not report['failures'],name
            logs=Path(r['log']).read_text(encoding='utf-8');assert 'Godot Engine v4.7.2.stable.official.ed1daf0bf' in logs
            assert 'Vulkan' in logs and 'AMD Radeon RX 9070 XT' in logs
            if part=='suite':
                expected=[(True,False,False,False,True,400),(True,True,False,False,True,500),(True,True,True,False,True,500),(True,True,False,True,False,500),(False,False,False,False,True,0),(True,True,False,True,False,500)]
                actual=[tuple(x[k] for k in ['success','devil','assisted','practice','ordinary_eligible','score']) for x in report['results']]
                assert actual==expected,(name,actual)
                assert all(x['game_id']=='game-028' and x['score_summary']['total']==x['score'] for x in report['results'])
                assert [x['label'] for x in physical['gameplay_capture_history']]==['ordinary','devil','assisted-ai','timeout']
            pngs=[]
            for path in sorted(folder.glob('*.png')):
                raw=path.read_bytes();assert raw[:8]==b'\x89PNG\r\n\x1a\n'
                width,height=struct.unpack('>II',raw[16:24]);assert f'{width}x{height}'==r['environment']['JELLY_REVIEW_SIZE']
                pngs.append(dict(**file_info(path),size=[width,height]));include(path,'raw-Main-viewport-PNG')
            assert len(pngs)==len(report['captures'])
            for files in physical['original_hashes'].values():
                for path,digest in files.items():assert sha(path)==digest
            for path,category in [(receipt_path,'process-receipt'),(r['log'],'raw-engine-UTF8-log'),(r['stdio'],'raw-launcher-stdio'),(r['audit'],'prelaunch-source-audit'),(folder/'physical-report.json','physical-report'),(folder/'report.json','native-Main-report')]: include(path,category)
            profile=Path(r['environment']['SNAPLAND_SAVE_PATH']).parent
            include(profile/'native-originals.json','writer-photo-provenance-receipt')
            provenance=json.loads((profile/'native-originals.json').read_bytes());assert provenance['coins']==160
            assert 'ACH_GAME_028' in json.loads((profile/'progress.json').read_bytes())['achievements']
            for photo,record in provenance['photos'].items():
                if not photo.startswith('photo-candy-'):continue
                assert photo in ['photo-candy-game-4','photo-candy-devil-4']
                for key in ['original_frames','frames']:
                    for path in record.get(key,[]):include(path,'GPU-original' if key=='original_frames' else 'saved-320x180-thumbnail')
            cases.append(dict(label=name,process=r,checks_before_audio_cleanup=physical['checks'],captures=pngs,results=report['results'],gameplay_capture_history=physical['gameplay_capture_history'],current_original_hashes=physical['original_hashes'],writer_provenance=file_info(profile/'native-originals.json')))
        for kind in ['stage.json','import-receipt.json','import.log','import-stdio.log','import-prelaunch-audit.json']:
            include(HERE/(label+'-'+kind),'source-stage-or-import-audit')
    first=stage_infos[0]['source_sha256']
    assert all(info['source_sha256']==first for info in stage_infos),'all current native and QA source graphs identical'
    assert all(sha(ROOT/n)==digest for n,digest in first.items()),'current workspace equals every source graph'
    build=json.loads((HERE/'qa-final-build.json').read_bytes())
    assert all(sha(Path(build['stage'])/n)==digest for n,digest in build['runtime_sha256'].items())
    assert sha(build['binary']['path'])==build['binary']['sha256']
    for t in build['templates'].values():assert sha(t['path'])==t['sha256']
    for name in FIXTURES:include(ROOT/name,'exact-fixture-source')
    for name in ['game/main.gd','game/minigames/session.gd','game/minigames/jelly_trampoline_model.gd','game/minigames/jelly_trampoline_driver.gd','game/minigames/jelly_trampoline_view.gd','game/world/candy_world.gd','assets/ui/tutorials/game-028-step-01.png','assets/ui/tutorials/game-028-step-02.png','assets/ui/tutorials/game-028-step-03.png']:include(ROOT/name,'current-source-identity')
    for name in ['qa-final-build.json','qa-final-export-receipt.json','qa-final-export.log','qa-final-export-stdio.log','qa-final-export-prelaunch-audit.json','run.py','matrix.py','package.py','collect.py']:include(HERE/name,'QA-build-or-reproduction')
    for name in ['build.json','acceptance.json']:include(Path(build['base'])/name,'embedded-exe-identity-acceptance')
    rejected=[]
    for path in sorted(HERE.glob('*-receipt.json')):
        if path.stem.removesuffix('-receipt') not in {c['label'] for c in cases} and not path.name.startswith(tuple(x+'-import' for x in LABELS)) and not path.name.startswith('qa-final-export'):
            rejected.append(file_info(path))
    manifest=dict(status='FROZEN current-source Task4 automated Main native and embedded QA acceptance',cases=cases,source_sha256=first,fixture_source_sha256={n:first[n] for n in FIXTURES},source_count=len(first),qa_build=build,rejected_or_superseded_receipts=rejected,engine_graphical_binary=file_info(Path(ENGINE).with_name('Godot_v4.7.2-stable_win64.exe')))
    dump(HERE/'promoted-native.json',manifest);include(HERE/'promoted-native.json','frozen-process-source-PNG-index')
    dump(HERE/'public-archive-inputs.json',dict(scope='Explicit current passing evidence only; no executable, player profile, rejected candidate or whole stage',files=list(inputs.values())))
    print('PASS promoted',len(cases),'processes',sum(len(c['captures']) for c in cases),'raw PNGs',len(inputs),'archive files',flush=True)
    return manifest
if __name__=='__main__':collect()
