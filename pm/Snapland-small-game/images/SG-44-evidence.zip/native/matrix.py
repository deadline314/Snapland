from run import native
cases=[('final800','800x600','suite'),('retake1280ordinary','1280x720','retake-ordinary'),('retake1280devil','1280x720','retake-devil'),('retake800ordinary','800x600','retake-ordinary'),('retake1152devil','1152x648','retake-devil')]
if __name__=='__main__':
    for case in cases: native(*case)
