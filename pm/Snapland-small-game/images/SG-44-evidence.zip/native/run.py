"""Fresh D tracked-runtime/explicit-fixture staging and prelaunch audits, never child launches."""
import hashlib,json,os,re,shutil,subprocess,sys,uuid
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from tools.build_desktop_release import prepare_runtime_stage
from tools.godot_entrypoints import run_validated_godot
ENGINE='C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe'
FIXTURES=['game/tests/native_jelly_trampoline_main.gd','game/tests/native_jelly_trampoline_main.tscn','game/tests/native_sugar_bridge_main.gd','game/tests/audio_playback_release.gd']
MARKER='PASS: native jelly Main genuine inputs, real fruit bell deliveries, GPU originals and restart'
KEYS=['SNAPLAND_SAVE_PATH','APPDATA','LOCALAPPDATA','TEMP','TMP','JELLY_CAPTURE_DIR','JELLY_REVIEW_MODE','JELLY_REVIEW_SIZE']
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,v): Path(p).write_bytes(json.dumps(v,indent=2,ensure_ascii=False).encode('utf-8'))
def environment(base,profile,mode='',size='1280x720'):
    env=dict(os.environ,SNAPLAND_SAVE_PATH=str(profile/'progress.json'),APPDATA=str(base/'appdata'),LOCALAPPDATA=str(base/'localappdata'),TEMP=str(base/'temp'),TMP=str(base/'temp'),JELLY_CAPTURE_DIR=str(base/'captures'),JELLY_REVIEW_MODE=mode,JELLY_REVIEW_SIZE=size)
    for k in KEYS:
        assert Path(env[k]).is_absolute() and Path(env[k]).drive.upper()=='D:' if k not in ['JELLY_REVIEW_MODE','JELLY_REVIEW_SIZE'] else True
    for k in ['APPDATA','LOCALAPPDATA','TEMP']: Path(env[k]).mkdir(parents=True,exist_ok=True)
    return env

def audit(stage,label):
    # Whole staged source audit is stronger than only literal refs, covering dynamic load and named inheritance.
    sources={p.relative_to(stage).as_posix():sha(p) for p in stage.rglob('*') if p.is_file() and p.suffix in ['.gd','.tscn']}
    tests={n for n in sources if n.startswith('game/tests/')}
    assert tests==set(FIXTURES),tests
    launches=[]
    for name in sources:
        for number,line in enumerate((stage/name).read_text(encoding='utf-8').splitlines(),1):
            if re.search(r'OS\s*\.\s*(?:execute|create_process|execute_with_pipe|create_instance)\s*\(',line): launches.append(dict(file=name,line=number,source=line.strip()))
    record=dict(stage=str(stage),scope='every staged gd/tscn including exact entry, inherited base, all transitive helpers, dynamic-load runtime and autoloads',fixture_allowlist=FIXTURES,source_sha256=sources,process_launch_calls=launches)
    path=HERE/(label+'-prelaunch-audit.json');dump(path,record)
    assert not launches,launches
    return path

def run(stage,command,env,label,marker=None,release=None):
    audit_path=audit(stage,label)
    engine_log=Path(env['TEMP']).parent/'engine.log'
    command=command+['--log-file',str(engine_log)]
    result=run_validated_godot(stage,command,env,300,release_directory=release)
    stdio=HERE/(label+'-stdio.log');stdio.write_bytes((result.stdout+result.stderr).encode('utf-8'))
    log=HERE/(label+'.log')
    raw=engine_log.read_bytes() if engine_log.exists() else (result.stdout+result.stderr).encode('utf-8')
    log.write_bytes(raw);body=raw.decode('utf-8',errors='replace')
    errors=len(re.findall(r'(?:SCRIPT )?ERROR:',body))
    leaks=re.findall(r'(?im)^.*(?:ObjectDB instances leaked|resources still in use|\b\d+\s+RIDs?\s+(?:of type .*?)?were leaked|Leaked instance:|still in use at exit|RID allocations.*leaked).*$',body)
    count=body.splitlines().count(marker) if marker else None
    ok=result.returncode==0 and errors==0 and not leaks and (marker is None or count==1)
    receipt=dict(command=command,environment={k:env[k] for k in KEYS},exit=result.returncode,errors=errors,leak_diagnostics=leaks,marker_count=count,pass_all_guards=ok,log=str(log),log_sha256=sha(log),log_bytes=len(raw),stdio=str(stdio),stdio_sha256=sha(stdio),audit=str(audit_path),audit_sha256=sha(audit_path),release_directory=str(release) if release else None)
    dump(HERE/(label+'-receipt.json'),receipt)
    print(label,result.returncode,errors,ok,flush=True)
    if not ok: print(body[-11000:],flush=True);raise RuntimeError(label+' failed strict guards')
    return receipt

def stage_new(label):
    base=Path('D:/Snapland-QA')/('jelly-native-'+label+'-'+uuid.uuid4().hex[:8]);stage=base/'project';stage.mkdir(parents=True)
    tracked=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT,text=True,encoding='utf-8').split('\0')
    tracked=[n for n in tracked if not n.endswith(('.uid','.import'))]
    manifest=prepare_runtime_stage(ROOT,stage,tracked)
    for name in FIXTURES:
        target=stage/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/name,target);manifest[name]=sha(target)
    info=dict(base=str(base),stage=str(stage),source_sha256=manifest,qa_fixture_allowlist=FIXTURES,engine=dict(path=ENGINE,sha256=sha(ENGINE)),source_commit_base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip())
    dump(base/'source-manifest.json',info);dump(HERE/(label+'-stage.json'),info)
    run(stage,[ENGINE,'--headless','--path',str(stage),'--editor','--import','--quit'],environment(base/'import',base/'import-profile'),label+'-import')
    return base,stage

def native(label,size,mode):
    base,stage=stage_new(label);profile=base/'writer-profile';assert not profile.exists()
    for part in [mode,'read']:
        run(stage,[ENGINE,'--path',str(stage),'res://game/tests/native_jelly_trampoline_main.tscn'],environment(base/(part+'-process'),profile,part,size),label+'-'+part,MARKER)
    return base,stage
if __name__=='__main__': native(*sys.argv[1:4])
