"""Post-freeze EOF-only hygiene; no engine launch, Git action, stage/receipt/log/PNG mutation."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];HERE=Path(__file__).resolve().parent
NAME='game/tests/native_jelly_trampoline_main.gd'
def sha_bytes(raw):return hashlib.sha256(raw).hexdigest()
def sha(path):return sha_bytes(Path(path).read_bytes())
def dump(path,value):Path(path).write_bytes(json.dumps(value,ensure_ascii=False,indent=2).encode('utf-8'))
index_path=HERE/'promoted-native.json';index=json.loads(index_path.read_bytes())
executed_manifest=index['source_sha256'];executed_sha=executed_manifest[NAME]
assert executed_sha=='a3a5dca72aad8355bf506e239fcfadae28e1a16905a13b15f2032759c8923956'
first=index['cases'][0];stage=Path(json.loads(Path(first['process']['audit']).read_bytes())['stage'])
executed_path=stage/NAME;old=executed_path.read_bytes();assert sha_bytes(old)==executed_sha
assert old.endswith(b'\r\n\r\n') and not old.endswith(b'\r\n\r\n\r\n')
new=old[:-2];path=ROOT/NAME
assert path.read_bytes() in (old,new)
if path.read_bytes()==old:path.write_bytes(new)
assert path.read_bytes()==new and old==new+b'\r\n'
assert old.rstrip(b'\r\n')==new.rstrip(b'\r\n')
checkout_sha=sha_bytes(new)
unchanged=[n for n,h in executed_manifest.items() if n!=NAME and sha(ROOT/n)==h]
assert len(unchanged)==len(executed_manifest)-1
# Every accepted audit retains the old executed source; no accepted artifact is rewritten.
for case in index['cases']:
    audit=json.loads(Path(case['process']['audit']).read_bytes())
    assert audit['source_sha256'][NAME]==executed_sha
    assert sha(Path(audit['stage'])/NAME)==executed_sha
    assert sha(case['process']['log'])==case['process']['log_sha256']
proof=dict(scope='Only final checkout fixture EOF whitespace; accepted executed stages/receipts/logs/PNG/exe unchanged',file=NAME,executed_source=dict(path=str(executed_path),sha256=executed_sha,bytes=len(old)),final_checkout=dict(path=str(path),sha256=checkout_sha,bytes=len(new)),exact_delta=dict(removed_bytes_hex='0d0a',offset_zero_based=len(new),statement='executed bytes equal final checkout bytes followed by exactly one CRLF'),checks=dict(exact_old_equals_new_plus_one_CRLF=True,exact_bytes_equal_after_stripping_only_final_CR_LF=True,unchanged_other_checkout_source_count=len(unchanged),accepted_runtime_audits_verified=len(index['cases']),engine_rerun=False,accepted_artifacts_modified=False))
proof_path=HERE/'source-hygiene.json';dump(proof_path,proof)
index['status']='FROZEN executed-source Task4 acceptance; final checkout has separately verified one-CRLF EOF hygiene'
index['source_sha256_semantics']='Exact executed source bytes; retained unchanged, not a claim of exact final checkout byte identity for the one fixture listed in source_hygiene.'
index['checkout_source_sha256']={**executed_manifest,NAME:checkout_sha}
index['source_hygiene']=dict(path=str(proof_path),sha256=sha(proof_path),bytes=proof_path.stat().st_size,executed_sha256=executed_sha,checkout_sha256=checkout_sha)
dump(index_path,index)
report_path=ROOT/'.superpowers/sdd/2026-11-18-jelly-trampoline/task-4-report.md';report=report_path.read_text(encoding='utf-8')
report=report.replace('All 967 tracked-runtime plus exact-fixture source hashes match the current workspace and every promoted native/independent QA source graph.','All 967 original executed source hashes match every promoted native/independent QA source graph. After the post-freeze EOF hygiene described below,966 still match the final checkout exactly; the one fixture differs by exactly one removed final CRLF, with explicit byte-equivalence proof. This is not exact967-file final-checkout byte identity.')
report=report.replace('## Exact source identities','## Exact executed source identities')
report=report.replace('| File | Raw-byte SHA256 |','The following table retains the actual **executed** raw-byte identities. Final checkout fixture identity is separately recorded below; no engine was rerun after whitespace cleanup.\n\n| File | Executed raw-byte SHA256 |')
report=report.replace('All final dimensions were rerun under the current final source.','All final dimensions were run under the executed functional source, before the later one-CRLF EOF-only hygiene below.')
marker='\n## Post-freeze EOF-only source hygiene\n'
if marker in report:report=report.split(marker)[0]
report += f'''\n## Post-freeze EOF-only source hygiene

Root precommit `git diff --cached --check` found one extra blank line at EOF in the new native fixture. Removed only its final CRLF; no game logic, earlier newline, other source, Git/index state, accepted stage, receipt, log, PNG, template or executable was changed. No engine/import/export was rerun.

- Actual executed fixture: `{executed_sha}`, {len(old)} bytes.
- Final checkout fixture: `{checkout_sha}`, {len(new)} bytes.
- Exact byte proof: executed bytes equal final checkout bytes followed by two-byte `0d0a`, removed at zero-based offset{len(new)}. The complete bytes are also identical after stripping only final CR/LF bytes; this is stronger than a textual/semantic comparison.
- The other966 source files still match their executed raw-byte hashes exactly. All16 accepted runtime audits/stages retain the old executed fixture hash and bytes. The independent executable retains the executed pre-cleanup fixture; its recorded SHA and all acceptance remain unchanged.

`.review/jelly-trampoline-20261118/native/source-hygiene.json` retains the actual executed-stage path, both raw hashes/byte counts and exact comparison checks. `promoted-native.json` keeps `source_sha256`/`fixture_source_sha256` as executed bytes, labels those semantics, and adds separate `checkout_source_sha256` and source-hygiene provenance. The metadata generator freeze.py now refuses to regenerate the historical freeze when this post-freeze proof exists. The public allowlist updates only the changed checkout fixture/report/index/freeze metadata and adds this proof/updater; no historical receipt/log/PNG hash is rewritten.
'''
report_path.write_bytes(report.encode('utf-8'))
freeze_path=HERE/'freeze.py';freeze=freeze_path.read_text(encoding='utf-8')
needle="from collect import *\n"
guard="if (HERE/'source-hygiene.json').exists():\n    raise SystemExit('Historical executed-source freeze retained; see source-hygiene.json for final checkout EOF-only equivalence. No regeneration or engine rerun.')\n"
assert needle in freeze
if guard not in freeze:freeze=freeze.replace(needle,needle+guard,1)
freeze_path.write_bytes(freeze.encode('utf-8'))
allow_path=HERE/'public-archive-inputs.json';allow=json.loads(allow_path.read_bytes())
changed={str(path),str(report_path),str(index_path),str(freeze_path)}
updated=[]
for row in allow['files']:
    p=Path(row['path']);digest=sha(p);size=p.stat().st_size
    if str(p) in changed:
        if row['sha256']!=digest:updated.append(str(p))
        row['sha256']=digest;row['bytes']=size
    else:assert row['sha256']==digest and row['bytes']==size,p
existing={r['path'] for r in allow['files']}
for p,category in [(proof_path,'post-freeze-exact-byte-source-equivalence'),(Path(__file__).resolve(),'post-freeze-metadata-updater')]:
    row=dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size,category=category)
    if str(p) in existing:
        for r in allow['files']:
            if r['path']==str(p):r.update(row)
    else:allow['files'].append(row)
allow['post_freeze_hygiene']='Accepted artifacts unchanged; one final fixture LF removed and changed current-source/report/index/freeze metadata hashes refreshed, with explicit executed-vs-checkout proof.'
dump(allow_path,allow)
assert len(updated)==4,updated
assert all(sha(r['path'])==r['sha256'] and Path(r['path']).stat().st_size==r['bytes'] for r in allow['files'])
print('DONE EOF-only hygiene:',executed_sha,'->',checkout_sha,'removed1 CRLF;',len(allow['files']),'allowlist files verified;',len(unchanged),'other source files unchanged; no engine/Git/stage changes')
