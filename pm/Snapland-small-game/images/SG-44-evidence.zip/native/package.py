"""New independent D-only explicit QA closure; unchanged normal source entry/exclusions."""
from run import *
label='qa-final'
base,stage=stage_new(label)
normal_main=(ROOT/'project.godot').read_bytes();normal_presets=(ROOT/'export_presets.cfg').read_bytes()
project=stage/'project.godot'
body=project.read_text(encoding='utf-8')
assert body.count('run/main_scene="res://game/main.tscn"')==1
project.write_bytes(body.replace('run/main_scene="res://game/main.tscn"','run/main_scene="res://game/tests/native_jelly_trampoline_main.tscn"').encode('utf-8'))
template_root=Path(os.environ['APPDATA'])/'Godot/export_templates/4.7.2.stable'
assert (template_root/'version.txt').read_text().strip()=='4.7.2.stable'
pinned={'debug':'51498b72b3a237f882ebd7d1787f06a4bc1eaf0572daab93837adcfd3cfdc107','release':'d34d36f3be1a6c49c56525ae86469b92e4f417ddf0b43cf00dd80c385c4b0562'}
templates={}
preset=stage/'export_presets.cfg';body=preset.read_text(encoding='utf-8').replace('game/tests/*,','',1)
for kind,digest in pinned.items():
    source=template_root/('windows_'+kind+'_x86_64.exe');assert sha(source)==digest
    target=base/'templates'/source.name;target.parent.mkdir(exist_ok=True);shutil.copy2(source,target);assert sha(target)==digest
    templates[kind]=dict(source=str(source),path=str(target),sha256=digest,bytes=target.stat().st_size)
    body=body.replace('custom_template/'+kind+'=""','custom_template/'+kind+'="'+target.as_posix()+'"',1)
preset.write_bytes(body.encode('utf-8'))
release=base/'release';release.mkdir();binary=release/'JellyTrampolineQA.exe'
run(stage,[ENGINE,'--headless','--path',str(stage),'--editor','--export-release','Windows Desktop',str(binary),'--quit'],environment(base/'export',base/'export-profile'),label+'-export')
assert binary.is_file() and binary.read_bytes()[:2]==b'MZ' and binary.stat().st_size>templates['release']['bytes']
source=json.loads((HERE/(label+'-stage.json')).read_bytes());runtime={n:sha(stage/n) for n in source['source_sha256']}
manifest=dict(base=str(base),stage=str(stage),source_commit_base=source['source_commit_base'],source_sha256=source['source_sha256'],runtime_sha256=runtime,engine=source['engine'],templates=templates,qa_fixture_allowlist=FIXTURES,qa_only_overrides=['project.godot run/main_scene','Windows export preset fixture inclusion and pinned D templates'],binary=dict(path=str(binary),sha256=sha(binary),bytes=binary.stat().st_size),normal_player_main_preserved=True,normal_export_exclusions_preserved=True)
dump(base/'build.json',manifest);dump(HERE/(label+'-build.json'),manifest)
profile=base/'embedded-writer-profile';assert not profile.exists()
receipts=[]
for mode in ['suite','read']:
    receipts.append(run(stage,[str(binary)],environment(base/(mode+'-process'),profile,mode,'1280x720'),label+'-'+mode,MARKER,release))
assert all(sha(ROOT/n)==digest for n,digest in source['source_sha256'].items())
assert sha(binary)==manifest['binary']['sha256'] and (ROOT/'project.godot').read_bytes()==normal_main and (ROOT/'export_presets.cfg').read_bytes()==normal_presets
dump(base/'acceptance.json',dict(receipts=receipts,source_hashes_verified=len(runtime),binary_sha256_verified=True))
print('PASS: independent embedded Windows QA executable writer and new-process reader',flush=True)
