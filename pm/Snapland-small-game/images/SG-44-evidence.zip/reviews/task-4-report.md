# Task 4 frozen producer report

Status: DONE/frozen. Root owns exact-source commit, fresh Task4 review, whole-branch review, PM/public archive/Git/main/CI delivery. Only the new native Jelly Main .gd/.tscn, private native orchestration/evidence and this requested report were authored. No production, Model/Driver/View, tutorial PNG, unchanged Sugar base/audio helper, PM, Git/index/HEAD, old QA package or player profile was changed.

Effective source base: `22d2c2c58c6327e7954609c534f99616100abd21`. All 967 original executed source hashes match every promoted native/independent QA source graph. After the post-freeze EOF hygiene described below,966 still match the final checkout exactly; the one fixture differs by exactly one removed final CRLF, with explicit byte-equivalence proof. This is not exact967-file final-checkout byte identity. QA-only runtime config overrides are separately hashed. No engine execution follows this final metadata freeze.

## Exact executed source identities

The following table retains the actual **executed** raw-byte identities. Final checkout fixture identity is separately recorded below; no engine was rerun after whitespace cleanup.

| File | Executed raw-byte SHA256 |
|---|---|
| `game/tests/native_jelly_trampoline_main.gd` | `a3a5dca72aad8355bf506e239fcfadae28e1a16905a13b15f2032759c8923956` |
| `game/tests/native_jelly_trampoline_main.tscn` | `98cfe221694c2b1e5f3ddb3ced68d3ca19ebe230682128da0ac351270c6e5b83` |
| `game/tests/native_sugar_bridge_main.gd` | `f802c6de3c6ae892ae2895a13cff7917a13d14b857082267ce1910a7024524d7` |
| `game/tests/audio_playback_release.gd` | `1b61bba4e5c54e38050e8ba0b7170b18848198928937ca2c4dfdebc31cc37184` |
| `game/main.gd` | `504296500e1176becdafbf984d567dc77266cad5be4f77544e02ce92613c854f` |
| `game/minigames/session.gd` | `e7eb06b478313d7c46a487f11bf67cf9941f1413acf077cb799aa51c66824cda` |
| `game/minigames/jelly_trampoline_model.gd` | `86134f411bae5c41bee6732340155bb06ca6991d85b9e98ef5b5191bd90cf822` |
| `game/minigames/jelly_trampoline_driver.gd` | `9b03f31b464a09fb5896438ca61d5c7f6d44e59606f92d47938357b2821887b7` |
| `game/minigames/jelly_trampoline_view.gd` | `33c8f3e5a5038004e95e781cd8f43093c6d83184ddd83d9115a5d9def7097b11` |
| `game/world/candy_world.gd` | `21a8b8ff07ee30af336a76d5f22fe67b27514583204c04342394fca0b9e9d3e3` |
| `assets/ui/tutorials/game-028-step-01.png` | `ef2fa79e4890b25878323f7b63a62265af52ebf5176d7a1c56b4f406a19d3fa9` |
| `assets/ui/tutorials/game-028-step-02.png` | `44dd41c0497d68c9ef917253eda892435844f2038aee07af3d3eef48c01c7a24` |
| `assets/ui/tutorials/game-028-step-03.png` | `0a400080054a61667b52259b6ba0dd74805cedb1b678948cc14bd1211db7dcbf` |

Full source, process, PNG, original-photo and executable identities: `.review/jelly-trampoline-20261118/native/promoted-native.json`. Public inputs: `public-archive-inputs.json` in that directory; every allowlisted existing file has absolute path, raw-byte SHA256, category and byte count. Nothing failed/superseded is promoted.

## Accepted finite cases

**16 passing runtime processes / eight writer-reader pairs; 438 raw viewport PNGs.** Every accepted process returned exit0, zero ERROR entries, zero genuine leak/still-in-use diagnostics, exact completion marker once, empty fixture failure arrays and successful unchanged house audio release. Guard counts below precede the inherited final audio-release check.

| Process | Guards | Raw PNGs | Natural results |
|---|---:|---:|---:|
| `current1280-suite` | 2101 | 71 | 6 |
| `current1280-read` | 68 | 1 | 0 |
| `current1152-suite` | 2079 | 71 | 6 |
| `current1152-read` | 52 | 1 | 0 |
| `final800-suite` | 2483 | 80 | 6 |
| `final800-read` | 50 | 1 | 0 |
| `retake1280ordinary-retake-ordinary` | 976 | 31 | 1 |
| `retake1280ordinary-read` | 66 | 1 | 0 |
| `retake1280devil-retake-devil` | 1041 | 33 | 1 |
| `retake1280devil-read` | 68 | 1 | 0 |
| `retake800ordinary-retake-ordinary` | 1366 | 40 | 1 |
| `retake800ordinary-read` | 48 | 1 | 0 |
| `retake1152devil-retake-devil` | 1019 | 33 | 1 |
| `retake1152devil-read` | 52 | 1 | 0 |
| `qa-final-suite` | 2101 | 71 | 6 |
| `qa-final-read` | 68 | 1 | 0 |

Three real Main suite writers run physical1280×720,1152×648 and800×600;800 uses UI1.25/reduced motion. The independent embedded exe repeats the1280 suite. Each enters actual factory nearest/E invitation after disclosed controlled placement, opens the focused regional map/four-entry callback, traverses all five ordered rule pages via actual Next callbacks, then three decoded tutorial images and **every semantic copy page for each image** via focused TutorialCopyNext callbacks. All captured active Button/Label/RichTextLabel rectangles fit physical viewport and clipping ancestors; Button string widths/Label line heights and seven transformed View-control rectangles are checked. Inactive semantic groups are explicitly excluded because the house pager scrolls rather than hides them.

Input is genuine Input.parse_input_event through the real focused GUI/View and normal Session driver/process. Keyboard, mouse and synthetic screen-touch APIs configure bed/slant, held depth/trajectory and manual release. The fixture disables automatic Session processing and supplies deterministic finite delta to its real _process; no direct _unhandled_input fallback, model stepping/injection, result/card/score/bell/achievement/coin/photo injection is used. Public snapshot decisions choose the frozen published physical recipes.

Each suite naturally produces ordinary400, bell-devil500, assisted-AI-devil500, optional recovered-bell practice500, participated timeout failure0, and successful practice500. Practice results remain ineligible. Three actual high-platform deliveries and the same bell-touched fruit delivery determine success/devil. AI only catches a real returning fruit and waits for subsequent manual hold/release; ordinary/devil completion does not require AI or recatch. The optional A recipe proves actual bell contact, right-wall reflection, moved-bed recatch and manual third delivery; actual pause→RetryButton→ConfirmAction selects A after Main practice mode initially selects B.

Separate real practice routes prove X preserves completed deliveries/bell checkpoints, clears an unfinished bell on the current flying fruit, charges the appropriate mistake and never refunds elapsed time; actual natural loss resets normal progress while assisted loss preserves completed checkpoints. Pause clears held charge and freezes time/fruit; real HUD leave/confirm cancels without awards. Actual album and four-entry achievement book are captured. Fixed identity remains game-028/jelly_trampoline/candy local4/photo-candy-game-4/photo-candy-devil-4/ACH_GAME_028. Current catalog-derived physical sign visibly reads4/12. Older factory cards remain absent.

Only six explicitly labelled welcome-admission cards plus intro/prologue-seen context are synthetic. Controlled actor setup first places `(0,GROUND_Y,-10.8)` beside the sign solely for its distance-gated visible capture, then restores `(7,GROUND_Y,-1)` before real nearest detection/E. Both placements are disclosed in logs/reports; neither is walking, earned fresh-save admission or full-island evidence.

## Actual GPU retake and new-process persistence

Required selected retakes are ordinary+devil1280, ordinary800 and devil1152, each with its own unique fresh writer save. Each begins with zero028 cards, enters real practice, genuinely charges/releases, cancels through actual pause/HUD confirmation and returns to the selected retake gate. Actual arrangement callbacks and GPU shutter save the selected card only, honest retake acquisition with initially no challenge proof, fixed achievement and one40coin receipt (120→160). The stored full original pixels equal the actual arranged SubViewport pixels;320×180 thumbnails decode.

A later actual matching physical challenge preserves the selected retake original paths, byte SHA and acquisition method, adds genuine devil challenge proof when applicable and grants no second receipt. A separate new process reads the exact same writer save and verifies exact acquired IDs/full provenance records, coins, tutorial/region/achievement, original SHA and decoded originals/thumbnails. Readers alone share writer saves; their APPDATA/LOCALAPPDATA/TEMP/TMP/captures are independent fresh D paths. Later genuine devil completion may honestly acquire the other normal card after initially selected-only retake.

Gameplay photo semantics remain intentionally different: completed ordinary/devil gameplay refresh shared latest original paths. The suite records per-completion SHA histories and asserts actual refresh, while preserving one money receipt. It does not compare card dictionaries to claim first-gameplay-byte immutability. Current full originals decode at actual viewport dimensions, and normal/devil current original hashes agree. A practice/cancel never refreshes or awards cards.

## Launch isolation, audit and independent Windows export

Exact console engine: `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe`, SHA `c8f0a6bc45a19b33541501e57f6f7cd972ab18453743266339d495cbbe846643`. Actual logs identify4.7.2.stable.official.ed1daf0bf, Vulkan Forward+ / AMD Radeon RX9070XT. Graphical engine sibling SHA `ab1824f85bfd8e0e4128182c000c4003a3e042245b2967848d089b2a04b22424` is separately retained. This proves this machine/render path only.

Before **every** import/runtime/export/embedded-exe launch, run.py read-only audits every exact staged .gd/.tscn (stronger than literal fixture/helper traversal), including inherited Sugar base, audio helper, dynamic-load production graph and autoloads. Audit manifests preserve all source SHA values and assert the exact four-file test closure, zero OS.execute/create_process/execute_with_pipe/create_instance calls. The four legacy fault-child suites never enter these stages. All processes are explicitly launched through tools.godot_entrypoints.run_validated_godot with300-second bounded timeout; fixture watchdog is180 seconds. Raw engine --log-file UTF8 output and launcher stdio are both retained, with independent raw-byte hashes. No diagnostics are suppressed.

prepare_runtime_stage uses tracked runtime with .uid/.import sidecars filtered, then copies only the explicit new native .gd/.tscn plus unchanged Sugar .gd and AudioRelease .gd. Every stage/profile/TEMP/TMP/APPDATA/LOCALAPPDATA/capture/export is a fresh absolute D path. No C import, whole repo/test tree, C cache, copied UID, old package or player profile is used. Engine-generated D import files are expected fresh results. Source stages and commands below are fully expanded in the immutable receipts.

Independent QA base: `D:\Snapland-QA\jelly-native-qa-final-118f8cd8`. Actual embedded executable: `D:\Snapland-QA\jelly-native-qa-final-118f8cd8\release\JellyTrampolineQA.exe`, 285733344 bytes, SHA `ec76b938816345c58d351f75bc0d241b8a94b8467b6eb6255db5b7b4e2f53e11`. It was launched twice from its clean release directory **without project/path/scene override**: one writer and one new-process reader. Its only engine argument is an absolute D --log-file. Source graph/runtime overrides/binary/template identities and both commands/profiles are retained in qa-final-build.json, D build.json/acceptance.json and exact process receipts.

Pinned official Windows4.7.2 release template SHA `d34d36f3be1a6c49c56525ae86469b92e4f417ddf0b43cf00dd80c385c4b0562`; debug SHA `51498b72b3a237f882ebd7d1787f06a4bc1eaf0572daab93837adcfd3cfdc107`. The checked source template version is4.7.2.stable; both exact templates are copied into fresh D template paths before export. The staged project main scene and Windows-only export test inclusion are the declared QA config overrides; normal checkout main remains res://game/main.tscn and normal export test exclusions stay unchanged. No player release is replaced.

Reproduction command families; exact actual Godot commands are in process receipts. current1280 was completed by the initial scheduler. Historical rejected commands cannot reproduce old source states, and new runs must use new labels so frozen receipt names are not reused:

```powershell
python .review/jelly-trampoline-20261118/native/run.py current1152 1152x648 suite
python .review/jelly-trampoline-20261118/native/run.py current1280 1280x720 suite
python .review/jelly-trampoline-20261118/native/matrix.py
python .review/jelly-trampoline-20261118/native/package.py
python .review/jelly-trampoline-20261118/native/freeze.py
```

Exact promoted capture directories:

- `current1280-suite`: `D:\Snapland-QA\jelly-native-current1280-2429409d\suite-process\captures`.
- `current1280-read`: `D:\Snapland-QA\jelly-native-current1280-2429409d\read-process\captures`.
- `current1152-suite`: `D:\Snapland-QA\jelly-native-current1152-62266c31\suite-process\captures`.
- `current1152-read`: `D:\Snapland-QA\jelly-native-current1152-62266c31\read-process\captures`.
- `final800-suite`: `D:\Snapland-QA\jelly-native-final800-d7291e5e\suite-process\captures`.
- `final800-read`: `D:\Snapland-QA\jelly-native-final800-d7291e5e\read-process\captures`.
- `retake1280ordinary-retake-ordinary`: `D:\Snapland-QA\jelly-native-retake1280ordinary-2afbb20b\retake-ordinary-process\captures`.
- `retake1280ordinary-read`: `D:\Snapland-QA\jelly-native-retake1280ordinary-2afbb20b\read-process\captures`.
- `retake1280devil-retake-devil`: `D:\Snapland-QA\jelly-native-retake1280devil-b23e07c2\retake-devil-process\captures`.
- `retake1280devil-read`: `D:\Snapland-QA\jelly-native-retake1280devil-b23e07c2\read-process\captures`.
- `retake800ordinary-retake-ordinary`: `D:\Snapland-QA\jelly-native-retake800ordinary-4fc14ccd\retake-ordinary-process\captures`.
- `retake800ordinary-read`: `D:\Snapland-QA\jelly-native-retake800ordinary-4fc14ccd\read-process\captures`.
- `retake1152devil-retake-devil`: `D:\Snapland-QA\jelly-native-retake1152devil-6c89b56a\retake-devil-process\captures`.
- `retake1152devil-read`: `D:\Snapland-QA\jelly-native-retake1152devil-6c89b56a\read-process\captures`.
- `qa-final-suite`: `D:\Snapland-QA\jelly-native-qa-final-118f8cd8\suite-process\captures`.
- `qa-final-read`: `D:\Snapland-QA\jelly-native-qa-final-118f8cd8\read-process\captures`.

For each suite, raw representatives include factory-visible-sign/entrance, invitation, five rules pages, map/four entries, three tutorial images plus semantic-copy pages, seven-controls, charged slant/depth/trajectory, real ballistic/bell/delivery, ordinary/devil/assisted results, normal/assisted unfinished-bell resets/loss, real wall/recatch/manual release, participated timeout, successful practice, pause, album and achievement book. Retakes retain demonstration/arranged/saved and matching-challenge/result; all readers retain restart-album. All PNGs remain uncropped/unmodified. The public allowlist includes promoted raw captures, saved originals/thumbnails/provenance receipts, logs/stdio/audits/process/source/build identities and reproduction scripts, but excludes the large exe, player profiles, rejected candidates and whole stage.

## Rejected/superseded chronology and limits

draft1 import passed; its native entry failed to parse two inferred Font variables in the new fixture. The exact owned wrapper was stopped and the failed receipt/log retained. Explicit fixture types corrected this; no production change. draft2 rejected a fixture attempt to reset via mouse while touch owned charge, causing cascading unfinished-session failures. The fixture now performs matching outside-touch release cancellation before mouse reset. draft3 then passed ordinary/devil/assisted core routes but rejected the A-only optional recatch recipe run after practice selected B; actual HUD retry now selects A. draft4 passed1280 but is superseded by stronger complete lesson-page coverage.

final1152 and tutorial-diagnostic1152 rejected a scanner that mistook ancestor-clipped inactive semantic scroll groups for visible text. Exact node/text/rect diagnostics and raw screenshots are retained. Root accepted fixture-only diagnosis: inactive groups now explicitly excluded and every active page still checked against viewport plus clipping ancestors. All final dimensions were run under the executed functional source, before the later one-CRLF EOF-only hygiene below. No shared UI or production ticket/change was needed.

The first already-loaded scheduler included two unnecessary retake-size variants. Root narrowed to the four required pairs before any unnecessary retake launch. The completed current1280 pair is retained; only that owned scheduler/current800 writer tree was stopped at the next boundary. Its partial current800 runtime has no accepted completion and remains excluded; scheduler-stop.json records exact paths/limitation. Fresh final800 uses another new stage/profile. No accepted package or stage was patched/reused.

No fresh Model/Driver/View/workbench/Python/full-suite run was needed here; root monitors source CI separately. No finite recording was required by the house Task4 baseline, so screenshots remain static scripted GPU evidence only. No human play/hearing, art naturalness, physical touch hardware, cross-device performance, walking or earned-admission acceptance is claimed. ART16/17, MIC1..3 and ST5 are not closed by these results. Root fresh scoped/whole-branch review and final PM/Git/CI delivery remain outstanding.

## Post-freeze EOF-only source hygiene

Root precommit `git diff --cached --check` found one extra blank line at EOF in the new native fixture. Removed only its final CRLF; no game logic, earlier newline, other source, Git/index state, accepted stage, receipt, log, PNG, template or executable was changed. No engine/import/export was rerun.

- Actual executed fixture: `a3a5dca72aad8355bf506e239fcfadae28e1a16905a13b15f2032759c8923956`, 28194 bytes.
- Final checkout fixture: `ccf272149dae2b50501d32cff78659f9e87129e7810983d1a5ea084603764fc3`, 28192 bytes.
- Exact byte proof: executed bytes equal final checkout bytes followed by two-byte `0d0a`, removed at zero-based offset28192. The complete bytes are also identical after stripping only final CR/LF bytes; this is stronger than a textual/semantic comparison.
- The other966 source files still match their executed raw-byte hashes exactly. All16 accepted runtime audits/stages retain the old executed fixture hash and bytes. The independent executable retains the executed pre-cleanup fixture; its recorded SHA and all acceptance remain unchanged.

`.review/jelly-trampoline-20261118/native/source-hygiene.json` retains the actual executed-stage path, both raw hashes/byte counts and exact comparison checks. `promoted-native.json` keeps `source_sha256`/`fixture_source_sha256` as executed bytes, labels those semantics, and adds separate `checkout_source_sha256` and source-hygiene provenance. The metadata generator freeze.py now refuses to regenerate the historical freeze when this post-freeze proof exists. The public allowlist updates only the changed checkout fixture/report/index/freeze metadata and adds this proof/updater; no historical receipt/log/PNG hash is rewritten.
