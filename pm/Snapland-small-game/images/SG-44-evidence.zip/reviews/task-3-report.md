# Task 3 frozen integration report

Status: DONE, ready for root exact-source commit and fresh independent review. Base: `cd582d2080b53cf37c804f564201ca109d764977`. No Task4 work or GPU/package acceptance is claimed.

Evidence correction: the final audit found additional `OS.execute` children in the existing region-progress and photo-retake-progress suites. I had already executed those parents twice before finding the helpers. Their children inherited the parents' isolated D profiles and wrote only D child save paths, but bypassed the mandatory validated launcher and independent per-process profile boundary. Both parents are excluded from promoted acceptance; raw parent receipts remain untouched, with no separate validated child receipts/raw child logs claimed. Root was informed before handoff. The clean promoted set is15 suites, with progress/retake persistence covered by new and old factory Main routes.

## Delivered boundary

The house Session driver table now routes `game-028` / `jelly_trampoline`. The existing catalog, fixed progress/reward/achievement pipeline, ordinary participation copy, book and retake prop indexing consume fourth candy local identity4: `photo-candy-game-4`, `photo-candy-devil-4`, `ACH_GAME_028`. Candy exposes the real fourth entrance at `(7, GROUND_Y, -1)`; actual physics footing and nearest interaction choose it, and the regional map callback remains focusable and opens the normal invitation. There are28 real games,128 candidates, factory4/12;029 is still the first unbuilt game.

Three tutorial steps use the frozen unedited PNGs. Step1 teaches actual held charge/slant; Step2 explicitly explains its real500 result from a genuinely delivered bell fruit; Step3 shows real same-fruit bell→bed catch/manual recharge at2/3. AI/recatch remain optional recovery, never a devil requirement. Copy distinguishes natural normal loss (restart the three-fruit chain), assisted checkpoints, and X (current fruit only, retain deliveries, clear unfinished bell contact, applicable mistake, no time refund). The large800 rules pages and every lesson's semantic fields fit using the existing pager; no shared UI fix was needed.

Only the required integration/data/runner/validation and affected fixtures changed. No Progress schema, Steam economy, audio framework, normal player entry bypass or save migration was added. Shared audio fallback remains intentional. General gameplay capture still uses inherited latest-capture refresh. Real challenge/reload checks preserve selected retake original bytes and acquisition provenance. The unit images are clearly labelled synthetic PNG I/O, not GPU photographs.

`boundary-receipt.json` records the unchanged boundaries: old27 runtime definitions, park+27 existing lessons,127 other candidate design rows and first27 retake prop rows are structurally unchanged. Welcome/harbor runtime JSON and Progress/SteamBridge code match base canonical text (Git LF versus checkout CRLF normalized). Frozen Model, Driver, View and all3 PNG raw SHA values match root's frozen values. No frozen source or PNG was edited; no standalone native workbench was rerun. Existing untracked UID/import metadata was preserved.

## Honest chronology

1. Before wiring, wrote the real missing-catalog/driver Session fixture and ran `pre-wiring-red` through the validated exact engine in a fresh D stage. Import exit0/errors0; actual Session exit1/errors1, marker **`Jelly trampoline Session: 1 checks, 1 failures`**, explicitly requiring028 to route through the actual Session Jelly driver. This is genuine pre-wiring RED; no injected outcome or reversed source replay.
2. Before wiring, started `pre-wiring-baseline`:15 selected existing parent suites plus import, each observed direct process exit0/errors0. Two parents were later excluded for unvalidated hidden children as disclosed above; the valid child-free baseline comprises13 suites. Original private harness falsely matched Syrup JSON keys named `leaked` as leak diagnostics (27/15 matches), causing only its final Python assertion to exit1. Raw logs/receipts are retained unchanged. Diagnostic-only regex correction and `evidence-index.json` explicitly reclassify actual baseline leak diagnostics as0; no engine failure was suppressed and no baseline result was fabricated or replayed.
3. Implemented minimal house wiring and meaningful new Session/Main fixtures. `first-wired`: import0, Session52/0, MainPASS; errors/leaks0. Extended actual800x600 rules and dynamic factory menus, registered all five suites, updated only necessary affected counts/allowlists/first-unbuilt assertions.
4. `selected-green`:17 selected parent suites plus import returned clean direct results;15 are promoted after excluding the two hidden-child parents. This stage includes the earlier028 invitation/recovery copy. Later root requested clearer consequences; only028 copy was refined. `final-copy` reran the affected current-data Main, retake panel and both tutorial suites; `final-main` additionally checks the final new Main's factory stamps/ticket/guide assertions. All current entrypoint fixture SHAs match the promoted run. The evidence index lists every global staged-manifest difference honestly: older cases differ only in final028 invitation/tutorial copy and the later new Main fixture, covered by the promoted current-copy/current-Main runs. Existing game identities/rules/routes did not change.
5. Focused boundary helper initially compared Git LF against checkout CRLF as raw bytes and stopped before checking; normalizing line endings for canonical-text comparisons corrected that private check only. Final boundary assertions and98 affected Python contracts passed; games/links/runtime configuration and diff checks passed. No more production edits follow this frozen set.

## Promoted executable evidence

All evidence lives under `.review/jelly-trampoline-20261118/integration/`. `evidence-index.json` is the promoted selected-results index, with exact source hashes, receipt/log SHA, current-entrypoint matching and explicit staged source differences. Each automatic run receipt contains the complete actual command, five isolated absolute environment paths, process exit, `ERROR:` count, leak diagnostics and complete staged resource SHA manifest. Raw `.log` files retain all warnings. After the exclusion ruling, `fixture-launch-audit.json` records a read-only audit of all15 promoted cases' complete explicit transitive fixture/helper closure:22 unique exact staged sources, each SHA-matched to its receipt, with zero OS process launch calls. No extra engine run or source patch was used for that audit.

| Suite | Promoted run | Result | Warnings retained |
|---|---|---|---:|
| Jelly Main | final-main | exact PASS marker |45|
| Jelly Session | selected-green |52 checks,0 failures|0|
| Catalog | selected-green |PASS|0|
| Candy world | selected-green |PASS|0|
| Sugar Session/Main | selected-green |21/0; PASS|0 /30|
| Cookie Session/Main | selected-green |21/0; PASS|0 /30|
| Syrup Session/Main | selected-green |46/0; PASS|0 /45|
| Participation results | selected-green |all28 PASS|0|
| Retake panel | final-copy |all28 canonical targets PASS|0|
| Travel book UI | selected-green |PASS|19|
| Tutorial panel/catalog | final-copy |park+28 PASS|1 intentional missing-image fixture|
| Tutorial paged viewport | final-copy |all current lessons/all fields PASS|0|

Every promoted process is exit0/errors0/leaks0. Main/travel material warnings are the retained existing OcclusionController baseline, not suppressed. The deliberately missing tutorial-image warning remains raw and counted. The excluded retake-progress parent's16 fixture warnings remain raw but are not accepted evidence. The inherited tutorial marker names three sizes; the expanded fixture now checks three widths at four dimensions:800×600,800×450,1280×720,1920×1080, all at1.25. New Main separately asserts its actual visible viewport is800×600 and inspects all five actual rules pages for complete text, actions and nonoverlap.

The new Session's52 checks exercise real keyboard/pointer A/B × normal/assisted × ordinary/bell routes, actual AI catch then manual release, a separate real bell→wall→bed→manual recharge/delivery route, charge/hold/release participation, pause clear/no ghost launch, focus loss, retry retention/variant, natural idle and participated timeout, practice and cancel, and model-owned HUD/score rows. No internal Model state/outcome assignment exists in these routes.

Main verifies admission without bypass (only six explicitly labelled welcome admission cards and opening seen are fixture prerequisites), the actual nearest entrance/map callback/first lesson, natural idle/participated/success results, exact local4/global028 cards and first40-coin receipt deduplication, assisted devil, practice/cancel no rewards, saved restart identity, four candy stamps/lessons and4/12 ticket. Both selected-only retakes use a clearly labelled synthetic pixel image after the real set reaches shutter. A genuine matching three-fruit ordinary/devil challenge then reloads; original PNG SHA, frames, original_frames and retake provenance remain unchanged. These are unit PNG/persistence checks, not GPU/new-process claims.

Recorded command chronology from repository root:

```text
python .review/jelly-trampoline-20261118/integration/run.py pre-wiring-red test_jelly_trampoline_session.gd
python .review/jelly-trampoline-20261118/integration/run.py selected-green test_jelly_trampoline_main.tscn test_jelly_trampoline_session.gd test_game_catalog.gd test_candy_world.gd test_sugar_bridge_session.gd test_sugar_bridge_main.tscn test_cookie_mold_session.gd test_cookie_mold_main.tscn test_syrup_flood_session.gd test_syrup_flood_main.tscn test_participation_results.gd test_retake_panel.gd test_travel_book_ui.tscn test_region_progress.gd test_photo_retake_progress.gd test_tutorial_panel.gd test_tutorial_paged_viewport.gd
python .review/jelly-trampoline-20261118/integration/run.py final-copy test_jelly_trampoline_main.tscn test_retake_panel.gd test_tutorial_panel.gd test_tutorial_paged_viewport.gd
python .review/jelly-trampoline-20261118/integration/run.py final-main test_jelly_trampoline_main.tscn
python .review/jelly-trampoline-20261118/integration/verify.py
python .review/jelly-trampoline-20261118/integration/audit_closure.py
python .review/jelly-trampoline-20261118/integration/freeze.py
```

The RED and original selected-green commands document history. Rerunning against frozen wired sources cannot reproduce historical RED; the tightened private harness now rejects the two hidden-child progress parents in the original selected-green command. Original receipts preserve the actual entries, original one-check RED fixture and staged SHAs. A future clean selection must omit those parents. No source rewind, hidden rerun or child-launcher bypass is requested or claimed.

Every promoted direct Godot run used exactly `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe` via `tools.godot_entrypoints.run_validated_godot`. SceneTree entries use `--script`; Main uses a real `.tscn`. Every run has a new `D:/Snapland-QA/jelly-integration-<label>-<nonce>/project`; each promoted process has separate absolute D `SNAPLAND_SAVE_PATH`, `APPDATA`, `LOCALAPPDATA`, `TEMP`, `TMP`. The excluded hidden children are the disclosed exception: same editor executable and isolated D stage, but direct legacy launch/inherited process directories. `prepare_runtime_stage` receives tracked runtime excluding UID/import metadata, then copies exactly the selected transitive test/helper closure. No whole repository/test tree, C import cache, player profile or old accepted package is copied, and no C checkout import occurs.

`python-final-receipt.json`/`python-final-*.log` contain exact commands and exit0 outputs:98 tests in design validation, runtime result/strict marker, runtime shard, validated entrypoint and desktop stage contracts; design games and links; configured native runtime command; `git diff --check`. The five new Jelly suites are registered once with exact215/78/83/52/clean-Main markers. PixelShell/avatar-only240-second exceptions and every other90-second runner timeout/shard safety remain unchanged. These static/Python checks do not claim game playtesting.

## Local limits and handoff

Per brief, **did not execute** `test_photo_retake_main` or `test_region_travel`: their legacy `OS.execute` children bypass the mandated Python launcher and inherit profile paths. Their launchers were not rewritten or stage-patched. Necessary fourth-game counts in region travel were updated by inspection; photo-retake Main had no affected fixed count. The additionally discovered region-progress and photo-retake-progress parents were mistakenly executed, explicitly excluded, and will not be rerun. All four legacy launcher implementations and CI registrations remain unchanged; only the listed required region-travel count assertions were updated. Child-free retake panel, all three old factory Main/Session, new Main progress/retake/reload, travel-book UI, participation and tutorial suites supply the local accepted coverage.

No whole local suite, new native workbench, genuine GPU retake, new-process photo reopen, exported package, human playtesting, listening, art naturalness, hardware touch/gamepad or cross-device performance acceptance was performed. Task4 owns GPU/new-process/package evidence. No player save,028 result/bell/card/achievement/receipt injection in the new Session/Main routes, PM/plan/authority-spec/HEAD/index mutation, commit, push, branch cleanup or publication occurred. Root owns exact commit/review and the next gate.

## Initial frozen owned source SHA256

The following30 files are the initial handoff before fix round1; the two superseding fix hashes appear below, and evidence-index.json carries all30 current hashes. Raw hashes include their actual checkout bytes. Private harness hashes and unchanged producer PNG/source hashes are in `evidence-index.json` and `boundary-receipt.json`.

- design/02-minigames/catalog.json: fea16709f4448c6baa37eeb4ffb71b7f0fa4ba15460ad247e475c40f336baaa6
- design/02-minigames/catalog.md: cf3cd39b3ba3abed11263cececf7a5efa039c7cd617de548dbdb3495c4f44233
- design/runtime/full-game-delivery.md: bb15b656971476bf4eaeeb9ae953237a0137fe5122cafde1135a449c932098e5
- game/core/game_catalog.gd: 4f112eb002cca83497b9b6344ee3b7c18c12cf57cb94bd02195c7fbf869b7df5
- game/data/candy_games.json: 56f0355a75ee28430e5a7f9930417eb46fc9ea794c553d5198ca875848bb103e
- game/data/tutorials.json: 1b4c68bb1aa1006c8847b2f7559d44d5153a282f3b4291d3dea92dc17eaf3365
- game/main.gd: 504296500e1176becdafbf984d567dc77266cad5be4f77544e02ce92613c854f
- game/minigames/session.gd: e7eb06b478313d7c46a487f11bf67cf9941f1413acf077cb799aa51c66824cda
- game/tests/test_candy_world.gd: 383590dfe25bb6bba25292b37295275f7da851a4c18feef490dbfe50ae2e18d9
- game/tests/test_cookie_mold_main.gd: 1ab9aedf83fb056b28f52a628ba75439f0b1c68a190040edc3fc1f08596c979b
- game/tests/test_cookie_mold_session.gd: fec5b7492b70f76c736c85d4e26cafd2d161c5707b6d50264efa02b2c3a06a00
- game/tests/test_game_catalog.gd: f67cbb17916908fd08c7a39f7179926d373566d04139316371ba426543d0ccdc
- game/tests/test_jelly_trampoline_main.gd: d207d4095fcbca01eca7e5e5e6a645e9621573bbdf30b1c8dc8840653baf4492
- game/tests/test_jelly_trampoline_main.tscn: 703576dc31b85385279deb3da531dcbba2c63b9be1c011e7e2a185a22b5834e8
- game/tests/test_jelly_trampoline_session.gd: 517a8d5dc2f7e634f06ced54ad25a298c756526baa424a0df4e8285040aebfdc
- game/tests/test_participation_results.gd: 0dfd13b69e8b50c3a59e76191f2ec59019cb806eb25bda6da5d7eaa7d546516d
- game/tests/test_region_travel.gd: 8f196a8f815a363bf598980fb5fa0c7b8650c56fd47118062f2b6c0299eeba5a
- game/tests/test_retake_panel.gd: fdd6a05b446c42ccb85f72a9dc2b139f6065ca441cff80ca29d0bf687d85b5e4
- game/tests/test_sugar_bridge_main.gd: 2ef2bec822081aebd0b40364a642d6a377bd465a4892f68585014e766a0dd0bc
- game/tests/test_sugar_bridge_session.gd: 53ce6a47d24eab389ff0af04bb812de25e700c3e4aef76f8c05e31316d4f5876
- game/tests/test_syrup_flood_main.gd: 8eb3cf813af7d1262d765f3a4486b022b38898b76c9665936bdffd63a177ff96
- game/tests/test_tutorial_paged_viewport.gd: c47e16b5335e8384d69c108750220205085bad7fa1e64fb1e2b7e179954b6bb1
- game/ui/collection_book_panel.gd: 8384647c5ab09f60a098e7a3a9247abb2f0142d736d66277ffbe19615a6ccafe
- game/ui/retake_panel.gd: 8aad6a0af2351e917107d53c59806812718dec37a76296f0681463ed141ed42e
- game/ui/tutorial_catalog.gd: 70a346b28b8bdf97c3b6d85b245b48d4f6f7222fa8c743e8a282f6240e4d7248
- game/world/candy_world.gd: 3f556468a3567be1caa809c190ed06ef40ea15092e01e63c8afca41d074ccbe1
- tests/test_design_validation.py: fe1599c306d5a3f9ec7eea5ab86eb60a06a7876be6a917389e4f5197c1cfba4f
- tests/test_runtime_result_contract.py: 37cfb2d6e32733934d39fe4f069b500b568859e00b6ca9e6f61c5ab84d6998cb
- tools/run_game_tests.py: dca400a6a46dc4d84e65aa0f3ef2d3fcf97529f24e30de84db55ad4d96864ea6
- tools/verify_design.py: 81d49ba0167df819652fdcd20e9c69eb0d7928bfbffd5022f3ee156a82432921


## Fix round 1 — physical factory game-count sign

Status: DONE for scoped re-review. FIX_BASE `7037511cdd6a9749725bb404f36bfe013c6a1bdf`. Sole P2 finding: the physical factory sign still advertised3/12 despite four real entrances. The sign now formats the delivered candy count from the existing lightweight catalog accessor. Its `Vector3(0, GROUND_Y, -10.8)` position and every existing entrance remain unchanged. The existing candy-world fixture finds the constructed Label3D by its actual sign text prefix and requires exactly one visible sign reading `工廠遊戲 4／12` on all three world visits.

Genuine pre-edit chronology: added the sign assertion while the old3/12 production expression was still intact. Before any engine launch, the exact staged selected fixture/helper closure was audited for OS process-launch APIs: RED1 file and each GREEN7 files, zero launch calls, source SHAs recorded in each prelaunch audit. `fix1-red` import exit0/errors0; actual old-code candy-world exit1/errors3/leaks0, exactly the new sign assertion on three visits (`Candy world checks: 4311`, `FAIL: candy world (3/4311)`). The automatic receipt retains the old world's raw SHA and original regression fixture SHA. That first assertion also checked visibility from entry, missing the existing distance gate; it was therefore a confounded RED, not an isolated text-only regression. No code rewind or replay is claimed.

Then changed only the shared sign text expression. The first `fix1-green` still failed the three sign assertions because the label is correctly hidden19.8m from entry; current Main passed. That failed receipt/log remains unchanged and excluded. Corrected only the fixture setup to stand the player on safe floor beside the sign, let two real physics frames update distance visibility, check the visible4/12 Label3D, and return to entry before existing checks. The final fixture differs from the first RED fixture; no clean same-final-fixture old-code RED was replayed. Root was informed of this limitation.

`fix1-final-green` used another fresh D stage and fresh five-path D profiles per process: import exit0/errors0, candy-world exit0/errors0/leaks0 with4311 checks and its exact existing PASS marker, and current Jelly Main exit0/errors0/leaks0 with its exact existing PASS marker. Candy-world warnings0; Main's45 existing material warnings remain unsuppressed. Main rechecks the current fourth entrance/map callback, actual800-large rules, natural routes/rewards, selected retakes and reload. This is headless scripted integration evidence, not human playtesting or GPU proof.

Exact engine and launcher remain `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe` via `run_validated_godot`; SceneTree uses `--script`, Main uses its real `.tscn`. Full actual commands, isolated absolute D save/APPDATA/LOCALAPPDATA/TEMP/TMP paths, exits/errors/leaks/markers and source SHA manifests are in `fix1-red-receipt.json`, failed `fix1-green-receipt.json` and accepted `fix1-final-green-receipt.json`; raw logs and prelaunch audit files share those run prefixes under the private integration directory.

```text
python .review/jelly-trampoline-20261118/integration/run.py fix1-red test_candy_world.gd
python .review/jelly-trampoline-20261118/integration/run.py fix1-green test_candy_world.gd test_jelly_trampoline_main.tscn
python .review/jelly-trampoline-20261118/integration/run.py fix1-final-green test_candy_world.gd test_jelly_trampoline_main.tscn
```

The RED/first-GREEN commands record historical execution with earlier fixture setup; rerunning them after the correction will not reproduce their failures. The promoted index now replaces only candy-world and Jelly Main with current fix1-final-green evidence. Older accepted stages explicitly list the changed world sign and, where their selected closure contained it, the changed candy-world fixture among current-source differences; earlier028 copy/Main-fixture differences remain declared. The new exact promoted closure audit remains read-only. The excluded legacy child parents and all their raw history remain excluded and unchanged.

No whole15-suite/98-Python/native/export rerun, launcher refactor, stage source patch, frozen Model/Driver/View/tutorial-PNG edit, Git mutation or Task4 work occurred. The six frozen producer/PNG hashes were checked read-only and still match. Only these two source hashes supersede the initial list:

- `game/world/candy_world.gd`: `21a8b8ff07ee30af336a76d5f22fe67b27514583204c04342394fca0b9e9d3e3`
- `game/tests/test_candy_world.gd`: `e5ce9b9a0c452216b8994c37e049a44e7147b5745fcf89b6b829aac1a19e7042`


### Historical Python hash semantics

The existing `python-final-receipt.json` field `log_sha256` hashes in-memory UTF-8 text with LF newlines before Windows text writing produced the preserved CRLF log files. Those historical values are **canonical-text hashes**, not raw-byte hashes. Old receipts/log bytes were not rewritten and passing Python commands were not rerun. The evidence index now labels that meaning and adds a separate raw-byte hash for each preserved file:

| Log | Historical UTF-8/LF canonical SHA256 | Preserved raw-byte SHA256 |
|---|---|---|
| python-final-0.log | dfff142d6a49b5caab5621cfeb21fa333c7c51fafe52f32c0f4649c23f3c0c7a | 23ee906001a91a3114bfaec810e69cc18d4883b3ab1004a73b2e18fdda75097b |
| python-final-1.log | 58a0276f36f4d2f68c0475ff53d3651990ac61346e09b20f0dd007d51961a7cd | 98d80686bda08dd7591d93035b698a67c20158738e0b081dfd6c23839f32134d |
| python-final-2.log | 1678ecd1298ff541489ef85da76183a8a0fb6e08000a05d5487d5de44be67f0d | 33ba8157d5b3f66735486df997ef07707cba2e689b506b25336880b6603b2b67 |
| python-final-3.log | 8c14f1dcf68360073cfcb3a9a3cf80818a2f6f5e80bafa60d8775fdbae4bf9fa | 3b6c5994ccac21ea603c99a1f9af0d13131d4fc669c60cb2775b6eb9ea1cc836 |
| python-final-4.log | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 |

Runtime logs, source files, receipts and audit SHA values remain explicitly raw-byte hashes. This metadata clarification grants no new Python execution or gameplay acceptance.
