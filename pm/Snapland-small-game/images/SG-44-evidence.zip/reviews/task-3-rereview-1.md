# Task 3 re-review — fix round 1

Reviewed `7037511cdd6a9749725bb404f36bfe013c6a1bdf` → `544de49` on 2026-11-18. Scope: the original physical-sign P2, the two-file fix package (+8/−1), the same Task 3 brief, the report's fix appendix, and focused retained evidence. Read-only except this report; no engine, native, export, Python-suite, or broader regression rerun.

**Original P2: ADDRESSED.**

**Updated Task 3 spec gate: ✅. Quality: Approved.** These gates retain the original review's selected-evidence and later-task limits; they do not accept Task 4 or the excluded legacy children.

## Resolution and new-breakage review

- `game/world/candy_world.gd:83` replaces the stale3/12 literal with the existing lightweight catalog's `definitions("candy").size()`. With four delivered definitions, the constructed sign reads `工廠遊戲 4／12`. Its position remains `Vector3(0, GROUND_Y, -10.8)` and every entrance is unchanged. This also avoids a separately maintained delivered-count literal.
- `game/tests/test_candy_world.gd:34–40` finds the actual constructed Label3D, requires exactly one matching sign, and checks both tree visibility and exact4/12 text on all three visits. It places the actor on existing safe floor beside the sign, clears velocity, waits two real physics frames, then returns to entry before the previous assertions. The parent world's existing distance-visibility update runs before its blocked-movement handling, so the setup respects the real visibility gate without forcing visibility or changing production rules.
- No new actionable breakage found in this fix diff. No other source, gameplay, UI framework, input, reward, identity, entrance, or saved-data change is introduced.

## Focused evidence assessment

Independently matched both current source SHA256 values to the index and all three final-green receipt manifests, and matched their staged copies to the checkout:

- World: `21a8b8ff07ee30af336a76d5f22fe67b27514583204c04342394fca0b9e9d3e3`.
- Fixture: `e5ce9b9a0c452216b8994c37e049a44e7147b5745fcf89b6b829aac1a19e7042`.

The promoted `fix1-final-green` receipt/log raw-byte hashes match the index. Import, candy-world, and current Jelly Main record exit0/errors0/leaks0. Candy-world logs4311 checks and its exact existing PASS marker with zero warnings; Jelly Main logs its exact existing PASS marker and retains45 existing material warnings. Both promoted entries declare no current staged-source difference. Commands use the exact 4.7.2 console engine, SceneTree `--script` for candy-world and a real Main `.tscn`, with separate absolute D save/profile/TEMP/TMP paths per process. The final prelaunch audit records the seven selected fixture/helper sources with no launch calls. No GPU or human visibility claim is inferred from `is_visible_in_tree()`.

The chronology limitation is explicitly accepted as a limitation, not a clean TDD claim: the first old-code RED and first GREEN used an assertion that also expected visibility from the distant entry. Both failed the new assertions on three visits. The final placed-player fixture differs from that RED, so the historical failures do not isolate the text defect and do not form an identical-final-fixture RED→GREEN pair. The original stale source expression, corrected expression, meaningful current regression, and passing current evidence are sufficient to resolve this small finding without replaying old sources. The report retains the confounded runs and does not claim a source rewind or staged patch.

The historical Python metadata now distinguishes LF-canonical hashes from raw-file hashes. Independently verified all five pairs against the preserved logs. This clarification does not imply another Python execution.

## Limits carried forward

This re-review closes the single original P2 and examines new breakage only in its two-file fix. The original review's other integration conclusions stand; no broad re-review was performed. The historical unvalidated child-process execution remains disclosed and both affected parents remain unpromoted. No new child-launch acceptance or player/C-profile safety conclusion follows from this review.

Task 4 has not started and receives no acceptance: genuine GPU retakes, new-process reopen, executable write/read, native final presentation and human/hardware checks remain later work. Frozen Model/Driver/View/tutorial PNGs are outside this fix and absent from its diff.

Skipped engine/native/export/Python-suite reruns as instructed. Remaining risk is limited to the previously disclosed selected coverage and Task 4 acceptance boundaries; no unresolved fix-specific defect was found.
