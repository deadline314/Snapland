# Task 1 scoped re-review — fix round 1

Base `276c355`; reviewed head `8818d5a`. Read the same Task 1 brief, original Important finding, appended Formal fix round 1 report, and supplied `review-276c355..8818d5a.diff`. Inspected retained RED/GREEN receipts, test logs, evidence index and current owned source hashes. This is a review of the fix and its regressions, not a broad re-review.

**Original Important finding: ADDRESSED.**

**Spec gate: ✅ for Task 1 implementation behavior. Quality gate: Approved.** No new Critical, Important or Minor findings in this fix diff. The initial preimplementation RED requirement remains a disclosed historical process limitation; this approval does not retroactively claim it was fulfilled.

## Why the correction addresses the finding

`game/minigames/jelly_trampoline_model.gd:247–261` introduces only a snapshot-local `preview_held`, initialized from the real held state. Creating a hypothetical charged-ready release explicitly changes that local flag to false. Already-airborne prediction keeps the real held value. Both paths still call the same `_flight` function; helper state, collision rules, coefficients, input mutation, score and success predicates are unchanged. The real model's held input is never changed by prediction.

The new public-input regression at `game/tests/test_jelly_trampoline.gd:421–472` directly distinguishes the relevant paths:

- Normal A, bed340, tilt0, helper off, hold0.8: the charged preview must contain all24points. It compares every subsequent0.1-second sample with explicitly released actual motion through two substantial bed rebounds and requires actual flight to continue without automatic catch or charging.
- Already-airborne held preparation: prediction retains the intended catch, compares precontact samples, and ends at(340,492). The actual fruit catches ready with zero velocity and begins charging only after contact. This prevents an unconditional forced-release fix from passing.
- Helper-enabled charged-ready prediction: a hypothetical release still predicts the genuine helper contact catch, and actual release catches without starting charge. This separately protects helper behavior.
- Repeated snapshots preserve the original ready/held or airborne input state. Existing nested snapshot/trajectory mutation isolation and the24-point cap remain unchanged.

The guarded comparison loop is not a weakened expectation: the preceding explicit24-point assertion fails on a truncated preview; the guard only permits the remaining regression checks to run without indexing outside the old preview.

## Retained executable evidence

RED `fix1-preview-red`: old Model SHA `d3573a2c4307833756deeef08f2f93e967e0d23dab13cf4b81756f1afb3f4f1b`, new fixture SHA `4731a456790147a9bf8844affed605f88f2d6b7985af8bb1a99691cfc7e6913e`. Import exit0/errors0; test exit1/errors2. Log marker: **`Jelly trampoline tests: 205 checks, 2 failures`**. Both failures name the original charged preview defect.

GREEN `fix1-preview-green`: Model SHA `86134f411bae5c41bee6732340155bb06ca6991d85b9e98ef5b5191bd90cf822`; fixture SHA is identical to RED. Import and test exit0/errors0. Exact marker: **`Jelly trampoline tests: 215 checks, 0 failures`**. The ten additional executed comparisons follow from the corrected longer preview; no fixture change between RED and GREEN is hidden by the different assertion counts. Current workspace hashes match both GREEN staged manifests and the evidence index.

Both receipts record exact Godot4.7.2, SceneTree `--script`, distinct fresh absolute D stages and separate import/test save/APPDATA/LOCALAPPDATA/TEMP profiles. They retain the existing validated launcher/staging workflow. GREEN log preserves the unchanged eight public A/B×normal/assist×ordinary/bell results, all assisted genuine catch markers, exact deadline bracket and the same-fruit bell→bed→manual-release success at elapsed11.114980510, score500. This supports absence of a regression in those existing scoped checks; it does not expand their acceptance scope.

Task 1's original behavioral blocker is closed at this exact head. The initial wrong-entrypoint and after-draft controlled RED chronology remain accurately preserved in the report and index; this fix has its own genuine unchanged-regression RED→GREEN.

No engine run, broad suite, source edit or Git mutation was performed during re-review. Only this report was written. Driver/View/Session/Main, native input/3D/GPU, audio, export/save-read, human playtesting and Tasks2–4 remain outside this gate; retained headless numeric evidence grants none of those acceptances.
