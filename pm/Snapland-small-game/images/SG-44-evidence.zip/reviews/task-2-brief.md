## Task 2: Input, retained2.5D View and real tutorials

**Ownership:** game/minigames/jelly_trampoline_driver.gd, jelly_trampoline_view.gd; game/tests/test_jelly_trampoline_driver.gd, test_jelly_trampoline_view.gd, native_jelly_trampoline_workbench_review.gd/.tscn; assets/ui/tutorials/game-028-step-01..03.png; private presentation+freshD. No frozenModel/integration/docs/PM/Git edits without concrete defect/root ruling.
**Interfaces:** consume Task1publicAPI/snapshot. Export house Driver API, KEY/COMMAND/buttongeometry/statichelpers for Session tests, command_requested/pointer_requested lifecycle used by View. Sevencommands A/D/Q/E/Space/R/X; press/hold/release charge, cancel outside release; exact authority.

- [ ] RED missing driver/view, implement house ownership/echo/emulatedmouse/secondtouch/focus/treeexit/resetguards with actual held-charge input; cover three modalities, both variants+assistance and ordinary/bell completed routes via realevents.
- [ ] Retained true3D elasticbed/fruit/platform/bell/walls/trajectory from same snapshot, bounded nodes/meshes/materials over120presents; actualmodel feedback owns footer because Session suppresses genericdriverfeedback. Exact score rows/zero-floor/practice.
- [ ] Native three sizes actualInput.parse routes, clear depth/slant/trajectory/AIcatch/wall+bell/realthree-delivery result/missrecovery, all seven controls/textbounds and reduced-motion critical states retained. Save raw PNGs and exactlogs/profiles. Promote3tutorialimages raw native1280 captures matching lessonclaims, no imageedits.
- [ ] Freeze task-2-report.md with allsource/PNGSHAs, actual per-stage checkmarkers/profiles, three tutorialprovenance and limits. Root views rawrepresentatives, commits/reviews exacttask; Task3 later owns Main/rewards.

