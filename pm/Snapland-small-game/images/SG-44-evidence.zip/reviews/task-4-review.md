# Spec Compliance

- ✅ Spec compliant for the Task 4 implementation gate, reviewing `22d2c2c58c6327e7954609c534f99616100abd21..159ec69`. The diff adds only the native Jelly fixture and its real Node scene. Actual factory proximity/E, focused map admission, five rules pages, three tutorial images and every semantic page, seven controls, natural Session outcomes, retakes and fresh-process readers are present (`game/tests/native_jelly_trampoline_main.gd:17`; `game/tests/native_jelly_trampoline_main.tscn:1`). No production/base/helper/schema/economy/audio-framework edits occur in this task.
- ✅ Allowed synthetic admission and controlled placement are explicitly labelled; the fixture drives parsed input and the real Session process rather than setting 028 gameplay/results/rewards (`game/tests/native_jelly_trampoline_main.gd:17`). The inherited input/capture boundary was inspected for the concrete risk of hidden injection: `game/tests/native_sugar_bridge_main.gd` supplies parsed keyboard/mouse events, raw viewport capture, decoding and audio teardown; its Sugar-specific `_run`/retake are overridden, not executed.
- ✅ Selected ordinary/devil retakes, matching natural challenge, preserved original paths/SHA/provenance, one reward receipt and new-process exact record comparisons are implemented. The reader compares all stored records and original hashes, not merely card presence (`game/tests/native_jelly_trampoline_main.gd:499`, `:509`, `:514`). Required passing pairs are ordinary1280, devil1280, ordinary800 and devil1152 in `promoted-native.json`.
- ✅ Accepted executed-source provenance survives the formatting-only final checkout change. Independently compared the retained executed-stage bytes to checkout bytes: exactly `old == new + b'\r\n'`, lengths 28194/28192, with both recorded SHA256 values matching `source-hygiene.json:1`. This does not claim byte identity between the embedded fixture and final checkout. One final blank line has no executable behavior; a rerun is unnecessary for this disclosed delta.
- ⚠️ Cross-task guarantees for all older 27 games/saves, the unchanged 128-candidate catalog and normal release entry/exclusions are outside this two-file diff. This task does not alter them; the controller's earlier-task/whole-branch checks remain their gate. Final PM completion, PNG archive publication, push/rebase/main/CI and branch cleanup remain controller delivery duties, not accomplished by this fixture review (`task-4-brief.md:1`; `task-4-report.md:1`).

# Strengths

- The fixture checks real downward deliveries and same-fruit bell proof, assisted catch without automatic launch, completed versus unfinished bell reset, normal versus assisted loss, real retry, timeout, practice and pause/cancel behavior. All four retained suite result arrays are exactly ordinary400, devil500, assisted500, recovered practice500/ineligible, participated failure0, practice500/ineligible (`game/tests/native_jelly_trampoline_main.gd:17`; `promoted-native.json`, corresponding `cases[].results`).
- The active tutorial-page scan respects clipping ancestors and traverses all active pages rather than accepting only the first semantic page. Its inactive-group exception is specific to the existing scroll pager. Independently viewed the raw final800 `tutorial-3-copy-3.png`: active page and footer controls fit the physical viewport. Broader raw-image inspection is explicitly recorded by the controller in `root-visual-review.md:1`; these remain scripted GPU observations.
- Launch and export isolation have a small auditable boundary. `run.py:22` audits every staged script/scene and enforces the exact four-file test closure; `run.py:36` invokes the validated launcher after that audit. `package.py:1` builds a new D-only QA stage, pins templates, changes staged config only and launches the embedded executable without a scene/path override.

# Issues

## Critical (Must Fix)

- None found.

## Important (Should Fix)

- None found.

## Minor (Nice to Have)

- None warrant a task change.

# Evidence Checks and Limits

- Named risk: stale or optimistic retained acceptance. Independently checked all 16 promoted runtime log hashes and audit hashes against manifest records, exact four-fixture allowlists, no reported child-launch calls, exit0, exactly one completion marker, zero errors/leaks, empty native/physical report failure arrays and the actual result matrices. Read both retained log/stdio content for warning/error/leak diagnostics: none. Capture counts total438; allowlist currently contains655 entries. This was retained-evidence inspection, not engine execution.
- Named risk: executable acceptance silently using an external project or player profile. Both retained QA commands contain only the independent executable and absolute `--log-file`; all runtime save/APPDATA/LOCALAPPDATA/TEMP/TMP/capture paths are absolute D paths. Writer/readers share only the intended writer save. Build evidence retains pinned engine/templates/binary identities. No whole-stage or binary rehash duplicated the controller's earlier complete integrity check.
- Named risk: EOF hygiene invalidates historical evidence. Independently verified exact old/new byte equality apart from the final CRLF and both file hashes. Preserved manifests explicitly distinguish executed versus checkout hashes. Controller-provided full967-source/all655-input checks are not represented as newly rerun here.
- Review input: initial combined output truncated the beginning of the packaged diff; reread that missing beginning to complete the hunk. No changed source text was separately opened. The only changed-file byte read was the named EOF provenance comparison. No Git operation, engine/import/export launch, suite rerun or source/index/HEAD/PM mutation was performed.

# Assessment

**Task quality: Approved.**

The new fixture reuses the house GPU/input/audio boundary and provides finite, meaningful assertions on natural production behavior, persistent selected retakes and independent executable launch. The explicit EOF-only source distinction is adequate provenance; no blocking correctness, compliance or maintainability defect was found.

Not rerun: engine/import/export/full suites; no human play, hearing, physical-touch or cross-device acceptance.
Risk/limit: scripted captures establish this machine's observed path only; cross-task and final delivery gates remain with the controller.
