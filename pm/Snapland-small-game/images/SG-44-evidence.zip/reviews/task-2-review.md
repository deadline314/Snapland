# Task 2 independent spec and quality review

Reviewed base `8818d5a` through exact head `9de97fd` for SG-44/game-028. Scope: the nine owned files (1002 added text lines and three raw PNGs), Task 2 brief, gameplay authority, frozen producer report, and retained presentation evidence. Code and Git were read-only; only this review document was written. No engine, native, export, or redundant gameplay test was rerun.

**Spec: ✅ — Task 2 meets its scoped requirements.**

**Quality: Approved.**

## Actionable findings

- Critical: none.
- Important: none.
- Minor: none.

The elliptical fruit/bell question is adjudicated below rather than silently omitted or treated as an unproved physics defect.

## Spec assessment

| Requirement | Assessment and evidence |
|---|---|
| Frozen Model and house Driver API | ✅ `reset`, `create_view`, `handle_input`, `clear_input`, `step`, `snapshot`, `present`, and `score_summary` match the existing house signatures. A focused comparison with CookieMoldDriver and Session callers found no API incompatibility. Model SHA is `86134f411bae5c41bee6732340155bb06ca6991d85b9e98ef5b5191bd90cf822`; `game/tests/test_jelly_trampoline.gd` SHA is `4731a456790147a9bf8844affed605f88f2d6b7985af8bb1a99691cfc7e6913e`. Both match the required freeze. |
| Seven real commands and held charging | ✅ Driver lines 31–110 retain physical-key ownership, alias matching, one step per press, keyboard configuration while charging, and source ownership across mouse/touch. Only a matching release can launch. Pointer outside/canceled/nonfinite releases clear charge; echo, repeated presses, emulated mouse, a second touch, and unmatched releases do not launch. X resets the Model before clearing input, preserving charged-reset mistake accounting. |
| Lifecycle cancellation | ✅ Driver reset/clear/tree-exit and View focus cancellation clear owners and Model continuous input without launching or resetting flight. Existing Session pause/exit paths call `clear_input`; actual Session registration and integrated execution remain Task 3. The retained fixtures cover focus cancellation, tree exit, view recreation, retry, and late release. |
| Truthful feedback and score | ✅ View lines 246–261 draw actual `snapshot.feedback` in its own footer. Driver score rows use Model deliveries/success/devil/mistakes, explicitly reconcile the zero floor, and return the exact practice exclusion. Ordinary and devil totals are 400/500 only for their corresponding real results. |
| Retained true 3D stage | ✅ View creates a SubViewport, World3D, orthographic Camera3D, lighting, thick bed/compression/platform/walls, SphereMesh fruit/bell, and one fixed 24-dot trajectory pool. `present` duplicates the snapshot and updates retained transforms/material values, without creating nodes, meshes, or materials per frame. Snapshot positions, depression, tilt, mass text, target/bell radii, and trajectory share the same state. |
| Collision and reduced-motion cues | ✅ Bed and target bright spans subtract the fruit radius before mapping their dimensions. Fruit origin follows actual Model depression. Bed rotation and asymmetric compression remain present with reduced motion, as do trajectory and essential feedback. See the explicit affine-projection assessment below. |
| Native dimensions and input matrix | ✅ Retained final logs independently contain 24 distinct parsed-input route tuples at each of 1280×720, 1152×648, and 800×600. Those tuples cover all three modalities × both variants × normal/assist × ordinary/bell outcomes. The small case uses text scale 1.25 and reduced motion. Button/text-bound checks and raw views support the visibility claim. |
| Tutorials | ✅ All three tracked PNGs are byte-identical to their final raw native-1280 capture sources. They show actual charged/slanted state, three completed deliveries with one real bell delivery/500 points, and a bell-touched fruit after real recatch during manual recharge. Neither their visible text nor the rule says AI or recatching is mandatory. The second image's 500 is the captured devil result, not a claim that every successful round scores 500. |
| Isolation and evidence | ✅ Retained commands use the validated launcher and exact Godot 4.7.2. SceneTree fixtures use `--script`; the Node workbench uses its `.tscn`. Each process has independent absolute D save/APPDATA/LOCALAPPDATA/TEMP/TMP paths. The runner uses tracked runtime staging plus its explicit fixture closure. Nine source hashes, all 24 raw PNG hashes, all three source/target tutorial mappings, and all active staged-source hashes were independently checked during this review. |
| Scope boundary | ✅ Exact Git diff contains only the nine owned files. No Model/model fixture, Session/Main, integration, PM, authority, player save, or old-stage edit is included. |

## Affine fruit/bell projection judgment

Inspected `jelly_trampoline_view.gd` lines 123–124, 186–197, and 224–233, all three official tutorial images, raw 800×600 charge, and raw 1152×648 real bell contact. The visible fruit and bell are horizontally elliptical. This is a deliberate common affine stage mapping, not evidence that their drawn contact radii use unrelated dimensions:

- `world_point` maps one logical x unit to 0.02 world units and one logical y unit to 0.01.
- A logical fruit radius of 28 therefore maps to x/y radii 0.56/0.28. Its radius-0.28 SphereMesh with x scale 2 has those same radii.
- Bell radius 32 similarly maps to 0.64/0.32, and the assisted bell multiplies the entire transform by its actual snapshot radius ratio.
- Platform/bed positions, radius-adjusted bright support spans, and trajectory positions use that same mapping. The camera then projects the common scene.

The transformed meshes are world-space ellipsoids, so this review does **not** claim that their world-space transforms or final pixel silhouettes are geometrically perfect spheres. I interpret the authority's spherical-fruit/2.5D requirement as a volumetric rendering of the logical round fruit with coherent physical cues. On that functional reading, this package meets it: actual curved 3D surfaces, light/shading, depth, common coordinate mapping, and correct corresponding logical radii are retained. I found no radius-specific cue contradiction that warrants a blocking correction. A future preference for circular screen silhouettes would be a presentation decision requiring coherent scene remapping; removing x scale alone would make the visible horizontal radius disagree with Model collision distance. This judgment grants no art-naturalness or human-play acceptance.

## Retained executable evidence checked

| Run | Retained result | Independent review checks |
|---|---|---|
| `final-unit` Driver | 78 checks, 0 failures | Current executed Driver/View and both unit fixtures match manifest and staged hashes; exit 0/errors 0. |
| `final-unit` View | 83 checks, 0 failures | Retained identity over 120 presentations and teardown assertions; 43 nodes/37 mesh instances/8 materials. |
| `native-final-1280x720` | 135 checks, 0 failures | 24 distinct actual parsed routes; eight raw captures; current full active six-file closure; exit 0/errors 0. |
| `native-1152x648` | 135 checks, 0 failures | Same independent route/capture/closure/process gates. |
| `native-800x600` | 135 checks, 0 failures | Same gates with UI 1.25/reduced motion. |

All three native logs retain `nodes=43 mesh_instances=37 unique_meshes=14 materials=8`. Engine banners identify `Godot Engine v4.7.2.stable.official.ed1daf0bf`; native logs identify Vulkan/Forward+/AMD Radeon RX 9070 XT. The final-unit stage's unused older native fixture copy does not invalidate its four current executed sources. All final native stages contain the current complete native closure.

The genuine preimplementation receipt uses the correct missing Driver/View SceneTree paths, with import exit 0 and each fixture exit 1/errors 1. The report preserves the rejected draft parse/type failure and timeout chronology rather than promoting them to acceptance. Later final receipts and source hashes support the final passing package.

Capture-state checks independently confirm: step 1 is charging/unparticipated at score 0; step 3 is charging with the same fruit bell flag, delivered 2, bell deliveries 0, score 200; step 2 is genuine success/devil with delivered 3, bell deliveries 1, score 500. Capture creation reads the viewport after rendering and saves its raw PNG; the native setup does not inject fruit, score, bell, delivery, or reward state.

## Cannot verify / outside this gate

This is approval of the standalone Task 2 Driver/View/tests/tutorial package. Main/Session registration and layout in actual gameplay, reward/photo/achievement integration, export and fresh-process save write/read, GPU retake, audio, touchscreen hardware, gamepad, human play, art naturalness, and cross-device performance remain unverified here. Task 3 and ART/MIC/ST acceptance are not completed by these receipts.

I inspected retained evidence and representative raw images; I did not rerun the engine, broaden to the full suite, walk the island, or alter any runtime stage. The remaining material risk is future integration behavior, which must be verified in its own gate.
