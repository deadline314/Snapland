# Task 3 independent spec and quality review

Reviewed base `cd582d2080b53cf37c804f564201ca109d764977` through head `7037511cdd6a9749725bb404f36bfe013c6a1bdf` on 2026-11-18. Read the Task 3 brief, binding gameplay authority, frozen producer report, and scoped review package. Review was read-only except this report; no engine, native, export, or existing test suite was rerun.

**Spec: ❌ — one visible factory-count integration omission.**

**Quality: Changes requested — one P2 finding.**

## Actionable finding

### [P2] Update the factory's physical game-count sign

**File:** `game/world/candy_world.gd:83` (same changed geometry builder as the new entrance at line93).

`_build_region_geometry()` still creates `_sign("工廠遊戲 3／12", ...)`. Adding game-028 makes four actual factory entrances, and the updated catalog, ticket, achievement stamps, lesson guide, and collection book correctly expose four games. Every player entering the factory can therefore see a physical sign contradicting the delivered 4/12 scope. `_sign()` puts the supplied literal directly into a Label3D; no later dynamic replacement exists in this file.

Update this sign to the delivered candy count (the existing catalog count is available if avoiding another independent literal), while preserving its position and the three existing entrances. Add a focused assertion to the existing candy-world fixture that the constructed visible Label3D advertises 4/12. The current fixture checks nine interactions/four game points and safe selection, and the new Main fixture checks the ticket's 4/12 text, but neither checks this physical sign; that is why the affected suites pass despite the mismatch. This is a small completion of the requested fourth-game integration, not a shared UI redesign.

## Spec coverage otherwise supported

- Catalog and Session use `game-028` / `jelly_trampoline`, candy local4, `photo-candy-game-4`, `photo-candy-devil-4`, and `ACH_GAME_028`. There are 28 delivered games against 128 candidates; game-029 remains unbuilt. The actual new interaction is `(7, GROUND_Y, -1)`.
- Production integration reuses the existing driver table, dynamic regional interfaces, reward/achievement/progress routes, and retake indexing. No Progress schema, Steam economy, audio framework, save migration, or normal-entry bypass was introduced.
- The new Session fixture drives public keyboard/pointer input and natural results: A/B, normal/assisted, ordinary/same-fruit bell, actual AI catch then manual release, a real bell/wall/bed recatch, held charge, pause/focus clearing, late-release rejection, retry retention, practice, cancellation, and model-owned HUD/result values. It does not assign model outcomes to manufacture these routes.
- The new Main fixture checks actual nearest-entrance interaction, a focusable map callback through the normal invitation, first lesson/start, all five real rules pages at actual 800×600 with 1.25 text, semantic RulesNote1 navigation, natural idle/participated/success outcomes, local4 reward identity, first40-coin deduplication, four factory stamps/lessons and ticket4/12. Only the sign above is omitted.
- Ordinary and devil selected retakes reach the real panel's enabled shutter before explicitly synthetic PNG I/O. Matching real challenges followed by in-process reload preserve original image bytes/paths and acquisition provenance. These tests do not establish GPU image provenance or new-process persistence.
- Tutorial copy preserves the intended X/current-fruit semantics, unfinished bell clearing, no time refund, normal natural-loss chain reset, assisted checkpoints, and optional AI/recatch. The 500-point image explanation explicitly includes a genuinely delivered bell fruit. The house pager and all previous lesson data remain intact.
- Five new suites are registered once with the exact 215/78/83/52/Main markers. Strict completion handling includes Jelly. Existing avatar/PixelShell 240-second exceptions, other 90-second limits, and shard/error handling were not broadened by the production diff.

## Evidence checked independently

- All 30 source SHA256 values in `evidence-index.json` match the current checkout. The six frozen Model/Driver/View/tutorial-PNG SHA256 values in `boundary-receipt.json` also match. None is modified in the reviewed commits.
- Independently compared old welcome/harbor data and Progress/SteamBridge canonical text against base; old candy rows, park+27 previous lessons, and all 127 other candidate rows are structurally unchanged. The retake diff only appends the 28th prop row.
- All 15 promoted receipt hashes and raw runtime-log hashes match their index. Each selected process exits0, records errors0, has its exact completion marker in the raw log, and has no actual leak diagnostic. Their five environment paths are absolute D paths and separate across promoted processes; commands name the exact 4.7.2 console executable. Launcher use is supported by the inspected private harness and receipts, not a fresh engine execution.
- Independently reconstructed each promoted fixture/helper closure from the exact staged entrypoint, matched it to the audit, and verified all 22 unique staged source hashes against their receipts. No OS process-launch API occurs in that closure. Current staged-source differences exactly match the index: older selected cases differ in final028 copy and the later Main fixture; current-copy/current-Main results cover those changes. Final Main has no declared source difference.
- Historical RED receipt records clean import followed by actual Session exit1/errors1 and `Jelly trampoline Session: 1 checks, 1 failures`. Accepted green Session records52/0. This review did not replay RED against wired sources.
- Existing Main material warnings remain visible: Jelly/Syrup45, Sugar/Cookie30; travel UI19 and the intentional missing tutorial-image warning are retained. The old overbroad `leaked` regex matched JSON field names; inspected runtime logs support diagnostic-only reclassification rather than suppression of an engine error.
- The Python receipt and logs report98 affected contracts passing, games/links validation, runtime configuration coverage and diff checks. **Hash-format distinction:** `verify.py:56–57` hashes its in-memory LF output before Windows text writing creates CRLF files. All five Python log hashes match after LF normalization; these are canonical-text hashes, unlike the runtime index's raw-byte log hashes. No unexplained content mismatch was found.

## Independent judgment on excluded child-process executions

The original brief excluded `test_photo_retake_main` and `test_region_travel`; the producer nevertheless also ran two other legacy parents before discovering their helper launch paths. Inspection confirms `test_region_progress.gd:136` and `test_photo_retake_progress.gd:143` directly call `OS.execute`, change the child save beneath the parent's D directory, and inherit the other profile paths. Those executions did violate the binding validated-launcher/per-process-directory rule. A later plan clarification cannot make those children validated retroactively.

The report and index now exclude **both entire additional parents**, retain the raw history, and claim no independent child receipts. The two originally excluded suites were not locally run. All four legacy suite registrations and launcher implementations remain in place; region-travel changes only update affected assertions. The clean promoted set is15, with a complete independently checked22-source fixture/helper closure. New Main supplies real fourth-game reward/retake/reload coverage, and old three factory Main/Session plus child-free catalog/world/participation/tutorial/travel-book/retake-panel routes supply the selected regression evidence.

That is a transparent and defensible limit for this scoped Task 3 review under the root's same-scope clarification. I do not request a launcher rewrite or another engine run here. I also do not accept the excluded parents' diagnostic/atomic-failure cases, infer separate child environment isolation, or treat their recorded parent PASS markers as promoted acceptance. The historical execution mistake remains a disclosed process deviation, not an additional fabricated passing result.

## Cannot verify and later-task boundaries

No new engine run was performed by this reviewer. The review supports the inspected code and retained scoped evidence, subject to the sign correction above; it is not an all-suite or CI acceptance. The four excluded legacy child-process routes remain locally unaccepted. Their hidden children have no separate validated receipts, so I cannot independently certify their full launch boundary or make player/C-profile safety claims from parent receipts.

Task 4 has not started and receives no acceptance here. Genuine GPU retakes, new-process photo reopen, exported executable write/read, native three-size final integration, human playtesting/listening/art naturalness, hardware touch/gamepad and cross-device performance remain outside this review. Synthetic PNGs and in-process reload are not substitutes for them. No ART16/17, MIC1–3, or ST5 completion follows from this report.

Skipped engine/native/export/full-suite reruns as instructed. Remaining immediate risk: the physical factory sign misreports content until the P2 correction is delivered and reviewed.
