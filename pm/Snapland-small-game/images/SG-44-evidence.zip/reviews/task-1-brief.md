## Task 1: Pure elastic/ballistic model

**Ownership:** only game/minigames/jelly_trampoline_model.gd and game/tests/test_jelly_trampoline.gd; private .review/jelly-trampoline-20261118/model and freshD. Root owns specs/docs/PM/Git. No Driver/View/integration edits.
**Interfaces:** implement exact JellyTrampolineModel public API and snapshot from authority; Task2/3 consume it. Read authority first, house syrup_flood_model.gd/testing launcher as needed.

- [ ] RED missing real model/API test via exact validated engine in fresh tracked D stage+explicitnewfixture; preserve import/test commands/env/exit/logs.
- [ ] Minimum pure model: actual energy/mass/angle trajectory, swept contacts/reflections, held charge/catch/release, true deliveries/same-fruit bell, AI onlyrealcatch, miss/reset/checkpoint, participation/deadline/score/finite bounds; snapshots cannot mutate model.
- [ ] Public-input A/B×normal/assist×ordinary/bell eight winning routes; assisted routes actually exercise AI recovery/catch. Prove shallow/deep/left/right/mass trajectories, real miss+recovery, bell-hit-but-lost ineligible, no-op/helper/config/hold nonparticipation, cancellation, readyvsflight release, fast/tangent/duplicate contacts, exact deadline bracket, maliciousdelta and long bounded loops. No private state/result injection in winning trajectories. Report any calibration defect before changing frozen spec coefficients; root updates authority if warranted.
- [ ] Freeze full report task-1-report.md in planworkspace: files/hashes, exact meaningful checkmarker, tests/TDD/proven public recipes and limits. Root commits exact sources, fresh task review, marks complete; never replay completed tasks.

