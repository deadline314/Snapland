# Task 1 independent review

Reviewed head `276c355` against base `5fd412a342f5368a18643f996308dea50058e703`, including root's approved max-bed calibration commit `bb0e2a1`. Read the brief, authoritative gameplay specification, producer report, and supplied scoped diff package once. Scope is the pure Model and focused SceneTree fixture only.

**Spec: ❌ Changes required.** The charged-ready trajectory uses the held input from before release, so its bed-return behavior differs from the actual released shot.

**Quality: Changes requested.** One Important finding; no Critical or separate Minor findings. The implementation otherwise follows the existing RefCounted/Dictionary design with bounded state and no dependencies, framework or persistence.

## Important — predict the input state after the hypothetical release

Location: `game/minigames/jelly_trampoline_model.gd:249–259`, specifically `_flight(preview, SUBSTEP, _held)` at line 259. Related missing regression: `game/tests/test_jelly_trampoline.gd:355–389` (`_prediction`).

When `snapshot()` finds a charged ready fruit, it computes hypothetical launch velocities and changes `preview.fruit.ready` to false. It nevertheless simulates that future shot using the real `_held == true` from the charging state. The actual mandatory `release_charge()` clears `_held` before launching (line 47). At a descending bed contact, `_flight` catches and settles when `held` is true (lines 217–225); an ordinary released shot with helper off instead rebounds with 0.65 vertical and 0.85 horizontal restitution. Sharing `_flight` therefore does not make these two paths equivalent: they receive different input state.

Concrete public-input case, derived directly from the reviewed code rather than claimed as a new engine run: reset normal A, leave bed at x340, adjust tilt to 0, keep helper off, begin charge, advance 0.8 seconds, and save the charged snapshot. Then release and advance the actual model. This shot cannot reach the target at x870 and returns to the bed after approximately 1.228 seconds of flight. The saved preview catches and terminates there because it still passes `held=true`; the released actual fruit retains substantial rebound velocity (approximately vy=-347) and continues upward. This contact is within the existing 2.3-second/24-point preview horizon. The player is shown a different future path from the shot they are preparing to release.

Required correction: when the ready charged preview creates a hypothetical release, predict with the released input state. Preserve the actual current hold state when predicting an already airborne fruit, where a prepared held catch really is intended. Preserve helper behavior and the existing shared physical collision rules.

Required regression: add a public-input charged-ready, helper-off vertical return case that compares preview samples to the actual explicitly released fruit through and after the bed rebound, and requires the preview to continue through that bounce. Also cover an already-airborne held-catch prediction so the correction does not erase legitimate prepared catches. Keep snapshot isolation and the 24-point bound. The existing high-angle target/wall preview cases do not exercise this distinction.

## Specification assessment

| Requirement within Task 1 | Result | Evidence / qualification |
|---|---|---|
| Exact Model API and required snapshot fields | ✅ | Public reset/move/tilt/charge/release/cancel/helper/current reset/clear/step/snapshot methods are present; focused fixture enumerates required snapshot fields. |
| Frozen geometry, mass/height order, charge energy, launch position and angle | ✅ | Implementation matches authority including the approved x620 bound. No other coefficient or success predicate was relaxed. |
| Actual gravity, wall/top reflection, swept circle sensing and descending platform delivery | ✅ | Shared `_flight`, explicit support-center radius subtraction, real circle segment checks, positive downward contact velocity. Exact geometry tests are internal starting-physics unit fixtures, not winning-route evidence. |
| Three real deliveries; same fruit must touch bell and then deliver | ✅ | `delivered` changes only at target contact; bell count increments from that fruit's flag; natural success requires three. Eight public-input routes plus the separate real bell→bed→manual-release route inspect outcomes without injecting result state. |
| Real catches only; AI waits for manual charge/release | ✅ | Helper is read only at actual bed contact. Assisted public recipes first perform a genuine descending recovery and then manually release later shots. Separate same-fruit bell return preserves contact across real recatch. |
| Normal loss resets progress; assisted loss retains completed checkpoint | ✅ | Shared loss branch and both public loss routes; completed bell checkpoint and unfinished bell loss tested independently. |
| Participation, held input, cancellation, reset and terminal scoring | ✅ | Participation begins only on eligible manual release; pure hold/configuration/helper/reset cannot earn it. Current reset does not rewind time. Score uses bounded floor and actual deliveries/success/devil. Driver source ownership/cancellation remains later scope. |
| Honest deadline and finite/bounded stepping | ✅ | Invalid deltas return; valid delta capped to 0.25 with ≤1/120 substeps; actual contact time checked within remaining interval before terminal settlement. Recorded ±1e-10 deadline bracket distinguishes after-deadline failure. The 1e-9 clock normalization does not enlarge the contact comparison. |
| Isolated snapshots, bounded history/trajectory, same actual/predicted physics | ❌ | Deep copies and maximum 24 points are implemented; hypothetical release uses the wrong held state as described above. |
| Initial genuine preimplementation RED | ❌ process limitation | The first launcher typo prevented test execution; controlled missing-model RED occurred after the first unvalidated draft. Report states this accurately. It does not invalidate the later executable results or justify weakening current checks. |
| Focused regression RED for apex tangent correction | ✅ | `apex-red-test.log` records 171 checks / 1 failure for the exact ascending-to-apex fixture; final source requires positive descending velocity and final log records 171 / 0. |

## Evidence inspected

- Current owned source SHA256 values match the producer report, evidence index and both final import/test receipt manifests: Model `d3573a2c4307833756deeef08f2f93e967e0d23dab13cf4b81756f1afb3f4f1b`; fixture `a6e586f7cb5710071fbf4eb21602ece828cc53d909b864c65a292ef5c6241acf`.
- `final-green-test.log` contains the exact marker **`Jelly trampoline tests: 171 checks, 0 failures`**, all eight A/B × normal/assist × ordinary/bell outcomes, genuine AI-catch markers, and the separate bell-recatch completion marker.
- `final-green-receipt.json` records import and test exit 0 / errors 0, exact Godot 4.7.2 console executable, fresh absolute D stage, `--script res://game/tests/test_jelly_trampoline.gd`, and separate import/test save, APPDATA, LOCALAPPDATA and TEMP/TMP paths.
- Reviewed private `run.py`: it uses `prepare_runtime_stage` with tracked runtime, explicitly adds only the two owned files, calls `run_validated_godot`, and creates distinct D profiles. Existing tracked runtime metadata is inherited through that house staging helper; no whole test tree or C import cache copy is used by this runner.
- Inspected the initial wrong-entrypoint note, controlled missing-model receipt/log, apex RED log, final GREEN log and evidence index. Controlled missing-model receipt omits the Model and records import exit 0 / test exit 1. The report preserves the initial chronology instead of calling that after-draft RED preimplementation TDD.
- Root's x500→620 calibration is isolated in the package and consistent with the approved authority. It widens actual recovery support without changing three-delivery success, bell sensing, same-fruit accounting or manual-release rules.

## Limits and disposition

No existing tests were rerun and no new engine process was started. The preview finding follows directly from a public reachable charge state and the two different `held` arguments; producer should capture its focused RED→GREEN in the same isolated exact-engine workflow. No production/Git files were changed by this review; only this report was written.

The receipts and source hashes support the recorded headless Model checks, not native gameplay, human playtesting, visual quality, input-source arbitration, audio, GPU capture, export save/read, or cross-device performance. Driver/View/Session/Main, runner registration and Tasks 2–4 are outside this review and receive no acceptance here. Historical process ownership and absence of all possible player-data access cannot be independently proven from logs alone; the inspected runner paths are explicitly isolated.

After the Important correction and its focused regression, request a fresh review of the exact amended Model/fixture and receipt. Current Task 1 should remain open.
