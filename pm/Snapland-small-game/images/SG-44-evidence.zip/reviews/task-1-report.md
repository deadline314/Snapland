# Task 1 frozen producer report

Status: DONE, ready for root exact-source commit and independent fresh review. No Task 2 work started. Effective implementation base was `5fd412a342f5368a18643f996308dea50058e703`; root authority amendment `bb0e2a1` permits max bed x620. No Git/index/HEAD operations were performed by this producer.

## Owned deliverables and exact source hashes

- `game/minigames/jelly_trampoline_model.gd`: `d3573a2c4307833756deeef08f2f93e967e0d23dab13cf4b81756f1afb3f4f1b`
- `game/tests/test_jelly_trampoline.gd`: `a6e586f7cb5710071fbf4eb21602ece828cc53d909b864c65a292ef5c6241acf`
- Private evidence only: `.review/jelly-trampoline-20261118/model/`, isolated new D stages/profiles, and this requested report. No Driver, View, integration, PM, runtime spec, existing tests, old accepted stages, UID/import metadata or player profiles were edited.

The model uses the house RefCounted/Dictionary pattern without dependencies, new framework, extra configuration or persistence. Public callers are the later Driver/View/Session tasks; only the exact frozen public API/snapshot was added here. The focused SceneTree test is the exact new fixture closure. Root owns registration, runner wiring, exports/callers and future integration verification.

## Final executable evidence

Command from repository root: `python .review/jelly-trampoline-20261118/model/run.py final-green`.

Exact meaningful marker: **`Jelly trampoline tests: 171 checks, 0 failures`**.

Both final import and SceneTree test returned exit0, with zero `ERROR:` entries. Engine was the validated exact `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe`, version4.7.2. Entry was `--headless --path <stage> --script res://game/tests/test_jelly_trampoline.gd`; import used `--editor --import --quit`.

Final stage: `D:\Snapland-QA\jelly_trampoline-model-final-green-c40aa5de\project`.

`final-green-receipt.json` contains actual full commands, process exits, error counts, complete staged source SHA manifest, and five independent absolute D environment paths per process. Import and test use distinct `SNAPLAND_SAVE_PATH`, `APPDATA`, `LOCALAPPDATA`, `TEMP`/`TMP` profiles. `prepare_runtime_stage` staged tracked runtime first, then precisely the two owned untracked GDScript sources were explicitly copied. No full repository/test-tree/UID/C cache/player profile copy was used. Each run has its own fresh D stage and new profiles. `final-green-import.log` and `final-green-test.log` preserve full output; `evidence-index.json` cross-checks final source hashes against both automatic receipts.

## Honest test chronology

1. The first minimal missing-model test source was written before the draft, but the initial runner erroneously named `jelly_trampoline_flood` files. Import completed, and the validated launcher rejected the nonexistent script before running the test. This is **not** preimplementation RED. `red-import.log`, `initial-wrong-entrypoint.txt` and `red-attempt-reconstructed-receipt.json` retain the limitation; the latter is explicitly reconstructed from the original runner, observed output and surviving D stage because the original exception prevented automatic receipt creation.
2. First unvalidated draft SHA was `4537415e724fec44777aa84ee79cbf7bcd064332b3f23bbf868bafe2b051585b`. The root-requested SG43 branch pause occurred after that draft. On resume the identical checkpoint hashes were root-confirmed. `first-unvalidated-draft.gd` preserves byte-identical draft content reconstructed by reversing exactly the three subsequent edits then verifying this recorded hash; no source rewind/replay is claimed.
3. `controlled-missing-model`: after the draft, a fresh tracked stage explicitly omitted only the real model and included the minimal correct test. Import exit0/errors0; test exit1 with one explicit missing-model assertion. This is controlled after-draft RED, with automatic commands/env/exit/source hashes and full logs, not genuine preimplementation TDD.
4. `draft-green`: actual draft model/API loaded;2 checks,0 failures. This was a narrow API check only.
5. `routes-v1`: all eight real routes passed, but two strict float-equality assertions failed at accumulated1.4-second depth. Assertions were corrected to appropriate tight physical approximate comparisons; no success/contact tolerance was added. This run also retained actual initial max500 bell-recatch failure.
6. `rules-v2`:123 checks,1 failure from an incorrect negative fixture: full1.4-second shot actually delivered its bell fruit. The losing recipe was corrected to1.3seconds; real rules were retained.
7. `calibrated-v3`:151 checks,0 failures after root max620 ruling, real same-fruit recatch and preview samples.
8. `thresholds-v4`:165 checks,0 failures; candidate pass before self-review.
9. Self-review identified that an exact platform apex tangent from below was incorrectly accepted despite requiring a descending crossing. Added the isolated exact fixture first; `apex-red`:171 checks,1 expected failure. Minimal shared support condition now requires positive contact vertical velocity, for both bed and platform; no numerical success epsilon. This is genuine focused RED→GREEN for this correction.
10. `final-green`:171 checks,0 failures. Both owned sources are frozen at the hashes above; no further same-code rerun or broad/full-suite rerun was performed.

## Public recipes and actual outcomes

All eight winning routes and the separate bell-recatch winning route call only reset, move_bed, adjust_tilt, begin_charge, step, release_charge, toggle_helper and snapshot. They never inject internal state, scores, results, contact flags, deliveries, cards, rewards or participation. The reusable static `solve`, `configure`, `launch`, `advance` and `wait_ready` test helpers expose literal house public-input recipes for later Session adapters; they do not add a production framework.

Ordinary shot recipes by current fruit mass/height:

| Mass / platform top | Bed x | Tilt | Hold seconds |
|---|---:|---:|---:|
|1.0 /240|380|21|1.28|
|1.15 /260|420|28|1.28|
|0.9 /220|340|21|1.26|

A uses these in order1.0,1.15,0.9; B uses1.15,0.9,1.0. For a bell route, add80 to only the first shot's bed x; all subsequent recipes remain ordinary. Hold via begin_charge/step then explicitly release; step until actual delivery/new ready fruit. Fruit launches from actual `492+40*d`, uses mass/energy/angle, and the bell is a circle sensor without steering.

Every assisted route first configures bed340/tilt0, enables AI, manually charges0.8seconds/releases, and steps until a genuine descending bed contact catches. A catches atelapsed2.033333333; B at1.95. Tests require ready fruit, zero velocities, no new charging, no delivery/mistake, then disable AI and execute manual shot recipes. AI never adjusts bed/tilt, charges or launches.

| Variant | Assisted | Bell | Final elapsed | Score |
|---|---|---|---:|---:|
|A|false|false|7.724980510|400|
|A|false|true|7.724980510|500|
|A|true|false|9.758313844|400|
|A|true|true|9.758313844|500|
|B|false|false|7.727749588|400|
|B|false|true|7.727749588|500|
|B|true|false|9.677749588|400|
|B|true|true|9.677749588|500|

Each route asserts exactly three deliveries, natural ended/success/ordinary eligibility, exact bell delivery count0/1, exact devil state and score. Ordinary routes do not touch the bell before delivery.

Separate true bell→bed→manual release recipe: normal A, deliver first two ordinary recipes. At third mass0.9, configure x500/35°, enable helper, manually hold1.34seconds/release. During flight move bed right three steps to620. The fruit actually touches bell, reflects right wall, falls back onto the moved support and is caught atelapsed8.15 with same-fruit bell true, delivered2, bell_deliveries0, no mistake and no charging. Wait0.25seconds to prove no auto launch. Configure x340/21°, manually hold1.26seconds/release. The third fruit really lands; finalelapsed11.114980510, three deliveries, bell_deliveries1, deviltrue, score500. The bell flag is preserved through real catch/recharge and counted only at delivery.

## Calibration evidence and root ruling

Initial spec maxbed500 could not reach the bell-touched return: actual A third mass0.9 x500/35°/1.34s touched the bell near(871.3285,185.2571), reflected right wall, then crossed the bed plane near x656.0, beyond maximum normal supported center542. `routes-v1-test.log` and `rules-v2-test.log` preserve real trajectories and subsequent loss. Exploratory private standard-library `calibrate.py` evaluated literal launch grids and estimated minimum bell-touched return656.01; these exploratory calculations were never presented as gameplay evidence or used to inject a winning state.

Before editing any coefficient the producer reported the exact failure and proposed only maxbed500→620, maintaining the40-unit grid and normal support reach662. Root accepted and independently amended authority in `bb0e2a1`. Only that approved bound changed; radii, support widths, masses/heights, energy, gravity, tilt, restitution, real three-delivery success, same-fruit bell, manual input and AI boundaries remain authoritative. Cost: somewhat easier recovery and a wider bed-travel range.

## Meaningful rule coverage

- True charge depression/launch position, depth-squared energy, angle/mass speeds, shallow versus deep actual trajectories, negative tilt actual left flight and gravity.
- Exact0.15-second minimum, shallow-tap rejection, held-full charge without autolaunch, duplicate begin, release in flight inert, cancel/clear preserving flight and preventing ghost launch.
- Helper toggle cannot catch distant fruit; actual AI catch waits; actual held-flight catch starts charge only on contact; manual release after catch.
- Real public misses, normal lost-progress reset versus assisted completed checkpoints, lost bell checkpoint behavior, current-fruit X cost/clear without rewinding time or completed deliveries; no negative score.
- Real bell-touch-but-lost ineligible, airborne current-fruit X clears uncompleted contact, fresh fruit starts without prior bell flag, completed bell counter requires same fruit delivery.
- Swept true-circle tangent/near-miss/stationary geometry; fast swept bell plus right-wall reflection; bell sensor cannot steer; side/top/bed exact restitution; low-speed natural settle; fruit-radius-adjusted normal/assisted platform edges; ascending and exact apex contact rejected; one large step cannot duplicate delivery onto next fruit.
- Deadline controlled fixtures at−1e−7,−1e−10,0,+1e−10,+1e−7seconds around final contact: before/exact succeed, both after fail. Clock residual may normalize only below1e−9, and does not enlarge contact eligibility.
- Malicious NaN/infinite/nonpositive delta inert; huge delta capped0.25; fixed≤1/120 physics substeps;8000 held-loop finite/bounded state, no autolaunch/participation and natural expiry.
- Snapshot nested dictionaries/trajectory isolated; preview≤24points; repeated snapshots inert; charged preview starts depressed and matches actual ballistic/side-wall-reflected0.1-second samples; preview terminates at actual original fruit contact, without plotting the next fruit's respawn.

The exact collision/deadline edge cases above use clearly separated internal **starting-physics fixtures** and private geometry calls to reach exact boundaries. They are unit checks, not public winning routes or gameplay/award proof. No private injection is used in the eight winning routes or actual bell-recatch route.

## Self-review and limits

Reviewed shared call sites inside the pure Model: all public state mutation paths, _flight used by both actual simulation and detached prediction, _new_fruit, charge clearing, score settlement and terminal behavior. The one found apex defect was fixed by the shared support test after real focused RED. Retained one bounded state dictionary plus input flag; no history, new dependencies, option matrix, generic route engine, extra APIs or persistence. Physics integrates scalar float64 positions; Vector2 is used only for bounded preview and swept bell geometry. A bounded four-event loop is sufficient for physically reachable capped speeds/substeps.

This proves model physics and numeric/public-input recipes in exact headless Godot only. Driver ownership, native input-source cancellation, View/3D/UI, Session/Main registration, screenshots, gamepad/touch device behavior, GPU photo pipelines, executable save/read, audio, art feel, playtesting and full suites are outside this task and remain for root/later tasks. No player save was accessed. No broad/full-suite rerun, dependency addition, generated success picture, reward injection, publish or commit was performed.


# Formal fix round 1 — frozen replacement evidence

Status: DONE, frozen for root exact fix commit and scoped re-review. FIX_BASE `276c355`. This section supersedes the earlier171-check candidate marker and source hashes; all previous artifacts remain unchanged as before-fix evidence. Task 2 has not started; no Git/index/HEAD, PM, authority, Driver/View/integration or unrelated source changes were made by this producer.

## Review finding and minimal correction

Read the full fresh `task-1-review.md`. Accepted Important finding: a charged-ready hypothetical launch inherited `_held=true`, whereas actual explicit release sets it false; the old preview therefore caught at bed while the actual helper-off shot rebounded. Sharing the physical collision function was insufficient because input state differed.

Changed only `snapshot()` production behavior: copy `_held` into a local `preview_held`; when constructing a hypothetical charged-ready release set this local flag false; pass it to existing shared `_flight`. Already-airborne prediction keeps actual current held catch preparation. Helper state and every physics/coefficient/success/score/input condition remain unchanged. No new API, state field, dependency, option, wrapper or framework. Self-check compared the red-stage Model source against the frozen source and asserted that exactly those three textual changes produce the final Model.

## Correct actual RED→GREEN

1. Added `_prediction_input_state` public-input regression first, leaving the production Model unchanged. Ran `python .review/jelly-trampoline-20261118/model/run.py fix1-preview-red`.
2. RED import exit0/errors0; test exit1/errors2, exact marker **`Jelly trampoline tests: 205 checks, 2 failures`**. Both failures identify the finding: charged-ready preview failed to continue through the real rebound and mismatched explicitly released motion. RED receipt Model SHA equals the original frozen `d3573a2c4307833756deeef08f2f93e967e0d23dab13cf4b81756f1afb3f4f1b`; the regression fixture hash is identical between RED and GREEN.
3. Applied the minimal snapshot-local input correction, then ran `python .review/jelly-trampoline-20261118/model/run.py fix1-preview-green`.
4. GREEN import and test both exit0/errors0. New exact frozen marker: **`Jelly trampoline tests: 215 checks, 0 failures`**. The assertion count increases from RED because the corrected preview supplies all24points, allowing ten additional actual-sample comparisons; no test/assertion was removed or weakened.

Raw logs: `.review/jelly-trampoline-20261118/model/fix1-preview-red-import.log`, `fix1-preview-red-test.log`, `fix1-preview-green-import.log`, `fix1-preview-green-test.log`.

Automatic full command/environment/exit/error/source-manifest receipts: `fix1-preview-red-receipt.json`, `fix1-preview-green-receipt.json`, alongside those logs. Updated `evidence-index.json` retains the earlier candidate under `before_fix_round_1` and identifies the current frozen source and marker.

Fresh RED stage: `D:\Snapland-QA\jelly_trampoline-model-fix1-preview-red-b5b19db8\project`.
Fresh GREEN stage: `D:\Snapland-QA\jelly_trampoline-model-fix1-preview-green-72f53413\project`.

Both used exact validated Godot `C:/Tools/Godot/Godot_v4.7.2-stable_win64_console.exe`, headless import then `--script res://game/tests/test_jelly_trampoline.gd`. Each import/test process has independent absolute D save/APPDATA/LOCALAPPDATA/TEMP/TMP paths recorded in its receipt. The same tracked-runtime `prepare_runtime_stage` and exact owned two-file explicit fixture closure were retained; no whole-test/tree/cache or player-profile copy and no broad/full-suite rerun.

## Required regressions and preserved behavior

- Charged-ready normal A /bed340 /tilt0 /helper off /hold0.8seconds, followed by real explicit release. The saved prediction must have24points and match actual0.1-second samples through and after bed rebounds. Actual rebounds logged at flight time1.3, y469.471373403, vy−282.886547322, and flight time2.1, y473.948578072, vy−135.834231652. Fruit remains in real flight; no auto catch/charging. Repeated snapshots preserve the real held ready state.
- Already-airborne held preparation: launch the same vertical shot, advance0.2seconds, call begin_charge while airborne, then snapshot. Prediction remains a legitimate12-point catch path with endpoint(340,492); all nonterminal0.1-second samples match actual motion. Real descending contact catches with velocities0, ready/charging true and charge time only after contact. No forced release was applied to airborne prediction.
- Charged-ready helper enabled: hypothetical release still predicts genuine helper contact catch, and actual explicit release catches without starting charge. This guards helper preservation independently of held input.
- Existing detached nested snapshots, mutable trajectory isolation and24-point maximum remain covered. New regressions use only public inputs and snapshots, with no private state/result/score/contact injection.
- All original171 checks remain. Eight public A/B×normal/assist×ordinary/bell routes keep exactly the previous elapsed values, three real deliveries, scores400/500 and correct devil states. All four assisted route actual AI catches and the separate real same-fruit bell→bed620→manual release→third delivery remain in the same GREEN log; final bell-recatch delivery stillelapsed11.114980510, score500/deviltrue. Deadline and other physics checks remain unchanged.

## Current frozen source hashes

- `game/minigames/jelly_trampoline_model.gd`: `86134f411bae5c41bee6732340155bb06ca6991d85b9e98ef5b5191bd90cf822`
- `game/tests/test_jelly_trampoline.gd`: `4731a456790147a9bf8844affed605f88f2d6b7985af8bb1a99691cfc7e6913e`

The source hashes equal both GREEN automatic staged manifests. No further source writes or same-code reruns follow this freeze. This round proves the reviewed model prediction correction only; native UI/input/3D/GPU/audio/export and full suites remain outside this task. Headless numeric checks are not human gameplay evidence.
